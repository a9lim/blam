import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605636720026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.app (.var 0) (.var 0))))))
theorem wire_e605636720026 : Closed e605636720026 ∧ code e605636720026 = 2804659975578 := by decide
theorem cert_e605636720026 : check e605636720026 [[],[]] .chain = true := by decide
def e605636720182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))) (.var 1)))))
theorem wire_e605636720182 : Closed e605636720182 ∧ code e605636720182 = 2804659975734 := by decide
theorem cert_e605636720182 : check e605636720182 [[],[]] .sourceHead = true := by decide
def e605636720234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))) (.var 0)))))
theorem wire_e605636720234 : Closed e605636720234 ∧ code e605636720234 = 2804659975786 := by decide
theorem cert_e605636720234 : check e605636720234 [[],[]] .chain = true := by decide
def e605636720258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.lam (.var 0)))))))
theorem wire_e605636720258 : Closed e605636720258 ∧ code e605636720258 = 2804659975810 := by decide
theorem cert_e605636720258 : check e605636720258 [[],[]] .chain = true := by decide
def e605636720270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 2))))))
theorem wire_e605636720270 : Closed e605636720270 ∧ code e605636720270 = 2804659975822 := by decide
theorem cert_e605636720270 : check e605636720270 [[],[]] .sourceHead = true := by decide
def e605636720282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.app (.var 0) (.var 0))))))
theorem wire_e605636720282 : Closed e605636720282 ∧ code e605636720282 = 2804659975834 := by decide
theorem cert_e605636720282 : check e605636720282 [[],[]] .chain = true := by decide
def e605636726650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))) (.var 0)))))
theorem wire_e605636726650 : Closed e605636726650 ∧ code e605636726650 = 2804659982202 := by decide
theorem cert_e605636726650 : check e605636726650 [[],[]] .chain = true := by decide
def e605636726714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))) (.var 0)))))
theorem wire_e605636726714 : Closed e605636726714 ∧ code e605636726714 = 2804659982266 := by decide
theorem cert_e605636726714 : check e605636726714 [[],[]] .chain = true := by decide
def e605636734394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e605636734394 : Closed e605636734394 ∧ code e605636734394 = 2804659989946 := by decide
theorem cert_e605636734394 : check e605636734394 [[],[]] .chain = true := by decide
def e605636734426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e605636734426 : Closed e605636734426 ∧ code e605636734426 = 2804659989978 := by decide
theorem cert_e605636734426 : check e605636734426 [[],[]] .chain = true := by decide
def e605636734650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e605636734650 : Closed e605636734650 ∧ code e605636734650 = 2804659990202 := by decide
theorem cert_e605636734650 : check e605636734650 [[],[]] .chain = true := by decide
def e605636734698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e605636734698 : Closed e605636734698 ∧ code e605636734698 = 2804659990250 := by decide
theorem cert_e605636734698 : check e605636734698 [[],[]] .chain = true := by decide
def e605636734810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e605636734810 : Closed e605636734810 ∧ code e605636734810 = 2804659990362 := by decide
theorem cert_e605636734810 : check e605636734810 [[],[]] .chain = true := by decide
def e605636734826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e605636734826 : Closed e605636734826 ∧ code e605636734826 = 2804659990378 := by decide
theorem cert_e605636734826 : check e605636734826 [[],[]] .chain = true := by decide
def e605636735930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e605636735930 : Closed e605636735930 ∧ code e605636735930 = 2804659991482 := by decide
theorem cert_e605636735930 : check e605636735930 [[],[]] .chain = true := by decide
def e605636735962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e605636735962 : Closed e605636735962 ∧ code e605636735962 = 2804659991514 := by decide
theorem cert_e605636735962 : check e605636735962 [[],[]] .chain = true := by decide
def e605636737270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))) (.var 1)))))
theorem wire_e605636737270 : Closed e605636737270 ∧ code e605636737270 = 2804659992822 := by decide
theorem cert_e605636737270 : check e605636737270 [[],[]] .sourceHead = true := by decide
def e605636737466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e605636737466 : Closed e605636737466 ∧ code e605636737466 = 2804659993018 := by decide
theorem cert_e605636737466 : check e605636737466 [[],[]] .chain = true := by decide
def e605636737514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e605636737514 : Closed e605636737514 ∧ code e605636737514 = 2804659993066 := by decide
theorem cert_e605636737514 : check e605636737514 [[],[]] .chain = true := by decide
def e605636737922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.lam (.var 0)))))))
theorem wire_e605636737922 : Closed e605636737922 ∧ code e605636737922 = 2804659993474 := by decide
theorem cert_e605636737922 : check e605636737922 [[],[]] .chain = true := by decide
def e605636737934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 2))))))
theorem wire_e605636737934 : Closed e605636737934 ∧ code e605636737934 = 2804659993486 := by decide
theorem cert_e605636737934 : check e605636737934 [[],[]] .sourceHead = true := by decide
def e605636737946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.app (.var 0) (.var 0))))))
theorem wire_e605636737946 : Closed e605636737946 ∧ code e605636737946 = 2804659993498 := by decide
theorem cert_e605636737946 : check e605636737946 [[],[]] .chain = true := by decide
def e605636738166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))) (.var 1)))))
theorem wire_e605636738166 : Closed e605636738166 ∧ code e605636738166 = 2804659993718 := by decide
theorem cert_e605636738166 : check e605636738166 [[],[]] .sourceHead = true := by decide
def e605636738266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e605636738266 : Closed e605636738266 ∧ code e605636738266 = 2804659993818 := by decide
theorem cert_e605636738266 : check e605636738266 [[],[]] .chain = true := by decide
def e605636738282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e605636738282 : Closed e605636738282 ∧ code e605636738282 = 2804659993834 := by decide
theorem cert_e605636738282 : check e605636738282 [[],[]] .chain = true := by decide
def e605636738434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.lam (.var 0)))))))
theorem wire_e605636738434 : Closed e605636738434 ∧ code e605636738434 = 2804659993986 := by decide
theorem cert_e605636738434 : check e605636738434 [[],[]] .chain = true := by decide
def e605636738446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 2))))))
theorem wire_e605636738446 : Closed e605636738446 ∧ code e605636738446 = 2804659993998 := by decide
theorem cert_e605636738446 : check e605636738446 [[],[]] .sourceHead = true := by decide
def e605636738458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.app (.var 0) (.var 0))))))
theorem wire_e605636738458 : Closed e605636738458 ∧ code e605636738458 = 2804659994010 := by decide
theorem cert_e605636738458 : check e605636738458 [[],[]] .chain = true := by decide
def e605636757370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))) (.var 0)))))
theorem wire_e605636757370 : Closed e605636757370 ∧ code e605636757370 = 2804660012922 := by decide
theorem cert_e605636757370 : check e605636757370 [[],[]] .chain = true := by decide
def e605636757466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))) (.var 0)))))
theorem wire_e605636757466 : Closed e605636757466 ∧ code e605636757466 = 2804660013018 := by decide
theorem cert_e605636757466 : check e605636757466 [[],[]] .chain = true := by decide
def e605636761274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e605636761274 : Closed e605636761274 ∧ code e605636761274 = 2804660016826 := by decide
theorem cert_e605636761274 : check e605636761274 [[],[]] .chain = true := by decide
def e605636761322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e605636761322 : Closed e605636761322 ∧ code e605636761322 = 2804660016874 := by decide
theorem cert_e605636761322 : check e605636761322 [[],[]] .chain = true := by decide
def e605636761514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))) (.var 0)))))
theorem wire_e605636761514 : Closed e605636761514 ∧ code e605636761514 = 2804660017066 := by decide
theorem cert_e605636761514 : check e605636761514 [[],[]] .chain = true := by decide
def e605636761846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))) (.var 1)))))
theorem wire_e605636761846 : Closed e605636761846 ∧ code e605636761846 = 2804660017398 := by decide
theorem cert_e605636761846 : check e605636761846 [[],[]] .sourceHead = true := by decide
def e605636762042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e605636762042 : Closed e605636762042 ∧ code e605636762042 = 2804660017594 := by decide
theorem cert_e605636762042 : check e605636762042 [[],[]] .chain = true := by decide
def e605636762090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e605636762090 : Closed e605636762090 ∧ code e605636762090 = 2804660017642 := by decide
theorem cert_e605636762090 : check e605636762090 [[],[]] .chain = true := by decide
def e605636762498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.lam (.var 0)))))))
theorem wire_e605636762498 : Closed e605636762498 ∧ code e605636762498 = 2804660018050 := by decide
theorem cert_e605636762498 : check e605636762498 [[],[]] .chain = true := by decide
def e605636762510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 2))))))
theorem wire_e605636762510 : Closed e605636762510 ∧ code e605636762510 = 2804660018062 := by decide
theorem cert_e605636762510 : check e605636762510 [[],[]] .sourceHead = true := by decide
def e605636762522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.app (.var 0) (.var 0))))))
theorem wire_e605636762522 : Closed e605636762522 ∧ code e605636762522 = 2804660018074 := by decide
theorem cert_e605636762522 : check e605636762522 [[],[]] .chain = true := by decide
def e605636763190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))) (.var 1)))))
theorem wire_e605636763190 : Closed e605636763190 ∧ code e605636763190 = 2804660018742 := by decide
theorem cert_e605636763190 : check e605636763190 [[],[]] .sourceHead = true := by decide
def e605636763242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))) (.var 0)))))
theorem wire_e605636763242 : Closed e605636763242 ∧ code e605636763242 = 2804660018794 := by decide
theorem cert_e605636763242 : check e605636763242 [[],[]] .chain = true := by decide
def e605636763266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.lam (.var 0)))))))
theorem wire_e605636763266 : Closed e605636763266 ∧ code e605636763266 = 2804660018818 := by decide
theorem cert_e605636763266 : check e605636763266 [[],[]] .chain = true := by decide
def e605636763278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 2))))))
theorem wire_e605636763278 : Closed e605636763278 ∧ code e605636763278 = 2804660018830 := by decide
theorem cert_e605636763278 : check e605636763278 [[],[]] .sourceHead = true := by decide
def e605636763290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.app (.var 0) (.var 0))))))
theorem wire_e605636763290 : Closed e605636763290 ∧ code e605636763290 = 2804660018842 := by decide
theorem cert_e605636763290 : check e605636763290 [[],[]] .chain = true := by decide
def e605636772794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e605636772794 : Closed e605636772794 ∧ code e605636772794 = 2804660028346 := by decide
theorem cert_e605636772794 : check e605636772794 [[],[]] .chain = true := by decide
def e605636772826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e605636772826 : Closed e605636772826 ∧ code e605636772826 = 2804660028378 := by decide
theorem cert_e605636772826 : check e605636772826 [[],[]] .chain = true := by decide
def e605636774746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e605636774746 : Closed e605636774746 ∧ code e605636774746 = 2804660030298 := by decide
theorem cert_e605636774746 : check e605636774746 [[],[]] .chain = true := by decide
def e605636774762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e605636774762 : Closed e605636774762 ∧ code e605636774762 = 2804660030314 := by decide
theorem cert_e605636774762 : check e605636774762 [[],[]] .chain = true := by decide
def e605636774826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))) (.var 0)))))
theorem wire_e605636774826 : Closed e605636774826 ∧ code e605636774826 = 2804660030378 := by decide
theorem cert_e605636774826 : check e605636774826 [[],[]] .chain = true := by decide
def e605636775030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))) (.var 1)))))
theorem wire_e605636775030 : Closed e605636775030 ∧ code e605636775030 = 2804660030582 := by decide
theorem cert_e605636775030 : check e605636775030 [[],[]] .sourceHead = true := by decide
def e605636775130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e605636775130 : Closed e605636775130 ∧ code e605636775130 = 2804660030682 := by decide
theorem cert_e605636775130 : check e605636775130 [[],[]] .chain = true := by decide
def e605636775146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e605636775146 : Closed e605636775146 ∧ code e605636775146 = 2804660030698 := by decide
theorem cert_e605636775146 : check e605636775146 [[],[]] .chain = true := by decide
def e605636775298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.lam (.var 0)))))))
theorem wire_e605636775298 : Closed e605636775298 ∧ code e605636775298 = 2804660030850 := by decide
theorem cert_e605636775298 : check e605636775298 [[],[]] .chain = true := by decide
def e605636775310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 2))))))
theorem wire_e605636775310 : Closed e605636775310 ∧ code e605636775310 = 2804660030862 := by decide
theorem cert_e605636775310 : check e605636775310 [[],[]] .sourceHead = true := by decide
def e605636775322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.app (.var 0) (.var 0))))))
theorem wire_e605636775322 : Closed e605636775322 ∧ code e605636775322 = 2804660030874 := by decide
theorem cert_e605636775322 : check e605636775322 [[],[]] .chain = true := by decide
def e605636775478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))) (.var 1)))))
theorem wire_e605636775478 : Closed e605636775478 ∧ code e605636775478 = 2804660031030 := by decide
theorem cert_e605636775478 : check e605636775478 [[],[]] .sourceHead = true := by decide
def e605636775530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))) (.var 0)))))
theorem wire_e605636775530 : Closed e605636775530 ∧ code e605636775530 = 2804660031082 := by decide
theorem cert_e605636775530 : check e605636775530 [[],[]] .chain = true := by decide
def e605636775554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.lam (.var 0)))))))
theorem wire_e605636775554 : Closed e605636775554 ∧ code e605636775554 = 2804660031106 := by decide
theorem cert_e605636775554 : check e605636775554 [[],[]] .chain = true := by decide
def e605636775566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 2))))))
theorem wire_e605636775566 : Closed e605636775566 ∧ code e605636775566 = 2804660031118 := by decide
theorem cert_e605636775566 : check e605636775566 [[],[]] .sourceHead = true := by decide
def e605636775578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.app (.var 0) (.var 0))))))
theorem wire_e605636775578 : Closed e605636775578 ∧ code e605636775578 = 2804660031130 := by decide
theorem cert_e605636775578 : check e605636775578 [[],[]] .chain = true := by decide
def e605636791150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605636791150 : Closed e605636791150 ∧ code e605636791150 = 2804660046702 := by decide
theorem cert_e605636791150 : check e605636791150 [[],[]] .smaller = true := by decide
def e605636791158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605636791158 : Closed e605636791158 ∧ code e605636791158 = 2804660046710 := by decide
theorem cert_e605636791158 : check e605636791158 [[],[]] .smaller = true := by decide
def e605636791214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605636791214 : Closed e605636791214 ∧ code e605636791214 = 2804660046766 := by decide
theorem cert_e605636791214 : check e605636791214 [[],[]] .smaller = true := by decide
def e605636791226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605636791226 : Closed e605636791226 ∧ code e605636791226 = 2804660046778 := by decide
theorem cert_e605636791226 : check e605636791226 [[],[]] .smaller = true := by decide
def e605636791254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605636791254 : Closed e605636791254 ∧ code e605636791254 = 2804660046806 := by decide
theorem cert_e605636791254 : check e605636791254 [[],[]] .smaller = true := by decide
def e605636791258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605636791258 : Closed e605636791258 ∧ code e605636791258 = 2804660046810 := by decide
theorem cert_e605636791258 : check e605636791258 [[],[]] .smaller = true := by decide
def e605636791534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605636791534 : Closed e605636791534 ∧ code e605636791534 = 2804660047086 := by decide
theorem cert_e605636791534 : check e605636791534 [[],[]] .smaller = true := by decide
def e605636791542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605636791542 : Closed e605636791542 ∧ code e605636791542 = 2804660047094 := by decide
theorem cert_e605636791542 : check e605636791542 [[],[]] .smaller = true := by decide
def e605636791918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605636791918 : Closed e605636791918 ∧ code e605636791918 = 2804660047470 := by decide
theorem cert_e605636791918 : check e605636791918 [[],[]] .smaller = true := by decide
def e605636791930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605636791930 : Closed e605636791930 ∧ code e605636791930 = 2804660047482 := by decide
theorem cert_e605636791930 : check e605636791930 [[],[]] .smaller = true := by decide
def e605636792118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605636792118 : Closed e605636792118 ∧ code e605636792118 = 2804660047670 := by decide
theorem cert_e605636792118 : check e605636792118 [[],[]] .smaller = true := by decide
def e605636792122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605636792122 : Closed e605636792122 ∧ code e605636792122 = 2804660047674 := by decide
theorem cert_e605636792122 : check e605636792122 [[],[]] .smaller = true := by decide
def e605636987758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605636987758 : Closed e605636987758 ∧ code e605636987758 = 2804660243310 := by decide
theorem cert_e605636987758 : check e605636987758 [[],[]] .sourceHead = true := by decide
def e605636987766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605636987766 : Closed e605636987766 ∧ code e605636987766 = 2804660243318 := by decide
theorem cert_e605636987766 : check e605636987766 [[],[]] .sourceHead = true := by decide
def e605636987822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605636987822 : Closed e605636987822 ∧ code e605636987822 = 2804660243374 := by decide
theorem cert_e605636987822 : check e605636987822 [[],[]] .sourceHead = true := by decide
def e605636987834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605636987834 : Closed e605636987834 ∧ code e605636987834 = 2804660243386 := by decide
theorem cert_e605636987834 : check e605636987834 [[],[]] .sourceHead = true := by decide
def e605636987862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605636987862 : Closed e605636987862 ∧ code e605636987862 = 2804660243414 := by decide
theorem cert_e605636987862 : check e605636987862 [[],[]] .sourceHead = true := by decide
def e605636987866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605636987866 : Closed e605636987866 ∧ code e605636987866 = 2804660243418 := by decide
theorem cert_e605636987866 : check e605636987866 [[],[]] .sourceHead = true := by decide
def e605636988142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605636988142 : Closed e605636988142 ∧ code e605636988142 = 2804660243694 := by decide
theorem cert_e605636988142 : check e605636988142 [[],[]] .sourceHead = true := by decide
def e605636988150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605636988150 : Closed e605636988150 ∧ code e605636988150 = 2804660243702 := by decide
theorem cert_e605636988150 : check e605636988150 [[],[]] .sourceHead = true := by decide
def e605636988526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605636988526 : Closed e605636988526 ∧ code e605636988526 = 2804660244078 := by decide
theorem cert_e605636988526 : check e605636988526 [[],[]] .sourceHead = true := by decide
def e605636988538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605636988538 : Closed e605636988538 ∧ code e605636988538 = 2804660244090 := by decide
theorem cert_e605636988538 : check e605636988538 [[],[]] .sourceHead = true := by decide
def e605636988726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605636988726 : Closed e605636988726 ∧ code e605636988726 = 2804660244278 := by decide
theorem cert_e605636988726 : check e605636988726 [[],[]] .sourceHead = true := by decide
def e605636988730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605636988730 : Closed e605636988730 ∧ code e605636988730 = 2804660244282 := by decide
theorem cert_e605636988730 : check e605636988730 [[],[]] .sourceHead = true := by decide
def e605637324218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e605637324218 : Closed e605637324218 ∧ code e605637324218 = 2804660579770 := by decide
theorem cert_e605637324218 : check e605637324218 [[],[]] .chain = true := by decide
def e605637324250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e605637324250 : Closed e605637324250 ∧ code e605637324250 = 2804660579802 := by decide
theorem cert_e605637324250 : check e605637324250 [[],[]] .chain = true := by decide
def e605637324474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e605637324474 : Closed e605637324474 ∧ code e605637324474 = 2804660580026 := by decide
theorem cert_e605637324474 : check e605637324474 [[],[]] .chain = true := by decide
def e605637324522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e605637324522 : Closed e605637324522 ∧ code e605637324522 = 2804660580074 := by decide
theorem cert_e605637324522 : check e605637324522 [[],[]] .chain = true := by decide
def e605637324634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e605637324634 : Closed e605637324634 ∧ code e605637324634 = 2804660580186 := by decide
theorem cert_e605637324634 : check e605637324634 [[],[]] .chain = true := by decide
def e605637324650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e605637324650 : Closed e605637324650 ∧ code e605637324650 = 2804660580202 := by decide
theorem cert_e605637324650 : check e605637324650 [[],[]] .chain = true := by decide
def e605637325754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e605637325754 : Closed e605637325754 ∧ code e605637325754 = 2804660581306 := by decide
theorem cert_e605637325754 : check e605637325754 [[],[]] .chain = true := by decide
def e605637325786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e605637325786 : Closed e605637325786 ∧ code e605637325786 = 2804660581338 := by decide
theorem cert_e605637325786 : check e605637325786 [[],[]] .chain = true := by decide
def e605637327290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e605637327290 : Closed e605637327290 ∧ code e605637327290 = 2804660582842 := by decide
theorem cert_e605637327290 : check e605637327290 [[],[]] .chain = true := by decide
def e605637327338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e605637327338 : Closed e605637327338 ∧ code e605637327338 = 2804660582890 := by decide
theorem cert_e605637327338 : check e605637327338 [[],[]] .chain = true := by decide
def e605637328090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e605637328090 : Closed e605637328090 ∧ code e605637328090 = 2804660583642 := by decide
theorem cert_e605637328090 : check e605637328090 [[],[]] .chain = true := by decide
def e605637328106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e605637328106 : Closed e605637328106 ∧ code e605637328106 = 2804660583658 := by decide
theorem cert_e605637328106 : check e605637328106 [[],[]] .chain = true := by decide
def e605637380974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605637380974 : Closed e605637380974 ∧ code e605637380974 = 2804660636526 := by decide
theorem cert_e605637380974 : check e605637380974 [[],[]] .chain = true := by decide
def e605637380982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605637380982 : Closed e605637380982 ∧ code e605637380982 = 2804660636534 := by decide
theorem cert_e605637380982 : check e605637380982 [[],[]] .chain = true := by decide
def e605637381038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605637381038 : Closed e605637381038 ∧ code e605637381038 = 2804660636590 := by decide
theorem cert_e605637381038 : check e605637381038 [[],[]] .chain = true := by decide
def e605637381050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605637381050 : Closed e605637381050 ∧ code e605637381050 = 2804660636602 := by decide
theorem cert_e605637381050 : check e605637381050 [[],[]] .chain = true := by decide
def e605637381078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605637381078 : Closed e605637381078 ∧ code e605637381078 = 2804660636630 := by decide
theorem cert_e605637381078 : check e605637381078 [[],[]] .chain = true := by decide
def e605637381082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605637381082 : Closed e605637381082 ∧ code e605637381082 = 2804660636634 := by decide
theorem cert_e605637381082 : check e605637381082 [[],[]] .chain = true := by decide
def e605637381358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605637381358 : Closed e605637381358 ∧ code e605637381358 = 2804660636910 := by decide
theorem cert_e605637381358 : check e605637381358 [[],[]] .chain = true := by decide
def e605637381366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605637381366 : Closed e605637381366 ∧ code e605637381366 = 2804660636918 := by decide
theorem cert_e605637381366 : check e605637381366 [[],[]] .chain = true := by decide
def e605637381742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605637381742 : Closed e605637381742 ∧ code e605637381742 = 2804660637294 := by decide
theorem cert_e605637381742 : check e605637381742 [[],[]] .chain = true := by decide
def e605637381754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605637381754 : Closed e605637381754 ∧ code e605637381754 = 2804660637306 := by decide
theorem cert_e605637381754 : check e605637381754 [[],[]] .chain = true := by decide
def e605637381942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605637381942 : Closed e605637381942 ∧ code e605637381942 = 2804660637494 := by decide
theorem cert_e605637381942 : check e605637381942 [[],[]] .chain = true := by decide
def e605637381946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605637381946 : Closed e605637381946 ∧ code e605637381946 = 2804660637498 := by decide
theorem cert_e605637381946 : check e605637381946 [[],[]] .chain = true := by decide
def e605637577582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605637577582 : Closed e605637577582 ∧ code e605637577582 = 2804660833134 := by decide
theorem cert_e605637577582 : check e605637577582 [[],[]] .smaller = true := by decide
def e605637577590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605637577590 : Closed e605637577590 ∧ code e605637577590 = 2804660833142 := by decide
theorem cert_e605637577590 : check e605637577590 [[],[]] .smaller = true := by decide
def e605637577646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605637577646 : Closed e605637577646 ∧ code e605637577646 = 2804660833198 := by decide
theorem cert_e605637577646 : check e605637577646 [[],[]] .smaller = true := by decide
def e605637577658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605637577658 : Closed e605637577658 ∧ code e605637577658 = 2804660833210 := by decide
theorem cert_e605637577658 : check e605637577658 [[],[]] .smaller = true := by decide
def e605637577686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605637577686 : Closed e605637577686 ∧ code e605637577686 = 2804660833238 := by decide
theorem cert_e605637577686 : check e605637577686 [[],[]] .smaller = true := by decide
def e605637577690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605637577690 : Closed e605637577690 ∧ code e605637577690 = 2804660833242 := by decide
theorem cert_e605637577690 : check e605637577690 [[],[]] .smaller = true := by decide
def e605637577966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605637577966 : Closed e605637577966 ∧ code e605637577966 = 2804660833518 := by decide
theorem cert_e605637577966 : check e605637577966 [[],[]] .smaller = true := by decide
def e605637577974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605637577974 : Closed e605637577974 ∧ code e605637577974 = 2804660833526 := by decide
theorem cert_e605637577974 : check e605637577974 [[],[]] .smaller = true := by decide
def e605637578350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605637578350 : Closed e605637578350 ∧ code e605637578350 = 2804660833902 := by decide
theorem cert_e605637578350 : check e605637578350 [[],[]] .smaller = true := by decide
def e605637578362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605637578362 : Closed e605637578362 ∧ code e605637578362 = 2804660833914 := by decide
theorem cert_e605637578362 : check e605637578362 [[],[]] .smaller = true := by decide
def e605637578550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605637578550 : Closed e605637578550 ∧ code e605637578550 = 2804660834102 := by decide
theorem cert_e605637578550 : check e605637578550 [[],[]] .smaller = true := by decide
def e605637578554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605637578554 : Closed e605637578554 ∧ code e605637578554 = 2804660834106 := by decide
theorem cert_e605637578554 : check e605637578554 [[],[]] .smaller = true := by decide
def e605637586398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e605637586398 : Closed e605637586398 ∧ code e605637586398 = 2804660841950 := by decide
theorem cert_e605637586398 : check e605637586398 [[],[]] .chain = true := by decide
def e605637586414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e605637586414 : Closed e605637586414 ∧ code e605637586414 = 2804660841966 := by decide
theorem cert_e605637586414 : check e605637586414 [[],[]] .chain = true := by decide
def e605637586782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e605637586782 : Closed e605637586782 ∧ code e605637586782 = 2804660842334 := by decide
theorem cert_e605637586782 : check e605637586782 [[],[]] .chain = true := by decide
def e605637586810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e605637586810 : Closed e605637586810 ∧ code e605637586810 = 2804660842362 := by decide
theorem cert_e605637586810 : check e605637586810 [[],[]] .chain = true := by decide
def e605637586862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e605637586862 : Closed e605637586862 ∧ code e605637586862 = 2804660842414 := by decide
theorem cert_e605637586862 : check e605637586862 [[],[]] .chain = true := by decide
def e605637586874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e605637586874 : Closed e605637586874 ∧ code e605637586874 = 2804660842426 := by decide
theorem cert_e605637586874 : check e605637586874 [[],[]] .chain = true := by decide
def e605637587934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e605637587934 : Closed e605637587934 ∧ code e605637587934 = 2804660843486 := by decide
theorem cert_e605637587934 : check e605637587934 [[],[]] .chain = true := by decide
def e605637587950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e605637587950 : Closed e605637587950 ∧ code e605637587950 = 2804660843502 := by decide
theorem cert_e605637587950 : check e605637587950 [[],[]] .chain = true := by decide
def e605637590238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e605637590238 : Closed e605637590238 ∧ code e605637590238 = 2804660845790 := by decide
theorem cert_e605637590238 : check e605637590238 [[],[]] .chain = true := by decide
def e605637590266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e605637590266 : Closed e605637590266 ∧ code e605637590266 = 2804660845818 := by decide
theorem cert_e605637590266 : check e605637590266 [[],[]] .chain = true := by decide
def e605637590638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e605637590638 : Closed e605637590638 ∧ code e605637590638 = 2804660846190 := by decide
theorem cert_e605637590638 : check e605637590638 [[],[]] .chain = true := by decide
def e605637590650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e605637590650 : Closed e605637590650 ∧ code e605637590650 = 2804660846202 := by decide
theorem cert_e605637590650 : check e605637590650 [[],[]] .chain = true := by decide
def e605637619054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605637619054 : Closed e605637619054 ∧ code e605637619054 = 2804660874606 := by decide
theorem cert_e605637619054 : check e605637619054 [[],[]] .chain = true := by decide
def e605637619062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605637619062 : Closed e605637619062 ∧ code e605637619062 = 2804660874614 := by decide
theorem cert_e605637619062 : check e605637619062 [[],[]] .chain = true := by decide
def e605637619118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605637619118 : Closed e605637619118 ∧ code e605637619118 = 2804660874670 := by decide
theorem cert_e605637619118 : check e605637619118 [[],[]] .chain = true := by decide
def e605637619130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605637619130 : Closed e605637619130 ∧ code e605637619130 = 2804660874682 := by decide
theorem cert_e605637619130 : check e605637619130 [[],[]] .chain = true := by decide
def e605637619158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605637619158 : Closed e605637619158 ∧ code e605637619158 = 2804660874710 := by decide
theorem cert_e605637619158 : check e605637619158 [[],[]] .chain = true := by decide
def e605637619162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605637619162 : Closed e605637619162 ∧ code e605637619162 = 2804660874714 := by decide
theorem cert_e605637619162 : check e605637619162 [[],[]] .chain = true := by decide
def e605637619374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605637619374 : Closed e605637619374 ∧ code e605637619374 = 2804660874926 := by decide
theorem cert_e605637619374 : check e605637619374 [[],[]] .chain = true := by decide
def e605637619386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605637619386 : Closed e605637619386 ∧ code e605637619386 = 2804660874938 := by decide
theorem cert_e605637619386 : check e605637619386 [[],[]] .chain = true := by decide
def e605637619434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605637619434 : Closed e605637619434 ∧ code e605637619434 = 2804660874986 := by decide
theorem cert_e605637619434 : check e605637619434 [[],[]] .chain = true := by decide
def e605637619542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605637619542 : Closed e605637619542 ∧ code e605637619542 = 2804660875094 := by decide
theorem cert_e605637619542 : check e605637619542 [[],[]] .chain = true := by decide
def e605637619546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605637619546 : Closed e605637619546 ∧ code e605637619546 = 2804660875098 := by decide
theorem cert_e605637619546 : check e605637619546 [[],[]] .chain = true := by decide
def e605637619562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605637619562 : Closed e605637619562 ∧ code e605637619562 = 2804660875114 := by decide
theorem cert_e605637619562 : check e605637619562 [[],[]] .chain = true := by decide
def e605637620590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605637620590 : Closed e605637620590 ∧ code e605637620590 = 2804660876142 := by decide
theorem cert_e605637620590 : check e605637620590 [[],[]] .chain = true := by decide
def e605637620598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605637620598 : Closed e605637620598 ∧ code e605637620598 = 2804660876150 := by decide
theorem cert_e605637620598 : check e605637620598 [[],[]] .chain = true := by decide
def e605637620654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605637620654 : Closed e605637620654 ∧ code e605637620654 = 2804660876206 := by decide
theorem cert_e605637620654 : check e605637620654 [[],[]] .chain = true := by decide
def e605637620666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605637620666 : Closed e605637620666 ∧ code e605637620666 = 2804660876218 := by decide
theorem cert_e605637620666 : check e605637620666 [[],[]] .chain = true := by decide
def e605637620694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605637620694 : Closed e605637620694 ∧ code e605637620694 = 2804660876246 := by decide
theorem cert_e605637620694 : check e605637620694 [[],[]] .chain = true := by decide
def e605637620698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605637620698 : Closed e605637620698 ∧ code e605637620698 = 2804660876250 := by decide
theorem cert_e605637620698 : check e605637620698 [[],[]] .chain = true := by decide
def e605637620974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605637620974 : Closed e605637620974 ∧ code e605637620974 = 2804660876526 := by decide
theorem cert_e605637620974 : check e605637620974 [[],[]] .chain = true := by decide
def e605637620982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605637620982 : Closed e605637620982 ∧ code e605637620982 = 2804660876534 := by decide
theorem cert_e605637620982 : check e605637620982 [[],[]] .chain = true := by decide
def e605637621358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605637621358 : Closed e605637621358 ∧ code e605637621358 = 2804660876910 := by decide
theorem cert_e605637621358 : check e605637621358 [[],[]] .chain = true := by decide
def e605637621370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605637621370 : Closed e605637621370 ∧ code e605637621370 = 2804660876922 := by decide
theorem cert_e605637621370 : check e605637621370 [[],[]] .chain = true := by decide
def e605637621558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605637621558 : Closed e605637621558 ∧ code e605637621558 = 2804660877110 := by decide
theorem cert_e605637621558 : check e605637621558 [[],[]] .chain = true := by decide
def e605637621562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605637621562 : Closed e605637621562 ∧ code e605637621562 = 2804660877114 := by decide
theorem cert_e605637621562 : check e605637621562 [[],[]] .chain = true := by decide
def e605637622190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605637622190 : Closed e605637622190 ∧ code e605637622190 = 2804660877742 := by decide
theorem cert_e605637622190 : check e605637622190 [[],[]] .chain = true := by decide
def e605637622202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605637622202 : Closed e605637622202 ∧ code e605637622202 = 2804660877754 := by decide
theorem cert_e605637622202 : check e605637622202 [[],[]] .chain = true := by decide
def e605637622250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605637622250 : Closed e605637622250 ∧ code e605637622250 = 2804660877802 := by decide
theorem cert_e605637622250 : check e605637622250 [[],[]] .chain = true := by decide
def e605637622382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605637622382 : Closed e605637622382 ∧ code e605637622382 = 2804660877934 := by decide
theorem cert_e605637622382 : check e605637622382 [[],[]] .chain = true := by decide
end Blc.Floor41
