import CodeBridge
import Batch044
namespace Certgen.R598355260270
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 7,.lam 2,.app 3 6,.app 4 5,.var 0,.var 0,.var 0,.lam 8,.app 9 10,.var 0,.lam 11,.lam 12,.app 13 18,.app 14 15,.var 0,.app 16 17,.var 0,.var 1,.var 2]
def values : Array (List AClo) := #[[⟨7,[]⟩],[⟨10,[3]⟩,⟨15,[2,1,3]⟩,⟨17,[2,1,3]⟩],[⟨6,[0]⟩,⟨10,[3]⟩,⟨15,[2,1,3]⟩,⟨17,[2,1,3]⟩,⟨18,[2,1,3]⟩],[⟨5,[0]⟩,⟨10,[3]⟩,⟨15,[2,1,3]⟩,⟨17,[2,1,3]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨7,[]⟩,0⟩],[⟨⟨18,[2,1,3]⟩,0⟩,⟨⟨18,[2,1,3]⟩,2⟩,⟨⟨18,[2,1,3]⟩,3⟩,⟨⟨18,[2,1,3]⟩,4⟩,⟨⟨18,[2,1,3]⟩,5⟩,⟨⟨18,[2,1,3]⟩,7⟩],[⟨⟨15,[2,1,3]⟩,2⟩],[⟨⟨17,[2,1,3]⟩,3⟩,⟨⟨17,[2,1,3]⟩,4⟩,⟨⟨17,[2,1,3]⟩,7⟩],[⟨⟨6,[0]⟩,0⟩],[⟨⟨5,[0]⟩,5⟩],[⟨⟨10,[3]⟩,2⟩,⟨⟨10,[3]⟩,3⟩,⟨⟨10,[3]⟩,4⟩,⟨⟨10,[3]⟩,5⟩,⟨⟨10,[3]⟩,7⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[0]⟩,0⟩,⟨⟨3,[0]⟩,5⟩,⟨⟨4,[0]⟩,6⟩,⟨⟨5,[0]⟩,3⟩,⟨⟨5,[0]⟩,4⟩,⟨⟨5,[0]⟩,7⟩,⟨⟨6,[0]⟩,3⟩,⟨⟨6,[0]⟩,4⟩,⟨⟨7,[]⟩,3⟩,⟨⟨7,[]⟩,4⟩,⟨⟨7,[]⟩,6⟩,⟨⟨7,[]⟩,7⟩,⟨⟨8,[3]⟩,2⟩,⟨⟨8,[3]⟩,3⟩,⟨⟨8,[3]⟩,4⟩,⟨⟨8,[3]⟩,5⟩,⟨⟨8,[3]⟩,7⟩,⟨⟨9,[3]⟩,7⟩,⟨⟨10,[3]⟩,3⟩,⟨⟨10,[3]⟩,4⟩,⟨⟨10,[3]⟩,7⟩,⟨⟨11,[1,3]⟩,2⟩,⟨⟨11,[1,3]⟩,3⟩,⟨⟨11,[1,3]⟩,4⟩,⟨⟨11,[1,3]⟩,5⟩,⟨⟨11,[1,3]⟩,7⟩,⟨⟨12,[2,1,3]⟩,0⟩,⟨⟨12,[2,1,3]⟩,2⟩,⟨⟨12,[2,1,3]⟩,3⟩,⟨⟨12,[2,1,3]⟩,4⟩,⟨⟨12,[2,1,3]⟩,5⟩,⟨⟨12,[2,1,3]⟩,7⟩,⟨⟨13,[2,1,3]⟩,2⟩,⟨⟨14,[2,1,3]⟩,3⟩,⟨⟨15,[2,1,3]⟩,3⟩,⟨⟨15,[2,1,3]⟩,4⟩,⟨⟨15,[2,1,3]⟩,7⟩,⟨⟨16,[2,1,3]⟩,4⟩,⟨⟨17,[2,1,3]⟩,3⟩,⟨⟨17,[2,1,3]⟩,4⟩,⟨⟨17,[2,1,3]⟩,7⟩,⟨⟨18,[2,1,3]⟩,3⟩,⟨⟨18,[2,1,3]⟩,4⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[4],[12],[10],[11],[13],[10],[11],[14],[15,16,18],[17],[14,15,16,17,18],[19],[19],[19],[19],[19],[7,22,38,42],[23],[24,25,27],[23,24,25,26,27],[28,29,30,31,32,33],[29],[30,31,33],[28],[29,30,31,32,33],[34],[34],[34],[34],[34],[34],[35],[8,20,36,40,43],[39],[39],[39],[9,21,37,41,44],[20,36,40],[21,37,41],[22,38,42],[5,20,36,40],[6,21,37,41]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem block24 : checkRange P V K states hints 24 12=true := by decide
theorem block36 : checkRange P V K states hints 36 9=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<45 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 by_cases h12 : i<24
 · exact range_sound block12 i (by omega) h12 hi
 by_cases h24 : i<36
 · exact range_sound block24 i (by omega) h24 hi
 exact range_sound block36 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Floor41 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit16 : Term := .var 0
def lit17 : Term := .var 1
def lit18 : Term := .var 2
def lit3 : Term := .app lit16 lit16
def lit15 : Term := .app lit16 lit17
def lit2 : Term := .app lit3 lit16
def lit13 : Term := .app lit16 lit15
def lit1 : Term := .lam lit2
def lit12 : Term := .app lit13 lit18
def lit11 : Term := .lam lit12
def lit10 : Term := .lam lit11
def lit8 : Term := .app lit16 lit10
def lit7 : Term := .lam lit8
def lit0 : Term := .app lit1 lit7
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub18 : model.term 18 = lit18 := model.var_eq 18 2 (by rfl)
theorem sub17 : model.term 17 = lit17 := model.var_eq 17 1 (by rfl)
theorem sub16 : model.term 16 = lit16 := model.var_eq 16 0 (by rfl)
theorem sub15 : model.term 15 = lit15 := by rw [model.app_eq 15 16 17 (by rfl), sub16, sub17]; rfl
theorem sub14 : model.term 14 = lit16 := model.var_eq 14 0 (by rfl)
theorem sub13 : model.term 13 = lit13 := by rw [model.app_eq 13 14 15 (by rfl), sub14, sub15]; rfl
theorem sub12 : model.term 12 = lit12 := by rw [model.app_eq 12 13 18 (by rfl), sub13, sub18]; rfl
theorem sub11 : model.term 11 = lit11 := by rw [model.lam_eq 11 12 (by rfl), sub12]; rfl
theorem sub10 : model.term 10 = lit10 := by rw [model.lam_eq 10 11 (by rfl), sub11]; rfl
theorem sub9 : model.term 9 = lit16 := model.var_eq 9 0 (by rfl)
theorem sub8 : model.term 8 = lit8 := by rw [model.app_eq 8 9 10 (by rfl), sub9, sub10]; rfl
theorem sub7 : model.term 7 = lit7 := by rw [model.lam_eq 7 8 (by rfl), sub8]; rfl
theorem sub6 : model.term 6 = lit16 := model.var_eq 6 0 (by rfl)
theorem sub5 : model.term 5 = lit16 := model.var_eq 5 0 (by rfl)
theorem sub4 : model.term 4 = lit16 := model.var_eq 4 0 (by rfl)
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 5 (by rfl), sub4, sub5]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 6 (by rfl), sub3, sub6]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.lam_eq 1 2 (by rfl), sub2]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 7 (by rfl), sub1, sub7]; rfl
theorem excluded : ¬ IsSelfInterpreter e598355260270 := by
 intro he
 have hp : replay [] e598355260270 = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (rawCount he) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R598355260270
