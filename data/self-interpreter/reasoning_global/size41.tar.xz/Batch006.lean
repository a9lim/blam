import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e175288536506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e175288536506 : Closed e175288536506 ∧ code e175288536506 = 2374311792058 := by decide
theorem cert_e175288536506 : check e175288536506 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288536538 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e175288536538 : Closed e175288536538 ∧ code e175288536538 = 2374311792090 := by decide
theorem cert_e175288536538 : check e175288536538 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288536762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e175288536762 : Closed e175288536762 ∧ code e175288536762 = 2374311792314 := by decide
theorem cert_e175288536762 : check e175288536762 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288536810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e175288536810 : Closed e175288536810 ∧ code e175288536810 = 2374311792362 := by decide
theorem cert_e175288536810 : check e175288536810 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288536922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e175288536922 : Closed e175288536922 ∧ code e175288536922 = 2374311792474 := by decide
theorem cert_e175288536922 : check e175288536922 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288536938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e175288536938 : Closed e175288536938 ∧ code e175288536938 = 2374311792490 := by decide
theorem cert_e175288536938 : check e175288536938 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288538042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e175288538042 : Closed e175288538042 ∧ code e175288538042 = 2374311793594 := by decide
theorem cert_e175288538042 : check e175288538042 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288538074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e175288538074 : Closed e175288538074 ∧ code e175288538074 = 2374311793626 := by decide
theorem cert_e175288538074 : check e175288538074 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288539578 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e175288539578 : Closed e175288539578 ∧ code e175288539578 = 2374311795130 := by decide
theorem cert_e175288539578 : check e175288539578 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288539626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e175288539626 : Closed e175288539626 ∧ code e175288539626 = 2374311795178 := by decide
theorem cert_e175288539626 : check e175288539626 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288540378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e175288540378 : Closed e175288540378 ∧ code e175288540378 = 2374311795930 := by decide
theorem cert_e175288540378 : check e175288540378 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288540394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e175288540394 : Closed e175288540394 ∧ code e175288540394 = 2374311795946 := by decide
theorem cert_e175288540394 : check e175288540394 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288542906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e175288542906 : Closed e175288542906 ∧ code e175288542906 = 2374311798458 := by decide
theorem cert_e175288542906 : check e175288542906 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288542954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e175288542954 : Closed e175288542954 ∧ code e175288542954 = 2374311798506 := by decide
theorem cert_e175288542954 : check e175288542954 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288543146 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e175288543146 : Closed e175288543146 ∧ code e175288543146 = 2374311798698 := by decide
theorem cert_e175288543146 : check e175288543146 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288543674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e175288543674 : Closed e175288543674 ∧ code e175288543674 = 2374311799226 := by decide
theorem cert_e175288543674 : check e175288543674 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288543722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e175288543722 : Closed e175288543722 ∧ code e175288543722 = 2374311799274 := by decide
theorem cert_e175288543722 : check e175288543722 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288544874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e175288544874 : Closed e175288544874 ∧ code e175288544874 = 2374311800426 := by decide
theorem cert_e175288544874 : check e175288544874 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288546138 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e175288546138 : Closed e175288546138 ∧ code e175288546138 = 2374311801690 := by decide
theorem cert_e175288546138 : check e175288546138 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288546154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e175288546154 : Closed e175288546154 ∧ code e175288546154 = 2374311801706 := by decide
theorem cert_e175288546154 : check e175288546154 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288546218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e175288546218 : Closed e175288546218 ∧ code e175288546218 = 2374311801770 := by decide
theorem cert_e175288546218 : check e175288546218 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288546522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e175288546522 : Closed e175288546522 ∧ code e175288546522 = 2374311802074 := by decide
theorem cert_e175288546522 : check e175288546522 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288546538 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e175288546538 : Closed e175288546538 ∧ code e175288546538 = 2374311802090 := by decide
theorem cert_e175288546538 : check e175288546538 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288546922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e175288546922 : Closed e175288546922 ∧ code e175288546922 = 2374311802474 := by decide
theorem cert_e175288546922 : check e175288546922 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288561082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e175288561082 : Closed e175288561082 ∧ code e175288561082 = 2374311816634 := by decide
theorem cert_e175288561082 : check e175288561082 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288561114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e175288561114 : Closed e175288561114 ∧ code e175288561114 = 2374311816666 := by decide
theorem cert_e175288561114 : check e175288561114 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288561338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e175288561338 : Closed e175288561338 ∧ code e175288561338 = 2374311816890 := by decide
theorem cert_e175288561338 : check e175288561338 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288561386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e175288561386 : Closed e175288561386 ∧ code e175288561386 = 2374311816938 := by decide
theorem cert_e175288561386 : check e175288561386 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288561498 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e175288561498 : Closed e175288561498 ∧ code e175288561498 = 2374311817050 := by decide
theorem cert_e175288561498 : check e175288561498 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288561514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e175288561514 : Closed e175288561514 ∧ code e175288561514 = 2374311817066 := by decide
theorem cert_e175288561514 : check e175288561514 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288562618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e175288562618 : Closed e175288562618 ∧ code e175288562618 = 2374311818170 := by decide
theorem cert_e175288562618 : check e175288562618 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288562650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e175288562650 : Closed e175288562650 ∧ code e175288562650 = 2374311818202 := by decide
theorem cert_e175288562650 : check e175288562650 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288564154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e175288564154 : Closed e175288564154 ∧ code e175288564154 = 2374311819706 := by decide
theorem cert_e175288564154 : check e175288564154 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288564202 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e175288564202 : Closed e175288564202 ∧ code e175288564202 = 2374311819754 := by decide
theorem cert_e175288564202 : check e175288564202 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288564954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e175288564954 : Closed e175288564954 ∧ code e175288564954 = 2374311820506 := by decide
theorem cert_e175288564954 : check e175288564954 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288564970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e175288564970 : Closed e175288564970 ∧ code e175288564970 = 2374311820522 := by decide
theorem cert_e175288564970 : check e175288564970 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288587962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e175288587962 : Closed e175288587962 ∧ code e175288587962 = 2374311843514 := by decide
theorem cert_e175288587962 : check e175288587962 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288588010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e175288588010 : Closed e175288588010 ∧ code e175288588010 = 2374311843562 := by decide
theorem cert_e175288588010 : check e175288588010 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288588202 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e175288588202 : Closed e175288588202 ∧ code e175288588202 = 2374311843754 := by decide
theorem cert_e175288588202 : check e175288588202 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288588730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e175288588730 : Closed e175288588730 ∧ code e175288588730 = 2374311844282 := by decide
theorem cert_e175288588730 : check e175288588730 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288588778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e175288588778 : Closed e175288588778 ∧ code e175288588778 = 2374311844330 := by decide
theorem cert_e175288588778 : check e175288588778 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288589930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e175288589930 : Closed e175288589930 ∧ code e175288589930 = 2374311845482 := by decide
theorem cert_e175288589930 : check e175288589930 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288601434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e175288601434 : Closed e175288601434 ∧ code e175288601434 = 2374311856986 := by decide
theorem cert_e175288601434 : check e175288601434 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288601450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e175288601450 : Closed e175288601450 ∧ code e175288601450 = 2374311857002 := by decide
theorem cert_e175288601450 : check e175288601450 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288601514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e175288601514 : Closed e175288601514 ∧ code e175288601514 = 2374311857066 := by decide
theorem cert_e175288601514 : check e175288601514 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288601818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e175288601818 : Closed e175288601818 ∧ code e175288601818 = 2374311857370 := by decide
theorem cert_e175288601818 : check e175288601818 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288601834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e175288601834 : Closed e175288601834 ∧ code e175288601834 = 2374311857386 := by decide
theorem cert_e175288601834 : check e175288601834 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288602218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e175288602218 : Closed e175288602218 ∧ code e175288602218 = 2374311857770 := by decide
theorem cert_e175288602218 : check e175288602218 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175289064378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.var 0)))
theorem wire_e175289064378 : Closed e175289064378 ∧ code e175289064378 = 2374312319930 := by decide
theorem cert_e175289064378 : check e175289064378 [[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e175289064890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e175289064890 : Closed e175289064890 ∧ code e175289064890 = 2374312320442 := by decide
theorem cert_e175289064890 : check e175289064890 [[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e175289064922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e175289064922 : Closed e175289064922 ∧ code e175289064922 = 2374312320474 := by decide
theorem cert_e175289064922 : check e175289064922 [[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e175289068474 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.var 0)))
theorem wire_e175289068474 : Closed e175289068474 ∧ code e175289068474 = 2374312324026 := by decide
theorem cert_e175289068474 : check e175289068474 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e175289069242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e175289069242 : Closed e175289069242 ∧ code e175289069242 = 2374312324794 := by decide
theorem cert_e175289069242 : check e175289069242 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e175289069290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e175289069290 : Closed e175289069290 ∧ code e175289069290 = 2374312324842 := by decide
theorem cert_e175289069290 : check e175289069290 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e175289071034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e175289071034 : Closed e175289071034 ∧ code e175289071034 = 2374312326586 := by decide
theorem cert_e175289071034 : check e175289071034 [[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e175289071066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e175289071066 : Closed e175289071066 ∧ code e175289071066 = 2374312326618 := by decide
theorem cert_e175289071066 : check e175289071066 [[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e175289071290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e175289071290 : Closed e175289071290 ∧ code e175289071290 = 2374312326842 := by decide
theorem cert_e175289071290 : check e175289071290 [[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e175289071338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e175289071338 : Closed e175289071338 ∧ code e175289071338 = 2374312326890 := by decide
theorem cert_e175289071338 : check e175289071338 [[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e175289071450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e175289071450 : Closed e175289071450 ∧ code e175289071450 = 2374312327002 := by decide
private def t_e175289071450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.var 0)))
theorem cert_e175289071450 : ¬ IsSelfInterpreter e175289071450 :=
  wSource (t := t_e175289071450) (replay_sound (ps := []) (t := e175289071450) (by decide)) (by decide)
def e175289071466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e175289071466 : Closed e175289071466 ∧ code e175289071466 = 2374312327018 := by decide
private def t_e175289071466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.var 0)))
theorem cert_e175289071466 : ¬ IsSelfInterpreter e175289071466 :=
  wSource (t := t_e175289071466) (replay_sound (ps := []) (t := e175289071466) (by decide)) (by decide)
def e175289088954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.var 0)))
theorem wire_e175289088954 : Closed e175289088954 ∧ code e175289088954 = 2374312344506 := by decide
theorem cert_e175289088954 : check e175289088954 [[.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e175289089466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e175289089466 : Closed e175289089466 ∧ code e175289089466 = 2374312345018 := by decide
theorem cert_e175289089466 : check e175289089466 [[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e175289089498 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e175289089498 : Closed e175289089498 ∧ code e175289089498 = 2374312345050 := by decide
theorem cert_e175289089498 : check e175289089498 [[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e175289100218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.var 0)))
theorem wire_e175289100218 : Closed e175289100218 ∧ code e175289100218 = 2374312355770 := by decide
theorem cert_e175289100218 : check e175289100218 [[.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e175289103290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e175289103290 : Closed e175289103290 ∧ code e175289103290 = 2374312358842 := by decide
theorem cert_e175289103290 : check e175289103290 [[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e175289103322 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e175289103322 : Closed e175289103322 ∧ code e175289103322 = 2374312358874 := by decide
theorem cert_e175289103322 : check e175289103322 [[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e175289113530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.var 0)))
theorem wire_e175289113530 : Closed e175289113530 ∧ code e175289113530 = 2374312369082 := by decide
theorem cert_e175289113530 : checkPay e175289113530 [[.left],[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left]] = true := by decide
def e175289114298 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e175289114298 : Closed e175289114298 ∧ code e175289114298 = 2374312369850 := by decide
theorem cert_e175289114298 : checkPay e175289114298 [[.left],[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e175289114346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e175289114346 : Closed e175289114346 ∧ code e175289114346 = 2374312369898 := by decide
theorem cert_e175289114346 : checkPay e175289114346 [[.left],[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e175289116602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.var 0)))
theorem wire_e175289116602 : Closed e175289116602 ∧ code e175289116602 = 2374312372154 := by decide
theorem cert_e175289116602 : checkPay e175289116602 [[.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e175289121210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e175289121210 : Closed e175289121210 ∧ code e175289121210 = 2374312376762 := by decide
theorem cert_e175289121210 : checkPay e175289121210 [[.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e175289121258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e175289121258 : Closed e175289121258 ∧ code e175289121258 = 2374312376810 := by decide
theorem cert_e175289121258 : checkPay e175289121258 [[.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e175289126330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e175289126330 : Closed e175289126330 ∧ code e175289126330 = 2374312381882 := by decide
theorem cert_e175289126330 : check e175289126330 [[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e175289126362 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e175289126362 : Closed e175289126362 ∧ code e175289126362 = 2374312381914 := by decide
theorem cert_e175289126362 : check e175289126362 [[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e175289126586 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e175289126586 : Closed e175289126586 ∧ code e175289126586 = 2374312382138 := by decide
theorem cert_e175289126586 : check e175289126586 [[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e175289126634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e175289126634 : Closed e175289126634 ∧ code e175289126634 = 2374312382186 := by decide
theorem cert_e175289126634 : check e175289126634 [[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e175289126746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e175289126746 : Closed e175289126746 ∧ code e175289126746 = 2374312382298 := by decide
theorem cert_e175289126746 : check e175289126746 [[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e175289126762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e175289126762 : Closed e175289126762 ∧ code e175289126762 = 2374312382314 := by decide
theorem cert_e175289126762 : check e175289126762 [[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e175289127866 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e175289127866 : Closed e175289127866 ∧ code e175289127866 = 2374312383418 := by decide
theorem cert_e175289127866 : check e175289127866 [[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e175289127898 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e175289127898 : Closed e175289127898 ∧ code e175289127898 = 2374312383450 := by decide
theorem cert_e175289127898 : check e175289127898 [[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e175289129402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e175289129402 : Closed e175289129402 ∧ code e175289129402 = 2374312384954 := by decide
theorem cert_e175289129402 : check e175289129402 [[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e175289129450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e175289129450 : Closed e175289129450 ∧ code e175289129450 = 2374312385002 := by decide
theorem cert_e175289129450 : check e175289129450 [[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e175289130202 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e175289130202 : Closed e175289130202 ∧ code e175289130202 = 2374312385754 := by decide
private def t_e175289130202 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem cert_e175289130202 : ¬ IsSelfInterpreter e175289130202 :=
  wSource (t := t_e175289130202) (replay_sound (ps := []) (t := e175289130202) (by decide)) (by decide)
def e175289130218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e175289130218 : Closed e175289130218 ∧ code e175289130218 = 2374312385770 := by decide
private def t_e175289130218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem cert_e175289130218 : ¬ IsSelfInterpreter e175289130218 :=
  wSource (t := t_e175289130218) (replay_sound (ps := []) (t := e175289130218) (by decide)) (by decide)
def e175289150906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e175289150906 : Closed e175289150906 ∧ code e175289150906 = 2374312406458 := by decide
theorem cert_e175289150906 : check e175289150906 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175289150938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e175289150938 : Closed e175289150938 ∧ code e175289150938 = 2374312406490 := by decide
theorem cert_e175289150938 : check e175289150938 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175289151162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e175289151162 : Closed e175289151162 ∧ code e175289151162 = 2374312406714 := by decide
theorem cert_e175289151162 : check e175289151162 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175289151210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e175289151210 : Closed e175289151210 ∧ code e175289151210 = 2374312406762 := by decide
theorem cert_e175289151210 : check e175289151210 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175289151322 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e175289151322 : Closed e175289151322 ∧ code e175289151322 = 2374312406874 := by decide
theorem cert_e175289151322 : check e175289151322 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175289151338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e175289151338 : Closed e175289151338 ∧ code e175289151338 = 2374312406890 := by decide
theorem cert_e175289151338 : check e175289151338 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175289152442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e175289152442 : Closed e175289152442 ∧ code e175289152442 = 2374312407994 := by decide
theorem cert_e175289152442 : check e175289152442 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175289152474 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e175289152474 : Closed e175289152474 ∧ code e175289152474 = 2374312408026 := by decide
theorem cert_e175289152474 : check e175289152474 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175289153978 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e175289153978 : Closed e175289153978 ∧ code e175289153978 = 2374312409530 := by decide
theorem cert_e175289153978 : check e175289153978 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175289154026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e175289154026 : Closed e175289154026 ∧ code e175289154026 = 2374312409578 := by decide
theorem cert_e175289154026 : check e175289154026 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175289154778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e175289154778 : Closed e175289154778 ∧ code e175289154778 = 2374312410330 := by decide
theorem cert_e175289154778 : check e175289154778 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175289154794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e175289154794 : Closed e175289154794 ∧ code e175289154794 = 2374312410346 := by decide
theorem cert_e175289154794 : check e175289154794 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175289187258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.var 0)))
theorem wire_e175289187258 : Closed e175289187258 ∧ code e175289187258 = 2374312442810 := by decide
theorem cert_e175289187258 : check e175289187258 [[.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e175289187770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e175289187770 : Closed e175289187770 ∧ code e175289187770 = 2374312443322 := by decide
theorem cert_e175289187770 : checkPay e175289187770 [[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e175289187802 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e175289187802 : Closed e175289187802 ∧ code e175289187802 = 2374312443354 := by decide
theorem cert_e175289187802 : check e175289187802 [[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e175289198522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.var 0)))
theorem wire_e175289198522 : Closed e175289198522 ∧ code e175289198522 = 2374312454074 := by decide
theorem cert_e175289198522 : check e175289198522 [[.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e175289201594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e175289201594 : Closed e175289201594 ∧ code e175289201594 = 2374312457146 := by decide
theorem cert_e175289201594 : check e175289201594 [[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e175289201626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e175289201626 : Closed e175289201626 ∧ code e175289201626 = 2374312457178 := by decide
theorem cert_e175289201626 : check e175289201626 [[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e175289293754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.var 0)))
theorem wire_e175289293754 : Closed e175289293754 ∧ code e175289293754 = 2374312549306 := by decide
theorem cert_e175289293754 : check e175289293754 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e175289294522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e175289294522 : Closed e175289294522 ∧ code e175289294522 = 2374312550074 := by decide
theorem cert_e175289294522 : check e175289294522 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e175289294570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e175289294570 : Closed e175289294570 ∧ code e175289294570 = 2374312550122 := by decide
theorem cert_e175289294570 : check e175289294570 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e175289296826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.var 0)))
theorem wire_e175289296826 : Closed e175289296826 ∧ code e175289296826 = 2374312552378 := by decide
theorem cert_e175289296826 : check e175289296826 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e175289301434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e175289301434 : Closed e175289301434 ∧ code e175289301434 = 2374312556986 := by decide
theorem cert_e175289301434 : check e175289301434 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e175289301482 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e175289301482 : Closed e175289301482 ∧ code e175289301482 = 2374312557034 := by decide
theorem cert_e175289301482 : check e175289301482 [[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e175289347514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e175289347514 : Closed e175289347514 ∧ code e175289347514 = 2374312603066 := by decide
theorem cert_e175289347514 : check e175289347514 [[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e175289347546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e175289347546 : Closed e175289347546 ∧ code e175289347546 = 2374312603098 := by decide
theorem cert_e175289347546 : check e175289347546 [[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e175289347770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e175289347770 : Closed e175289347770 ∧ code e175289347770 = 2374312603322 := by decide
theorem cert_e175289347770 : check e175289347770 [[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e175289347818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e175289347818 : Closed e175289347818 ∧ code e175289347818 = 2374312603370 := by decide
theorem cert_e175289347818 : check e175289347818 [[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e175289347930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e175289347930 : Closed e175289347930 ∧ code e175289347930 = 2374312603482 := by decide
theorem cert_e175289347930 : check e175289347930 [[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e175289347946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e175289347946 : Closed e175289347946 ∧ code e175289347946 = 2374312603498 := by decide
theorem cert_e175289347946 : check e175289347946 [[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e175289349050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e175289349050 : Closed e175289349050 ∧ code e175289349050 = 2374312604602 := by decide
theorem cert_e175289349050 : check e175289349050 [[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e175289349082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e175289349082 : Closed e175289349082 ∧ code e175289349082 = 2374312604634 := by decide
theorem cert_e175289349082 : check e175289349082 [[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e175289350586 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e175289350586 : Closed e175289350586 ∧ code e175289350586 = 2374312606138 := by decide
theorem cert_e175289350586 : check e175289350586 [[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e175289350634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e175289350634 : Closed e175289350634 ∧ code e175289350634 = 2374312606186 := by decide
theorem cert_e175289350634 : check e175289350634 [[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e175289351386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e175289351386 : Closed e175289351386 ∧ code e175289351386 = 2374312606938 := by decide
theorem cert_e175289351386 : check e175289351386 [[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e175289351402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e175289351402 : Closed e175289351402 ∧ code e175289351402 = 2374312606954 := by decide
theorem cert_e175289351402 : check e175289351402 [[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e175291510202 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e175291510202 : Closed e175291510202 ∧ code e175291510202 = 2374314765754 := by decide
theorem cert_e175291510202 : check e175291510202 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175291510234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e175291510234 : Closed e175291510234 ∧ code e175291510234 = 2374314765786 := by decide
theorem cert_e175291510234 : check e175291510234 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175291510458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e175291510458 : Closed e175291510458 ∧ code e175291510458 = 2374314766010 := by decide
theorem cert_e175291510458 : check e175291510458 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175291510506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e175291510506 : Closed e175291510506 ∧ code e175291510506 = 2374314766058 := by decide
theorem cert_e175291510506 : check e175291510506 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175291510618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e175291510618 : Closed e175291510618 ∧ code e175291510618 = 2374314766170 := by decide
theorem cert_e175291510618 : check e175291510618 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175291510634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e175291510634 : Closed e175291510634 ∧ code e175291510634 = 2374314766186 := by decide
theorem cert_e175291510634 : check e175291510634 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175291511738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e175291511738 : Closed e175291511738 ∧ code e175291511738 = 2374314767290 := by decide
theorem cert_e175291511738 : check e175291511738 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175291511770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e175291511770 : Closed e175291511770 ∧ code e175291511770 = 2374314767322 := by decide
theorem cert_e175291511770 : check e175291511770 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175291513274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e175291513274 : Closed e175291513274 ∧ code e175291513274 = 2374314768826 := by decide
theorem cert_e175291513274 : check e175291513274 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175291513322 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e175291513322 : Closed e175291513322 ∧ code e175291513322 = 2374314768874 := by decide
theorem cert_e175291513322 : check e175291513322 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175291514074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e175291514074 : Closed e175291514074 ∧ code e175291514074 = 2374314769626 := by decide
theorem cert_e175291514074 : check e175291514074 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175291514090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e175291514090 : Closed e175291514090 ∧ code e175291514090 = 2374314769642 := by decide
theorem cert_e175291514090 : check e175291514090 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e188989926938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188989926938 : Closed e188989926938 ∧ code e188989926938 = 2388013182490 := by decide
theorem cert_e188989926938 : check e188989926938 [] .sourceHead = true := by decide
def e188989928986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188989928986 : Closed e188989928986 ∧ code e188989928986 = 2388013184538 := by decide
theorem cert_e188989928986 : check e188989928986 [] .sourceHead = true := by decide
def e188989943322 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188989943322 : Closed e188989943322 ∧ code e188989943322 = 2388013198874 := by decide
theorem cert_e188989943322 : check e188989943322 [] .sourceHead = true := by decide
def e188989946394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188989946394 : Closed e188989946394 ∧ code e188989946394 = 2388013201946 := by decide
theorem cert_e188989946394 : check e188989946394 [] .sourceHead = true := by decide
def e188989953562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188989953562 : Closed e188989953562 ∧ code e188989953562 = 2388013209114 := by decide
theorem cert_e188989953562 : check e188989953562 [] .sourceHead = true := by decide
def e188989954586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188989954586 : Closed e188989954586 ∧ code e188989954586 = 2388013210138 := by decide
theorem cert_e188989954586 : check e188989954586 [] .sourceHead = true := by decide
def e188990008858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990008858 : Closed e188990008858 ∧ code e188990008858 = 2388013264410 := by decide
theorem cert_e188990008858 : check e188990008858 [] .sourceHead = true := by decide
def e188990011930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990011930 : Closed e188990011930 ∧ code e188990011930 = 2388013267482 := by decide
theorem cert_e188990011930 : check e188990011930 [] .sourceHead = true := by decide
def e188990024218 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990024218 : Closed e188990024218 ∧ code e188990024218 = 2388013279770 := by decide
theorem cert_e188990024218 : check e188990024218 [] .sourceHead = true := by decide
def e188990051866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990051866 : Closed e188990051866 ∧ code e188990051866 = 2388013307418 := by decide
theorem cert_e188990051866 : check e188990051866 [] .sourceHead = true := by decide
def e188990052890 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990052890 : Closed e188990052890 ∧ code e188990052890 = 2388013308442 := by decide
theorem cert_e188990052890 : check e188990052890 [] .sourceHead = true := by decide
def e188990056986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990056986 : Closed e188990056986 ∧ code e188990056986 = 2388013312538 := by decide
theorem cert_e188990056986 : check e188990056986 [] .sourceHead = true := by decide
def e188990320154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990320154 : Closed e188990320154 ∧ code e188990320154 = 2388013575706 := by decide
theorem cert_e188990320154 : check e188990320154 [] .sourceHead = true := by decide
def e188990322202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990322202 : Closed e188990322202 ∧ code e188990322202 = 2388013577754 := by decide
theorem cert_e188990322202 : check e188990322202 [] .sourceHead = true := by decide
def e188990336538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990336538 : Closed e188990336538 ∧ code e188990336538 = 2388013592090 := by decide
theorem cert_e188990336538 : check e188990336538 [] .sourceHead = true := by decide
def e188990339610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990339610 : Closed e188990339610 ∧ code e188990339610 = 2388013595162 := by decide
theorem cert_e188990339610 : check e188990339610 [] .sourceHead = true := by decide
def e188990346778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990346778 : Closed e188990346778 ∧ code e188990346778 = 2388013602330 := by decide
theorem cert_e188990346778 : check e188990346778 [] .sourceHead = true := by decide
def e188990347802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990347802 : Closed e188990347802 ∧ code e188990347802 = 2388013603354 := by decide
theorem cert_e188990347802 : check e188990347802 [] .sourceHead = true := by decide
def e188990418458 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990418458 : Closed e188990418458 ∧ code e188990418458 = 2388013674010 := by decide
theorem cert_e188990418458 : check e188990418458 [] .sourceHead = true := by decide
def e188990420506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990420506 : Closed e188990420506 ∧ code e188990420506 = 2388013676058 := by decide
theorem cert_e188990420506 : check e188990420506 [] .sourceHead = true := by decide
def e188990516762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990516762 : Closed e188990516762 ∧ code e188990516762 = 2388013772314 := by decide
theorem cert_e188990516762 : check e188990516762 [] .sourceHead = true := by decide
def e188990519834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990519834 : Closed e188990519834 ∧ code e188990519834 = 2388013775386 := by decide
theorem cert_e188990519834 : check e188990519834 [] .sourceHead = true := by decide
def e188990567962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990567962 : Closed e188990567962 ∧ code e188990567962 = 2388013823514 := by decide
theorem cert_e188990567962 : check e188990567962 [] .sourceHead = true := by decide
def e188990568986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990568986 : Closed e188990568986 ∧ code e188990568986 = 2388013824538 := by decide
theorem cert_e188990568986 : check e188990568986 [] .sourceHead = true := by decide
def e188990729754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990729754 : Closed e188990729754 ∧ code e188990729754 = 2388013985306 := by decide
theorem cert_e188990729754 : check e188990729754 [] .sourceHead = true := by decide
def e188990732826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990732826 : Closed e188990732826 ∧ code e188990732826 = 2388013988378 := by decide
theorem cert_e188990732826 : check e188990732826 [] .sourceHead = true := by decide
def e188990745114 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990745114 : Closed e188990745114 ∧ code e188990745114 = 2388014000666 := by decide
theorem cert_e188990745114 : check e188990745114 [] .sourceHead = true := by decide
def e188990778906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990778906 : Closed e188990778906 ∧ code e188990778906 = 2388014034458 := by decide
theorem cert_e188990778906 : check e188990778906 [] .sourceHead = true := by decide
end Blc.Floor41
