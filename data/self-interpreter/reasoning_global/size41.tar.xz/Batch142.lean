import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605791927534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e605791927534 : Closed e605791927534 ∧ code e605791927534 = 2804815183086 := by decide
theorem cert_e605791927534 : check e605791927534 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605791927542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e605791927542 : Closed e605791927542 ∧ code e605791927542 = 2804815183094 := by decide
theorem cert_e605791927542 : check e605791927542 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e605791927546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605791927546 : Closed e605791927546 ∧ code e605791927546 = 2804815183098 := by decide
theorem cert_e605791927546 : check e605791927546 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791927918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605791927918 : Closed e605791927918 ∧ code e605791927918 = 2804815183470 := by decide
def e605791927926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e605791927926 : Closed e605791927926 ∧ code e605791927926 = 2804815183478 := by decide
theorem cert_e605791927926 : check e605791927926 [[],[],[],[]] .chain = true := by decide
def e605791927930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605791927930 : Closed e605791927930 ∧ code e605791927930 = 2804815183482 := by decide
theorem cert_e605791927930 : check e605791927930 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e605791950558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605791950558 : Closed e605791950558 ∧ code e605791950558 = 2804815206110 := by decide
theorem cert_e605791950558 : check e605791950558 [[],[],[],[]] .chain = true := by decide
def e605791950574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e605791950574 : Closed e605791950574 ∧ code e605791950574 = 2804815206126 := by decide
theorem cert_e605791950574 : check e605791950574 [[],[],[],[]] .sourceHead = true := by decide
def e605791950582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605791950582 : Closed e605791950582 ∧ code e605791950582 = 2804815206134 := by decide
theorem cert_e605791950582 : check e605791950582 [[],[],[],[]] .chain = true := by decide
def e605791950686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605791950686 : Closed e605791950686 ∧ code e605791950686 = 2804815206238 := by decide
theorem cert_e605791950686 : check e605791950686 [[],[],[],[]] .chain = true := by decide
def e605791950714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605791950714 : Closed e605791950714 ∧ code e605791950714 = 2804815206266 := by decide
theorem cert_e605791950714 : check e605791950714 [[],[],[],[]] .chain = true := by decide
def e605791950766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e605791950766 : Closed e605791950766 ∧ code e605791950766 = 2804815206318 := by decide
theorem cert_e605791950766 : check e605791950766 [[],[],[],[]] .sourceHead = true := by decide
def e605791950778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e605791950778 : Closed e605791950778 ∧ code e605791950778 = 2804815206330 := by decide
theorem cert_e605791950778 : check e605791950778 [[],[],[],[]] .sourceHead = true := by decide
def e605791950806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605791950806 : Closed e605791950806 ∧ code e605791950806 = 2804815206358 := by decide
theorem cert_e605791950806 : check e605791950806 [[],[],[],[]] .chain = true := by decide
def e605791950810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605791950810 : Closed e605791950810 ∧ code e605791950810 = 2804815206362 := by decide
theorem cert_e605791950810 : check e605791950810 [[],[],[],[]] .chain = true := by decide
def e605791951326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605791951326 : Closed e605791951326 ∧ code e605791951326 = 2804815206878 := by decide
theorem cert_e605791951326 : check e605791951326 [[],[],[],[]] .chain = true := by decide
def e605791951342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e605791951342 : Closed e605791951342 ∧ code e605791951342 = 2804815206894 := by decide
theorem cert_e605791951342 : check e605791951342 [[],[],[],[]] .sourceHead = true := by decide
def e605791951350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605791951350 : Closed e605791951350 ∧ code e605791951350 = 2804815206902 := by decide
theorem cert_e605791951350 : check e605791951350 [[],[],[],[]] .chain = true := by decide
def e605791952094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605791952094 : Closed e605791952094 ∧ code e605791952094 = 2804815207646 := by decide
theorem cert_e605791952094 : check e605791952094 [[],[],[],[]] .chain = true := by decide
def e605791952122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605791952122 : Closed e605791952122 ∧ code e605791952122 = 2804815207674 := by decide
theorem cert_e605791952122 : check e605791952122 [[],[],[],[]] .chain = true := by decide
def e605791952446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e605791952446 : Closed e605791952446 ∧ code e605791952446 = 2804815207998 := by decide
theorem cert_e605791952446 : check e605791952446 [[],[],[],[]] .sourceHead = true := by decide
def e605791952494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e605791952494 : Closed e605791952494 ∧ code e605791952494 = 2804815208046 := by decide
theorem cert_e605791952494 : check e605791952494 [[],[],[],[]] .sourceHead = true := by decide
def e605791952506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e605791952506 : Closed e605791952506 ∧ code e605791952506 = 2804815208058 := by decide
theorem cert_e605791952506 : check e605791952506 [[],[],[],[]] .sourceHead = true := by decide
def e605791952670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e605791952670 : Closed e605791952670 ∧ code e605791952670 = 2804815208222 := by decide
theorem cert_e605791952670 : check e605791952670 [[],[],[],[]] .sourceHead = true := by decide
def e605791952694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605791952694 : Closed e605791952694 ∧ code e605791952694 = 2804815208246 := by decide
theorem cert_e605791952694 : check e605791952694 [[],[],[],[]] .chain = true := by decide
def e605791952698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605791952698 : Closed e605791952698 ∧ code e605791952698 = 2804815208250 := by decide
theorem cert_e605791952698 : check e605791952698 [[],[],[],[]] .chain = true := by decide
def e605791962046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e605791962046 : Closed e605791962046 ∧ code e605791962046 = 2804815217598 := by decide
theorem cert_e605791962046 : check e605791962046 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791962102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e605791962102 : Closed e605791962102 ∧ code e605791962102 = 2804815217654 := by decide
theorem cert_e605791962102 : check e605791962102 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791963998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e605791963998 : Closed e605791963998 ∧ code e605791963998 = 2804815219550 := by decide
theorem cert_e605791963998 : check e605791963998 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605791964014 : Closed e605791964014 ∧ code e605791964014 = 2804815219566 := by decide
theorem cert_e605791964014 : check e605791964014 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605791964022 : Closed e605791964022 ∧ code e605791964022 = 2804815219574 := by decide
theorem cert_e605791964022 : check e605791964022 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e605791964026 : Closed e605791964026 ∧ code e605791964026 = 2804815219578 := by decide
theorem cert_e605791964026 : check e605791964026 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605791964078 : Closed e605791964078 ∧ code e605791964078 = 2804815219630 := by decide
theorem cert_e605791964078 : check e605791964078 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605791964090 : Closed e605791964090 ∧ code e605791964090 = 2804815219642 := by decide
theorem cert_e605791964090 : check e605791964090 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605791964118 : Closed e605791964118 ∧ code e605791964118 = 2804815219670 := by decide
theorem cert_e605791964118 : check e605791964118 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605791964122 : Closed e605791964122 ∧ code e605791964122 = 2804815219674 := by decide
theorem cert_e605791964122 : check e605791964122 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e605791964138 : Closed e605791964138 ∧ code e605791964138 = 2804815219690 := by decide
theorem cert_e605791964138 : check e605791964138 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e605791964382 : Closed e605791964382 ∧ code e605791964382 = 2804815219934 := by decide
theorem cert_e605791964382 : check e605791964382 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605791964398 : Closed e605791964398 ∧ code e605791964398 = 2804815219950 := by decide
theorem cert_e605791964398 : check e605791964398 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605791964406 : Closed e605791964406 ∧ code e605791964406 = 2804815219958 := by decide
theorem cert_e605791964406 : check e605791964406 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e605791964410 : Closed e605791964410 ∧ code e605791964410 = 2804815219962 := by decide
theorem cert_e605791964410 : check e605791964410 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e605791964734 : Closed e605791964734 ∧ code e605791964734 = 2804815220286 := by decide
theorem cert_e605791964734 : check e605791964734 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605791964782 : Closed e605791964782 ∧ code e605791964782 = 2804815220334 := by decide
theorem cert_e605791964782 : check e605791964782 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605791964794 : Closed e605791964794 ∧ code e605791964794 = 2804815220346 := by decide
theorem cert_e605791964794 : check e605791964794 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605791964982 : Closed e605791964982 ∧ code e605791964982 = 2804815220534 := by decide
theorem cert_e605791964982 : check e605791964982 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791964986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605791964986 : Closed e605791964986 ∧ code e605791964986 = 2804815220538 := by decide
theorem cert_e605791964986 : check e605791964986 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791965070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e605791965070 : Closed e605791965070 ∧ code e605791965070 = 2804815220622 := by decide
theorem cert_e605791965070 : check e605791965070 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791965082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e605791965082 : Closed e605791965082 ∧ code e605791965082 = 2804815220634 := by decide
theorem cert_e605791965082 : check e605791965082 [[],[],[],[],[.under,.under]] .three = true := by decide
def e605791969758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605791969758 : Closed e605791969758 ∧ code e605791969758 = 2804815225310 := by decide
theorem cert_e605791969758 : check e605791969758 [[],[],[],[],[.under,.under],[.under,.under]] .chain = true := by decide
def e605791969782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605791969782 : Closed e605791969782 ∧ code e605791969782 = 2804815225334 := by decide
theorem cert_e605791969782 : check e605791969782 [[],[],[],[],[.under,.under],[.under,.under]] .chain = true := by decide
def e605791970734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605791970734 : Closed e605791970734 ∧ code e605791970734 = 2804815226286 := by decide
theorem cert_e605791970734 : check e605791970734 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e605791970742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605791970742 : Closed e605791970742 ∧ code e605791970742 = 2804815226294 := by decide
theorem cert_e605791970742 : check e605791970742 [[],[],[],[]] .chain = true := by decide
def e605791970746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605791970746 : Closed e605791970746 ∧ code e605791970746 = 2804815226298 := by decide
theorem cert_e605791970746 : check e605791970746 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under]] .identityHead = true := by decide
def e605791970774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605791970774 : Closed e605791970774 ∧ code e605791970774 = 2804815226326 := by decide
theorem cert_e605791970774 : check e605791970774 [[],[],[],[]] .chain = true := by decide
def e605791970778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605791970778 : Closed e605791970778 ∧ code e605791970778 = 2804815226330 := by decide
theorem cert_e605791970778 : check e605791970778 [[],[],[],[]] .chain = true := by decide
def e605791970794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605791970794 : Closed e605791970794 ∧ code e605791970794 = 2804815226346 := by decide
theorem cert_e605791970794 : check e605791970794 [[],[],[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e605791970926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605791970926 : Closed e605791970926 ∧ code e605791970926 = 2804815226478 := by decide
def e605791970934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605791970934 : Closed e605791970934 ∧ code e605791970934 = 2804815226486 := by decide
theorem cert_e605791970934 : check e605791970934 [[],[],[],[]] .chain = true := by decide
def e605791970938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605791970938 : Closed e605791970938 ∧ code e605791970938 = 2804815226490 := by decide
theorem cert_e605791970938 : check e605791970938 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under]] .identityHead = true := by decide
def e605791971102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605791971102 : Closed e605791971102 ∧ code e605791971102 = 2804815226654 := by decide
theorem cert_e605791971102 : checkPay e605791971102 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[]] 0 [[.under,.under,.under,.under],[.under,.under,.under,.under,.under,.under]] = true := by decide
def e605791971126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605791971126 : Closed e605791971126 ∧ code e605791971126 = 2804815226678 := by decide
theorem cert_e605791971126 : check e605791971126 [[],[],[],[]] .chain = true := by decide
def e605791971130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605791971130 : Closed e605791971130 ∧ code e605791971130 = 2804815226682 := by decide
theorem cert_e605791971130 : check e605791971130 [[],[],[],[]] .chain = true := by decide
def e605791971214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605791971214 : Closed e605791971214 ∧ code e605791971214 = 2804815226766 := by decide
theorem cert_e605791971214 : check e605791971214 [[],[],[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605791971226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605791971226 : Closed e605791971226 ∧ code e605791971226 = 2804815226778 := by decide
theorem cert_e605791971226 : check e605791971226 [[],[],[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605792417134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605792417134 : Closed e605792417134 ∧ code e605792417134 = 2804815672686 := by decide
theorem cert_e605792417134 : check e605792417134 [[],[],[],[]] .sourceHead = true := by decide
def e605792417142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605792417142 : Closed e605792417142 ∧ code e605792417142 = 2804815672694 := by decide
theorem cert_e605792417142 : check e605792417142 [[],[],[],[]] .sourceHead = true := by decide
def e605792417198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605792417198 : Closed e605792417198 ∧ code e605792417198 = 2804815672750 := by decide
theorem cert_e605792417198 : check e605792417198 [[],[],[],[]] .sourceHead = true := by decide
def e605792417210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605792417210 : Closed e605792417210 ∧ code e605792417210 = 2804815672762 := by decide
theorem cert_e605792417210 : check e605792417210 [[],[],[],[]] .sourceHead = true := by decide
def e605792417238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605792417238 : Closed e605792417238 ∧ code e605792417238 = 2804815672790 := by decide
theorem cert_e605792417238 : check e605792417238 [[],[],[],[]] .sourceHead = true := by decide
def e605792417242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605792417242 : Closed e605792417242 ∧ code e605792417242 = 2804815672794 := by decide
theorem cert_e605792417242 : check e605792417242 [[],[],[],[]] .sourceHead = true := by decide
def e605792417454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605792417454 : Closed e605792417454 ∧ code e605792417454 = 2804815673006 := by decide
theorem cert_e605792417454 : check e605792417454 [[],[],[],[]] .sourceHead = true := by decide
def e605792417466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605792417466 : Closed e605792417466 ∧ code e605792417466 = 2804815673018 := by decide
theorem cert_e605792417466 : check e605792417466 [[],[],[],[]] .sourceHead = true := by decide
def e605792417514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605792417514 : Closed e605792417514 ∧ code e605792417514 = 2804815673066 := by decide
theorem cert_e605792417514 : check e605792417514 [[],[],[],[]] .sourceHead = true := by decide
def e605792417622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605792417622 : Closed e605792417622 ∧ code e605792417622 = 2804815673174 := by decide
theorem cert_e605792417622 : check e605792417622 [[],[],[],[]] .sourceHead = true := by decide
def e605792417626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605792417626 : Closed e605792417626 ∧ code e605792417626 = 2804815673178 := by decide
theorem cert_e605792417626 : check e605792417626 [[],[],[],[]] .sourceHead = true := by decide
def e605792417642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605792417642 : Closed e605792417642 ∧ code e605792417642 = 2804815673194 := by decide
theorem cert_e605792417642 : check e605792417642 [[],[],[],[]] .sourceHead = true := by decide
def e605792418478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605792418478 : Closed e605792418478 ∧ code e605792418478 = 2804815674030 := by decide
theorem cert_e605792418478 : check e605792418478 [[],[],[],[],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e605792418490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605792418490 : Closed e605792418490 ∧ code e605792418490 = 2804815674042 := by decide
theorem cert_e605792418490 : check e605792418490 [[],[],[],[],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e605792418538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605792418538 : Closed e605792418538 ∧ code e605792418538 = 2804815674090 := by decide
theorem cert_e605792418538 : check e605792418538 [[],[],[],[],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e605792418730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605792418730 : Closed e605792418730 ∧ code e605792418730 = 2804815674282 := by decide
private def t_e605792418730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem cert_e605792418730 : ¬ IsSelfInterpreter e605792418730 :=
  wSource (t := t_e605792418730) (replay_sound (ps := []) (t := e605792418730) (by decide)) (by decide)
def e605792419158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605792419158 : Closed e605792419158 ∧ code e605792419158 = 2804815674710 := by decide
theorem cert_e605792419158 : check e605792419158 [[],[],[],[],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e605792419162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605792419162 : Closed e605792419162 ∧ code e605792419162 = 2804815674714 := by decide
theorem cert_e605792419162 : check e605792419162 [[],[],[],[],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e605792419178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605792419178 : Closed e605792419178 ∧ code e605792419178 = 2804815674730 := by decide
theorem cert_e605792419178 : check e605792419178 [[],[],[],[],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e605792419242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605792419242 : Closed e605792419242 ∧ code e605792419242 = 2804815674794 := by decide
private def t_e605792419242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem cert_e605792419242 : ¬ IsSelfInterpreter e605792419242 :=
  wSource (t := t_e605792419242) (replay_sound (ps := []) (t := e605792419242) (by decide)) (by decide)
def e605792420206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e605792420206 : Closed e605792420206 ∧ code e605792420206 = 2804815675758 := by decide
theorem cert_e605792420206 : check e605792420206 [[],[],[],[]] .sourceHead = true := by decide
def e605792420214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e605792420214 : Closed e605792420214 ∧ code e605792420214 = 2804815675766 := by decide
theorem cert_e605792420214 : check e605792420214 [[],[],[],[]] .sourceHead = true := by decide
def e605792421742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e605792421742 : Closed e605792421742 ∧ code e605792421742 = 2804815677294 := by decide
theorem cert_e605792421742 : check e605792421742 [[],[],[],[]] .sourceHead = true := by decide
def e605792421750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e605792421750 : Closed e605792421750 ∧ code e605792421750 = 2804815677302 := by decide
theorem cert_e605792421750 : check e605792421750 [[],[],[],[]] .sourceHead = true := by decide
def e605792421814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e605792421814 : Closed e605792421814 ∧ code e605792421814 = 2804815677366 := by decide
theorem cert_e605792421814 : check e605792421814 [[],[],[],[]] .sourceHead = true := by decide
def e605792423278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e605792423278 : Closed e605792423278 ∧ code e605792423278 = 2804815678830 := by decide
theorem cert_e605792423278 : check e605792423278 [[],[],[],[]] .sourceHead = true := by decide
def e605792423286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e605792423286 : Closed e605792423286 ∧ code e605792423286 = 2804815678838 := by decide
theorem cert_e605792423286 : check e605792423286 [[],[],[],[]] .sourceHead = true := by decide
def e605792423342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e605792423342 : Closed e605792423342 ∧ code e605792423342 = 2804815678894 := by decide
theorem cert_e605792423342 : check e605792423342 [[],[],[],[]] .sourceHead = true := by decide
def e605792423354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e605792423354 : Closed e605792423354 ∧ code e605792423354 = 2804815678906 := by decide
theorem cert_e605792423354 : check e605792423354 [[],[],[],[]] .sourceHead = true := by decide
def e605792423382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e605792423382 : Closed e605792423382 ∧ code e605792423382 = 2804815678934 := by decide
theorem cert_e605792423382 : check e605792423382 [[],[],[],[]] .sourceHead = true := by decide
def e605792423386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e605792423386 : Closed e605792423386 ∧ code e605792423386 = 2804815678938 := by decide
theorem cert_e605792423386 : check e605792423386 [[],[],[],[]] .sourceHead = true := by decide
def e605792423598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605792423598 : Closed e605792423598 ∧ code e605792423598 = 2804815679150 := by decide
theorem cert_e605792423598 : check e605792423598 [[],[],[],[]] .sourceHead = true := by decide
def e605792423610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605792423610 : Closed e605792423610 ∧ code e605792423610 = 2804815679162 := by decide
theorem cert_e605792423610 : check e605792423610 [[],[],[],[]] .sourceHead = true := by decide
def e605792423658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605792423658 : Closed e605792423658 ∧ code e605792423658 = 2804815679210 := by decide
theorem cert_e605792423658 : check e605792423658 [[],[],[],[]] .sourceHead = true := by decide
def e605792423766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e605792423766 : Closed e605792423766 ∧ code e605792423766 = 2804815679318 := by decide
theorem cert_e605792423766 : check e605792423766 [[],[],[],[]] .sourceHead = true := by decide
def e605792423770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e605792423770 : Closed e605792423770 ∧ code e605792423770 = 2804815679322 := by decide
theorem cert_e605792423770 : check e605792423770 [[],[],[],[]] .sourceHead = true := by decide
def e605792423786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e605792423786 : Closed e605792423786 ∧ code e605792423786 = 2804815679338 := by decide
theorem cert_e605792423786 : check e605792423786 [[],[],[],[]] .sourceHead = true := by decide
def e605792424814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605792424814 : Closed e605792424814 ∧ code e605792424814 = 2804815680366 := by decide
theorem cert_e605792424814 : check e605792424814 [[],[],[],[]] .sourceHead = true := by decide
def e605792424822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605792424822 : Closed e605792424822 ∧ code e605792424822 = 2804815680374 := by decide
theorem cert_e605792424822 : check e605792424822 [[],[],[],[]] .sourceHead = true := by decide
def e605792424878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605792424878 : Closed e605792424878 ∧ code e605792424878 = 2804815680430 := by decide
theorem cert_e605792424878 : check e605792424878 [[],[],[],[]] .sourceHead = true := by decide
def e605792424890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605792424890 : Closed e605792424890 ∧ code e605792424890 = 2804815680442 := by decide
theorem cert_e605792424890 : check e605792424890 [[],[],[],[]] .sourceHead = true := by decide
def e605792424918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605792424918 : Closed e605792424918 ∧ code e605792424918 = 2804815680470 := by decide
theorem cert_e605792424918 : check e605792424918 [[],[],[],[]] .sourceHead = true := by decide
def e605792424922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605792424922 : Closed e605792424922 ∧ code e605792424922 = 2804815680474 := by decide
theorem cert_e605792424922 : check e605792424922 [[],[],[],[]] .sourceHead = true := by decide
def e605792425198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605792425198 : Closed e605792425198 ∧ code e605792425198 = 2804815680750 := by decide
theorem cert_e605792425198 : check e605792425198 [[],[],[],[]] .sourceHead = true := by decide
def e605792425206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605792425206 : Closed e605792425206 ∧ code e605792425206 = 2804815680758 := by decide
theorem cert_e605792425206 : check e605792425206 [[],[],[],[]] .sourceHead = true := by decide
def e605792425582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605792425582 : Closed e605792425582 ∧ code e605792425582 = 2804815681134 := by decide
theorem cert_e605792425582 : check e605792425582 [[],[],[],[]] .sourceHead = true := by decide
def e605792425594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605792425594 : Closed e605792425594 ∧ code e605792425594 = 2804815681146 := by decide
theorem cert_e605792425594 : check e605792425594 [[],[],[],[]] .sourceHead = true := by decide
def e605792425782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605792425782 : Closed e605792425782 ∧ code e605792425782 = 2804815681334 := by decide
theorem cert_e605792425782 : check e605792425782 [[],[],[],[]] .sourceHead = true := by decide
def e605792425786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605792425786 : Closed e605792425786 ∧ code e605792425786 = 2804815681338 := by decide
theorem cert_e605792425786 : check e605792425786 [[],[],[],[]] .sourceHead = true := by decide
def e605792426030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605792426030 : Closed e605792426030 ∧ code e605792426030 = 2804815681582 := by decide
theorem cert_e605792426030 : check e605792426030 [[],[],[],[]] .sourceHead = true := by decide
def e605792426222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605792426222 : Closed e605792426222 ∧ code e605792426222 = 2804815681774 := by decide
theorem cert_e605792426222 : check e605792426222 [[],[],[],[]] .sourceHead = true := by decide
def e605792426230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605792426230 : Closed e605792426230 ∧ code e605792426230 = 2804815681782 := by decide
theorem cert_e605792426230 : check e605792426230 [[],[],[],[]] .sourceHead = true := by decide
def e605792426414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605792426414 : Closed e605792426414 ∧ code e605792426414 = 2804815681966 := by decide
theorem cert_e605792426414 : check e605792426414 [[],[],[],[]] .sourceHead = true := by decide
def e605792426426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605792426426 : Closed e605792426426 ∧ code e605792426426 = 2804815681978 := by decide
theorem cert_e605792426426 : check e605792426426 [[],[],[],[]] .sourceHead = true := by decide
def e605792426474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605792426474 : Closed e605792426474 ∧ code e605792426474 = 2804815682026 := by decide
theorem cert_e605792426474 : check e605792426474 [[],[],[],[]] .sourceHead = true := by decide
def e605792426606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605792426606 : Closed e605792426606 ∧ code e605792426606 = 2804815682158 := by decide
theorem cert_e605792426606 : check e605792426606 [[],[],[],[]] .sourceHead = true := by decide
def e605792426618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605792426618 : Closed e605792426618 ∧ code e605792426618 = 2804815682170 := by decide
theorem cert_e605792426618 : check e605792426618 [[],[],[],[]] .sourceHead = true := by decide
def e605792426782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605792426782 : Closed e605792426782 ∧ code e605792426782 = 2804815682334 := by decide
theorem cert_e605792426782 : check e605792426782 [[],[],[],[]] .sourceHead = true := by decide
def e605792426882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e605792426882 : Closed e605792426882 ∧ code e605792426882 = 2804815682434 := by decide
theorem cert_e605792426882 : check e605792426882 [[],[],[],[]] .sourceHead = true := by decide
def e605792426894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605792426894 : Closed e605792426894 ∧ code e605792426894 = 2804815682446 := by decide
theorem cert_e605792426894 : check e605792426894 [[],[],[],[]] .sourceHead = true := by decide
def e605792426906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605792426906 : Closed e605792426906 ∧ code e605792426906 = 2804815682458 := by decide
theorem cert_e605792426906 : check e605792426906 [[],[],[],[]] .sourceHead = true := by decide
def e605792427030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605792427030 : Closed e605792427030 ∧ code e605792427030 = 2804815682582 := by decide
theorem cert_e605792427030 : check e605792427030 [[],[],[],[]] .sourceHead = true := by decide
def e605792427126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e605792427126 : Closed e605792427126 ∧ code e605792427126 = 2804815682678 := by decide
theorem cert_e605792427126 : check e605792427126 [[],[],[],[]] .sourceHead = true := by decide
def e605792427222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605792427222 : Closed e605792427222 ∧ code e605792427222 = 2804815682774 := by decide
theorem cert_e605792427222 : check e605792427222 [[],[],[],[]] .sourceHead = true := by decide
def e605792427226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605792427226 : Closed e605792427226 ∧ code e605792427226 = 2804815682778 := by decide
theorem cert_e605792427226 : check e605792427226 [[],[],[],[]] .sourceHead = true := by decide
def e605792427242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605792427242 : Closed e605792427242 ∧ code e605792427242 = 2804815682794 := by decide
theorem cert_e605792427242 : check e605792427242 [[],[],[],[]] .sourceHead = true := by decide
def e605792427318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605792427318 : Closed e605792427318 ∧ code e605792427318 = 2804815682870 := by decide
theorem cert_e605792427318 : check e605792427318 [[],[],[],[]] .sourceHead = true := by decide
def e605792427322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605792427322 : Closed e605792427322 ∧ code e605792427322 = 2804815682874 := by decide
theorem cert_e605792427322 : check e605792427322 [[],[],[],[]] .sourceHead = true := by decide
def e605792427394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e605792427394 : Closed e605792427394 ∧ code e605792427394 = 2804815682946 := by decide
theorem cert_e605792427394 : check e605792427394 [[],[],[],[]] .sourceHead = true := by decide
def e605792427406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e605792427406 : Closed e605792427406 ∧ code e605792427406 = 2804815682958 := by decide
theorem cert_e605792427406 : check e605792427406 [[],[],[],[]] .sourceHead = true := by decide
def e605792427418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605792427418 : Closed e605792427418 ∧ code e605792427418 = 2804815682970 := by decide
theorem cert_e605792427418 : check e605792427418 [[],[],[],[]] .sourceHead = true := by decide
def e605792428206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e605792428206 : Closed e605792428206 ∧ code e605792428206 = 2804815683758 := by decide
theorem cert_e605792428206 : check e605792428206 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e605792428218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e605792428218 : Closed e605792428218 ∧ code e605792428218 = 2804815683770 := by decide
theorem cert_e605792428218 : check e605792428218 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e605792428910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e605792428910 : Closed e605792428910 ∧ code e605792428910 = 2804815684462 := by decide
theorem cert_e605792428910 : check e605792428910 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e605792428918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e605792428918 : Closed e605792428918 ∧ code e605792428918 = 2804815684470 := by decide
theorem cert_e605792428918 : check e605792428918 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e605792428974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e605792428974 : Closed e605792428974 ∧ code e605792428974 = 2804815684526 := by decide
theorem cert_e605792428974 : check e605792428974 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792428986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e605792428986 : Closed e605792428986 ∧ code e605792428986 = 2804815684538 := by decide
def e605792429014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e605792429014 : Closed e605792429014 ∧ code e605792429014 = 2804815684566 := by decide
theorem cert_e605792429014 : check e605792429014 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e605792429018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e605792429018 : Closed e605792429018 ∧ code e605792429018 = 2804815684570 := by decide
def e605792429742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605792429742 : Closed e605792429742 ∧ code e605792429742 = 2804815685294 := by decide
theorem cert_e605792429742 : check e605792429742 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792429754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605792429754 : Closed e605792429754 ∧ code e605792429754 = 2804815685306 := by decide
theorem cert_e605792429754 : check e605792429754 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792429802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605792429802 : Closed e605792429802 ∧ code e605792429802 = 2804815685354 := by decide
theorem cert_e605792429802 : check e605792429802 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792429994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605792429994 : Closed e605792429994 ∧ code e605792429994 = 2804815685546 := by decide
theorem cert_e605792429994 : check e605792429994 [[],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e605792430126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605792430126 : Closed e605792430126 ∧ code e605792430126 = 2804815685678 := by decide
theorem cert_e605792430126 : check e605792430126 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792430318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605792430318 : Closed e605792430318 ∧ code e605792430318 = 2804815685870 := by decide
theorem cert_e605792430318 : check e605792430318 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792430326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605792430326 : Closed e605792430326 ∧ code e605792430326 = 2804815685878 := by decide
theorem cert_e605792430326 : check e605792430326 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792430510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605792430510 : Closed e605792430510 ∧ code e605792430510 = 2804815686062 := by decide
theorem cert_e605792430510 : check e605792430510 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792430522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605792430522 : Closed e605792430522 ∧ code e605792430522 = 2804815686074 := by decide
theorem cert_e605792430522 : check e605792430522 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792430570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605792430570 : Closed e605792430570 ∧ code e605792430570 = 2804815686122 := by decide
theorem cert_e605792430570 : check e605792430570 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792430702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605792430702 : Closed e605792430702 ∧ code e605792430702 = 2804815686254 := by decide
theorem cert_e605792430702 : check e605792430702 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792430714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605792430714 : Closed e605792430714 ∧ code e605792430714 = 2804815686266 := by decide
theorem cert_e605792430714 : check e605792430714 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792430878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605792430878 : Closed e605792430878 ∧ code e605792430878 = 2804815686430 := by decide
theorem cert_e605792430878 : check e605792430878 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792430978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e605792430978 : Closed e605792430978 ∧ code e605792430978 = 2804815686530 := by decide
theorem cert_e605792430978 : check e605792430978 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792430990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605792430990 : Closed e605792430990 ∧ code e605792430990 = 2804815686542 := by decide
theorem cert_e605792430990 : check e605792430990 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792431002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605792431002 : Closed e605792431002 ∧ code e605792431002 = 2804815686554 := by decide
theorem cert_e605792431002 : check e605792431002 [[],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605792431214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605792431214 : Closed e605792431214 ∧ code e605792431214 = 2804815686766 := by decide
private def t_e605792431214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem cert_e605792431214 : ¬ IsSelfInterpreter e605792431214 :=
  wSource (t := t_e605792431214) (replay_sound (ps := []) (t := e605792431214) (by decide)) (by decide)
end Blc.Floor41
