import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e206306338426 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e206306338426 : Closed e206306338426 ∧ code e206306338426 = 2405329593978 := by decide
theorem cert_e206306338426 : check e206306338426 [] .sourceHead = true := by decide
def e206306338714 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e206306338714 : Closed e206306338714 ∧ code e206306338714 = 2405329594266 := by decide
theorem cert_e206306338714 : check e206306338714 [] .sourceHead = true := by decide
def e206306341590 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e206306341590 : Closed e206306341590 ∧ code e206306341590 = 2405329597142 := by decide
theorem cert_e206306341590 : check e206306341590 [] .sourceHead = true := by decide
def e206306341594 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e206306341594 : Closed e206306341594 ∧ code e206306341594 = 2405329597146 := by decide
theorem cert_e206306341594 : check e206306341594 [] .sourceHead = true := by decide
def e206306341610 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e206306341610 : Closed e206306341610 ∧ code e206306341610 = 2405329597162 := by decide
theorem cert_e206306341610 : check e206306341610 [] .sourceHead = true := by decide
def e206306341686 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e206306341686 : Closed e206306341686 ∧ code e206306341686 = 2405329597238 := by decide
theorem cert_e206306341686 : check e206306341686 [] .sourceHead = true := by decide
def e206306341690 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e206306341690 : Closed e206306341690 ∧ code e206306341690 = 2405329597242 := by decide
theorem cert_e206306341690 : check e206306341690 [] .sourceHead = true := by decide
def e206306341786 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e206306341786 : Closed e206306341786 ∧ code e206306341786 = 2405329597338 := by decide
theorem cert_e206306341786 : check e206306341786 [] .sourceHead = true := by decide
def e206740764698 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206740764698 : Closed e206740764698 ∧ code e206740764698 = 2405764020250 := by decide
theorem cert_e206740764698 : check e206740764698 [] .sourceHead = true := by decide
def e206740772890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206740772890 : Closed e206740772890 ∧ code e206740772890 = 2405764028442 := by decide
theorem cert_e206740772890 : check e206740772890 [] .sourceHead = true := by decide
def e206740830234 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206740830234 : Closed e206740830234 ∧ code e206740830234 = 2405764085786 := by decide
theorem cert_e206740830234 : check e206740830234 [] .sourceHead = true := by decide
def e206740842522 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206740842522 : Closed e206740842522 ∧ code e206740842522 = 2405764098074 := by decide
theorem cert_e206740842522 : check e206740842522 [] .sourceHead = true := by decide
def e206740871194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206740871194 : Closed e206740871194 ∧ code e206740871194 = 2405764126746 := by decide
theorem cert_e206740871194 : check e206740871194 [] .sourceHead = true := by decide
def e206740875290 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206740875290 : Closed e206740875290 ∧ code e206740875290 = 2405764130842 := by decide
theorem cert_e206740875290 : check e206740875290 [] .sourceHead = true := by decide
def e206741092378 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206741092378 : Closed e206741092378 ∧ code e206741092378 = 2405764347930 := by decide
theorem cert_e206741092378 : check e206741092378 [] .sourceHead = true := by decide
def e206741104666 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206741104666 : Closed e206741104666 ∧ code e206741104666 = 2405764360218 := by decide
theorem cert_e206741104666 : check e206741104666 [] .sourceHead = true := by decide
def e206741153818 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206741153818 : Closed e206741153818 ∧ code e206741153818 = 2405764409370 := by decide
theorem cert_e206741153818 : check e206741153818 [] .sourceHead = true := by decide
def e206741264410 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206741264410 : Closed e206741264410 ∧ code e206741264410 = 2405764519962 := by decide
theorem cert_e206741264410 : check e206741264410 [] .sourceHead = true := by decide
def e206741268506 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206741268506 : Closed e206741268506 ∧ code e206741268506 = 2405764524058 := by decide
theorem cert_e206741268506 : check e206741268506 [] .sourceHead = true := by decide
def e206741284890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206741284890 : Closed e206741284890 ∧ code e206741284890 = 2405764540442 := by decide
theorem cert_e206741284890 : check e206741284890 [] .sourceHead = true := by decide
def e206742337562 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206742337562 : Closed e206742337562 ∧ code e206742337562 = 2405765593114 := by decide
theorem cert_e206742337562 : check e206742337562 [] .sourceHead = true := by decide
def e206742345754 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206742345754 : Closed e206742345754 ∧ code e206742345754 = 2405765601306 := by decide
theorem cert_e206742345754 : check e206742345754 [] .sourceHead = true := by decide
def e206742403098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206742403098 : Closed e206742403098 ∧ code e206742403098 = 2405765658650 := by decide
theorem cert_e206742403098 : check e206742403098 [] .sourceHead = true := by decide
def e206742415386 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206742415386 : Closed e206742415386 ∧ code e206742415386 = 2405765670938 := by decide
theorem cert_e206742415386 : check e206742415386 [] .sourceHead = true := by decide
def e206742444058 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206742444058 : Closed e206742444058 ∧ code e206742444058 = 2405765699610 := by decide
theorem cert_e206742444058 : check e206742444058 [] .sourceHead = true := by decide
def e206742448154 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206742448154 : Closed e206742448154 ∧ code e206742448154 = 2405765703706 := by decide
theorem cert_e206742448154 : check e206742448154 [] .sourceHead = true := by decide
def e206742730778 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206742730778 : Closed e206742730778 ∧ code e206742730778 = 2405765986330 := by decide
theorem cert_e206742730778 : check e206742730778 [] .sourceHead = true := by decide
def e206742738970 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206742738970 : Closed e206742738970 ∧ code e206742738970 = 2405765994522 := by decide
theorem cert_e206742738970 : check e206742738970 [] .sourceHead = true := by decide
def e206743123994 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206743123994 : Closed e206743123994 ∧ code e206743123994 = 2405766379546 := by decide
theorem cert_e206743123994 : check e206743123994 [] .sourceHead = true := by decide
def e206743136282 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206743136282 : Closed e206743136282 ∧ code e206743136282 = 2405766391834 := by decide
theorem cert_e206743136282 : check e206743136282 [] .sourceHead = true := by decide
def e206743328794 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206743328794 : Closed e206743328794 ∧ code e206743328794 = 2405766584346 := by decide
theorem cert_e206743328794 : check e206743328794 [] .sourceHead = true := by decide
def e206743332890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206743332890 : Closed e206743332890 ∧ code e206743332890 = 2405766588442 := by decide
theorem cert_e206743332890 : check e206743332890 [] .sourceHead = true := by decide
def e206743975962 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206743975962 : Closed e206743975962 ∧ code e206743975962 = 2405767231514 := by decide
theorem cert_e206743975962 : check e206743975962 [] .sourceHead = true := by decide
def e206743988250 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206743988250 : Closed e206743988250 ∧ code e206743988250 = 2405767243802 := by decide
theorem cert_e206743988250 : check e206743988250 [] .sourceHead = true := by decide
def e206744037402 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206744037402 : Closed e206744037402 ∧ code e206744037402 = 2405767292954 := by decide
theorem cert_e206744037402 : check e206744037402 [] .sourceHead = true := by decide
def e206744172570 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206744172570 : Closed e206744172570 ∧ code e206744172570 = 2405767428122 := by decide
theorem cert_e206744172570 : check e206744172570 [] .sourceHead = true := by decide
def e206744184858 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206744184858 : Closed e206744184858 ∧ code e206744184858 = 2405767440410 := by decide
theorem cert_e206744184858 : check e206744184858 [] .sourceHead = true := by decide
def e206744479770 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206744479770 : Closed e206744479770 ∧ code e206744479770 = 2405767735322 := by decide
theorem cert_e206744479770 : check e206744479770 [] .sourceHead = true := by decide
def e206744803354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206744803354 : Closed e206744803354 ∧ code e206744803354 = 2405768058906 := by decide
theorem cert_e206744803354 : check e206744803354 [] .sourceHead = true := by decide
def e206744807450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206744807450 : Closed e206744807450 ∧ code e206744807450 = 2405768063002 := by decide
theorem cert_e206744807450 : check e206744807450 [] .sourceHead = true := by decide
def e206744823834 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206744823834 : Closed e206744823834 ∧ code e206744823834 = 2405768079386 := by decide
theorem cert_e206744823834 : check e206744823834 [] .sourceHead = true := by decide
def e206744901658 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206744901658 : Closed e206744901658 ∧ code e206744901658 = 2405768157210 := by decide
theorem cert_e206744901658 : check e206744901658 [] .sourceHead = true := by decide
def e206744905754 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206744905754 : Closed e206744905754 ∧ code e206744905754 = 2405768161306 := by decide
theorem cert_e206744905754 : check e206744905754 [] .sourceHead = true := by decide
def e206745004058 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206745004058 : Closed e206745004058 ∧ code e206745004058 = 2405768259610 := by decide
theorem cert_e206745004058 : check e206745004058 [] .sourceHead = true := by decide
def e206748629018 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206748629018 : Closed e206748629018 ∧ code e206748629018 = 2405771884570 := by decide
theorem cert_e206748629018 : check e206748629018 [] .sourceHead = true := by decide
def e206748637210 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206748637210 : Closed e206748637210 ∧ code e206748637210 = 2405771892762 := by decide
theorem cert_e206748637210 : check e206748637210 [] .sourceHead = true := by decide
def e206748694554 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206748694554 : Closed e206748694554 ∧ code e206748694554 = 2405771950106 := by decide
theorem cert_e206748694554 : check e206748694554 [] .sourceHead = true := by decide
def e206748706842 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206748706842 : Closed e206748706842 ∧ code e206748706842 = 2405771962394 := by decide
theorem cert_e206748706842 : check e206748706842 [] .sourceHead = true := by decide
def e206748735514 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206748735514 : Closed e206748735514 ∧ code e206748735514 = 2405771991066 := by decide
theorem cert_e206748735514 : check e206748735514 [] .sourceHead = true := by decide
def e206748739610 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206748739610 : Closed e206748739610 ∧ code e206748739610 = 2405771995162 := by decide
theorem cert_e206748739610 : check e206748739610 [] .sourceHead = true := by decide
def e206749022234 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206749022234 : Closed e206749022234 ∧ code e206749022234 = 2405772277786 := by decide
theorem cert_e206749022234 : check e206749022234 [] .sourceHead = true := by decide
def e206749030426 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206749030426 : Closed e206749030426 ∧ code e206749030426 = 2405772285978 := by decide
theorem cert_e206749030426 : check e206749030426 [] .sourceHead = true := by decide
def e206749415450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206749415450 : Closed e206749415450 ∧ code e206749415450 = 2405772671002 := by decide
theorem cert_e206749415450 : check e206749415450 [] .sourceHead = true := by decide
def e206749427738 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206749427738 : Closed e206749427738 ∧ code e206749427738 = 2405772683290 := by decide
theorem cert_e206749427738 : check e206749427738 [] .sourceHead = true := by decide
def e206749620250 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206749620250 : Closed e206749620250 ∧ code e206749620250 = 2405772875802 := by decide
theorem cert_e206749620250 : check e206749620250 [] .sourceHead = true := by decide
def e206749624346 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206749624346 : Closed e206749624346 ∧ code e206749624346 = 2405772879898 := by decide
theorem cert_e206749624346 : check e206749624346 [] .sourceHead = true := by decide
def e206749871470 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e206749871470 : Closed e206749871470 ∧ code e206749871470 = 2405773127022 := by decide
theorem cert_e206749871470 : check e206749871470 [] .sourceHead = true := by decide
def e206749871478 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e206749871478 : Closed e206749871478 ∧ code e206749871478 = 2405773127030 := by decide
theorem cert_e206749871478 : check e206749871478 [] .sourceHead = true := by decide
def e206749871534 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e206749871534 : Closed e206749871534 ∧ code e206749871534 = 2405773127086 := by decide
theorem cert_e206749871534 : check e206749871534 [] .sourceHead = true := by decide
def e206749871546 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e206749871546 : Closed e206749871546 ∧ code e206749871546 = 2405773127098 := by decide
theorem cert_e206749871546 : check e206749871546 [] .sourceHead = true := by decide
def e206749871574 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e206749871574 : Closed e206749871574 ∧ code e206749871574 = 2405773127126 := by decide
theorem cert_e206749871574 : check e206749871574 [] .sourceHead = true := by decide
def e206749871578 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e206749871578 : Closed e206749871578 ∧ code e206749871578 = 2405773127130 := by decide
theorem cert_e206749871578 : check e206749871578 [] .sourceHead = true := by decide
def e206749871790 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e206749871790 : Closed e206749871790 ∧ code e206749871790 = 2405773127342 := by decide
theorem cert_e206749871790 : check e206749871790 [] .sourceHead = true := by decide
def e206749871802 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e206749871802 : Closed e206749871802 ∧ code e206749871802 = 2405773127354 := by decide
theorem cert_e206749871802 : check e206749871802 [] .sourceHead = true := by decide
def e206749871850 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e206749871850 : Closed e206749871850 ∧ code e206749871850 = 2405773127402 := by decide
theorem cert_e206749871850 : check e206749871850 [] .sourceHead = true := by decide
def e206749871958 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e206749871958 : Closed e206749871958 ∧ code e206749871958 = 2405773127510 := by decide
theorem cert_e206749871958 : check e206749871958 [] .sourceHead = true := by decide
def e206749871962 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e206749871962 : Closed e206749871962 ∧ code e206749871962 = 2405773127514 := by decide
theorem cert_e206749871962 : check e206749871962 [] .sourceHead = true := by decide
def e206749871978 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e206749871978 : Closed e206749871978 ∧ code e206749871978 = 2405773127530 := by decide
theorem cert_e206749871978 : check e206749871978 [] .sourceHead = true := by decide
def e206749873006 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e206749873006 : Closed e206749873006 ∧ code e206749873006 = 2405773128558 := by decide
theorem cert_e206749873006 : check e206749873006 [] .sourceHead = true := by decide
def e206749873014 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e206749873014 : Closed e206749873014 ∧ code e206749873014 = 2405773128566 := by decide
theorem cert_e206749873014 : check e206749873014 [] .sourceHead = true := by decide
def e206749873070 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e206749873070 : Closed e206749873070 ∧ code e206749873070 = 2405773128622 := by decide
theorem cert_e206749873070 : check e206749873070 [] .sourceHead = true := by decide
def e206749873082 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e206749873082 : Closed e206749873082 ∧ code e206749873082 = 2405773128634 := by decide
theorem cert_e206749873082 : check e206749873082 [] .sourceHead = true := by decide
def e206749873110 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e206749873110 : Closed e206749873110 ∧ code e206749873110 = 2405773128662 := by decide
theorem cert_e206749873110 : check e206749873110 [] .sourceHead = true := by decide
def e206749873114 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e206749873114 : Closed e206749873114 ∧ code e206749873114 = 2405773128666 := by decide
theorem cert_e206749873114 : check e206749873114 [] .sourceHead = true := by decide
def e206749873390 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e206749873390 : Closed e206749873390 ∧ code e206749873390 = 2405773128942 := by decide
theorem cert_e206749873390 : check e206749873390 [] .sourceHead = true := by decide
def e206749873398 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e206749873398 : Closed e206749873398 ∧ code e206749873398 = 2405773128950 := by decide
theorem cert_e206749873398 : check e206749873398 [] .sourceHead = true := by decide
def e206749873774 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e206749873774 : Closed e206749873774 ∧ code e206749873774 = 2405773129326 := by decide
theorem cert_e206749873774 : check e206749873774 [] .sourceHead = true := by decide
def e206749873786 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e206749873786 : Closed e206749873786 ∧ code e206749873786 = 2405773129338 := by decide
theorem cert_e206749873786 : check e206749873786 [] .sourceHead = true := by decide
def e206749873974 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e206749873974 : Closed e206749873974 ∧ code e206749873974 = 2405773129526 := by decide
theorem cert_e206749873974 : check e206749873974 [] .sourceHead = true := by decide
def e206749873978 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e206749873978 : Closed e206749873978 ∧ code e206749873978 = 2405773129530 := by decide
theorem cert_e206749873978 : check e206749873978 [] .sourceHead = true := by decide
def e206749874606 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e206749874606 : Closed e206749874606 ∧ code e206749874606 = 2405773130158 := by decide
theorem cert_e206749874606 : check e206749874606 [] .sourceHead = true := by decide
def e206749874618 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e206749874618 : Closed e206749874618 ∧ code e206749874618 = 2405773130170 := by decide
theorem cert_e206749874618 : check e206749874618 [] .sourceHead = true := by decide
def e206749874666 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e206749874666 : Closed e206749874666 ∧ code e206749874666 = 2405773130218 := by decide
theorem cert_e206749874666 : check e206749874666 [] .sourceHead = true := by decide
def e206749874798 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e206749874798 : Closed e206749874798 ∧ code e206749874798 = 2405773130350 := by decide
theorem cert_e206749874798 : check e206749874798 [] .sourceHead = true := by decide
def e206749874810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e206749874810 : Closed e206749874810 ∧ code e206749874810 = 2405773130362 := by decide
theorem cert_e206749874810 : check e206749874810 [] .sourceHead = true := by decide
def e206749875098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e206749875098 : Closed e206749875098 ∧ code e206749875098 = 2405773130650 := by decide
theorem cert_e206749875098 : check e206749875098 [] .sourceHead = true := by decide
def e206749875414 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e206749875414 : Closed e206749875414 ∧ code e206749875414 = 2405773130966 := by decide
theorem cert_e206749875414 : check e206749875414 [] .sourceHead = true := by decide
def e206749875418 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e206749875418 : Closed e206749875418 ∧ code e206749875418 = 2405773130970 := by decide
theorem cert_e206749875418 : check e206749875418 [] .sourceHead = true := by decide
def e206749875434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e206749875434 : Closed e206749875434 ∧ code e206749875434 = 2405773130986 := by decide
theorem cert_e206749875434 : check e206749875434 [] .sourceHead = true := by decide
def e206749875510 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e206749875510 : Closed e206749875510 ∧ code e206749875510 = 2405773131062 := by decide
theorem cert_e206749875510 : check e206749875510 [] .sourceHead = true := by decide
def e206749875514 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e206749875514 : Closed e206749875514 ∧ code e206749875514 = 2405773131066 := by decide
theorem cert_e206749875514 : check e206749875514 [] .sourceHead = true := by decide
def e206749875610 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e206749875610 : Closed e206749875610 ∧ code e206749875610 = 2405773131162 := by decide
theorem cert_e206749875610 : check e206749875610 [] .sourceHead = true := by decide
def e206749879150 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e206749879150 : Closed e206749879150 ∧ code e206749879150 = 2405773134702 := by decide
theorem cert_e206749879150 : check e206749879150 [] .sourceHead = true := by decide
def e206749879158 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e206749879158 : Closed e206749879158 ∧ code e206749879158 = 2405773134710 := by decide
theorem cert_e206749879158 : check e206749879158 [] .sourceHead = true := by decide
def e206749879214 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e206749879214 : Closed e206749879214 ∧ code e206749879214 = 2405773134766 := by decide
theorem cert_e206749879214 : check e206749879214 [] .sourceHead = true := by decide
def e206749879226 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e206749879226 : Closed e206749879226 ∧ code e206749879226 = 2405773134778 := by decide
theorem cert_e206749879226 : check e206749879226 [] .sourceHead = true := by decide
def e206749879254 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e206749879254 : Closed e206749879254 ∧ code e206749879254 = 2405773134806 := by decide
theorem cert_e206749879254 : check e206749879254 [] .sourceHead = true := by decide
def e206749879258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e206749879258 : Closed e206749879258 ∧ code e206749879258 = 2405773134810 := by decide
theorem cert_e206749879258 : check e206749879258 [] .sourceHead = true := by decide
def e206749879534 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e206749879534 : Closed e206749879534 ∧ code e206749879534 = 2405773135086 := by decide
theorem cert_e206749879534 : check e206749879534 [] .sourceHead = true := by decide
def e206749879542 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e206749879542 : Closed e206749879542 ∧ code e206749879542 = 2405773135094 := by decide
theorem cert_e206749879542 : check e206749879542 [] .sourceHead = true := by decide
def e206749879918 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e206749879918 : Closed e206749879918 ∧ code e206749879918 = 2405773135470 := by decide
theorem cert_e206749879918 : check e206749879918 [] .sourceHead = true := by decide
def e206749879930 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e206749879930 : Closed e206749879930 ∧ code e206749879930 = 2405773135482 := by decide
theorem cert_e206749879930 : check e206749879930 [] .sourceHead = true := by decide
def e206749880118 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e206749880118 : Closed e206749880118 ∧ code e206749880118 = 2405773135670 := by decide
theorem cert_e206749880118 : check e206749880118 [] .sourceHead = true := by decide
def e206749880122 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e206749880122 : Closed e206749880122 ∧ code e206749880122 = 2405773135674 := by decide
theorem cert_e206749880122 : check e206749880122 [] .sourceHead = true := by decide
def e206749885870 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e206749885870 : Closed e206749885870 ∧ code e206749885870 = 2405773141422 := by decide
theorem cert_e206749885870 : check e206749885870 [] .sourceHead = true := by decide
def e206749885882 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e206749885882 : Closed e206749885882 ∧ code e206749885882 = 2405773141434 := by decide
theorem cert_e206749885882 : check e206749885882 [] .sourceHead = true := by decide
def e206749885930 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e206749885930 : Closed e206749885930 ∧ code e206749885930 = 2405773141482 := by decide
theorem cert_e206749885930 : check e206749885930 [] .sourceHead = true := by decide
def e206749886062 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e206749886062 : Closed e206749886062 ∧ code e206749886062 = 2405773141614 := by decide
theorem cert_e206749886062 : check e206749886062 [] .sourceHead = true := by decide
def e206749886074 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e206749886074 : Closed e206749886074 ∧ code e206749886074 = 2405773141626 := by decide
theorem cert_e206749886074 : check e206749886074 [] .sourceHead = true := by decide
def e206749886362 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e206749886362 : Closed e206749886362 ∧ code e206749886362 = 2405773141914 := by decide
theorem cert_e206749886362 : check e206749886362 [] .sourceHead = true := by decide
def e206749889238 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e206749889238 : Closed e206749889238 ∧ code e206749889238 = 2405773144790 := by decide
theorem cert_e206749889238 : check e206749889238 [] .sourceHead = true := by decide
def e206749889242 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e206749889242 : Closed e206749889242 ∧ code e206749889242 = 2405773144794 := by decide
theorem cert_e206749889242 : check e206749889242 [] .sourceHead = true := by decide
def e206749889258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e206749889258 : Closed e206749889258 ∧ code e206749889258 = 2405773144810 := by decide
theorem cert_e206749889258 : check e206749889258 [] .sourceHead = true := by decide
def e206749889334 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e206749889334 : Closed e206749889334 ∧ code e206749889334 = 2405773144886 := by decide
theorem cert_e206749889334 : check e206749889334 [] .sourceHead = true := by decide
def e206749889338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e206749889338 : Closed e206749889338 ∧ code e206749889338 = 2405773144890 := by decide
theorem cert_e206749889338 : check e206749889338 [] .sourceHead = true := by decide
def e206749889434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e206749889434 : Closed e206749889434 ∧ code e206749889434 = 2405773144986 := by decide
theorem cert_e206749889434 : check e206749889434 [] .sourceHead = true := by decide
def e206750026606 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e206750026606 : Closed e206750026606 ∧ code e206750026606 = 2405773282158 := by decide
theorem cert_e206750026606 : check e206750026606 [] .sourceHead = true := by decide
def e206750026614 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e206750026614 : Closed e206750026614 ∧ code e206750026614 = 2405773282166 := by decide
theorem cert_e206750026614 : check e206750026614 [] .sourceHead = true := by decide
def e206750026670 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e206750026670 : Closed e206750026670 ∧ code e206750026670 = 2405773282222 := by decide
theorem cert_e206750026670 : check e206750026670 [] .sourceHead = true := by decide
def e206750026682 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e206750026682 : Closed e206750026682 ∧ code e206750026682 = 2405773282234 := by decide
theorem cert_e206750026682 : check e206750026682 [] .sourceHead = true := by decide
def e206750026710 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e206750026710 : Closed e206750026710 ∧ code e206750026710 = 2405773282262 := by decide
theorem cert_e206750026710 : check e206750026710 [] .sourceHead = true := by decide
def e206750026714 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e206750026714 : Closed e206750026714 ∧ code e206750026714 = 2405773282266 := by decide
theorem cert_e206750026714 : check e206750026714 [] .sourceHead = true := by decide
def e206750026990 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e206750026990 : Closed e206750026990 ∧ code e206750026990 = 2405773282542 := by decide
theorem cert_e206750026990 : check e206750026990 [] .sourceHead = true := by decide
def e206750026998 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e206750026998 : Closed e206750026998 ∧ code e206750026998 = 2405773282550 := by decide
theorem cert_e206750026998 : check e206750026998 [] .sourceHead = true := by decide
def e206750027374 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e206750027374 : Closed e206750027374 ∧ code e206750027374 = 2405773282926 := by decide
theorem cert_e206750027374 : check e206750027374 [] .sourceHead = true := by decide
def e206750027386 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e206750027386 : Closed e206750027386 ∧ code e206750027386 = 2405773282938 := by decide
theorem cert_e206750027386 : check e206750027386 [] .sourceHead = true := by decide
def e206750027574 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e206750027574 : Closed e206750027574 ∧ code e206750027574 = 2405773283126 := by decide
theorem cert_e206750027574 : check e206750027574 [] .sourceHead = true := by decide
def e206750027578 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e206750027578 : Closed e206750027578 ∧ code e206750027578 = 2405773283130 := by decide
theorem cert_e206750027578 : check e206750027578 [] .sourceHead = true := by decide
def e206755510298 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206755510298 : Closed e206755510298 ∧ code e206755510298 = 2405778765850 := by decide
theorem cert_e206755510298 : check e206755510298 [] .sourceHead = true := by decide
def e206755522586 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206755522586 : Closed e206755522586 ∧ code e206755522586 = 2405778778138 := by decide
theorem cert_e206755522586 : check e206755522586 [] .sourceHead = true := by decide
def e206755571738 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206755571738 : Closed e206755571738 ∧ code e206755571738 = 2405778827290 := by decide
theorem cert_e206755571738 : check e206755571738 [] .sourceHead = true := by decide
def e206755706906 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206755706906 : Closed e206755706906 ∧ code e206755706906 = 2405778962458 := by decide
theorem cert_e206755706906 : check e206755706906 [] .sourceHead = true := by decide
def e206755719194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206755719194 : Closed e206755719194 ∧ code e206755719194 = 2405778974746 := by decide
theorem cert_e206755719194 : check e206755719194 [] .sourceHead = true := by decide
def e206756014106 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206756014106 : Closed e206756014106 ∧ code e206756014106 = 2405779269658 := by decide
theorem cert_e206756014106 : check e206756014106 [] .sourceHead = true := by decide
def e206758959130 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206758959130 : Closed e206758959130 ∧ code e206758959130 = 2405782214682 := by decide
theorem cert_e206758959130 : check e206758959130 [] .sourceHead = true := by decide
def e206758963226 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206758963226 : Closed e206758963226 ∧ code e206758963226 = 2405782218778 := by decide
theorem cert_e206758963226 : check e206758963226 [] .sourceHead = true := by decide
def e206758979610 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206758979610 : Closed e206758979610 ∧ code e206758979610 = 2405782235162 := by decide
theorem cert_e206758979610 : check e206758979610 [] .sourceHead = true := by decide
def e206759057434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206759057434 : Closed e206759057434 ∧ code e206759057434 = 2405782312986 := by decide
theorem cert_e206759057434 : check e206759057434 [] .sourceHead = true := by decide
def e206759061530 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206759061530 : Closed e206759061530 ∧ code e206759061530 = 2405782317082 := by decide
theorem cert_e206759061530 : check e206759061530 [] .sourceHead = true := by decide
def e206759159834 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e206759159834 : Closed e206759159834 ∧ code e206759159834 = 2405782415386 := by decide
theorem cert_e206759159834 : check e206759159834 [] .sourceHead = true := by decide
def e208510236698 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e208510236698 : Closed e208510236698 ∧ code e208510236698 = 2407533492250 := by decide
theorem cert_e208510236698 : check e208510236698 [] .sourceHead = true := by decide
def e208510244890 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e208510244890 : Closed e208510244890 ∧ code e208510244890 = 2407533500442 := by decide
theorem cert_e208510244890 : check e208510244890 [] .sourceHead = true := by decide
def e208510302234 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e208510302234 : Closed e208510302234 ∧ code e208510302234 = 2407533557786 := by decide
theorem cert_e208510302234 : check e208510302234 [] .sourceHead = true := by decide
def e208510314522 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e208510314522 : Closed e208510314522 ∧ code e208510314522 = 2407533570074 := by decide
theorem cert_e208510314522 : check e208510314522 [] .sourceHead = true := by decide
def e208510343194 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e208510343194 : Closed e208510343194 ∧ code e208510343194 = 2407533598746 := by decide
theorem cert_e208510343194 : check e208510343194 [] .sourceHead = true := by decide
def e208510347290 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e208510347290 : Closed e208510347290 ∧ code e208510347290 = 2407533602842 := by decide
theorem cert_e208510347290 : check e208510347290 [] .sourceHead = true := by decide
def e208510629914 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e208510629914 : Closed e208510629914 ∧ code e208510629914 = 2407533885466 := by decide
theorem cert_e208510629914 : check e208510629914 [] .sourceHead = true := by decide
def e208510638106 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e208510638106 : Closed e208510638106 ∧ code e208510638106 = 2407533893658 := by decide
theorem cert_e208510638106 : check e208510638106 [] .sourceHead = true := by decide
def e208511023130 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e208511023130 : Closed e208511023130 ∧ code e208511023130 = 2407534278682 := by decide
theorem cert_e208511023130 : check e208511023130 [] .sourceHead = true := by decide
def e208511035418 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e208511035418 : Closed e208511035418 ∧ code e208511035418 = 2407534290970 := by decide
theorem cert_e208511035418 : check e208511035418 [] .sourceHead = true := by decide
def e208511227930 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e208511227930 : Closed e208511227930 ∧ code e208511227930 = 2407534483482 := by decide
theorem cert_e208511227930 : check e208511227930 [] .sourceHead = true := by decide
def e208511232026 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e208511232026 : Closed e208511232026 ∧ code e208511232026 = 2407534487578 := by decide
theorem cert_e208511232026 : check e208511232026 [] .sourceHead = true := by decide
def e208524062062 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e208524062062 : Closed e208524062062 ∧ code e208524062062 = 2407547317614 := by decide
theorem cert_e208524062062 : check e208524062062 [] .sourceHead = true := by decide
def e208524062070 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e208524062070 : Closed e208524062070 ∧ code e208524062070 = 2407547317622 := by decide
theorem cert_e208524062070 : check e208524062070 [] .sourceHead = true := by decide
def e208524062126 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e208524062126 : Closed e208524062126 ∧ code e208524062126 = 2407547317678 := by decide
theorem cert_e208524062126 : check e208524062126 [] .sourceHead = true := by decide
def e208524062138 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e208524062138 : Closed e208524062138 ∧ code e208524062138 = 2407547317690 := by decide
theorem cert_e208524062138 : check e208524062138 [] .sourceHead = true := by decide
def e208524062166 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e208524062166 : Closed e208524062166 ∧ code e208524062166 = 2407547317718 := by decide
theorem cert_e208524062166 : check e208524062166 [] .sourceHead = true := by decide
def e208524062170 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e208524062170 : Closed e208524062170 ∧ code e208524062170 = 2407547317722 := by decide
theorem cert_e208524062170 : check e208524062170 [] .sourceHead = true := by decide
def e208524062382 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e208524062382 : Closed e208524062382 ∧ code e208524062382 = 2407547317934 := by decide
theorem cert_e208524062382 : check e208524062382 [] .sourceHead = true := by decide
def e208524062394 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e208524062394 : Closed e208524062394 ∧ code e208524062394 = 2407547317946 := by decide
theorem cert_e208524062394 : check e208524062394 [] .sourceHead = true := by decide
end Blc.Floor41
