import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598342880214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598342880214 : Closed e598342880214 ∧ code e598342880214 = 2797366135766 := by decide
theorem cert_e598342880214 : check e598342880214 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e598342880218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598342880218 : Closed e598342880218 ∧ code e598342880218 = 2797366135770 := by decide
theorem cert_e598342880218 : check e598342880218 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e598342880234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e598342880234 : Closed e598342880234 ∧ code e598342880234 = 2797366135786 := by decide
theorem cert_e598342880234 : check e598342880234 [[],[.left],[],[.under,.under]] .three = true := by decide
def e598342880478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e598342880478 : Closed e598342880478 ∧ code e598342880478 = 2797366136030 := by decide
theorem cert_e598342880478 : check e598342880478 [[],[.left],[],[.under,.under]] .three = true := by decide
def e598342880494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598342880494 : Closed e598342880494 ∧ code e598342880494 = 2797366136046 := by decide
theorem cert_e598342880494 : check e598342880494 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e598342880502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598342880502 : Closed e598342880502 ∧ code e598342880502 = 2797366136054 := by decide
theorem cert_e598342880502 : check e598342880502 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e598342880506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e598342880506 : Closed e598342880506 ∧ code e598342880506 = 2797366136058 := by decide
theorem cert_e598342880506 : check e598342880506 [[],[.left],[],[.under,.under]] .three = true := by decide
def e598342880878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598342880878 : Closed e598342880878 ∧ code e598342880878 = 2797366136430 := by decide
theorem cert_e598342880878 : check e598342880878 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e598342880890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598342880890 : Closed e598342880890 ∧ code e598342880890 = 2797366136442 := by decide
theorem cert_e598342880890 : check e598342880890 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e598342881078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598342881078 : Closed e598342881078 ∧ code e598342881078 = 2797366136630 := by decide
theorem cert_e598342881078 : check e598342881078 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e598342881082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598342881082 : Closed e598342881082 ∧ code e598342881082 = 2797366136634 := by decide
theorem cert_e598342881082 : check e598342881082 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e598342881178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e598342881178 : Closed e598342881178 ∧ code e598342881178 = 2797366136730 := by decide
theorem cert_e598342881178 : check e598342881178 [[],[.left],[],[.under,.under]] .three = true := by decide
def e598342886830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e598342886830 : Closed e598342886830 ∧ code e598342886830 = 2797366142382 := by decide
theorem cert_e598342886830 : check e598342886830 [[],[.left],[],[.under,.under]] .three = true := by decide
def e598342886838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e598342886838 : Closed e598342886838 ∧ code e598342886838 = 2797366142390 := by decide
theorem cert_e598342886838 : check e598342886838 [[],[.left],[]] .chain = true := by decide
def e598342886842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e598342886842 : Closed e598342886842 ∧ code e598342886842 = 2797366142394 := by decide
theorem cert_e598342886842 : check e598342886842 [[],[.left],[],[.under,.under]] .three = true := by decide
def e598342886870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e598342886870 : Closed e598342886870 ∧ code e598342886870 = 2797366142422 := by decide
theorem cert_e598342886870 : check e598342886870 [[],[.left],[]] .chain = true := by decide
def e598342886874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e598342886874 : Closed e598342886874 ∧ code e598342886874 = 2797366142426 := by decide
theorem cert_e598342886874 : check e598342886874 [[],[.left],[]] .chain = true := by decide
def e598342886890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e598342886890 : Closed e598342886890 ∧ code e598342886890 = 2797366142442 := by decide
theorem cert_e598342886890 : check e598342886890 [[],[.left],[],[.under,.under]] .three = true := by decide
def e598342887022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e598342887022 : Closed e598342887022 ∧ code e598342887022 = 2797366142574 := by decide
theorem cert_e598342887022 : check e598342887022 [[],[.left],[],[.under,.under]] .three = true := by decide
def e598342887030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e598342887030 : Closed e598342887030 ∧ code e598342887030 = 2797366142582 := by decide
theorem cert_e598342887030 : check e598342887030 [[],[.left],[]] .chain = true := by decide
def e598342887034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e598342887034 : Closed e598342887034 ∧ code e598342887034 = 2797366142586 := by decide
theorem cert_e598342887034 : check e598342887034 [[],[.left],[],[.under,.under]] .three = true := by decide
def e598342887222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e598342887222 : Closed e598342887222 ∧ code e598342887222 = 2797366142774 := by decide
theorem cert_e598342887222 : check e598342887222 [[],[.left],[]] .chain = true := by decide
def e598342887226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e598342887226 : Closed e598342887226 ∧ code e598342887226 = 2797366142778 := by decide
theorem cert_e598342887226 : check e598342887226 [[],[.left],[]] .chain = true := by decide
def e598342887322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e598342887322 : Closed e598342887322 ∧ code e598342887322 = 2797366142874 := by decide
theorem cert_e598342887322 : check e598342887322 [[],[.left],[],[.under,.under]] .three = true := by decide
def e598343333230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e598343333230 : Closed e598343333230 ∧ code e598343333230 = 2797366588782 := by decide
theorem cert_e598343333230 : check e598343333230 [[],[.left],[]] .sourceHead = true := by decide
def e598343333238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e598343333238 : Closed e598343333238 ∧ code e598343333238 = 2797366588790 := by decide
theorem cert_e598343333238 : check e598343333238 [[],[.left],[]] .sourceHead = true := by decide
def e598343333294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e598343333294 : Closed e598343333294 ∧ code e598343333294 = 2797366588846 := by decide
theorem cert_e598343333294 : check e598343333294 [[],[.left],[]] .sourceHead = true := by decide
def e598343333306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e598343333306 : Closed e598343333306 ∧ code e598343333306 = 2797366588858 := by decide
theorem cert_e598343333306 : check e598343333306 [[],[.left],[]] .sourceHead = true := by decide
def e598343333334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e598343333334 : Closed e598343333334 ∧ code e598343333334 = 2797366588886 := by decide
theorem cert_e598343333334 : check e598343333334 [[],[.left],[]] .sourceHead = true := by decide
def e598343333338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e598343333338 : Closed e598343333338 ∧ code e598343333338 = 2797366588890 := by decide
theorem cert_e598343333338 : check e598343333338 [[],[.left],[]] .sourceHead = true := by decide
def e598343333550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e598343333550 : Closed e598343333550 ∧ code e598343333550 = 2797366589102 := by decide
theorem cert_e598343333550 : check e598343333550 [[],[.left],[]] .sourceHead = true := by decide
def e598343333562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e598343333562 : Closed e598343333562 ∧ code e598343333562 = 2797366589114 := by decide
theorem cert_e598343333562 : check e598343333562 [[],[.left],[]] .sourceHead = true := by decide
def e598343333610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e598343333610 : Closed e598343333610 ∧ code e598343333610 = 2797366589162 := by decide
theorem cert_e598343333610 : check e598343333610 [[],[.left],[]] .sourceHead = true := by decide
def e598343333718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e598343333718 : Closed e598343333718 ∧ code e598343333718 = 2797366589270 := by decide
theorem cert_e598343333718 : check e598343333718 [[],[.left],[]] .sourceHead = true := by decide
def e598343333722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e598343333722 : Closed e598343333722 ∧ code e598343333722 = 2797366589274 := by decide
theorem cert_e598343333722 : check e598343333722 [[],[.left],[]] .sourceHead = true := by decide
def e598343333738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e598343333738 : Closed e598343333738 ∧ code e598343333738 = 2797366589290 := by decide
theorem cert_e598343333738 : check e598343333738 [[],[.left],[]] .sourceHead = true := by decide
def e598343334574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e598343334574 : Closed e598343334574 ∧ code e598343334574 = 2797366590126 := by decide
theorem cert_e598343334574 : check e598343334574 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343334586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e598343334586 : Closed e598343334586 ∧ code e598343334586 = 2797366590138 := by decide
theorem cert_e598343334586 : check e598343334586 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e598343334634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e598343334634 : Closed e598343334634 ∧ code e598343334634 = 2797366590186 := by decide
theorem cert_e598343334634 : check e598343334634 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e598343334826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e598343334826 : Closed e598343334826 ∧ code e598343334826 = 2797366590378 := by decide
theorem cert_e598343334826 : check e598343334826 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e598343335254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e598343335254 : Closed e598343335254 ∧ code e598343335254 = 2797366590806 := by decide
theorem cert_e598343335254 : check e598343335254 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343335258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e598343335258 : Closed e598343335258 ∧ code e598343335258 = 2797366590810 := by decide
theorem cert_e598343335258 : check e598343335258 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e598343335274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e598343335274 : Closed e598343335274 ∧ code e598343335274 = 2797366590826 := by decide
theorem cert_e598343335274 : check e598343335274 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e598343335338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e598343335338 : Closed e598343335338 ∧ code e598343335338 = 2797366590890 := by decide
theorem cert_e598343335338 : check e598343335338 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e598343337838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e598343337838 : Closed e598343337838 ∧ code e598343337838 = 2797366593390 := by decide
theorem cert_e598343337838 : check e598343337838 [[],[.left],[]] .sourceHead = true := by decide
def e598343337846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e598343337846 : Closed e598343337846 ∧ code e598343337846 = 2797366593398 := by decide
theorem cert_e598343337846 : check e598343337846 [[],[.left],[]] .sourceHead = true := by decide
def e598343337910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e598343337910 : Closed e598343337910 ∧ code e598343337910 = 2797366593462 := by decide
theorem cert_e598343337910 : check e598343337910 [[],[.left],[]] .sourceHead = true := by decide
def e598343339374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e598343339374 : Closed e598343339374 ∧ code e598343339374 = 2797366594926 := by decide
theorem cert_e598343339374 : check e598343339374 [[],[.left],[]] .sourceHead = true := by decide
def e598343339382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e598343339382 : Closed e598343339382 ∧ code e598343339382 = 2797366594934 := by decide
theorem cert_e598343339382 : check e598343339382 [[],[.left],[]] .sourceHead = true := by decide
def e598343339438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e598343339438 : Closed e598343339438 ∧ code e598343339438 = 2797366594990 := by decide
theorem cert_e598343339438 : check e598343339438 [[],[.left],[]] .sourceHead = true := by decide
def e598343339450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e598343339450 : Closed e598343339450 ∧ code e598343339450 = 2797366595002 := by decide
theorem cert_e598343339450 : check e598343339450 [[],[.left],[]] .sourceHead = true := by decide
def e598343339478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e598343339478 : Closed e598343339478 ∧ code e598343339478 = 2797366595030 := by decide
theorem cert_e598343339478 : check e598343339478 [[],[.left],[]] .sourceHead = true := by decide
def e598343339482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e598343339482 : Closed e598343339482 ∧ code e598343339482 = 2797366595034 := by decide
theorem cert_e598343339482 : check e598343339482 [[],[.left],[]] .sourceHead = true := by decide
def e598343339694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e598343339694 : Closed e598343339694 ∧ code e598343339694 = 2797366595246 := by decide
theorem cert_e598343339694 : check e598343339694 [[],[.left],[]] .sourceHead = true := by decide
def e598343339706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e598343339706 : Closed e598343339706 ∧ code e598343339706 = 2797366595258 := by decide
theorem cert_e598343339706 : check e598343339706 [[],[.left],[]] .sourceHead = true := by decide
def e598343339754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e598343339754 : Closed e598343339754 ∧ code e598343339754 = 2797366595306 := by decide
theorem cert_e598343339754 : check e598343339754 [[],[.left],[]] .sourceHead = true := by decide
def e598343339862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e598343339862 : Closed e598343339862 ∧ code e598343339862 = 2797366595414 := by decide
theorem cert_e598343339862 : check e598343339862 [[],[.left],[]] .sourceHead = true := by decide
def e598343339866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e598343339866 : Closed e598343339866 ∧ code e598343339866 = 2797366595418 := by decide
theorem cert_e598343339866 : check e598343339866 [[],[.left],[]] .sourceHead = true := by decide
def e598343339882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e598343339882 : Closed e598343339882 ∧ code e598343339882 = 2797366595434 := by decide
theorem cert_e598343339882 : check e598343339882 [[],[.left],[]] .sourceHead = true := by decide
def e598343340910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e598343340910 : Closed e598343340910 ∧ code e598343340910 = 2797366596462 := by decide
theorem cert_e598343340910 : check e598343340910 [[],[.left],[]] .sourceHead = true := by decide
def e598343340918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e598343340918 : Closed e598343340918 ∧ code e598343340918 = 2797366596470 := by decide
theorem cert_e598343340918 : check e598343340918 [[],[.left],[]] .sourceHead = true := by decide
def e598343340974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e598343340974 : Closed e598343340974 ∧ code e598343340974 = 2797366596526 := by decide
theorem cert_e598343340974 : check e598343340974 [[],[.left],[]] .sourceHead = true := by decide
def e598343340986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e598343340986 : Closed e598343340986 ∧ code e598343340986 = 2797366596538 := by decide
theorem cert_e598343340986 : check e598343340986 [[],[.left],[]] .sourceHead = true := by decide
def e598343341014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e598343341014 : Closed e598343341014 ∧ code e598343341014 = 2797366596566 := by decide
theorem cert_e598343341014 : check e598343341014 [[],[.left],[]] .sourceHead = true := by decide
def e598343341018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e598343341018 : Closed e598343341018 ∧ code e598343341018 = 2797366596570 := by decide
theorem cert_e598343341018 : check e598343341018 [[],[.left],[]] .sourceHead = true := by decide
def e598343341294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e598343341294 : Closed e598343341294 ∧ code e598343341294 = 2797366596846 := by decide
theorem cert_e598343341294 : check e598343341294 [[],[.left],[]] .sourceHead = true := by decide
def e598343341302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e598343341302 : Closed e598343341302 ∧ code e598343341302 = 2797366596854 := by decide
theorem cert_e598343341302 : check e598343341302 [[],[.left],[]] .sourceHead = true := by decide
def e598343341678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e598343341678 : Closed e598343341678 ∧ code e598343341678 = 2797366597230 := by decide
theorem cert_e598343341678 : check e598343341678 [[],[.left],[]] .sourceHead = true := by decide
def e598343341690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e598343341690 : Closed e598343341690 ∧ code e598343341690 = 2797366597242 := by decide
theorem cert_e598343341690 : check e598343341690 [[],[.left],[]] .sourceHead = true := by decide
def e598343341878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e598343341878 : Closed e598343341878 ∧ code e598343341878 = 2797366597430 := by decide
theorem cert_e598343341878 : check e598343341878 [[],[.left],[]] .sourceHead = true := by decide
def e598343341882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e598343341882 : Closed e598343341882 ∧ code e598343341882 = 2797366597434 := by decide
theorem cert_e598343341882 : check e598343341882 [[],[.left],[]] .sourceHead = true := by decide
def e598343342318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e598343342318 : Closed e598343342318 ∧ code e598343342318 = 2797366597870 := by decide
theorem cert_e598343342318 : check e598343342318 [[],[.left],[]] .sourceHead = true := by decide
def e598343342326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e598343342326 : Closed e598343342326 ∧ code e598343342326 = 2797366597878 := by decide
theorem cert_e598343342326 : check e598343342326 [[],[.left],[]] .sourceHead = true := by decide
def e598343342510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e598343342510 : Closed e598343342510 ∧ code e598343342510 = 2797366598062 := by decide
theorem cert_e598343342510 : check e598343342510 [[],[.left],[]] .sourceHead = true := by decide
def e598343342522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e598343342522 : Closed e598343342522 ∧ code e598343342522 = 2797366598074 := by decide
theorem cert_e598343342522 : check e598343342522 [[],[.left],[]] .sourceHead = true := by decide
def e598343342570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e598343342570 : Closed e598343342570 ∧ code e598343342570 = 2797366598122 := by decide
theorem cert_e598343342570 : check e598343342570 [[],[.left],[]] .sourceHead = true := by decide
def e598343342702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e598343342702 : Closed e598343342702 ∧ code e598343342702 = 2797366598254 := by decide
theorem cert_e598343342702 : check e598343342702 [[],[.left],[]] .sourceHead = true := by decide
def e598343342714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e598343342714 : Closed e598343342714 ∧ code e598343342714 = 2797366598266 := by decide
theorem cert_e598343342714 : check e598343342714 [[],[.left],[]] .sourceHead = true := by decide
def e598343342878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e598343342878 : Closed e598343342878 ∧ code e598343342878 = 2797366598430 := by decide
theorem cert_e598343342878 : check e598343342878 [[],[.left],[]] .sourceHead = true := by decide
def e598343342990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e598343342990 : Closed e598343342990 ∧ code e598343342990 = 2797366598542 := by decide
theorem cert_e598343342990 : check e598343342990 [[],[.left],[]] .sourceHead = true := by decide
def e598343343002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e598343343002 : Closed e598343343002 ∧ code e598343343002 = 2797366598554 := by decide
theorem cert_e598343343002 : check e598343343002 [[],[.left],[]] .sourceHead = true := by decide
def e598343343222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e598343343222 : Closed e598343343222 ∧ code e598343343222 = 2797366598774 := by decide
theorem cert_e598343343222 : check e598343343222 [[],[.left],[]] .sourceHead = true := by decide
def e598343343318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e598343343318 : Closed e598343343318 ∧ code e598343343318 = 2797366598870 := by decide
theorem cert_e598343343318 : check e598343343318 [[],[.left],[]] .sourceHead = true := by decide
def e598343343322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e598343343322 : Closed e598343343322 ∧ code e598343343322 = 2797366598874 := by decide
theorem cert_e598343343322 : check e598343343322 [[],[.left],[]] .sourceHead = true := by decide
def e598343343338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e598343343338 : Closed e598343343338 ∧ code e598343343338 = 2797366598890 := by decide
theorem cert_e598343343338 : check e598343343338 [[],[.left],[]] .sourceHead = true := by decide
def e598343343414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e598343343414 : Closed e598343343414 ∧ code e598343343414 = 2797366598966 := by decide
theorem cert_e598343343414 : check e598343343414 [[],[.left],[]] .sourceHead = true := by decide
def e598343343418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e598343343418 : Closed e598343343418 ∧ code e598343343418 = 2797366598970 := by decide
theorem cert_e598343343418 : check e598343343418 [[],[.left],[]] .sourceHead = true := by decide
def e598343343502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e598343343502 : Closed e598343343502 ∧ code e598343343502 = 2797366599054 := by decide
theorem cert_e598343343502 : check e598343343502 [[],[.left],[]] .sourceHead = true := by decide
def e598343343514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e598343343514 : Closed e598343343514 ∧ code e598343343514 = 2797366599066 := by decide
theorem cert_e598343343514 : check e598343343514 [[],[.left],[]] .sourceHead = true := by decide
def e598343345006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e598343345006 : Closed e598343345006 ∧ code e598343345006 = 2797366600558 := by decide
def e598343345014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e598343345014 : Closed e598343345014 ∧ code e598343345014 = 2797366600566 := by decide
theorem cert_e598343345014 : check e598343345014 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e598343345070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e598343345070 : Closed e598343345070 ∧ code e598343345070 = 2797366600622 := by decide
theorem cert_e598343345070 : check e598343345070 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343345082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e598343345082 : Closed e598343345082 ∧ code e598343345082 = 2797366600634 := by decide
theorem cert_e598343345082 : check e598343345082 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343345110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e598343345110 : Closed e598343345110 ∧ code e598343345110 = 2797366600662 := by decide
theorem cert_e598343345110 : check e598343345110 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343345114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e598343345114 : Closed e598343345114 ∧ code e598343345114 = 2797366600666 := by decide
def e598343345838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e598343345838 : Closed e598343345838 ∧ code e598343345838 = 2797366601390 := by decide
theorem cert_e598343345838 : check e598343345838 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343345850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e598343345850 : Closed e598343345850 ∧ code e598343345850 = 2797366601402 := by decide
theorem cert_e598343345850 : check e598343345850 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343345898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e598343345898 : Closed e598343345898 ∧ code e598343345898 = 2797366601450 := by decide
theorem cert_e598343345898 : check e598343345898 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e598343346090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e598343346090 : Closed e598343346090 ∧ code e598343346090 = 2797366601642 := by decide
theorem cert_e598343346090 : check e598343346090 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e598343346414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e598343346414 : Closed e598343346414 ∧ code e598343346414 = 2797366601966 := by decide
theorem cert_e598343346414 : check e598343346414 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343346422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e598343346422 : Closed e598343346422 ∧ code e598343346422 = 2797366601974 := by decide
theorem cert_e598343346422 : check e598343346422 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598343346606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e598343346606 : Closed e598343346606 ∧ code e598343346606 = 2797366602158 := by decide
theorem cert_e598343346606 : check e598343346606 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343346618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e598343346618 : Closed e598343346618 ∧ code e598343346618 = 2797366602170 := by decide
theorem cert_e598343346618 : check e598343346618 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343346666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e598343346666 : Closed e598343346666 ∧ code e598343346666 = 2797366602218 := by decide
theorem cert_e598343346666 : check e598343346666 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343346798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e598343346798 : Closed e598343346798 ∧ code e598343346798 = 2797366602350 := by decide
theorem cert_e598343346798 : check e598343346798 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343346810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e598343346810 : Closed e598343346810 ∧ code e598343346810 = 2797366602362 := by decide
theorem cert_e598343346810 : check e598343346810 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343346974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e598343346974 : Closed e598343346974 ∧ code e598343346974 = 2797366602526 := by decide
def e598343347086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e598343347086 : Closed e598343347086 ∧ code e598343347086 = 2797366602638 := by decide
theorem cert_e598343347086 : check e598343347086 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343347098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e598343347098 : Closed e598343347098 ∧ code e598343347098 = 2797366602650 := by decide
theorem cert_e598343347098 : check e598343347098 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343347310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e598343347310 : Closed e598343347310 ∧ code e598343347310 = 2797366602862 := by decide
theorem cert_e598343347310 : check e598343347310 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e598343347322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e598343347322 : Closed e598343347322 ∧ code e598343347322 = 2797366602874 := by decide
theorem cert_e598343347322 : check e598343347322 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343347486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e598343347486 : Closed e598343347486 ∧ code e598343347486 = 2797366603038 := by decide
theorem cert_e598343347486 : check e598343347486 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343347654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e598343347654 : Closed e598343347654 ∧ code e598343347654 = 2797366603206 := by decide
def e598343347766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e598343347766 : Closed e598343347766 ∧ code e598343347766 = 2797366603318 := by decide
theorem cert_e598343347766 : check e598343347766 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e598343347770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e598343347770 : Closed e598343347770 ∧ code e598343347770 = 2797366603322 := by decide
theorem cert_e598343347770 : check e598343347770 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343347818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e598343347818 : Closed e598343347818 ∧ code e598343347818 = 2797366603370 := by decide
theorem cert_e598343347818 : check e598343347818 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e598343347854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e598343347854 : Closed e598343347854 ∧ code e598343347854 = 2797366603406 := by decide
theorem cert_e598343347854 : check e598343347854 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343347866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e598343347866 : Closed e598343347866 ∧ code e598343347866 = 2797366603418 := by decide
theorem cert_e598343347866 : check e598343347866 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e598343347910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e598343347910 : Closed e598343347910 ∧ code e598343347910 = 2797366603462 := by decide
def e598343348662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e598343348662 : Closed e598343348662 ∧ code e598343348662 = 2797366604214 := by decide
theorem cert_e598343348662 : check e598343348662 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e598343348694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e598343348694 : Closed e598343348694 ∧ code e598343348694 = 2797366604246 := by decide
theorem cert_e598343348694 : check e598343348694 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343348698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e598343348698 : Closed e598343348698 ∧ code e598343348698 = 2797366604250 := by decide
theorem cert_e598343348698 : check e598343348698 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343349078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e598343349078 : Closed e598343349078 ∧ code e598343349078 = 2797366604630 := by decide
theorem cert_e598343349078 : check e598343349078 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343349082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e598343349082 : Closed e598343349082 ∧ code e598343349082 = 2797366604634 := by decide
theorem cert_e598343349082 : check e598343349082 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343349098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e598343349098 : Closed e598343349098 ∧ code e598343349098 = 2797366604650 := by decide
theorem cert_e598343349098 : check e598343349098 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e598343349162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e598343349162 : Closed e598343349162 ∧ code e598343349162 = 2797366604714 := by decide
theorem cert_e598343349162 : check e598343349162 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e598343349366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e598343349366 : Closed e598343349366 ∧ code e598343349366 = 2797366604918 := by decide
theorem cert_e598343349366 : check e598343349366 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343349462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e598343349462 : Closed e598343349462 ∧ code e598343349462 = 2797366605014 := by decide
theorem cert_e598343349462 : check e598343349462 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343349466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e598343349466 : Closed e598343349466 ∧ code e598343349466 = 2797366605018 := by decide
theorem cert_e598343349466 : check e598343349466 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343349482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e598343349482 : Closed e598343349482 ∧ code e598343349482 = 2797366605034 := by decide
theorem cert_e598343349482 : check e598343349482 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343349558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e598343349558 : Closed e598343349558 ∧ code e598343349558 = 2797366605110 := by decide
theorem cert_e598343349558 : check e598343349558 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343349562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e598343349562 : Closed e598343349562 ∧ code e598343349562 = 2797366605114 := by decide
theorem cert_e598343349562 : check e598343349562 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343349646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e598343349646 : Closed e598343349646 ∧ code e598343349646 = 2797366605198 := by decide
theorem cert_e598343349646 : check e598343349646 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343349658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e598343349658 : Closed e598343349658 ∧ code e598343349658 = 2797366605210 := by decide
theorem cert_e598343349658 : check e598343349658 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343349814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e598343349814 : Closed e598343349814 ∧ code e598343349814 = 2797366605366 := by decide
theorem cert_e598343349814 : check e598343349814 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e598343349818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e598343349818 : Closed e598343349818 ∧ code e598343349818 = 2797366605370 := by decide
theorem cert_e598343349818 : check e598343349818 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e598343349866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e598343349866 : Closed e598343349866 ∧ code e598343349866 = 2797366605418 := by decide
theorem cert_e598343349866 : check e598343349866 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e598343349902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e598343349902 : Closed e598343349902 ∧ code e598343349902 = 2797366605454 := by decide
theorem cert_e598343349902 : check e598343349902 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598343349914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e598343349914 : Closed e598343349914 ∧ code e598343349914 = 2797366605466 := by decide
theorem cert_e598343349914 : check e598343349914 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e598343349958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e598343349958 : Closed e598343349958 ∧ code e598343349958 = 2797366605510 := by decide
def e598343356142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e598343356142 : Closed e598343356142 ∧ code e598343356142 = 2797366611694 := by decide
theorem cert_e598343356142 : check e598343356142 [[],[.left],[]] .sourceHead = true := by decide
def e598343356150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e598343356150 : Closed e598343356150 ∧ code e598343356150 = 2797366611702 := by decide
theorem cert_e598343356150 : check e598343356150 [[],[.left],[]] .sourceHead = true := by decide
def e598343356270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e598343356270 : Closed e598343356270 ∧ code e598343356270 = 2797366611822 := by decide
theorem cert_e598343356270 : check e598343356270 [[],[.left],[]] .sourceHead = true := by decide
def e598343356282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e598343356282 : Closed e598343356282 ∧ code e598343356282 = 2797366611834 := by decide
theorem cert_e598343356282 : check e598343356282 [[],[.left],[]] .sourceHead = true := by decide
def e598343356342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e598343356342 : Closed e598343356342 ∧ code e598343356342 = 2797366611894 := by decide
theorem cert_e598343356342 : check e598343356342 [[],[.left],[]] .sourceHead = true := by decide
def e598343356346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e598343356346 : Closed e598343356346 ∧ code e598343356346 = 2797366611898 := by decide
theorem cert_e598343356346 : check e598343356346 [[],[.left],[]] .sourceHead = true := by decide
def e598343359726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e598343359726 : Closed e598343359726 ∧ code e598343359726 = 2797366615278 := by decide
theorem cert_e598343359726 : check e598343359726 [[],[.left],[]] .sourceHead = true := by decide
def e598343359734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e598343359734 : Closed e598343359734 ∧ code e598343359734 = 2797366615286 := by decide
theorem cert_e598343359734 : check e598343359734 [[],[.left],[]] .sourceHead = true := by decide
def e598343360118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e598343360118 : Closed e598343360118 ∧ code e598343360118 = 2797366615670 := by decide
theorem cert_e598343360118 : check e598343360118 [[],[.left],[]] .sourceHead = true := by decide
def e598343363950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e598343363950 : Closed e598343363950 ∧ code e598343363950 = 2797366619502 := by decide
theorem cert_e598343363950 : check e598343363950 [[],[.left],[]] .sourceHead = true := by decide
def e598343363958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e598343363958 : Closed e598343363958 ∧ code e598343363958 = 2797366619510 := by decide
theorem cert_e598343363958 : check e598343363958 [[],[.left],[]] .sourceHead = true := by decide
def e598343364014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e598343364014 : Closed e598343364014 ∧ code e598343364014 = 2797366619566 := by decide
theorem cert_e598343364014 : check e598343364014 [[],[.left],[]] .sourceHead = true := by decide
def e598343364026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e598343364026 : Closed e598343364026 ∧ code e598343364026 = 2797366619578 := by decide
theorem cert_e598343364026 : check e598343364026 [[],[.left],[]] .sourceHead = true := by decide
def e598343364054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e598343364054 : Closed e598343364054 ∧ code e598343364054 = 2797366619606 := by decide
theorem cert_e598343364054 : check e598343364054 [[],[.left],[]] .sourceHead = true := by decide
def e598343364058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e598343364058 : Closed e598343364058 ∧ code e598343364058 = 2797366619610 := by decide
theorem cert_e598343364058 : check e598343364058 [[],[.left],[]] .sourceHead = true := by decide
def e598343364270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e598343364270 : Closed e598343364270 ∧ code e598343364270 = 2797366619822 := by decide
theorem cert_e598343364270 : check e598343364270 [[],[.left],[]] .sourceHead = true := by decide
def e598343364282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e598343364282 : Closed e598343364282 ∧ code e598343364282 = 2797366619834 := by decide
theorem cert_e598343364282 : check e598343364282 [[],[.left],[]] .sourceHead = true := by decide
def e598343364330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e598343364330 : Closed e598343364330 ∧ code e598343364330 = 2797366619882 := by decide
theorem cert_e598343364330 : check e598343364330 [[],[.left],[]] .sourceHead = true := by decide
def e598343364438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e598343364438 : Closed e598343364438 ∧ code e598343364438 = 2797366619990 := by decide
theorem cert_e598343364438 : check e598343364438 [[],[.left],[]] .sourceHead = true := by decide
def e598343364442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e598343364442 : Closed e598343364442 ∧ code e598343364442 = 2797366619994 := by decide
theorem cert_e598343364442 : check e598343364442 [[],[.left],[]] .sourceHead = true := by decide
end Blc.Floor41
