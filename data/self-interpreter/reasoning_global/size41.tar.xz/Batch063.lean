import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e604583802478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e604583802478 : Closed e604583802478 ∧ code e604583802478 = 2803607058030 := by decide
theorem cert_e604583802478 : check e604583802478 [[],[]] .smaller = true := by decide
def e604583802490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e604583802490 : Closed e604583802490 ∧ code e604583802490 = 2803607058042 := by decide
theorem cert_e604583802490 : check e604583802490 [[],[]] .smaller = true := by decide
def e604583802678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e604583802678 : Closed e604583802678 ∧ code e604583802678 = 2803607058230 := by decide
theorem cert_e604583802678 : check e604583802678 [[],[]] .smaller = true := by decide
def e604583802682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e604583802682 : Closed e604583802682 ∧ code e604583802682 = 2803607058234 := by decide
theorem cert_e604583802682 : check e604583802682 [[],[]] .smaller = true := by decide
def e604583803310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e604583803310 : Closed e604583803310 ∧ code e604583803310 = 2803607058862 := by decide
theorem cert_e604583803310 : check e604583803310 [[],[]] .smaller = true := by decide
def e604583803322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e604583803322 : Closed e604583803322 ∧ code e604583803322 = 2803607058874 := by decide
theorem cert_e604583803322 : check e604583803322 [[],[]] .smaller = true := by decide
def e604583803370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e604583803370 : Closed e604583803370 ∧ code e604583803370 = 2803607058922 := by decide
theorem cert_e604583803370 : check e604583803370 [[],[]] .smaller = true := by decide
def e604583803502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e604583803502 : Closed e604583803502 ∧ code e604583803502 = 2803607059054 := by decide
theorem cert_e604583803502 : check e604583803502 [[],[]] .smaller = true := by decide
def e604583803514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e604583803514 : Closed e604583803514 ∧ code e604583803514 = 2803607059066 := by decide
theorem cert_e604583803514 : check e604583803514 [[],[]] .smaller = true := by decide
def e604583803802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e604583803802 : Closed e604583803802 ∧ code e604583803802 = 2803607059354 := by decide
theorem cert_e604583803802 : check e604583803802 [[],[]] .smaller = true := by decide
def e604583804118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e604583804118 : Closed e604583804118 ∧ code e604583804118 = 2803607059670 := by decide
theorem cert_e604583804118 : check e604583804118 [[],[]] .smaller = true := by decide
def e604583804122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e604583804122 : Closed e604583804122 ∧ code e604583804122 = 2803607059674 := by decide
theorem cert_e604583804122 : check e604583804122 [[],[]] .smaller = true := by decide
def e604583804138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e604583804138 : Closed e604583804138 ∧ code e604583804138 = 2803607059690 := by decide
theorem cert_e604583804138 : check e604583804138 [[],[]] .smaller = true := by decide
def e604583804214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e604583804214 : Closed e604583804214 ∧ code e604583804214 = 2803607059766 := by decide
theorem cert_e604583804214 : check e604583804214 [[],[]] .smaller = true := by decide
def e604583804218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e604583804218 : Closed e604583804218 ∧ code e604583804218 = 2803607059770 := by decide
theorem cert_e604583804218 : check e604583804218 [[],[]] .smaller = true := by decide
def e604583804314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e604583804314 : Closed e604583804314 ∧ code e604583804314 = 2803607059866 := by decide
theorem cert_e604583804314 : check e604583804314 [[],[]] .smaller = true := by decide
def e604583807854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e604583807854 : Closed e604583807854 ∧ code e604583807854 = 2803607063406 := by decide
theorem cert_e604583807854 : check e604583807854 [[],[]] .smaller = true := by decide
def e604583807862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e604583807862 : Closed e604583807862 ∧ code e604583807862 = 2803607063414 := by decide
theorem cert_e604583807862 : check e604583807862 [[],[]] .smaller = true := by decide
def e604583807918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e604583807918 : Closed e604583807918 ∧ code e604583807918 = 2803607063470 := by decide
theorem cert_e604583807918 : check e604583807918 [[],[]] .smaller = true := by decide
def e604583807930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e604583807930 : Closed e604583807930 ∧ code e604583807930 = 2803607063482 := by decide
theorem cert_e604583807930 : check e604583807930 [[],[]] .smaller = true := by decide
def e604583807958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e604583807958 : Closed e604583807958 ∧ code e604583807958 = 2803607063510 := by decide
theorem cert_e604583807958 : check e604583807958 [[],[]] .smaller = true := by decide
def e604583807962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e604583807962 : Closed e604583807962 ∧ code e604583807962 = 2803607063514 := by decide
theorem cert_e604583807962 : check e604583807962 [[],[]] .smaller = true := by decide
def e604583808238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e604583808238 : Closed e604583808238 ∧ code e604583808238 = 2803607063790 := by decide
theorem cert_e604583808238 : check e604583808238 [[],[]] .smaller = true := by decide
def e604583808246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e604583808246 : Closed e604583808246 ∧ code e604583808246 = 2803607063798 := by decide
theorem cert_e604583808246 : check e604583808246 [[],[]] .smaller = true := by decide
def e604583808622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e604583808622 : Closed e604583808622 ∧ code e604583808622 = 2803607064174 := by decide
theorem cert_e604583808622 : check e604583808622 [[],[]] .smaller = true := by decide
def e604583808634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e604583808634 : Closed e604583808634 ∧ code e604583808634 = 2803607064186 := by decide
theorem cert_e604583808634 : check e604583808634 [[],[]] .smaller = true := by decide
def e604583808822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e604583808822 : Closed e604583808822 ∧ code e604583808822 = 2803607064374 := by decide
theorem cert_e604583808822 : check e604583808822 [[],[]] .smaller = true := by decide
def e604583808826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e604583808826 : Closed e604583808826 ∧ code e604583808826 = 2803607064378 := by decide
theorem cert_e604583808826 : check e604583808826 [[],[]] .smaller = true := by decide
def e604583814574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e604583814574 : Closed e604583814574 ∧ code e604583814574 = 2803607070126 := by decide
theorem cert_e604583814574 : check e604583814574 [[],[]] .smaller = true := by decide
def e604583814586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e604583814586 : Closed e604583814586 ∧ code e604583814586 = 2803607070138 := by decide
theorem cert_e604583814586 : check e604583814586 [[],[]] .smaller = true := by decide
def e604583814634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e604583814634 : Closed e604583814634 ∧ code e604583814634 = 2803607070186 := by decide
theorem cert_e604583814634 : check e604583814634 [[],[]] .smaller = true := by decide
def e604583814766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e604583814766 : Closed e604583814766 ∧ code e604583814766 = 2803607070318 := by decide
theorem cert_e604583814766 : check e604583814766 [[],[]] .smaller = true := by decide
def e604583814778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e604583814778 : Closed e604583814778 ∧ code e604583814778 = 2803607070330 := by decide
theorem cert_e604583814778 : check e604583814778 [[],[]] .smaller = true := by decide
def e604583815066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e604583815066 : Closed e604583815066 ∧ code e604583815066 = 2803607070618 := by decide
theorem cert_e604583815066 : check e604583815066 [[],[]] .smaller = true := by decide
def e604583817942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e604583817942 : Closed e604583817942 ∧ code e604583817942 = 2803607073494 := by decide
theorem cert_e604583817942 : check e604583817942 [[],[]] .smaller = true := by decide
def e604583817946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e604583817946 : Closed e604583817946 ∧ code e604583817946 = 2803607073498 := by decide
theorem cert_e604583817946 : check e604583817946 [[],[]] .smaller = true := by decide
def e604583817962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e604583817962 : Closed e604583817962 ∧ code e604583817962 = 2803607073514 := by decide
theorem cert_e604583817962 : check e604583817962 [[],[]] .smaller = true := by decide
def e604583818038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e604583818038 : Closed e604583818038 ∧ code e604583818038 = 2803607073590 := by decide
theorem cert_e604583818038 : check e604583818038 [[],[]] .smaller = true := by decide
def e604583818042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e604583818042 : Closed e604583818042 ∧ code e604583818042 = 2803607073594 := by decide
theorem cert_e604583818042 : check e604583818042 [[],[]] .smaller = true := by decide
def e604583818138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e604583818138 : Closed e604583818138 ∧ code e604583818138 = 2803607073690 := by decide
theorem cert_e604583818138 : check e604583818138 [[],[]] .smaller = true := by decide
def e604583933678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e604583933678 : Closed e604583933678 ∧ code e604583933678 = 2803607189230 := by decide
theorem cert_e604583933678 : check e604583933678 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604583933806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e604583933806 : Closed e604583933806 ∧ code e604583933806 = 2803607189358 := by decide
theorem cert_e604583933806 : check e604583933806 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e604583933814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e604583933814 : Closed e604583933814 ∧ code e604583933814 = 2803607189366 := by decide
theorem cert_e604583933814 : check e604583933814 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604583934702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e604583934702 : Closed e604583934702 ∧ code e604583934702 = 2803607190254 := by decide
theorem cert_e604583934702 : check e604583934702 [[],[]] .sourceHead = true := by decide
def e604583934894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e604583934894 : Closed e604583934894 ∧ code e604583934894 = 2803607190446 := by decide
theorem cert_e604583934894 : check e604583934894 [[],[]] .sourceHead = true := by decide
def e604583934906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e604583934906 : Closed e604583934906 ∧ code e604583934906 = 2803607190458 := by decide
theorem cert_e604583934906 : check e604583934906 [[],[]] .sourceHead = true := by decide
def e604583935342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e604583935342 : Closed e604583935342 ∧ code e604583935342 = 2803607190894 := by decide
theorem cert_e604583935342 : check e604583935342 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604583935350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e604583935350 : Closed e604583935350 ∧ code e604583935350 = 2803607190902 := by decide
theorem cert_e604583935350 : check e604583935350 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604583935406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e604583935406 : Closed e604583935406 ∧ code e604583935406 = 2803607190958 := by decide
theorem cert_e604583935406 : check e604583935406 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604583935418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e604583935418 : Closed e604583935418 ∧ code e604583935418 = 2803607190970 := by decide
theorem cert_e604583935418 : check e604583935418 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604583935446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e604583935446 : Closed e604583935446 ∧ code e604583935446 = 2803607190998 := by decide
theorem cert_e604583935446 : check e604583935446 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604583935450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e604583935450 : Closed e604583935450 ∧ code e604583935450 = 2803607191002 := by decide
theorem cert_e604583935450 : check e604583935450 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604583939822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e604583939822 : Closed e604583939822 ∧ code e604583939822 = 2803607195374 := by decide
theorem cert_e604583939822 : check e604583939822 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604583939950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e604583939950 : Closed e604583939950 ∧ code e604583939950 = 2803607195502 := by decide
theorem cert_e604583939950 : checkPay e604583939950 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] 0 [] = true := by decide
def e604583939958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e604583939958 : Closed e604583939958 ∧ code e604583939958 = 2803607195510 := by decide
theorem cert_e604583939958 : checkPay e604583939958 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604583942638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e604583942638 : Closed e604583942638 ∧ code e604583942638 = 2803607198190 := by decide
theorem cert_e604583942638 : check e604583942638 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604583943406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e604583943406 : Closed e604583943406 ∧ code e604583943406 = 2803607198958 := by decide
theorem cert_e604583943406 : check e604583943406 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604583943414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e604583943414 : Closed e604583943414 ∧ code e604583943414 = 2803607198966 := by decide
theorem cert_e604583943414 : check e604583943414 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left]] .identityHead = true := by decide
def e604583945966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e604583945966 : Closed e604583945966 ∧ code e604583945966 = 2803607201518 := by decide
theorem cert_e604583945966 : checkPay e604583945966 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[]] = true := by decide
def e604583946158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e604583946158 : Closed e604583946158 ∧ code e604583946158 = 2803607201710 := by decide
theorem cert_e604583946158 : checkPay e604583946158 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left]] = true := by decide
def e604583946170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e604583946170 : Closed e604583946170 ∧ code e604583946170 = 2803607201722 := by decide
theorem cert_e604583946170 : checkPay e604583946170 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] = true := by decide
def e604583946734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e604583946734 : Closed e604583946734 ∧ code e604583946734 = 2803607202286 := by decide
theorem cert_e604583946734 : checkPay e604583946734 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604583947886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e604583947886 : Closed e604583947886 ∧ code e604583947886 = 2803607203438 := by decide
theorem cert_e604583947886 : checkPay e604583947886 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e604583947898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e604583947898 : Closed e604583947898 ∧ code e604583947898 = 2803607203450 := by decide
theorem cert_e604583947898 : checkPay e604583947898 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.right]] = true := by decide
def e604583949166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e604583949166 : Closed e604583949166 ∧ code e604583949166 = 2803607204718 := by decide
theorem cert_e604583949166 : check e604583949166 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604583949174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e604583949174 : Closed e604583949174 ∧ code e604583949174 = 2803607204726 := by decide
theorem cert_e604583949174 : check e604583949174 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604583949230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e604583949230 : Closed e604583949230 ∧ code e604583949230 = 2803607204782 := by decide
theorem cert_e604583949230 : check e604583949230 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604583949242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e604583949242 : Closed e604583949242 ∧ code e604583949242 = 2803607204794 := by decide
theorem cert_e604583949242 : check e604583949242 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604583949270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e604583949270 : Closed e604583949270 ∧ code e604583949270 = 2803607204822 := by decide
theorem cert_e604583949270 : check e604583949270 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604583949274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e604583949274 : Closed e604583949274 ∧ code e604583949274 = 2803607204826 := by decide
theorem cert_e604583949274 : check e604583949274 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604583949550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e604583949550 : Closed e604583949550 ∧ code e604583949550 = 2803607205102 := by decide
theorem cert_e604583949550 : check e604583949550 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604583949558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e604583949558 : Closed e604583949558 ∧ code e604583949558 = 2803607205110 := by decide
theorem cert_e604583949558 : check e604583949558 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604583949934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e604583949934 : Closed e604583949934 ∧ code e604583949934 = 2803607205486 := by decide
theorem cert_e604583949934 : check e604583949934 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604583949946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e604583949946 : Closed e604583949946 ∧ code e604583949946 = 2803607205498 := by decide
theorem cert_e604583949946 : check e604583949946 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604583950134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e604583950134 : Closed e604583950134 ∧ code e604583950134 = 2803607205686 := by decide
theorem cert_e604583950134 : check e604583950134 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604583950138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e604583950138 : Closed e604583950138 ∧ code e604583950138 = 2803607205690 := by decide
theorem cert_e604583950138 : check e604583950138 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604583955310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e604583955310 : Closed e604583955310 ∧ code e604583955310 = 2803607210862 := by decide
theorem cert_e604583955310 : check e604583955310 [[],[]] .smaller = true := by decide
def e604583955318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e604583955318 : Closed e604583955318 ∧ code e604583955318 = 2803607210870 := by decide
theorem cert_e604583955318 : check e604583955318 [[],[]] .smaller = true := by decide
def e604583955374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e604583955374 : Closed e604583955374 ∧ code e604583955374 = 2803607210926 := by decide
theorem cert_e604583955374 : check e604583955374 [[],[]] .smaller = true := by decide
def e604583955386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e604583955386 : Closed e604583955386 ∧ code e604583955386 = 2803607210938 := by decide
theorem cert_e604583955386 : check e604583955386 [[],[]] .smaller = true := by decide
def e604583955414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e604583955414 : Closed e604583955414 ∧ code e604583955414 = 2803607210966 := by decide
theorem cert_e604583955414 : check e604583955414 [[],[]] .smaller = true := by decide
def e604583955418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e604583955418 : Closed e604583955418 ∧ code e604583955418 = 2803607210970 := by decide
theorem cert_e604583955418 : check e604583955418 [[],[]] .smaller = true := by decide
def e604583955694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e604583955694 : Closed e604583955694 ∧ code e604583955694 = 2803607211246 := by decide
theorem cert_e604583955694 : check e604583955694 [[],[]] .smaller = true := by decide
def e604583955702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e604583955702 : Closed e604583955702 ∧ code e604583955702 = 2803607211254 := by decide
theorem cert_e604583955702 : check e604583955702 [[],[]] .smaller = true := by decide
def e604583956078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e604583956078 : Closed e604583956078 ∧ code e604583956078 = 2803607211630 := by decide
theorem cert_e604583956078 : check e604583956078 [[],[]] .smaller = true := by decide
def e604583956090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e604583956090 : Closed e604583956090 ∧ code e604583956090 = 2803607211642 := by decide
theorem cert_e604583956090 : check e604583956090 [[],[]] .smaller = true := by decide
def e604583956278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e604583956278 : Closed e604583956278 ∧ code e604583956278 = 2803607211830 := by decide
theorem cert_e604583956278 : check e604583956278 [[],[]] .smaller = true := by decide
def e604583956282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e604583956282 : Closed e604583956282 ∧ code e604583956282 = 2803607211834 := by decide
theorem cert_e604583956282 : check e604583956282 [[],[]] .smaller = true := by decide
def e604583964398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e604583964398 : Closed e604583964398 ∧ code e604583964398 = 2803607219950 := by decide
theorem cert_e604583964398 : check e604583964398 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604583964526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e604583964526 : Closed e604583964526 ∧ code e604583964526 = 2803607220078 := by decide
theorem cert_e604583964526 : checkPay e604583964526 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e604583964534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e604583964534 : Closed e604583964534 ∧ code e604583964534 = 2803607220086 := by decide
theorem cert_e604583964534 : check e604583964534 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e604583967214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e604583967214 : Closed e604583967214 ∧ code e604583967214 = 2803607222766 := by decide
theorem cert_e604583967214 : check e604583967214 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604583967982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e604583967982 : Closed e604583967982 ∧ code e604583967982 = 2803607223534 := by decide
theorem cert_e604583967982 : checkPay e604583967982 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[],[.under,.under,.right]] = true := by decide
def e604583967990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e604583967990 : Closed e604583967990 ∧ code e604583967990 = 2803607223542 := by decide
theorem cert_e604583967990 : check e604583967990 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[],[.left],[]] .identityHead = true := by decide
def e604583991022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e604583991022 : Closed e604583991022 ∧ code e604583991022 = 2803607246574 := by decide
theorem cert_e604583991022 : check e604583991022 [[],[]] .sourceHead = true := by decide
def e604583991214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e604583991214 : Closed e604583991214 ∧ code e604583991214 = 2803607246766 := by decide
theorem cert_e604583991214 : check e604583991214 [[],[]] .sourceHead = true := by decide
def e604583991226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e604583991226 : Closed e604583991226 ∧ code e604583991226 = 2803607246778 := by decide
theorem cert_e604583991226 : check e604583991226 [[],[]] .sourceHead = true := by decide
def e604583991790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e604583991790 : Closed e604583991790 ∧ code e604583991790 = 2803607247342 := by decide
theorem cert_e604583991790 : check e604583991790 [[],[]] .sourceHead = true := by decide
def e604583992942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e604583992942 : Closed e604583992942 ∧ code e604583992942 = 2803607248494 := by decide
theorem cert_e604583992942 : check e604583992942 [[],[]] .sourceHead = true := by decide
def e604583992954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e604583992954 : Closed e604583992954 ∧ code e604583992954 = 2803607248506 := by decide
theorem cert_e604583992954 : check e604583992954 [[],[]] .sourceHead = true := by decide
def e604584004462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604584004462 : Closed e604584004462 ∧ code e604584004462 = 2803607260014 := by decide
theorem cert_e604584004462 : check e604584004462 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604584004470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604584004470 : Closed e604584004470 ∧ code e604584004470 = 2803607260022 := by decide
theorem cert_e604584004470 : check e604584004470 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604584004526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604584004526 : Closed e604584004526 ∧ code e604584004526 = 2803607260078 := by decide
theorem cert_e604584004526 : check e604584004526 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604584004538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604584004538 : Closed e604584004538 ∧ code e604584004538 = 2803607260090 := by decide
theorem cert_e604584004538 : check e604584004538 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604584004566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604584004566 : Closed e604584004566 ∧ code e604584004566 = 2803607260118 := by decide
theorem cert_e604584004566 : check e604584004566 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604584004570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604584004570 : Closed e604584004570 ∧ code e604584004570 = 2803607260122 := by decide
theorem cert_e604584004570 : check e604584004570 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604584004846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604584004846 : Closed e604584004846 ∧ code e604584004846 = 2803607260398 := by decide
theorem cert_e604584004846 : check e604584004846 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604584004854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604584004854 : Closed e604584004854 ∧ code e604584004854 = 2803607260406 := by decide
theorem cert_e604584004854 : check e604584004854 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604584005230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604584005230 : Closed e604584005230 ∧ code e604584005230 = 2803607260782 := by decide
theorem cert_e604584005230 : check e604584005230 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604584005242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604584005242 : Closed e604584005242 ∧ code e604584005242 = 2803607260794 := by decide
theorem cert_e604584005242 : check e604584005242 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604584005430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604584005430 : Closed e604584005430 ∧ code e604584005430 = 2803607260982 := by decide
theorem cert_e604584005430 : check e604584005430 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604584005434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604584005434 : Closed e604584005434 ∧ code e604584005434 = 2803607260986 := by decide
theorem cert_e604584005434 : check e604584005434 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604584545134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e604584545134 : Closed e604584545134 ∧ code e604584545134 = 2803607800686 := by decide
theorem cert_e604584545134 : check e604584545134 [[],[]] .smaller = true := by decide
def e604584545142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e604584545142 : Closed e604584545142 ∧ code e604584545142 = 2803607800694 := by decide
theorem cert_e604584545142 : check e604584545142 [[],[]] .smaller = true := by decide
def e604584545198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e604584545198 : Closed e604584545198 ∧ code e604584545198 = 2803607800750 := by decide
theorem cert_e604584545198 : check e604584545198 [[],[]] .smaller = true := by decide
def e604584545210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e604584545210 : Closed e604584545210 ∧ code e604584545210 = 2803607800762 := by decide
theorem cert_e604584545210 : check e604584545210 [[],[]] .smaller = true := by decide
def e604584545238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e604584545238 : Closed e604584545238 ∧ code e604584545238 = 2803607800790 := by decide
theorem cert_e604584545238 : check e604584545238 [[],[]] .smaller = true := by decide
def e604584545242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e604584545242 : Closed e604584545242 ∧ code e604584545242 = 2803607800794 := by decide
theorem cert_e604584545242 : check e604584545242 [[],[]] .smaller = true := by decide
def e604584545518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e604584545518 : Closed e604584545518 ∧ code e604584545518 = 2803607801070 := by decide
theorem cert_e604584545518 : check e604584545518 [[],[]] .smaller = true := by decide
def e604584545526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e604584545526 : Closed e604584545526 ∧ code e604584545526 = 2803607801078 := by decide
theorem cert_e604584545526 : check e604584545526 [[],[]] .smaller = true := by decide
def e604584545902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e604584545902 : Closed e604584545902 ∧ code e604584545902 = 2803607801454 := by decide
theorem cert_e604584545902 : check e604584545902 [[],[]] .smaller = true := by decide
def e604584545914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e604584545914 : Closed e604584545914 ∧ code e604584545914 = 2803607801466 := by decide
theorem cert_e604584545914 : check e604584545914 [[],[]] .smaller = true := by decide
def e604584546102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e604584546102 : Closed e604584546102 ∧ code e604584546102 = 2803607801654 := by decide
theorem cert_e604584546102 : check e604584546102 [[],[]] .smaller = true := by decide
def e604584546106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e604584546106 : Closed e604584546106 ∧ code e604584546106 = 2803607801658 := by decide
theorem cert_e604584546106 : check e604584546106 [[],[]] .smaller = true := by decide
def e604617399150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e604617399150 : Closed e604617399150 ∧ code e604617399150 = 2803640654702 := by decide
theorem cert_e604617399150 : check e604617399150 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604617399158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e604617399158 : Closed e604617399158 ∧ code e604617399158 = 2803640654710 := by decide
theorem cert_e604617399158 : check e604617399158 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604617399222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e604617399222 : Closed e604617399222 ∧ code e604617399222 = 2803640654774 := by decide
theorem cert_e604617399222 : check e604617399222 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604617399662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e604617399662 : Closed e604617399662 ∧ code e604617399662 = 2803640655214 := by decide
theorem cert_e604617399662 : check e604617399662 [[],[]] .sourceHead = true := by decide
def e604617399670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e604617399670 : Closed e604617399670 ∧ code e604617399670 = 2803640655222 := by decide
theorem cert_e604617399670 : check e604617399670 [[],[]] .sourceHead = true := by decide
def e604617399726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e604617399726 : Closed e604617399726 ∧ code e604617399726 = 2803640655278 := by decide
theorem cert_e604617399726 : check e604617399726 [[],[]] .sourceHead = true := by decide
def e604617399738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e604617399738 : Closed e604617399738 ∧ code e604617399738 = 2803640655290 := by decide
theorem cert_e604617399738 : check e604617399738 [[],[]] .sourceHead = true := by decide
def e604617399766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e604617399766 : Closed e604617399766 ∧ code e604617399766 = 2803640655318 := by decide
theorem cert_e604617399766 : check e604617399766 [[],[]] .sourceHead = true := by decide
def e604617399770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e604617399770 : Closed e604617399770 ∧ code e604617399770 = 2803640655322 := by decide
theorem cert_e604617399770 : check e604617399770 [[],[]] .sourceHead = true := by decide
def e604617399990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e604617399990 : Closed e604617399990 ∧ code e604617399990 = 2803640655542 := by decide
theorem cert_e604617399990 : check e604617399990 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604617400022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e604617400022 : Closed e604617400022 ∧ code e604617400022 = 2803640655574 := by decide
theorem cert_e604617400022 : check e604617400022 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604617400026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e604617400026 : Closed e604617400026 ∧ code e604617400026 = 2803640655578 := by decide
theorem cert_e604617400026 : check e604617400026 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604617402222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e604617402222 : Closed e604617402222 ∧ code e604617402222 = 2803640657774 := by decide
theorem cert_e604617402222 : check e604617402222 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604617402230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e604617402230 : Closed e604617402230 ∧ code e604617402230 = 2803640657782 := by decide
theorem cert_e604617402230 : check e604617402230 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604617402294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e604617402294 : Closed e604617402294 ∧ code e604617402294 = 2803640657846 := by decide
theorem cert_e604617402294 : check e604617402294 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604617403630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e604617403630 : Closed e604617403630 ∧ code e604617403630 = 2803640659182 := by decide
theorem cert_e604617403630 : check e604617403630 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604617403638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e604617403638 : Closed e604617403638 ∧ code e604617403638 = 2803640659190 := by decide
theorem cert_e604617403638 : check e604617403638 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604617404022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e604617404022 : Closed e604617404022 ∧ code e604617404022 = 2803640659574 := by decide
theorem cert_e604617404022 : check e604617404022 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604617405294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e604617405294 : Closed e604617405294 ∧ code e604617405294 = 2803640660846 := by decide
theorem cert_e604617405294 : checkPay e604617405294 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e604617405302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e604617405302 : Closed e604617405302 ∧ code e604617405302 = 2803640660854 := by decide
theorem cert_e604617405302 : checkPay e604617405302 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[]] = true := by decide
def e604617405358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e604617405358 : Closed e604617405358 ∧ code e604617405358 = 2803640660910 := by decide
theorem cert_e604617405358 : checkPay e604617405358 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604617405370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e604617405370 : Closed e604617405370 ∧ code e604617405370 = 2803640660922 := by decide
theorem cert_e604617405370 : checkPay e604617405370 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e604617405398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e604617405398 : Closed e604617405398 ∧ code e604617405398 = 2803640660950 := by decide
theorem cert_e604617405398 : checkPay e604617405398 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] = true := by decide
def e604617405402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e604617405402 : Closed e604617405402 ∧ code e604617405402 = 2803640660954 := by decide
theorem cert_e604617405402 : checkPay e604617405402 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.right]] = true := by decide
def e604617405678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e604617405678 : Closed e604617405678 ∧ code e604617405678 = 2803640661230 := by decide
theorem cert_e604617405678 : checkPay e604617405678 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604617405686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e604617405686 : Closed e604617405686 ∧ code e604617405686 = 2803640661238 := by decide
theorem cert_e604617405686 : checkPay e604617405686 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604617406062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e604617406062 : Closed e604617406062 ∧ code e604617406062 = 2803640661614 := by decide
theorem cert_e604617406062 : checkPay e604617406062 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604617406074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e604617406074 : Closed e604617406074 ∧ code e604617406074 = 2803640661626 := by decide
theorem cert_e604617406074 : checkPay e604617406074 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604617406262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e604617406262 : Closed e604617406262 ∧ code e604617406262 = 2803640661814 := by decide
theorem cert_e604617406262 : checkPay e604617406262 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e604617406266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e604617406266 : Closed e604617406266 ∧ code e604617406266 = 2803640661818 := by decide
theorem cert_e604617406266 : checkPay e604617406266 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e604617406902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e604617406902 : Closed e604617406902 ∧ code e604617406902 = 2803640662454 := by decide
theorem cert_e604617406902 : check e604617406902 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604617406934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e604617406934 : Closed e604617406934 ∧ code e604617406934 = 2803640662486 := by decide
theorem cert_e604617406934 : check e604617406934 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604617406938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e604617406938 : Closed e604617406938 ∧ code e604617406938 = 2803640662490 := by decide
theorem cert_e604617406938 : check e604617406938 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604617407094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e604617407094 : Closed e604617407094 ∧ code e604617407094 = 2803640662646 := by decide
theorem cert_e604617407094 : check e604617407094 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604617407286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e604617407286 : Closed e604617407286 ∧ code e604617407286 = 2803640662838 := by decide
theorem cert_e604617407286 : check e604617407286 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604617407290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e604617407290 : Closed e604617407290 ∧ code e604617407290 = 2803640662842 := by decide
theorem cert_e604617407290 : check e604617407290 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
end Blc.Floor41
