import CodeBridge
import Batch043
namespace Certgen.R598345584438
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 7,.lam 2,.app 3 6,.app 4 5,.var 0,.var 0,.var 0,.lam 8,.lam 9,.app 10 13,.app 11 12,.var 0,.var 0,.lam 14,.app 15 16,.var 2,.app 17 18,.var 0,.var 1]
def values : Array (List AClo) := #[[⟨7,[]⟩],[⟨12,[3,2]⟩,⟨16,[1,3,2]⟩,⟨18,[1,3,2]⟩],[⟨5,[0]⟩,⟨12,[3,2]⟩,⟨16,[1,3,2]⟩,⟨18,[1,3,2]⟩],[⟨6,[0]⟩,⟨12,[3,2]⟩,⟨13,[3,2]⟩,⟨16,[1,3,2]⟩,⟨18,[1,3,2]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨7,[]⟩,0⟩],[⟨⟨12,[3,2]⟩,7⟩],[⟨⟨16,[1,3,2]⟩,2⟩,⟨⟨16,[1,3,2]⟩,3⟩,⟨⟨16,[1,3,2]⟩,4⟩,⟨⟨16,[1,3,2]⟩,7⟩],[⟨⟨18,[1,3,2]⟩,2⟩,⟨⟨18,[1,3,2]⟩,3⟩,⟨⟨18,[1,3,2]⟩,4⟩],[⟨⟨6,[0]⟩,0⟩],[⟨⟨5,[0]⟩,5⟩],[⟨⟨13,[3,2]⟩,0⟩,⟨⟨13,[3,2]⟩,2⟩,⟨⟨13,[3,2]⟩,3⟩,⟨⟨13,[3,2]⟩,4⟩,⟨⟨13,[3,2]⟩,7⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[0]⟩,0⟩,⟨⟨3,[0]⟩,5⟩,⟨⟨4,[0]⟩,6⟩,⟨⟨5,[0]⟩,3⟩,⟨⟨6,[0]⟩,2⟩,⟨⟨6,[0]⟩,3⟩,⟨⟨6,[0]⟩,4⟩,⟨⟨7,[]⟩,2⟩,⟨⟨7,[]⟩,3⟩,⟨⟨7,[]⟩,4⟩,⟨⟨7,[]⟩,6⟩,⟨⟨8,[2]⟩,2⟩,⟨⟨8,[2]⟩,3⟩,⟨⟨8,[2]⟩,4⟩,⟨⟨8,[2]⟩,5⟩,⟨⟨8,[2]⟩,7⟩,⟨⟨9,[3,2]⟩,0⟩,⟨⟨9,[3,2]⟩,2⟩,⟨⟨9,[3,2]⟩,3⟩,⟨⟨9,[3,2]⟩,4⟩,⟨⟨9,[3,2]⟩,7⟩,⟨⟨10,[3,2]⟩,7⟩,⟨⟨11,[3,2]⟩,2⟩,⟨⟨12,[3,2]⟩,2⟩,⟨⟨12,[3,2]⟩,3⟩,⟨⟨12,[3,2]⟩,4⟩,⟨⟨13,[3,2]⟩,2⟩,⟨⟨13,[3,2]⟩,3⟩,⟨⟨13,[3,2]⟩,4⟩,⟨⟨14,[1,3,2]⟩,2⟩,⟨⟨14,[1,3,2]⟩,3⟩,⟨⟨14,[1,3,2]⟩,4⟩,⟨⟨14,[1,3,2]⟩,7⟩,⟨⟨15,[1,3,2]⟩,3⟩,⟨⟨16,[1,3,2]⟩,2⟩,⟨⟨16,[1,3,2]⟩,3⟩,⟨⟨16,[1,3,2]⟩,4⟩,⟨⟨17,[1,3,2]⟩,4⟩,⟨⟨18,[1,3,2]⟩,2⟩,⟨⟨18,[1,3,2]⟩,3⟩,⟨⟨18,[1,3,2]⟩,4⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[4],[12],[10],[9],[10],[11],[17],[13,14,15,17],[13,14,15],[16],[22],[19,20,21,22],[19,20,21],[18],[18,19,20,21,22],[23],[23],[23],[23],[23],[24],[6,25,28,36,40],[6,25,28,36,40],[7,26,29,37,41],[8,27,30,38,42],[34],[31,32,33,34],[31,32,33],[35],[35],[35],[35],[5,26,37,41],[39],[39],[39],[27,38,42],[6,25,28,36,40],[7,26,29,37,41],[8,27,30,38,42]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem block24 : checkRange P V K states hints 24 12=true := by decide
theorem block36 : checkRange P V K states hints 36 7=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<43 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 by_cases h12 : i<24
 · exact range_sound block12 i (by omega) h12 hi
 by_cases h24 : i<36
 · exact range_sound block24 i (by omega) h24 hi
 exact range_sound block36 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Floor41 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit17 : Term := .var 0
def lit18 : Term := .var 1
def lit15 : Term := .var 2
def lit10 : Term := .app lit17 lit17
def lit16 : Term := .app lit17 lit18
def lit2 : Term := .app lit10 lit17
def lit1 : Term := .lam lit2
def lit14 : Term := .app lit15 lit16
def lit13 : Term := .lam lit14
def lit9 : Term := .app lit10 lit13
def lit8 : Term := .lam lit9
def lit7 : Term := .lam lit8
def lit0 : Term := .app lit1 lit7
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub18 : model.term 18 = lit18 := model.var_eq 18 1 (by rfl)
theorem sub17 : model.term 17 = lit17 := model.var_eq 17 0 (by rfl)
theorem sub16 : model.term 16 = lit16 := by rw [model.app_eq 16 17 18 (by rfl), sub17, sub18]; rfl
theorem sub15 : model.term 15 = lit15 := model.var_eq 15 2 (by rfl)
theorem sub14 : model.term 14 = lit14 := by rw [model.app_eq 14 15 16 (by rfl), sub15, sub16]; rfl
theorem sub13 : model.term 13 = lit13 := by rw [model.lam_eq 13 14 (by rfl), sub14]; rfl
theorem sub12 : model.term 12 = lit17 := model.var_eq 12 0 (by rfl)
theorem sub11 : model.term 11 = lit17 := model.var_eq 11 0 (by rfl)
theorem sub10 : model.term 10 = lit10 := by rw [model.app_eq 10 11 12 (by rfl), sub11, sub12]; rfl
theorem sub9 : model.term 9 = lit9 := by rw [model.app_eq 9 10 13 (by rfl), sub10, sub13]; rfl
theorem sub8 : model.term 8 = lit8 := by rw [model.lam_eq 8 9 (by rfl), sub9]; rfl
theorem sub7 : model.term 7 = lit7 := by rw [model.lam_eq 7 8 (by rfl), sub8]; rfl
theorem sub6 : model.term 6 = lit17 := model.var_eq 6 0 (by rfl)
theorem sub5 : model.term 5 = lit17 := model.var_eq 5 0 (by rfl)
theorem sub4 : model.term 4 = lit17 := model.var_eq 4 0 (by rfl)
theorem sub3 : model.term 3 = lit10 := by rw [model.app_eq 3 4 5 (by rfl), sub4, sub5]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 6 (by rfl), sub3, sub6]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.lam_eq 1 2 (by rfl), sub2]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 7 (by rfl), sub1, sub7]; rfl
theorem excluded : ¬ IsSelfInterpreter e598345584438 := by
 intro he
 have hp : replay [] e598345584438 = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (rawCount he) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R598345584438
