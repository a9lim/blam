import R597890436918Data
namespace Certgen.R597890436918
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl2376 : FloorIndex.rangeOK validState 2376 11 = true := by decide +kernel
end Certgen.R597890436918
