import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605601652106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e605601652106 : Closed e605601652106 ∧ code e605601652106 = 2804624907658 := by decide
private def t_e605601652106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem cert_e605601652106 : ¬ IsSelfInterpreter e605601652106 :=
  wSource (t := t_e605601652106) (replay_sound (ps := []) (t := e605601652106) (by decide)) (by decide)
def e605601652130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e605601652130 : Closed e605601652130 ∧ code e605601652130 = 2804624907682 := by decide
private def t_e605601652130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem cert_e605601652130 : ¬ IsSelfInterpreter e605601652130 :=
  wSource (t := t_e605601652130) (replay_sound (ps := []) (t := e605601652130) (by decide)) (by decide)
def e605601652142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e605601652142 : Closed e605601652142 ∧ code e605601652142 = 2804624907694 := by decide
private def t_e605601652142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 2))))))
theorem cert_e605601652142 : ¬ IsSelfInterpreter e605601652142 :=
  wSource (t := t_e605601652142) (replay_sound (ps := []) (t := e605601652142) (by decide)) (by decide)
def e605601652154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e605601652154 : Closed e605601652154 ∧ code e605601652154 = 2804624907706 := by decide
private def t_e605601652154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 2)) (.var 0))))))
theorem cert_e605601652154 : ¬ IsSelfInterpreter e605601652154 :=
  wSource (t := t_e605601652154) (replay_sound (ps := []) (t := e605601652154) (by decide)) (by decide)
def e605601652182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e605601652182 : Closed e605601652182 ∧ code e605601652182 = 2804624907734 := by decide
private def t_e605601652182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e605601652182 : ¬ IsSelfInterpreter e605601652182 :=
  wSource (t := t_e605601652182) (replay_sound (ps := []) (t := e605601652182) (by decide)) (by decide)
def e605601652186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e605601652186 : Closed e605601652186 ∧ code e605601652186 = 2804624907738 := by decide
private def t_e605601652186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e605601652186 : ¬ IsSelfInterpreter e605601652186 :=
  wSource (t := t_e605601652186) (replay_sound (ps := []) (t := e605601652186) (by decide)) (by decide)
def e605601664366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e605601664366 : Closed e605601664366 ∧ code e605601664366 = 2804624919918 := by decide
theorem cert_e605601664366 : check e605601664366 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605601664374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e605601664374 : Closed e605601664374 ∧ code e605601664374 = 2804624919926 := by decide
theorem cert_e605601664374 : checkPay e605601664374 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e605601665902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e605601665902 : Closed e605601665902 ∧ code e605601665902 = 2804624921454 := by decide
theorem cert_e605601665902 : check e605601665902 [[],[]] .chain = true := by decide
def e605601665910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e605601665910 : Closed e605601665910 ∧ code e605601665910 = 2804624921462 := by decide
theorem cert_e605601665910 : check e605601665910 [[],[]] .chain = true := by decide
def e605601665966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e605601665966 : Closed e605601665966 ∧ code e605601665966 = 2804624921518 := by decide
theorem cert_e605601665966 : check e605601665966 [[],[]] .chain = true := by decide
def e605601665978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e605601665978 : Closed e605601665978 ∧ code e605601665978 = 2804624921530 := by decide
theorem cert_e605601665978 : check e605601665978 [[],[]] .chain = true := by decide
def e605601666006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e605601666006 : Closed e605601666006 ∧ code e605601666006 = 2804624921558 := by decide
theorem cert_e605601666006 : check e605601666006 [[],[]] .chain = true := by decide
def e605601666010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e605601666010 : Closed e605601666010 ∧ code e605601666010 = 2804624921562 := by decide
theorem cert_e605601666010 : check e605601666010 [[],[]] .chain = true := by decide
def e605601666286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e605601666286 : Closed e605601666286 ∧ code e605601666286 = 2804624921838 := by decide
theorem cert_e605601666286 : check e605601666286 [[],[]] .chain = true := by decide
def e605601666294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e605601666294 : Closed e605601666294 ∧ code e605601666294 = 2804624921846 := by decide
theorem cert_e605601666294 : check e605601666294 [[],[]] .chain = true := by decide
def e605601666670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601666670 : Closed e605601666670 ∧ code e605601666670 = 2804624922222 := by decide
theorem cert_e605601666670 : check e605601666670 [[],[]] .chain = true := by decide
def e605601666682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601666682 : Closed e605601666682 ∧ code e605601666682 = 2804624922234 := by decide
theorem cert_e605601666682 : check e605601666682 [[],[]] .chain = true := by decide
def e605601666870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601666870 : Closed e605601666870 ∧ code e605601666870 = 2804624922422 := by decide
theorem cert_e605601666870 : check e605601666870 [[],[]] .chain = true := by decide
def e605601666874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601666874 : Closed e605601666874 ∧ code e605601666874 = 2804624922426 := by decide
theorem cert_e605601666874 : check e605601666874 [[],[]] .chain = true := by decide
def e605601668846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.var 2))))))
theorem wire_e605601668846 : Closed e605601668846 ∧ code e605601668846 = 2804624924398 := by decide
theorem cert_e605601668846 : checkPay e605601668846 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e605601668974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.var 2))))))
theorem wire_e605601668974 : Closed e605601668974 ∧ code e605601668974 = 2804624924526 := by decide
theorem cert_e605601668974 : check e605601668974 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601668982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 2)) (.var 1))))))
theorem wire_e605601668982 : Closed e605601668982 ∧ code e605601668982 = 2804624924534 := by decide
theorem cert_e605601668982 : check e605601668982 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601675118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e605601675118 : Closed e605601675118 ∧ code e605601675118 = 2804624930670 := by decide
theorem cert_e605601675118 : check e605601675118 [[],[]] .chain = true := by decide
def e605601675126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e605601675126 : Closed e605601675126 ∧ code e605601675126 = 2804624930678 := by decide
theorem cert_e605601675126 : check e605601675126 [[],[]] .chain = true := by decide
def e605601675190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)) (.var 1))))))
theorem wire_e605601675190 : Closed e605601675190 ∧ code e605601675190 = 2804624930742 := by decide
theorem cert_e605601675190 : check e605601675190 [[],[]] .chain = true := by decide
def e605601676142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e605601676142 : Closed e605601676142 ∧ code e605601676142 = 2804624931694 := by decide
theorem cert_e605601676142 : check e605601676142 [[],[]] .chain = true := by decide
def e605601676150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e605601676150 : Closed e605601676150 ∧ code e605601676150 = 2804624931702 := by decide
theorem cert_e605601676150 : check e605601676150 [[],[]] .chain = true := by decide
def e605601676206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e605601676206 : Closed e605601676206 ∧ code e605601676206 = 2804624931758 := by decide
theorem cert_e605601676206 : check e605601676206 [[],[]] .chain = true := by decide
def e605601676218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e605601676218 : Closed e605601676218 ∧ code e605601676218 = 2804624931770 := by decide
theorem cert_e605601676218 : check e605601676218 [[],[]] .chain = true := by decide
def e605601676246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e605601676246 : Closed e605601676246 ∧ code e605601676246 = 2804624931798 := by decide
theorem cert_e605601676246 : check e605601676246 [[],[]] .chain = true := by decide
def e605601676250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e605601676250 : Closed e605601676250 ∧ code e605601676250 = 2804624931802 := by decide
theorem cert_e605601676250 : check e605601676250 [[],[]] .chain = true := by decide
def e605601676654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e605601676654 : Closed e605601676654 ∧ code e605601676654 = 2804624932206 := by decide
theorem cert_e605601676654 : check e605601676654 [[],[]] .chain = true := by decide
def e605601676662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e605601676662 : Closed e605601676662 ∧ code e605601676662 = 2804624932214 := by decide
theorem cert_e605601676662 : check e605601676662 [[],[]] .chain = true := by decide
def e605601676718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e605601676718 : Closed e605601676718 ∧ code e605601676718 = 2804624932270 := by decide
theorem cert_e605601676718 : check e605601676718 [[],[]] .chain = true := by decide
def e605601676730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e605601676730 : Closed e605601676730 ∧ code e605601676730 = 2804624932282 := by decide
theorem cert_e605601676730 : check e605601676730 [[],[]] .chain = true := by decide
def e605601676778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e605601676778 : Closed e605601676778 ∧ code e605601676778 = 2804624932330 := by decide
theorem cert_e605601676778 : check e605601676778 [[],[]] .chain = true := by decide
def e605601676982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e605601676982 : Closed e605601676982 ∧ code e605601676982 = 2804624932534 := by decide
theorem cert_e605601676982 : check e605601676982 [[],[]] .chain = true := by decide
def e605601677014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e605601677014 : Closed e605601677014 ∧ code e605601677014 = 2804624932566 := by decide
theorem cert_e605601677014 : check e605601677014 [[],[]] .chain = true := by decide
def e605601677018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e605601677018 : Closed e605601677018 ∧ code e605601677018 = 2804624932570 := by decide
theorem cert_e605601677018 : check e605601677018 [[],[]] .chain = true := by decide
def e605601677034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e605601677034 : Closed e605601677034 ∧ code e605601677034 = 2804624932586 := by decide
theorem cert_e605601677034 : check e605601677034 [[],[]] .chain = true := by decide
def e605601681134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e605601681134 : Closed e605601681134 ∧ code e605601681134 = 2804624936686 := by decide
theorem cert_e605601681134 : check e605601681134 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605601681262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e605601681262 : Closed e605601681262 ∧ code e605601681262 = 2804624936814 := by decide
theorem cert_e605601681262 : check e605601681262 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605601681270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e605601681270 : Closed e605601681270 ∧ code e605601681270 = 2804624936822 := by decide
theorem cert_e605601681270 : checkPay e605601681270 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605601683950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e605601683950 : Closed e605601683950 ∧ code e605601683950 = 2804624939502 := by decide
theorem cert_e605601683950 : check e605601683950 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e605601684718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e605601684718 : Closed e605601684718 ∧ code e605601684718 = 2804624940270 := by decide
theorem cert_e605601684718 : check e605601684718 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601684726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e605601684726 : Closed e605601684726 ∧ code e605601684726 = 2804624940278 := by decide
theorem cert_e605601684726 : check e605601684726 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605601687406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e605601687406 : Closed e605601687406 ∧ code e605601687406 = 2804624942958 := by decide
theorem cert_e605601687406 : check e605601687406 [[],[]] .chain = true := by decide
def e605601687414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e605601687414 : Closed e605601687414 ∧ code e605601687414 = 2804624942966 := by decide
theorem cert_e605601687414 : check e605601687414 [[],[]] .chain = true := by decide
def e605601687478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e605601687478 : Closed e605601687478 ∧ code e605601687478 = 2804624943030 := by decide
theorem cert_e605601687478 : check e605601687478 [[],[]] .chain = true := by decide
def e605601688814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e605601688814 : Closed e605601688814 ∧ code e605601688814 = 2804624944366 := by decide
theorem cert_e605601688814 : check e605601688814 [[],[]] .chain = true := by decide
def e605601688822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e605601688822 : Closed e605601688822 ∧ code e605601688822 = 2804624944374 := by decide
theorem cert_e605601688822 : check e605601688822 [[],[]] .chain = true := by decide
def e605601689206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e605601689206 : Closed e605601689206 ∧ code e605601689206 = 2804624944758 := by decide
theorem cert_e605601689206 : check e605601689206 [[],[]] .chain = true := by decide
def e605601690094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.var 2))))))
theorem wire_e605601690094 : Closed e605601690094 ∧ code e605601690094 = 2804624945646 := by decide
theorem cert_e605601690094 : check e605601690094 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e605601690478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e605601690478 : Closed e605601690478 ∧ code e605601690478 = 2804624946030 := by decide
theorem cert_e605601690478 : check e605601690478 [[],[]] .chain = true := by decide
def e605601690486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e605601690486 : Closed e605601690486 ∧ code e605601690486 = 2804624946038 := by decide
theorem cert_e605601690486 : check e605601690486 [[],[]] .chain = true := by decide
def e605601690542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e605601690542 : Closed e605601690542 ∧ code e605601690542 = 2804624946094 := by decide
theorem cert_e605601690542 : check e605601690542 [[],[]] .chain = true := by decide
def e605601690554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e605601690554 : Closed e605601690554 ∧ code e605601690554 = 2804624946106 := by decide
theorem cert_e605601690554 : check e605601690554 [[],[]] .chain = true := by decide
def e605601690582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e605601690582 : Closed e605601690582 ∧ code e605601690582 = 2804624946134 := by decide
theorem cert_e605601690582 : check e605601690582 [[],[]] .chain = true := by decide
def e605601690586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e605601690586 : Closed e605601690586 ∧ code e605601690586 = 2804624946138 := by decide
theorem cert_e605601690586 : check e605601690586 [[],[]] .chain = true := by decide
def e605601690862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e605601690862 : Closed e605601690862 ∧ code e605601690862 = 2804624946414 := by decide
theorem cert_e605601690862 : check e605601690862 [[],[]] .chain = true := by decide
def e605601690870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e605601690870 : Closed e605601690870 ∧ code e605601690870 = 2804624946422 := by decide
theorem cert_e605601690870 : check e605601690870 [[],[]] .chain = true := by decide
def e605601691246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601691246 : Closed e605601691246 ∧ code e605601691246 = 2804624946798 := by decide
theorem cert_e605601691246 : check e605601691246 [[],[]] .chain = true := by decide
def e605601691258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601691258 : Closed e605601691258 ∧ code e605601691258 = 2804624946810 := by decide
theorem cert_e605601691258 : check e605601691258 [[],[]] .chain = true := by decide
def e605601691422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 3)))))))
theorem wire_e605601691422 : Closed e605601691422 ∧ code e605601691422 = 2804624946974 := by decide
theorem cert_e605601691422 : check e605601691422 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e605601691446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601691446 : Closed e605601691446 ∧ code e605601691446 = 2804624946998 := by decide
theorem cert_e605601691446 : check e605601691446 [[],[]] .chain = true := by decide
def e605601691450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601691450 : Closed e605601691450 ∧ code e605601691450 = 2804624947002 := by decide
theorem cert_e605601691450 : check e605601691450 [[],[]] .chain = true := by decide
def e605601691886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.var 2))))))
theorem wire_e605601691886 : Closed e605601691886 ∧ code e605601691886 = 2804624947438 := by decide
theorem cert_e605601691886 : check e605601691886 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601691894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 3))) (.var 1))))))
theorem wire_e605601691894 : Closed e605601691894 ∧ code e605601691894 = 2804624947446 := by decide
theorem cert_e605601691894 : check e605601691894 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601692086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e605601692086 : Closed e605601692086 ∧ code e605601692086 = 2804624947638 := by decide
theorem cert_e605601692086 : check e605601692086 [[],[]] .chain = true := by decide
def e605601692118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e605601692118 : Closed e605601692118 ∧ code e605601692118 = 2804624947670 := by decide
theorem cert_e605601692118 : check e605601692118 [[],[]] .chain = true := by decide
def e605601692122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e605601692122 : Closed e605601692122 ∧ code e605601692122 = 2804624947674 := by decide
theorem cert_e605601692122 : check e605601692122 [[],[]] .chain = true := by decide
def e605601692278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e605601692278 : Closed e605601692278 ∧ code e605601692278 = 2804624947830 := by decide
theorem cert_e605601692278 : check e605601692278 [[],[]] .chain = true := by decide
def e605601692446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e605601692446 : Closed e605601692446 ∧ code e605601692446 = 2804624947998 := by decide
theorem cert_e605601692446 : check e605601692446 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601692470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601692470 : Closed e605601692470 ∧ code e605601692470 = 2804624948022 := by decide
theorem cert_e605601692470 : check e605601692470 [[],[]] .chain = true := by decide
def e605601692474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601692474 : Closed e605601692474 ∧ code e605601692474 = 2804624948026 := by decide
theorem cert_e605601692474 : check e605601692474 [[],[]] .chain = true := by decide
def e605601692558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e605601692558 : Closed e605601692558 ∧ code e605601692558 = 2804624948110 := by decide
theorem cert_e605601692558 : checkPay e605601692558 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] 0 [] = true := by decide
def e605601707374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e605601707374 : Closed e605601707374 ∧ code e605601707374 = 2804624962926 := by decide
theorem cert_e605601707374 : check e605601707374 [[],[]] .chain = true := by decide
def e605601707382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e605601707382 : Closed e605601707382 ∧ code e605601707382 = 2804624962934 := by decide
theorem cert_e605601707382 : check e605601707382 [[],[]] .chain = true := by decide
def e605601707438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e605601707438 : Closed e605601707438 ∧ code e605601707438 = 2804624962990 := by decide
theorem cert_e605601707438 : check e605601707438 [[],[]] .chain = true := by decide
def e605601707450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e605601707450 : Closed e605601707450 ∧ code e605601707450 = 2804624963002 := by decide
theorem cert_e605601707450 : check e605601707450 [[],[]] .chain = true := by decide
def e605601707478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e605601707478 : Closed e605601707478 ∧ code e605601707478 = 2804624963030 := by decide
theorem cert_e605601707478 : check e605601707478 [[],[]] .chain = true := by decide
def e605601707482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e605601707482 : Closed e605601707482 ∧ code e605601707482 = 2804624963034 := by decide
theorem cert_e605601707482 : check e605601707482 [[],[]] .chain = true := by decide
def e605601707694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e605601707694 : Closed e605601707694 ∧ code e605601707694 = 2804624963246 := by decide
theorem cert_e605601707694 : check e605601707694 [[],[]] .chain = true := by decide
def e605601707706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e605601707706 : Closed e605601707706 ∧ code e605601707706 = 2804624963258 := by decide
theorem cert_e605601707706 : check e605601707706 [[],[]] .chain = true := by decide
def e605601707754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e605601707754 : Closed e605601707754 ∧ code e605601707754 = 2804624963306 := by decide
theorem cert_e605601707754 : check e605601707754 [[],[]] .chain = true := by decide
def e605601707862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e605601707862 : Closed e605601707862 ∧ code e605601707862 = 2804624963414 := by decide
theorem cert_e605601707862 : check e605601707862 [[],[]] .chain = true := by decide
def e605601707866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e605601707866 : Closed e605601707866 ∧ code e605601707866 = 2804624963418 := by decide
theorem cert_e605601707866 : check e605601707866 [[],[]] .chain = true := by decide
def e605601707882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e605601707882 : Closed e605601707882 ∧ code e605601707882 = 2804624963434 := by decide
theorem cert_e605601707882 : check e605601707882 [[],[]] .chain = true := by decide
def e605601708718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e605601708718 : Closed e605601708718 ∧ code e605601708718 = 2804624964270 := by decide
theorem cert_e605601708718 : check e605601708718 [[],[]] .chain = true := by decide
def e605601708730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e605601708730 : Closed e605601708730 ∧ code e605601708730 = 2804624964282 := by decide
theorem cert_e605601708730 : check e605601708730 [[],[]] .chain = true := by decide
def e605601708778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e605601708778 : Closed e605601708778 ∧ code e605601708778 = 2804624964330 := by decide
theorem cert_e605601708778 : check e605601708778 [[],[]] .chain = true := by decide
def e605601708970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e605601708970 : Closed e605601708970 ∧ code e605601708970 = 2804624964522 := by decide
theorem cert_e605601708970 : check e605601708970 [[],[]] .chain = true := by decide
def e605601709398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e605601709398 : Closed e605601709398 ∧ code e605601709398 = 2804624964950 := by decide
theorem cert_e605601709398 : check e605601709398 [[],[]] .chain = true := by decide
def e605601709402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e605601709402 : Closed e605601709402 ∧ code e605601709402 = 2804624964954 := by decide
theorem cert_e605601709402 : check e605601709402 [[],[]] .chain = true := by decide
def e605601709418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e605601709418 : Closed e605601709418 ∧ code e605601709418 = 2804624964970 := by decide
theorem cert_e605601709418 : check e605601709418 [[],[]] .chain = true := by decide
def e605601709482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e605601709482 : Closed e605601709482 ∧ code e605601709482 = 2804624965034 := by decide
theorem cert_e605601709482 : check e605601709482 [[],[]] .chain = true := by decide
def e605601710446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e605601710446 : Closed e605601710446 ∧ code e605601710446 = 2804624965998 := by decide
theorem cert_e605601710446 : check e605601710446 [[],[]] .chain = true := by decide
def e605601710454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e605601710454 : Closed e605601710454 ∧ code e605601710454 = 2804624966006 := by decide
theorem cert_e605601710454 : check e605601710454 [[],[]] .chain = true := by decide
def e605601711982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e605601711982 : Closed e605601711982 ∧ code e605601711982 = 2804624967534 := by decide
theorem cert_e605601711982 : check e605601711982 [[],[]] .chain = true := by decide
def e605601711990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e605601711990 : Closed e605601711990 ∧ code e605601711990 = 2804624967542 := by decide
theorem cert_e605601711990 : check e605601711990 [[],[]] .chain = true := by decide
def e605601712054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.var 1))))))
theorem wire_e605601712054 : Closed e605601712054 ∧ code e605601712054 = 2804624967606 := by decide
theorem cert_e605601712054 : check e605601712054 [[],[]] .chain = true := by decide
def e605601713518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e605601713518 : Closed e605601713518 ∧ code e605601713518 = 2804624969070 := by decide
theorem cert_e605601713518 : check e605601713518 [[],[]] .chain = true := by decide
def e605601713526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e605601713526 : Closed e605601713526 ∧ code e605601713526 = 2804624969078 := by decide
theorem cert_e605601713526 : check e605601713526 [[],[]] .chain = true := by decide
def e605601713582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e605601713582 : Closed e605601713582 ∧ code e605601713582 = 2804624969134 := by decide
theorem cert_e605601713582 : check e605601713582 [[],[]] .chain = true := by decide
def e605601713594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e605601713594 : Closed e605601713594 ∧ code e605601713594 = 2804624969146 := by decide
theorem cert_e605601713594 : check e605601713594 [[],[]] .chain = true := by decide
def e605601713622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e605601713622 : Closed e605601713622 ∧ code e605601713622 = 2804624969174 := by decide
theorem cert_e605601713622 : check e605601713622 [[],[]] .chain = true := by decide
def e605601713626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e605601713626 : Closed e605601713626 ∧ code e605601713626 = 2804624969178 := by decide
theorem cert_e605601713626 : check e605601713626 [[],[]] .chain = true := by decide
def e605601713838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e605601713838 : Closed e605601713838 ∧ code e605601713838 = 2804624969390 := by decide
theorem cert_e605601713838 : check e605601713838 [[],[]] .chain = true := by decide
def e605601713850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e605601713850 : Closed e605601713850 ∧ code e605601713850 = 2804624969402 := by decide
theorem cert_e605601713850 : check e605601713850 [[],[]] .chain = true := by decide
def e605601713898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e605601713898 : Closed e605601713898 ∧ code e605601713898 = 2804624969450 := by decide
theorem cert_e605601713898 : check e605601713898 [[],[]] .chain = true := by decide
def e605601714006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e605601714006 : Closed e605601714006 ∧ code e605601714006 = 2804624969558 := by decide
theorem cert_e605601714006 : check e605601714006 [[],[]] .chain = true := by decide
def e605601714010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e605601714010 : Closed e605601714010 ∧ code e605601714010 = 2804624969562 := by decide
theorem cert_e605601714010 : check e605601714010 [[],[]] .chain = true := by decide
def e605601714026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e605601714026 : Closed e605601714026 ∧ code e605601714026 = 2804624969578 := by decide
theorem cert_e605601714026 : check e605601714026 [[],[]] .chain = true := by decide
def e605601715054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e605601715054 : Closed e605601715054 ∧ code e605601715054 = 2804624970606 := by decide
theorem cert_e605601715054 : check e605601715054 [[],[]] .chain = true := by decide
def e605601715062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e605601715062 : Closed e605601715062 ∧ code e605601715062 = 2804624970614 := by decide
theorem cert_e605601715062 : check e605601715062 [[],[]] .chain = true := by decide
def e605601715118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e605601715118 : Closed e605601715118 ∧ code e605601715118 = 2804624970670 := by decide
theorem cert_e605601715118 : check e605601715118 [[],[]] .chain = true := by decide
def e605601715130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e605601715130 : Closed e605601715130 ∧ code e605601715130 = 2804624970682 := by decide
theorem cert_e605601715130 : check e605601715130 [[],[]] .chain = true := by decide
def e605601715158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e605601715158 : Closed e605601715158 ∧ code e605601715158 = 2804624970710 := by decide
theorem cert_e605601715158 : check e605601715158 [[],[]] .chain = true := by decide
def e605601715162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e605601715162 : Closed e605601715162 ∧ code e605601715162 = 2804624970714 := by decide
theorem cert_e605601715162 : check e605601715162 [[],[]] .chain = true := by decide
def e605601715438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e605601715438 : Closed e605601715438 ∧ code e605601715438 = 2804624970990 := by decide
theorem cert_e605601715438 : check e605601715438 [[],[]] .chain = true := by decide
def e605601715446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e605601715446 : Closed e605601715446 ∧ code e605601715446 = 2804624970998 := by decide
theorem cert_e605601715446 : check e605601715446 [[],[]] .chain = true := by decide
def e605601715822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601715822 : Closed e605601715822 ∧ code e605601715822 = 2804624971374 := by decide
theorem cert_e605601715822 : check e605601715822 [[],[]] .chain = true := by decide
def e605601715834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601715834 : Closed e605601715834 ∧ code e605601715834 = 2804624971386 := by decide
theorem cert_e605601715834 : check e605601715834 [[],[]] .chain = true := by decide
def e605601716022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601716022 : Closed e605601716022 ∧ code e605601716022 = 2804624971574 := by decide
theorem cert_e605601716022 : check e605601716022 [[],[]] .chain = true := by decide
def e605601716026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601716026 : Closed e605601716026 ∧ code e605601716026 = 2804624971578 := by decide
theorem cert_e605601716026 : check e605601716026 [[],[]] .chain = true := by decide
def e605601716270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e605601716270 : Closed e605601716270 ∧ code e605601716270 = 2804624971822 := by decide
theorem cert_e605601716270 : check e605601716270 [[],[]] .chain = true := by decide
def e605601716462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 2))) (.var 2))))))
theorem wire_e605601716462 : Closed e605601716462 ∧ code e605601716462 = 2804624972014 := by decide
theorem cert_e605601716462 : check e605601716462 [[],[]] .chain = true := by decide
def e605601716470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.var 1))))))
theorem wire_e605601716470 : Closed e605601716470 ∧ code e605601716470 = 2804624972022 := by decide
theorem cert_e605601716470 : check e605601716470 [[],[]] .chain = true := by decide
def e605601716654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e605601716654 : Closed e605601716654 ∧ code e605601716654 = 2804624972206 := by decide
theorem cert_e605601716654 : check e605601716654 [[],[]] .chain = true := by decide
def e605601716666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e605601716666 : Closed e605601716666 ∧ code e605601716666 = 2804624972218 := by decide
theorem cert_e605601716666 : check e605601716666 [[],[]] .chain = true := by decide
def e605601716714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e605601716714 : Closed e605601716714 ∧ code e605601716714 = 2804624972266 := by decide
theorem cert_e605601716714 : check e605601716714 [[],[]] .chain = true := by decide
def e605601716846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601716846 : Closed e605601716846 ∧ code e605601716846 = 2804624972398 := by decide
theorem cert_e605601716846 : check e605601716846 [[],[]] .chain = true := by decide
def e605601716858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601716858 : Closed e605601716858 ∧ code e605601716858 = 2804624972410 := by decide
theorem cert_e605601716858 : check e605601716858 [[],[]] .chain = true := by decide
def e605601717022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e605601717022 : Closed e605601717022 ∧ code e605601717022 = 2804624972574 := by decide
theorem cert_e605601717022 : check e605601717022 [[],[]] .chain = true := by decide
def e605601717122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e605601717122 : Closed e605601717122 ∧ code e605601717122 = 2804624972674 := by decide
theorem cert_e605601717122 : check e605601717122 [[],[]] .chain = true := by decide
def e605601717134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e605601717134 : Closed e605601717134 ∧ code e605601717134 = 2804624972686 := by decide
theorem cert_e605601717134 : check e605601717134 [[],[]] .chain = true := by decide
def e605601717146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601717146 : Closed e605601717146 ∧ code e605601717146 = 2804624972698 := by decide
theorem cert_e605601717146 : check e605601717146 [[],[]] .chain = true := by decide
def e605601717270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e605601717270 : Closed e605601717270 ∧ code e605601717270 = 2804624972822 := by decide
theorem cert_e605601717270 : check e605601717270 [[],[]] .chain = true := by decide
def e605601717366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.var 1))))))
theorem wire_e605601717366 : Closed e605601717366 ∧ code e605601717366 = 2804624972918 := by decide
theorem cert_e605601717366 : check e605601717366 [[],[]] .chain = true := by decide
def e605601717462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e605601717462 : Closed e605601717462 ∧ code e605601717462 = 2804624973014 := by decide
theorem cert_e605601717462 : check e605601717462 [[],[]] .chain = true := by decide
def e605601717466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e605601717466 : Closed e605601717466 ∧ code e605601717466 = 2804624973018 := by decide
theorem cert_e605601717466 : check e605601717466 [[],[]] .chain = true := by decide
def e605601717482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e605601717482 : Closed e605601717482 ∧ code e605601717482 = 2804624973034 := by decide
theorem cert_e605601717482 : check e605601717482 [[],[]] .chain = true := by decide
def e605601717558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601717558 : Closed e605601717558 ∧ code e605601717558 = 2804624973110 := by decide
theorem cert_e605601717558 : check e605601717558 [[],[]] .chain = true := by decide
def e605601717562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601717562 : Closed e605601717562 ∧ code e605601717562 = 2804624973114 := by decide
theorem cert_e605601717562 : check e605601717562 [[],[]] .chain = true := by decide
def e605601717634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e605601717634 : Closed e605601717634 ∧ code e605601717634 = 2804624973186 := by decide
theorem cert_e605601717634 : check e605601717634 [[],[]] .chain = true := by decide
def e605601717646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e605601717646 : Closed e605601717646 ∧ code e605601717646 = 2804624973198 := by decide
theorem cert_e605601717646 : check e605601717646 [[],[]] .chain = true := by decide
def e605601717658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601717658 : Closed e605601717658 ∧ code e605601717658 = 2804624973210 := by decide
theorem cert_e605601717658 : check e605601717658 [[],[]] .chain = true := by decide
def e605601718446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e605601718446 : Closed e605601718446 ∧ code e605601718446 = 2804624973998 := by decide
theorem cert_e605601718446 : check e605601718446 [[],[]] .chain = true := by decide
def e605601718458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e605601718458 : Closed e605601718458 ∧ code e605601718458 = 2804624974010 := by decide
theorem cert_e605601718458 : check e605601718458 [[],[]] .chain = true := by decide
def e605601719022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 2))))))
theorem wire_e605601719022 : Closed e605601719022 ∧ code e605601719022 = 2804624974574 := by decide
theorem cert_e605601719022 : check e605601719022 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601719150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e605601719150 : Closed e605601719150 ∧ code e605601719150 = 2804624974702 := by decide
theorem cert_e605601719150 : check e605601719150 [[],[]] .chain = true := by decide
def e605601719158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e605601719158 : Closed e605601719158 ∧ code e605601719158 = 2804624974710 := by decide
theorem cert_e605601719158 : check e605601719158 [[],[]] .chain = true := by decide
def e605601719214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e605601719214 : Closed e605601719214 ∧ code e605601719214 = 2804624974766 := by decide
theorem cert_e605601719214 : check e605601719214 [[],[]] .chain = true := by decide
def e605601719226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e605601719226 : Closed e605601719226 ∧ code e605601719226 = 2804624974778 := by decide
theorem cert_e605601719226 : check e605601719226 [[],[]] .chain = true := by decide
def e605601719254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e605601719254 : Closed e605601719254 ∧ code e605601719254 = 2804624974806 := by decide
theorem cert_e605601719254 : check e605601719254 [[],[]] .chain = true := by decide
def e605601719258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e605601719258 : Closed e605601719258 ∧ code e605601719258 = 2804624974810 := by decide
theorem cert_e605601719258 : check e605601719258 [[],[]] .chain = true := by decide
def e605601719982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e605601719982 : Closed e605601719982 ∧ code e605601719982 = 2804624975534 := by decide
theorem cert_e605601719982 : check e605601719982 [[],[]] .chain = true := by decide
def e605601719994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e605601719994 : Closed e605601719994 ∧ code e605601719994 = 2804624975546 := by decide
theorem cert_e605601719994 : check e605601719994 [[],[]] .chain = true := by decide
def e605601720042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e605601720042 : Closed e605601720042 ∧ code e605601720042 = 2804624975594 := by decide
theorem cert_e605601720042 : check e605601720042 [[],[]] .chain = true := by decide
end Blc.Floor41
