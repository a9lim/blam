import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e189851028334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e189851028334 : Closed e189851028334 ∧ code e189851028334 = 2388874283886 := by decide
theorem cert_e189851028334 : check e189851028334 [] .sourceHead = true := by decide
def e189851028342 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e189851028342 : Closed e189851028342 ∧ code e189851028342 = 2388874283894 := by decide
theorem cert_e189851028342 : check e189851028342 [] .sourceHead = true := by decide
def e189851028398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e189851028398 : Closed e189851028398 ∧ code e189851028398 = 2388874283950 := by decide
theorem cert_e189851028398 : check e189851028398 [] .sourceHead = true := by decide
def e189851028410 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e189851028410 : Closed e189851028410 ∧ code e189851028410 = 2388874283962 := by decide
theorem cert_e189851028410 : check e189851028410 [] .sourceHead = true := by decide
def e189851028438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e189851028438 : Closed e189851028438 ∧ code e189851028438 = 2388874283990 := by decide
theorem cert_e189851028438 : check e189851028438 [] .sourceHead = true := by decide
def e189851028442 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e189851028442 : Closed e189851028442 ∧ code e189851028442 = 2388874283994 := by decide
theorem cert_e189851028442 : check e189851028442 [] .sourceHead = true := by decide
def e189851028718 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e189851028718 : Closed e189851028718 ∧ code e189851028718 = 2388874284270 := by decide
theorem cert_e189851028718 : check e189851028718 [] .sourceHead = true := by decide
def e189851028726 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e189851028726 : Closed e189851028726 ∧ code e189851028726 = 2388874284278 := by decide
theorem cert_e189851028726 : check e189851028726 [] .sourceHead = true := by decide
def e189851029102 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e189851029102 : Closed e189851029102 ∧ code e189851029102 = 2388874284654 := by decide
theorem cert_e189851029102 : check e189851029102 [] .sourceHead = true := by decide
def e189851029114 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e189851029114 : Closed e189851029114 ∧ code e189851029114 = 2388874284666 := by decide
theorem cert_e189851029114 : check e189851029114 [] .sourceHead = true := by decide
def e189851029302 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e189851029302 : Closed e189851029302 ∧ code e189851029302 = 2388874284854 := by decide
theorem cert_e189851029302 : check e189851029302 [] .sourceHead = true := by decide
def e189851029306 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e189851029306 : Closed e189851029306 ∧ code e189851029306 = 2388874284858 := by decide
theorem cert_e189851029306 : check e189851029306 [] .sourceHead = true := by decide
def e189851035054 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e189851035054 : Closed e189851035054 ∧ code e189851035054 = 2388874290606 := by decide
theorem cert_e189851035054 : check e189851035054 [] .sourceHead = true := by decide
def e189851035066 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e189851035066 : Closed e189851035066 ∧ code e189851035066 = 2388874290618 := by decide
theorem cert_e189851035066 : check e189851035066 [] .sourceHead = true := by decide
def e189851035114 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e189851035114 : Closed e189851035114 ∧ code e189851035114 = 2388874290666 := by decide
theorem cert_e189851035114 : check e189851035114 [] .sourceHead = true := by decide
def e189851035246 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e189851035246 : Closed e189851035246 ∧ code e189851035246 = 2388874290798 := by decide
theorem cert_e189851035246 : check e189851035246 [] .sourceHead = true := by decide
def e189851035258 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e189851035258 : Closed e189851035258 ∧ code e189851035258 = 2388874290810 := by decide
theorem cert_e189851035258 : check e189851035258 [] .sourceHead = true := by decide
def e189851035546 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e189851035546 : Closed e189851035546 ∧ code e189851035546 = 2388874291098 := by decide
theorem cert_e189851035546 : check e189851035546 [] .sourceHead = true := by decide
def e189851038422 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e189851038422 : Closed e189851038422 ∧ code e189851038422 = 2388874293974 := by decide
theorem cert_e189851038422 : check e189851038422 [] .sourceHead = true := by decide
def e189851038426 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e189851038426 : Closed e189851038426 ∧ code e189851038426 = 2388874293978 := by decide
theorem cert_e189851038426 : check e189851038426 [] .sourceHead = true := by decide
def e189851038442 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e189851038442 : Closed e189851038442 ∧ code e189851038442 = 2388874293994 := by decide
theorem cert_e189851038442 : check e189851038442 [] .sourceHead = true := by decide
def e189851038518 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e189851038518 : Closed e189851038518 ∧ code e189851038518 = 2388874294070 := by decide
theorem cert_e189851038518 : check e189851038518 [] .sourceHead = true := by decide
def e189851038522 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e189851038522 : Closed e189851038522 ∧ code e189851038522 = 2388874294074 := by decide
theorem cert_e189851038522 : check e189851038522 [] .sourceHead = true := by decide
def e189851038618 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e189851038618 : Closed e189851038618 ∧ code e189851038618 = 2388874294170 := by decide
theorem cert_e189851038618 : check e189851038618 [] .sourceHead = true := by decide
def e189851154158 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e189851154158 : Closed e189851154158 ∧ code e189851154158 = 2388874409710 := by decide
theorem cert_e189851154158 : check e189851154158 [] .sourceHead = true := by decide
def e189851154286 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e189851154286 : Closed e189851154286 ∧ code e189851154286 = 2388874409838 := by decide
theorem cert_e189851154286 : check e189851154286 [] .sourceHead = true := by decide
def e189851154294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e189851154294 : Closed e189851154294 ∧ code e189851154294 = 2388874409846 := by decide
theorem cert_e189851154294 : check e189851154294 [] .sourceHead = true := by decide
def e189851155182 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e189851155182 : Closed e189851155182 ∧ code e189851155182 = 2388874410734 := by decide
theorem cert_e189851155182 : check e189851155182 [] .sourceHead = true := by decide
def e189851155374 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e189851155374 : Closed e189851155374 ∧ code e189851155374 = 2388874410926 := by decide
theorem cert_e189851155374 : check e189851155374 [] .sourceHead = true := by decide
def e189851155386 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e189851155386 : Closed e189851155386 ∧ code e189851155386 = 2388874410938 := by decide
theorem cert_e189851155386 : check e189851155386 [] .sourceHead = true := by decide
def e189851155822 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e189851155822 : Closed e189851155822 ∧ code e189851155822 = 2388874411374 := by decide
theorem cert_e189851155822 : check e189851155822 [] .sourceHead = true := by decide
def e189851155830 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e189851155830 : Closed e189851155830 ∧ code e189851155830 = 2388874411382 := by decide
theorem cert_e189851155830 : check e189851155830 [] .sourceHead = true := by decide
def e189851155886 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e189851155886 : Closed e189851155886 ∧ code e189851155886 = 2388874411438 := by decide
theorem cert_e189851155886 : check e189851155886 [] .sourceHead = true := by decide
def e189851155898 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e189851155898 : Closed e189851155898 ∧ code e189851155898 = 2388874411450 := by decide
theorem cert_e189851155898 : check e189851155898 [] .sourceHead = true := by decide
def e189851155926 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e189851155926 : Closed e189851155926 ∧ code e189851155926 = 2388874411478 := by decide
theorem cert_e189851155926 : check e189851155926 [] .sourceHead = true := by decide
def e189851155930 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e189851155930 : Closed e189851155930 ∧ code e189851155930 = 2388874411482 := by decide
theorem cert_e189851155930 : check e189851155930 [] .sourceHead = true := by decide
def e189851160302 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e189851160302 : Closed e189851160302 ∧ code e189851160302 = 2388874415854 := by decide
theorem cert_e189851160302 : check e189851160302 [] .sourceHead = true := by decide
def e189851160430 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e189851160430 : Closed e189851160430 ∧ code e189851160430 = 2388874415982 := by decide
theorem cert_e189851160430 : check e189851160430 [] .sourceHead = true := by decide
def e189851160438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e189851160438 : Closed e189851160438 ∧ code e189851160438 = 2388874415990 := by decide
theorem cert_e189851160438 : check e189851160438 [] .sourceHead = true := by decide
def e189851163118 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e189851163118 : Closed e189851163118 ∧ code e189851163118 = 2388874418670 := by decide
theorem cert_e189851163118 : check e189851163118 [] .sourceHead = true := by decide
def e189851163886 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e189851163886 : Closed e189851163886 ∧ code e189851163886 = 2388874419438 := by decide
theorem cert_e189851163886 : check e189851163886 [] .sourceHead = true := by decide
def e189851163894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e189851163894 : Closed e189851163894 ∧ code e189851163894 = 2388874419446 := by decide
theorem cert_e189851163894 : check e189851163894 [] .sourceHead = true := by decide
def e189851166446 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e189851166446 : Closed e189851166446 ∧ code e189851166446 = 2388874421998 := by decide
theorem cert_e189851166446 : check e189851166446 [] .sourceHead = true := by decide
def e189851166638 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e189851166638 : Closed e189851166638 ∧ code e189851166638 = 2388874422190 := by decide
theorem cert_e189851166638 : check e189851166638 [] .sourceHead = true := by decide
def e189851166650 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e189851166650 : Closed e189851166650 ∧ code e189851166650 = 2388874422202 := by decide
theorem cert_e189851166650 : check e189851166650 [] .sourceHead = true := by decide
def e189851167214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e189851167214 : Closed e189851167214 ∧ code e189851167214 = 2388874422766 := by decide
theorem cert_e189851167214 : check e189851167214 [] .sourceHead = true := by decide
def e189851168366 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e189851168366 : Closed e189851168366 ∧ code e189851168366 = 2388874423918 := by decide
theorem cert_e189851168366 : check e189851168366 [] .sourceHead = true := by decide
def e189851168378 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e189851168378 : Closed e189851168378 ∧ code e189851168378 = 2388874423930 := by decide
theorem cert_e189851168378 : check e189851168378 [] .sourceHead = true := by decide
def e189851169646 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e189851169646 : Closed e189851169646 ∧ code e189851169646 = 2388874425198 := by decide
theorem cert_e189851169646 : check e189851169646 [] .sourceHead = true := by decide
def e189851169654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e189851169654 : Closed e189851169654 ∧ code e189851169654 = 2388874425206 := by decide
theorem cert_e189851169654 : check e189851169654 [] .sourceHead = true := by decide
def e189851169710 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e189851169710 : Closed e189851169710 ∧ code e189851169710 = 2388874425262 := by decide
theorem cert_e189851169710 : check e189851169710 [] .sourceHead = true := by decide
def e189851169722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e189851169722 : Closed e189851169722 ∧ code e189851169722 = 2388874425274 := by decide
theorem cert_e189851169722 : check e189851169722 [] .sourceHead = true := by decide
def e189851169750 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e189851169750 : Closed e189851169750 ∧ code e189851169750 = 2388874425302 := by decide
theorem cert_e189851169750 : check e189851169750 [] .sourceHead = true := by decide
def e189851169754 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e189851169754 : Closed e189851169754 ∧ code e189851169754 = 2388874425306 := by decide
theorem cert_e189851169754 : check e189851169754 [] .sourceHead = true := by decide
def e189851170030 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e189851170030 : Closed e189851170030 ∧ code e189851170030 = 2388874425582 := by decide
theorem cert_e189851170030 : check e189851170030 [] .sourceHead = true := by decide
def e189851170038 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e189851170038 : Closed e189851170038 ∧ code e189851170038 = 2388874425590 := by decide
theorem cert_e189851170038 : check e189851170038 [] .sourceHead = true := by decide
def e189851170414 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e189851170414 : Closed e189851170414 ∧ code e189851170414 = 2388874425966 := by decide
theorem cert_e189851170414 : check e189851170414 [] .sourceHead = true := by decide
def e189851170426 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e189851170426 : Closed e189851170426 ∧ code e189851170426 = 2388874425978 := by decide
theorem cert_e189851170426 : check e189851170426 [] .sourceHead = true := by decide
def e189851170614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e189851170614 : Closed e189851170614 ∧ code e189851170614 = 2388874426166 := by decide
theorem cert_e189851170614 : check e189851170614 [] .sourceHead = true := by decide
def e189851170618 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e189851170618 : Closed e189851170618 ∧ code e189851170618 = 2388874426170 := by decide
theorem cert_e189851170618 : check e189851170618 [] .sourceHead = true := by decide
def e189851175790 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e189851175790 : Closed e189851175790 ∧ code e189851175790 = 2388874431342 := by decide
theorem cert_e189851175790 : check e189851175790 [] .sourceHead = true := by decide
def e189851175798 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e189851175798 : Closed e189851175798 ∧ code e189851175798 = 2388874431350 := by decide
theorem cert_e189851175798 : check e189851175798 [] .sourceHead = true := by decide
def e189851175854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e189851175854 : Closed e189851175854 ∧ code e189851175854 = 2388874431406 := by decide
theorem cert_e189851175854 : check e189851175854 [] .sourceHead = true := by decide
def e189851175866 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e189851175866 : Closed e189851175866 ∧ code e189851175866 = 2388874431418 := by decide
theorem cert_e189851175866 : check e189851175866 [] .sourceHead = true := by decide
def e189851175894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e189851175894 : Closed e189851175894 ∧ code e189851175894 = 2388874431446 := by decide
theorem cert_e189851175894 : check e189851175894 [] .sourceHead = true := by decide
def e189851175898 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e189851175898 : Closed e189851175898 ∧ code e189851175898 = 2388874431450 := by decide
theorem cert_e189851175898 : check e189851175898 [] .sourceHead = true := by decide
def e189851176174 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e189851176174 : Closed e189851176174 ∧ code e189851176174 = 2388874431726 := by decide
theorem cert_e189851176174 : check e189851176174 [] .sourceHead = true := by decide
def e189851176182 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e189851176182 : Closed e189851176182 ∧ code e189851176182 = 2388874431734 := by decide
theorem cert_e189851176182 : check e189851176182 [] .sourceHead = true := by decide
def e189851176558 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e189851176558 : Closed e189851176558 ∧ code e189851176558 = 2388874432110 := by decide
theorem cert_e189851176558 : check e189851176558 [] .sourceHead = true := by decide
def e189851176570 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e189851176570 : Closed e189851176570 ∧ code e189851176570 = 2388874432122 := by decide
theorem cert_e189851176570 : check e189851176570 [] .sourceHead = true := by decide
def e189851176758 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e189851176758 : Closed e189851176758 ∧ code e189851176758 = 2388874432310 := by decide
theorem cert_e189851176758 : check e189851176758 [] .sourceHead = true := by decide
def e189851176762 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e189851176762 : Closed e189851176762 ∧ code e189851176762 = 2388874432314 := by decide
theorem cert_e189851176762 : check e189851176762 [] .sourceHead = true := by decide
def e189851184878 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e189851184878 : Closed e189851184878 ∧ code e189851184878 = 2388874440430 := by decide
theorem cert_e189851184878 : check e189851184878 [] .sourceHead = true := by decide
def e189851185006 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e189851185006 : Closed e189851185006 ∧ code e189851185006 = 2388874440558 := by decide
theorem cert_e189851185006 : check e189851185006 [] .sourceHead = true := by decide
def e189851185014 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e189851185014 : Closed e189851185014 ∧ code e189851185014 = 2388874440566 := by decide
theorem cert_e189851185014 : check e189851185014 [] .sourceHead = true := by decide
def e189851187694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e189851187694 : Closed e189851187694 ∧ code e189851187694 = 2388874443246 := by decide
theorem cert_e189851187694 : check e189851187694 [] .sourceHead = true := by decide
def e189851188462 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e189851188462 : Closed e189851188462 ∧ code e189851188462 = 2388874444014 := by decide
theorem cert_e189851188462 : check e189851188462 [] .sourceHead = true := by decide
def e189851188470 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e189851188470 : Closed e189851188470 ∧ code e189851188470 = 2388874444022 := by decide
theorem cert_e189851188470 : check e189851188470 [] .sourceHead = true := by decide
def e189851211502 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e189851211502 : Closed e189851211502 ∧ code e189851211502 = 2388874467054 := by decide
theorem cert_e189851211502 : check e189851211502 [] .sourceHead = true := by decide
def e189851211694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e189851211694 : Closed e189851211694 ∧ code e189851211694 = 2388874467246 := by decide
theorem cert_e189851211694 : check e189851211694 [] .sourceHead = true := by decide
def e189851211706 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e189851211706 : Closed e189851211706 ∧ code e189851211706 = 2388874467258 := by decide
theorem cert_e189851211706 : check e189851211706 [] .sourceHead = true := by decide
def e189851212270 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e189851212270 : Closed e189851212270 ∧ code e189851212270 = 2388874467822 := by decide
theorem cert_e189851212270 : check e189851212270 [] .sourceHead = true := by decide
def e189851213422 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e189851213422 : Closed e189851213422 ∧ code e189851213422 = 2388874468974 := by decide
theorem cert_e189851213422 : check e189851213422 [] .sourceHead = true := by decide
def e189851213434 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e189851213434 : Closed e189851213434 ∧ code e189851213434 = 2388874468986 := by decide
theorem cert_e189851213434 : check e189851213434 [] .sourceHead = true := by decide
def e189851224942 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e189851224942 : Closed e189851224942 ∧ code e189851224942 = 2388874480494 := by decide
theorem cert_e189851224942 : check e189851224942 [] .sourceHead = true := by decide
def e189851224950 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e189851224950 : Closed e189851224950 ∧ code e189851224950 = 2388874480502 := by decide
theorem cert_e189851224950 : check e189851224950 [] .sourceHead = true := by decide
def e189851225006 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e189851225006 : Closed e189851225006 ∧ code e189851225006 = 2388874480558 := by decide
theorem cert_e189851225006 : check e189851225006 [] .sourceHead = true := by decide
def e189851225018 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e189851225018 : Closed e189851225018 ∧ code e189851225018 = 2388874480570 := by decide
theorem cert_e189851225018 : check e189851225018 [] .sourceHead = true := by decide
def e189851225046 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e189851225046 : Closed e189851225046 ∧ code e189851225046 = 2388874480598 := by decide
theorem cert_e189851225046 : check e189851225046 [] .sourceHead = true := by decide
def e189851225050 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e189851225050 : Closed e189851225050 ∧ code e189851225050 = 2388874480602 := by decide
theorem cert_e189851225050 : check e189851225050 [] .sourceHead = true := by decide
def e189851225326 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e189851225326 : Closed e189851225326 ∧ code e189851225326 = 2388874480878 := by decide
theorem cert_e189851225326 : check e189851225326 [] .sourceHead = true := by decide
def e189851225334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e189851225334 : Closed e189851225334 ∧ code e189851225334 = 2388874480886 := by decide
theorem cert_e189851225334 : check e189851225334 [] .sourceHead = true := by decide
def e189851225710 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e189851225710 : Closed e189851225710 ∧ code e189851225710 = 2388874481262 := by decide
theorem cert_e189851225710 : check e189851225710 [] .sourceHead = true := by decide
def e189851225722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e189851225722 : Closed e189851225722 ∧ code e189851225722 = 2388874481274 := by decide
theorem cert_e189851225722 : check e189851225722 [] .sourceHead = true := by decide
def e189851225910 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e189851225910 : Closed e189851225910 ∧ code e189851225910 = 2388874481462 := by decide
theorem cert_e189851225910 : check e189851225910 [] .sourceHead = true := by decide
def e189851225914 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e189851225914 : Closed e189851225914 ∧ code e189851225914 = 2388874481466 := by decide
theorem cert_e189851225914 : check e189851225914 [] .sourceHead = true := by decide
def e189851765614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e189851765614 : Closed e189851765614 ∧ code e189851765614 = 2388875021166 := by decide
theorem cert_e189851765614 : check e189851765614 [] .sourceHead = true := by decide
def e189851765622 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e189851765622 : Closed e189851765622 ∧ code e189851765622 = 2388875021174 := by decide
theorem cert_e189851765622 : check e189851765622 [] .sourceHead = true := by decide
def e189851765678 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e189851765678 : Closed e189851765678 ∧ code e189851765678 = 2388875021230 := by decide
theorem cert_e189851765678 : check e189851765678 [] .sourceHead = true := by decide
def e189851765690 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e189851765690 : Closed e189851765690 ∧ code e189851765690 = 2388875021242 := by decide
theorem cert_e189851765690 : check e189851765690 [] .sourceHead = true := by decide
def e189851765718 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e189851765718 : Closed e189851765718 ∧ code e189851765718 = 2388875021270 := by decide
theorem cert_e189851765718 : check e189851765718 [] .sourceHead = true := by decide
def e189851765722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e189851765722 : Closed e189851765722 ∧ code e189851765722 = 2388875021274 := by decide
theorem cert_e189851765722 : check e189851765722 [] .sourceHead = true := by decide
def e189851765998 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e189851765998 : Closed e189851765998 ∧ code e189851765998 = 2388875021550 := by decide
theorem cert_e189851765998 : check e189851765998 [] .sourceHead = true := by decide
def e189851766006 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e189851766006 : Closed e189851766006 ∧ code e189851766006 = 2388875021558 := by decide
theorem cert_e189851766006 : check e189851766006 [] .sourceHead = true := by decide
def e189851766382 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e189851766382 : Closed e189851766382 ∧ code e189851766382 = 2388875021934 := by decide
theorem cert_e189851766382 : check e189851766382 [] .sourceHead = true := by decide
def e189851766394 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e189851766394 : Closed e189851766394 ∧ code e189851766394 = 2388875021946 := by decide
theorem cert_e189851766394 : check e189851766394 [] .sourceHead = true := by decide
def e189851766582 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e189851766582 : Closed e189851766582 ∧ code e189851766582 = 2388875022134 := by decide
theorem cert_e189851766582 : check e189851766582 [] .sourceHead = true := by decide
def e189851766586 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e189851766586 : Closed e189851766586 ∧ code e189851766586 = 2388875022138 := by decide
theorem cert_e189851766586 : check e189851766586 [] .sourceHead = true := by decide
def e206306323822 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e206306323822 : Closed e206306323822 ∧ code e206306323822 = 2405329579374 := by decide
theorem cert_e206306323822 : check e206306323822 [] .sourceHead = true := by decide
def e206306323830 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e206306323830 : Closed e206306323830 ∧ code e206306323830 = 2405329579382 := by decide
theorem cert_e206306323830 : check e206306323830 [] .sourceHead = true := by decide
def e206306323886 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e206306323886 : Closed e206306323886 ∧ code e206306323886 = 2405329579438 := by decide
theorem cert_e206306323886 : check e206306323886 [] .sourceHead = true := by decide
def e206306323898 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e206306323898 : Closed e206306323898 ∧ code e206306323898 = 2405329579450 := by decide
theorem cert_e206306323898 : check e206306323898 [] .sourceHead = true := by decide
def e206306323926 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e206306323926 : Closed e206306323926 ∧ code e206306323926 = 2405329579478 := by decide
theorem cert_e206306323926 : check e206306323926 [] .sourceHead = true := by decide
def e206306323930 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e206306323930 : Closed e206306323930 ∧ code e206306323930 = 2405329579482 := by decide
theorem cert_e206306323930 : check e206306323930 [] .sourceHead = true := by decide
def e206306324142 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e206306324142 : Closed e206306324142 ∧ code e206306324142 = 2405329579694 := by decide
theorem cert_e206306324142 : check e206306324142 [] .sourceHead = true := by decide
def e206306324154 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e206306324154 : Closed e206306324154 ∧ code e206306324154 = 2405329579706 := by decide
theorem cert_e206306324154 : check e206306324154 [] .sourceHead = true := by decide
def e206306324202 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e206306324202 : Closed e206306324202 ∧ code e206306324202 = 2405329579754 := by decide
theorem cert_e206306324202 : check e206306324202 [] .sourceHead = true := by decide
def e206306324310 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e206306324310 : Closed e206306324310 ∧ code e206306324310 = 2405329579862 := by decide
theorem cert_e206306324310 : check e206306324310 [] .sourceHead = true := by decide
def e206306324314 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e206306324314 : Closed e206306324314 ∧ code e206306324314 = 2405329579866 := by decide
theorem cert_e206306324314 : check e206306324314 [] .sourceHead = true := by decide
def e206306324330 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e206306324330 : Closed e206306324330 ∧ code e206306324330 = 2405329579882 := by decide
theorem cert_e206306324330 : check e206306324330 [] .sourceHead = true := by decide
def e206306325358 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e206306325358 : Closed e206306325358 ∧ code e206306325358 = 2405329580910 := by decide
theorem cert_e206306325358 : check e206306325358 [] .sourceHead = true := by decide
def e206306325366 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e206306325366 : Closed e206306325366 ∧ code e206306325366 = 2405329580918 := by decide
theorem cert_e206306325366 : check e206306325366 [] .sourceHead = true := by decide
def e206306325422 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e206306325422 : Closed e206306325422 ∧ code e206306325422 = 2405329580974 := by decide
theorem cert_e206306325422 : check e206306325422 [] .sourceHead = true := by decide
def e206306325434 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e206306325434 : Closed e206306325434 ∧ code e206306325434 = 2405329580986 := by decide
theorem cert_e206306325434 : check e206306325434 [] .sourceHead = true := by decide
def e206306325462 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e206306325462 : Closed e206306325462 ∧ code e206306325462 = 2405329581014 := by decide
theorem cert_e206306325462 : check e206306325462 [] .sourceHead = true := by decide
def e206306325466 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e206306325466 : Closed e206306325466 ∧ code e206306325466 = 2405329581018 := by decide
theorem cert_e206306325466 : check e206306325466 [] .sourceHead = true := by decide
def e206306325742 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e206306325742 : Closed e206306325742 ∧ code e206306325742 = 2405329581294 := by decide
theorem cert_e206306325742 : check e206306325742 [] .sourceHead = true := by decide
def e206306325750 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e206306325750 : Closed e206306325750 ∧ code e206306325750 = 2405329581302 := by decide
theorem cert_e206306325750 : check e206306325750 [] .sourceHead = true := by decide
def e206306326126 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e206306326126 : Closed e206306326126 ∧ code e206306326126 = 2405329581678 := by decide
theorem cert_e206306326126 : check e206306326126 [] .sourceHead = true := by decide
def e206306326138 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e206306326138 : Closed e206306326138 ∧ code e206306326138 = 2405329581690 := by decide
theorem cert_e206306326138 : check e206306326138 [] .sourceHead = true := by decide
def e206306326326 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e206306326326 : Closed e206306326326 ∧ code e206306326326 = 2405329581878 := by decide
theorem cert_e206306326326 : check e206306326326 [] .sourceHead = true := by decide
def e206306326330 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e206306326330 : Closed e206306326330 ∧ code e206306326330 = 2405329581882 := by decide
theorem cert_e206306326330 : check e206306326330 [] .sourceHead = true := by decide
def e206306326958 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e206306326958 : Closed e206306326958 ∧ code e206306326958 = 2405329582510 := by decide
theorem cert_e206306326958 : check e206306326958 [] .sourceHead = true := by decide
def e206306326970 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e206306326970 : Closed e206306326970 ∧ code e206306326970 = 2405329582522 := by decide
theorem cert_e206306326970 : check e206306326970 [] .sourceHead = true := by decide
def e206306327018 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e206306327018 : Closed e206306327018 ∧ code e206306327018 = 2405329582570 := by decide
theorem cert_e206306327018 : check e206306327018 [] .sourceHead = true := by decide
def e206306327150 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e206306327150 : Closed e206306327150 ∧ code e206306327150 = 2405329582702 := by decide
theorem cert_e206306327150 : check e206306327150 [] .sourceHead = true := by decide
def e206306327162 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e206306327162 : Closed e206306327162 ∧ code e206306327162 = 2405329582714 := by decide
theorem cert_e206306327162 : check e206306327162 [] .sourceHead = true := by decide
def e206306327450 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e206306327450 : Closed e206306327450 ∧ code e206306327450 = 2405329583002 := by decide
theorem cert_e206306327450 : check e206306327450 [] .sourceHead = true := by decide
def e206306327766 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e206306327766 : Closed e206306327766 ∧ code e206306327766 = 2405329583318 := by decide
theorem cert_e206306327766 : check e206306327766 [] .sourceHead = true := by decide
def e206306327770 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e206306327770 : Closed e206306327770 ∧ code e206306327770 = 2405329583322 := by decide
theorem cert_e206306327770 : check e206306327770 [] .sourceHead = true := by decide
def e206306327786 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e206306327786 : Closed e206306327786 ∧ code e206306327786 = 2405329583338 := by decide
theorem cert_e206306327786 : check e206306327786 [] .sourceHead = true := by decide
def e206306327862 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e206306327862 : Closed e206306327862 ∧ code e206306327862 = 2405329583414 := by decide
theorem cert_e206306327862 : check e206306327862 [] .sourceHead = true := by decide
def e206306327866 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e206306327866 : Closed e206306327866 ∧ code e206306327866 = 2405329583418 := by decide
theorem cert_e206306327866 : check e206306327866 [] .sourceHead = true := by decide
def e206306327962 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e206306327962 : Closed e206306327962 ∧ code e206306327962 = 2405329583514 := by decide
theorem cert_e206306327962 : check e206306327962 [] .sourceHead = true := by decide
def e206306331502 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e206306331502 : Closed e206306331502 ∧ code e206306331502 = 2405329587054 := by decide
theorem cert_e206306331502 : check e206306331502 [] .sourceHead = true := by decide
def e206306331510 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e206306331510 : Closed e206306331510 ∧ code e206306331510 = 2405329587062 := by decide
theorem cert_e206306331510 : check e206306331510 [] .sourceHead = true := by decide
def e206306331566 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e206306331566 : Closed e206306331566 ∧ code e206306331566 = 2405329587118 := by decide
theorem cert_e206306331566 : check e206306331566 [] .sourceHead = true := by decide
def e206306331578 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e206306331578 : Closed e206306331578 ∧ code e206306331578 = 2405329587130 := by decide
theorem cert_e206306331578 : check e206306331578 [] .sourceHead = true := by decide
def e206306331606 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e206306331606 : Closed e206306331606 ∧ code e206306331606 = 2405329587158 := by decide
theorem cert_e206306331606 : check e206306331606 [] .sourceHead = true := by decide
def e206306331610 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e206306331610 : Closed e206306331610 ∧ code e206306331610 = 2405329587162 := by decide
theorem cert_e206306331610 : check e206306331610 [] .sourceHead = true := by decide
def e206306331886 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e206306331886 : Closed e206306331886 ∧ code e206306331886 = 2405329587438 := by decide
theorem cert_e206306331886 : check e206306331886 [] .sourceHead = true := by decide
def e206306331894 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e206306331894 : Closed e206306331894 ∧ code e206306331894 = 2405329587446 := by decide
theorem cert_e206306331894 : check e206306331894 [] .sourceHead = true := by decide
def e206306332270 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e206306332270 : Closed e206306332270 ∧ code e206306332270 = 2405329587822 := by decide
theorem cert_e206306332270 : check e206306332270 [] .sourceHead = true := by decide
def e206306332282 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e206306332282 : Closed e206306332282 ∧ code e206306332282 = 2405329587834 := by decide
theorem cert_e206306332282 : check e206306332282 [] .sourceHead = true := by decide
def e206306332470 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e206306332470 : Closed e206306332470 ∧ code e206306332470 = 2405329588022 := by decide
theorem cert_e206306332470 : check e206306332470 [] .sourceHead = true := by decide
def e206306332474 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e206306332474 : Closed e206306332474 ∧ code e206306332474 = 2405329588026 := by decide
theorem cert_e206306332474 : check e206306332474 [] .sourceHead = true := by decide
def e206306338222 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e206306338222 : Closed e206306338222 ∧ code e206306338222 = 2405329593774 := by decide
theorem cert_e206306338222 : check e206306338222 [] .sourceHead = true := by decide
def e206306338234 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e206306338234 : Closed e206306338234 ∧ code e206306338234 = 2405329593786 := by decide
theorem cert_e206306338234 : check e206306338234 [] .sourceHead = true := by decide
def e206306338282 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e206306338282 : Closed e206306338282 ∧ code e206306338282 = 2405329593834 := by decide
theorem cert_e206306338282 : check e206306338282 [] .sourceHead = true := by decide
def e206306338414 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e206306338414 : Closed e206306338414 ∧ code e206306338414 = 2405329593966 := by decide
theorem cert_e206306338414 : check e206306338414 [] .sourceHead = true := by decide
end Blc.Floor41
