import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e215620964078 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e215620964078 : Closed e215620964078 ∧ code e215620964078 = 2414644219630 := by decide
theorem cert_e215620964078 : check e215620964078 [] .sourceHead = true := by decide
def e215620964206 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e215620964206 : Closed e215620964206 ∧ code e215620964206 = 2414644219758 := by decide
theorem cert_e215620964206 : check e215620964206 [] .sourceHead = true := by decide
def e215620964214 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e215620964214 : Closed e215620964214 ∧ code e215620964214 = 2414644219766 := by decide
theorem cert_e215620964214 : check e215620964214 [] .sourceHead = true := by decide
def e215620966894 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e215620966894 : Closed e215620966894 ∧ code e215620966894 = 2414644222446 := by decide
theorem cert_e215620966894 : check e215620966894 [] .sourceHead = true := by decide
def e215620967662 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e215620967662 : Closed e215620967662 ∧ code e215620967662 = 2414644223214 := by decide
theorem cert_e215620967662 : check e215620967662 [] .sourceHead = true := by decide
def e215620967670 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e215620967670 : Closed e215620967670 ∧ code e215620967670 = 2414644223222 := by decide
theorem cert_e215620967670 : check e215620967670 [] .sourceHead = true := by decide
def e215620970222 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e215620970222 : Closed e215620970222 ∧ code e215620970222 = 2414644225774 := by decide
theorem cert_e215620970222 : check e215620970222 [] .sourceHead = true := by decide
def e215620970414 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e215620970414 : Closed e215620970414 ∧ code e215620970414 = 2414644225966 := by decide
theorem cert_e215620970414 : check e215620970414 [] .sourceHead = true := by decide
def e215620970426 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e215620970426 : Closed e215620970426 ∧ code e215620970426 = 2414644225978 := by decide
theorem cert_e215620970426 : check e215620970426 [] .sourceHead = true := by decide
def e215620970990 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e215620970990 : Closed e215620970990 ∧ code e215620970990 = 2414644226542 := by decide
theorem cert_e215620970990 : check e215620970990 [] .sourceHead = true := by decide
def e215620972142 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e215620972142 : Closed e215620972142 ∧ code e215620972142 = 2414644227694 := by decide
theorem cert_e215620972142 : check e215620972142 [] .sourceHead = true := by decide
def e215620972154 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e215620972154 : Closed e215620972154 ∧ code e215620972154 = 2414644227706 := by decide
theorem cert_e215620972154 : check e215620972154 [] .sourceHead = true := by decide
def e215620973422 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e215620973422 : Closed e215620973422 ∧ code e215620973422 = 2414644228974 := by decide
theorem cert_e215620973422 : check e215620973422 [] .sourceHead = true := by decide
def e215620973430 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e215620973430 : Closed e215620973430 ∧ code e215620973430 = 2414644228982 := by decide
theorem cert_e215620973430 : check e215620973430 [] .sourceHead = true := by decide
def e215620973486 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e215620973486 : Closed e215620973486 ∧ code e215620973486 = 2414644229038 := by decide
theorem cert_e215620973486 : check e215620973486 [] .sourceHead = true := by decide
def e215620973498 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e215620973498 : Closed e215620973498 ∧ code e215620973498 = 2414644229050 := by decide
theorem cert_e215620973498 : check e215620973498 [] .sourceHead = true := by decide
def e215620973526 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e215620973526 : Closed e215620973526 ∧ code e215620973526 = 2414644229078 := by decide
theorem cert_e215620973526 : check e215620973526 [] .sourceHead = true := by decide
def e215620973530 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e215620973530 : Closed e215620973530 ∧ code e215620973530 = 2414644229082 := by decide
theorem cert_e215620973530 : check e215620973530 [] .sourceHead = true := by decide
def e215620973806 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e215620973806 : Closed e215620973806 ∧ code e215620973806 = 2414644229358 := by decide
theorem cert_e215620973806 : check e215620973806 [] .sourceHead = true := by decide
def e215620973814 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e215620973814 : Closed e215620973814 ∧ code e215620973814 = 2414644229366 := by decide
theorem cert_e215620973814 : check e215620973814 [] .sourceHead = true := by decide
def e215620974190 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e215620974190 : Closed e215620974190 ∧ code e215620974190 = 2414644229742 := by decide
theorem cert_e215620974190 : check e215620974190 [] .sourceHead = true := by decide
def e215620974202 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e215620974202 : Closed e215620974202 ∧ code e215620974202 = 2414644229754 := by decide
theorem cert_e215620974202 : check e215620974202 [] .sourceHead = true := by decide
def e215620974390 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e215620974390 : Closed e215620974390 ∧ code e215620974390 = 2414644229942 := by decide
theorem cert_e215620974390 : check e215620974390 [] .sourceHead = true := by decide
def e215620974394 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e215620974394 : Closed e215620974394 ∧ code e215620974394 = 2414644229946 := by decide
theorem cert_e215620974394 : check e215620974394 [] .sourceHead = true := by decide
def e215620979566 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e215620979566 : Closed e215620979566 ∧ code e215620979566 = 2414644235118 := by decide
theorem cert_e215620979566 : check e215620979566 [] .sourceHead = true := by decide
def e215620979574 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e215620979574 : Closed e215620979574 ∧ code e215620979574 = 2414644235126 := by decide
theorem cert_e215620979574 : check e215620979574 [] .sourceHead = true := by decide
def e215620979630 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e215620979630 : Closed e215620979630 ∧ code e215620979630 = 2414644235182 := by decide
theorem cert_e215620979630 : check e215620979630 [] .sourceHead = true := by decide
def e215620979642 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e215620979642 : Closed e215620979642 ∧ code e215620979642 = 2414644235194 := by decide
theorem cert_e215620979642 : check e215620979642 [] .sourceHead = true := by decide
def e215620979670 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e215620979670 : Closed e215620979670 ∧ code e215620979670 = 2414644235222 := by decide
theorem cert_e215620979670 : check e215620979670 [] .sourceHead = true := by decide
def e215620979674 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e215620979674 : Closed e215620979674 ∧ code e215620979674 = 2414644235226 := by decide
theorem cert_e215620979674 : check e215620979674 [] .sourceHead = true := by decide
def e215620979950 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e215620979950 : Closed e215620979950 ∧ code e215620979950 = 2414644235502 := by decide
theorem cert_e215620979950 : check e215620979950 [] .sourceHead = true := by decide
def e215620979958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e215620979958 : Closed e215620979958 ∧ code e215620979958 = 2414644235510 := by decide
theorem cert_e215620979958 : check e215620979958 [] .sourceHead = true := by decide
def e215620980334 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e215620980334 : Closed e215620980334 ∧ code e215620980334 = 2414644235886 := by decide
theorem cert_e215620980334 : check e215620980334 [] .sourceHead = true := by decide
def e215620980346 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e215620980346 : Closed e215620980346 ∧ code e215620980346 = 2414644235898 := by decide
theorem cert_e215620980346 : check e215620980346 [] .sourceHead = true := by decide
def e215620980534 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e215620980534 : Closed e215620980534 ∧ code e215620980534 = 2414644236086 := by decide
theorem cert_e215620980534 : check e215620980534 [] .sourceHead = true := by decide
def e215620980538 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e215620980538 : Closed e215620980538 ∧ code e215620980538 = 2414644236090 := by decide
theorem cert_e215620980538 : check e215620980538 [] .sourceHead = true := by decide
def e215620988654 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e215620988654 : Closed e215620988654 ∧ code e215620988654 = 2414644244206 := by decide
theorem cert_e215620988654 : check e215620988654 [] .sourceHead = true := by decide
def e215620988782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e215620988782 : Closed e215620988782 ∧ code e215620988782 = 2414644244334 := by decide
theorem cert_e215620988782 : check e215620988782 [] .sourceHead = true := by decide
def e215620988790 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e215620988790 : Closed e215620988790 ∧ code e215620988790 = 2414644244342 := by decide
theorem cert_e215620988790 : check e215620988790 [] .sourceHead = true := by decide
def e215620991470 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e215620991470 : Closed e215620991470 ∧ code e215620991470 = 2414644247022 := by decide
theorem cert_e215620991470 : check e215620991470 [] .sourceHead = true := by decide
def e215620992238 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e215620992238 : Closed e215620992238 ∧ code e215620992238 = 2414644247790 := by decide
theorem cert_e215620992238 : check e215620992238 [] .sourceHead = true := by decide
def e215620992246 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e215620992246 : Closed e215620992246 ∧ code e215620992246 = 2414644247798 := by decide
theorem cert_e215620992246 : check e215620992246 [] .sourceHead = true := by decide
def e215621015278 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e215621015278 : Closed e215621015278 ∧ code e215621015278 = 2414644270830 := by decide
theorem cert_e215621015278 : check e215621015278 [] .sourceHead = true := by decide
def e215621015470 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e215621015470 : Closed e215621015470 ∧ code e215621015470 = 2414644271022 := by decide
theorem cert_e215621015470 : check e215621015470 [] .sourceHead = true := by decide
def e215621015482 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e215621015482 : Closed e215621015482 ∧ code e215621015482 = 2414644271034 := by decide
theorem cert_e215621015482 : check e215621015482 [] .sourceHead = true := by decide
def e215621016046 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e215621016046 : Closed e215621016046 ∧ code e215621016046 = 2414644271598 := by decide
theorem cert_e215621016046 : check e215621016046 [] .sourceHead = true := by decide
def e215621017198 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e215621017198 : Closed e215621017198 ∧ code e215621017198 = 2414644272750 := by decide
theorem cert_e215621017198 : check e215621017198 [] .sourceHead = true := by decide
def e215621017210 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e215621017210 : Closed e215621017210 ∧ code e215621017210 = 2414644272762 := by decide
theorem cert_e215621017210 : check e215621017210 [] .sourceHead = true := by decide
def e215621028718 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e215621028718 : Closed e215621028718 ∧ code e215621028718 = 2414644284270 := by decide
theorem cert_e215621028718 : check e215621028718 [] .sourceHead = true := by decide
def e215621028726 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e215621028726 : Closed e215621028726 ∧ code e215621028726 = 2414644284278 := by decide
theorem cert_e215621028726 : check e215621028726 [] .sourceHead = true := by decide
def e215621028782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e215621028782 : Closed e215621028782 ∧ code e215621028782 = 2414644284334 := by decide
theorem cert_e215621028782 : check e215621028782 [] .sourceHead = true := by decide
def e215621028794 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e215621028794 : Closed e215621028794 ∧ code e215621028794 = 2414644284346 := by decide
theorem cert_e215621028794 : check e215621028794 [] .sourceHead = true := by decide
def e215621028822 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e215621028822 : Closed e215621028822 ∧ code e215621028822 = 2414644284374 := by decide
theorem cert_e215621028822 : check e215621028822 [] .sourceHead = true := by decide
def e215621028826 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e215621028826 : Closed e215621028826 ∧ code e215621028826 = 2414644284378 := by decide
theorem cert_e215621028826 : check e215621028826 [] .sourceHead = true := by decide
def e215621029102 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e215621029102 : Closed e215621029102 ∧ code e215621029102 = 2414644284654 := by decide
theorem cert_e215621029102 : check e215621029102 [] .sourceHead = true := by decide
def e215621029110 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e215621029110 : Closed e215621029110 ∧ code e215621029110 = 2414644284662 := by decide
theorem cert_e215621029110 : check e215621029110 [] .sourceHead = true := by decide
def e215621029486 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e215621029486 : Closed e215621029486 ∧ code e215621029486 = 2414644285038 := by decide
theorem cert_e215621029486 : check e215621029486 [] .sourceHead = true := by decide
def e215621029498 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e215621029498 : Closed e215621029498 ∧ code e215621029498 = 2414644285050 := by decide
theorem cert_e215621029498 : check e215621029498 [] .sourceHead = true := by decide
def e215621029686 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e215621029686 : Closed e215621029686 ∧ code e215621029686 = 2414644285238 := by decide
theorem cert_e215621029686 : check e215621029686 [] .sourceHead = true := by decide
def e215621029690 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e215621029690 : Closed e215621029690 ∧ code e215621029690 = 2414644285242 := by decide
theorem cert_e215621029690 : check e215621029690 [] .sourceHead = true := by decide
def e215621569390 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e215621569390 : Closed e215621569390 ∧ code e215621569390 = 2414644824942 := by decide
theorem cert_e215621569390 : check e215621569390 [] .sourceHead = true := by decide
def e215621569398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e215621569398 : Closed e215621569398 ∧ code e215621569398 = 2414644824950 := by decide
theorem cert_e215621569398 : check e215621569398 [] .sourceHead = true := by decide
def e215621569454 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e215621569454 : Closed e215621569454 ∧ code e215621569454 = 2414644825006 := by decide
theorem cert_e215621569454 : check e215621569454 [] .sourceHead = true := by decide
def e215621569466 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e215621569466 : Closed e215621569466 ∧ code e215621569466 = 2414644825018 := by decide
theorem cert_e215621569466 : check e215621569466 [] .sourceHead = true := by decide
def e215621569494 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e215621569494 : Closed e215621569494 ∧ code e215621569494 = 2414644825046 := by decide
theorem cert_e215621569494 : check e215621569494 [] .sourceHead = true := by decide
def e215621569498 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e215621569498 : Closed e215621569498 ∧ code e215621569498 = 2414644825050 := by decide
theorem cert_e215621569498 : check e215621569498 [] .sourceHead = true := by decide
def e215621569774 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e215621569774 : Closed e215621569774 ∧ code e215621569774 = 2414644825326 := by decide
theorem cert_e215621569774 : check e215621569774 [] .sourceHead = true := by decide
def e215621569782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e215621569782 : Closed e215621569782 ∧ code e215621569782 = 2414644825334 := by decide
theorem cert_e215621569782 : check e215621569782 [] .sourceHead = true := by decide
def e215621570158 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e215621570158 : Closed e215621570158 ∧ code e215621570158 = 2414644825710 := by decide
theorem cert_e215621570158 : check e215621570158 [] .sourceHead = true := by decide
def e215621570170 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e215621570170 : Closed e215621570170 ∧ code e215621570170 = 2414644825722 := by decide
theorem cert_e215621570170 : check e215621570170 [] .sourceHead = true := by decide
def e215621570358 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e215621570358 : Closed e215621570358 ∧ code e215621570358 = 2414644825910 := by decide
theorem cert_e215621570358 : check e215621570358 [] .sourceHead = true := by decide
def e215621570362 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e215621570362 : Closed e215621570362 ∧ code e215621570362 = 2414644825914 := by decide
theorem cert_e215621570362 : check e215621570362 [] .sourceHead = true := by decide
def e552631987738 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552631987738 : Closed e552631987738 ∧ code e552631987738 = 2751655243290 := by decide
theorem cert_e552631987738 : check e552631987738 [[]] .width = true := by decide
def e552632512026 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552632512026 : Closed e552632512026 ∧ code e552632512026 = 2751655767578 := by decide
theorem cert_e552632512026 : check e552632512026 [[]] .width = true := by decide
def e552632544794 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552632544794 : Closed e552632544794 ∧ code e552632544794 = 2751655800346 := by decide
theorem cert_e552632544794 : check e552632544794 [[]] .width = true := by decide
def e552632546842 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552632546842 : Closed e552632546842 ∧ code e552632546842 = 2751655802394 := by decide
theorem cert_e552632546842 : check e552632546842 [[]] .width = true := by decide
def e552636182042 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552636182042 : Closed e552636182042 ∧ code e552636182042 = 2751659437594 := by decide
theorem cert_e552636182042 : check e552636182042 [[]] .width = true := by decide
def e552636968474 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552636968474 : Closed e552636968474 ∧ code e552636968474 = 2751660224026 := by decide
theorem cert_e552636968474 : check e552636968474 [[]] .width = true := by decide
def e552637017626 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552637017626 : Closed e552637017626 ∧ code e552637017626 = 2751660273178 := by decide
theorem cert_e552637017626 : check e552637017626 [[]] .width = true := by decide
def e552637020698 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552637020698 : Closed e552637020698 ∧ code e552637020698 = 2751660276250 := by decide
theorem cert_e552637020698 : check e552637020698 [[]] .width = true := by decide
def e552638803482 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552638803482 : Closed e552638803482 ∧ code e552638803482 = 2751662059034 := by decide
theorem cert_e552638803482 : check e552638803482 [[]] .width = true := by decide
def e552638836250 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552638836250 : Closed e552638836250 ∧ code e552638836250 = 2751662091802 := by decide
theorem cert_e552638836250 : check e552638836250 [[]] .width = true := by decide
def e552638838298 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552638838298 : Closed e552638838298 ∧ code e552638838298 = 2751662093850 := by decide
theorem cert_e552638838298 : check e552638838298 [[]] .width = true := by decide
def e552639065626 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552639065626 : Closed e552639065626 ∧ code e552639065626 = 2751662321178 := by decide
theorem cert_e552639065626 : check e552639065626 [[]] .width = true := by decide
def e552639114778 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552639114778 : Closed e552639114778 ∧ code e552639114778 = 2751662370330 := by decide
theorem cert_e552639114778 : check e552639114778 [[]] .width = true := by decide
def e552639117850 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552639117850 : Closed e552639117850 ∧ code e552639117850 = 2751662373402 := by decide
theorem cert_e552639117850 : check e552639117850 [[]] .width = true := by decide
def e552639229466 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552639229466 : Closed e552639229466 ∧ code e552639229466 = 2751662485018 := by decide
private def t_e552639229466 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552639229466 : ¬ IsSelfInterpreter e552639229466 :=
  wSource (t := t_e552639229466) (replay_sound (ps := []) (t := e552639229466) (by decide)) (by decide)
def e552639231514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552639231514 : Closed e552639231514 ∧ code e552639231514 = 2751662487066 := by decide
private def t_e552639231514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552639231514 : ¬ IsSelfInterpreter e552639231514 :=
  wSource (t := t_e552639231514) (replay_sound (ps := []) (t := e552639231514) (by decide)) (by decide)
def e552639245850 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552639245850 : Closed e552639245850 ∧ code e552639245850 = 2751662501402 := by decide
private def t_e552639245850 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552639245850 : ¬ IsSelfInterpreter e552639245850 :=
  wSource (t := t_e552639245850) (replay_sound (ps := []) (t := e552639245850) (by decide)) (by decide)
def e552639248922 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552639248922 : Closed e552639248922 ∧ code e552639248922 = 2751662504474 := by decide
private def t_e552639248922 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552639248922 : ¬ IsSelfInterpreter e552639248922 :=
  wSource (t := t_e552639248922) (replay_sound (ps := []) (t := e552639248922) (by decide)) (by decide)
def e552639256090 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552639256090 : Closed e552639256090 ∧ code e552639256090 = 2751662511642 := by decide
private def t_e552639256090 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552639256090 : ¬ IsSelfInterpreter e552639256090 :=
  wSource (t := t_e552639256090) (replay_sound (ps := []) (t := e552639256090) (by decide)) (by decide)
def e552639257114 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552639257114 : Closed e552639257114 ∧ code e552639257114 = 2751662512666 := by decide
private def t_e552639257114 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552639257114 : ¬ IsSelfInterpreter e552639257114 :=
  wSource (t := t_e552639257114) (replay_sound (ps := []) (t := e552639257114) (by decide)) (by decide)
def e552657153562 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552657153562 : Closed e552657153562 ∧ code e552657153562 = 2751680409114 := by decide
theorem cert_e552657153562 : check e552657153562 [[]] .width = true := by decide
def e552657677850 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552657677850 : Closed e552657677850 ∧ code e552657677850 = 2751680933402 := by decide
theorem cert_e552657677850 : check e552657677850 [[]] .width = true := by decide
def e552657710618 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552657710618 : Closed e552657710618 ∧ code e552657710618 = 2751680966170 := by decide
theorem cert_e552657710618 : check e552657710618 [[]] .width = true := by decide
def e552657712666 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552657712666 : Closed e552657712666 ∧ code e552657712666 = 2751680968218 := by decide
theorem cert_e552657712666 : check e552657712666 [[]] .width = true := by decide
def e552668687898 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552668687898 : Closed e552668687898 ∧ code e552668687898 = 2751691943450 := by decide
theorem cert_e552668687898 : check e552668687898 [[]] .width = true := by decide
def e552670457370 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552670457370 : Closed e552670457370 ∧ code e552670457370 = 2751693712922 := by decide
theorem cert_e552670457370 : check e552670457370 [[]] .width = true := by decide
def e552670560282 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552670560282 : Closed e552670560282 ∧ code e552670560282 = 2751693815834 := by decide
theorem cert_e552670560282 : check e552670560282 [[]] .width = true := by decide
def e552670560374 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552670560374 : Closed e552670560374 ∧ code e552670560374 = 2751693815926 := by decide
theorem cert_e552670560374 : check e552670560374 [[]] .width = true := by decide
def e552670560618 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552670560618 : Closed e552670560618 ∧ code e552670560618 = 2751693816170 := by decide
theorem cert_e552670560618 : check e552670560618 [[]] .width = true := by decide
def e552670560666 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552670560666 : Closed e552670560666 ∧ code e552670560666 = 2751693816218 := by decide
theorem cert_e552670560666 : check e552670560666 [[]] .width = true := by decide
def e552670561674 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552670561674 : Closed e552670561674 ∧ code e552670561674 = 2751693817226 := by decide
theorem cert_e552670561674 : check e552670561674 [[]] .width = true := by decide
def e552670561698 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552670561698 : Closed e552670561698 ∧ code e552670561698 = 2751693817250 := by decide
theorem cert_e552670561698 : check e552670561698 [[]] .width = true := by decide
def e552670561806 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552670561806 : Closed e552670561806 ∧ code e552670561806 = 2751693817358 := by decide
theorem cert_e552670561806 : check e552670561806 [[]] .width = true := by decide
def e552670561818 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552670561818 : Closed e552670561818 ∧ code e552670561818 = 2751693817370 := by decide
theorem cert_e552670561818 : check e552670561818 [[]] .width = true := by decide
def e552670561890 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552670561890 : Closed e552670561890 ∧ code e552670561890 = 2751693817442 := by decide
theorem cert_e552670561890 : check e552670561890 [[]] .width = true := by decide
def e552671833626 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552671833626 : Closed e552671833626 ∧ code e552671833626 = 2751695089178 := by decide
theorem cert_e552671833626 : check e552671833626 [[]] .width = true := by decide
def e552671866394 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552671866394 : Closed e552671866394 ∧ code e552671866394 = 2751695121946 := by decide
theorem cert_e552671866394 : check e552671866394 [[]] .width = true := by decide
def e552671868442 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552671868442 : Closed e552671868442 ∧ code e552671868442 = 2751695123994 := by decide
theorem cert_e552671868442 : check e552671868442 [[]] .width = true := by decide
def e552672554522 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552672554522 : Closed e552672554522 ∧ code e552672554522 = 2751695810074 := by decide
theorem cert_e552672554522 : check e552672554522 [[]] .width = true := by decide
def e552672657434 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552672657434 : Closed e552672657434 ∧ code e552672657434 = 2751695912986 := by decide
theorem cert_e552672657434 : check e552672657434 [[]] .width = true := by decide
def e552672657526 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552672657526 : Closed e552672657526 ∧ code e552672657526 = 2751695913078 := by decide
theorem cert_e552672657526 : check e552672657526 [[]] .width = true := by decide
def e552672657770 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552672657770 : Closed e552672657770 ∧ code e552672657770 = 2751695913322 := by decide
theorem cert_e552672657770 : check e552672657770 [[]] .width = true := by decide
def e552672657818 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552672657818 : Closed e552672657818 ∧ code e552672657818 = 2751695913370 := by decide
theorem cert_e552672657818 : check e552672657818 [[]] .width = true := by decide
def e552672658826 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552672658826 : Closed e552672658826 ∧ code e552672658826 = 2751695914378 := by decide
theorem cert_e552672658826 : check e552672658826 [[]] .width = true := by decide
def e552672658850 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552672658850 : Closed e552672658850 ∧ code e552672658850 = 2751695914402 := by decide
theorem cert_e552672658850 : check e552672658850 [[]] .width = true := by decide
def e552672658958 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552672658958 : Closed e552672658958 ∧ code e552672658958 = 2751695914510 := by decide
theorem cert_e552672658958 : check e552672658958 [[]] .width = true := by decide
def e552672658970 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552672658970 : Closed e552672658970 ∧ code e552672658970 = 2751695914522 := by decide
theorem cert_e552672658970 : check e552672658970 [[]] .width = true := by decide
def e552672659042 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552672659042 : Closed e552672659042 ∧ code e552672659042 = 2751695914594 := by decide
theorem cert_e552672659042 : check e552672659042 [[]] .width = true := by decide
def e552672751130 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552672751130 : Closed e552672751130 ∧ code e552672751130 = 2751696006682 := by decide
theorem cert_e552672751130 : check e552672751130 [[]] .width = true := by decide
def e552672753178 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552672753178 : Closed e552672753178 ∧ code e552672753178 = 2751696008730 := by decide
theorem cert_e552672753178 : check e552672753178 [[]] .width = true := by decide
def e552672788506 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552672788506 : Closed e552672788506 ∧ code e552672788506 = 2751696044058 := by decide
theorem cert_e552672788506 : check e552672788506 [[]] .width = true := by decide
def e552672788598 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552672788598 : Closed e552672788598 ∧ code e552672788598 = 2751696044150 := by decide
theorem cert_e552672788598 : check e552672788598 [[]] .width = true := by decide
def e552672788842 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552672788842 : Closed e552672788842 ∧ code e552672788842 = 2751696044394 := by decide
theorem cert_e552672788842 : check e552672788842 [[]] .width = true := by decide
def e552672788890 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552672788890 : Closed e552672788890 ∧ code e552672788890 = 2751696044442 := by decide
theorem cert_e552672788890 : check e552672788890 [[]] .width = true := by decide
def e552672789898 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552672789898 : Closed e552672789898 ∧ code e552672789898 = 2751696045450 := by decide
theorem cert_e552672789898 : check e552672789898 [[]] .width = true := by decide
def e552672789922 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552672789922 : Closed e552672789922 ∧ code e552672789922 = 2751696045474 := by decide
theorem cert_e552672789922 : check e552672789922 [[]] .width = true := by decide
def e552672790030 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552672790030 : Closed e552672790030 ∧ code e552672790030 = 2751696045582 := by decide
theorem cert_e552672790030 : check e552672790030 [[]] .width = true := by decide
def e552672790042 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552672790042 : Closed e552672790042 ∧ code e552672790042 = 2751696045594 := by decide
theorem cert_e552672790042 : check e552672790042 [[]] .width = true := by decide
def e552672790114 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552672790114 : Closed e552672790114 ∧ code e552672790114 = 2751696045666 := by decide
theorem cert_e552672790114 : check e552672790114 [[]] .width = true := by decide
def e552682319386 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552682319386 : Closed e552682319386 ∧ code e552682319386 = 2751705574938 := by decide
theorem cert_e552682319386 : check e552682319386 [[]] .width = true := by decide
def e552683105818 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552683105818 : Closed e552683105818 ∧ code e552683105818 = 2751706361370 := by decide
theorem cert_e552683105818 : check e552683105818 [[]] .width = true := by decide
def e552683154970 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552683154970 : Closed e552683154970 ∧ code e552683154970 = 2751706410522 := by decide
theorem cert_e552683154970 : check e552683154970 [[]] .width = true := by decide
def e552683158042 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552683158042 : Closed e552683158042 ∧ code e552683158042 = 2751706413594 := by decide
theorem cert_e552683158042 : check e552683158042 [[]] .width = true := by decide
def e552685465114 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552685465114 : Closed e552685465114 ∧ code e552685465114 = 2751708720666 := by decide
theorem cert_e552685465114 : check e552685465114 [[]] .width = true := by decide
def e552687234586 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552687234586 : Closed e552687234586 ∧ code e552687234586 = 2751710490138 := by decide
theorem cert_e552687234586 : check e552687234586 [[]] .width = true := by decide
def e552687337498 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552687337498 : Closed e552687337498 ∧ code e552687337498 = 2751710593050 := by decide
theorem cert_e552687337498 : check e552687337498 [[]] .width = true := by decide
def e552687337590 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552687337590 : Closed e552687337590 ∧ code e552687337590 = 2751710593142 := by decide
theorem cert_e552687337590 : check e552687337590 [[]] .width = true := by decide
def e552687337834 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552687337834 : Closed e552687337834 ∧ code e552687337834 = 2751710593386 := by decide
theorem cert_e552687337834 : check e552687337834 [[]] .width = true := by decide
def e552687337882 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552687337882 : Closed e552687337882 ∧ code e552687337882 = 2751710593434 := by decide
theorem cert_e552687337882 : check e552687337882 [[]] .width = true := by decide
def e552687338890 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552687338890 : Closed e552687338890 ∧ code e552687338890 = 2751710594442 := by decide
theorem cert_e552687338890 : check e552687338890 [[]] .width = true := by decide
def e552687338914 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552687338914 : Closed e552687338914 ∧ code e552687338914 = 2751710594466 := by decide
theorem cert_e552687338914 : check e552687338914 [[]] .width = true := by decide
def e552687339022 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552687339022 : Closed e552687339022 ∧ code e552687339022 = 2751710594574 := by decide
theorem cert_e552687339022 : check e552687339022 [[]] .width = true := by decide
def e552687339034 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552687339034 : Closed e552687339034 ∧ code e552687339034 = 2751710594586 := by decide
theorem cert_e552687339034 : check e552687339034 [[]] .width = true := by decide
def e552687339106 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552687339106 : Closed e552687339106 ∧ code e552687339106 = 2751710594658 := by decide
theorem cert_e552687339106 : check e552687339106 [[]] .width = true := by decide
def e552690183706 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552690183706 : Closed e552690183706 ∧ code e552690183706 = 2751713439258 := by decide
theorem cert_e552690183706 : check e552690183706 [[]] .width = true := by decide
def e552690232858 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552690232858 : Closed e552690232858 ∧ code e552690232858 = 2751713488410 := by decide
theorem cert_e552690232858 : check e552690232858 [[]] .width = true := by decide
def e552690235930 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552690235930 : Closed e552690235930 ∧ code e552690235930 = 2751713491482 := by decide
theorem cert_e552690235930 : check e552690235930 [[]] .width = true := by decide
def e552690380314 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552690380314 : Closed e552690380314 ∧ code e552690380314 = 2751713635866 := by decide
theorem cert_e552690380314 : check e552690380314 [[]] .width = true := by decide
def e552690483226 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552690483226 : Closed e552690483226 ∧ code e552690483226 = 2751713738778 := by decide
theorem cert_e552690483226 : check e552690483226 [[]] .width = true := by decide
def e552690483318 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552690483318 : Closed e552690483318 ∧ code e552690483318 = 2751713738870 := by decide
theorem cert_e552690483318 : check e552690483318 [[]] .width = true := by decide
def e552690483562 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552690483562 : Closed e552690483562 ∧ code e552690483562 = 2751713739114 := by decide
theorem cert_e552690483562 : check e552690483562 [[]] .width = true := by decide
def e552690483610 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552690483610 : Closed e552690483610 ∧ code e552690483610 = 2751713739162 := by decide
theorem cert_e552690483610 : check e552690483610 [[]] .width = true := by decide
def e552690484618 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552690484618 : Closed e552690484618 ∧ code e552690484618 = 2751713740170 := by decide
theorem cert_e552690484618 : check e552690484618 [[]] .width = true := by decide
def e552690484642 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552690484642 : Closed e552690484642 ∧ code e552690484642 = 2751713740194 := by decide
theorem cert_e552690484642 : check e552690484642 [[]] .width = true := by decide
def e552690484750 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552690484750 : Closed e552690484750 ∧ code e552690484750 = 2751713740302 := by decide
theorem cert_e552690484750 : check e552690484750 [[]] .width = true := by decide
def e552690484762 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552690484762 : Closed e552690484762 ∧ code e552690484762 = 2751713740314 := by decide
theorem cert_e552690484762 : check e552690484762 [[]] .width = true := by decide
def e552690484834 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552690484834 : Closed e552690484834 ∧ code e552690484834 = 2751713740386 := by decide
theorem cert_e552690484834 : check e552690484834 [[]] .width = true := by decide
def e552690675226 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552690675226 : Closed e552690675226 ∧ code e552690675226 = 2751713930778 := by decide
theorem cert_e552690675226 : check e552690675226 [[]] .width = true := by decide
end Blc.Floor41
