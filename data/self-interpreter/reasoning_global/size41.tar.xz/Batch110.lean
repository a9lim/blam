import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605602609214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 4)))))))))
theorem wire_e605602609214 : Closed e605602609214 ∧ code e605602609214 = 2804625864766 := by decide
theorem cert_e605602609214 : checkPay e605602609214 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602609262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605602609262 : Closed e605602609262 ∧ code e605602609262 = 2804625864814 := by decide
theorem cert_e605602609262 : check e605602609262 [[],[]] .chain = true := by decide
def e605602609270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605602609270 : Closed e605602609270 ∧ code e605602609270 = 2804625864822 := by decide
theorem cert_e605602609270 : check e605602609270 [[],[]] .chain = true := by decide
def e605602609274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605602609274 : Closed e605602609274 ∧ code e605602609274 = 2804625864826 := by decide
theorem cert_e605602609274 : check e605602609274 [[],[]] .chain = true := by decide
def e605602609514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605602609514 : Closed e605602609514 ∧ code e605602609514 = 2804625865066 := by decide
theorem cert_e605602609514 : check e605602609514 [[],[]] .chain = true := by decide
def e605602609538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605602609538 : Closed e605602609538 ∧ code e605602609538 = 2804625865090 := by decide
theorem cert_e605602609538 : check e605602609538 [[],[]] .chain = true := by decide
def e605602609550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605602609550 : Closed e605602609550 ∧ code e605602609550 = 2804625865102 := by decide
theorem cert_e605602609550 : check e605602609550 [[],[]] .chain = true := by decide
def e605602609562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605602609562 : Closed e605602609562 ∧ code e605602609562 = 2804625865114 := by decide
theorem cert_e605602609562 : check e605602609562 [[],[]] .chain = true := by decide
def e605602609606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605602609606 : Closed e605602609606 ∧ code e605602609606 = 2804625865158 := by decide
theorem cert_e605602609606 : check e605602609606 [[],[]] .chain = true := by decide
def e605602609634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605602609634 : Closed e605602609634 ∧ code e605602609634 = 2804625865186 := by decide
theorem cert_e605602609634 : checkPay e605602609634 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602609646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 2))))))))
theorem wire_e605602609646 : Closed e605602609646 ∧ code e605602609646 = 2804625865198 := by decide
theorem cert_e605602609646 : checkPay e605602609646 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602646894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605602646894 : Closed e605602646894 ∧ code e605602646894 = 2804625902446 := by decide
theorem cert_e605602646894 : check e605602646894 [[],[]] .smaller = true := by decide
def e605602646902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605602646902 : Closed e605602646902 ∧ code e605602646902 = 2804625902454 := by decide
theorem cert_e605602646902 : check e605602646902 [[],[]] .smaller = true := by decide
def e605602646958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605602646958 : Closed e605602646958 ∧ code e605602646958 = 2804625902510 := by decide
theorem cert_e605602646958 : check e605602646958 [[],[]] .smaller = true := by decide
def e605602646970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605602646970 : Closed e605602646970 ∧ code e605602646970 = 2804625902522 := by decide
theorem cert_e605602646970 : check e605602646970 [[],[]] .smaller = true := by decide
def e605602646998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605602646998 : Closed e605602646998 ∧ code e605602646998 = 2804625902550 := by decide
theorem cert_e605602646998 : check e605602646998 [[],[]] .smaller = true := by decide
def e605602647002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605602647002 : Closed e605602647002 ∧ code e605602647002 = 2804625902554 := by decide
theorem cert_e605602647002 : check e605602647002 [[],[]] .smaller = true := by decide
def e605602647278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605602647278 : Closed e605602647278 ∧ code e605602647278 = 2804625902830 := by decide
theorem cert_e605602647278 : check e605602647278 [[],[]] .smaller = true := by decide
def e605602647286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605602647286 : Closed e605602647286 ∧ code e605602647286 = 2804625902838 := by decide
theorem cert_e605602647286 : check e605602647286 [[],[]] .smaller = true := by decide
def e605602647614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e605602647614 : Closed e605602647614 ∧ code e605602647614 = 2804625903166 := by decide
theorem cert_e605602647614 : check e605602647614 [[],[]] .chain = true := by decide
def e605602647662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605602647662 : Closed e605602647662 ∧ code e605602647662 = 2804625903214 := by decide
theorem cert_e605602647662 : check e605602647662 [[],[]] .smaller = true := by decide
def e605602647674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605602647674 : Closed e605602647674 ∧ code e605602647674 = 2804625903226 := by decide
theorem cert_e605602647674 : check e605602647674 [[],[]] .smaller = true := by decide
def e605602647862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602647862 : Closed e605602647862 ∧ code e605602647862 = 2804625903414 := by decide
theorem cert_e605602647862 : check e605602647862 [[],[]] .smaller = true := by decide
def e605602647866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602647866 : Closed e605602647866 ∧ code e605602647866 = 2804625903418 := by decide
theorem cert_e605602647866 : check e605602647866 [[],[]] .smaller = true := by decide
def e605602647950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e605602647950 : Closed e605602647950 ∧ code e605602647950 = 2804625903502 := by decide
theorem cert_e605602647950 : check e605602647950 [[],[]] .chain = true := by decide
def e605602655342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605602655342 : Closed e605602655342 ∧ code e605602655342 = 2804625910894 := by decide
theorem cert_e605602655342 : check e605602655342 [[],[]] .chain = true := by decide
def e605602655354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605602655354 : Closed e605602655354 ∧ code e605602655354 = 2804625910906 := by decide
theorem cert_e605602655354 : check e605602655354 [[],[]] .chain = true := by decide
def e605602655518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605602655518 : Closed e605602655518 ∧ code e605602655518 = 2804625911070 := by decide
theorem cert_e605602655518 : check e605602655518 [[],[]] .chain = true := by decide
def e605602655686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605602655686 : Closed e605602655686 ∧ code e605602655686 = 2804625911238 := by decide
theorem cert_e605602655686 : check e605602655686 [[],[]] .chain = true := by decide
def e605602656026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e605602656026 : Closed e605602656026 ∧ code e605602656026 = 2804625911578 := by decide
theorem cert_e605602656026 : check e605602656026 [[],[]] .chain = true := by decide
def e605602656070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e605602656070 : Closed e605602656070 ∧ code e605602656070 = 2804625911622 := by decide
theorem cert_e605602656070 : check e605602656070 [[],[]] .chain = true := by decide
def e605602656478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e605602656478 : Closed e605602656478 ∧ code e605602656478 = 2804625912030 := by decide
theorem cert_e605602656478 : check e605602656478 [[],[]] .chain = true := by decide
def e605602656506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e605602656506 : Closed e605602656506 ∧ code e605602656506 = 2804625912058 := by decide
theorem cert_e605602656506 : check e605602656506 [[],[]] .chain = true := by decide
def e605602657054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605602657054 : Closed e605602657054 ∧ code e605602657054 = 2804625912606 := by decide
theorem cert_e605602657054 : check e605602657054 [[],[]] .chain = true := by decide
def e605602657222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605602657222 : Closed e605602657222 ∧ code e605602657222 = 2804625912774 := by decide
theorem cert_e605602657222 : check e605602657222 [[],[]] .chain = true := by decide
def e605602659382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e605602659382 : Closed e605602659382 ∧ code e605602659382 = 2804625914934 := by decide
theorem cert_e605602659382 : check e605602659382 [[],[]] .chain = true := by decide
def e605602659386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e605602659386 : Closed e605602659386 ∧ code e605602659386 = 2804625914938 := by decide
theorem cert_e605602659386 : check e605602659386 [[],[]] .chain = true := by decide
def e605602659526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e605602659526 : Closed e605602659526 ∧ code e605602659526 = 2804625915078 := by decide
theorem cert_e605602659526 : check e605602659526 [[],[]] .chain = true := by decide
def e605602677230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e605602677230 : Closed e605602677230 ∧ code e605602677230 = 2804625932782 := by decide
theorem cert_e605602677230 : check e605602677230 [[],[]] .chain = true := by decide
def e605602678198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e605602678198 : Closed e605602678198 ∧ code e605602678198 = 2804625933750 := by decide
theorem cert_e605602678198 : check e605602678198 [[],[]] .chain = true := by decide
def e605602678230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e605602678230 : Closed e605602678230 ∧ code e605602678230 = 2804625933782 := by decide
theorem cert_e605602678230 : check e605602678230 [[],[]] .chain = true := by decide
def e605602678234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e605602678234 : Closed e605602678234 ∧ code e605602678234 = 2804625933786 := by decide
theorem cert_e605602678234 : check e605602678234 [[],[]] .chain = true := by decide
def e605602678390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e605602678390 : Closed e605602678390 ∧ code e605602678390 = 2804625933942 := by decide
theorem cert_e605602678390 : check e605602678390 [[],[]] .chain = true := by decide
def e605602678558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605602678558 : Closed e605602678558 ∧ code e605602678558 = 2804625934110 := by decide
theorem cert_e605602678558 : check e605602678558 [[],[]] .chain = true := by decide
def e605602678582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602678582 : Closed e605602678582 ∧ code e605602678582 = 2804625934134 := by decide
theorem cert_e605602678582 : check e605602678582 [[],[]] .chain = true := by decide
def e605602678586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602678586 : Closed e605602678586 ∧ code e605602678586 = 2804625934138 := by decide
theorem cert_e605602678586 : check e605602678586 [[],[]] .chain = true := by decide
def e605602678670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605602678670 : Closed e605602678670 ∧ code e605602678670 = 2804625934222 := by decide
theorem cert_e605602678670 : check e605602678670 [[],[]] .chain = true := by decide
def e605602682282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605602682282 : Closed e605602682282 ∧ code e605602682282 = 2804625937834 := by decide
theorem cert_e605602682282 : check e605602682282 [[],[]] .chain = true := by decide
def e605602682378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605602682378 : Closed e605602682378 ∧ code e605602682378 = 2804625937930 := by decide
theorem cert_e605602682378 : check e605602682378 [[],[]] .chain = true := by decide
def e605602682414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605602682414 : Closed e605602682414 ∧ code e605602682414 = 2804625937966 := by decide
theorem cert_e605602682414 : checkPay e605602682414 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602682422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605602682422 : Closed e605602682422 ∧ code e605602682422 = 2804625937974 := by decide
theorem cert_e605602682422 : check e605602682422 [[],[]] .chain = true := by decide
def e605602682426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605602682426 : Closed e605602682426 ∧ code e605602682426 = 2804625937978 := by decide
theorem cert_e605602682426 : check e605602682426 [[],[]] .chain = true := by decide
def e605602682474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605602682474 : Closed e605602682474 ∧ code e605602682474 = 2804625938026 := by decide
theorem cert_e605602682474 : check e605602682474 [[],[]] .chain = true := by decide
def e605602682498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605602682498 : Closed e605602682498 ∧ code e605602682498 = 2804625938050 := by decide
theorem cert_e605602682498 : check e605602682498 [[],[]] .chain = true := by decide
def e605602682510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605602682510 : Closed e605602682510 ∧ code e605602682510 = 2804625938062 := by decide
theorem cert_e605602682510 : check e605602682510 [[],[]] .chain = true := by decide
def e605602682522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605602682522 : Closed e605602682522 ∧ code e605602682522 = 2804625938074 := by decide
theorem cert_e605602682522 : check e605602682522 [[],[]] .chain = true := by decide
def e605602682566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605602682566 : Closed e605602682566 ∧ code e605602682566 = 2804625938118 := by decide
theorem cert_e605602682566 : check e605602682566 [[],[]] .chain = true := by decide
def e605602682594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605602682594 : Closed e605602682594 ∧ code e605602682594 = 2804625938146 := by decide
theorem cert_e605602682594 : checkPay e605602682594 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602682606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e605602682606 : Closed e605602682606 ∧ code e605602682606 = 2804625938158 := by decide
theorem cert_e605602682606 : checkPay e605602682606 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602682650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e605602682650 : Closed e605602682650 ∧ code e605602682650 = 2804625938202 := by decide
theorem cert_e605602682650 : check e605602682650 [[],[]] .chain = true := by decide
def e605602682694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e605602682694 : Closed e605602682694 ∧ code e605602682694 = 2804625938246 := by decide
theorem cert_e605602682694 : check e605602682694 [[],[]] .chain = true := by decide
def e605602682762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605602682762 : Closed e605602682762 ∧ code e605602682762 = 2804625938314 := by decide
theorem cert_e605602682762 : checkPay e605602682762 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602682786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605602682786 : Closed e605602682786 ∧ code e605602682786 = 2804625938338 := by decide
theorem cert_e605602682786 : checkPay e605602682786 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602682798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e605602682798 : Closed e605602682798 ∧ code e605602682798 = 2804625938350 := by decide
theorem cert_e605602682798 : checkPay e605602682798 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602682810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e605602682810 : Closed e605602682810 ∧ code e605602682810 = 2804625938362 := by decide
theorem cert_e605602682810 : checkPay e605602682810 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602682906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605602682906 : Closed e605602682906 ∧ code e605602682906 = 2804625938458 := by decide
theorem cert_e605602682906 : checkPay e605602682906 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602682942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e605602682942 : Closed e605602682942 ∧ code e605602682942 = 2804625938494 := by decide
theorem cert_e605602682942 : checkPay e605602682942 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602682990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605602682990 : Closed e605602682990 ∧ code e605602682990 = 2804625938542 := by decide
theorem cert_e605602682990 : check e605602682990 [[],[]] .chain = true := by decide
def e605602682998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605602682998 : Closed e605602682998 ∧ code e605602682998 = 2804625938550 := by decide
theorem cert_e605602682998 : check e605602682998 [[],[]] .chain = true := by decide
def e605602683002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605602683002 : Closed e605602683002 ∧ code e605602683002 = 2804625938554 := by decide
theorem cert_e605602683002 : check e605602683002 [[],[]] .chain = true := by decide
def e605602683242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605602683242 : Closed e605602683242 ∧ code e605602683242 = 2804625938794 := by decide
theorem cert_e605602683242 : check e605602683242 [[],[]] .chain = true := by decide
def e605602683266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605602683266 : Closed e605602683266 ∧ code e605602683266 = 2804625938818 := by decide
theorem cert_e605602683266 : check e605602683266 [[],[]] .chain = true := by decide
def e605602683278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605602683278 : Closed e605602683278 ∧ code e605602683278 = 2804625938830 := by decide
theorem cert_e605602683278 : check e605602683278 [[],[]] .chain = true := by decide
def e605602683290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605602683290 : Closed e605602683290 ∧ code e605602683290 = 2804625938842 := by decide
theorem cert_e605602683290 : check e605602683290 [[],[]] .chain = true := by decide
def e605602683334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605602683334 : Closed e605602683334 ∧ code e605602683334 = 2804625938886 := by decide
theorem cert_e605602683334 : check e605602683334 [[],[]] .chain = true := by decide
def e605602683362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605602683362 : Closed e605602683362 ∧ code e605602683362 = 2804625938914 := by decide
theorem cert_e605602683362 : checkPay e605602683362 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602683374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e605602683374 : Closed e605602683374 ∧ code e605602683374 = 2804625938926 := by decide
theorem cert_e605602683374 : checkPay e605602683374 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602683958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e605602683958 : Closed e605602683958 ∧ code e605602683958 = 2804625939510 := by decide
theorem cert_e605602683958 : check e605602683958 [[],[]] .chain = true := by decide
def e605602683962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e605602683962 : Closed e605602683962 ∧ code e605602683962 = 2804625939514 := by decide
theorem cert_e605602683962 : check e605602683962 [[],[]] .chain = true := by decide
def e605602684102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e605602684102 : Closed e605602684102 ∧ code e605602684102 = 2804625939654 := by decide
theorem cert_e605602684102 : check e605602684102 [[],[]] .chain = true := by decide
def e605602684430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e605602684430 : Closed e605602684430 ∧ code e605602684430 = 2804625939982 := by decide
theorem cert_e605602684430 : checkPay e605602684430 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602684514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605602684514 : Closed e605602684514 ∧ code e605602684514 = 2804625940066 := by decide
theorem cert_e605602684514 : checkPay e605602684514 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602684526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e605602684526 : Closed e605602684526 ∧ code e605602684526 = 2804625940078 := by decide
theorem cert_e605602684526 : checkPay e605602684526 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602684538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e605602684538 : Closed e605602684538 ∧ code e605602684538 = 2804625940090 := by decide
theorem cert_e605602684538 : checkPay e605602684538 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602712886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602712886 : Closed e605602712886 ∧ code e605602712886 = 2804625968438 := by decide
theorem cert_e605602712886 : check e605602712886 [[],[],[.under,.under,.left]] .width = true := by decide
def e605602712890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602712890 : Closed e605602712890 ∧ code e605602712890 = 2804625968442 := by decide
theorem cert_e605602712890 : check e605602712890 [[],[],[.under,.under,.left]] .width = true := by decide
def e605602713462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 2))))) (.var 1))))))
theorem wire_e605602713462 : Closed e605602713462 ∧ code e605602713462 = 2804625969014 := by decide
theorem cert_e605602713462 : check e605602713462 [[],[]] .chain = true := by decide
def e605602713466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 3))))) (.var 0))))))
theorem wire_e605602713466 : Closed e605602713466 ∧ code e605602713466 = 2804625969018 := by decide
theorem cert_e605602713466 : check e605602713466 [[],[]] .chain = true := by decide
def e605602713530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 2))))) (.var 0))))))
theorem wire_e605602713530 : Closed e605602713530 ∧ code e605602713530 = 2804625969082 := by decide
theorem cert_e605602713530 : check e605602713530 [[],[]] .chain = true := by decide
def e605602714326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e605602714326 : Closed e605602714326 ∧ code e605602714326 = 2804625969878 := by decide
theorem cert_e605602714326 : check e605602714326 [[],[]] .chain = true := by decide
def e605602714330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e605602714330 : Closed e605602714330 ∧ code e605602714330 = 2804625969882 := by decide
theorem cert_e605602714330 : check e605602714330 [[],[]] .chain = true := by decide
def e605602714346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e605602714346 : Closed e605602714346 ∧ code e605602714346 = 2804625969898 := by decide
theorem cert_e605602714346 : check e605602714346 [[],[]] .chain = true := by decide
def e605602714422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e605602714422 : Closed e605602714422 ∧ code e605602714422 = 2804625969974 := by decide
theorem cert_e605602714422 : check e605602714422 [[],[]] .chain = true := by decide
def e605602714426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e605602714426 : Closed e605602714426 ∧ code e605602714426 = 2804625969978 := by decide
theorem cert_e605602714426 : check e605602714426 [[],[]] .chain = true := by decide
def e605602714522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e605602714522 : Closed e605602714522 ∧ code e605602714522 = 2804625970074 := by decide
theorem cert_e605602714522 : check e605602714522 [[],[]] .chain = true := by decide
def e605602716910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602716910 : Closed e605602716910 ∧ code e605602716910 = 2804625972462 := by decide
theorem cert_e605602716910 : check e605602716910 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602716918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602716918 : Closed e605602716918 ∧ code e605602716918 = 2804625972470 := by decide
theorem cert_e605602716918 : check e605602716918 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602717294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602717294 : Closed e605602717294 ∧ code e605602717294 = 2804625972846 := by decide
theorem cert_e605602717294 : check e605602717294 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602717306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602717306 : Closed e605602717306 ∧ code e605602717306 = 2804625972858 := by decide
theorem cert_e605602717306 : check e605602717306 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602717494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602717494 : Closed e605602717494 ∧ code e605602717494 = 2804625973046 := by decide
theorem cert_e605602717494 : check e605602717494 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602717498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602717498 : Closed e605602717498 ∧ code e605602717498 = 2804625973050 := by decide
theorem cert_e605602717498 : check e605602717498 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602721206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.var 1))))))
theorem wire_e605602721206 : Closed e605602721206 ∧ code e605602721206 = 2804625976758 := by decide
theorem cert_e605602721206 : check e605602721206 [[],[]] .chain = true := by decide
def e605602721210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e605602721210 : Closed e605602721210 ∧ code e605602721210 = 2804625976762 := by decide
theorem cert_e605602721210 : check e605602721210 [[],[]] .chain = true := by decide
def e605602721242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e605602721242 : Closed e605602721242 ∧ code e605602721242 = 2804625976794 := by decide
theorem cert_e605602721242 : check e605602721242 [[],[]] .chain = true := by decide
def e605602721462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e605602721462 : Closed e605602721462 ∧ code e605602721462 = 2804625977014 := by decide
theorem cert_e605602721462 : check e605602721462 [[],[]] .chain = true := by decide
def e605602721466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e605602721466 : Closed e605602721466 ∧ code e605602721466 = 2804625977018 := by decide
theorem cert_e605602721466 : check e605602721466 [[],[]] .chain = true := by decide
def e605602721494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e605602721494 : Closed e605602721494 ∧ code e605602721494 = 2804625977046 := by decide
theorem cert_e605602721494 : check e605602721494 [[],[]] .chain = true := by decide
def e605602721514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e605602721514 : Closed e605602721514 ∧ code e605602721514 = 2804625977066 := by decide
theorem cert_e605602721514 : check e605602721514 [[],[]] .chain = true := by decide
def e605602721626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e605602721626 : Closed e605602721626 ∧ code e605602721626 = 2804625977178 := by decide
theorem cert_e605602721626 : check e605602721626 [[],[]] .chain = true := by decide
def e605602721642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e605602721642 : Closed e605602721642 ∧ code e605602721642 = 2804625977194 := by decide
theorem cert_e605602721642 : check e605602721642 [[],[]] .chain = true := by decide
def e605602722742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.var 1))))))
theorem wire_e605602722742 : Closed e605602722742 ∧ code e605602722742 = 2804625978294 := by decide
theorem cert_e605602722742 : check e605602722742 [[],[]] .chain = true := by decide
def e605602722746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e605602722746 : Closed e605602722746 ∧ code e605602722746 = 2804625978298 := by decide
theorem cert_e605602722746 : check e605602722746 [[],[]] .chain = true := by decide
def e605602722778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e605602722778 : Closed e605602722778 ∧ code e605602722778 = 2804625978330 := by decide
theorem cert_e605602722778 : check e605602722778 [[],[]] .chain = true := by decide
def e605602723446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 1)))))))
theorem wire_e605602723446 : Closed e605602723446 ∧ code e605602723446 = 2804625978998 := by decide
theorem cert_e605602723446 : check e605602723446 [[],[]] .chain = true := by decide
def e605602723638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602723638 : Closed e605602723638 ∧ code e605602723638 = 2804625979190 := by decide
theorem cert_e605602723638 : check e605602723638 [[],[]] .chain = true := by decide
def e605602723642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602723642 : Closed e605602723642 ∧ code e605602723642 = 2804625979194 := by decide
theorem cert_e605602723642 : check e605602723642 [[],[]] .chain = true := by decide
def e605602724086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 1))))))
theorem wire_e605602724086 : Closed e605602724086 ∧ code e605602724086 = 2804625979638 := by decide
theorem cert_e605602724086 : check e605602724086 [[],[]] .chain = true := by decide
def e605602724278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e605602724278 : Closed e605602724278 ∧ code e605602724278 = 2804625979830 := by decide
theorem cert_e605602724278 : check e605602724278 [[],[]] .chain = true := by decide
def e605602724282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e605602724282 : Closed e605602724282 ∧ code e605602724282 = 2804625979834 := by decide
theorem cert_e605602724282 : check e605602724282 [[],[]] .chain = true := by decide
def e605602724310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e605602724310 : Closed e605602724310 ∧ code e605602724310 = 2804625979862 := by decide
theorem cert_e605602724310 : check e605602724310 [[],[]] .chain = true := by decide
def e605602724330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e605602724330 : Closed e605602724330 ∧ code e605602724330 = 2804625979882 := by decide
theorem cert_e605602724330 : check e605602724330 [[],[]] .chain = true := by decide
def e605602724470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 1)))))))
theorem wire_e605602724470 : Closed e605602724470 ∧ code e605602724470 = 2804625980022 := by decide
theorem cert_e605602724470 : check e605602724470 [[],[]] .chain = true := by decide
def e605602724662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602724662 : Closed e605602724662 ∧ code e605602724662 = 2804625980214 := by decide
theorem cert_e605602724662 : check e605602724662 [[],[]] .chain = true := by decide
def e605602724666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602724666 : Closed e605602724666 ∧ code e605602724666 = 2804625980218 := by decide
theorem cert_e605602724666 : check e605602724666 [[],[]] .chain = true := by decide
def e605602724750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e605602724750 : Closed e605602724750 ∧ code e605602724750 = 2804625980302 := by decide
theorem cert_e605602724750 : check e605602724750 [[],[]] .chain = true := by decide
def e605602724762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602724762 : Closed e605602724762 ∧ code e605602724762 = 2804625980314 := by decide
theorem cert_e605602724762 : check e605602724762 [[],[]] .chain = true := by decide
def e605602724982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))) (.var 1))))))
theorem wire_e605602724982 : Closed e605602724982 ∧ code e605602724982 = 2804625980534 := by decide
theorem cert_e605602724982 : check e605602724982 [[],[]] .chain = true := by decide
def e605602724986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 3))))) (.var 0))))))
theorem wire_e605602724986 : Closed e605602724986 ∧ code e605602724986 = 2804625980538 := by decide
theorem cert_e605602724986 : check e605602724986 [[],[]] .chain = true := by decide
def e605602725082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e605602725082 : Closed e605602725082 ∧ code e605602725082 = 2804625980634 := by decide
theorem cert_e605602725082 : check e605602725082 [[],[]] .chain = true := by decide
def e605602725098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e605602725098 : Closed e605602725098 ∧ code e605602725098 = 2804625980650 := by decide
theorem cert_e605602725098 : check e605602725098 [[],[]] .chain = true := by decide
def e605602725174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602725174 : Closed e605602725174 ∧ code e605602725174 = 2804625980726 := by decide
theorem cert_e605602725174 : check e605602725174 [[],[]] .chain = true := by decide
def e605602725178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602725178 : Closed e605602725178 ∧ code e605602725178 = 2804625980730 := by decide
theorem cert_e605602725178 : check e605602725178 [[],[]] .chain = true := by decide
def e605602725262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e605602725262 : Closed e605602725262 ∧ code e605602725262 = 2804625980814 := by decide
theorem cert_e605602725262 : check e605602725262 [[],[]] .chain = true := by decide
def e605602725274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602725274 : Closed e605602725274 ∧ code e605602725274 = 2804625980826 := by decide
theorem cert_e605602725274 : check e605602725274 [[],[]] .chain = true := by decide
def e605602725318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e605602725318 : Closed e605602725318 ∧ code e605602725318 = 2804625980870 := by decide
theorem cert_e605602725318 : check e605602725318 [[],[]] .chain = true := by decide
def e605602728814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605602728814 : Closed e605602728814 ∧ code e605602728814 = 2804625984366 := by decide
theorem cert_e605602728814 : check e605602728814 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602728822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605602728822 : Closed e605602728822 ∧ code e605602728822 = 2804625984374 := by decide
theorem cert_e605602728822 : check e605602728822 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602728878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605602728878 : Closed e605602728878 ∧ code e605602728878 = 2804625984430 := by decide
theorem cert_e605602728878 : check e605602728878 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602728890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605602728890 : Closed e605602728890 ∧ code e605602728890 = 2804625984442 := by decide
theorem cert_e605602728890 : check e605602728890 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602728918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605602728918 : Closed e605602728918 ∧ code e605602728918 = 2804625984470 := by decide
theorem cert_e605602728918 : check e605602728918 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602728922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605602728922 : Closed e605602728922 ∧ code e605602728922 = 2804625984474 := by decide
theorem cert_e605602728922 : check e605602728922 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602729198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605602729198 : Closed e605602729198 ∧ code e605602729198 = 2804625984750 := by decide
theorem cert_e605602729198 : check e605602729198 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602729206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605602729206 : Closed e605602729206 ∧ code e605602729206 = 2804625984758 := by decide
theorem cert_e605602729206 : check e605602729206 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602729582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605602729582 : Closed e605602729582 ∧ code e605602729582 = 2804625985134 := by decide
theorem cert_e605602729582 : check e605602729582 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602729594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605602729594 : Closed e605602729594 ∧ code e605602729594 = 2804625985146 := by decide
theorem cert_e605602729594 : check e605602729594 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602729782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605602729782 : Closed e605602729782 ∧ code e605602729782 = 2804625985334 := by decide
theorem cert_e605602729782 : check e605602729782 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602729786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605602729786 : Closed e605602729786 ∧ code e605602729786 = 2804625985338 := by decide
theorem cert_e605602729786 : check e605602729786 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602734574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e605602734574 : Closed e605602734574 ∧ code e605602734574 = 2804625990126 := by decide
theorem cert_e605602734574 : check e605602734574 [[],[]] .chain = true := by decide
def e605602735542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e605602735542 : Closed e605602735542 ∧ code e605602735542 = 2804625991094 := by decide
theorem cert_e605602735542 : check e605602735542 [[],[]] .chain = true := by decide
def e605602735574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e605602735574 : Closed e605602735574 ∧ code e605602735574 = 2804625991126 := by decide
theorem cert_e605602735574 : check e605602735574 [[],[]] .chain = true := by decide
def e605602735578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e605602735578 : Closed e605602735578 ∧ code e605602735578 = 2804625991130 := by decide
theorem cert_e605602735578 : check e605602735578 [[],[]] .chain = true := by decide
def e605602735734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e605602735734 : Closed e605602735734 ∧ code e605602735734 = 2804625991286 := by decide
theorem cert_e605602735734 : check e605602735734 [[],[]] .chain = true := by decide
def e605602735902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e605602735902 : Closed e605602735902 ∧ code e605602735902 = 2804625991454 := by decide
theorem cert_e605602735902 : check e605602735902 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602735926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e605602735926 : Closed e605602735926 ∧ code e605602735926 = 2804625991478 := by decide
theorem cert_e605602735926 : check e605602735926 [[],[]] .chain = true := by decide
def e605602735930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e605602735930 : Closed e605602735930 ∧ code e605602735930 = 2804625991482 := by decide
theorem cert_e605602735930 : check e605602735930 [[],[]] .chain = true := by decide
def e605602736014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e605602736014 : Closed e605602736014 ∧ code e605602736014 = 2804625991566 := by decide
theorem cert_e605602736014 : check e605602736014 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602738414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e605602738414 : Closed e605602738414 ∧ code e605602738414 = 2804625993966 := by decide
theorem cert_e605602738414 : check e605602738414 [[],[]] .chain = true := by decide
def e605602738422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e605602738422 : Closed e605602738422 ∧ code e605602738422 = 2804625993974 := by decide
theorem cert_e605602738422 : check e605602738422 [[],[]] .chain = true := by decide
def e605602738902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e605602738902 : Closed e605602738902 ∧ code e605602738902 = 2804625994454 := by decide
theorem cert_e605602738902 : check e605602738902 [[],[]] .chain = true := by decide
def e605602738906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e605602738906 : Closed e605602738906 ∧ code e605602738906 = 2804625994458 := by decide
theorem cert_e605602738906 : check e605602738906 [[],[]] .chain = true := by decide
end Blc.Floor41
