import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e565594337114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e565594337114 : Closed e565594337114 ∧ code e565594337114 = 2764617592666 := by decide
theorem cert_e565594337114 : check e565594337114 [[],[.under]] .three = true := by decide
def e565594337130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e565594337130 : Closed e565594337130 ∧ code e565594337130 = 2764617592682 := by decide
theorem cert_e565594337130 : check e565594337130 [[],[.under]] .three = true := by decide
def e565594338158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e565594338158 : Closed e565594338158 ∧ code e565594338158 = 2764617593710 := by decide
theorem cert_e565594338158 : check e565594338158 [[],[.under]] .three = true := by decide
def e565594338166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e565594338166 : Closed e565594338166 ∧ code e565594338166 = 2764617593718 := by decide
theorem cert_e565594338166 : check e565594338166 [[],[.under]] .three = true := by decide
def e565594338222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e565594338222 : Closed e565594338222 ∧ code e565594338222 = 2764617593774 := by decide
theorem cert_e565594338222 : check e565594338222 [[],[.under]] .three = true := by decide
def e565594338234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e565594338234 : Closed e565594338234 ∧ code e565594338234 = 2764617593786 := by decide
theorem cert_e565594338234 : check e565594338234 [[],[.under]] .three = true := by decide
def e565594338262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e565594338262 : Closed e565594338262 ∧ code e565594338262 = 2764617593814 := by decide
theorem cert_e565594338262 : check e565594338262 [[],[.under]] .three = true := by decide
def e565594338266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e565594338266 : Closed e565594338266 ∧ code e565594338266 = 2764617593818 := by decide
theorem cert_e565594338266 : check e565594338266 [[],[.under]] .three = true := by decide
def e565594338542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e565594338542 : Closed e565594338542 ∧ code e565594338542 = 2764617594094 := by decide
theorem cert_e565594338542 : check e565594338542 [[],[.under]] .three = true := by decide
def e565594338550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e565594338550 : Closed e565594338550 ∧ code e565594338550 = 2764617594102 := by decide
theorem cert_e565594338550 : check e565594338550 [[],[.under]] .three = true := by decide
def e565594338926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e565594338926 : Closed e565594338926 ∧ code e565594338926 = 2764617594478 := by decide
theorem cert_e565594338926 : check e565594338926 [[],[.under]] .three = true := by decide
def e565594338938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e565594338938 : Closed e565594338938 ∧ code e565594338938 = 2764617594490 := by decide
theorem cert_e565594338938 : check e565594338938 [[],[.under]] .three = true := by decide
def e565594339126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e565594339126 : Closed e565594339126 ∧ code e565594339126 = 2764617594678 := by decide
theorem cert_e565594339126 : check e565594339126 [[],[.under]] .three = true := by decide
def e565594339130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e565594339130 : Closed e565594339130 ∧ code e565594339130 = 2764617594682 := by decide
theorem cert_e565594339130 : check e565594339130 [[],[.under]] .three = true := by decide
def e565594339566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))
theorem wire_e565594339566 : Closed e565594339566 ∧ code e565594339566 = 2764617595118 := by decide
theorem cert_e565594339566 : check e565594339566 [[],[.under]] .three = true := by decide
def e565594339574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))
theorem wire_e565594339574 : Closed e565594339574 ∧ code e565594339574 = 2764617595126 := by decide
theorem cert_e565594339574 : check e565594339574 [[],[.under]] .three = true := by decide
def e565594339758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e565594339758 : Closed e565594339758 ∧ code e565594339758 = 2764617595310 := by decide
theorem cert_e565594339758 : check e565594339758 [[],[.under]] .three = true := by decide
def e565594339770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e565594339770 : Closed e565594339770 ∧ code e565594339770 = 2764617595322 := by decide
theorem cert_e565594339770 : check e565594339770 [[],[.under]] .three = true := by decide
def e565594339818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e565594339818 : Closed e565594339818 ∧ code e565594339818 = 2764617595370 := by decide
theorem cert_e565594339818 : check e565594339818 [[],[.under]] .three = true := by decide
def e565594339950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e565594339950 : Closed e565594339950 ∧ code e565594339950 = 2764617595502 := by decide
theorem cert_e565594339950 : check e565594339950 [[],[.under]] .three = true := by decide
def e565594339962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e565594339962 : Closed e565594339962 ∧ code e565594339962 = 2764617595514 := by decide
theorem cert_e565594339962 : check e565594339962 [[],[.under]] .three = true := by decide
def e565594340126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))
theorem wire_e565594340126 : Closed e565594340126 ∧ code e565594340126 = 2764617595678 := by decide
theorem cert_e565594340126 : check e565594340126 [[],[.under]] .three = true := by decide
def e565594340238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))
theorem wire_e565594340238 : Closed e565594340238 ∧ code e565594340238 = 2764617595790 := by decide
theorem cert_e565594340238 : check e565594340238 [[],[.under]] .three = true := by decide
def e565594340250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e565594340250 : Closed e565594340250 ∧ code e565594340250 = 2764617595802 := by decide
theorem cert_e565594340250 : check e565594340250 [[],[.under]] .three = true := by decide
def e565594340470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))
theorem wire_e565594340470 : Closed e565594340470 ∧ code e565594340470 = 2764617596022 := by decide
theorem cert_e565594340470 : check e565594340470 [[],[.under]] .three = true := by decide
def e565594340566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e565594340566 : Closed e565594340566 ∧ code e565594340566 = 2764617596118 := by decide
theorem cert_e565594340566 : check e565594340566 [[],[.under]] .three = true := by decide
def e565594340570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e565594340570 : Closed e565594340570 ∧ code e565594340570 = 2764617596122 := by decide
theorem cert_e565594340570 : check e565594340570 [[],[.under]] .three = true := by decide
def e565594340586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e565594340586 : Closed e565594340586 ∧ code e565594340586 = 2764617596138 := by decide
theorem cert_e565594340586 : check e565594340586 [[],[.under]] .three = true := by decide
def e565594340662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e565594340662 : Closed e565594340662 ∧ code e565594340662 = 2764617596214 := by decide
theorem cert_e565594340662 : check e565594340662 [[],[.under]] .three = true := by decide
def e565594340666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e565594340666 : Closed e565594340666 ∧ code e565594340666 = 2764617596218 := by decide
theorem cert_e565594340666 : check e565594340666 [[],[.under]] .three = true := by decide
def e565594340750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))
theorem wire_e565594340750 : Closed e565594340750 ∧ code e565594340750 = 2764617596302 := by decide
theorem cert_e565594340750 : check e565594340750 [[],[.under]] .three = true := by decide
def e565594340762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e565594340762 : Closed e565594340762 ∧ code e565594340762 = 2764617596314 := by decide
theorem cert_e565594340762 : check e565594340762 [[],[.under]] .three = true := by decide
def e565594342366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e565594342366 : Closed e565594342366 ∧ code e565594342366 = 2764617597918 := by decide
theorem cert_e565594342366 : check e565594342366 [[],[.under]] .three = true := by decide
def e565594342382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e565594342382 : Closed e565594342382 ∧ code e565594342382 = 2764617597934 := by decide
theorem cert_e565594342382 : check e565594342382 [[],[.under]] .three = true := by decide
def e565594344302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e565594344302 : Closed e565594344302 ∧ code e565594344302 = 2764617599854 := by decide
theorem cert_e565594344302 : check e565594344302 [[],[.under]] .three = true := by decide
def e565594344310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e565594344310 : Closed e565594344310 ∧ code e565594344310 = 2764617599862 := by decide
theorem cert_e565594344310 : check e565594344310 [[],[.under]] .three = true := by decide
def e565594344366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e565594344366 : Closed e565594344366 ∧ code e565594344366 = 2764617599918 := by decide
theorem cert_e565594344366 : check e565594344366 [[],[.under]] .three = true := by decide
def e565594344378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e565594344378 : Closed e565594344378 ∧ code e565594344378 = 2764617599930 := by decide
theorem cert_e565594344378 : check e565594344378 [[],[.under]] .three = true := by decide
def e565594344406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e565594344406 : Closed e565594344406 ∧ code e565594344406 = 2764617599958 := by decide
theorem cert_e565594344406 : check e565594344406 [[],[.under]] .three = true := by decide
def e565594344410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e565594344410 : Closed e565594344410 ∧ code e565594344410 = 2764617599962 := by decide
theorem cert_e565594344410 : check e565594344410 [[],[.under]] .three = true := by decide
def e565594344686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e565594344686 : Closed e565594344686 ∧ code e565594344686 = 2764617600238 := by decide
theorem cert_e565594344686 : check e565594344686 [[],[.under]] .three = true := by decide
def e565594344694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e565594344694 : Closed e565594344694 ∧ code e565594344694 = 2764617600246 := by decide
theorem cert_e565594344694 : check e565594344694 [[],[.under]] .three = true := by decide
def e565594345070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e565594345070 : Closed e565594345070 ∧ code e565594345070 = 2764617600622 := by decide
theorem cert_e565594345070 : check e565594345070 [[],[.under]] .three = true := by decide
def e565594345082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e565594345082 : Closed e565594345082 ∧ code e565594345082 = 2764617600634 := by decide
theorem cert_e565594345082 : check e565594345082 [[],[.under]] .three = true := by decide
def e565594345270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e565594345270 : Closed e565594345270 ∧ code e565594345270 = 2764617600822 := by decide
theorem cert_e565594345270 : check e565594345270 [[],[.under]] .three = true := by decide
def e565594345274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e565594345274 : Closed e565594345274 ∧ code e565594345274 = 2764617600826 := by decide
theorem cert_e565594345274 : check e565594345274 [[],[.under]] .three = true := by decide
def e565594350046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e565594350046 : Closed e565594350046 ∧ code e565594350046 = 2764617605598 := by decide
theorem cert_e565594350046 : check e565594350046 [[],[.under]] .three = true := by decide
def e565594350070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e565594350070 : Closed e565594350070 ∧ code e565594350070 = 2764617605622 := by decide
theorem cert_e565594350070 : check e565594350070 [[],[.under]] .three = true := by decide
def e565594351022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e565594351022 : Closed e565594351022 ∧ code e565594351022 = 2764617606574 := by decide
theorem cert_e565594351022 : check e565594351022 [[],[.under]] .three = true := by decide
def e565594351034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e565594351034 : Closed e565594351034 ∧ code e565594351034 = 2764617606586 := by decide
theorem cert_e565594351034 : check e565594351034 [[],[.under]] .three = true := by decide
def e565594351082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e565594351082 : Closed e565594351082 ∧ code e565594351082 = 2764617606634 := by decide
theorem cert_e565594351082 : check e565594351082 [[],[.under]] .three = true := by decide
def e565594351214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e565594351214 : Closed e565594351214 ∧ code e565594351214 = 2764617606766 := by decide
theorem cert_e565594351214 : check e565594351214 [[],[.under]] .three = true := by decide
def e565594351226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e565594351226 : Closed e565594351226 ∧ code e565594351226 = 2764617606778 := by decide
theorem cert_e565594351226 : check e565594351226 [[],[.under]] .three = true := by decide
def e565594351390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e565594351390 : Closed e565594351390 ∧ code e565594351390 = 2764617606942 := by decide
theorem cert_e565594351390 : check e565594351390 [[],[.under]] .three = true := by decide
def e565594351502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e565594351502 : Closed e565594351502 ∧ code e565594351502 = 2764617607054 := by decide
theorem cert_e565594351502 : check e565594351502 [[],[.under]] .three = true := by decide
def e565594351514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e565594351514 : Closed e565594351514 ∧ code e565594351514 = 2764617607066 := by decide
theorem cert_e565594351514 : check e565594351514 [[],[.under]] .three = true := by decide
def e565594353902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e565594353902 : Closed e565594353902 ∧ code e565594353902 = 2764617609454 := by decide
theorem cert_e565594353902 : check e565594353902 [[],[.under]] .three = true := by decide
def e565594353910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e565594353910 : Closed e565594353910 ∧ code e565594353910 = 2764617609462 := by decide
theorem cert_e565594353910 : check e565594353910 [[],[.under]] .three = true := by decide
def e565594354390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e565594354390 : Closed e565594354390 ∧ code e565594354390 = 2764617609942 := by decide
theorem cert_e565594354390 : check e565594354390 [[],[.under]] .three = true := by decide
def e565594354394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e565594354394 : Closed e565594354394 ∧ code e565594354394 = 2764617609946 := by decide
theorem cert_e565594354394 : check e565594354394 [[],[.under]] .three = true := by decide
def e565594354410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e565594354410 : Closed e565594354410 ∧ code e565594354410 = 2764617609962 := by decide
theorem cert_e565594354410 : check e565594354410 [[],[.under]] .three = true := by decide
def e565594354486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e565594354486 : Closed e565594354486 ∧ code e565594354486 = 2764617610038 := by decide
theorem cert_e565594354486 : check e565594354486 [[],[.under]] .three = true := by decide
def e565594354490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e565594354490 : Closed e565594354490 ∧ code e565594354490 = 2764617610042 := by decide
theorem cert_e565594354490 : check e565594354490 [[],[.under]] .three = true := by decide
def e565594354574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e565594354574 : Closed e565594354574 ∧ code e565594354574 = 2764617610126 := by decide
theorem cert_e565594354574 : check e565594354574 [[],[.under]] .three = true := by decide
def e565594354586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e565594354586 : Closed e565594354586 ∧ code e565594354586 = 2764617610138 := by decide
theorem cert_e565594354586 : check e565594354586 [[],[.under]] .three = true := by decide
def e565594445486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e565594445486 : Closed e565594445486 ∧ code e565594445486 = 2764617701038 := by decide
theorem cert_e565594445486 : check e565594445486 [[],[.under]] .three = true := by decide
def e565594445498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e565594445498 : Closed e565594445498 ∧ code e565594445498 = 2764617701050 := by decide
theorem cert_e565594445498 : check e565594445498 [[],[.under]] .three = true := by decide
def e565594445546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e565594445546 : Closed e565594445546 ∧ code e565594445546 = 2764617701098 := by decide
theorem cert_e565594445546 : check e565594445546 [[],[.under]] .three = true := by decide
def e565594445738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e565594445738 : Closed e565594445738 ∧ code e565594445738 = 2764617701290 := by decide
theorem cert_e565594445738 : check e565594445738 [[],[.under]] .three = true := by decide
def e565594446062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e565594446062 : Closed e565594446062 ∧ code e565594446062 = 2764617701614 := by decide
theorem cert_e565594446062 : check e565594446062 [[],[.under]] .three = true := by decide
def e565594446070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e565594446070 : Closed e565594446070 ∧ code e565594446070 = 2764617701622 := by decide
theorem cert_e565594446070 : check e565594446070 [[],[.under]] .three = true := by decide
def e565594446254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e565594446254 : Closed e565594446254 ∧ code e565594446254 = 2764617701806 := by decide
theorem cert_e565594446254 : check e565594446254 [[],[.under]] .three = true := by decide
def e565594446266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e565594446266 : Closed e565594446266 ∧ code e565594446266 = 2764617701818 := by decide
theorem cert_e565594446266 : check e565594446266 [[],[.under]] .three = true := by decide
def e565594446314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e565594446314 : Closed e565594446314 ∧ code e565594446314 = 2764617701866 := by decide
theorem cert_e565594446314 : check e565594446314 [[],[.under]] .three = true := by decide
def e565594446446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e565594446446 : Closed e565594446446 ∧ code e565594446446 = 2764617701998 := by decide
theorem cert_e565594446446 : check e565594446446 [[],[.under]] .three = true := by decide
def e565594446458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e565594446458 : Closed e565594446458 ∧ code e565594446458 = 2764617702010 := by decide
theorem cert_e565594446458 : check e565594446458 [[],[.under]] .three = true := by decide
def e565594446622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e565594446622 : Closed e565594446622 ∧ code e565594446622 = 2764617702174 := by decide
theorem cert_e565594446622 : check e565594446622 [[],[.under]] .three = true := by decide
def e565594446734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e565594446734 : Closed e565594446734 ∧ code e565594446734 = 2764617702286 := by decide
theorem cert_e565594446734 : check e565594446734 [[],[.under]] .three = true := by decide
def e565594446746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e565594446746 : Closed e565594446746 ∧ code e565594446746 = 2764617702298 := by decide
theorem cert_e565594446746 : check e565594446746 [[],[.under]] .three = true := by decide
def e565594446958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e565594446958 : Closed e565594446958 ∧ code e565594446958 = 2764617702510 := by decide
theorem cert_e565594446958 : check e565594446958 [[],[.under]] .three = true := by decide
def e565594446970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e565594446970 : Closed e565594446970 ∧ code e565594446970 = 2764617702522 := by decide
theorem cert_e565594446970 : check e565594446970 [[],[.under]] .three = true := by decide
def e565594447134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e565594447134 : Closed e565594447134 ∧ code e565594447134 = 2764617702686 := by decide
theorem cert_e565594447134 : check e565594447134 [[],[.under]] .three = true := by decide
def e565594447302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e565594447302 : Closed e565594447302 ∧ code e565594447302 = 2764617702854 := by decide
theorem cert_e565594447302 : check e565594447302 [[],[.under]] .three = true := by decide
def e565594447414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e565594447414 : Closed e565594447414 ∧ code e565594447414 = 2764617702966 := by decide
theorem cert_e565594447414 : check e565594447414 [[],[.under]] .three = true := by decide
def e565594447418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e565594447418 : Closed e565594447418 ∧ code e565594447418 = 2764617702970 := by decide
theorem cert_e565594447418 : check e565594447418 [[],[.under]] .three = true := by decide
def e565594447466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e565594447466 : Closed e565594447466 ∧ code e565594447466 = 2764617703018 := by decide
theorem cert_e565594447466 : check e565594447466 [[],[.under]] .three = true := by decide
def e565594447502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e565594447502 : Closed e565594447502 ∧ code e565594447502 = 2764617703054 := by decide
theorem cert_e565594447502 : check e565594447502 [[],[.under]] .three = true := by decide
def e565594447514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e565594447514 : Closed e565594447514 ∧ code e565594447514 = 2764617703066 := by decide
theorem cert_e565594447514 : check e565594447514 [[],[.under]] .three = true := by decide
def e565594447558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e565594447558 : Closed e565594447558 ∧ code e565594447558 = 2764617703110 := by decide
theorem cert_e565594447558 : check e565594447558 [[],[.under]] .three = true := by decide
def e565594448350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e565594448350 : Closed e565594448350 ∧ code e565594448350 = 2764617703902 := by decide
theorem cert_e565594448350 : check e565594448350 [[],[.under]] .three = true := by decide
def e565594448374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e565594448374 : Closed e565594448374 ∧ code e565594448374 = 2764617703926 := by decide
theorem cert_e565594448374 : check e565594448374 [[],[.under]] .three = true := by decide
def e565594449326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e565594449326 : Closed e565594449326 ∧ code e565594449326 = 2764617704878 := by decide
theorem cert_e565594449326 : check e565594449326 [[],[.under]] .three = true := by decide
def e565594449338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e565594449338 : Closed e565594449338 ∧ code e565594449338 = 2764617704890 := by decide
theorem cert_e565594449338 : check e565594449338 [[],[.under]] .three = true := by decide
def e565594449386 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e565594449386 : Closed e565594449386 ∧ code e565594449386 = 2764617704938 := by decide
theorem cert_e565594449386 : check e565594449386 [[],[.under]] .three = true := by decide
def e565594449518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e565594449518 : Closed e565594449518 ∧ code e565594449518 = 2764617705070 := by decide
theorem cert_e565594449518 : check e565594449518 [[],[.under]] .three = true := by decide
def e565594449530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e565594449530 : Closed e565594449530 ∧ code e565594449530 = 2764617705082 := by decide
theorem cert_e565594449530 : check e565594449530 [[],[.under]] .three = true := by decide
def e565594449694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e565594449694 : Closed e565594449694 ∧ code e565594449694 = 2764617705246 := by decide
theorem cert_e565594449694 : check e565594449694 [[],[.under]] .three = true := by decide
def e565594449806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e565594449806 : Closed e565594449806 ∧ code e565594449806 = 2764617705358 := by decide
theorem cert_e565594449806 : check e565594449806 [[],[.under]] .three = true := by decide
def e565594449818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e565594449818 : Closed e565594449818 ∧ code e565594449818 = 2764617705370 := by decide
theorem cert_e565594449818 : check e565594449818 [[],[.under]] .three = true := by decide
def e565594452766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e565594452766 : Closed e565594452766 ∧ code e565594452766 = 2764617708318 := by decide
theorem cert_e565594452766 : check e565594452766 [[],[.under]] .three = true := by decide
def e565594452934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e565594452934 : Closed e565594452934 ∧ code e565594452934 = 2764617708486 := by decide
theorem cert_e565594452934 : check e565594452934 [[],[.under]] .three = true := by decide
def e565594454134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e565594454134 : Closed e565594454134 ∧ code e565594454134 = 2764617709686 := by decide
theorem cert_e565594454134 : check e565594454134 [[],[.under]] .three = true := by decide
def e565594454378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e565594454378 : Closed e565594454378 ∧ code e565594454378 = 2764617709930 := by decide
theorem cert_e565594454378 : check e565594454378 [[],[.under]] .three = true := by decide
def e565594454414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e565594454414 : Closed e565594454414 ∧ code e565594454414 = 2764617709966 := by decide
theorem cert_e565594454414 : check e565594454414 [[],[.under]] .three = true := by decide
def e565594454426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e565594454426 : Closed e565594454426 ∧ code e565594454426 = 2764617709978 := by decide
theorem cert_e565594454426 : check e565594454426 [[],[.under]] .three = true := by decide
def e565594454470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e565594454470 : Closed e565594454470 ∧ code e565594454470 = 2764617710022 := by decide
theorem cert_e565594454470 : check e565594454470 [[],[.under]] .three = true := by decide
def e565594499926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e565594499926 : Closed e565594499926 ∧ code e565594499926 = 2764617755478 := by decide
theorem cert_e565594499926 : check e565594499926 [[],[.under]] .three = true := by decide
def e565594499930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e565594499930 : Closed e565594499930 ∧ code e565594499930 = 2764617755482 := by decide
theorem cert_e565594499930 : check e565594499930 [[],[.under]] .three = true := by decide
def e565594499946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e565594499946 : Closed e565594499946 ∧ code e565594499946 = 2764617755498 := by decide
theorem cert_e565594499946 : check e565594499946 [[],[.under]] .three = true := by decide
def e565594500010 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e565594500010 : Closed e565594500010 ∧ code e565594500010 = 2764617755562 := by decide
theorem cert_e565594500010 : check e565594500010 [[],[.under]] .three = true := by decide
def e565594500214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))
theorem wire_e565594500214 : Closed e565594500214 ∧ code e565594500214 = 2764617755766 := by decide
theorem cert_e565594500214 : check e565594500214 [[],[.under]] .three = true := by decide
def e565594500310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e565594500310 : Closed e565594500310 ∧ code e565594500310 = 2764617755862 := by decide
theorem cert_e565594500310 : check e565594500310 [[],[.under]] .three = true := by decide
def e565594500314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e565594500314 : Closed e565594500314 ∧ code e565594500314 = 2764617755866 := by decide
theorem cert_e565594500314 : check e565594500314 [[],[.under]] .three = true := by decide
def e565594500330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e565594500330 : Closed e565594500330 ∧ code e565594500330 = 2764617755882 := by decide
theorem cert_e565594500330 : check e565594500330 [[],[.under]] .three = true := by decide
def e565594500406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e565594500406 : Closed e565594500406 ∧ code e565594500406 = 2764617755958 := by decide
theorem cert_e565594500406 : check e565594500406 [[],[.under]] .three = true := by decide
def e565594500410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e565594500410 : Closed e565594500410 ∧ code e565594500410 = 2764617755962 := by decide
theorem cert_e565594500410 : check e565594500410 [[],[.under]] .three = true := by decide
def e565594500494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))
theorem wire_e565594500494 : Closed e565594500494 ∧ code e565594500494 = 2764617756046 := by decide
theorem cert_e565594500494 : check e565594500494 [[],[.under]] .three = true := by decide
def e565594500506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e565594500506 : Closed e565594500506 ∧ code e565594500506 = 2764617756058 := by decide
theorem cert_e565594500506 : check e565594500506 [[],[.under]] .three = true := by decide
def e565594500662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))
theorem wire_e565594500662 : Closed e565594500662 ∧ code e565594500662 = 2764617756214 := by decide
theorem cert_e565594500662 : check e565594500662 [[],[.under]] .three = true := by decide
def e565594500666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))
theorem wire_e565594500666 : Closed e565594500666 ∧ code e565594500666 = 2764617756218 := by decide
theorem cert_e565594500666 : check e565594500666 [[],[.under]] .three = true := by decide
def e565594500714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e565594500714 : Closed e565594500714 ∧ code e565594500714 = 2764617756266 := by decide
theorem cert_e565594500714 : check e565594500714 [[],[.under]] .three = true := by decide
def e565594500750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))
theorem wire_e565594500750 : Closed e565594500750 ∧ code e565594500750 = 2764617756302 := by decide
theorem cert_e565594500750 : check e565594500750 [[],[.under]] .three = true := by decide
def e565594500762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e565594500762 : Closed e565594500762 ∧ code e565594500762 = 2764617756314 := by decide
theorem cert_e565594500762 : check e565594500762 [[],[.under]] .three = true := by decide
def e565594500806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))
theorem wire_e565594500806 : Closed e565594500806 ∧ code e565594500806 = 2764617756358 := by decide
theorem cert_e565594500806 : check e565594500806 [[],[.under]] .three = true := by decide
def e565594501358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e565594501358 : Closed e565594501358 ∧ code e565594501358 = 2764617756910 := by decide
theorem cert_e565594501358 : check e565594501358 [[],[.under]] .three = true := by decide
def e565594501366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e565594501366 : Closed e565594501366 ∧ code e565594501366 = 2764617756918 := by decide
theorem cert_e565594501366 : check e565594501366 [[],[.under]] .three = true := by decide
def e565594501846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e565594501846 : Closed e565594501846 ∧ code e565594501846 = 2764617757398 := by decide
theorem cert_e565594501846 : check e565594501846 [[],[.under]] .three = true := by decide
def e565594501850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e565594501850 : Closed e565594501850 ∧ code e565594501850 = 2764617757402 := by decide
theorem cert_e565594501850 : check e565594501850 [[],[.under]] .three = true := by decide
def e565594501866 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e565594501866 : Closed e565594501866 ∧ code e565594501866 = 2764617757418 := by decide
theorem cert_e565594501866 : check e565594501866 [[],[.under]] .three = true := by decide
def e565594501942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e565594501942 : Closed e565594501942 ∧ code e565594501942 = 2764617757494 := by decide
theorem cert_e565594501942 : check e565594501942 [[],[.under]] .three = true := by decide
def e565594501946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e565594501946 : Closed e565594501946 ∧ code e565594501946 = 2764617757498 := by decide
theorem cert_e565594501946 : check e565594501946 [[],[.under]] .three = true := by decide
def e565594502030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e565594502030 : Closed e565594502030 ∧ code e565594502030 = 2764617757582 := by decide
theorem cert_e565594502030 : check e565594502030 [[],[.under]] .three = true := by decide
def e565594502042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e565594502042 : Closed e565594502042 ∧ code e565594502042 = 2764617757594 := by decide
theorem cert_e565594502042 : check e565594502042 [[],[.under]] .three = true := by decide
def e565594503286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e565594503286 : Closed e565594503286 ∧ code e565594503286 = 2764617758838 := by decide
theorem cert_e565594503286 : check e565594503286 [[],[.under]] .three = true := by decide
def e565594503530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e565594503530 : Closed e565594503530 ∧ code e565594503530 = 2764617759082 := by decide
theorem cert_e565594503530 : check e565594503530 [[],[.under]] .three = true := by decide
def e565594503566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e565594503566 : Closed e565594503566 ∧ code e565594503566 = 2764617759118 := by decide
theorem cert_e565594503566 : check e565594503566 [[],[.under]] .three = true := by decide
def e565594503578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e565594503578 : Closed e565594503578 ∧ code e565594503578 = 2764617759130 := by decide
theorem cert_e565594503578 : check e565594503578 [[],[.under]] .three = true := by decide
def e565594503622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e565594503622 : Closed e565594503622 ∧ code e565594503622 = 2764617759174 := by decide
theorem cert_e565594503622 : check e565594503622 [[],[.under]] .three = true := by decide
def e565596401082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e565596401082 : Closed e565596401082 ∧ code e565596401082 = 2764619656634 := by decide
theorem cert_e565596401082 : check e565596401082 [[],[.under]] .chain = true := by decide
def e565596401114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e565596401114 : Closed e565596401114 ∧ code e565596401114 = 2764619656666 := by decide
theorem cert_e565596401114 : check e565596401114 [[],[.under]] .chain = true := by decide
def e565596401338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e565596401338 : Closed e565596401338 ∧ code e565596401338 = 2764619656890 := by decide
theorem cert_e565596401338 : check e565596401338 [[],[.under]] .chain = true := by decide
def e565596401386 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e565596401386 : Closed e565596401386 ∧ code e565596401386 = 2764619656938 := by decide
theorem cert_e565596401386 : check e565596401386 [[],[.under]] .chain = true := by decide
def e565596401498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e565596401498 : Closed e565596401498 ∧ code e565596401498 = 2764619657050 := by decide
theorem cert_e565596401498 : check e565596401498 [[],[.under]] .chain = true := by decide
def e565596401514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e565596401514 : Closed e565596401514 ∧ code e565596401514 = 2764619657066 := by decide
theorem cert_e565596401514 : check e565596401514 [[],[.under]] .chain = true := by decide
def e565596402618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e565596402618 : Closed e565596402618 ∧ code e565596402618 = 2764619658170 := by decide
theorem cert_e565596402618 : check e565596402618 [[],[.under]] .chain = true := by decide
def e565596402650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e565596402650 : Closed e565596402650 ∧ code e565596402650 = 2764619658202 := by decide
theorem cert_e565596402650 : check e565596402650 [[],[.under]] .chain = true := by decide
def e565596404154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e565596404154 : Closed e565596404154 ∧ code e565596404154 = 2764619659706 := by decide
theorem cert_e565596404154 : check e565596404154 [[],[.under]] .chain = true := by decide
def e565596404202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e565596404202 : Closed e565596404202 ∧ code e565596404202 = 2764619659754 := by decide
theorem cert_e565596404202 : check e565596404202 [[],[.under]] .chain = true := by decide
def e565596404954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e565596404954 : Closed e565596404954 ∧ code e565596404954 = 2764619660506 := by decide
theorem cert_e565596404954 : check e565596404954 [[],[.under]] .chain = true := by decide
def e565596404970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e565596404970 : Closed e565596404970 ∧ code e565596404970 = 2764619660522 := by decide
theorem cert_e565596404970 : check e565596404970 [[],[.under]] .chain = true := by decide
def e565596457838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e565596457838 : Closed e565596457838 ∧ code e565596457838 = 2764619713390 := by decide
theorem cert_e565596457838 : check e565596457838 [[],[.under]] .chain = true := by decide
def e565596457846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e565596457846 : Closed e565596457846 ∧ code e565596457846 = 2764619713398 := by decide
theorem cert_e565596457846 : check e565596457846 [[],[.under]] .chain = true := by decide
def e565596457902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e565596457902 : Closed e565596457902 ∧ code e565596457902 = 2764619713454 := by decide
theorem cert_e565596457902 : check e565596457902 [[],[.under]] .chain = true := by decide
def e565596457914 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e565596457914 : Closed e565596457914 ∧ code e565596457914 = 2764619713466 := by decide
theorem cert_e565596457914 : check e565596457914 [[],[.under]] .chain = true := by decide
def e565596457942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e565596457942 : Closed e565596457942 ∧ code e565596457942 = 2764619713494 := by decide
theorem cert_e565596457942 : check e565596457942 [[],[.under]] .chain = true := by decide
def e565596457946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e565596457946 : Closed e565596457946 ∧ code e565596457946 = 2764619713498 := by decide
theorem cert_e565596457946 : check e565596457946 [[],[.under]] .chain = true := by decide
def e565596458222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e565596458222 : Closed e565596458222 ∧ code e565596458222 = 2764619713774 := by decide
theorem cert_e565596458222 : check e565596458222 [[],[.under]] .chain = true := by decide
def e565596458230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e565596458230 : Closed e565596458230 ∧ code e565596458230 = 2764619713782 := by decide
theorem cert_e565596458230 : check e565596458230 [[],[.under]] .chain = true := by decide
def e565596458606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e565596458606 : Closed e565596458606 ∧ code e565596458606 = 2764619714158 := by decide
theorem cert_e565596458606 : check e565596458606 [[],[.under]] .chain = true := by decide
def e565596458618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e565596458618 : Closed e565596458618 ∧ code e565596458618 = 2764619714170 := by decide
theorem cert_e565596458618 : check e565596458618 [[],[.under]] .chain = true := by decide
end Blc.Floor41
