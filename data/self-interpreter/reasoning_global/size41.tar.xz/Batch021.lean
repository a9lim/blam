import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e564820942874 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564820942874 : Closed e564820942874 ∧ code e564820942874 = 2763844198426 := by decide
theorem cert_e564820942874 : check e564820942874 [[]] .width = true := by decide
def e564820942966 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564820942966 : Closed e564820942966 ∧ code e564820942966 = 2763844198518 := by decide
theorem cert_e564820942966 : check e564820942966 [[]] .width = true := by decide
def e564820943210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564820943210 : Closed e564820943210 ∧ code e564820943210 = 2763844198762 := by decide
theorem cert_e564820943210 : check e564820943210 [[]] .width = true := by decide
def e564820943258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564820943258 : Closed e564820943258 ∧ code e564820943258 = 2763844198810 := by decide
theorem cert_e564820943258 : check e564820943258 [[]] .width = true := by decide
def e564879126726 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564879126726 : Closed e564879126726 ∧ code e564879126726 = 2763902382278 := by decide
theorem cert_e564879126726 : check e564879126726 [[]] .width = true := by decide
def e564879143110 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564879143110 : Closed e564879143110 ∧ code e564879143110 = 2763902398662 := by decide
theorem cert_e564879143110 : check e564879143110 [[]] .width = true := by decide
def e564879257798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564879257798 : Closed e564879257798 ∧ code e564879257798 = 2763902513350 := by decide
theorem cert_e564879257798 : check e564879257798 [[]] .width = true := by decide
def e564879282374 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564879282374 : Closed e564879282374 ∧ code e564879282374 = 2763902537926 := by decide
theorem cert_e564879282374 : check e564879282374 [[]] .width = true := by decide
def e564879339718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564879339718 : Closed e564879339718 ∧ code e564879339718 = 2763902595270 := by decide
theorem cert_e564879339718 : check e564879339718 [[]] .width = true := by decide
def e564879347910 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564879347910 : Closed e564879347910 ∧ code e564879347910 = 2763902603462 := by decide
theorem cert_e564879347910 : check e564879347910 [[]] .width = true := by decide
def e564879782086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564879782086 : Closed e564879782086 ∧ code e564879782086 = 2763903037638 := by decide
theorem cert_e564879782086 : check e564879782086 [[]] .width = true := by decide
def e564879806662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564879806662 : Closed e564879806662 ∧ code e564879806662 = 2763903062214 := by decide
theorem cert_e564879806662 : check e564879806662 [[]] .width = true := by decide
def e564879904966 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564879904966 : Closed e564879904966 ∧ code e564879904966 = 2763903160518 := by decide
theorem cert_e564879904966 : check e564879904966 [[]] .width = true := by decide
def e564880126150 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564880126150 : Closed e564880126150 ∧ code e564880126150 = 2763903381702 := by decide
theorem cert_e564880126150 : check e564880126150 [[]] .width = true := by decide
def e564880134342 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564880134342 : Closed e564880134342 ∧ code e564880134342 = 2763903389894 := by decide
theorem cert_e564880134342 : check e564880134342 [[]] .width = true := by decide
def e564880167110 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564880167110 : Closed e564880167110 ∧ code e564880167110 = 2763903422662 := by decide
theorem cert_e564880167110 : check e564880167110 [[]] .width = true := by decide
def e564881448986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564881448986 : Closed e564881448986 ∧ code e564881448986 = 2763904704538 := by decide
theorem cert_e564881448986 : check e564881448986 [[]] .width = true := by decide
def e564881449078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564881449078 : Closed e564881449078 ∧ code e564881449078 = 2763904704630 := by decide
theorem cert_e564881449078 : check e564881449078 [[]] .width = true := by decide
def e564881449322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564881449322 : Closed e564881449322 ∧ code e564881449322 = 2763904704874 := by decide
theorem cert_e564881449322 : check e564881449322 [[]] .width = true := by decide
def e564881449370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564881449370 : Closed e564881449370 ∧ code e564881449370 = 2763904704922 := by decide
theorem cert_e564881449370 : check e564881449370 [[]] .width = true := by decide
def e564881481754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564881481754 : Closed e564881481754 ∧ code e564881481754 = 2763904737306 := by decide
theorem cert_e564881481754 : check e564881481754 [[]] .width = true := by decide
def e564881481846 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564881481846 : Closed e564881481846 ∧ code e564881481846 = 2763904737398 := by decide
theorem cert_e564881481846 : check e564881481846 [[]] .width = true := by decide
def e564881482090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564881482090 : Closed e564881482090 ∧ code e564881482090 = 2763904737642 := by decide
theorem cert_e564881482090 : check e564881482090 [[]] .width = true := by decide
def e564881482138 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564881482138 : Closed e564881482138 ∧ code e564881482138 = 2763904737690 := by decide
theorem cert_e564881482138 : check e564881482138 [[]] .width = true := by decide
def e564882272454 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564882272454 : Closed e564882272454 ∧ code e564882272454 = 2763905528006 := by decide
theorem cert_e564882272454 : check e564882272454 [[]] .width = true := by decide
def e564882288838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564882288838 : Closed e564882288838 ∧ code e564882288838 = 2763905544390 := by decide
theorem cert_e564882288838 : check e564882288838 [[]] .width = true := by decide
def e564882403526 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564882403526 : Closed e564882403526 ∧ code e564882403526 = 2763905659078 := by decide
theorem cert_e564882403526 : check e564882403526 [[]] .width = true := by decide
def e564882428102 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564882428102 : Closed e564882428102 ∧ code e564882428102 = 2763905683654 := by decide
theorem cert_e564882428102 : check e564882428102 [[]] .width = true := by decide
def e564882485446 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564882485446 : Closed e564882485446 ∧ code e564882485446 = 2763905740998 := by decide
theorem cert_e564882485446 : check e564882485446 [[]] .width = true := by decide
def e564882493638 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564882493638 : Closed e564882493638 ∧ code e564882493638 = 2763905749190 := by decide
theorem cert_e564882493638 : check e564882493638 [[]] .width = true := by decide
def e564883058886 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564883058886 : Closed e564883058886 ∧ code e564883058886 = 2763906314438 := by decide
theorem cert_e564883058886 : check e564883058886 [[]] .width = true := by decide
def e564883075270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564883075270 : Closed e564883075270 ∧ code e564883075270 = 2763906330822 := by decide
theorem cert_e564883075270 : check e564883075270 [[]] .width = true := by decide
def e564883742746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564883742746 : Closed e564883742746 ∧ code e564883742746 = 2763906998298 := by decide
theorem cert_e564883742746 : check e564883742746 [[]] .width = true := by decide
def e564883742838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564883742838 : Closed e564883742838 ∧ code e564883742838 = 2763906998390 := by decide
theorem cert_e564883742838 : check e564883742838 [[]] .width = true := by decide
def e564883743082 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564883743082 : Closed e564883743082 ∧ code e564883743082 = 2763906998634 := by decide
theorem cert_e564883743082 : check e564883743082 [[]] .width = true := by decide
def e564883743130 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564883743130 : Closed e564883743130 ∧ code e564883743130 = 2763906998682 := by decide
theorem cert_e564883743130 : check e564883743130 [[]] .width = true := by decide
def e564883845318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564883845318 : Closed e564883845318 ∧ code e564883845318 = 2763907100870 := by decide
theorem cert_e564883845318 : check e564883845318 [[]] .width = true := by decide
def e564883869894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564883869894 : Closed e564883869894 ∧ code e564883869894 = 2763907125446 := by decide
theorem cert_e564883869894 : check e564883869894 [[]] .width = true := by decide
def e564884078790 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564884078790 : Closed e564884078790 ∧ code e564884078790 = 2763907334342 := by decide
theorem cert_e564884078790 : check e564884078790 [[]] .width = true := by decide
def e564884079318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e564884079318 : Closed e564884079318 ∧ code e564884079318 = 2763907334870 := by decide
theorem cert_e564884079318 : check e564884079318 [[]] .width = true := by decide
def e564884079322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e564884079322 : Closed e564884079322 ∧ code e564884079322 = 2763907334874 := by decide
theorem cert_e564884079322 : check e564884079322 [[]] .width = true := by decide
def e564884079338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e564884079338 : Closed e564884079338 ∧ code e564884079338 = 2763907334890 := by decide
theorem cert_e564884079338 : check e564884079338 [[]] .width = true := by decide
def e564884079414 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e564884079414 : Closed e564884079414 ∧ code e564884079414 = 2763907334966 := by decide
theorem cert_e564884079414 : check e564884079414 [[]] .width = true := by decide
def e564884079418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e564884079418 : Closed e564884079418 ∧ code e564884079418 = 2763907334970 := by decide
theorem cert_e564884079418 : check e564884079418 [[]] .width = true := by decide
def e564884079502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e564884079502 : Closed e564884079502 ∧ code e564884079502 = 2763907335054 := by decide
theorem cert_e564884079502 : check e564884079502 [[]] .width = true := by decide
def e564884079514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e564884079514 : Closed e564884079514 ∧ code e564884079514 = 2763907335066 := by decide
theorem cert_e564884079514 : check e564884079514 [[]] .width = true := by decide
def e564884081434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e564884081434 : Closed e564884081434 ∧ code e564884081434 = 2763907336986 := by decide
theorem cert_e564884081434 : check e564884081434 [[]] .width = true := by decide
def e564884081478 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e564884081478 : Closed e564884081478 ∧ code e564884081478 = 2763907337030 := by decide
theorem cert_e564884081478 : check e564884081478 [[]] .width = true := by decide
def e564884081718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e564884081718 : Closed e564884081718 ∧ code e564884081718 = 2763907337270 := by decide
theorem cert_e564884081718 : check e564884081718 [[]] .width = true := by decide
def e564884081722 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e564884081722 : Closed e564884081722 ∧ code e564884081722 = 2763907337274 := by decide
theorem cert_e564884081722 : check e564884081722 [[]] .width = true := by decide
def e564884081862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e564884081862 : Closed e564884081862 ∧ code e564884081862 = 2763907337414 := by decide
theorem cert_e564884081862 : check e564884081862 [[]] .width = true := by decide
def e564884201498 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564884201498 : Closed e564884201498 ∧ code e564884201498 = 2763907457050 := by decide
theorem cert_e564884201498 : check e564884201498 [[]] .width = true := by decide
def e564884201590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564884201590 : Closed e564884201590 ∧ code e564884201590 = 2763907457142 := by decide
private def t_e564884201590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e564884201590 : ¬ IsSelfInterpreter e564884201590 :=
  wSource (t := t_e564884201590) (replay_sound (ps := []) (t := e564884201590) (by decide)) (by decide)
def e564884201834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564884201834 : Closed e564884201834 ∧ code e564884201834 = 2763907457386 := by decide
private def t_e564884201834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e564884201834 : ¬ IsSelfInterpreter e564884201834 :=
  wSource (t := t_e564884201834) (replay_sound (ps := []) (t := e564884201834) (by decide)) (by decide)
def e564884201882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564884201882 : Closed e564884201882 ∧ code e564884201882 = 2763907457434 := by decide
private def t_e564884201882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e564884201882 : ¬ IsSelfInterpreter e564884201882 :=
  wSource (t := t_e564884201882) (replay_sound (ps := []) (t := e564884201882) (by decide)) (by decide)
def e564884254918 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564884254918 : Closed e564884254918 ∧ code e564884254918 = 2763907510470 := by decide
theorem cert_e564884254918 : check e564884254918 [[]] .width = true := by decide
def e564884263110 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564884263110 : Closed e564884263110 ∧ code e564884263110 = 2763907518662 := by decide
theorem cert_e564884263110 : check e564884263110 [[]] .width = true := by decide
def e564884340934 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564884340934 : Closed e564884340934 ∧ code e564884340934 = 2763907596486 := by decide
theorem cert_e564884340934 : check e564884340934 [[]] .width = true := by decide
def e564884341462 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e564884341462 : Closed e564884341462 ∧ code e564884341462 = 2763907597014 := by decide
theorem cert_e564884341462 : check e564884341462 [[]] .width = true := by decide
def e564884341466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e564884341466 : Closed e564884341466 ∧ code e564884341466 = 2763907597018 := by decide
theorem cert_e564884341466 : check e564884341466 [[]] .width = true := by decide
def e564884341482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e564884341482 : Closed e564884341482 ∧ code e564884341482 = 2763907597034 := by decide
theorem cert_e564884341482 : check e564884341482 [[]] .width = true := by decide
def e564884341558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e564884341558 : Closed e564884341558 ∧ code e564884341558 = 2763907597110 := by decide
theorem cert_e564884341558 : check e564884341558 [[]] .width = true := by decide
def e564884341562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e564884341562 : Closed e564884341562 ∧ code e564884341562 = 2763907597114 := by decide
theorem cert_e564884341562 : check e564884341562 [[]] .width = true := by decide
def e564884341646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e564884341646 : Closed e564884341646 ∧ code e564884341646 = 2763907597198 := by decide
theorem cert_e564884341646 : check e564884341646 [[]] .width = true := by decide
def e564884341658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e564884341658 : Closed e564884341658 ∧ code e564884341658 = 2763907597210 := by decide
theorem cert_e564884341658 : check e564884341658 [[]] .width = true := by decide
def e564884343578 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e564884343578 : Closed e564884343578 ∧ code e564884343578 = 2763907599130 := by decide
theorem cert_e564884343578 : check e564884343578 [[]] .width = true := by decide
def e564884343622 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e564884343622 : Closed e564884343622 ∧ code e564884343622 = 2763907599174 := by decide
private def t_e564884343622 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem cert_e564884343622 : ¬ IsSelfInterpreter e564884343622 :=
  wSource (t := t_e564884343622) (replay_sound (ps := []) (t := e564884343622) (by decide)) (by decide)
def e564884343862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e564884343862 : Closed e564884343862 ∧ code e564884343862 = 2763907599414 := by decide
private def t_e564884343862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem cert_e564884343862 : ¬ IsSelfInterpreter e564884343862 :=
  wSource (t := t_e564884343862) (replay_sound (ps := []) (t := e564884343862) (by decide)) (by decide)
def e564884343866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e564884343866 : Closed e564884343866 ∧ code e564884343866 = 2763907599418 := by decide
private def t_e564884343866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem cert_e564884343866 : ¬ IsSelfInterpreter e564884343866 :=
  wSource (t := t_e564884343866) (replay_sound (ps := []) (t := e564884343866) (by decide)) (by decide)
def e564884344006 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e564884344006 : Closed e564884344006 ∧ code e564884344006 = 2763907599558 := by decide
theorem cert_e564884344006 : check e564884344006 [[]] .width = true := by decide
def e564885119002 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564885119002 : Closed e564885119002 ∧ code e564885119002 = 2763908374554 := by decide
theorem cert_e564885119002 : check e564885119002 [[]] .width = true := by decide
def e564885119094 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564885119094 : Closed e564885119094 ∧ code e564885119094 = 2763908374646 := by decide
theorem cert_e564885119094 : check e564885119094 [[]] .width = true := by decide
def e564885119338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564885119338 : Closed e564885119338 ∧ code e564885119338 = 2763908374890 := by decide
theorem cert_e564885119338 : check e564885119338 [[]] .width = true := by decide
def e564885119386 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564885119386 : Closed e564885119386 ∧ code e564885119386 = 2763908374938 := by decide
theorem cert_e564885119386 : check e564885119386 [[]] .width = true := by decide
def e564885168154 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564885168154 : Closed e564885168154 ∧ code e564885168154 = 2763908423706 := by decide
theorem cert_e564885168154 : check e564885168154 [[]] .width = true := by decide
def e564885168246 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564885168246 : Closed e564885168246 ∧ code e564885168246 = 2763908423798 := by decide
theorem cert_e564885168246 : check e564885168246 [[]] .width = true := by decide
def e564885168490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564885168490 : Closed e564885168490 ∧ code e564885168490 = 2763908424042 := by decide
theorem cert_e564885168490 : check e564885168490 [[]] .width = true := by decide
def e564885168538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564885168538 : Closed e564885168538 ∧ code e564885168538 = 2763908424090 := by decide
theorem cert_e564885168538 : check e564885168538 [[]] .width = true := by decide
def e564885549254 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564885549254 : Closed e564885549254 ∧ code e564885549254 = 2763908804806 := by decide
theorem cert_e564885549254 : check e564885549254 [[]] .width = true := by decide
def e564885573830 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564885573830 : Closed e564885573830 ∧ code e564885573830 = 2763908829382 := by decide
theorem cert_e564885573830 : check e564885573830 [[]] .width = true := by decide
def e564885672134 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564885672134 : Closed e564885672134 ∧ code e564885672134 = 2763908927686 := by decide
theorem cert_e564885672134 : check e564885672134 [[]] .width = true := by decide
def e564885839898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564885839898 : Closed e564885839898 ∧ code e564885839898 = 2763909095450 := by decide
theorem cert_e564885839898 : check e564885839898 [[]] .width = true := by decide
def e564885839990 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564885839990 : Closed e564885839990 ∧ code e564885839990 = 2763909095542 := by decide
theorem cert_e564885839990 : check e564885839990 [[]] .width = true := by decide
def e564885840234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564885840234 : Closed e564885840234 ∧ code e564885840234 = 2763909095786 := by decide
theorem cert_e564885840234 : check e564885840234 [[]] .width = true := by decide
def e564885840282 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564885840282 : Closed e564885840282 ∧ code e564885840282 = 2763909095834 := by decide
theorem cert_e564885840282 : check e564885840282 [[]] .width = true := by decide
def e564885942470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564885942470 : Closed e564885942470 ∧ code e564885942470 = 2763909198022 := by decide
theorem cert_e564885942470 : check e564885942470 [[]] .width = true := by decide
def e564885967046 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564885967046 : Closed e564885967046 ∧ code e564885967046 = 2763909222598 := by decide
theorem cert_e564885967046 : check e564885967046 [[]] .width = true := by decide
def e564886175942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564886175942 : Closed e564886175942 ∧ code e564886175942 = 2763909431494 := by decide
theorem cert_e564886175942 : check e564886175942 [[]] .width = true := by decide
def e564886176470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e564886176470 : Closed e564886176470 ∧ code e564886176470 = 2763909432022 := by decide
theorem cert_e564886176470 : check e564886176470 [[]] .width = true := by decide
def e564886176474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e564886176474 : Closed e564886176474 ∧ code e564886176474 = 2763909432026 := by decide
theorem cert_e564886176474 : check e564886176474 [[]] .width = true := by decide
def e564886176490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e564886176490 : Closed e564886176490 ∧ code e564886176490 = 2763909432042 := by decide
theorem cert_e564886176490 : check e564886176490 [[]] .width = true := by decide
def e564886176566 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e564886176566 : Closed e564886176566 ∧ code e564886176566 = 2763909432118 := by decide
theorem cert_e564886176566 : check e564886176566 [[]] .width = true := by decide
def e564886176570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e564886176570 : Closed e564886176570 ∧ code e564886176570 = 2763909432122 := by decide
theorem cert_e564886176570 : check e564886176570 [[]] .width = true := by decide
def e564886176654 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e564886176654 : Closed e564886176654 ∧ code e564886176654 = 2763909432206 := by decide
theorem cert_e564886176654 : check e564886176654 [[]] .width = true := by decide
def e564886176666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e564886176666 : Closed e564886176666 ∧ code e564886176666 = 2763909432218 := by decide
theorem cert_e564886176666 : check e564886176666 [[]] .width = true := by decide
def e564886178586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e564886178586 : Closed e564886178586 ∧ code e564886178586 = 2763909434138 := by decide
theorem cert_e564886178586 : check e564886178586 [[]] .width = true := by decide
def e564886178630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e564886178630 : Closed e564886178630 ∧ code e564886178630 = 2763909434182 := by decide
theorem cert_e564886178630 : check e564886178630 [[]] .width = true := by decide
def e564886178870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e564886178870 : Closed e564886178870 ∧ code e564886178870 = 2763909434422 := by decide
theorem cert_e564886178870 : check e564886178870 [[]] .width = true := by decide
def e564886178874 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e564886178874 : Closed e564886178874 ∧ code e564886178874 = 2763909434426 := by decide
theorem cert_e564886178874 : check e564886178874 [[]] .width = true := by decide
def e564886179014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e564886179014 : Closed e564886179014 ∧ code e564886179014 = 2763909434566 := by decide
theorem cert_e564886179014 : check e564886179014 [[]] .width = true := by decide
def e564886528026 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564886528026 : Closed e564886528026 ∧ code e564886528026 = 2763909783578 := by decide
theorem cert_e564886528026 : check e564886528026 [[]] .width = true := by decide
def e564886528118 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564886528118 : Closed e564886528118 ∧ code e564886528118 = 2763909783670 := by decide
theorem cert_e564886528118 : check e564886528118 [[]] .width = true := by decide
def e564886528362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564886528362 : Closed e564886528362 ∧ code e564886528362 = 2763909783914 := by decide
theorem cert_e564886528362 : check e564886528362 [[]] .width = true := by decide
def e564886528410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564886528410 : Closed e564886528410 ∧ code e564886528410 = 2763909783962 := by decide
theorem cert_e564886528410 : check e564886528410 [[]] .width = true := by decide
def e564886556870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564886556870 : Closed e564886556870 ∧ code e564886556870 = 2763909812422 := by decide
theorem cert_e564886556870 : check e564886556870 [[]] .width = true := by decide
def e564886569158 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564886569158 : Closed e564886569158 ∧ code e564886569158 = 2763909824710 := by decide
theorem cert_e564886569158 : check e564886569158 [[]] .width = true := by decide
def e564886569686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e564886569686 : Closed e564886569686 ∧ code e564886569686 = 2763909825238 := by decide
theorem cert_e564886569686 : check e564886569686 [[]] .width = true := by decide
def e564886569690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e564886569690 : Closed e564886569690 ∧ code e564886569690 = 2763909825242 := by decide
theorem cert_e564886569690 : check e564886569690 [[]] .width = true := by decide
def e564886569706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e564886569706 : Closed e564886569706 ∧ code e564886569706 = 2763909825258 := by decide
theorem cert_e564886569706 : check e564886569706 [[]] .width = true := by decide
def e564886569782 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e564886569782 : Closed e564886569782 ∧ code e564886569782 = 2763909825334 := by decide
theorem cert_e564886569782 : check e564886569782 [[]] .width = true := by decide
def e564886569786 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e564886569786 : Closed e564886569786 ∧ code e564886569786 = 2763909825338 := by decide
theorem cert_e564886569786 : check e564886569786 [[]] .width = true := by decide
def e564886569870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e564886569870 : Closed e564886569870 ∧ code e564886569870 = 2763909825422 := by decide
theorem cert_e564886569870 : check e564886569870 [[]] .width = true := by decide
def e564886569882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e564886569882 : Closed e564886569882 ∧ code e564886569882 = 2763909825434 := by decide
theorem cert_e564886569882 : check e564886569882 [[]] .width = true := by decide
def e564886571802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e564886571802 : Closed e564886571802 ∧ code e564886571802 = 2763909827354 := by decide
theorem cert_e564886571802 : check e564886571802 [[]] .width = true := by decide
def e564886571846 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e564886571846 : Closed e564886571846 ∧ code e564886571846 = 2763909827398 := by decide
theorem cert_e564886571846 : check e564886571846 [[]] .width = true := by decide
def e564886572086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e564886572086 : Closed e564886572086 ∧ code e564886572086 = 2763909827638 := by decide
theorem cert_e564886572086 : check e564886572086 [[]] .width = true := by decide
def e564886572090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e564886572090 : Closed e564886572090 ∧ code e564886572090 = 2763909827642 := by decide
theorem cert_e564886572090 : check e564886572090 [[]] .width = true := by decide
def e564886572230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e564886572230 : Closed e564886572230 ∧ code e564886572230 = 2763909827782 := by decide
theorem cert_e564886572230 : check e564886572230 [[]] .width = true := by decide
def e564886986778 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564886986778 : Closed e564886986778 ∧ code e564886986778 = 2763910242330 := by decide
theorem cert_e564886986778 : check e564886986778 [[]] .width = true := by decide
def e564886986870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564886986870 : Closed e564886986870 ∧ code e564886986870 = 2763910242422 := by decide
theorem cert_e564886986870 : check e564886986870 [[]] .width = true := by decide
def e564886987114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564886987114 : Closed e564886987114 ∧ code e564886987114 = 2763910242666 := by decide
theorem cert_e564886987114 : check e564886987114 [[]] .width = true := by decide
def e564886987162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564886987162 : Closed e564886987162 ∧ code e564886987162 = 2763910242714 := by decide
theorem cert_e564886987162 : check e564886987162 [[]] .width = true := by decide
def e564887003162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564887003162 : Closed e564887003162 ∧ code e564887003162 = 2763910258714 := by decide
theorem cert_e564887003162 : check e564887003162 [[]] .width = true := by decide
def e564887003254 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564887003254 : Closed e564887003254 ∧ code e564887003254 = 2763910258806 := by decide
theorem cert_e564887003254 : check e564887003254 [[]] .width = true := by decide
def e564887003498 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564887003498 : Closed e564887003498 ∧ code e564887003498 = 2763910259050 := by decide
theorem cert_e564887003498 : check e564887003498 [[]] .width = true := by decide
def e564887003546 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564887003546 : Closed e564887003546 ∧ code e564887003546 = 2763910259098 := by decide
theorem cert_e564887003546 : check e564887003546 [[]] .width = true := by decide
def e564887204038 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564887204038 : Closed e564887204038 ∧ code e564887204038 = 2763910459590 := by decide
theorem cert_e564887204038 : check e564887204038 [[]] .width = true := by decide
def e564887212230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564887212230 : Closed e564887212230 ∧ code e564887212230 = 2763910467782 := by decide
theorem cert_e564887212230 : check e564887212230 [[]] .width = true := by decide
def e564887244998 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564887244998 : Closed e564887244998 ∧ code e564887244998 = 2763910500550 := by decide
theorem cert_e564887244998 : check e564887244998 [[]] .width = true := by decide
def e564887347226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564887347226 : Closed e564887347226 ∧ code e564887347226 = 2763910602778 := by decide
theorem cert_e564887347226 : check e564887347226 [[]] .width = true := by decide
def e564887347318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564887347318 : Closed e564887347318 ∧ code e564887347318 = 2763910602870 := by decide
private def t_e564887347318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e564887347318 : ¬ IsSelfInterpreter e564887347318 :=
  wSource (t := t_e564887347318) (replay_sound (ps := []) (t := e564887347318) (by decide)) (by decide)
def e564887347562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564887347562 : Closed e564887347562 ∧ code e564887347562 = 2763910603114 := by decide
private def t_e564887347562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e564887347562 : ¬ IsSelfInterpreter e564887347562 :=
  wSource (t := t_e564887347562) (replay_sound (ps := []) (t := e564887347562) (by decide)) (by decide)
def e564887347610 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564887347610 : Closed e564887347610 ∧ code e564887347610 = 2763910603162 := by decide
private def t_e564887347610 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e564887347610 : ¬ IsSelfInterpreter e564887347610 :=
  wSource (t := t_e564887347610) (replay_sound (ps := []) (t := e564887347610) (by decide)) (by decide)
def e564887400646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564887400646 : Closed e564887400646 ∧ code e564887400646 = 2763910656198 := by decide
theorem cert_e564887400646 : check e564887400646 [[]] .width = true := by decide
def e564887408838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564887408838 : Closed e564887408838 ∧ code e564887408838 = 2763910664390 := by decide
theorem cert_e564887408838 : check e564887408838 [[]] .width = true := by decide
def e564887486662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564887486662 : Closed e564887486662 ∧ code e564887486662 = 2763910742214 := by decide
theorem cert_e564887486662 : check e564887486662 [[]] .width = true := by decide
def e564887487190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e564887487190 : Closed e564887487190 ∧ code e564887487190 = 2763910742742 := by decide
theorem cert_e564887487190 : check e564887487190 [[]] .width = true := by decide
def e564887487194 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e564887487194 : Closed e564887487194 ∧ code e564887487194 = 2763910742746 := by decide
theorem cert_e564887487194 : check e564887487194 [[]] .width = true := by decide
def e564887487210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e564887487210 : Closed e564887487210 ∧ code e564887487210 = 2763910742762 := by decide
theorem cert_e564887487210 : check e564887487210 [[]] .width = true := by decide
def e564887487286 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e564887487286 : Closed e564887487286 ∧ code e564887487286 = 2763910742838 := by decide
theorem cert_e564887487286 : check e564887487286 [[]] .width = true := by decide
def e564887487290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e564887487290 : Closed e564887487290 ∧ code e564887487290 = 2763910742842 := by decide
theorem cert_e564887487290 : check e564887487290 [[]] .width = true := by decide
def e564887487374 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e564887487374 : Closed e564887487374 ∧ code e564887487374 = 2763910742926 := by decide
theorem cert_e564887487374 : check e564887487374 [[]] .width = true := by decide
def e564887487386 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e564887487386 : Closed e564887487386 ∧ code e564887487386 = 2763910742938 := by decide
theorem cert_e564887487386 : check e564887487386 [[]] .width = true := by decide
def e564887489306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e564887489306 : Closed e564887489306 ∧ code e564887489306 = 2763910744858 := by decide
theorem cert_e564887489306 : check e564887489306 [[]] .width = true := by decide
def e564887489350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e564887489350 : Closed e564887489350 ∧ code e564887489350 = 2763910744902 := by decide
private def t_e564887489350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem cert_e564887489350 : ¬ IsSelfInterpreter e564887489350 :=
  wSource (t := t_e564887489350) (replay_sound (ps := []) (t := e564887489350) (by decide)) (by decide)
def e564887489590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e564887489590 : Closed e564887489590 ∧ code e564887489590 = 2763910745142 := by decide
private def t_e564887489590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem cert_e564887489590 : ¬ IsSelfInterpreter e564887489590 :=
  wSource (t := t_e564887489590) (replay_sound (ps := []) (t := e564887489590) (by decide)) (by decide)
def e564887489594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e564887489594 : Closed e564887489594 ∧ code e564887489594 = 2763910745146 := by decide
private def t_e564887489594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem cert_e564887489594 : ¬ IsSelfInterpreter e564887489594 :=
  wSource (t := t_e564887489594) (replay_sound (ps := []) (t := e564887489594) (by decide)) (by decide)
def e564887489734 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e564887489734 : Closed e564887489734 ∧ code e564887489734 = 2763910745286 := by decide
theorem cert_e564887489734 : check e564887489734 [[]] .width = true := by decide
def e564887576602 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564887576602 : Closed e564887576602 ∧ code e564887576602 = 2763910832154 := by decide
theorem cert_e564887576602 : check e564887576602 [[]] .width = true := by decide
def e564887576694 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564887576694 : Closed e564887576694 ∧ code e564887576694 = 2763910832246 := by decide
theorem cert_e564887576694 : check e564887576694 [[]] .width = true := by decide
def e564887576938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564887576938 : Closed e564887576938 ∧ code e564887576938 = 2763910832490 := by decide
theorem cert_e564887576938 : check e564887576938 [[]] .width = true := by decide
def e564887576986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564887576986 : Closed e564887576986 ∧ code e564887576986 = 2763910832538 := by decide
theorem cert_e564887576986 : check e564887576986 [[]] .width = true := by decide
def e564887605446 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564887605446 : Closed e564887605446 ∧ code e564887605446 = 2763910860998 := by decide
theorem cert_e564887605446 : check e564887605446 [[]] .width = true := by decide
def e564887617734 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564887617734 : Closed e564887617734 ∧ code e564887617734 = 2763910873286 := by decide
theorem cert_e564887617734 : check e564887617734 [[]] .width = true := by decide
def e564887618262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e564887618262 : Closed e564887618262 ∧ code e564887618262 = 2763910873814 := by decide
theorem cert_e564887618262 : check e564887618262 [[]] .width = true := by decide
def e564887618266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e564887618266 : Closed e564887618266 ∧ code e564887618266 = 2763910873818 := by decide
theorem cert_e564887618266 : check e564887618266 [[]] .width = true := by decide
def e564887618282 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e564887618282 : Closed e564887618282 ∧ code e564887618282 = 2763910873834 := by decide
theorem cert_e564887618282 : check e564887618282 [[]] .width = true := by decide
def e564887618358 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e564887618358 : Closed e564887618358 ∧ code e564887618358 = 2763910873910 := by decide
theorem cert_e564887618358 : check e564887618358 [[]] .width = true := by decide
def e564887618362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e564887618362 : Closed e564887618362 ∧ code e564887618362 = 2763910873914 := by decide
theorem cert_e564887618362 : check e564887618362 [[]] .width = true := by decide
def e564887618446 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e564887618446 : Closed e564887618446 ∧ code e564887618446 = 2763910873998 := by decide
theorem cert_e564887618446 : check e564887618446 [[]] .width = true := by decide
end Blc.Floor41
