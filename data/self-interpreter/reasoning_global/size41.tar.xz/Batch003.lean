import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e151297051886 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e151297051886 : Closed e151297051886 ∧ code e151297051886 = 2350320307438 := by decide
theorem cert_e151297051886 : check e151297051886 [[.under],[.under]] .three = true := by decide
def e151297051894 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e151297051894 : Closed e151297051894 ∧ code e151297051894 = 2350320307446 := by decide
theorem cert_e151297051894 : check e151297051894 [[.under],[.under]] .three = true := by decide
def e151297052270 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e151297052270 : Closed e151297052270 ∧ code e151297052270 = 2350320307822 := by decide
theorem cert_e151297052270 : check e151297052270 [[.under],[.under]] .three = true := by decide
def e151297052282 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e151297052282 : Closed e151297052282 ∧ code e151297052282 = 2350320307834 := by decide
theorem cert_e151297052282 : check e151297052282 [[.under],[.under]] .three = true := by decide
def e151297052470 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e151297052470 : Closed e151297052470 ∧ code e151297052470 = 2350320308022 := by decide
theorem cert_e151297052470 : check e151297052470 [[.under],[.under]] .three = true := by decide
def e151297052474 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e151297052474 : Closed e151297052474 ∧ code e151297052474 = 2350320308026 := by decide
theorem cert_e151297052474 : check e151297052474 [[.under],[.under]] .three = true := by decide
def e151297058230 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e151297058230 : Closed e151297058230 ∧ code e151297058230 = 2350320313782 := by decide
theorem cert_e151297058230 : check e151297058230 [[.under],[.under]] .three = true := by decide
def e151297058262 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e151297058262 : Closed e151297058262 ∧ code e151297058262 = 2350320313814 := by decide
theorem cert_e151297058262 : check e151297058262 [[.under],[.under]] .three = true := by decide
def e151297058266 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e151297058266 : Closed e151297058266 ∧ code e151297058266 = 2350320313818 := by decide
theorem cert_e151297058266 : check e151297058266 [[.under],[.under]] .three = true := by decide
def e151297058422 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e151297058422 : Closed e151297058422 ∧ code e151297058422 = 2350320313974 := by decide
theorem cert_e151297058422 : check e151297058422 [[.under],[.under]] .three = true := by decide
def e151297058614 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e151297058614 : Closed e151297058614 ∧ code e151297058614 = 2350320314166 := by decide
theorem cert_e151297058614 : check e151297058614 [[.under],[.under]] .three = true := by decide
def e151297058618 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e151297058618 : Closed e151297058618 ∧ code e151297058618 = 2350320314170 := by decide
theorem cert_e151297058618 : check e151297058618 [[.under],[.under]] .three = true := by decide
def e151297395566 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e151297395566 : Closed e151297395566 ∧ code e151297395566 = 2350320651118 := by decide
theorem cert_e151297395566 : checkPay e151297395566 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e151297395574 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e151297395574 : Closed e151297395574 ∧ code e151297395574 = 2350320651126 := by decide
theorem cert_e151297395574 : checkPay e151297395574 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e151297395630 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e151297395630 : Closed e151297395630 ∧ code e151297395630 = 2350320651182 := by decide
theorem cert_e151297395630 : checkPay e151297395630 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e151297395642 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e151297395642 : Closed e151297395642 ∧ code e151297395642 = 2350320651194 := by decide
theorem cert_e151297395642 : checkPay e151297395642 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e151297395670 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e151297395670 : Closed e151297395670 ∧ code e151297395670 = 2350320651222 := by decide
theorem cert_e151297395670 : checkPay e151297395670 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e151297395674 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e151297395674 : Closed e151297395674 ∧ code e151297395674 = 2350320651226 := by decide
theorem cert_e151297395674 : checkPay e151297395674 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e151297395950 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e151297395950 : Closed e151297395950 ∧ code e151297395950 = 2350320651502 := by decide
theorem cert_e151297395950 : checkPay e151297395950 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e151297395958 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e151297395958 : Closed e151297395958 ∧ code e151297395958 = 2350320651510 := by decide
theorem cert_e151297395958 : checkPay e151297395958 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e151297396334 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e151297396334 : Closed e151297396334 ∧ code e151297396334 = 2350320651886 := by decide
theorem cert_e151297396334 : checkPay e151297396334 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e151297396346 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e151297396346 : Closed e151297396346 ∧ code e151297396346 = 2350320651898 := by decide
theorem cert_e151297396346 : checkPay e151297396346 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e151297396534 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e151297396534 : Closed e151297396534 ∧ code e151297396534 = 2350320652086 := by decide
theorem cert_e151297396534 : checkPay e151297396534 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e151297396538 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e151297396538 : Closed e151297396538 ∧ code e151297396538 = 2350320652090 := by decide
theorem cert_e151297396538 : checkPay e151297396538 [[.left],[.left],[.left],[]] 0 [] = true := by decide
def e151409178350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 2))))))
theorem wire_e151409178350 : Closed e151409178350 ∧ code e151409178350 = 2350432433902 := by decide
theorem cert_e151409178350 : check e151409178350 [[.under],[.under]] .chain = true := by decide
def e151409178478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 2))))))
theorem wire_e151409178478 : Closed e151409178478 ∧ code e151409178478 = 2350432434030 := by decide
theorem cert_e151409178478 : check e151409178478 [[.under],[.under]] .chain = true := by decide
def e151409179374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 2))))))
theorem wire_e151409179374 : Closed e151409179374 ∧ code e151409179374 = 2350432434926 := by decide
theorem cert_e151409179374 : check e151409179374 [[.under],[.under]] .chain = true := by decide
def e151409179566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 2))))))
theorem wire_e151409179566 : Closed e151409179566 ∧ code e151409179566 = 2350432435118 := by decide
theorem cert_e151409179566 : check e151409179566 [[.under],[.under]] .chain = true := by decide
def e151409180014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e151409180014 : Closed e151409180014 ∧ code e151409180014 = 2350432435566 := by decide
theorem cert_e151409180014 : check e151409180014 [[.under],[.under]] .chain = true := by decide
def e151409180078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e151409180078 : Closed e151409180078 ∧ code e151409180078 = 2350432435630 := by decide
theorem cert_e151409180078 : check e151409180078 [[.under],[.under]] .chain = true := by decide
def e151409184494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 2))))))
theorem wire_e151409184494 : Closed e151409184494 ∧ code e151409184494 = 2350432440046 := by decide
theorem cert_e151409184494 : check e151409184494 [[.under],[.under]] .chain = true := by decide
def e151409184622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 2))))))
theorem wire_e151409184622 : Closed e151409184622 ∧ code e151409184622 = 2350432440174 := by decide
theorem cert_e151409184622 : check e151409184622 [[.under],[.under]] .chain = true := by decide
def e151409190638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e151409190638 : Closed e151409190638 ∧ code e151409190638 = 2350432446190 := by decide
theorem cert_e151409190638 : check e151409190638 [[.under],[.under]] .chain = true := by decide
def e151409190830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e151409190830 : Closed e151409190830 ∧ code e151409190830 = 2350432446382 := by decide
theorem cert_e151409190830 : check e151409190830 [[.under],[.under]] .chain = true := by decide
def e151409193838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e151409193838 : Closed e151409193838 ∧ code e151409193838 = 2350432449390 := by decide
theorem cert_e151409193838 : check e151409193838 [[.under],[.under]] .chain = true := by decide
def e151409193902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e151409193902 : Closed e151409193902 ∧ code e151409193902 = 2350432449454 := by decide
theorem cert_e151409193902 : check e151409193902 [[.under],[.under]] .chain = true := by decide
def e151409593198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e151409593198 : Closed e151409593198 ∧ code e151409593198 = 2350432848750 := by decide
theorem cert_e151409593198 : check e151409593198 [[.under],[.under]] .chain = true := by decide
def e151409593206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e151409593206 : Closed e151409593206 ∧ code e151409593206 = 2350432848758 := by decide
theorem cert_e151409593206 : check e151409593206 [[.under],[.under]] .chain = true := by decide
def e151409593262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e151409593262 : Closed e151409593262 ∧ code e151409593262 = 2350432848814 := by decide
theorem cert_e151409593262 : check e151409593262 [[.under],[.under]] .chain = true := by decide
def e151409593274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e151409593274 : Closed e151409593274 ∧ code e151409593274 = 2350432848826 := by decide
theorem cert_e151409593274 : check e151409593274 [[.under],[.under]] .chain = true := by decide
def e151409593302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e151409593302 : Closed e151409593302 ∧ code e151409593302 = 2350432848854 := by decide
theorem cert_e151409593302 : check e151409593302 [[.under],[.under]] .chain = true := by decide
def e151409593306 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e151409593306 : Closed e151409593306 ∧ code e151409593306 = 2350432848858 := by decide
theorem cert_e151409593306 : check e151409593306 [[.under],[.under]] .chain = true := by decide
def e151409593582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e151409593582 : Closed e151409593582 ∧ code e151409593582 = 2350432849134 := by decide
theorem cert_e151409593582 : check e151409593582 [[.under],[.under]] .chain = true := by decide
def e151409593590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e151409593590 : Closed e151409593590 ∧ code e151409593590 = 2350432849142 := by decide
theorem cert_e151409593590 : check e151409593590 [[.under],[.under]] .chain = true := by decide
def e151409593966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e151409593966 : Closed e151409593966 ∧ code e151409593966 = 2350432849518 := by decide
theorem cert_e151409593966 : check e151409593966 [[.under],[.under]] .chain = true := by decide
def e151409593978 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e151409593978 : Closed e151409593978 ∧ code e151409593978 = 2350432849530 := by decide
theorem cert_e151409593978 : check e151409593978 [[.under],[.under]] .chain = true := by decide
def e151409594166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e151409594166 : Closed e151409594166 ∧ code e151409594166 = 2350432849718 := by decide
theorem cert_e151409594166 : check e151409594166 [[.under],[.under]] .chain = true := by decide
def e151409594170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e151409594170 : Closed e151409594170 ∧ code e151409594170 = 2350432849722 := by decide
theorem cert_e151409594170 : check e151409594170 [[.under],[.under]] .chain = true := by decide
def e151409929658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e151409929658 : Closed e151409929658 ∧ code e151409929658 = 2350433185210 := by decide
theorem cert_e151409929658 : check e151409929658 [[.under],[.under]] .chain = true := by decide
def e151409929690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e151409929690 : Closed e151409929690 ∧ code e151409929690 = 2350433185242 := by decide
theorem cert_e151409929690 : check e151409929690 [[.under],[.under]] .chain = true := by decide
def e151409929914 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e151409929914 : Closed e151409929914 ∧ code e151409929914 = 2350433185466 := by decide
theorem cert_e151409929914 : check e151409929914 [[.under],[.under]] .chain = true := by decide
def e151409929962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e151409929962 : Closed e151409929962 ∧ code e151409929962 = 2350433185514 := by decide
theorem cert_e151409929962 : check e151409929962 [[.under],[.under]] .chain = true := by decide
def e151409930074 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e151409930074 : Closed e151409930074 ∧ code e151409930074 = 2350433185626 := by decide
theorem cert_e151409930074 : check e151409930074 [[.under],[.under]] .chain = true := by decide
def e151409930090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e151409930090 : Closed e151409930090 ∧ code e151409930090 = 2350433185642 := by decide
theorem cert_e151409930090 : check e151409930090 [[.under],[.under]] .chain = true := by decide
def e151409931194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e151409931194 : Closed e151409931194 ∧ code e151409931194 = 2350433186746 := by decide
theorem cert_e151409931194 : check e151409931194 [[.under],[.under]] .chain = true := by decide
def e151409931226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e151409931226 : Closed e151409931226 ∧ code e151409931226 = 2350433186778 := by decide
theorem cert_e151409931226 : check e151409931226 [[.under],[.under]] .chain = true := by decide
def e151409932730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e151409932730 : Closed e151409932730 ∧ code e151409932730 = 2350433188282 := by decide
theorem cert_e151409932730 : check e151409932730 [[.under],[.under]] .chain = true := by decide
def e151409932778 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e151409932778 : Closed e151409932778 ∧ code e151409932778 = 2350433188330 := by decide
theorem cert_e151409932778 : check e151409932778 [[.under],[.under]] .chain = true := by decide
def e151409933530 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e151409933530 : Closed e151409933530 ∧ code e151409933530 = 2350433189082 := by decide
theorem cert_e151409933530 : check e151409933530 [[.under],[.under]] .chain = true := by decide
def e151409933546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e151409933546 : Closed e151409933546 ∧ code e151409933546 = 2350433189098 := by decide
theorem cert_e151409933546 : check e151409933546 [[.under],[.under]] .chain = true := by decide
def e151409986414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e151409986414 : Closed e151409986414 ∧ code e151409986414 = 2350433241966 := by decide
theorem cert_e151409986414 : check e151409986414 [[.under],[.under]] .chain = true := by decide
def e151409986422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e151409986422 : Closed e151409986422 ∧ code e151409986422 = 2350433241974 := by decide
theorem cert_e151409986422 : check e151409986422 [[.under],[.under]] .chain = true := by decide
def e151409986478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e151409986478 : Closed e151409986478 ∧ code e151409986478 = 2350433242030 := by decide
theorem cert_e151409986478 : check e151409986478 [[.under],[.under]] .chain = true := by decide
def e151409986490 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e151409986490 : Closed e151409986490 ∧ code e151409986490 = 2350433242042 := by decide
theorem cert_e151409986490 : check e151409986490 [[.under],[.under]] .chain = true := by decide
def e151409986518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e151409986518 : Closed e151409986518 ∧ code e151409986518 = 2350433242070 := by decide
theorem cert_e151409986518 : check e151409986518 [[.under],[.under]] .chain = true := by decide
def e151409986522 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e151409986522 : Closed e151409986522 ∧ code e151409986522 = 2350433242074 := by decide
theorem cert_e151409986522 : check e151409986522 [[.under],[.under]] .chain = true := by decide
def e151409986798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e151409986798 : Closed e151409986798 ∧ code e151409986798 = 2350433242350 := by decide
theorem cert_e151409986798 : check e151409986798 [[.under],[.under]] .chain = true := by decide
def e151409986806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e151409986806 : Closed e151409986806 ∧ code e151409986806 = 2350433242358 := by decide
theorem cert_e151409986806 : check e151409986806 [[.under],[.under]] .chain = true := by decide
def e151409987182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e151409987182 : Closed e151409987182 ∧ code e151409987182 = 2350433242734 := by decide
theorem cert_e151409987182 : check e151409987182 [[.under],[.under]] .chain = true := by decide
def e151409987194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e151409987194 : Closed e151409987194 ∧ code e151409987194 = 2350433242746 := by decide
theorem cert_e151409987194 : check e151409987194 [[.under],[.under]] .chain = true := by decide
def e151409987382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e151409987382 : Closed e151409987382 ∧ code e151409987382 = 2350433242934 := by decide
theorem cert_e151409987382 : check e151409987382 [[.under],[.under]] .chain = true := by decide
def e151409987386 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e151409987386 : Closed e151409987386 ∧ code e151409987386 = 2350433242938 := by decide
theorem cert_e151409987386 : check e151409987386 [[.under],[.under]] .chain = true := by decide
def e151411166062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e151411166062 : Closed e151411166062 ∧ code e151411166062 = 2350434421614 := by decide
theorem cert_e151411166062 : check e151411166062 [[.under],[.under]] .chain = true := by decide
def e151411166070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e151411166070 : Closed e151411166070 ∧ code e151411166070 = 2350434421622 := by decide
theorem cert_e151411166070 : check e151411166070 [[.under],[.under]] .chain = true := by decide
def e151411166126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e151411166126 : Closed e151411166126 ∧ code e151411166126 = 2350434421678 := by decide
theorem cert_e151411166126 : check e151411166126 [[.under],[.under]] .chain = true := by decide
def e151411166138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e151411166138 : Closed e151411166138 ∧ code e151411166138 = 2350434421690 := by decide
theorem cert_e151411166138 : check e151411166138 [[.under],[.under]] .chain = true := by decide
def e151411166166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e151411166166 : Closed e151411166166 ∧ code e151411166166 = 2350434421718 := by decide
theorem cert_e151411166166 : check e151411166166 [[.under],[.under]] .chain = true := by decide
def e151411166170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e151411166170 : Closed e151411166170 ∧ code e151411166170 = 2350434421722 := by decide
theorem cert_e151411166170 : check e151411166170 [[.under],[.under]] .chain = true := by decide
def e151411166446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e151411166446 : Closed e151411166446 ∧ code e151411166446 = 2350434421998 := by decide
theorem cert_e151411166446 : check e151411166446 [[.under],[.under]] .chain = true := by decide
def e151411166454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e151411166454 : Closed e151411166454 ∧ code e151411166454 = 2350434422006 := by decide
theorem cert_e151411166454 : check e151411166454 [[.under],[.under]] .chain = true := by decide
def e151411166830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e151411166830 : Closed e151411166830 ∧ code e151411166830 = 2350434422382 := by decide
theorem cert_e151411166830 : check e151411166830 [[.under],[.under]] .chain = true := by decide
def e151411166842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e151411166842 : Closed e151411166842 ∧ code e151411166842 = 2350434422394 := by decide
theorem cert_e151411166842 : check e151411166842 [[.under],[.under]] .chain = true := by decide
def e151411167030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e151411167030 : Closed e151411167030 ∧ code e151411167030 = 2350434422582 := by decide
theorem cert_e151411167030 : check e151411167030 [[.under],[.under]] .chain = true := by decide
def e151411167034 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e151411167034 : Closed e151411167034 ∧ code e151411167034 = 2350434422586 := by decide
theorem cert_e151411167034 : check e151411167034 [[.under],[.under]] .chain = true := by decide
def e151413370222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e151413370222 : Closed e151413370222 ∧ code e151413370222 = 2350436625774 := by decide
theorem cert_e151413370222 : check e151413370222 [[.under],[.under]] .chain = true := by decide
def e151413370230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e151413370230 : Closed e151413370230 ∧ code e151413370230 = 2350436625782 := by decide
theorem cert_e151413370230 : check e151413370230 [[.under],[.under]] .chain = true := by decide
def e151413370286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e151413370286 : Closed e151413370286 ∧ code e151413370286 = 2350436625838 := by decide
theorem cert_e151413370286 : check e151413370286 [[.under],[.under]] .chain = true := by decide
def e151413370298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e151413370298 : Closed e151413370298 ∧ code e151413370298 = 2350436625850 := by decide
theorem cert_e151413370298 : check e151413370298 [[.under],[.under]] .chain = true := by decide
def e151413370326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e151413370326 : Closed e151413370326 ∧ code e151413370326 = 2350436625878 := by decide
theorem cert_e151413370326 : check e151413370326 [[.under],[.under]] .chain = true := by decide
def e151413370330 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e151413370330 : Closed e151413370330 ∧ code e151413370330 = 2350436625882 := by decide
theorem cert_e151413370330 : check e151413370330 [[.under],[.under]] .chain = true := by decide
def e151413370542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e151413370542 : Closed e151413370542 ∧ code e151413370542 = 2350436626094 := by decide
theorem cert_e151413370542 : check e151413370542 [[.under],[.under]] .chain = true := by decide
def e151413370554 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e151413370554 : Closed e151413370554 ∧ code e151413370554 = 2350436626106 := by decide
theorem cert_e151413370554 : check e151413370554 [[.under],[.under]] .chain = true := by decide
def e151413370602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e151413370602 : Closed e151413370602 ∧ code e151413370602 = 2350436626154 := by decide
theorem cert_e151413370602 : check e151413370602 [[.under],[.under]] .chain = true := by decide
def e151413370710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e151413370710 : Closed e151413370710 ∧ code e151413370710 = 2350436626262 := by decide
theorem cert_e151413370710 : check e151413370710 [[.under],[.under]] .chain = true := by decide
def e151413370714 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e151413370714 : Closed e151413370714 ∧ code e151413370714 = 2350436626266 := by decide
theorem cert_e151413370714 : check e151413370714 [[.under],[.under]] .chain = true := by decide
def e151413370730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e151413370730 : Closed e151413370730 ∧ code e151413370730 = 2350436626282 := by decide
theorem cert_e151413370730 : check e151413370730 [[.under],[.under]] .chain = true := by decide
def e151413371758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e151413371758 : Closed e151413371758 ∧ code e151413371758 = 2350436627310 := by decide
theorem cert_e151413371758 : check e151413371758 [[.under],[.under]] .chain = true := by decide
def e151413371766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e151413371766 : Closed e151413371766 ∧ code e151413371766 = 2350436627318 := by decide
theorem cert_e151413371766 : check e151413371766 [[.under],[.under]] .chain = true := by decide
def e151413371822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e151413371822 : Closed e151413371822 ∧ code e151413371822 = 2350436627374 := by decide
theorem cert_e151413371822 : check e151413371822 [[.under],[.under]] .chain = true := by decide
def e151413371834 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e151413371834 : Closed e151413371834 ∧ code e151413371834 = 2350436627386 := by decide
theorem cert_e151413371834 : check e151413371834 [[.under],[.under]] .chain = true := by decide
def e151413371862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e151413371862 : Closed e151413371862 ∧ code e151413371862 = 2350436627414 := by decide
theorem cert_e151413371862 : check e151413371862 [[.under],[.under]] .chain = true := by decide
def e151413371866 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e151413371866 : Closed e151413371866 ∧ code e151413371866 = 2350436627418 := by decide
theorem cert_e151413371866 : check e151413371866 [[.under],[.under]] .chain = true := by decide
def e151413372142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e151413372142 : Closed e151413372142 ∧ code e151413372142 = 2350436627694 := by decide
theorem cert_e151413372142 : check e151413372142 [[.under],[.under]] .chain = true := by decide
def e151413372150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e151413372150 : Closed e151413372150 ∧ code e151413372150 = 2350436627702 := by decide
theorem cert_e151413372150 : check e151413372150 [[.under],[.under]] .chain = true := by decide
def e151413372526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e151413372526 : Closed e151413372526 ∧ code e151413372526 = 2350436628078 := by decide
theorem cert_e151413372526 : check e151413372526 [[.under],[.under]] .chain = true := by decide
def e151413372538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e151413372538 : Closed e151413372538 ∧ code e151413372538 = 2350436628090 := by decide
theorem cert_e151413372538 : check e151413372538 [[.under],[.under]] .chain = true := by decide
def e151413372726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e151413372726 : Closed e151413372726 ∧ code e151413372726 = 2350436628278 := by decide
theorem cert_e151413372726 : check e151413372726 [[.under],[.under]] .chain = true := by decide
def e151413372730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e151413372730 : Closed e151413372730 ∧ code e151413372730 = 2350436628282 := by decide
theorem cert_e151413372730 : check e151413372730 [[.under],[.under]] .chain = true := by decide
def e151413373358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e151413373358 : Closed e151413373358 ∧ code e151413373358 = 2350436628910 := by decide
theorem cert_e151413373358 : check e151413373358 [[.under],[.under]] .chain = true := by decide
def e151413373370 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e151413373370 : Closed e151413373370 ∧ code e151413373370 = 2350436628922 := by decide
theorem cert_e151413373370 : check e151413373370 [[.under],[.under]] .chain = true := by decide
def e151413373418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e151413373418 : Closed e151413373418 ∧ code e151413373418 = 2350436628970 := by decide
theorem cert_e151413373418 : check e151413373418 [[.under],[.under]] .chain = true := by decide
def e151413373550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e151413373550 : Closed e151413373550 ∧ code e151413373550 = 2350436629102 := by decide
theorem cert_e151413373550 : check e151413373550 [[.under],[.under]] .chain = true := by decide
def e151413373562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e151413373562 : Closed e151413373562 ∧ code e151413373562 = 2350436629114 := by decide
theorem cert_e151413373562 : check e151413373562 [[.under],[.under]] .chain = true := by decide
def e151413373850 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e151413373850 : Closed e151413373850 ∧ code e151413373850 = 2350436629402 := by decide
theorem cert_e151413373850 : check e151413373850 [[.under],[.under]] .chain = true := by decide
def e151413374166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e151413374166 : Closed e151413374166 ∧ code e151413374166 = 2350436629718 := by decide
theorem cert_e151413374166 : check e151413374166 [[.under],[.under]] .chain = true := by decide
def e151413374170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e151413374170 : Closed e151413374170 ∧ code e151413374170 = 2350436629722 := by decide
theorem cert_e151413374170 : check e151413374170 [[.under],[.under]] .chain = true := by decide
def e151413374186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e151413374186 : Closed e151413374186 ∧ code e151413374186 = 2350436629738 := by decide
theorem cert_e151413374186 : check e151413374186 [[.under],[.under]] .chain = true := by decide
def e151413374262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e151413374262 : Closed e151413374262 ∧ code e151413374262 = 2350436629814 := by decide
theorem cert_e151413374262 : check e151413374262 [[.under],[.under]] .chain = true := by decide
def e151413374266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e151413374266 : Closed e151413374266 ∧ code e151413374266 = 2350436629818 := by decide
theorem cert_e151413374266 : check e151413374266 [[.under],[.under]] .chain = true := by decide
def e151413374362 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e151413374362 : Closed e151413374362 ∧ code e151413374362 = 2350436629914 := by decide
theorem cert_e151413374362 : check e151413374362 [[.under],[.under]] .chain = true := by decide
def e151413377902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e151413377902 : Closed e151413377902 ∧ code e151413377902 = 2350436633454 := by decide
theorem cert_e151413377902 : check e151413377902 [[.under],[.under]] .chain = true := by decide
def e151413377910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e151413377910 : Closed e151413377910 ∧ code e151413377910 = 2350436633462 := by decide
theorem cert_e151413377910 : check e151413377910 [[.under],[.under]] .chain = true := by decide
def e151413377966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e151413377966 : Closed e151413377966 ∧ code e151413377966 = 2350436633518 := by decide
theorem cert_e151413377966 : check e151413377966 [[.under],[.under]] .chain = true := by decide
def e151413377978 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e151413377978 : Closed e151413377978 ∧ code e151413377978 = 2350436633530 := by decide
theorem cert_e151413377978 : check e151413377978 [[.under],[.under]] .chain = true := by decide
def e151413378006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e151413378006 : Closed e151413378006 ∧ code e151413378006 = 2350436633558 := by decide
theorem cert_e151413378006 : check e151413378006 [[.under],[.under]] .chain = true := by decide
def e151413378010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e151413378010 : Closed e151413378010 ∧ code e151413378010 = 2350436633562 := by decide
theorem cert_e151413378010 : check e151413378010 [[.under],[.under]] .chain = true := by decide
def e151413378286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e151413378286 : Closed e151413378286 ∧ code e151413378286 = 2350436633838 := by decide
theorem cert_e151413378286 : check e151413378286 [[.under],[.under]] .chain = true := by decide
def e151413378294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e151413378294 : Closed e151413378294 ∧ code e151413378294 = 2350436633846 := by decide
theorem cert_e151413378294 : check e151413378294 [[.under],[.under]] .chain = true := by decide
def e151413378670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e151413378670 : Closed e151413378670 ∧ code e151413378670 = 2350436634222 := by decide
theorem cert_e151413378670 : check e151413378670 [[.under],[.under]] .chain = true := by decide
def e151413378682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e151413378682 : Closed e151413378682 ∧ code e151413378682 = 2350436634234 := by decide
theorem cert_e151413378682 : check e151413378682 [[.under],[.under]] .chain = true := by decide
def e151413378870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e151413378870 : Closed e151413378870 ∧ code e151413378870 = 2350436634422 := by decide
theorem cert_e151413378870 : check e151413378870 [[.under],[.under]] .chain = true := by decide
def e151413378874 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e151413378874 : Closed e151413378874 ∧ code e151413378874 = 2350436634426 := by decide
theorem cert_e151413378874 : check e151413378874 [[.under],[.under]] .chain = true := by decide
def e151413384622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e151413384622 : Closed e151413384622 ∧ code e151413384622 = 2350436640174 := by decide
theorem cert_e151413384622 : check e151413384622 [[.under],[.under]] .chain = true := by decide
def e151413384634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e151413384634 : Closed e151413384634 ∧ code e151413384634 = 2350436640186 := by decide
theorem cert_e151413384634 : check e151413384634 [[.under],[.under]] .chain = true := by decide
def e151413384682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e151413384682 : Closed e151413384682 ∧ code e151413384682 = 2350436640234 := by decide
theorem cert_e151413384682 : check e151413384682 [[.under],[.under]] .chain = true := by decide
def e151413384814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e151413384814 : Closed e151413384814 ∧ code e151413384814 = 2350436640366 := by decide
theorem cert_e151413384814 : check e151413384814 [[.under],[.under]] .chain = true := by decide
def e151413384826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e151413384826 : Closed e151413384826 ∧ code e151413384826 = 2350436640378 := by decide
theorem cert_e151413384826 : check e151413384826 [[.under],[.under]] .chain = true := by decide
def e151413385114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e151413385114 : Closed e151413385114 ∧ code e151413385114 = 2350436640666 := by decide
theorem cert_e151413385114 : check e151413385114 [[.under],[.under]] .chain = true := by decide
def e151413387990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e151413387990 : Closed e151413387990 ∧ code e151413387990 = 2350436643542 := by decide
theorem cert_e151413387990 : check e151413387990 [[.under],[.under]] .chain = true := by decide
def e151413387994 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e151413387994 : Closed e151413387994 ∧ code e151413387994 = 2350436643546 := by decide
theorem cert_e151413387994 : check e151413387994 [[.under],[.under]] .chain = true := by decide
def e151413388010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e151413388010 : Closed e151413388010 ∧ code e151413388010 = 2350436643562 := by decide
theorem cert_e151413388010 : check e151413388010 [[.under],[.under]] .chain = true := by decide
def e151413388086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e151413388086 : Closed e151413388086 ∧ code e151413388086 = 2350436643638 := by decide
theorem cert_e151413388086 : check e151413388086 [[.under],[.under]] .chain = true := by decide
def e151413388090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e151413388090 : Closed e151413388090 ∧ code e151413388090 = 2350436643642 := by decide
theorem cert_e151413388090 : check e151413388090 [[.under],[.under]] .chain = true := by decide
def e151413388186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e151413388186 : Closed e151413388186 ∧ code e151413388186 = 2350436643738 := by decide
theorem cert_e151413388186 : check e151413388186 [[.under],[.under]] .chain = true := by decide
def e151413525358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e151413525358 : Closed e151413525358 ∧ code e151413525358 = 2350436780910 := by decide
theorem cert_e151413525358 : check e151413525358 [[.under],[.under]] .chain = true := by decide
def e151413525366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e151413525366 : Closed e151413525366 ∧ code e151413525366 = 2350436780918 := by decide
theorem cert_e151413525366 : check e151413525366 [[.under],[.under]] .chain = true := by decide
def e151413525422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e151413525422 : Closed e151413525422 ∧ code e151413525422 = 2350436780974 := by decide
theorem cert_e151413525422 : check e151413525422 [[.under],[.under]] .chain = true := by decide
def e151413525434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e151413525434 : Closed e151413525434 ∧ code e151413525434 = 2350436780986 := by decide
theorem cert_e151413525434 : check e151413525434 [[.under],[.under]] .chain = true := by decide
def e151413525462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e151413525462 : Closed e151413525462 ∧ code e151413525462 = 2350436781014 := by decide
theorem cert_e151413525462 : check e151413525462 [[.under],[.under]] .chain = true := by decide
def e151413525466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e151413525466 : Closed e151413525466 ∧ code e151413525466 = 2350436781018 := by decide
theorem cert_e151413525466 : check e151413525466 [[.under],[.under]] .chain = true := by decide
def e151413525742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e151413525742 : Closed e151413525742 ∧ code e151413525742 = 2350436781294 := by decide
theorem cert_e151413525742 : check e151413525742 [[.under],[.under]] .chain = true := by decide
def e151413525750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e151413525750 : Closed e151413525750 ∧ code e151413525750 = 2350436781302 := by decide
theorem cert_e151413525750 : check e151413525750 [[.under],[.under]] .chain = true := by decide
def e151413526126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e151413526126 : Closed e151413526126 ∧ code e151413526126 = 2350436781678 := by decide
theorem cert_e151413526126 : check e151413526126 [[.under],[.under]] .chain = true := by decide
def e151413526138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e151413526138 : Closed e151413526138 ∧ code e151413526138 = 2350436781690 := by decide
theorem cert_e151413526138 : check e151413526138 [[.under],[.under]] .chain = true := by decide
def e151413526326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e151413526326 : Closed e151413526326 ∧ code e151413526326 = 2350436781878 := by decide
theorem cert_e151413526326 : check e151413526326 [[.under],[.under]] .chain = true := by decide
def e151413526330 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e151413526330 : Closed e151413526330 ∧ code e151413526330 = 2350436781882 := by decide
theorem cert_e151413526330 : check e151413526330 [[.under],[.under]] .chain = true := by decide
def e151448914798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e151448914798 : Closed e151448914798 ∧ code e151448914798 = 2350472170350 := by decide
theorem cert_e151448914798 : check e151448914798 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e151448914806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e151448914806 : Closed e151448914806 ∧ code e151448914806 = 2350472170358 := by decide
theorem cert_e151448914806 : check e151448914806 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e151448914862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e151448914862 : Closed e151448914862 ∧ code e151448914862 = 2350472170414 := by decide
theorem cert_e151448914862 : check e151448914862 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e151448914874 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e151448914874 : Closed e151448914874 ∧ code e151448914874 = 2350472170426 := by decide
theorem cert_e151448914874 : check e151448914874 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
end Blc.Floor41
