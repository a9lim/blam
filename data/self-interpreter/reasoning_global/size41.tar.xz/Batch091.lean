import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605594150870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e605594150870 : Closed e605594150870 ∧ code e605594150870 = 2804617406422 := by decide
theorem cert_e605594150870 : check e605594150870 [[],[]] .three = true := by decide
def e605594150874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e605594150874 : Closed e605594150874 ∧ code e605594150874 = 2804617406426 := by decide
theorem cert_e605594150874 : check e605594150874 [[],[]] .three = true := by decide
def e605594150974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4))))))))))
theorem wire_e605594150974 : Closed e605594150974 ∧ code e605594150974 = 2804617406526 := by decide
theorem cert_e605594150974 : check e605594150974 [[],[]] .smaller = true := by decide
def e605594151390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605594151390 : Closed e605594151390 ∧ code e605594151390 = 2804617406942 := by decide
theorem cert_e605594151390 : check e605594151390 [[],[]] .three = true := by decide
def e605594151394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605594151394 : Closed e605594151394 ∧ code e605594151394 = 2804617406946 := by decide
theorem cert_e605594151394 : check e605594151394 [[],[]] .smaller = true := by decide
def e605594151406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e605594151406 : Closed e605594151406 ∧ code e605594151406 = 2804617406958 := by decide
theorem cert_e605594151406 : check e605594151406 [[],[]] .smaller = true := by decide
def e605594151414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605594151414 : Closed e605594151414 ∧ code e605594151414 = 2804617406966 := by decide
theorem cert_e605594151414 : check e605594151414 [[],[]] .three = true := by decide
def e605594152158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605594152158 : Closed e605594152158 ∧ code e605594152158 = 2804617407710 := by decide
theorem cert_e605594152158 : check e605594152158 [[],[]] .three = true := by decide
def e605594152174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605594152174 : Closed e605594152174 ∧ code e605594152174 = 2804617407726 := by decide
theorem cert_e605594152174 : check e605594152174 [[],[]] .smaller = true := by decide
def e605594152182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605594152182 : Closed e605594152182 ∧ code e605594152182 = 2804617407734 := by decide
theorem cert_e605594152182 : check e605594152182 [[],[]] .smaller = true := by decide
def e605594152186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605594152186 : Closed e605594152186 ∧ code e605594152186 = 2804617407738 := by decide
theorem cert_e605594152186 : check e605594152186 [[],[]] .three = true := by decide
def e605594152462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2))))))))))
theorem wire_e605594152462 : Closed e605594152462 ∧ code e605594152462 = 2804617408014 := by decide
theorem cert_e605594152462 : check e605594152462 [[],[]] .smaller = true := by decide
def e605594152474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605594152474 : Closed e605594152474 ∧ code e605594152474 = 2804617408026 := by decide
theorem cert_e605594152474 : check e605594152474 [[],[]] .smaller = true := by decide
def e605594152546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605594152546 : Closed e605594152546 ∧ code e605594152546 = 2804617408098 := by decide
theorem cert_e605594152546 : check e605594152546 [[],[]] .smaller = true := by decide
def e605594152558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605594152558 : Closed e605594152558 ∧ code e605594152558 = 2804617408110 := by decide
theorem cert_e605594152558 : check e605594152558 [[],[]] .smaller = true := by decide
def e605594152566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605594152566 : Closed e605594152566 ∧ code e605594152566 = 2804617408118 := by decide
theorem cert_e605594152566 : check e605594152566 [[],[]] .smaller = true := by decide
def e605594152570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605594152570 : Closed e605594152570 ∧ code e605594152570 = 2804617408122 := by decide
theorem cert_e605594152570 : check e605594152570 [[],[]] .smaller = true := by decide
def e605594152758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605594152758 : Closed e605594152758 ∧ code e605594152758 = 2804617408310 := by decide
theorem cert_e605594152758 : check e605594152758 [[],[]] .three = true := by decide
def e605594152762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605594152762 : Closed e605594152762 ∧ code e605594152762 = 2804617408314 := by decide
theorem cert_e605594152762 : check e605594152762 [[],[]] .three = true := by decide
def e605594153822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e605594153822 : Closed e605594153822 ∧ code e605594153822 = 2804617409374 := by decide
theorem cert_e605594153822 : check e605594153822 [[],[]] .three = true := by decide
def e605594153838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605594153838 : Closed e605594153838 ∧ code e605594153838 = 2804617409390 := by decide
theorem cert_e605594153838 : check e605594153838 [[],[]] .smaller = true := by decide
def e605594153846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605594153846 : Closed e605594153846 ∧ code e605594153846 = 2804617409398 := by decide
theorem cert_e605594153846 : check e605594153846 [[],[]] .smaller = true := by decide
def e605594153850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e605594153850 : Closed e605594153850 ∧ code e605594153850 = 2804617409402 := by decide
theorem cert_e605594153850 : check e605594153850 [[],[]] .three = true := by decide
def e605594153902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605594153902 : Closed e605594153902 ∧ code e605594153902 = 2804617409454 := by decide
theorem cert_e605594153902 : check e605594153902 [[],[]] .smaller = true := by decide
def e605594153914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605594153914 : Closed e605594153914 ∧ code e605594153914 = 2804617409466 := by decide
theorem cert_e605594153914 : check e605594153914 [[],[]] .smaller = true := by decide
def e605594153942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605594153942 : Closed e605594153942 ∧ code e605594153942 = 2804617409494 := by decide
theorem cert_e605594153942 : check e605594153942 [[],[]] .smaller = true := by decide
def e605594153946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605594153946 : Closed e605594153946 ∧ code e605594153946 = 2804617409498 := by decide
theorem cert_e605594153946 : check e605594153946 [[],[]] .smaller = true := by decide
def e605594153962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e605594153962 : Closed e605594153962 ∧ code e605594153962 = 2804617409514 := by decide
theorem cert_e605594153962 : check e605594153962 [[],[]] .three = true := by decide
def e605594154206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605594154206 : Closed e605594154206 ∧ code e605594154206 = 2804617409758 := by decide
theorem cert_e605594154206 : check e605594154206 [[],[]] .three = true := by decide
def e605594154222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605594154222 : Closed e605594154222 ∧ code e605594154222 = 2804617409774 := by decide
theorem cert_e605594154222 : check e605594154222 [[],[]] .smaller = true := by decide
def e605594154230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605594154230 : Closed e605594154230 ∧ code e605594154230 = 2804617409782 := by decide
theorem cert_e605594154230 : check e605594154230 [[],[]] .smaller = true := by decide
def e605594154234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605594154234 : Closed e605594154234 ∧ code e605594154234 = 2804617409786 := by decide
theorem cert_e605594154234 : check e605594154234 [[],[]] .three = true := by decide
def e605594154606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605594154606 : Closed e605594154606 ∧ code e605594154606 = 2804617410158 := by decide
theorem cert_e605594154606 : check e605594154606 [[],[]] .smaller = true := by decide
def e605594154618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605594154618 : Closed e605594154618 ∧ code e605594154618 = 2804617410170 := by decide
theorem cert_e605594154618 : check e605594154618 [[],[]] .smaller = true := by decide
def e605594154806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605594154806 : Closed e605594154806 ∧ code e605594154806 = 2804617410358 := by decide
theorem cert_e605594154806 : check e605594154806 [[],[]] .smaller = true := by decide
def e605594154810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605594154810 : Closed e605594154810 ∧ code e605594154810 = 2804617410362 := by decide
theorem cert_e605594154810 : check e605594154810 [[],[]] .smaller = true := by decide
def e605594154906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605594154906 : Closed e605594154906 ∧ code e605594154906 = 2804617410458 := by decide
theorem cert_e605594154906 : check e605594154906 [[],[]] .three = true := by decide
def e605594155066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0))))))))
theorem wire_e605594155066 : Closed e605594155066 ∧ code e605594155066 = 2804617410618 := by decide
theorem cert_e605594155066 : check e605594155066 [[],[]] .smaller = true := by decide
def e605594155114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e605594155114 : Closed e605594155114 ∧ code e605594155114 = 2804617410666 := by decide
theorem cert_e605594155114 : check e605594155114 [[],[]] .smaller = true := by decide
def e605594155162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e605594155162 : Closed e605594155162 ∧ code e605594155162 = 2804617410714 := by decide
theorem cert_e605594155162 : check e605594155162 [[],[]] .smaller = true := by decide
def e605594155206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1)))))))))
theorem wire_e605594155206 : Closed e605594155206 ∧ code e605594155206 = 2804617410758 := by decide
theorem cert_e605594155206 : check e605594155206 [[],[]] .smaller = true := by decide
def e605594155402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605594155402 : Closed e605594155402 ∧ code e605594155402 = 2804617410954 := by decide
theorem cert_e605594155402 : check e605594155402 [[],[]] .smaller = true := by decide
def e605594155426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e605594155426 : Closed e605594155426 ∧ code e605594155426 = 2804617410978 := by decide
theorem cert_e605594155426 : check e605594155426 [[],[]] .smaller = true := by decide
def e605594155438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605594155438 : Closed e605594155438 ∧ code e605594155438 = 2804617410990 := by decide
theorem cert_e605594155438 : check e605594155438 [[],[]] .smaller = true := by decide
def e605594155446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e605594155446 : Closed e605594155446 ∧ code e605594155446 = 2804617410998 := by decide
theorem cert_e605594155446 : check e605594155446 [[],[]] .smaller = true := by decide
def e605594155450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605594155450 : Closed e605594155450 ∧ code e605594155450 = 2804617411002 := by decide
theorem cert_e605594155450 : check e605594155450 [[],[]] .smaller = true := by decide
def e605594155478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e605594155478 : Closed e605594155478 ∧ code e605594155478 = 2804617411030 := by decide
theorem cert_e605594155478 : check e605594155478 [[],[]] .smaller = true := by decide
def e605594155482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e605594155482 : Closed e605594155482 ∧ code e605594155482 = 2804617411034 := by decide
theorem cert_e605594155482 : check e605594155482 [[],[]] .smaller = true := by decide
def e605594155498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605594155498 : Closed e605594155498 ∧ code e605594155498 = 2804617411050 := by decide
theorem cert_e605594155498 : check e605594155498 [[],[]] .smaller = true := by decide
def e605594155534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2))))))))))
theorem wire_e605594155534 : Closed e605594155534 ∧ code e605594155534 = 2804617411086 := by decide
theorem cert_e605594155534 : check e605594155534 [[],[]] .smaller = true := by decide
def e605594155546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605594155546 : Closed e605594155546 ∧ code e605594155546 = 2804617411098 := by decide
theorem cert_e605594155546 : check e605594155546 [[],[]] .smaller = true := by decide
def e605594155618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605594155618 : Closed e605594155618 ∧ code e605594155618 = 2804617411170 := by decide
theorem cert_e605594155618 : check e605594155618 [[],[]] .smaller = true := by decide
def e605594155630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605594155630 : Closed e605594155630 ∧ code e605594155630 = 2804617411182 := by decide
theorem cert_e605594155630 : check e605594155630 [[],[]] .smaller = true := by decide
def e605594155638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605594155638 : Closed e605594155638 ∧ code e605594155638 = 2804617411190 := by decide
theorem cert_e605594155638 : check e605594155638 [[],[]] .smaller = true := by decide
def e605594155642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605594155642 : Closed e605594155642 ∧ code e605594155642 = 2804617411194 := by decide
theorem cert_e605594155642 : check e605594155642 [[],[]] .smaller = true := by decide
def e605594155830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605594155830 : Closed e605594155830 ∧ code e605594155830 = 2804617411382 := by decide
theorem cert_e605594155830 : check e605594155830 [[],[]] .smaller = true := by decide
def e605594155834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605594155834 : Closed e605594155834 ∧ code e605594155834 = 2804617411386 := by decide
theorem cert_e605594155834 : check e605594155834 [[],[]] .smaller = true := by decide
def e605594155930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605594155930 : Closed e605594155930 ∧ code e605594155930 = 2804617411482 := by decide
theorem cert_e605594155930 : check e605594155930 [[],[]] .smaller = true := by decide
def e605594155998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 3))))))))
theorem wire_e605594155998 : Closed e605594155998 ∧ code e605594155998 = 2804617411550 := by decide
theorem cert_e605594155998 : check e605594155998 [[],[]] .three = true := by decide
def e605594156246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605594156246 : Closed e605594156246 ∧ code e605594156246 = 2804617411798 := by decide
theorem cert_e605594156246 : check e605594156246 [[],[]] .three = true := by decide
def e605594156250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605594156250 : Closed e605594156250 ∧ code e605594156250 = 2804617411802 := by decide
theorem cert_e605594156250 : check e605594156250 [[],[]] .three = true := by decide
def e605594156266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605594156266 : Closed e605594156266 ∧ code e605594156266 = 2804617411818 := by decide
theorem cert_e605594156266 : check e605594156266 [[],[]] .three = true := by decide
def e605594156342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605594156342 : Closed e605594156342 ∧ code e605594156342 = 2804617411894 := by decide
theorem cert_e605594156342 : check e605594156342 [[],[]] .three = true := by decide
def e605594156346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605594156346 : Closed e605594156346 ∧ code e605594156346 = 2804617411898 := by decide
theorem cert_e605594156346 : check e605594156346 [[],[]] .three = true := by decide
def e605594156442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605594156442 : Closed e605594156442 ∧ code e605594156442 = 2804617411994 := by decide
theorem cert_e605594156442 : check e605594156442 [[],[]] .three = true := by decide
def e605594156510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 3))))))))
theorem wire_e605594156510 : Closed e605594156510 ∧ code e605594156510 = 2804617412062 := by decide
theorem cert_e605594156510 : check e605594156510 [[],[]] .three = true := by decide
def e605594156526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 3)) (.var 2))))))))
theorem wire_e605594156526 : Closed e605594156526 ∧ code e605594156526 = 2804617412078 := by decide
theorem cert_e605594156526 : check e605594156526 [[],[]] .three = true := by decide
def e605594159038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e605594159038 : Closed e605594159038 ∧ code e605594159038 = 2804617414590 := by decide
theorem cert_e605594159038 : check e605594159038 [[],[]] .three = true := by decide
def e605594159070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 3))))))))))
theorem wire_e605594159070 : Closed e605594159070 ∧ code e605594159070 = 2804617414622 := by decide
theorem cert_e605594159070 : check e605594159070 [[],[]] .smaller = true := by decide
def e605594159086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e605594159086 : Closed e605594159086 ∧ code e605594159086 = 2804617414638 := by decide
theorem cert_e605594159086 : check e605594159086 [[],[]] .three = true := by decide
def e605594162734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e605594162734 : Closed e605594162734 ∧ code e605594162734 = 2804617418286 := by decide
theorem cert_e605594162734 : check e605594162734 [[],[]] .smaller = true := by decide
def e605594162910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605594162910 : Closed e605594162910 ∧ code e605594162910 = 2804617418462 := by decide
theorem cert_e605594162910 : check e605594162910 [[],[]] .three = true := by decide
def e605594162914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e605594162914 : Closed e605594162914 ∧ code e605594162914 = 2804617418466 := by decide
theorem cert_e605594162914 : check e605594162914 [[],[]] .smaller = true := by decide
def e605594162926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e605594162926 : Closed e605594162926 ∧ code e605594162926 = 2804617418478 := by decide
theorem cert_e605594162926 : check e605594162926 [[],[]] .smaller = true := by decide
def e605594162934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605594162934 : Closed e605594162934 ∧ code e605594162934 = 2804617418486 := by decide
theorem cert_e605594162934 : check e605594162934 [[],[]] .three = true := by decide
def e605594163038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605594163038 : Closed e605594163038 ∧ code e605594163038 = 2804617418590 := by decide
theorem cert_e605594163038 : check e605594163038 [[],[]] .three = true := by decide
def e605594163054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e605594163054 : Closed e605594163054 ∧ code e605594163054 = 2804617418606 := by decide
theorem cert_e605594163054 : check e605594163054 [[],[]] .smaller = true := by decide
def e605594163062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e605594163062 : Closed e605594163062 ∧ code e605594163062 = 2804617418614 := by decide
theorem cert_e605594163062 : check e605594163062 [[],[]] .smaller = true := by decide
def e605594163066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605594163066 : Closed e605594163066 ∧ code e605594163066 = 2804617418618 := by decide
theorem cert_e605594163066 : check e605594163066 [[],[]] .three = true := by decide
def e605594163082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e605594163082 : Closed e605594163082 ∧ code e605594163082 = 2804617418634 := by decide
theorem cert_e605594163082 : check e605594163082 [[],[]] .smaller = true := by decide
def e605594163106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e605594163106 : Closed e605594163106 ∧ code e605594163106 = 2804617418658 := by decide
theorem cert_e605594163106 : check e605594163106 [[],[]] .smaller = true := by decide
def e605594163118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e605594163118 : Closed e605594163118 ∧ code e605594163118 = 2804617418670 := by decide
theorem cert_e605594163118 : check e605594163118 [[],[]] .smaller = true := by decide
def e605594163126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e605594163126 : Closed e605594163126 ∧ code e605594163126 = 2804617418678 := by decide
theorem cert_e605594163126 : check e605594163126 [[],[]] .smaller = true := by decide
def e605594163130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e605594163130 : Closed e605594163130 ∧ code e605594163130 = 2804617418682 := by decide
theorem cert_e605594163130 : check e605594163130 [[],[]] .smaller = true := by decide
def e605594163158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605594163158 : Closed e605594163158 ∧ code e605594163158 = 2804617418710 := by decide
theorem cert_e605594163158 : check e605594163158 [[],[]] .three = true := by decide
def e605594163162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605594163162 : Closed e605594163162 ∧ code e605594163162 = 2804617418714 := by decide
theorem cert_e605594163162 : check e605594163162 [[],[]] .three = true := by decide
def e605594163262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4)))))))))))
theorem wire_e605594163262 : Closed e605594163262 ∧ code e605594163262 = 2804617418814 := by decide
theorem cert_e605594163262 : check e605594163262 [[],[]] .smaller = true := by decide
def e605594163678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605594163678 : Closed e605594163678 ∧ code e605594163678 = 2804617419230 := by decide
theorem cert_e605594163678 : check e605594163678 [[],[]] .three = true := by decide
def e605594163682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e605594163682 : Closed e605594163682 ∧ code e605594163682 = 2804617419234 := by decide
theorem cert_e605594163682 : check e605594163682 [[],[]] .smaller = true := by decide
def e605594163694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e605594163694 : Closed e605594163694 ∧ code e605594163694 = 2804617419246 := by decide
theorem cert_e605594163694 : check e605594163694 [[],[]] .smaller = true := by decide
def e605594163702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605594163702 : Closed e605594163702 ∧ code e605594163702 = 2804617419254 := by decide
theorem cert_e605594163702 : check e605594163702 [[],[]] .three = true := by decide
def e605594164446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605594164446 : Closed e605594164446 ∧ code e605594164446 = 2804617419998 := by decide
theorem cert_e605594164446 : check e605594164446 [[],[]] .three = true := by decide
def e605594164462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e605594164462 : Closed e605594164462 ∧ code e605594164462 = 2804617420014 := by decide
theorem cert_e605594164462 : check e605594164462 [[],[]] .smaller = true := by decide
def e605594164470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e605594164470 : Closed e605594164470 ∧ code e605594164470 = 2804617420022 := by decide
theorem cert_e605594164470 : check e605594164470 [[],[]] .smaller = true := by decide
def e605594164474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605594164474 : Closed e605594164474 ∧ code e605594164474 = 2804617420026 := by decide
theorem cert_e605594164474 : check e605594164474 [[],[]] .three = true := by decide
def e605594164750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2)))))))))))
theorem wire_e605594164750 : Closed e605594164750 ∧ code e605594164750 = 2804617420302 := by decide
theorem cert_e605594164750 : check e605594164750 [[],[]] .smaller = true := by decide
def e605594164762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e605594164762 : Closed e605594164762 ∧ code e605594164762 = 2804617420314 := by decide
theorem cert_e605594164762 : check e605594164762 [[],[]] .smaller = true := by decide
def e605594164834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e605594164834 : Closed e605594164834 ∧ code e605594164834 = 2804617420386 := by decide
theorem cert_e605594164834 : check e605594164834 [[],[]] .smaller = true := by decide
def e605594164846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e605594164846 : Closed e605594164846 ∧ code e605594164846 = 2804617420398 := by decide
theorem cert_e605594164846 : check e605594164846 [[],[]] .smaller = true := by decide
def e605594164854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e605594164854 : Closed e605594164854 ∧ code e605594164854 = 2804617420406 := by decide
theorem cert_e605594164854 : check e605594164854 [[],[]] .smaller = true := by decide
def e605594164858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e605594164858 : Closed e605594164858 ∧ code e605594164858 = 2804617420410 := by decide
theorem cert_e605594164858 : check e605594164858 [[],[]] .smaller = true := by decide
def e605594165046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605594165046 : Closed e605594165046 ∧ code e605594165046 = 2804617420598 := by decide
theorem cert_e605594165046 : check e605594165046 [[],[]] .three = true := by decide
def e605594165050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605594165050 : Closed e605594165050 ∧ code e605594165050 = 2804617420602 := by decide
theorem cert_e605594165050 : check e605594165050 [[],[]] .three = true := by decide
def e605594174398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e605594174398 : Closed e605594174398 ∧ code e605594174398 = 2804617429950 := by decide
theorem cert_e605594174398 : check e605594174398 [[],[]] .three = true := by decide
def e605594174454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e605594174454 : Closed e605594174454 ∧ code e605594174454 = 2804617430006 := by decide
theorem cert_e605594174454 : check e605594174454 [[],[]] .three = true := by decide
def e605594176350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e605594176350 : Closed e605594176350 ∧ code e605594176350 = 2804617431902 := by decide
theorem cert_e605594176350 : check e605594176350 [[],[]] .three = true := by decide
def e605594176366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605594176366 : Closed e605594176366 ∧ code e605594176366 = 2804617431918 := by decide
theorem cert_e605594176366 : check e605594176366 [[],[]] .smaller = true := by decide
def e605594176374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605594176374 : Closed e605594176374 ∧ code e605594176374 = 2804617431926 := by decide
theorem cert_e605594176374 : check e605594176374 [[],[]] .smaller = true := by decide
def e605594176378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e605594176378 : Closed e605594176378 ∧ code e605594176378 = 2804617431930 := by decide
theorem cert_e605594176378 : check e605594176378 [[],[]] .three = true := by decide
def e605594176430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605594176430 : Closed e605594176430 ∧ code e605594176430 = 2804617431982 := by decide
theorem cert_e605594176430 : check e605594176430 [[],[]] .smaller = true := by decide
def e605594176442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605594176442 : Closed e605594176442 ∧ code e605594176442 = 2804617431994 := by decide
theorem cert_e605594176442 : check e605594176442 [[],[]] .smaller = true := by decide
def e605594176470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605594176470 : Closed e605594176470 ∧ code e605594176470 = 2804617432022 := by decide
theorem cert_e605594176470 : check e605594176470 [[],[]] .smaller = true := by decide
def e605594176474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605594176474 : Closed e605594176474 ∧ code e605594176474 = 2804617432026 := by decide
theorem cert_e605594176474 : check e605594176474 [[],[]] .smaller = true := by decide
def e605594176490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e605594176490 : Closed e605594176490 ∧ code e605594176490 = 2804617432042 := by decide
theorem cert_e605594176490 : check e605594176490 [[],[]] .three = true := by decide
def e605594176734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e605594176734 : Closed e605594176734 ∧ code e605594176734 = 2804617432286 := by decide
theorem cert_e605594176734 : check e605594176734 [[],[]] .three = true := by decide
def e605594176750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605594176750 : Closed e605594176750 ∧ code e605594176750 = 2804617432302 := by decide
theorem cert_e605594176750 : check e605594176750 [[],[]] .smaller = true := by decide
def e605594176758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605594176758 : Closed e605594176758 ∧ code e605594176758 = 2804617432310 := by decide
theorem cert_e605594176758 : check e605594176758 [[],[]] .smaller = true := by decide
def e605594176762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e605594176762 : Closed e605594176762 ∧ code e605594176762 = 2804617432314 := by decide
theorem cert_e605594176762 : check e605594176762 [[],[]] .three = true := by decide
def e605594177134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605594177134 : Closed e605594177134 ∧ code e605594177134 = 2804617432686 := by decide
theorem cert_e605594177134 : check e605594177134 [[],[]] .smaller = true := by decide
def e605594177146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605594177146 : Closed e605594177146 ∧ code e605594177146 = 2804617432698 := by decide
theorem cert_e605594177146 : check e605594177146 [[],[]] .smaller = true := by decide
def e605594177334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605594177334 : Closed e605594177334 ∧ code e605594177334 = 2804617432886 := by decide
theorem cert_e605594177334 : check e605594177334 [[],[]] .smaller = true := by decide
def e605594177338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605594177338 : Closed e605594177338 ∧ code e605594177338 = 2804617432890 := by decide
theorem cert_e605594177338 : check e605594177338 [[],[]] .smaller = true := by decide
def e605594177434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e605594177434 : Closed e605594177434 ∧ code e605594177434 = 2804617432986 := by decide
theorem cert_e605594177434 : check e605594177434 [[],[]] .three = true := by decide
def e605594182110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605594182110 : Closed e605594182110 ∧ code e605594182110 = 2804617437662 := by decide
theorem cert_e605594182110 : check e605594182110 [[],[]] .smaller = true := by decide
def e605594182134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605594182134 : Closed e605594182134 ∧ code e605594182134 = 2804617437686 := by decide
theorem cert_e605594182134 : check e605594182134 [[],[]] .smaller = true := by decide
def e605594183050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e605594183050 : Closed e605594183050 ∧ code e605594183050 = 2804617438602 := by decide
theorem cert_e605594183050 : check e605594183050 [[],[]] .smaller = true := by decide
def e605594183074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e605594183074 : Closed e605594183074 ∧ code e605594183074 = 2804617438626 := by decide
theorem cert_e605594183074 : check e605594183074 [[],[]] .smaller = true := by decide
def e605594183086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605594183086 : Closed e605594183086 ∧ code e605594183086 = 2804617438638 := by decide
theorem cert_e605594183086 : check e605594183086 [[],[]] .smaller = true := by decide
def e605594183094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605594183094 : Closed e605594183094 ∧ code e605594183094 = 2804617438646 := by decide
theorem cert_e605594183094 : check e605594183094 [[],[]] .smaller = true := by decide
def e605594183098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605594183098 : Closed e605594183098 ∧ code e605594183098 = 2804617438650 := by decide
theorem cert_e605594183098 : check e605594183098 [[],[]] .smaller = true := by decide
def e605594183126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605594183126 : Closed e605594183126 ∧ code e605594183126 = 2804617438678 := by decide
theorem cert_e605594183126 : check e605594183126 [[],[]] .smaller = true := by decide
def e605594183130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605594183130 : Closed e605594183130 ∧ code e605594183130 = 2804617438682 := by decide
theorem cert_e605594183130 : check e605594183130 [[],[]] .smaller = true := by decide
def e605594183146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605594183146 : Closed e605594183146 ∧ code e605594183146 = 2804617438698 := by decide
theorem cert_e605594183146 : check e605594183146 [[],[]] .smaller = true := by decide
def e605594183182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2)))))))))))
theorem wire_e605594183182 : Closed e605594183182 ∧ code e605594183182 = 2804617438734 := by decide
theorem cert_e605594183182 : check e605594183182 [[],[]] .smaller = true := by decide
def e605594183194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e605594183194 : Closed e605594183194 ∧ code e605594183194 = 2804617438746 := by decide
theorem cert_e605594183194 : check e605594183194 [[],[]] .smaller = true := by decide
def e605594183266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e605594183266 : Closed e605594183266 ∧ code e605594183266 = 2804617438818 := by decide
theorem cert_e605594183266 : check e605594183266 [[],[]] .smaller = true := by decide
def e605594183278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605594183278 : Closed e605594183278 ∧ code e605594183278 = 2804617438830 := by decide
theorem cert_e605594183278 : check e605594183278 [[],[]] .smaller = true := by decide
def e605594183286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605594183286 : Closed e605594183286 ∧ code e605594183286 = 2804617438838 := by decide
theorem cert_e605594183286 : check e605594183286 [[],[]] .smaller = true := by decide
def e605594183290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605594183290 : Closed e605594183290 ∧ code e605594183290 = 2804617438842 := by decide
theorem cert_e605594183290 : check e605594183290 [[],[]] .smaller = true := by decide
def e605594183478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605594183478 : Closed e605594183478 ∧ code e605594183478 = 2804617439030 := by decide
theorem cert_e605594183478 : check e605594183478 [[],[]] .smaller = true := by decide
def e605594183482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605594183482 : Closed e605594183482 ∧ code e605594183482 = 2804617439034 := by decide
theorem cert_e605594183482 : check e605594183482 [[],[]] .smaller = true := by decide
def e605594183578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605594183578 : Closed e605594183578 ∧ code e605594183578 = 2804617439130 := by decide
theorem cert_e605594183578 : check e605594183578 [[],[]] .smaller = true := by decide
def e605594183646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 3)))))))))
theorem wire_e605594183646 : Closed e605594183646 ∧ code e605594183646 = 2804617439198 := by decide
theorem cert_e605594183646 : check e605594183646 [[],[]] .three = true := by decide
def e605594185966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605594185966 : Closed e605594185966 ∧ code e605594185966 = 2804617441518 := by decide
theorem cert_e605594185966 : check e605594185966 [[],[]] .three = true := by decide
def e605594185974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605594185974 : Closed e605594185974 ∧ code e605594185974 = 2804617441526 := by decide
theorem cert_e605594185974 : check e605594185974 [[],[]] .three = true := by decide
def e605594186454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605594186454 : Closed e605594186454 ∧ code e605594186454 = 2804617442006 := by decide
theorem cert_e605594186454 : check e605594186454 [[],[]] .three = true := by decide
def e605594186458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605594186458 : Closed e605594186458 ∧ code e605594186458 = 2804617442010 := by decide
theorem cert_e605594186458 : check e605594186458 [[],[]] .three = true := by decide
def e605594186474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605594186474 : Closed e605594186474 ∧ code e605594186474 = 2804617442026 := by decide
theorem cert_e605594186474 : check e605594186474 [[],[]] .three = true := by decide
def e605594186550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605594186550 : Closed e605594186550 ∧ code e605594186550 = 2804617442102 := by decide
theorem cert_e605594186550 : check e605594186550 [[],[]] .three = true := by decide
def e605594186554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605594186554 : Closed e605594186554 ∧ code e605594186554 = 2804617442106 := by decide
theorem cert_e605594186554 : check e605594186554 [[],[]] .three = true := by decide
def e605594186650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605594186650 : Closed e605594186650 ∧ code e605594186650 = 2804617442202 := by decide
theorem cert_e605594186650 : check e605594186650 [[],[]] .three = true := by decide
def e605594186718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 3)))))))))
theorem wire_e605594186718 : Closed e605594186718 ∧ code e605594186718 = 2804617442270 := by decide
theorem cert_e605594186718 : check e605594186718 [[],[]] .three = true := by decide
def e605594186734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 3) (.var 2)))))))))
theorem wire_e605594186734 : Closed e605594186734 ∧ code e605594186734 = 2804617442286 := by decide
theorem cert_e605594186734 : check e605594186734 [[],[]] .three = true := by decide
def e605594332638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605594332638 : Closed e605594332638 ∧ code e605594332638 = 2804617588190 := by decide
theorem cert_e605594332638 : check e605594332638 [[],[]] .smaller = true := by decide
def e605594332654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605594332654 : Closed e605594332654 ∧ code e605594332654 = 2804617588206 := by decide
theorem cert_e605594332654 : check e605594332654 [[],[]] .smaller = true := by decide
def e605594332910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e605594332910 : Closed e605594332910 ∧ code e605594332910 = 2804617588462 := by decide
theorem cert_e605594332910 : check e605594332910 [[],[]] .smaller = true := by decide
def e605594333022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605594333022 : Closed e605594333022 ∧ code e605594333022 = 2804617588574 := by decide
theorem cert_e605594333022 : check e605594333022 [[],[]] .smaller = true := by decide
def e605594333038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e605594333038 : Closed e605594333038 ∧ code e605594333038 = 2804617588590 := by decide
theorem cert_e605594333038 : check e605594333038 [[],[]] .smaller = true := by decide
def e605594333046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e605594333046 : Closed e605594333046 ∧ code e605594333046 = 2804617588598 := by decide
theorem cert_e605594333046 : check e605594333046 [[],[]] .smaller = true := by decide
def e605594333050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605594333050 : Closed e605594333050 ∧ code e605594333050 = 2804617588602 := by decide
theorem cert_e605594333050 : check e605594333050 [[],[]] .smaller = true := by decide
end Blc.Floor41
