import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605603149998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e605603149998 : Closed e605603149998 ∧ code e605603149998 = 2804626405550 := by decide
theorem cert_e605603149998 : check e605603149998 [[],[]] .smaller = true := by decide
def e605603150010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e605603150010 : Closed e605603150010 ∧ code e605603150010 = 2804626405562 := by decide
theorem cert_e605603150010 : check e605603150010 [[],[]] .smaller = true := by decide
def e605603150382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605603150382 : Closed e605603150382 ∧ code e605603150382 = 2804626405934 := by decide
theorem cert_e605603150382 : check e605603150382 [[],[]] .smaller = true := by decide
def e605603150558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e605603150558 : Closed e605603150558 ∧ code e605603150558 = 2804626406110 := by decide
theorem cert_e605603150558 : check e605603150558 [[],[]] .chain = true := by decide
def e605603150562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605603150562 : Closed e605603150562 ∧ code e605603150562 = 2804626406114 := by decide
theorem cert_e605603150562 : check e605603150562 [[],[]] .smaller = true := by decide
def e605603150574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e605603150574 : Closed e605603150574 ∧ code e605603150574 = 2804626406126 := by decide
theorem cert_e605603150574 : check e605603150574 [[],[]] .smaller = true := by decide
def e605603150582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e605603150582 : Closed e605603150582 ∧ code e605603150582 = 2804626406134 := by decide
theorem cert_e605603150582 : check e605603150582 [[],[]] .chain = true := by decide
def e605603150686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e605603150686 : Closed e605603150686 ∧ code e605603150686 = 2804626406238 := by decide
theorem cert_e605603150686 : check e605603150686 [[],[]] .chain = true := by decide
def e605603150714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e605603150714 : Closed e605603150714 ∧ code e605603150714 = 2804626406266 := by decide
theorem cert_e605603150714 : check e605603150714 [[],[]] .chain = true := by decide
def e605603150730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605603150730 : Closed e605603150730 ∧ code e605603150730 = 2804626406282 := by decide
theorem cert_e605603150730 : check e605603150730 [[],[]] .smaller = true := by decide
def e605603150754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605603150754 : Closed e605603150754 ∧ code e605603150754 = 2804626406306 := by decide
theorem cert_e605603150754 : check e605603150754 [[],[]] .smaller = true := by decide
def e605603150766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e605603150766 : Closed e605603150766 ∧ code e605603150766 = 2804626406318 := by decide
theorem cert_e605603150766 : check e605603150766 [[],[]] .smaller = true := by decide
def e605603150778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e605603150778 : Closed e605603150778 ∧ code e605603150778 = 2804626406330 := by decide
theorem cert_e605603150778 : check e605603150778 [[],[]] .smaller = true := by decide
def e605603150806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e605603150806 : Closed e605603150806 ∧ code e605603150806 = 2804626406358 := by decide
theorem cert_e605603150806 : check e605603150806 [[],[]] .chain = true := by decide
def e605603150810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e605603150810 : Closed e605603150810 ∧ code e605603150810 = 2804626406362 := by decide
theorem cert_e605603150810 : check e605603150810 [[],[]] .chain = true := by decide
def e605603150934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e605603150934 : Closed e605603150934 ∧ code e605603150934 = 2804626406486 := by decide
theorem cert_e605603150934 : check e605603150934 [[],[]] .smaller = true := by decide
def e605603150938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e605603150938 : Closed e605603150938 ∧ code e605603150938 = 2804626406490 := by decide
theorem cert_e605603150938 : check e605603150938 [[],[]] .smaller = true := by decide
def e605603151126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e605603151126 : Closed e605603151126 ∧ code e605603151126 = 2804626406678 := by decide
theorem cert_e605603151126 : check e605603151126 [[],[]] .smaller = true := by decide
def e605603151198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e605603151198 : Closed e605603151198 ∧ code e605603151198 = 2804626406750 := by decide
theorem cert_e605603151198 : check e605603151198 [[],[]] .chain = true := by decide
def e605603151202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e605603151202 : Closed e605603151202 ∧ code e605603151202 = 2804626406754 := by decide
theorem cert_e605603151202 : check e605603151202 [[],[]] .smaller = true := by decide
def e605603151214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605603151214 : Closed e605603151214 ∧ code e605603151214 = 2804626406766 := by decide
theorem cert_e605603151214 : check e605603151214 [[],[]] .smaller = true := by decide
def e605603151222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605603151222 : Closed e605603151222 ∧ code e605603151222 = 2804626406774 := by decide
theorem cert_e605603151222 : check e605603151222 [[],[]] .smaller = true := by decide
def e605603151226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e605603151226 : Closed e605603151226 ∧ code e605603151226 = 2804626406778 := by decide
theorem cert_e605603151226 : check e605603151226 [[],[]] .chain = true := by decide
def e605603151242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605603151242 : Closed e605603151242 ∧ code e605603151242 = 2804626406794 := by decide
theorem cert_e605603151242 : check e605603151242 [[],[]] .smaller = true := by decide
def e605603151266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605603151266 : Closed e605603151266 ∧ code e605603151266 = 2804626406818 := by decide
theorem cert_e605603151266 : check e605603151266 [[],[]] .smaller = true := by decide
def e605603151278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605603151278 : Closed e605603151278 ∧ code e605603151278 = 2804626406830 := by decide
theorem cert_e605603151278 : check e605603151278 [[],[]] .smaller = true := by decide
def e605603151290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605603151290 : Closed e605603151290 ∧ code e605603151290 = 2804626406842 := by decide
theorem cert_e605603151290 : check e605603151290 [[],[]] .smaller = true := by decide
def e605603151318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605603151318 : Closed e605603151318 ∧ code e605603151318 = 2804626406870 := by decide
theorem cert_e605603151318 : check e605603151318 [[],[]] .smaller = true := by decide
def e605603151322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605603151322 : Closed e605603151322 ∧ code e605603151322 = 2804626406874 := by decide
theorem cert_e605603151322 : check e605603151322 [[],[]] .smaller = true := by decide
def e605603151338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e605603151338 : Closed e605603151338 ∧ code e605603151338 = 2804626406890 := by decide
theorem cert_e605603151338 : check e605603151338 [[],[]] .chain = true := by decide
def e605603151534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605603151534 : Closed e605603151534 ∧ code e605603151534 = 2804626407086 := by decide
theorem cert_e605603151534 : check e605603151534 [[],[]] .chain = true := by decide
def e605603151542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e605603151542 : Closed e605603151542 ∧ code e605603151542 = 2804626407094 := by decide
theorem cert_e605603151542 : check e605603151542 [[],[]] .chain = true := by decide
def e605603151546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605603151546 : Closed e605603151546 ∧ code e605603151546 = 2804626407098 := by decide
theorem cert_e605603151546 : check e605603151546 [[],[]] .chain = true := by decide
def e605603151574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e605603151574 : Closed e605603151574 ∧ code e605603151574 = 2804626407126 := by decide
theorem cert_e605603151574 : check e605603151574 [[],[]] .chain = true := by decide
def e605603151578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e605603151578 : Closed e605603151578 ∧ code e605603151578 = 2804626407130 := by decide
theorem cert_e605603151578 : check e605603151578 [[],[]] .chain = true := by decide
def e605603151594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605603151594 : Closed e605603151594 ∧ code e605603151594 = 2804626407146 := by decide
theorem cert_e605603151594 : check e605603151594 [[],[]] .chain = true := by decide
def e605603152366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2))))))))
theorem wire_e605603152366 : Closed e605603152366 ∧ code e605603152366 = 2804626407918 := by decide
theorem cert_e605603152366 : check e605603152366 [[],[]] .smaller = true := by decide
def e605603152374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1))))))))
theorem wire_e605603152374 : Closed e605603152374 ∧ code e605603152374 = 2804626407926 := by decide
theorem cert_e605603152374 : check e605603152374 [[],[]] .smaller = true := by decide
def e605603153134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e605603153134 : Closed e605603153134 ∧ code e605603153134 = 2804626408686 := by decide
theorem cert_e605603153134 : check e605603153134 [[],[]] .smaller = true := by decide
def e605603153142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e605603153142 : Closed e605603153142 ∧ code e605603153142 = 2804626408694 := by decide
theorem cert_e605603153142 : check e605603153142 [[],[]] .smaller = true := by decide
def e605603153694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3)))))))))
theorem wire_e605603153694 : Closed e605603153694 ∧ code e605603153694 = 2804626409246 := by decide
theorem cert_e605603153694 : check e605603153694 [[],[]] .smaller = true := by decide
def e605603153806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2)))))))))
theorem wire_e605603153806 : Closed e605603153806 ∧ code e605603153806 = 2804626409358 := by decide
theorem cert_e605603153806 : check e605603153806 [[],[]] .smaller = true := by decide
def e605603155422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e605603155422 : Closed e605603155422 ∧ code e605603155422 = 2804626410974 := by decide
theorem cert_e605603155422 : check e605603155422 [[],[]] .chain = true := by decide
def e605603155438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e605603155438 : Closed e605603155438 ∧ code e605603155438 = 2804626410990 := by decide
theorem cert_e605603155438 : check e605603155438 [[],[]] .chain = true := by decide
def e605603155502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605603155502 : Closed e605603155502 ∧ code e605603155502 = 2804626411054 := by decide
theorem cert_e605603155502 : check e605603155502 [[],[]] .smaller = true := by decide
def e605603155678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e605603155678 : Closed e605603155678 ∧ code e605603155678 = 2804626411230 := by decide
theorem cert_e605603155678 : check e605603155678 [[],[]] .chain = true := by decide
def e605603155682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e605603155682 : Closed e605603155682 ∧ code e605603155682 = 2804626411234 := by decide
theorem cert_e605603155682 : check e605603155682 [[],[]] .smaller = true := by decide
def e605603155694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e605603155694 : Closed e605603155694 ∧ code e605603155694 = 2804626411246 := by decide
theorem cert_e605603155694 : check e605603155694 [[],[]] .smaller = true := by decide
def e605603155702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e605603155702 : Closed e605603155702 ∧ code e605603155702 = 2804626411254 := by decide
theorem cert_e605603155702 : check e605603155702 [[],[]] .chain = true := by decide
def e605603155734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605603155734 : Closed e605603155734 ∧ code e605603155734 = 2804626411286 := by decide
theorem cert_e605603155734 : check e605603155734 [[],[]] .smaller = true := by decide
def e605603155806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e605603155806 : Closed e605603155806 ∧ code e605603155806 = 2804626411358 := by decide
theorem cert_e605603155806 : check e605603155806 [[],[]] .chain = true := by decide
def e605603155810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e605603155810 : Closed e605603155810 ∧ code e605603155810 = 2804626411362 := by decide
theorem cert_e605603155810 : check e605603155810 [[],[]] .smaller = true := by decide
def e605603155822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e605603155822 : Closed e605603155822 ∧ code e605603155822 = 2804626411374 := by decide
theorem cert_e605603155822 : check e605603155822 [[],[]] .smaller = true := by decide
def e605603155830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e605603155830 : Closed e605603155830 ∧ code e605603155830 = 2804626411382 := by decide
theorem cert_e605603155830 : check e605603155830 [[],[]] .smaller = true := by decide
def e605603155834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e605603155834 : Closed e605603155834 ∧ code e605603155834 = 2804626411386 := by decide
theorem cert_e605603155834 : check e605603155834 [[],[]] .chain = true := by decide
def e605603155886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e605603155886 : Closed e605603155886 ∧ code e605603155886 = 2804626411438 := by decide
theorem cert_e605603155886 : check e605603155886 [[],[]] .chain = true := by decide
def e605603155894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e605603155894 : Closed e605603155894 ∧ code e605603155894 = 2804626411446 := by decide
theorem cert_e605603155894 : check e605603155894 [[],[]] .chain = true := by decide
def e605603155898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e605603155898 : Closed e605603155898 ∧ code e605603155898 = 2804626411450 := by decide
theorem cert_e605603155898 : check e605603155898 [[],[]] .chain = true := by decide
def e605603156958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e605603156958 : Closed e605603156958 ∧ code e605603156958 = 2804626412510 := by decide
theorem cert_e605603156958 : check e605603156958 [[],[]] .chain = true := by decide
def e605603156974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e605603156974 : Closed e605603156974 ∧ code e605603156974 = 2804626412526 := by decide
theorem cert_e605603156974 : check e605603156974 [[],[]] .chain = true := by decide
def e605603158078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4))))))))))
theorem wire_e605603158078 : Closed e605603158078 ∧ code e605603158078 = 2804626413630 := by decide
theorem cert_e605603158078 : check e605603158078 [[],[]] .smaller = true := by decide
def e605603158494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605603158494 : Closed e605603158494 ∧ code e605603158494 = 2804626414046 := by decide
theorem cert_e605603158494 : check e605603158494 [[],[]] .chain = true := by decide
def e605603158498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605603158498 : Closed e605603158498 ∧ code e605603158498 = 2804626414050 := by decide
theorem cert_e605603158498 : check e605603158498 [[],[]] .smaller = true := by decide
def e605603158510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e605603158510 : Closed e605603158510 ∧ code e605603158510 = 2804626414062 := by decide
theorem cert_e605603158510 : check e605603158510 [[],[]] .smaller = true := by decide
def e605603158518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605603158518 : Closed e605603158518 ∧ code e605603158518 = 2804626414070 := by decide
theorem cert_e605603158518 : check e605603158518 [[],[]] .chain = true := by decide
def e605603159070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3))))))))))
theorem wire_e605603159070 : Closed e605603159070 ∧ code e605603159070 = 2804626414622 := by decide
theorem cert_e605603159070 : check e605603159070 [[],[]] .smaller = true := by decide
def e605603159262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605603159262 : Closed e605603159262 ∧ code e605603159262 = 2804626414814 := by decide
theorem cert_e605603159262 : check e605603159262 [[],[]] .chain = true := by decide
def e605603159266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e605603159266 : Closed e605603159266 ∧ code e605603159266 = 2804626414818 := by decide
theorem cert_e605603159266 : check e605603159266 [[],[]] .smaller = true := by decide
def e605603159278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605603159278 : Closed e605603159278 ∧ code e605603159278 = 2804626414830 := by decide
theorem cert_e605603159278 : check e605603159278 [[],[]] .smaller = true := by decide
def e605603159286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605603159286 : Closed e605603159286 ∧ code e605603159286 = 2804626414838 := by decide
theorem cert_e605603159286 : check e605603159286 [[],[]] .smaller = true := by decide
def e605603159290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605603159290 : Closed e605603159290 ∧ code e605603159290 = 2804626414842 := by decide
theorem cert_e605603159290 : check e605603159290 [[],[]] .chain = true := by decide
def e605603159662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605603159662 : Closed e605603159662 ∧ code e605603159662 = 2804626415214 := by decide
theorem cert_e605603159662 : check e605603159662 [[],[]] .chain = true := by decide
def e605603159670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605603159670 : Closed e605603159670 ∧ code e605603159670 = 2804626415222 := by decide
theorem cert_e605603159670 : check e605603159670 [[],[]] .chain = true := by decide
def e605603159674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605603159674 : Closed e605603159674 ∧ code e605603159674 = 2804626415226 := by decide
theorem cert_e605603159674 : check e605603159674 [[],[]] .chain = true := by decide
def e605603160302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2))))))))
theorem wire_e605603160302 : Closed e605603160302 ∧ code e605603160302 = 2804626415854 := by decide
theorem cert_e605603160302 : check e605603160302 [[],[]] .smaller = true := by decide
def e605603160314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0))))))))
theorem wire_e605603160314 : Closed e605603160314 ∧ code e605603160314 = 2804626415866 := by decide
theorem cert_e605603160314 : check e605603160314 [[],[]] .smaller = true := by decide
def e605603160686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e605603160686 : Closed e605603160686 ∧ code e605603160686 = 2804626416238 := by decide
theorem cert_e605603160686 : check e605603160686 [[],[]] .smaller = true := by decide
def e605603160698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e605603160698 : Closed e605603160698 ∧ code e605603160698 = 2804626416250 := by decide
theorem cert_e605603160698 : check e605603160698 [[],[]] .smaller = true := by decide
def e605603160862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3)))))))))
theorem wire_e605603160862 : Closed e605603160862 ∧ code e605603160862 = 2804626416414 := by decide
theorem cert_e605603160862 : check e605603160862 [[],[]] .smaller = true := by decide
def e605603161030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1)))))))))
theorem wire_e605603161030 : Closed e605603161030 ∧ code e605603161030 = 2804626416582 := by decide
theorem cert_e605603161030 : check e605603161030 [[],[]] .smaller = true := by decide
def e605603161054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 3))))))))
theorem wire_e605603161054 : Closed e605603161054 ∧ code e605603161054 = 2804626416606 := by decide
theorem cert_e605603161054 : check e605603161054 [[],[]] .chain = true := by decide
def e605603161070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 2))))))))
theorem wire_e605603161070 : Closed e605603161070 ∧ code e605603161070 = 2804626416622 := by decide
theorem cert_e605603161070 : check e605603161070 [[],[]] .chain = true := by decide
def e605603161646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605603161646 : Closed e605603161646 ∧ code e605603161646 = 2804626417198 := by decide
theorem cert_e605603161646 : check e605603161646 [[],[]] .smaller = true := by decide
def e605603161822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e605603161822 : Closed e605603161822 ∧ code e605603161822 = 2804626417374 := by decide
theorem cert_e605603161822 : check e605603161822 [[],[]] .chain = true := by decide
def e605603161826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e605603161826 : Closed e605603161826 ∧ code e605603161826 = 2804626417378 := by decide
theorem cert_e605603161826 : check e605603161826 [[],[]] .smaller = true := by decide
def e605603161838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e605603161838 : Closed e605603161838 ∧ code e605603161838 = 2804626417390 := by decide
theorem cert_e605603161838 : check e605603161838 [[],[]] .smaller = true := by decide
def e605603161846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e605603161846 : Closed e605603161846 ∧ code e605603161846 = 2804626417398 := by decide
theorem cert_e605603161846 : check e605603161846 [[],[]] .chain = true := by decide
def e605603161950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e605603161950 : Closed e605603161950 ∧ code e605603161950 = 2804626417502 := by decide
theorem cert_e605603161950 : check e605603161950 [[],[]] .chain = true := by decide
def e605603161978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e605603161978 : Closed e605603161978 ∧ code e605603161978 = 2804626417530 := by decide
theorem cert_e605603161978 : check e605603161978 [[],[]] .chain = true := by decide
def e605603161994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605603161994 : Closed e605603161994 ∧ code e605603161994 = 2804626417546 := by decide
theorem cert_e605603161994 : check e605603161994 [[],[]] .smaller = true := by decide
def e605603162018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e605603162018 : Closed e605603162018 ∧ code e605603162018 = 2804626417570 := by decide
theorem cert_e605603162018 : check e605603162018 [[],[]] .smaller = true := by decide
def e605603162030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e605603162030 : Closed e605603162030 ∧ code e605603162030 = 2804626417582 := by decide
theorem cert_e605603162030 : check e605603162030 [[],[]] .smaller = true := by decide
def e605603162042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e605603162042 : Closed e605603162042 ∧ code e605603162042 = 2804626417594 := by decide
theorem cert_e605603162042 : check e605603162042 [[],[]] .smaller = true := by decide
def e605603162070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e605603162070 : Closed e605603162070 ∧ code e605603162070 = 2804626417622 := by decide
theorem cert_e605603162070 : check e605603162070 [[],[]] .chain = true := by decide
def e605603162074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e605603162074 : Closed e605603162074 ∧ code e605603162074 = 2804626417626 := by decide
theorem cert_e605603162074 : check e605603162074 [[],[]] .chain = true := by decide
def e605603162174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4))))))))))
theorem wire_e605603162174 : Closed e605603162174 ∧ code e605603162174 = 2804626417726 := by decide
theorem cert_e605603162174 : check e605603162174 [[],[]] .smaller = true := by decide
def e605603162590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605603162590 : Closed e605603162590 ∧ code e605603162590 = 2804626418142 := by decide
theorem cert_e605603162590 : check e605603162590 [[],[]] .chain = true := by decide
def e605603162594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605603162594 : Closed e605603162594 ∧ code e605603162594 = 2804626418146 := by decide
theorem cert_e605603162594 : check e605603162594 [[],[]] .smaller = true := by decide
def e605603162606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e605603162606 : Closed e605603162606 ∧ code e605603162606 = 2804626418158 := by decide
theorem cert_e605603162606 : check e605603162606 [[],[]] .smaller = true := by decide
def e605603162614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605603162614 : Closed e605603162614 ∧ code e605603162614 = 2804626418166 := by decide
theorem cert_e605603162614 : check e605603162614 [[],[]] .chain = true := by decide
def e605603163358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605603163358 : Closed e605603163358 ∧ code e605603163358 = 2804626418910 := by decide
theorem cert_e605603163358 : check e605603163358 [[],[]] .chain = true := by decide
def e605603163386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605603163386 : Closed e605603163386 ∧ code e605603163386 = 2804626418938 := by decide
theorem cert_e605603163386 : check e605603163386 [[],[]] .chain = true := by decide
def e605603163662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2))))))))))
theorem wire_e605603163662 : Closed e605603163662 ∧ code e605603163662 = 2804626419214 := by decide
theorem cert_e605603163662 : check e605603163662 [[],[]] .smaller = true := by decide
def e605603163710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e605603163710 : Closed e605603163710 ∧ code e605603163710 = 2804626419262 := by decide
theorem cert_e605603163710 : check e605603163710 [[],[]] .chain = true := by decide
def e605603163746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605603163746 : Closed e605603163746 ∧ code e605603163746 = 2804626419298 := by decide
theorem cert_e605603163746 : check e605603163746 [[],[]] .smaller = true := by decide
def e605603163758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605603163758 : Closed e605603163758 ∧ code e605603163758 = 2804626419310 := by decide
theorem cert_e605603163758 : check e605603163758 [[],[]] .smaller = true := by decide
def e605603163770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605603163770 : Closed e605603163770 ∧ code e605603163770 = 2804626419322 := by decide
theorem cert_e605603163770 : check e605603163770 [[],[]] .smaller = true := by decide
def e605603163934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e605603163934 : Closed e605603163934 ∧ code e605603163934 = 2804626419486 := by decide
theorem cert_e605603163934 : check e605603163934 [[],[]] .chain = true := by decide
def e605603163958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605603163958 : Closed e605603163958 ∧ code e605603163958 = 2804626419510 := by decide
theorem cert_e605603163958 : check e605603163958 [[],[]] .chain = true := by decide
def e605603163962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605603163962 : Closed e605603163962 ∧ code e605603163962 = 2804626419514 := by decide
theorem cert_e605603163962 : check e605603163962 [[],[]] .chain = true := by decide
def e605603164278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e605603164278 : Closed e605603164278 ∧ code e605603164278 = 2804626419830 := by decide
theorem cert_e605603164278 : check e605603164278 [[],[]] .smaller = true := by decide
def e605603164282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e605603164282 : Closed e605603164282 ∧ code e605603164282 = 2804626419834 := by decide
theorem cert_e605603164282 : check e605603164282 [[],[]] .smaller = true := by decide
def e605603164470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e605603164470 : Closed e605603164470 ∧ code e605603164470 = 2804626420022 := by decide
theorem cert_e605603164470 : check e605603164470 [[],[]] .smaller = true := by decide
def e605603164474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e605603164474 : Closed e605603164474 ∧ code e605603164474 = 2804626420026 := by decide
theorem cert_e605603164474 : check e605603164474 [[],[]] .smaller = true := by decide
def e605603164558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e605603164558 : Closed e605603164558 ∧ code e605603164558 = 2804626420110 := by decide
theorem cert_e605603164558 : check e605603164558 [[],[]] .smaller = true := by decide
def e605603164614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e605603164614 : Closed e605603164614 ∧ code e605603164614 = 2804626420166 := by decide
theorem cert_e605603164614 : check e605603164614 [[],[]] .smaller = true := by decide
def e605603164638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 3))))))))
theorem wire_e605603164638 : Closed e605603164638 ∧ code e605603164638 = 2804626420190 := by decide
theorem cert_e605603164638 : check e605603164638 [[],[]] .chain = true := by decide
def e605603164662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 1))))))))
theorem wire_e605603164662 : Closed e605603164662 ∧ code e605603164662 = 2804626420214 := by decide
theorem cert_e605603164662 : check e605603164662 [[],[]] .chain = true := by decide
def e605603164950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605603164950 : Closed e605603164950 ∧ code e605603164950 = 2804626420502 := by decide
theorem cert_e605603164950 : check e605603164950 [[],[]] .smaller = true := by decide
def e605603165022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e605603165022 : Closed e605603165022 ∧ code e605603165022 = 2804626420574 := by decide
theorem cert_e605603165022 : check e605603165022 [[],[]] .chain = true := by decide
def e605603165026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e605603165026 : Closed e605603165026 ∧ code e605603165026 = 2804626420578 := by decide
theorem cert_e605603165026 : check e605603165026 [[],[]] .smaller = true := by decide
def e605603165038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605603165038 : Closed e605603165038 ∧ code e605603165038 = 2804626420590 := by decide
theorem cert_e605603165038 : check e605603165038 [[],[]] .smaller = true := by decide
def e605603165046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605603165046 : Closed e605603165046 ∧ code e605603165046 = 2804626420598 := by decide
theorem cert_e605603165046 : check e605603165046 [[],[]] .smaller = true := by decide
def e605603165050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e605603165050 : Closed e605603165050 ∧ code e605603165050 = 2804626420602 := by decide
theorem cert_e605603165050 : check e605603165050 [[],[]] .chain = true := by decide
def e605603165066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605603165066 : Closed e605603165066 ∧ code e605603165066 = 2804626420618 := by decide
theorem cert_e605603165066 : check e605603165066 [[],[]] .smaller = true := by decide
def e605603165090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e605603165090 : Closed e605603165090 ∧ code e605603165090 = 2804626420642 := by decide
theorem cert_e605603165090 : check e605603165090 [[],[]] .smaller = true := by decide
def e605603165102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605603165102 : Closed e605603165102 ∧ code e605603165102 = 2804626420654 := by decide
theorem cert_e605603165102 : check e605603165102 [[],[]] .smaller = true := by decide
def e605603165114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605603165114 : Closed e605603165114 ∧ code e605603165114 = 2804626420666 := by decide
theorem cert_e605603165114 : check e605603165114 [[],[]] .smaller = true := by decide
def e605603165142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605603165142 : Closed e605603165142 ∧ code e605603165142 = 2804626420694 := by decide
theorem cert_e605603165142 : check e605603165142 [[],[]] .smaller = true := by decide
def e605603165146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605603165146 : Closed e605603165146 ∧ code e605603165146 = 2804626420698 := by decide
theorem cert_e605603165146 : check e605603165146 [[],[]] .smaller = true := by decide
def e605603165162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e605603165162 : Closed e605603165162 ∧ code e605603165162 = 2804626420714 := by decide
theorem cert_e605603165162 : check e605603165162 [[],[]] .chain = true := by decide
def e605603165214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e605603165214 : Closed e605603165214 ∧ code e605603165214 = 2804626420766 := by decide
theorem cert_e605603165214 : check e605603165214 [[],[]] .smaller = true := by decide
def e605603165406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605603165406 : Closed e605603165406 ∧ code e605603165406 = 2804626420958 := by decide
theorem cert_e605603165406 : check e605603165406 [[],[]] .chain = true := by decide
def e605603165410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e605603165410 : Closed e605603165410 ∧ code e605603165410 = 2804626420962 := by decide
theorem cert_e605603165410 : check e605603165410 [[],[]] .smaller = true := by decide
def e605603165422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605603165422 : Closed e605603165422 ∧ code e605603165422 = 2804626420974 := by decide
theorem cert_e605603165422 : check e605603165422 [[],[]] .smaller = true := by decide
def e605603165430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605603165430 : Closed e605603165430 ∧ code e605603165430 = 2804626420982 := by decide
theorem cert_e605603165430 : check e605603165430 [[],[]] .smaller = true := by decide
def e605603165434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605603165434 : Closed e605603165434 ∧ code e605603165434 = 2804626420986 := by decide
theorem cert_e605603165434 : check e605603165434 [[],[]] .chain = true := by decide
def e605603165710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e605603165710 : Closed e605603165710 ∧ code e605603165710 = 2804626421262 := by decide
theorem cert_e605603165710 : check e605603165710 [[],[]] .smaller = true := by decide
def e605603165758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e605603165758 : Closed e605603165758 ∧ code e605603165758 = 2804626421310 := by decide
theorem cert_e605603165758 : check e605603165758 [[],[]] .chain = true := by decide
def e605603165794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605603165794 : Closed e605603165794 ∧ code e605603165794 = 2804626421346 := by decide
theorem cert_e605603165794 : check e605603165794 [[],[]] .smaller = true := by decide
def e605603165806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605603165806 : Closed e605603165806 ∧ code e605603165806 = 2804626421358 := by decide
theorem cert_e605603165806 : check e605603165806 [[],[]] .smaller = true := by decide
def e605603165818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605603165818 : Closed e605603165818 ∧ code e605603165818 = 2804626421370 := by decide
theorem cert_e605603165818 : check e605603165818 [[],[]] .smaller = true := by decide
def e605603166006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605603166006 : Closed e605603166006 ∧ code e605603166006 = 2804626421558 := by decide
theorem cert_e605603166006 : check e605603166006 [[],[]] .smaller = true := by decide
def e605603166010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605603166010 : Closed e605603166010 ∧ code e605603166010 = 2804626421562 := by decide
theorem cert_e605603166010 : check e605603166010 [[],[]] .smaller = true := by decide
def e605603166094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e605603166094 : Closed e605603166094 ∧ code e605603166094 = 2804626421646 := by decide
theorem cert_e605603166094 : check e605603166094 [[],[]] .chain = true := by decide
def e605603166106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603166106 : Closed e605603166106 ∧ code e605603166106 = 2804626421658 := by decide
theorem cert_e605603166106 : check e605603166106 [[],[]] .chain = true := by decide
def e605603166446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605603166446 : Closed e605603166446 ∧ code e605603166446 = 2804626421998 := by decide
theorem cert_e605603166446 : check e605603166446 [[],[]] .chain = true := by decide
def e605603166454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605603166454 : Closed e605603166454 ∧ code e605603166454 = 2804626422006 := by decide
theorem cert_e605603166454 : check e605603166454 [[],[]] .chain = true := by decide
def e605603166638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605603166638 : Closed e605603166638 ∧ code e605603166638 = 2804626422190 := by decide
theorem cert_e605603166638 : check e605603166638 [[],[]] .chain = true := by decide
def e605603166646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e605603166646 : Closed e605603166646 ∧ code e605603166646 = 2804626422198 := by decide
theorem cert_e605603166646 : check e605603166646 [[],[]] .chain = true := by decide
def e605603166650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605603166650 : Closed e605603166650 ∧ code e605603166650 = 2804626422202 := by decide
theorem cert_e605603166650 : check e605603166650 [[],[]] .chain = true := by decide
def e605603166678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e605603166678 : Closed e605603166678 ∧ code e605603166678 = 2804626422230 := by decide
theorem cert_e605603166678 : check e605603166678 [[],[]] .chain = true := by decide
def e605603166682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e605603166682 : Closed e605603166682 ∧ code e605603166682 = 2804626422234 := by decide
theorem cert_e605603166682 : check e605603166682 [[],[]] .chain = true := by decide
def e605603166698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605603166698 : Closed e605603166698 ∧ code e605603166698 = 2804626422250 := by decide
theorem cert_e605603166698 : check e605603166698 [[],[]] .chain = true := by decide
def e605603166830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605603166830 : Closed e605603166830 ∧ code e605603166830 = 2804626422382 := by decide
theorem cert_e605603166830 : check e605603166830 [[],[]] .chain = true := by decide
def e605603166838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605603166838 : Closed e605603166838 ∧ code e605603166838 = 2804626422390 := by decide
theorem cert_e605603166838 : check e605603166838 [[],[]] .chain = true := by decide
def e605603166842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605603166842 : Closed e605603166842 ∧ code e605603166842 = 2804626422394 := by decide
theorem cert_e605603166842 : check e605603166842 [[],[]] .chain = true := by decide
def e605603167006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605603167006 : Closed e605603167006 ∧ code e605603167006 = 2804626422558 := by decide
theorem cert_e605603167006 : check e605603167006 [[],[]] .chain = true := by decide
def e605603167030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605603167030 : Closed e605603167030 ∧ code e605603167030 = 2804626422582 := by decide
theorem cert_e605603167030 : check e605603167030 [[],[]] .chain = true := by decide
def e605603167034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605603167034 : Closed e605603167034 ∧ code e605603167034 = 2804626422586 := by decide
theorem cert_e605603167034 : check e605603167034 [[],[]] .chain = true := by decide
end Blc.Floor41
