import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605605566946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605605566946 : Closed e605605566946 ∧ code e605605566946 = 2804628822498 := by decide
theorem cert_e605605566946 : check e605605566946 [[],[]] .sourceHead = true := by decide
def e605605566958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e605605566958 : Closed e605605566958 ∧ code e605605566958 = 2804628822510 := by decide
theorem cert_e605605566958 : check e605605566958 [[],[]] .sourceHead = true := by decide
def e605605567542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e605605567542 : Closed e605605567542 ∧ code e605605567542 = 2804628823094 := by decide
theorem cert_e605605567542 : check e605605567542 [[],[]] .chain = true := by decide
def e605605567546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e605605567546 : Closed e605605567546 ∧ code e605605567546 = 2804628823098 := by decide
theorem cert_e605605567546 : check e605605567546 [[],[]] .chain = true := by decide
def e605605567686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e605605567686 : Closed e605605567686 ∧ code e605605567686 = 2804628823238 := by decide
theorem cert_e605605567686 : check e605605567686 [[],[]] .chain = true := by decide
def e605605568014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e605605568014 : Closed e605605568014 ∧ code e605605568014 = 2804628823566 := by decide
theorem cert_e605605568014 : check e605605568014 [[],[]] .sourceHead = true := by decide
def e605605568098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605605568098 : Closed e605605568098 ∧ code e605605568098 = 2804628823650 := by decide
theorem cert_e605605568098 : check e605605568098 [[],[]] .sourceHead = true := by decide
def e605605568110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e605605568110 : Closed e605605568110 ∧ code e605605568110 = 2804628823662 := by decide
theorem cert_e605605568110 : check e605605568110 [[],[]] .sourceHead = true := by decide
def e605605568122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e605605568122 : Closed e605605568122 ∧ code e605605568122 = 2804628823674 := by decide
theorem cert_e605605568122 : check e605605568122 [[],[]] .sourceHead = true := by decide
def e605606129086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e605606129086 : Closed e605606129086 ∧ code e605606129086 = 2804629384638 := by decide
theorem cert_e605606129086 : check e605606129086 [[],[],[.under,.under]] .three = true := by decide
def e605606129142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e605606129142 : Closed e605606129142 ∧ code e605606129142 = 2804629384694 := by decide
theorem cert_e605606129142 : check e605606129142 [[],[],[.under,.under]] .three = true := by decide
def e605606129342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e605606129342 : Closed e605606129342 ∧ code e605606129342 = 2804629384894 := by decide
theorem cert_e605606129342 : check e605606129342 [[],[],[.under,.under]] .three = true := by decide
def e605606129402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e605606129402 : Closed e605606129402 ∧ code e605606129402 = 2804629384954 := by decide
private def t_e605606129402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem cert_e605606129402 : ¬ IsSelfInterpreter e605606129402 :=
  wSource (t := t_e605606129402) (replay_sound (ps := []) (t := e605606129402) (by decide)) (by decide)
def e605606129622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e605606129622 : Closed e605606129622 ∧ code e605606129622 = 2804629385174 := by decide
theorem cert_e605606129622 : check e605606129622 [[],[],[.under,.under]] .three = true := by decide
def e605606129626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e605606129626 : Closed e605606129626 ∧ code e605606129626 = 2804629385178 := by decide
private def t_e605606129626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem cert_e605606129626 : ¬ IsSelfInterpreter e605606129626 :=
  wSource (t := t_e605606129626) (replay_sound (ps := []) (t := e605606129626) (by decide)) (by decide)
def e605606130622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e605606130622 : Closed e605606130622 ∧ code e605606130622 = 2804629386174 := by decide
theorem cert_e605606130622 : check e605606130622 [[],[],[.under,.under]] .three = true := by decide
def e605606130678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e605606130678 : Closed e605606130678 ∧ code e605606130678 = 2804629386230 := by decide
theorem cert_e605606130678 : check e605606130678 [[],[],[.under,.under]] .three = true := by decide
def e605606132158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e605606132158 : Closed e605606132158 ∧ code e605606132158 = 2804629387710 := by decide
theorem cert_e605606132158 : check e605606132158 [[],[],[.under,.under]] .three = true := by decide
def e605606132218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e605606132218 : Closed e605606132218 ∧ code e605606132218 = 2804629387770 := by decide
theorem cert_e605606132218 : check e605606132218 [[],[],[.under,.under]] .three = true := by decide
def e605606133558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e605606133558 : Closed e605606133558 ∧ code e605606133558 = 2804629389110 := by decide
theorem cert_e605606133558 : check e605606133558 [[],[],[.under,.under]] .three = true := by decide
def e605606133562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e605606133562 : Closed e605606133562 ∧ code e605606133562 = 2804629389114 := by decide
theorem cert_e605606133562 : check e605606133562 [[],[],[.under,.under]] .three = true := by decide
def e605606161774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605606161774 : Closed e605606161774 ∧ code e605606161774 = 2804629417326 := by decide
private def t_e605606161774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem cert_e605606161774 : ¬ IsSelfInterpreter e605606161774 :=
  wSource (t := t_e605606161774) (replay_sound (ps := []) (t := e605606161774) (by decide)) (by decide)
def e605606161782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605606161782 : Closed e605606161782 ∧ code e605606161782 = 2804629417334 := by decide
private def t_e605606161782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem cert_e605606161782 : ¬ IsSelfInterpreter e605606161782 :=
  wSource (t := t_e605606161782) (replay_sound (ps := []) (t := e605606161782) (by decide)) (by decide)
def e605606161838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605606161838 : Closed e605606161838 ∧ code e605606161838 = 2804629417390 := by decide
theorem cert_e605606161838 : check e605606161838 [[],[],[.under,.under]] .three = true := by decide
def e605606161850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605606161850 : Closed e605606161850 ∧ code e605606161850 = 2804629417402 := by decide
theorem cert_e605606161850 : check e605606161850 [[],[],[.under,.under]] .three = true := by decide
def e605606161878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605606161878 : Closed e605606161878 ∧ code e605606161878 = 2804629417430 := by decide
theorem cert_e605606161878 : check e605606161878 [[],[],[.under,.under]] .three = true := by decide
def e605606161882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605606161882 : Closed e605606161882 ∧ code e605606161882 = 2804629417434 := by decide
theorem cert_e605606161882 : check e605606161882 [[],[],[.under,.under]] .three = true := by decide
def e605606162094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605606162094 : Closed e605606162094 ∧ code e605606162094 = 2804629417646 := by decide
theorem cert_e605606162094 : check e605606162094 [[],[],[.under,.under]] .three = true := by decide
def e605606162106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605606162106 : Closed e605606162106 ∧ code e605606162106 = 2804629417658 := by decide
theorem cert_e605606162106 : check e605606162106 [[],[],[.under,.under]] .three = true := by decide
def e605606162154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605606162154 : Closed e605606162154 ∧ code e605606162154 = 2804629417706 := by decide
theorem cert_e605606162154 : check e605606162154 [[],[],[.under,.under]] .three = true := by decide
def e605606162262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605606162262 : Closed e605606162262 ∧ code e605606162262 = 2804629417814 := by decide
theorem cert_e605606162262 : check e605606162262 [[],[],[.under,.under]] .three = true := by decide
def e605606162266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605606162266 : Closed e605606162266 ∧ code e605606162266 = 2804629417818 := by decide
theorem cert_e605606162266 : check e605606162266 [[],[],[.under,.under]] .three = true := by decide
def e605606162282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605606162282 : Closed e605606162282 ∧ code e605606162282 = 2804629417834 := by decide
theorem cert_e605606162282 : check e605606162282 [[],[],[.under,.under]] .three = true := by decide
def e605606162910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e605606162910 : Closed e605606162910 ∧ code e605606162910 = 2804629418462 := by decide
theorem cert_e605606162910 : check e605606162910 [[],[],[.under,.under]] .three = true := by decide
def e605606162934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e605606162934 : Closed e605606162934 ∧ code e605606162934 = 2804629418486 := by decide
theorem cert_e605606162934 : check e605606162934 [[],[],[.under,.under]] .three = true := by decide
def e605606163310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605606163310 : Closed e605606163310 ∧ code e605606163310 = 2804629418862 := by decide
theorem cert_e605606163310 : check e605606163310 [[],[],[.under,.under]] .three = true := by decide
def e605606163318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605606163318 : Closed e605606163318 ∧ code e605606163318 = 2804629418870 := by decide
theorem cert_e605606163318 : check e605606163318 [[],[],[.under,.under]] .three = true := by decide
def e605606163374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605606163374 : Closed e605606163374 ∧ code e605606163374 = 2804629418926 := by decide
theorem cert_e605606163374 : check e605606163374 [[],[],[.under,.under]] .three = true := by decide
def e605606163386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605606163386 : Closed e605606163386 ∧ code e605606163386 = 2804629418938 := by decide
theorem cert_e605606163386 : check e605606163386 [[],[],[.under,.under]] .three = true := by decide
def e605606163414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605606163414 : Closed e605606163414 ∧ code e605606163414 = 2804629418966 := by decide
theorem cert_e605606163414 : check e605606163414 [[],[],[.under,.under]] .three = true := by decide
def e605606163418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605606163418 : Closed e605606163418 ∧ code e605606163418 = 2804629418970 := by decide
theorem cert_e605606163418 : check e605606163418 [[],[],[.under,.under]] .three = true := by decide
def e605606163694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605606163694 : Closed e605606163694 ∧ code e605606163694 = 2804629419246 := by decide
private def t_e605606163694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem cert_e605606163694 : ¬ IsSelfInterpreter e605606163694 :=
  wSource (t := t_e605606163694) (replay_sound (ps := []) (t := e605606163694) (by decide)) (by decide)
def e605606163702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605606163702 : Closed e605606163702 ∧ code e605606163702 = 2804629419254 := by decide
private def t_e605606163702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem cert_e605606163702 : ¬ IsSelfInterpreter e605606163702 :=
  wSource (t := t_e605606163702) (replay_sound (ps := []) (t := e605606163702) (by decide)) (by decide)
def e605606164030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e605606164030 : Closed e605606164030 ∧ code e605606164030 = 2804629419582 := by decide
theorem cert_e605606164030 : check e605606164030 [[],[],[.under,.under]] .three = true := by decide
def e605606164078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605606164078 : Closed e605606164078 ∧ code e605606164078 = 2804629419630 := by decide
theorem cert_e605606164078 : check e605606164078 [[],[],[.under,.under]] .three = true := by decide
def e605606164090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605606164090 : Closed e605606164090 ∧ code e605606164090 = 2804629419642 := by decide
theorem cert_e605606164090 : check e605606164090 [[],[],[.under,.under]] .three = true := by decide
def e605606164278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605606164278 : Closed e605606164278 ∧ code e605606164278 = 2804629419830 := by decide
theorem cert_e605606164278 : check e605606164278 [[],[],[.under,.under]] .three = true := by decide
def e605606164282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605606164282 : Closed e605606164282 ∧ code e605606164282 = 2804629419834 := by decide
theorem cert_e605606164282 : check e605606164282 [[],[],[.under,.under]] .three = true := by decide
def e605606164366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e605606164366 : Closed e605606164366 ∧ code e605606164366 = 2804629419918 := by decide
private def t_e605606164366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem cert_e605606164366 : ¬ IsSelfInterpreter e605606164366 :=
  wSource (t := t_e605606164366) (replay_sound (ps := []) (t := e605606164366) (by decide)) (by decide)
def e605606164702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e605606164702 : Closed e605606164702 ∧ code e605606164702 = 2804629420254 := by decide
theorem cert_e605606164702 : check e605606164702 [[],[],[.under,.under]] .three = true := by decide
def e605606164718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605606164718 : Closed e605606164718 ∧ code e605606164718 = 2804629420270 := by decide
theorem cert_e605606164718 : check e605606164718 [[],[]] .chain = true := by decide
def e605606164726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605606164726 : Closed e605606164726 ∧ code e605606164726 = 2804629420278 := by decide
theorem cert_e605606164726 : check e605606164726 [[],[]] .chain = true := by decide
def e605606164730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e605606164730 : Closed e605606164730 ∧ code e605606164730 = 2804629420282 := by decide
theorem cert_e605606164730 : check e605606164730 [[],[],[.under,.under]] .three = true := by decide
def e605606164910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605606164910 : Closed e605606164910 ∧ code e605606164910 = 2804629420462 := by decide
theorem cert_e605606164910 : check e605606164910 [[],[],[.under,.under]] .three = true := by decide
def e605606164922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605606164922 : Closed e605606164922 ∧ code e605606164922 = 2804629420474 := by decide
theorem cert_e605606164922 : check e605606164922 [[],[],[.under,.under]] .three = true := by decide
def e605606164970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605606164970 : Closed e605606164970 ∧ code e605606164970 = 2804629420522 := by decide
theorem cert_e605606164970 : check e605606164970 [[],[],[.under,.under]] .three = true := by decide
def e605606165054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e605606165054 : Closed e605606165054 ∧ code e605606165054 = 2804629420606 := by decide
theorem cert_e605606165054 : check e605606165054 [[],[],[.under,.under]] .three = true := by decide
def e605606165102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605606165102 : Closed e605606165102 ∧ code e605606165102 = 2804629420654 := by decide
theorem cert_e605606165102 : check e605606165102 [[],[],[.under,.under]] .three = true := by decide
def e605606165114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605606165114 : Closed e605606165114 ∧ code e605606165114 = 2804629420666 := by decide
theorem cert_e605606165114 : check e605606165114 [[],[],[.under,.under]] .three = true := by decide
def e605606165278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605606165278 : Closed e605606165278 ∧ code e605606165278 = 2804629420830 := by decide
theorem cert_e605606165278 : check e605606165278 [[],[]] .chain = true := by decide
def e605606165390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605606165390 : Closed e605606165390 ∧ code e605606165390 = 2804629420942 := by decide
theorem cert_e605606165390 : check e605606165390 [[],[]] .chain = true := by decide
def e605606165402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605606165402 : Closed e605606165402 ∧ code e605606165402 = 2804629420954 := by decide
theorem cert_e605606165402 : check e605606165402 [[],[],[.under,.under]] .three = true := by decide
def e605606165446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e605606165446 : Closed e605606165446 ∧ code e605606165446 = 2804629420998 := by decide
theorem cert_e605606165446 : check e605606165446 [[],[],[.under,.under]] .three = true := by decide
def e605606165622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e605606165622 : Closed e605606165622 ∧ code e605606165622 = 2804629421174 := by decide
theorem cert_e605606165622 : check e605606165622 [[],[]] .chain = true := by decide
def e605606165718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605606165718 : Closed e605606165718 ∧ code e605606165718 = 2804629421270 := by decide
theorem cert_e605606165718 : check e605606165718 [[],[],[.under,.under]] .three = true := by decide
def e605606165722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605606165722 : Closed e605606165722 ∧ code e605606165722 = 2804629421274 := by decide
theorem cert_e605606165722 : check e605606165722 [[],[],[.under,.under]] .three = true := by decide
def e605606165738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605606165738 : Closed e605606165738 ∧ code e605606165738 = 2804629421290 := by decide
theorem cert_e605606165738 : check e605606165738 [[],[],[.under,.under]] .three = true := by decide
def e605606165814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605606165814 : Closed e605606165814 ∧ code e605606165814 = 2804629421366 := by decide
theorem cert_e605606165814 : check e605606165814 [[],[],[.under,.under]] .three = true := by decide
def e605606165818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605606165818 : Closed e605606165818 ∧ code e605606165818 = 2804629421370 := by decide
theorem cert_e605606165818 : check e605606165818 [[],[],[.under,.under]] .three = true := by decide
def e605606165902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e605606165902 : Closed e605606165902 ∧ code e605606165902 = 2804629421454 := by decide
theorem cert_e605606165902 : check e605606165902 [[],[]] .chain = true := by decide
def e605606165914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605606165914 : Closed e605606165914 ∧ code e605606165914 = 2804629421466 := by decide
theorem cert_e605606165914 : check e605606165914 [[],[],[.under,.under]] .three = true := by decide
def e605606166070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605606166070 : Closed e605606166070 ∧ code e605606166070 = 2804629421622 := by decide
theorem cert_e605606166070 : check e605606166070 [[],[],[.under,.under]] .three = true := by decide
def e605606166074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605606166074 : Closed e605606166074 ∧ code e605606166074 = 2804629421626 := by decide
theorem cert_e605606166074 : check e605606166074 [[],[],[.under,.under]] .three = true := by decide
def e605606166158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605606166158 : Closed e605606166158 ∧ code e605606166158 = 2804629421710 := by decide
private def t_e605606166158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem cert_e605606166158 : ¬ IsSelfInterpreter e605606166158 :=
  wSource (t := t_e605606166158) (replay_sound (ps := []) (t := e605606166158) (by decide)) (by decide)
def e605606166214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605606166214 : Closed e605606166214 ∧ code e605606166214 = 2804629421766 := by decide
theorem cert_e605606166214 : check e605606166214 [[],[],[.under,.under]] .three = true := by decide
def e605606169454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605606169454 : Closed e605606169454 ∧ code e605606169454 = 2804629425006 := by decide
theorem cert_e605606169454 : check e605606169454 [[],[],[.under,.under]] .three = true := by decide
def e605606169462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605606169462 : Closed e605606169462 ∧ code e605606169462 = 2804629425014 := by decide
theorem cert_e605606169462 : check e605606169462 [[],[],[.under,.under]] .three = true := by decide
def e605606169518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605606169518 : Closed e605606169518 ∧ code e605606169518 = 2804629425070 := by decide
theorem cert_e605606169518 : check e605606169518 [[],[],[.under,.under]] .three = true := by decide
def e605606169530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605606169530 : Closed e605606169530 ∧ code e605606169530 = 2804629425082 := by decide
theorem cert_e605606169530 : check e605606169530 [[],[],[.under,.under]] .three = true := by decide
def e605606169558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605606169558 : Closed e605606169558 ∧ code e605606169558 = 2804629425110 := by decide
theorem cert_e605606169558 : check e605606169558 [[],[],[.under,.under]] .three = true := by decide
def e605606169562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605606169562 : Closed e605606169562 ∧ code e605606169562 = 2804629425114 := by decide
theorem cert_e605606169562 : check e605606169562 [[],[],[.under,.under]] .three = true := by decide
def e605606169838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605606169838 : Closed e605606169838 ∧ code e605606169838 = 2804629425390 := by decide
theorem cert_e605606169838 : check e605606169838 [[],[],[.under,.under]] .three = true := by decide
def e605606169846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605606169846 : Closed e605606169846 ∧ code e605606169846 = 2804629425398 := by decide
theorem cert_e605606169846 : check e605606169846 [[],[],[.under,.under]] .three = true := by decide
def e605606170174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e605606170174 : Closed e605606170174 ∧ code e605606170174 = 2804629425726 := by decide
theorem cert_e605606170174 : check e605606170174 [[],[],[.under,.under]] .three = true := by decide
def e605606170222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605606170222 : Closed e605606170222 ∧ code e605606170222 = 2804629425774 := by decide
theorem cert_e605606170222 : check e605606170222 [[],[],[.under,.under]] .three = true := by decide
def e605606170234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605606170234 : Closed e605606170234 ∧ code e605606170234 = 2804629425786 := by decide
theorem cert_e605606170234 : check e605606170234 [[],[],[.under,.under]] .three = true := by decide
def e605606170422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605606170422 : Closed e605606170422 ∧ code e605606170422 = 2804629425974 := by decide
theorem cert_e605606170422 : check e605606170422 [[],[],[.under,.under]] .three = true := by decide
def e605606170426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605606170426 : Closed e605606170426 ∧ code e605606170426 = 2804629425978 := by decide
theorem cert_e605606170426 : check e605606170426 [[],[],[.under,.under]] .three = true := by decide
def e605606170510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e605606170510 : Closed e605606170510 ∧ code e605606170510 = 2804629426062 := by decide
theorem cert_e605606170510 : check e605606170510 [[],[],[.under,.under]] .three = true := by decide
def e605606176174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605606176174 : Closed e605606176174 ∧ code e605606176174 = 2804629431726 := by decide
theorem cert_e605606176174 : check e605606176174 [[],[],[.under,.under]] .three = true := by decide
def e605606176186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605606176186 : Closed e605606176186 ∧ code e605606176186 = 2804629431738 := by decide
theorem cert_e605606176186 : check e605606176186 [[],[],[.under,.under]] .three = true := by decide
def e605606176234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605606176234 : Closed e605606176234 ∧ code e605606176234 = 2804629431786 := by decide
theorem cert_e605606176234 : check e605606176234 [[],[],[.under,.under]] .three = true := by decide
def e605606176318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e605606176318 : Closed e605606176318 ∧ code e605606176318 = 2804629431870 := by decide
theorem cert_e605606176318 : check e605606176318 [[],[],[.under,.under]] .three = true := by decide
def e605606176366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605606176366 : Closed e605606176366 ∧ code e605606176366 = 2804629431918 := by decide
theorem cert_e605606176366 : check e605606176366 [[],[],[.under,.under]] .three = true := by decide
def e605606176378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605606176378 : Closed e605606176378 ∧ code e605606176378 = 2804629431930 := by decide
theorem cert_e605606176378 : check e605606176378 [[],[],[.under,.under]] .three = true := by decide
def e605606176542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605606176542 : Closed e605606176542 ∧ code e605606176542 = 2804629432094 := by decide
theorem cert_e605606176542 : check e605606176542 [[],[]] .chain = true := by decide
def e605606176654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605606176654 : Closed e605606176654 ∧ code e605606176654 = 2804629432206 := by decide
theorem cert_e605606176654 : check e605606176654 [[],[]] .chain = true := by decide
def e605606176666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605606176666 : Closed e605606176666 ∧ code e605606176666 = 2804629432218 := by decide
theorem cert_e605606176666 : check e605606176666 [[],[],[.under,.under]] .three = true := by decide
def e605606176710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e605606176710 : Closed e605606176710 ∧ code e605606176710 = 2804629432262 := by decide
theorem cert_e605606176710 : check e605606176710 [[],[],[.under,.under]] .three = true := by decide
def e605606179542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605606179542 : Closed e605606179542 ∧ code e605606179542 = 2804629435094 := by decide
theorem cert_e605606179542 : check e605606179542 [[],[],[.under,.under]] .three = true := by decide
def e605606179546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605606179546 : Closed e605606179546 ∧ code e605606179546 = 2804629435098 := by decide
theorem cert_e605606179546 : check e605606179546 [[],[],[.under,.under]] .three = true := by decide
def e605606179562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605606179562 : Closed e605606179562 ∧ code e605606179562 = 2804629435114 := by decide
theorem cert_e605606179562 : check e605606179562 [[],[],[.under,.under]] .three = true := by decide
def e605606179638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605606179638 : Closed e605606179638 ∧ code e605606179638 = 2804629435190 := by decide
theorem cert_e605606179638 : check e605606179638 [[],[],[.under,.under]] .three = true := by decide
def e605606179642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605606179642 : Closed e605606179642 ∧ code e605606179642 = 2804629435194 := by decide
theorem cert_e605606179642 : check e605606179642 [[],[],[.under,.under]] .three = true := by decide
def e605606179726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e605606179726 : Closed e605606179726 ∧ code e605606179726 = 2804629435278 := by decide
theorem cert_e605606179726 : check e605606179726 [[],[]] .chain = true := by decide
def e605606179738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605606179738 : Closed e605606179738 ∧ code e605606179738 = 2804629435290 := by decide
theorem cert_e605606179738 : check e605606179738 [[],[],[.under,.under]] .three = true := by decide
def e605606181262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605606181262 : Closed e605606181262 ∧ code e605606181262 = 2804629436814 := by decide
theorem cert_e605606181262 : check e605606181262 [[],[],[.under,.under]] .three = true := by decide
def e605606181318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605606181318 : Closed e605606181318 ∧ code e605606181318 = 2804629436870 := by decide
theorem cert_e605606181318 : check e605606181318 [[],[],[.under,.under]] .three = true := by decide
def e605606292822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605606292822 : Closed e605606292822 ∧ code e605606292822 = 2804629548374 := by decide
theorem cert_e605606292822 : check e605606292822 [[],[]] .chain = true := by decide
def e605606292826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605606292826 : Closed e605606292826 ∧ code e605606292826 = 2804629548378 := by decide
theorem cert_e605606292826 : check e605606292826 [[],[]] .chain = true := by decide
def e605606292842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605606292842 : Closed e605606292842 ∧ code e605606292842 = 2804629548394 := by decide
theorem cert_e605606292842 : check e605606292842 [[],[]] .chain = true := by decide
def e605606292906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605606292906 : Closed e605606292906 ∧ code e605606292906 = 2804629548458 := by decide
theorem cert_e605606292906 : check e605606292906 [[],[]] .chain = true := by decide
def e605606293162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605606293162 : Closed e605606293162 ∧ code e605606293162 = 2804629548714 := by decide
theorem cert_e605606293162 : check e605606293162 [[],[]] .chain = true := by decide
def e605606293590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e605606293590 : Closed e605606293590 ∧ code e605606293590 = 2804629549142 := by decide
theorem cert_e605606293590 : check e605606293590 [[],[]] .chain = true := by decide
def e605606293594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e605606293594 : Closed e605606293594 ∧ code e605606293594 = 2804629549146 := by decide
theorem cert_e605606293594 : check e605606293594 [[],[]] .chain = true := by decide
def e605606293870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e605606293870 : Closed e605606293870 ∧ code e605606293870 = 2804629549422 := by decide
theorem cert_e605606293870 : check e605606293870 [[],[],[.under,.under]] .three = true := by decide
def e605606293878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e605606293878 : Closed e605606293878 ∧ code e605606293878 = 2804629549430 := by decide
theorem cert_e605606293878 : check e605606293878 [[],[],[.under,.under]] .three = true := by decide
def e605606293942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e605606293942 : Closed e605606293942 ∧ code e605606293942 = 2804629549494 := by decide
theorem cert_e605606293942 : check e605606293942 [[],[]] .chain = true := by decide
def e605606293974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e605606293974 : Closed e605606293974 ∧ code e605606293974 = 2804629549526 := by decide
theorem cert_e605606293974 : check e605606293974 [[],[]] .chain = true := by decide
def e605606293978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e605606293978 : Closed e605606293978 ∧ code e605606293978 = 2804629549530 := by decide
theorem cert_e605606293978 : check e605606293978 [[],[]] .chain = true := by decide
def e605606294358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e605606294358 : Closed e605606294358 ∧ code e605606294358 = 2804629549910 := by decide
theorem cert_e605606294358 : check e605606294358 [[],[]] .chain = true := by decide
def e605606294362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e605606294362 : Closed e605606294362 ∧ code e605606294362 = 2804629549914 := by decide
theorem cert_e605606294362 : check e605606294362 [[],[]] .chain = true := by decide
def e605606294378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e605606294378 : Closed e605606294378 ∧ code e605606294378 = 2804629549930 := by decide
theorem cert_e605606294378 : check e605606294378 [[],[]] .chain = true := by decide
def e605606294442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605606294442 : Closed e605606294442 ∧ code e605606294442 = 2804629549994 := by decide
theorem cert_e605606294442 : check e605606294442 [[],[]] .chain = true := by decide
def e605606294550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605606294550 : Closed e605606294550 ∧ code e605606294550 = 2804629550102 := by decide
theorem cert_e605606294550 : check e605606294550 [[],[]] .chain = true := by decide
def e605606294646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e605606294646 : Closed e605606294646 ∧ code e605606294646 = 2804629550198 := by decide
theorem cert_e605606294646 : check e605606294646 [[],[]] .chain = true := by decide
def e605606294742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605606294742 : Closed e605606294742 ∧ code e605606294742 = 2804629550294 := by decide
theorem cert_e605606294742 : check e605606294742 [[],[]] .chain = true := by decide
def e605606294746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605606294746 : Closed e605606294746 ∧ code e605606294746 = 2804629550298 := by decide
theorem cert_e605606294746 : check e605606294746 [[],[]] .chain = true := by decide
def e605606294762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605606294762 : Closed e605606294762 ∧ code e605606294762 = 2804629550314 := by decide
theorem cert_e605606294762 : check e605606294762 [[],[]] .chain = true := by decide
def e605606294838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605606294838 : Closed e605606294838 ∧ code e605606294838 = 2804629550390 := by decide
theorem cert_e605606294838 : check e605606294838 [[],[]] .chain = true := by decide
def e605606294842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605606294842 : Closed e605606294842 ∧ code e605606294842 = 2804629550394 := by decide
theorem cert_e605606294842 : check e605606294842 [[],[]] .chain = true := by decide
def e605606294914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e605606294914 : Closed e605606294914 ∧ code e605606294914 = 2804629550466 := by decide
theorem cert_e605606294914 : check e605606294914 [[],[]] .chain = true := by decide
def e605606294926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e605606294926 : Closed e605606294926 ∧ code e605606294926 = 2804629550478 := by decide
theorem cert_e605606294926 : check e605606294926 [[],[]] .chain = true := by decide
def e605606294938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605606294938 : Closed e605606294938 ∧ code e605606294938 = 2804629550490 := by decide
theorem cert_e605606294938 : check e605606294938 [[],[]] .chain = true := by decide
def e605606295050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605606295050 : Closed e605606295050 ∧ code e605606295050 = 2804629550602 := by decide
theorem cert_e605606295050 : check e605606295050 [[],[]] .chain = true := by decide
def e605606295086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605606295086 : Closed e605606295086 ∧ code e605606295086 = 2804629550638 := by decide
theorem cert_e605606295086 : check e605606295086 [[],[],[.under,.under]] .three = true := by decide
def e605606295094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605606295094 : Closed e605606295094 ∧ code e605606295094 = 2804629550646 := by decide
theorem cert_e605606295094 : check e605606295094 [[],[]] .chain = true := by decide
def e605606295098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605606295098 : Closed e605606295098 ∧ code e605606295098 = 2804629550650 := by decide
theorem cert_e605606295098 : check e605606295098 [[],[]] .chain = true := by decide
def e605606295146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605606295146 : Closed e605606295146 ∧ code e605606295146 = 2804629550698 := by decide
theorem cert_e605606295146 : check e605606295146 [[],[]] .chain = true := by decide
def e605606295170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605606295170 : Closed e605606295170 ∧ code e605606295170 = 2804629550722 := by decide
theorem cert_e605606295170 : check e605606295170 [[],[]] .chain = true := by decide
def e605606295182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605606295182 : Closed e605606295182 ∧ code e605606295182 = 2804629550734 := by decide
theorem cert_e605606295182 : check e605606295182 [[],[]] .chain = true := by decide
def e605606295194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605606295194 : Closed e605606295194 ∧ code e605606295194 = 2804629550746 := by decide
theorem cert_e605606295194 : check e605606295194 [[],[]] .chain = true := by decide
def e605606295238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605606295238 : Closed e605606295238 ∧ code e605606295238 = 2804629550790 := by decide
theorem cert_e605606295238 : check e605606295238 [[],[]] .chain = true := by decide
def e605606295266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605606295266 : Closed e605606295266 ∧ code e605606295266 = 2804629550818 := by decide
theorem cert_e605606295266 : check e605606295266 [[],[],[.under,.under]] .three = true := by decide
def e605606295278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e605606295278 : Closed e605606295278 ∧ code e605606295278 = 2804629550830 := by decide
theorem cert_e605606295278 : check e605606295278 [[],[],[.under,.under]] .three = true := by decide
def e605606295318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e605606295318 : Closed e605606295318 ∧ code e605606295318 = 2804629550870 := by decide
theorem cert_e605606295318 : check e605606295318 [[],[],[.under,.under]] .three = true := by decide
def e605606295394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e605606295394 : Closed e605606295394 ∧ code e605606295394 = 2804629550946 := by decide
theorem cert_e605606295394 : check e605606295394 [[],[],[.under,.under]] .three = true := by decide
def e605606295406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e605606295406 : Closed e605606295406 ∧ code e605606295406 = 2804629550958 := by decide
theorem cert_e605606295406 : check e605606295406 [[],[],[.under,.under]] .three = true := by decide
def e605606295414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e605606295414 : Closed e605606295414 ∧ code e605606295414 = 2804629550966 := by decide
theorem cert_e605606295414 : check e605606295414 [[],[],[.under,.under]] .three = true := by decide
def e605606295594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e605606295594 : Closed e605606295594 ∧ code e605606295594 = 2804629551146 := by decide
theorem cert_e605606295594 : check e605606295594 [[],[]] .chain = true := by decide
def e605606295726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605606295726 : Closed e605606295726 ∧ code e605606295726 = 2804629551278 := by decide
theorem cert_e605606295726 : check e605606295726 [[],[],[.under,.under]] .three = true := by decide
def e605606295738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605606295738 : Closed e605606295738 ∧ code e605606295738 = 2804629551290 := by decide
theorem cert_e605606295738 : check e605606295738 [[],[],[.under,.under]] .three = true := by decide
def e605606295766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e605606295766 : Closed e605606295766 ∧ code e605606295766 = 2804629551318 := by decide
theorem cert_e605606295766 : check e605606295766 [[],[]] .chain = true := by decide
def e605606295770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e605606295770 : Closed e605606295770 ∧ code e605606295770 = 2804629551322 := by decide
theorem cert_e605606295770 : check e605606295770 [[],[]] .chain = true := by decide
def e605606295786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605606295786 : Closed e605606295786 ∧ code e605606295786 = 2804629551338 := by decide
theorem cert_e605606295786 : check e605606295786 [[],[]] .chain = true := by decide
def e605606295978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605606295978 : Closed e605606295978 ∧ code e605606295978 = 2804629551530 := by decide
theorem cert_e605606295978 : check e605606295978 [[],[]] .chain = true := by decide
def e605606296074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605606296074 : Closed e605606296074 ∧ code e605606296074 = 2804629551626 := by decide
theorem cert_e605606296074 : check e605606296074 [[],[]] .chain = true := by decide
def e605606296110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605606296110 : Closed e605606296110 ∧ code e605606296110 = 2804629551662 := by decide
theorem cert_e605606296110 : check e605606296110 [[],[],[.under,.under]] .three = true := by decide
def e605606296118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605606296118 : Closed e605606296118 ∧ code e605606296118 = 2804629551670 := by decide
theorem cert_e605606296118 : check e605606296118 [[],[]] .chain = true := by decide
def e605606296122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605606296122 : Closed e605606296122 ∧ code e605606296122 = 2804629551674 := by decide
theorem cert_e605606296122 : check e605606296122 [[],[]] .chain = true := by decide
end Blc.Floor41
