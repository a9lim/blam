import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e602907922206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e602907922206 : Closed e602907922206 ∧ code e602907922206 = 2801931177758 := by decide
theorem cert_e602907922206 : check e602907922206 [[],[]] .sourceHead = true := by decide
def e602907922230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e602907922230 : Closed e602907922230 ∧ code e602907922230 = 2801931177782 := by decide
theorem cert_e602907922230 : check e602907922230 [[],[]] .chain = true := by decide
def e602907922234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e602907922234 : Closed e602907922234 ∧ code e602907922234 = 2801931177786 := by decide
theorem cert_e602907922234 : check e602907922234 [[],[]] .chain = true := by decide
def e602907927006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e602907927006 : Closed e602907927006 ∧ code e602907927006 = 2801931182558 := by decide
theorem cert_e602907927006 : check e602907927006 [[],[]] .chain = true := by decide
def e602907927030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e602907927030 : Closed e602907927030 ∧ code e602907927030 = 2801931182582 := by decide
theorem cert_e602907927030 : check e602907927030 [[],[]] .chain = true := by decide
def e602907927982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e602907927982 : Closed e602907927982 ∧ code e602907927982 = 2801931183534 := by decide
theorem cert_e602907927982 : check e602907927982 [[],[]] .chain = true := by decide
def e602907927994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e602907927994 : Closed e602907927994 ∧ code e602907927994 = 2801931183546 := by decide
theorem cert_e602907927994 : check e602907927994 [[],[]] .chain = true := by decide
def e602907928042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e602907928042 : Closed e602907928042 ∧ code e602907928042 = 2801931183594 := by decide
theorem cert_e602907928042 : check e602907928042 [[],[]] .chain = true := by decide
def e602907928174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e602907928174 : Closed e602907928174 ∧ code e602907928174 = 2801931183726 := by decide
theorem cert_e602907928174 : check e602907928174 [[],[]] .chain = true := by decide
def e602907928186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e602907928186 : Closed e602907928186 ∧ code e602907928186 = 2801931183738 := by decide
theorem cert_e602907928186 : check e602907928186 [[],[]] .chain = true := by decide
def e602907928474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e602907928474 : Closed e602907928474 ∧ code e602907928474 = 2801931184026 := by decide
theorem cert_e602907928474 : check e602907928474 [[],[]] .chain = true := by decide
def e602907930862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e602907930862 : Closed e602907930862 ∧ code e602907930862 = 2801931186414 := by decide
theorem cert_e602907930862 : check e602907930862 [[],[]] .chain = true := by decide
def e602907930870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e602907930870 : Closed e602907930870 ∧ code e602907930870 = 2801931186422 := by decide
theorem cert_e602907930870 : check e602907930870 [[],[]] .chain = true := by decide
def e602907931350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e602907931350 : Closed e602907931350 ∧ code e602907931350 = 2801931186902 := by decide
theorem cert_e602907931350 : check e602907931350 [[],[]] .chain = true := by decide
def e602907931354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e602907931354 : Closed e602907931354 ∧ code e602907931354 = 2801931186906 := by decide
theorem cert_e602907931354 : check e602907931354 [[],[]] .chain = true := by decide
def e602907931370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e602907931370 : Closed e602907931370 ∧ code e602907931370 = 2801931186922 := by decide
theorem cert_e602907931370 : check e602907931370 [[],[]] .chain = true := by decide
def e602907931422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e602907931422 : Closed e602907931422 ∧ code e602907931422 = 2801931186974 := by decide
theorem cert_e602907931422 : check e602907931422 [[],[]] .sourceHead = true := by decide
def e602907931446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e602907931446 : Closed e602907931446 ∧ code e602907931446 = 2801931186998 := by decide
theorem cert_e602907931446 : check e602907931446 [[],[]] .chain = true := by decide
def e602907931450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e602907931450 : Closed e602907931450 ∧ code e602907931450 = 2801931187002 := by decide
theorem cert_e602907931450 : check e602907931450 [[],[]] .chain = true := by decide
def e602907931546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e602907931546 : Closed e602907931546 ∧ code e602907931546 = 2801931187098 := by decide
theorem cert_e602907931546 : check e602907931546 [[],[]] .chain = true := by decide
def e602907931590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e602907931590 : Closed e602907931590 ∧ code e602907931590 = 2801931187142 := by decide
theorem cert_e602907931590 : check e602907931590 [[],[]] .sourceHead = true := by decide
def e602908006110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e602908006110 : Closed e602908006110 ∧ code e602908006110 = 2801931261662 := by decide
theorem cert_e602908006110 : check e602908006110 [[],[],[.under,.under]] .smaller = true := by decide
def e602908006134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e602908006134 : Closed e602908006134 ∧ code e602908006134 = 2801931261686 := by decide
theorem cert_e602908006134 : check e602908006134 [[],[],[.under,.under]] .smaller = true := by decide
def e602908006238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e602908006238 : Closed e602908006238 ∧ code e602908006238 = 2801931261790 := by decide
theorem cert_e602908006238 : check e602908006238 [[],[],[.under,.under]] .smaller = true := by decide
def e602908006254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e602908006254 : Closed e602908006254 ∧ code e602908006254 = 2801931261806 := by decide
theorem cert_e602908006254 : check e602908006254 [[],[]] .chain = true := by decide
def e602908006262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e602908006262 : Closed e602908006262 ∧ code e602908006262 = 2801931261814 := by decide
theorem cert_e602908006262 : check e602908006262 [[],[]] .chain = true := by decide
def e602908006266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e602908006266 : Closed e602908006266 ∧ code e602908006266 = 2801931261818 := by decide
theorem cert_e602908006266 : check e602908006266 [[],[],[.under,.under]] .smaller = true := by decide
def e602908006326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e602908006326 : Closed e602908006326 ∧ code e602908006326 = 2801931261878 := by decide
theorem cert_e602908006326 : check e602908006326 [[],[]] .chain = true := by decide
def e602908006358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e602908006358 : Closed e602908006358 ∧ code e602908006358 = 2801931261910 := by decide
theorem cert_e602908006358 : check e602908006358 [[],[],[.under,.under]] .smaller = true := by decide
def e602908006362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e602908006362 : Closed e602908006362 ∧ code e602908006362 = 2801931261914 := by decide
theorem cert_e602908006362 : check e602908006362 [[],[],[.under,.under]] .smaller = true := by decide
def e602908006878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e602908006878 : Closed e602908006878 ∧ code e602908006878 = 2801931262430 := by decide
theorem cert_e602908006878 : check e602908006878 [[],[],[.under,.under]] .smaller = true := by decide
def e602908006902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e602908006902 : Closed e602908006902 ∧ code e602908006902 = 2801931262454 := by decide
theorem cert_e602908006902 : check e602908006902 [[],[],[.under,.under]] .smaller = true := by decide
def e602908007646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e602908007646 : Closed e602908007646 ∧ code e602908007646 = 2801931263198 := by decide
theorem cert_e602908007646 : check e602908007646 [[],[],[.under,.under]] .smaller = true := by decide
def e602908007662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e602908007662 : Closed e602908007662 ∧ code e602908007662 = 2801931263214 := by decide
theorem cert_e602908007662 : check e602908007662 [[],[]] .chain = true := by decide
def e602908007670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e602908007670 : Closed e602908007670 ∧ code e602908007670 = 2801931263222 := by decide
theorem cert_e602908007670 : check e602908007670 [[],[]] .chain = true := by decide
def e602908007674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e602908007674 : Closed e602908007674 ∧ code e602908007674 = 2801931263226 := by decide
theorem cert_e602908007674 : check e602908007674 [[],[],[.under,.under]] .smaller = true := by decide
def e602908008054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e602908008054 : Closed e602908008054 ∧ code e602908008054 = 2801931263606 := by decide
theorem cert_e602908008054 : check e602908008054 [[],[]] .chain = true := by decide
def e602908008246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e602908008246 : Closed e602908008246 ∧ code e602908008246 = 2801931263798 := by decide
theorem cert_e602908008246 : check e602908008246 [[],[],[.under,.under]] .smaller = true := by decide
def e602908008250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e602908008250 : Closed e602908008250 ∧ code e602908008250 = 2801931263802 := by decide
theorem cert_e602908008250 : check e602908008250 [[],[],[.under,.under]] .smaller = true := by decide
def e602908022454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e602908022454 : Closed e602908022454 ∧ code e602908022454 = 2801931278006 := by decide
theorem cert_e602908022454 : check e602908022454 [[],[]] .chain = true := by decide
def e602908022486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e602908022486 : Closed e602908022486 ∧ code e602908022486 = 2801931278038 := by decide
theorem cert_e602908022486 : check e602908022486 [[],[]] .chain = true := by decide
def e602908022490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e602908022490 : Closed e602908022490 ∧ code e602908022490 = 2801931278042 := by decide
theorem cert_e602908022490 : check e602908022490 [[],[]] .chain = true := by decide
def e602908022614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e602908022614 : Closed e602908022614 ∧ code e602908022614 = 2801931278166 := by decide
theorem cert_e602908022614 : check e602908022614 [[],[]] .chain = true := by decide
def e602908022618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e602908022618 : Closed e602908022618 ∧ code e602908022618 = 2801931278170 := by decide
theorem cert_e602908022618 : check e602908022618 [[],[]] .chain = true := by decide
def e602908022634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e602908022634 : Closed e602908022634 ∧ code e602908022634 = 2801931278186 := by decide
theorem cert_e602908022634 : check e602908022634 [[],[]] .chain = true := by decide
def e602908023022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e602908023022 : Closed e602908023022 ∧ code e602908023022 = 2801931278574 := by decide
theorem cert_e602908023022 : check e602908023022 [[],[],[.under,.under]] .smaller = true := by decide
def e602908023030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e602908023030 : Closed e602908023030 ∧ code e602908023030 = 2801931278582 := by decide
theorem cert_e602908023030 : check e602908023030 [[],[],[.under,.under]] .smaller = true := by decide
def e602908023222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e602908023222 : Closed e602908023222 ∧ code e602908023222 = 2801931278774 := by decide
theorem cert_e602908023222 : check e602908023222 [[],[]] .chain = true := by decide
def e602908023254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e602908023254 : Closed e602908023254 ∧ code e602908023254 = 2801931278806 := by decide
theorem cert_e602908023254 : check e602908023254 [[],[]] .chain = true := by decide
def e602908023258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e602908023258 : Closed e602908023258 ∧ code e602908023258 = 2801931278810 := by decide
theorem cert_e602908023258 : check e602908023258 [[],[]] .chain = true := by decide
def e602908023414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e602908023414 : Closed e602908023414 ∧ code e602908023414 = 2801931278966 := by decide
theorem cert_e602908023414 : check e602908023414 [[],[]] .chain = true := by decide
def e602908023582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e602908023582 : Closed e602908023582 ∧ code e602908023582 = 2801931279134 := by decide
theorem cert_e602908023582 : check e602908023582 [[],[],[.under,.under]] .smaller = true := by decide
def e602908023606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e602908023606 : Closed e602908023606 ∧ code e602908023606 = 2801931279158 := by decide
theorem cert_e602908023606 : check e602908023606 [[],[]] .chain = true := by decide
def e602908023610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e602908023610 : Closed e602908023610 ∧ code e602908023610 = 2801931279162 := by decide
theorem cert_e602908023610 : check e602908023610 [[],[]] .chain = true := by decide
def e602908023694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e602908023694 : Closed e602908023694 ∧ code e602908023694 = 2801931279246 := by decide
theorem cert_e602908023694 : check e602908023694 [[],[],[.under,.under]] .smaller = true := by decide
def e602908023918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e602908023918 : Closed e602908023918 ∧ code e602908023918 = 2801931279470 := by decide
theorem cert_e602908023918 : check e602908023918 [[],[],[.under,.under]] .smaller = true := by decide
def e602908023930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e602908023930 : Closed e602908023930 ∧ code e602908023930 = 2801931279482 := by decide
theorem cert_e602908023930 : check e602908023930 [[],[],[.under,.under]] .smaller = true := by decide
def e602908024022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e602908024022 : Closed e602908024022 ∧ code e602908024022 = 2801931279574 := by decide
theorem cert_e602908024022 : check e602908024022 [[],[]] .chain = true := by decide
def e602908024026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e602908024026 : Closed e602908024026 ∧ code e602908024026 = 2801931279578 := by decide
theorem cert_e602908024026 : check e602908024026 [[],[]] .chain = true := by decide
def e602908024042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e602908024042 : Closed e602908024042 ∧ code e602908024042 = 2801931279594 := by decide
theorem cert_e602908024042 : check e602908024042 [[],[]] .chain = true := by decide
def e602908024094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e602908024094 : Closed e602908024094 ∧ code e602908024094 = 2801931279646 := by decide
theorem cert_e602908024094 : check e602908024094 [[],[],[.under,.under]] .smaller = true := by decide
def e602908024118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e602908024118 : Closed e602908024118 ∧ code e602908024118 = 2801931279670 := by decide
theorem cert_e602908024118 : check e602908024118 [[],[]] .chain = true := by decide
def e602908024122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e602908024122 : Closed e602908024122 ∧ code e602908024122 = 2801931279674 := by decide
theorem cert_e602908024122 : check e602908024122 [[],[]] .chain = true := by decide
def e602908024218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e602908024218 : Closed e602908024218 ∧ code e602908024218 = 2801931279770 := by decide
theorem cert_e602908024218 : check e602908024218 [[],[]] .chain = true := by decide
def e602908024262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e602908024262 : Closed e602908024262 ∧ code e602908024262 = 2801931279814 := by decide
theorem cert_e602908024262 : check e602908024262 [[],[],[.under,.under]] .smaller = true := by decide
def e602908024374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e602908024374 : Closed e602908024374 ∧ code e602908024374 = 2801931279926 := by decide
theorem cert_e602908024374 : check e602908024374 [[],[],[.under,.under]] .smaller = true := by decide
def e602908024378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e602908024378 : Closed e602908024378 ∧ code e602908024378 = 2801931279930 := by decide
theorem cert_e602908024378 : check e602908024378 [[],[],[.under,.under]] .smaller = true := by decide
def e602908024462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e602908024462 : Closed e602908024462 ∧ code e602908024462 = 2801931280014 := by decide
theorem cert_e602908024462 : check e602908024462 [[],[],[.under,.under]] .smaller = true := by decide
def e602908024518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e602908024518 : Closed e602908024518 ∧ code e602908024518 = 2801931280070 := by decide
theorem cert_e602908024518 : check e602908024518 [[],[],[.under,.under]] .smaller = true := by decide
def e602908025326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e602908025326 : Closed e602908025326 ∧ code e602908025326 = 2801931280878 := by decide
theorem cert_e602908025326 : check e602908025326 [[],[]] .chain = true := by decide
def e602908026294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e602908026294 : Closed e602908026294 ∧ code e602908026294 = 2801931281846 := by decide
theorem cert_e602908026294 : check e602908026294 [[],[]] .chain = true := by decide
def e602908026326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e602908026326 : Closed e602908026326 ∧ code e602908026326 = 2801931281878 := by decide
theorem cert_e602908026326 : check e602908026326 [[],[]] .chain = true := by decide
def e602908026330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e602908026330 : Closed e602908026330 ∧ code e602908026330 = 2801931281882 := by decide
theorem cert_e602908026330 : check e602908026330 [[],[]] .chain = true := by decide
def e602908026486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e602908026486 : Closed e602908026486 ∧ code e602908026486 = 2801931282038 := by decide
theorem cert_e602908026486 : check e602908026486 [[],[]] .chain = true := by decide
def e602908026654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e602908026654 : Closed e602908026654 ∧ code e602908026654 = 2801931282206 := by decide
theorem cert_e602908026654 : check e602908026654 [[],[],[.under,.under]] .smaller = true := by decide
def e602908026678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e602908026678 : Closed e602908026678 ∧ code e602908026678 = 2801931282230 := by decide
theorem cert_e602908026678 : check e602908026678 [[],[]] .chain = true := by decide
def e602908026682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e602908026682 : Closed e602908026682 ∧ code e602908026682 = 2801931282234 := by decide
theorem cert_e602908026682 : check e602908026682 [[],[]] .chain = true := by decide
def e602908026766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e602908026766 : Closed e602908026766 ∧ code e602908026766 = 2801931282318 := by decide
theorem cert_e602908026766 : check e602908026766 [[],[],[.under,.under]] .smaller = true := by decide
def e602908029166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e602908029166 : Closed e602908029166 ∧ code e602908029166 = 2801931284718 := by decide
theorem cert_e602908029166 : check e602908029166 [[],[]] .chain = true := by decide
def e602908029174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e602908029174 : Closed e602908029174 ∧ code e602908029174 = 2801931284726 := by decide
theorem cert_e602908029174 : check e602908029174 [[],[]] .chain = true := by decide
def e602908029654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e602908029654 : Closed e602908029654 ∧ code e602908029654 = 2801931285206 := by decide
theorem cert_e602908029654 : check e602908029654 [[],[]] .chain = true := by decide
def e602908029658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e602908029658 : Closed e602908029658 ∧ code e602908029658 = 2801931285210 := by decide
theorem cert_e602908029658 : check e602908029658 [[],[]] .chain = true := by decide
def e602908029674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e602908029674 : Closed e602908029674 ∧ code e602908029674 = 2801931285226 := by decide
theorem cert_e602908029674 : check e602908029674 [[],[]] .chain = true := by decide
def e602908029726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e602908029726 : Closed e602908029726 ∧ code e602908029726 = 2801931285278 := by decide
theorem cert_e602908029726 : check e602908029726 [[],[],[.under,.under]] .smaller = true := by decide
def e602908029750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e602908029750 : Closed e602908029750 ∧ code e602908029750 = 2801931285302 := by decide
theorem cert_e602908029750 : check e602908029750 [[],[]] .chain = true := by decide
def e602908029754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e602908029754 : Closed e602908029754 ∧ code e602908029754 = 2801931285306 := by decide
theorem cert_e602908029754 : check e602908029754 [[],[]] .chain = true := by decide
def e602908029850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e602908029850 : Closed e602908029850 ∧ code e602908029850 = 2801931285402 := by decide
theorem cert_e602908029850 : check e602908029850 [[],[]] .chain = true := by decide
def e602908029894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e602908029894 : Closed e602908029894 ∧ code e602908029894 = 2801931285446 := by decide
theorem cert_e602908029894 : check e602908029894 [[],[],[.under,.under]] .smaller = true := by decide
def e602908031374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e602908031374 : Closed e602908031374 ∧ code e602908031374 = 2801931286926 := by decide
theorem cert_e602908031374 : check e602908031374 [[],[],[.under,.under]] .smaller = true := by decide
def e602908031430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e602908031430 : Closed e602908031430 ∧ code e602908031430 = 2801931286982 := by decide
theorem cert_e602908031430 : check e602908031430 [[],[],[.under,.under]] .smaller = true := by decide
def e602911824758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))))
theorem wire_e602911824758 : Closed e602911824758 ∧ code e602911824758 = 2801935080310 := by decide
theorem cert_e602911824758 : check e602911824758 [[],[]] .sourceHead = true := by decide
def e602911824822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))
theorem wire_e602911824822 : Closed e602911824822 ∧ code e602911824822 = 2801935080374 := by decide
theorem cert_e602911824822 : check e602911824822 [[],[]] .sourceHead = true := by decide
def e602911825270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))))
theorem wire_e602911825270 : Closed e602911825270 ∧ code e602911825270 = 2801935080822 := by decide
theorem cert_e602911825270 : check e602911825270 [[],[]] .sourceHead = true := by decide
def e602911825366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))))
theorem wire_e602911825366 : Closed e602911825366 ∧ code e602911825366 = 2801935080918 := by decide
theorem cert_e602911825366 : check e602911825366 [[],[]] .sourceHead = true := by decide
def e602911825590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))
theorem wire_e602911825590 : Closed e602911825590 ∧ code e602911825590 = 2801935081142 := by decide
theorem cert_e602911825590 : check e602911825590 [[],[]] .sourceHead = true := by decide
def e602911825622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))))
theorem wire_e602911825622 : Closed e602911825622 ∧ code e602911825622 = 2801935081174 := by decide
theorem cert_e602911825622 : check e602911825622 [[],[]] .sourceHead = true := by decide
def e602911827830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))))
theorem wire_e602911827830 : Closed e602911827830 ∧ code e602911827830 = 2801935083382 := by decide
theorem cert_e602911827830 : check e602911827830 [[],[]] .sourceHead = true := by decide
def e602911827894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))))
theorem wire_e602911827894 : Closed e602911827894 ∧ code e602911827894 = 2801935083446 := by decide
theorem cert_e602911827894 : check e602911827894 [[],[]] .sourceHead = true := by decide
def e602911830902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))))
theorem wire_e602911830902 : Closed e602911830902 ∧ code e602911830902 = 2801935086454 := by decide
theorem cert_e602911830902 : check e602911830902 [[],[]] .sourceHead = true := by decide
def e602911830998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))))
theorem wire_e602911830998 : Closed e602911830998 ∧ code e602911830998 = 2801935086550 := by decide
theorem cert_e602911830998 : check e602911830998 [[],[]] .sourceHead = true := by decide
def e602911832502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))))
theorem wire_e602911832502 : Closed e602911832502 ∧ code e602911832502 = 2801935088054 := by decide
theorem cert_e602911832502 : check e602911832502 [[],[]] .sourceHead = true := by decide
def e602911832534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))))
theorem wire_e602911832534 : Closed e602911832534 ∧ code e602911832534 = 2801935088086 := by decide
theorem cert_e602911832534 : check e602911832534 [[],[]] .sourceHead = true := by decide
def e602912000878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e602912000878 : Closed e602912000878 ∧ code e602912000878 = 2801935256430 := by decide
theorem cert_e602912000878 : check e602912000878 [[],[]] .sourceHead = true := by decide
def e602912000886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e602912000886 : Closed e602912000886 ∧ code e602912000886 = 2801935256438 := by decide
theorem cert_e602912000886 : check e602912000886 [[],[]] .sourceHead = true := by decide
def e602912000942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e602912000942 : Closed e602912000942 ∧ code e602912000942 = 2801935256494 := by decide
theorem cert_e602912000942 : check e602912000942 [[],[]] .sourceHead = true := by decide
def e602912000954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e602912000954 : Closed e602912000954 ∧ code e602912000954 = 2801935256506 := by decide
theorem cert_e602912000954 : check e602912000954 [[],[]] .sourceHead = true := by decide
def e602912000982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e602912000982 : Closed e602912000982 ∧ code e602912000982 = 2801935256534 := by decide
theorem cert_e602912000982 : check e602912000982 [[],[]] .sourceHead = true := by decide
def e602912000986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e602912000986 : Closed e602912000986 ∧ code e602912000986 = 2801935256538 := by decide
theorem cert_e602912000986 : check e602912000986 [[],[]] .sourceHead = true := by decide
def e602912001262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e602912001262 : Closed e602912001262 ∧ code e602912001262 = 2801935256814 := by decide
theorem cert_e602912001262 : check e602912001262 [[],[]] .sourceHead = true := by decide
def e602912001270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e602912001270 : Closed e602912001270 ∧ code e602912001270 = 2801935256822 := by decide
theorem cert_e602912001270 : check e602912001270 [[],[]] .sourceHead = true := by decide
def e602912001646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e602912001646 : Closed e602912001646 ∧ code e602912001646 = 2801935257198 := by decide
theorem cert_e602912001646 : check e602912001646 [[],[]] .sourceHead = true := by decide
def e602912001658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e602912001658 : Closed e602912001658 ∧ code e602912001658 = 2801935257210 := by decide
theorem cert_e602912001658 : check e602912001658 [[],[]] .sourceHead = true := by decide
def e602912001846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e602912001846 : Closed e602912001846 ∧ code e602912001846 = 2801935257398 := by decide
theorem cert_e602912001846 : check e602912001846 [[],[]] .sourceHead = true := by decide
def e602912001850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e602912001850 : Closed e602912001850 ∧ code e602912001850 = 2801935257402 := by decide
theorem cert_e602912001850 : check e602912001850 [[],[]] .sourceHead = true := by decide
def e602912075194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e602912075194 : Closed e602912075194 ∧ code e602912075194 = 2801935330746 := by decide
theorem cert_e602912075194 : check e602912075194 [[],[],[.under,.left]] .smaller = true := by decide
def e602912075226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e602912075226 : Closed e602912075226 ∧ code e602912075226 = 2801935330778 := by decide
theorem cert_e602912075226 : check e602912075226 [[],[],[.under,.left]] .smaller = true := by decide
def e602912075450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e602912075450 : Closed e602912075450 ∧ code e602912075450 = 2801935331002 := by decide
theorem cert_e602912075450 : check e602912075450 [[],[],[.under,.left]] .smaller = true := by decide
def e602912075498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e602912075498 : Closed e602912075498 ∧ code e602912075498 = 2801935331050 := by decide
theorem cert_e602912075498 : check e602912075498 [[],[],[.under,.left]] .smaller = true := by decide
def e602912075610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e602912075610 : Closed e602912075610 ∧ code e602912075610 = 2801935331162 := by decide
theorem cert_e602912075610 : check e602912075610 [[],[],[.under,.left]] .smaller = true := by decide
def e602912075626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e602912075626 : Closed e602912075626 ∧ code e602912075626 = 2801935331178 := by decide
theorem cert_e602912075626 : check e602912075626 [[],[],[.under,.left]] .smaller = true := by decide
def e602912076730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e602912076730 : Closed e602912076730 ∧ code e602912076730 = 2801935332282 := by decide
theorem cert_e602912076730 : check e602912076730 [[],[],[.under,.left]] .smaller = true := by decide
def e602912076762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e602912076762 : Closed e602912076762 ∧ code e602912076762 = 2801935332314 := by decide
theorem cert_e602912076762 : check e602912076762 [[],[],[.under,.left]] .smaller = true := by decide
def e602912078266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e602912078266 : Closed e602912078266 ∧ code e602912078266 = 2801935333818 := by decide
theorem cert_e602912078266 : check e602912078266 [[],[],[.under,.left]] .smaller = true := by decide
def e602912078314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e602912078314 : Closed e602912078314 ∧ code e602912078314 = 2801935333866 := by decide
theorem cert_e602912078314 : check e602912078314 [[],[],[.under,.left]] .smaller = true := by decide
def e602912079066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e602912079066 : Closed e602912079066 ∧ code e602912079066 = 2801935334618 := by decide
theorem cert_e602912079066 : check e602912079066 [[],[],[.under,.left]] .smaller = true := by decide
def e602912079082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e602912079082 : Closed e602912079082 ∧ code e602912079082 = 2801935334634 := by decide
theorem cert_e602912079082 : check e602912079082 [[],[],[.under,.left]] .smaller = true := by decide
def e602912131950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e602912131950 : Closed e602912131950 ∧ code e602912131950 = 2801935387502 := by decide
theorem cert_e602912131950 : check e602912131950 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e602912131958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e602912131958 : Closed e602912131958 ∧ code e602912131958 = 2801935387510 := by decide
theorem cert_e602912131958 : check e602912131958 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e602912132014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e602912132014 : Closed e602912132014 ∧ code e602912132014 = 2801935387566 := by decide
theorem cert_e602912132014 : check e602912132014 [[],[],[.under,.left],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e602912132026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e602912132026 : Closed e602912132026 ∧ code e602912132026 = 2801935387578 := by decide
theorem cert_e602912132026 : check e602912132026 [[],[],[.under,.left],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e602912132054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e602912132054 : Closed e602912132054 ∧ code e602912132054 = 2801935387606 := by decide
theorem cert_e602912132054 : checkPay e602912132054 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] 0 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] = true := by decide
def e602912132058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e602912132058 : Closed e602912132058 ∧ code e602912132058 = 2801935387610 := by decide
theorem cert_e602912132058 : check e602912132058 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .identityHead = true := by decide
def e602912132334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e602912132334 : Closed e602912132334 ∧ code e602912132334 = 2801935387886 := by decide
theorem cert_e602912132334 : check e602912132334 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left]] .identityHead = true := by decide
def e602912132342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e602912132342 : Closed e602912132342 ∧ code e602912132342 = 2801935387894 := by decide
theorem cert_e602912132342 : check e602912132342 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left],[],[],[],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e602912132718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e602912132718 : Closed e602912132718 ∧ code e602912132718 = 2801935388270 := by decide
theorem cert_e602912132718 : checkPay e602912132718 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] 0 [[],[.left],[],[.under,.left]] = true := by decide
def e602912132730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e602912132730 : Closed e602912132730 ∧ code e602912132730 = 2801935388282 := by decide
theorem cert_e602912132730 : checkPay e602912132730 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] 0 [[]] = true := by decide
def e602912132918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e602912132918 : Closed e602912132918 ∧ code e602912132918 = 2801935388470 := by decide
theorem cert_e602912132918 : check e602912132918 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602912132922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e602912132922 : Closed e602912132922 ∧ code e602912132922 = 2801935388474 := by decide
theorem cert_e602912132922 : check e602912132922 [[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602912331486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e602912331486 : Closed e602912331486 ∧ code e602912331486 = 2801935587038 := by decide
theorem cert_e602912331486 : check e602912331486 [[],[]] .smaller = true := by decide
def e602912331510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e602912331510 : Closed e602912331510 ∧ code e602912331510 = 2801935587062 := by decide
theorem cert_e602912331510 : check e602912331510 [[],[]] .smaller = true := by decide
def e602912331614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e602912331614 : Closed e602912331614 ∧ code e602912331614 = 2801935587166 := by decide
theorem cert_e602912331614 : check e602912331614 [[],[]] .smaller = true := by decide
def e602912331642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e602912331642 : Closed e602912331642 ∧ code e602912331642 = 2801935587194 := by decide
theorem cert_e602912331642 : check e602912331642 [[],[]] .smaller = true := by decide
def e602912331734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e602912331734 : Closed e602912331734 ∧ code e602912331734 = 2801935587286 := by decide
theorem cert_e602912331734 : check e602912331734 [[],[]] .smaller = true := by decide
def e602912331738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e602912331738 : Closed e602912331738 ∧ code e602912331738 = 2801935587290 := by decide
theorem cert_e602912331738 : check e602912331738 [[],[]] .smaller = true := by decide
def e602912332254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e602912332254 : Closed e602912332254 ∧ code e602912332254 = 2801935587806 := by decide
theorem cert_e602912332254 : check e602912332254 [[],[]] .smaller = true := by decide
def e602912332278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e602912332278 : Closed e602912332278 ∧ code e602912332278 = 2801935587830 := by decide
theorem cert_e602912332278 : check e602912332278 [[],[]] .smaller = true := by decide
def e602912333022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e602912333022 : Closed e602912333022 ∧ code e602912333022 = 2801935588574 := by decide
theorem cert_e602912333022 : check e602912333022 [[],[]] .smaller = true := by decide
def e602912333050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e602912333050 : Closed e602912333050 ∧ code e602912333050 = 2801935588602 := by decide
theorem cert_e602912333050 : check e602912333050 [[],[]] .smaller = true := by decide
def e602912333622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e602912333622 : Closed e602912333622 ∧ code e602912333622 = 2801935589174 := by decide
theorem cert_e602912333622 : check e602912333622 [[],[]] .smaller = true := by decide
def e602912333626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e602912333626 : Closed e602912333626 ∧ code e602912333626 = 2801935589178 := by decide
theorem cert_e602912333626 : check e602912333626 [[],[]] .smaller = true := by decide
def e602912348398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e602912348398 : Closed e602912348398 ∧ code e602912348398 = 2801935603950 := by decide
theorem cert_e602912348398 : check e602912348398 [[],[]] .smaller = true := by decide
def e602912348406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e602912348406 : Closed e602912348406 ∧ code e602912348406 = 2801935603958 := by decide
theorem cert_e602912348406 : check e602912348406 [[],[]] .smaller = true := by decide
def e602912348958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e602912348958 : Closed e602912348958 ∧ code e602912348958 = 2801935604510 := by decide
theorem cert_e602912348958 : check e602912348958 [[],[]] .smaller = true := by decide
def e602912349070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e602912349070 : Closed e602912349070 ∧ code e602912349070 = 2801935604622 := by decide
theorem cert_e602912349070 : check e602912349070 [[],[]] .smaller = true := by decide
def e602912349294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e602912349294 : Closed e602912349294 ∧ code e602912349294 = 2801935604846 := by decide
theorem cert_e602912349294 : check e602912349294 [[],[]] .smaller = true := by decide
def e602912349306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e602912349306 : Closed e602912349306 ∧ code e602912349306 = 2801935604858 := by decide
theorem cert_e602912349306 : check e602912349306 [[],[]] .smaller = true := by decide
def e602912349470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e602912349470 : Closed e602912349470 ∧ code e602912349470 = 2801935605022 := by decide
theorem cert_e602912349470 : check e602912349470 [[],[]] .smaller = true := by decide
def e602912349638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e602912349638 : Closed e602912349638 ∧ code e602912349638 = 2801935605190 := by decide
theorem cert_e602912349638 : check e602912349638 [[],[]] .smaller = true := by decide
def e602912349662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e602912349662 : Closed e602912349662 ∧ code e602912349662 = 2801935605214 := by decide
theorem cert_e602912349662 : check e602912349662 [[],[]] .chain = true := by decide
def e602912349678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e602912349678 : Closed e602912349678 ∧ code e602912349678 = 2801935605230 := by decide
theorem cert_e602912349678 : check e602912349678 [[],[]] .chain = true := by decide
end Blc.Floor41
