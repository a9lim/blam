import Extra41
import Batch139
import Batch142
import Batch143
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness605778095802
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u3 u0
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605778095802 : ¬ IsSelfInterpreter e605778095802 := by
  intro he
  have h : replay [] e605778095802 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605778095802
end Witness605778095802
namespace Witness605778097082
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.app u0 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u14 := Term.app u0 u3
private theorem sou3 : SO u3 := SO.var 1
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.app sou3 sou4
private theorem sou6 : SO u6 := SO.app sou0 sou5
private theorem sou14 : SO u14 := SO.app sou0 sou3
private theorem sou7 : SO u7 := SO.lam (r := u14) (g := u14) sou6 sou14 (by decide) (by decide)
private theorem sou8 : SO u8 := SO.lam (r := u0) (g := u7) sou7 sou0 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := SO.app sou10 sou0
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605778097082 : ¬ IsSelfInterpreter e605778097082 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605778097082
end Witness605778097082
namespace Witness605778097114
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u3 u4
private def u6 := Term.app u0 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u14 := Term.app u4 u0
private def u15 := Term.app u0 u4
private theorem sou3 : SO u3 := SO.var 2
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.app sou3 sou4
private theorem sou6 : SO u6 := SO.app sou0 sou5
private theorem sou14 : SO u14 := SO.app sou4 sou0
private theorem sou7 : SO u7 := SO.lam (r := u14) (g := u15) sou6 sou14 (by decide) (by decide)
private theorem sou8 : SO u8 := SO.lam (r := u0) (g := u7) sou7 sou0 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := SO.app sou10 sou0
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605778097114 : ¬ IsSelfInterpreter e605778097114 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605778097114
end Witness605778097114
namespace Witness605778099418
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u0 u4
private def u6 := Term.app u3 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605778099418 : ¬ IsSelfInterpreter e605778099418 := by
  intro he
  have h : replay [] e605778099418 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605778099418
end Witness605778099418
namespace Witness605778099434
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u4 u0
private def u6 := Term.app u3 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605778099434 : ¬ IsSelfInterpreter e605778099434 := by
  intro he
  have h : replay [] e605778099434 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605778099434
end Witness605778099434
namespace Witness605792428986
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.lam u4
private def u6 := Term.app u3 u5
private def u7 := Term.app u6 u4
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u14 := Term.lam u3
private def u15 := Term.app u0 u14
private def u16 := Term.app u15 u3
private def u17 := Term.app u3 u0
private theorem sou3 : SO u3 := SO.var 1
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := so_dead (by decide) sou4
private theorem sou6 : SO u6 := SO.app sou3 sou5
private theorem sou7 : SO u7 := SO.app sou6 sou4
private theorem sou8 : SO u8 := SO.app sou7 sou0
private theorem sou14 : SO u14 := so_dead (by decide) sou3
private theorem sou15 : SO u15 := SO.app sou0 sou14
private theorem sou16 : SO u16 := SO.app sou15 sou3
private theorem sou9 : SO u9 := SO.lam (r := u16) (g := u17) sou8 sou16 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605792428986 : ¬ IsSelfInterpreter e605792428986 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605792428986
end Witness605792428986
namespace Witness605792429018
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 3
private def u5 := Term.lam u4
private def u6 := Term.app u3 u5
private def u7 := Term.app u6 u3
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u14 := Term.lam u3
private def u15 := Term.var 2
private def u16 := Term.app u3 u15
private def u17 := Term.app u16 u3
private def u18 := Term.app u17 u0
private def u19 := Term.lam u18
private def u20 := Term.lam u15
private def u21 := Term.app u0 u20
private def u22 := Term.app u21 u0
private def u23 := Term.app u3 u0
private theorem sou3 : SO u3 := SO.var 1
private theorem sou4 : SO u4 := SO.var 3
private theorem sou5 : SO u5 := so_dead (by decide) sou4
private theorem sou6 : SO u6 := SO.app sou3 sou5
private theorem sou7 : SO u7 := SO.app sou6 sou3
private theorem sou8 : SO u8 := SO.app sou7 sou0
private theorem sou15 : SO u15 := SO.var 2
private theorem sou20 : SO u20 := so_dead (by decide) sou15
private theorem sou21 : SO u21 := SO.app sou0 sou20
private theorem sou22 : SO u22 := SO.app sou21 sou0
private theorem sou9 : SO u9 := SO.lam (r := u22) (g := u23) sou8 sou22 (by decide) (by decide)
private theorem sou14 : SO u14 := so_dead (by decide) sou3
private theorem sou10 : SO u10 := SO.lam (r := u14) (g := u19) sou9 sou14 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605792429018 : ¬ IsSelfInterpreter e605792429018 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605792429018
end Witness605792429018
namespace Witness605792432602
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.lam u3
private def u5 := Term.app u3 u4
private def u6 := Term.var 1
private def u7 := Term.app u5 u6
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u14 := Term.lam u6
private def u15 := Term.app u6 u14
private def u16 := Term.app u15 u0
private def u17 := Term.app u6 u0
private theorem sou3 : SO u3 := SO.var 2
private theorem sou4 : SO u4 := so_dead (by decide) sou3
private theorem sou5 : SO u5 := SO.app sou3 sou4
private theorem sou6 : SO u6 := SO.var 1
private theorem sou7 : SO u7 := SO.app sou5 sou6
private theorem sou8 : SO u8 := SO.app sou7 sou0
private theorem sou14 : SO u14 := so_dead (by decide) sou6
private theorem sou15 : SO u15 := SO.app sou6 sou14
private theorem sou16 : SO u16 := SO.app sou15 sou0
private theorem sou9 : SO u9 := SO.lam (r := u16) (g := u17) sou8 sou16 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605792432602 : ¬ IsSelfInterpreter e605792432602 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605792432602
end Witness605792432602
end Blc.Floor41
