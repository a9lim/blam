import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e602912349750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e602912349750 : Closed e602912349750 ∧ code e602912349750 = 2801935605302 := by decide
theorem cert_e602912349750 : check e602912349750 [[],[]] .smaller = true := by decide
def e602912349754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e602912349754 : Closed e602912349754 ∧ code e602912349754 = 2801935605306 := by decide
theorem cert_e602912349754 : check e602912349754 [[],[]] .smaller = true := by decide
def e602912349838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e602912349838 : Closed e602912349838 ∧ code e602912349838 = 2801935605390 := by decide
theorem cert_e602912349838 : check e602912349838 [[],[]] .smaller = true := by decide
def e602912349894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e602912349894 : Closed e602912349894 ∧ code e602912349894 = 2801935605446 := by decide
theorem cert_e602912349894 : check e602912349894 [[],[]] .smaller = true := by decide
def e602912349918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e602912349918 : Closed e602912349918 ∧ code e602912349918 = 2801935605470 := by decide
theorem cert_e602912349918 : check e602912349918 [[],[]] .chain = true := by decide
def e602912349942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e602912349942 : Closed e602912349942 ∧ code e602912349942 = 2801935605494 := by decide
theorem cert_e602912349942 : check e602912349942 [[],[]] .chain = true := by decide
def e602912350062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e602912350062 : Closed e602912350062 ∧ code e602912350062 = 2801935605614 := by decide
theorem cert_e602912350062 : check e602912350062 [[],[]] .chain = true := by decide
def e602912350070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e602912350070 : Closed e602912350070 ∧ code e602912350070 = 2801935605622 := by decide
theorem cert_e602912350070 : check e602912350070 [[],[]] .chain = true := by decide
def e602912352030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e602912352030 : Closed e602912352030 ∧ code e602912352030 = 2801935607582 := by decide
theorem cert_e602912352030 : check e602912352030 [[],[]] .smaller = true := by decide
def e602912352142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e602912352142 : Closed e602912352142 ∧ code e602912352142 = 2801935607694 := by decide
theorem cert_e602912352142 : check e602912352142 [[],[]] .smaller = true := by decide
def e602912355102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e602912355102 : Closed e602912355102 ∧ code e602912355102 = 2801935610654 := by decide
theorem cert_e602912355102 : check e602912355102 [[],[]] .smaller = true := by decide
def e602912355270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e602912355270 : Closed e602912355270 ∧ code e602912355270 = 2801935610822 := by decide
theorem cert_e602912355270 : check e602912355270 [[],[]] .smaller = true := by decide
def e602912355294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e602912355294 : Closed e602912355294 ∧ code e602912355294 = 2801935610846 := by decide
theorem cert_e602912355294 : check e602912355294 [[],[]] .chain = true := by decide
def e602912355310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e602912355310 : Closed e602912355310 ∧ code e602912355310 = 2801935610862 := by decide
theorem cert_e602912355310 : check e602912355310 [[],[]] .chain = true := by decide
def e602912356750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e602912356750 : Closed e602912356750 ∧ code e602912356750 = 2801935612302 := by decide
theorem cert_e602912356750 : check e602912356750 [[],[]] .smaller = true := by decide
def e602912356806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e602912356806 : Closed e602912356806 ∧ code e602912356806 = 2801935612358 := by decide
theorem cert_e602912356806 : check e602912356806 [[],[]] .smaller = true := by decide
def e602912356830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e602912356830 : Closed e602912356830 ∧ code e602912356830 = 2801935612382 := by decide
theorem cert_e602912356830 : check e602912356830 [[],[]] .chain = true := by decide
def e602912356854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e602912356854 : Closed e602912356854 ∧ code e602912356854 = 2801935612406 := by decide
theorem cert_e602912356854 : check e602912356854 [[],[]] .chain = true := by decide
def e602912357614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e602912357614 : Closed e602912357614 ∧ code e602912357614 = 2801935613166 := by decide
theorem cert_e602912357614 : check e602912357614 [[],[]] .chain = true := by decide
def e602912357622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e602912357622 : Closed e602912357622 ∧ code e602912357622 = 2801935613174 := by decide
theorem cert_e602912357622 : check e602912357622 [[],[]] .chain = true := by decide
def e602912414574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e602912414574 : Closed e602912414574 ∧ code e602912414574 = 2801935670126 := by decide
theorem cert_e602912414574 : check e602912414574 [[],[]] .chain = true := by decide
def e602912414582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e602912414582 : Closed e602912414582 ∧ code e602912414582 = 2801935670134 := by decide
theorem cert_e602912414582 : check e602912414582 [[],[]] .chain = true := by decide
def e602912414646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e602912414646 : Closed e602912414646 ∧ code e602912414646 = 2801935670198 := by decide
theorem cert_e602912414646 : check e602912414646 [[],[]] .chain = true := by decide
def e602912415086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e602912415086 : Closed e602912415086 ∧ code e602912415086 = 2801935670638 := by decide
theorem cert_e602912415086 : check e602912415086 [[],[]] .chain = true := by decide
def e602912415094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e602912415094 : Closed e602912415094 ∧ code e602912415094 = 2801935670646 := by decide
theorem cert_e602912415094 : check e602912415094 [[],[]] .chain = true := by decide
def e602912415150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e602912415150 : Closed e602912415150 ∧ code e602912415150 = 2801935670702 := by decide
theorem cert_e602912415150 : check e602912415150 [[],[]] .chain = true := by decide
def e602912415162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e602912415162 : Closed e602912415162 ∧ code e602912415162 = 2801935670714 := by decide
theorem cert_e602912415162 : check e602912415162 [[],[]] .chain = true := by decide
def e602912415190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e602912415190 : Closed e602912415190 ∧ code e602912415190 = 2801935670742 := by decide
theorem cert_e602912415190 : check e602912415190 [[],[]] .chain = true := by decide
def e602912415194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e602912415194 : Closed e602912415194 ∧ code e602912415194 = 2801935670746 := by decide
theorem cert_e602912415194 : check e602912415194 [[],[]] .chain = true := by decide
def e602912415414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e602912415414 : Closed e602912415414 ∧ code e602912415414 = 2801935670966 := by decide
theorem cert_e602912415414 : check e602912415414 [[],[]] .chain = true := by decide
def e602912415446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e602912415446 : Closed e602912415446 ∧ code e602912415446 = 2801935670998 := by decide
theorem cert_e602912415446 : check e602912415446 [[],[]] .chain = true := by decide
def e602912415450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e602912415450 : Closed e602912415450 ∧ code e602912415450 = 2801935671002 := by decide
theorem cert_e602912415450 : check e602912415450 [[],[]] .chain = true := by decide
def e602912417646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e602912417646 : Closed e602912417646 ∧ code e602912417646 = 2801935673198 := by decide
theorem cert_e602912417646 : check e602912417646 [[],[]] .chain = true := by decide
def e602912417654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e602912417654 : Closed e602912417654 ∧ code e602912417654 = 2801935673206 := by decide
theorem cert_e602912417654 : check e602912417654 [[],[]] .chain = true := by decide
def e602912417718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e602912417718 : Closed e602912417718 ∧ code e602912417718 = 2801935673270 := by decide
theorem cert_e602912417718 : check e602912417718 [[],[]] .chain = true := by decide
def e602912419054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e602912419054 : Closed e602912419054 ∧ code e602912419054 = 2801935674606 := by decide
theorem cert_e602912419054 : check e602912419054 [[],[]] .chain = true := by decide
def e602912419062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e602912419062 : Closed e602912419062 ∧ code e602912419062 = 2801935674614 := by decide
theorem cert_e602912419062 : check e602912419062 [[],[]] .chain = true := by decide
def e602912419446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e602912419446 : Closed e602912419446 ∧ code e602912419446 = 2801935674998 := by decide
theorem cert_e602912419446 : check e602912419446 [[],[]] .chain = true := by decide
def e602912420718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e602912420718 : Closed e602912420718 ∧ code e602912420718 = 2801935676270 := by decide
theorem cert_e602912420718 : check e602912420718 [[],[]] .chain = true := by decide
def e602912420726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e602912420726 : Closed e602912420726 ∧ code e602912420726 = 2801935676278 := by decide
theorem cert_e602912420726 : check e602912420726 [[],[]] .chain = true := by decide
def e602912420782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e602912420782 : Closed e602912420782 ∧ code e602912420782 = 2801935676334 := by decide
theorem cert_e602912420782 : check e602912420782 [[],[]] .chain = true := by decide
def e602912420794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e602912420794 : Closed e602912420794 ∧ code e602912420794 = 2801935676346 := by decide
theorem cert_e602912420794 : check e602912420794 [[],[]] .chain = true := by decide
def e602912420822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e602912420822 : Closed e602912420822 ∧ code e602912420822 = 2801935676374 := by decide
theorem cert_e602912420822 : check e602912420822 [[],[]] .chain = true := by decide
def e602912420826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e602912420826 : Closed e602912420826 ∧ code e602912420826 = 2801935676378 := by decide
theorem cert_e602912420826 : check e602912420826 [[],[]] .chain = true := by decide
def e602912421102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e602912421102 : Closed e602912421102 ∧ code e602912421102 = 2801935676654 := by decide
theorem cert_e602912421102 : check e602912421102 [[],[]] .chain = true := by decide
def e602912421110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e602912421110 : Closed e602912421110 ∧ code e602912421110 = 2801935676662 := by decide
theorem cert_e602912421110 : check e602912421110 [[],[]] .chain = true := by decide
def e602912421486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e602912421486 : Closed e602912421486 ∧ code e602912421486 = 2801935677038 := by decide
theorem cert_e602912421486 : check e602912421486 [[],[]] .chain = true := by decide
def e602912421498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e602912421498 : Closed e602912421498 ∧ code e602912421498 = 2801935677050 := by decide
theorem cert_e602912421498 : check e602912421498 [[],[]] .chain = true := by decide
def e602912421686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e602912421686 : Closed e602912421686 ∧ code e602912421686 = 2801935677238 := by decide
theorem cert_e602912421686 : check e602912421686 [[],[]] .chain = true := by decide
def e602912421690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e602912421690 : Closed e602912421690 ∧ code e602912421690 = 2801935677242 := by decide
theorem cert_e602912421690 : check e602912421690 [[],[]] .chain = true := by decide
def e602912422326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e602912422326 : Closed e602912422326 ∧ code e602912422326 = 2801935677878 := by decide
theorem cert_e602912422326 : check e602912422326 [[],[]] .chain = true := by decide
def e602912422358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e602912422358 : Closed e602912422358 ∧ code e602912422358 = 2801935677910 := by decide
theorem cert_e602912422358 : check e602912422358 [[],[]] .chain = true := by decide
def e602912422362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e602912422362 : Closed e602912422362 ∧ code e602912422362 = 2801935677914 := by decide
theorem cert_e602912422362 : check e602912422362 [[],[]] .chain = true := by decide
def e602912422518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e602912422518 : Closed e602912422518 ∧ code e602912422518 = 2801935678070 := by decide
theorem cert_e602912422518 : check e602912422518 [[],[]] .chain = true := by decide
def e602912422710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e602912422710 : Closed e602912422710 ∧ code e602912422710 = 2801935678262 := by decide
theorem cert_e602912422710 : check e602912422710 [[],[]] .chain = true := by decide
def e602912422714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e602912422714 : Closed e602912422714 ∧ code e602912422714 = 2801935678266 := by decide
theorem cert_e602912422714 : check e602912422714 [[],[]] .chain = true := by decide
def e602912429934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e602912429934 : Closed e602912429934 ∧ code e602912429934 = 2801935685486 := by decide
theorem cert_e602912429934 : check e602912429934 [[],[]] .chain = true := by decide
def e602912429942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e602912429942 : Closed e602912429942 ∧ code e602912429942 = 2801935685494 := by decide
theorem cert_e602912429942 : check e602912429942 [[],[]] .chain = true := by decide
def e602912430006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e602912430006 : Closed e602912430006 ∧ code e602912430006 = 2801935685558 := by decide
theorem cert_e602912430006 : check e602912430006 [[],[]] .chain = true := by decide
def e602912431342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e602912431342 : Closed e602912431342 ∧ code e602912431342 = 2801935686894 := by decide
theorem cert_e602912431342 : check e602912431342 [[],[]] .chain = true := by decide
def e602912431350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e602912431350 : Closed e602912431350 ∧ code e602912431350 = 2801935686902 := by decide
theorem cert_e602912431350 : check e602912431350 [[],[]] .chain = true := by decide
def e602912431734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e602912431734 : Closed e602912431734 ∧ code e602912431734 = 2801935687286 := by decide
theorem cert_e602912431734 : check e602912431734 [[],[]] .chain = true := by decide
def e602912443246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e602912443246 : Closed e602912443246 ∧ code e602912443246 = 2801935698798 := by decide
theorem cert_e602912443246 : check e602912443246 [[],[]] .chain = true := by decide
def e602912443254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e602912443254 : Closed e602912443254 ∧ code e602912443254 = 2801935698806 := by decide
theorem cert_e602912443254 : check e602912443254 [[],[]] .chain = true := by decide
def e602912443310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e602912443310 : Closed e602912443310 ∧ code e602912443310 = 2801935698862 := by decide
theorem cert_e602912443310 : check e602912443310 [[],[]] .chain = true := by decide
def e602912443322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e602912443322 : Closed e602912443322 ∧ code e602912443322 = 2801935698874 := by decide
theorem cert_e602912443322 : check e602912443322 [[],[]] .chain = true := by decide
def e602912443350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e602912443350 : Closed e602912443350 ∧ code e602912443350 = 2801935698902 := by decide
theorem cert_e602912443350 : check e602912443350 [[],[]] .chain = true := by decide
def e602912443354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e602912443354 : Closed e602912443354 ∧ code e602912443354 = 2801935698906 := by decide
theorem cert_e602912443354 : check e602912443354 [[],[]] .chain = true := by decide
def e602912443630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e602912443630 : Closed e602912443630 ∧ code e602912443630 = 2801935699182 := by decide
theorem cert_e602912443630 : check e602912443630 [[],[]] .chain = true := by decide
def e602912443638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e602912443638 : Closed e602912443638 ∧ code e602912443638 = 2801935699190 := by decide
theorem cert_e602912443638 : check e602912443638 [[],[]] .chain = true := by decide
def e602912444014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e602912444014 : Closed e602912444014 ∧ code e602912444014 = 2801935699566 := by decide
theorem cert_e602912444014 : check e602912444014 [[],[]] .chain = true := by decide
def e602912444026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e602912444026 : Closed e602912444026 ∧ code e602912444026 = 2801935699578 := by decide
theorem cert_e602912444026 : check e602912444026 [[],[]] .chain = true := by decide
def e602912444214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e602912444214 : Closed e602912444214 ∧ code e602912444214 = 2801935699766 := by decide
theorem cert_e602912444214 : check e602912444214 [[],[]] .chain = true := by decide
def e602912444218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e602912444218 : Closed e602912444218 ∧ code e602912444218 = 2801935699770 := by decide
theorem cert_e602912444218 : check e602912444218 [[],[]] .chain = true := by decide
def e602912449974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e602912449974 : Closed e602912449974 ∧ code e602912449974 = 2801935705526 := by decide
theorem cert_e602912449974 : check e602912449974 [[],[]] .chain = true := by decide
def e602912450006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e602912450006 : Closed e602912450006 ∧ code e602912450006 = 2801935705558 := by decide
theorem cert_e602912450006 : check e602912450006 [[],[]] .chain = true := by decide
def e602912450010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e602912450010 : Closed e602912450010 ∧ code e602912450010 = 2801935705562 := by decide
theorem cert_e602912450010 : check e602912450010 [[],[]] .chain = true := by decide
def e602912450166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e602912450166 : Closed e602912450166 ∧ code e602912450166 = 2801935705718 := by decide
theorem cert_e602912450166 : check e602912450166 [[],[]] .chain = true := by decide
def e602912450358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e602912450358 : Closed e602912450358 ∧ code e602912450358 = 2801935705910 := by decide
theorem cert_e602912450358 : check e602912450358 [[],[]] .chain = true := by decide
def e602912450362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e602912450362 : Closed e602912450362 ∧ code e602912450362 = 2801935705914 := by decide
theorem cert_e602912450362 : check e602912450362 [[],[]] .chain = true := by decide
def e602912787310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e602912787310 : Closed e602912787310 ∧ code e602912787310 = 2801936042862 := by decide
theorem cert_e602912787310 : check e602912787310 [[],[]] .sourceHead = true := by decide
def e602912787318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e602912787318 : Closed e602912787318 ∧ code e602912787318 = 2801936042870 := by decide
theorem cert_e602912787318 : check e602912787318 [[],[]] .sourceHead = true := by decide
def e602912787374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e602912787374 : Closed e602912787374 ∧ code e602912787374 = 2801936042926 := by decide
theorem cert_e602912787374 : check e602912787374 [[],[]] .sourceHead = true := by decide
def e602912787386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e602912787386 : Closed e602912787386 ∧ code e602912787386 = 2801936042938 := by decide
theorem cert_e602912787386 : check e602912787386 [[],[]] .sourceHead = true := by decide
def e602912787414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e602912787414 : Closed e602912787414 ∧ code e602912787414 = 2801936042966 := by decide
theorem cert_e602912787414 : check e602912787414 [[],[]] .sourceHead = true := by decide
def e602912787418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e602912787418 : Closed e602912787418 ∧ code e602912787418 = 2801936042970 := by decide
theorem cert_e602912787418 : check e602912787418 [[],[]] .sourceHead = true := by decide
def e602912787694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e602912787694 : Closed e602912787694 ∧ code e602912787694 = 2801936043246 := by decide
theorem cert_e602912787694 : check e602912787694 [[],[]] .sourceHead = true := by decide
def e602912787702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e602912787702 : Closed e602912787702 ∧ code e602912787702 = 2801936043254 := by decide
theorem cert_e602912787702 : check e602912787702 [[],[]] .sourceHead = true := by decide
def e602912788078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e602912788078 : Closed e602912788078 ∧ code e602912788078 = 2801936043630 := by decide
theorem cert_e602912788078 : check e602912788078 [[],[]] .sourceHead = true := by decide
def e602912788090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e602912788090 : Closed e602912788090 ∧ code e602912788090 = 2801936043642 := by decide
theorem cert_e602912788090 : check e602912788090 [[],[]] .sourceHead = true := by decide
def e602912788278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e602912788278 : Closed e602912788278 ∧ code e602912788278 = 2801936043830 := by decide
theorem cert_e602912788278 : check e602912788278 [[],[]] .sourceHead = true := by decide
def e602912788282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e602912788282 : Closed e602912788282 ∧ code e602912788282 = 2801936043834 := by decide
theorem cert_e602912788282 : check e602912788282 [[],[]] .sourceHead = true := by decide
def e602913385950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e602913385950 : Closed e602913385950 ∧ code e602913385950 = 2801936641502 := by decide
theorem cert_e602913385950 : check e602913385950 [[],[],[.under]] .smaller = true := by decide
def e602913385966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e602913385966 : Closed e602913385966 ∧ code e602913385966 = 2801936641518 := by decide
theorem cert_e602913385966 : check e602913385966 [[],[],[.under]] .smaller = true := by decide
def e602913386334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e602913386334 : Closed e602913386334 ∧ code e602913386334 = 2801936641886 := by decide
theorem cert_e602913386334 : check e602913386334 [[],[],[.under]] .smaller = true := by decide
def e602913386362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e602913386362 : Closed e602913386362 ∧ code e602913386362 = 2801936641914 := by decide
theorem cert_e602913386362 : check e602913386362 [[],[],[.under]] .smaller = true := by decide
def e602913386414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e602913386414 : Closed e602913386414 ∧ code e602913386414 = 2801936641966 := by decide
theorem cert_e602913386414 : check e602913386414 [[],[],[.under]] .smaller = true := by decide
def e602913386426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e602913386426 : Closed e602913386426 ∧ code e602913386426 = 2801936641978 := by decide
theorem cert_e602913386426 : check e602913386426 [[],[],[.under]] .smaller = true := by decide
def e602913387486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e602913387486 : Closed e602913387486 ∧ code e602913387486 = 2801936643038 := by decide
theorem cert_e602913387486 : check e602913387486 [[],[],[.under]] .smaller = true := by decide
def e602913387502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e602913387502 : Closed e602913387502 ∧ code e602913387502 = 2801936643054 := by decide
theorem cert_e602913387502 : check e602913387502 [[],[],[.under]] .smaller = true := by decide
def e602913389790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e602913389790 : Closed e602913389790 ∧ code e602913389790 = 2801936645342 := by decide
theorem cert_e602913389790 : check e602913389790 [[],[],[.under]] .smaller = true := by decide
def e602913389818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e602913389818 : Closed e602913389818 ∧ code e602913389818 = 2801936645370 := by decide
theorem cert_e602913389818 : check e602913389818 [[],[],[.under]] .smaller = true := by decide
def e602913390190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e602913390190 : Closed e602913390190 ∧ code e602913390190 = 2801936645742 := by decide
theorem cert_e602913390190 : check e602913390190 [[],[],[.under]] .smaller = true := by decide
def e602913390202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e602913390202 : Closed e602913390202 ∧ code e602913390202 = 2801936645754 := by decide
theorem cert_e602913390202 : check e602913390202 [[],[],[.under]] .smaller = true := by decide
def e602913418606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e602913418606 : Closed e602913418606 ∧ code e602913418606 = 2801936674158 := by decide
theorem cert_e602913418606 : check e602913418606 [[],[],[.under]] .smaller = true := by decide
def e602913418614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e602913418614 : Closed e602913418614 ∧ code e602913418614 = 2801936674166 := by decide
theorem cert_e602913418614 : check e602913418614 [[],[],[.under]] .smaller = true := by decide
def e602913418670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e602913418670 : Closed e602913418670 ∧ code e602913418670 = 2801936674222 := by decide
theorem cert_e602913418670 : check e602913418670 [[],[],[.under]] .smaller = true := by decide
def e602913418682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e602913418682 : Closed e602913418682 ∧ code e602913418682 = 2801936674234 := by decide
theorem cert_e602913418682 : check e602913418682 [[],[],[.under]] .smaller = true := by decide
def e602913418710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e602913418710 : Closed e602913418710 ∧ code e602913418710 = 2801936674262 := by decide
theorem cert_e602913418710 : check e602913418710 [[],[],[.under]] .smaller = true := by decide
def e602913418714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e602913418714 : Closed e602913418714 ∧ code e602913418714 = 2801936674266 := by decide
theorem cert_e602913418714 : check e602913418714 [[],[],[.under]] .smaller = true := by decide
def e602913418926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e602913418926 : Closed e602913418926 ∧ code e602913418926 = 2801936674478 := by decide
theorem cert_e602913418926 : check e602913418926 [[],[],[.under]] .smaller = true := by decide
def e602913418938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e602913418938 : Closed e602913418938 ∧ code e602913418938 = 2801936674490 := by decide
theorem cert_e602913418938 : check e602913418938 [[],[],[.under]] .smaller = true := by decide
def e602913418986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e602913418986 : Closed e602913418986 ∧ code e602913418986 = 2801936674538 := by decide
theorem cert_e602913418986 : check e602913418986 [[],[],[.under]] .smaller = true := by decide
def e602913419094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e602913419094 : Closed e602913419094 ∧ code e602913419094 = 2801936674646 := by decide
theorem cert_e602913419094 : check e602913419094 [[],[],[.under]] .smaller = true := by decide
def e602913419098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e602913419098 : Closed e602913419098 ∧ code e602913419098 = 2801936674650 := by decide
theorem cert_e602913419098 : check e602913419098 [[],[],[.under]] .smaller = true := by decide
def e602913419114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e602913419114 : Closed e602913419114 ∧ code e602913419114 = 2801936674666 := by decide
theorem cert_e602913419114 : check e602913419114 [[],[],[.under]] .smaller = true := by decide
def e602913420142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e602913420142 : Closed e602913420142 ∧ code e602913420142 = 2801936675694 := by decide
theorem cert_e602913420142 : check e602913420142 [[],[],[.under]] .smaller = true := by decide
def e602913420150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e602913420150 : Closed e602913420150 ∧ code e602913420150 = 2801936675702 := by decide
theorem cert_e602913420150 : check e602913420150 [[],[],[.under]] .smaller = true := by decide
def e602913420206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e602913420206 : Closed e602913420206 ∧ code e602913420206 = 2801936675758 := by decide
theorem cert_e602913420206 : check e602913420206 [[],[],[.under]] .smaller = true := by decide
def e602913420218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e602913420218 : Closed e602913420218 ∧ code e602913420218 = 2801936675770 := by decide
theorem cert_e602913420218 : check e602913420218 [[],[],[.under]] .smaller = true := by decide
def e602913420246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e602913420246 : Closed e602913420246 ∧ code e602913420246 = 2801936675798 := by decide
theorem cert_e602913420246 : check e602913420246 [[],[],[.under]] .smaller = true := by decide
def e602913420250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e602913420250 : Closed e602913420250 ∧ code e602913420250 = 2801936675802 := by decide
theorem cert_e602913420250 : check e602913420250 [[],[],[.under]] .smaller = true := by decide
def e602913420526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e602913420526 : Closed e602913420526 ∧ code e602913420526 = 2801936676078 := by decide
theorem cert_e602913420526 : check e602913420526 [[],[],[.under]] .smaller = true := by decide
def e602913420534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e602913420534 : Closed e602913420534 ∧ code e602913420534 = 2801936676086 := by decide
theorem cert_e602913420534 : check e602913420534 [[],[],[.under]] .smaller = true := by decide
def e602913420910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e602913420910 : Closed e602913420910 ∧ code e602913420910 = 2801936676462 := by decide
theorem cert_e602913420910 : check e602913420910 [[],[],[.under]] .smaller = true := by decide
def e602913420922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e602913420922 : Closed e602913420922 ∧ code e602913420922 = 2801936676474 := by decide
theorem cert_e602913420922 : check e602913420922 [[],[],[.under]] .smaller = true := by decide
def e602913421110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e602913421110 : Closed e602913421110 ∧ code e602913421110 = 2801936676662 := by decide
theorem cert_e602913421110 : check e602913421110 [[],[],[.under]] .smaller = true := by decide
def e602913421114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e602913421114 : Closed e602913421114 ∧ code e602913421114 = 2801936676666 := by decide
theorem cert_e602913421114 : check e602913421114 [[],[],[.under]] .smaller = true := by decide
def e602913421742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e602913421742 : Closed e602913421742 ∧ code e602913421742 = 2801936677294 := by decide
theorem cert_e602913421742 : check e602913421742 [[],[],[.under]] .smaller = true := by decide
def e602913421754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e602913421754 : Closed e602913421754 ∧ code e602913421754 = 2801936677306 := by decide
theorem cert_e602913421754 : check e602913421754 [[],[],[.under]] .smaller = true := by decide
def e602913421802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e602913421802 : Closed e602913421802 ∧ code e602913421802 = 2801936677354 := by decide
theorem cert_e602913421802 : check e602913421802 [[],[],[.under]] .smaller = true := by decide
def e602913421934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e602913421934 : Closed e602913421934 ∧ code e602913421934 = 2801936677486 := by decide
theorem cert_e602913421934 : check e602913421934 [[],[],[.under]] .smaller = true := by decide
def e602913421946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e602913421946 : Closed e602913421946 ∧ code e602913421946 = 2801936677498 := by decide
theorem cert_e602913421946 : check e602913421946 [[],[],[.under]] .smaller = true := by decide
def e602913422234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e602913422234 : Closed e602913422234 ∧ code e602913422234 = 2801936677786 := by decide
theorem cert_e602913422234 : check e602913422234 [[],[],[.under]] .smaller = true := by decide
def e602913422550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e602913422550 : Closed e602913422550 ∧ code e602913422550 = 2801936678102 := by decide
theorem cert_e602913422550 : check e602913422550 [[],[],[.under]] .smaller = true := by decide
def e602913422554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e602913422554 : Closed e602913422554 ∧ code e602913422554 = 2801936678106 := by decide
theorem cert_e602913422554 : check e602913422554 [[],[],[.under]] .smaller = true := by decide
def e602913422570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e602913422570 : Closed e602913422570 ∧ code e602913422570 = 2801936678122 := by decide
theorem cert_e602913422570 : check e602913422570 [[],[],[.under]] .smaller = true := by decide
def e602913422646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e602913422646 : Closed e602913422646 ∧ code e602913422646 = 2801936678198 := by decide
theorem cert_e602913422646 : check e602913422646 [[],[],[.under]] .smaller = true := by decide
def e602913422650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e602913422650 : Closed e602913422650 ∧ code e602913422650 = 2801936678202 := by decide
theorem cert_e602913422650 : check e602913422650 [[],[],[.under]] .smaller = true := by decide
def e602913422746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e602913422746 : Closed e602913422746 ∧ code e602913422746 = 2801936678298 := by decide
theorem cert_e602913422746 : check e602913422746 [[],[],[.under]] .smaller = true := by decide
def e602913424350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e602913424350 : Closed e602913424350 ∧ code e602913424350 = 2801936679902 := by decide
theorem cert_e602913424350 : check e602913424350 [[],[],[.under]] .smaller = true := by decide
def e602913424366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e602913424366 : Closed e602913424366 ∧ code e602913424366 = 2801936679918 := by decide
theorem cert_e602913424366 : check e602913424366 [[],[],[.under]] .smaller = true := by decide
def e602913426286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e602913426286 : Closed e602913426286 ∧ code e602913426286 = 2801936681838 := by decide
theorem cert_e602913426286 : check e602913426286 [[],[],[.under]] .smaller = true := by decide
def e602913426294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e602913426294 : Closed e602913426294 ∧ code e602913426294 = 2801936681846 := by decide
theorem cert_e602913426294 : check e602913426294 [[],[],[.under]] .smaller = true := by decide
def e602913426350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e602913426350 : Closed e602913426350 ∧ code e602913426350 = 2801936681902 := by decide
theorem cert_e602913426350 : check e602913426350 [[],[],[.under]] .smaller = true := by decide
def e602913426362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e602913426362 : Closed e602913426362 ∧ code e602913426362 = 2801936681914 := by decide
theorem cert_e602913426362 : check e602913426362 [[],[],[.under]] .smaller = true := by decide
def e602913426390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e602913426390 : Closed e602913426390 ∧ code e602913426390 = 2801936681942 := by decide
theorem cert_e602913426390 : check e602913426390 [[],[],[.under]] .smaller = true := by decide
def e602913426394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e602913426394 : Closed e602913426394 ∧ code e602913426394 = 2801936681946 := by decide
theorem cert_e602913426394 : check e602913426394 [[],[],[.under]] .smaller = true := by decide
def e602913426670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e602913426670 : Closed e602913426670 ∧ code e602913426670 = 2801936682222 := by decide
theorem cert_e602913426670 : check e602913426670 [[],[],[.under]] .smaller = true := by decide
def e602913426678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e602913426678 : Closed e602913426678 ∧ code e602913426678 = 2801936682230 := by decide
theorem cert_e602913426678 : check e602913426678 [[],[],[.under]] .smaller = true := by decide
def e602913427054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e602913427054 : Closed e602913427054 ∧ code e602913427054 = 2801936682606 := by decide
theorem cert_e602913427054 : check e602913427054 [[],[],[.under]] .smaller = true := by decide
def e602913427066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e602913427066 : Closed e602913427066 ∧ code e602913427066 = 2801936682618 := by decide
theorem cert_e602913427066 : check e602913427066 [[],[],[.under]] .smaller = true := by decide
def e602913427254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e602913427254 : Closed e602913427254 ∧ code e602913427254 = 2801936682806 := by decide
theorem cert_e602913427254 : check e602913427254 [[],[],[.under]] .smaller = true := by decide
def e602913427258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e602913427258 : Closed e602913427258 ∧ code e602913427258 = 2801936682810 := by decide
theorem cert_e602913427258 : check e602913427258 [[],[],[.under]] .smaller = true := by decide
def e602913432030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e602913432030 : Closed e602913432030 ∧ code e602913432030 = 2801936687582 := by decide
theorem cert_e602913432030 : check e602913432030 [[],[],[.under]] .smaller = true := by decide
def e602913432054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e602913432054 : Closed e602913432054 ∧ code e602913432054 = 2801936687606 := by decide
theorem cert_e602913432054 : check e602913432054 [[],[],[.under]] .smaller = true := by decide
def e602913433006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e602913433006 : Closed e602913433006 ∧ code e602913433006 = 2801936688558 := by decide
theorem cert_e602913433006 : check e602913433006 [[],[],[.under]] .smaller = true := by decide
def e602913433018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e602913433018 : Closed e602913433018 ∧ code e602913433018 = 2801936688570 := by decide
theorem cert_e602913433018 : check e602913433018 [[],[],[.under]] .smaller = true := by decide
def e602913433066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e602913433066 : Closed e602913433066 ∧ code e602913433066 = 2801936688618 := by decide
theorem cert_e602913433066 : check e602913433066 [[],[],[.under]] .smaller = true := by decide
def e602913433198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e602913433198 : Closed e602913433198 ∧ code e602913433198 = 2801936688750 := by decide
theorem cert_e602913433198 : check e602913433198 [[],[],[.under]] .smaller = true := by decide
end Blc.Floor41
