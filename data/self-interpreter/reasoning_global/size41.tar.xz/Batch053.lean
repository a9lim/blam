import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e602906123738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e602906123738 : Closed e602906123738 ∧ code e602906123738 = 2801929379290 := by decide
theorem cert_e602906123738 : check e602906123738 [[],[]] .smaller = true := by decide
def e602906123754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e602906123754 : Closed e602906123754 ∧ code e602906123754 = 2801929379306 := by decide
theorem cert_e602906123754 : check e602906123754 [[],[]] .smaller = true := by decide
def e602906123958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e602906123958 : Closed e602906123958 ∧ code e602906123958 = 2801929379510 := by decide
theorem cert_e602906123958 : check e602906123958 [[],[]] .smaller = true := by decide
def e602906123990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e602906123990 : Closed e602906123990 ∧ code e602906123990 = 2801929379542 := by decide
theorem cert_e602906123990 : check e602906123990 [[],[]] .smaller = true := by decide
def e602906123994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e602906123994 : Closed e602906123994 ∧ code e602906123994 = 2801929379546 := by decide
theorem cert_e602906123994 : check e602906123994 [[],[]] .smaller = true := by decide
def e602906124118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e602906124118 : Closed e602906124118 ∧ code e602906124118 = 2801929379670 := by decide
theorem cert_e602906124118 : check e602906124118 [[],[]] .smaller = true := by decide
def e602906124122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e602906124122 : Closed e602906124122 ∧ code e602906124122 = 2801929379674 := by decide
theorem cert_e602906124122 : check e602906124122 [[],[]] .smaller = true := by decide
def e602906124138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e602906124138 : Closed e602906124138 ∧ code e602906124138 = 2801929379690 := by decide
theorem cert_e602906124138 : check e602906124138 [[],[]] .smaller = true := by decide
def e602906126046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e602906126046 : Closed e602906126046 ∧ code e602906126046 = 2801929381598 := by decide
theorem cert_e602906126046 : check e602906126046 [[],[]] .smaller = true := by decide
def e602906126070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e602906126070 : Closed e602906126070 ∧ code e602906126070 = 2801929381622 := by decide
theorem cert_e602906126070 : check e602906126070 [[],[]] .smaller = true := by decide
def e602906126174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e602906126174 : Closed e602906126174 ∧ code e602906126174 = 2801929381726 := by decide
theorem cert_e602906126174 : check e602906126174 [[],[]] .smaller = true := by decide
def e602906126190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e602906126190 : Closed e602906126190 ∧ code e602906126190 = 2801929381742 := by decide
theorem cert_e602906126190 : check e602906126190 [[],[]] .smaller = true := by decide
def e602906126198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e602906126198 : Closed e602906126198 ∧ code e602906126198 = 2801929381750 := by decide
theorem cert_e602906126198 : check e602906126198 [[],[]] .smaller = true := by decide
def e602906126202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e602906126202 : Closed e602906126202 ∧ code e602906126202 = 2801929381754 := by decide
theorem cert_e602906126202 : check e602906126202 [[],[]] .smaller = true := by decide
def e602906126262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e602906126262 : Closed e602906126262 ∧ code e602906126262 = 2801929381814 := by decide
theorem cert_e602906126262 : check e602906126262 [[],[]] .smaller = true := by decide
def e602906126294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e602906126294 : Closed e602906126294 ∧ code e602906126294 = 2801929381846 := by decide
theorem cert_e602906126294 : check e602906126294 [[],[]] .smaller = true := by decide
def e602906126298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e602906126298 : Closed e602906126298 ∧ code e602906126298 = 2801929381850 := by decide
theorem cert_e602906126298 : check e602906126298 [[],[]] .smaller = true := by decide
def e602906126814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e602906126814 : Closed e602906126814 ∧ code e602906126814 = 2801929382366 := by decide
theorem cert_e602906126814 : check e602906126814 [[],[]] .smaller = true := by decide
def e602906126838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e602906126838 : Closed e602906126838 ∧ code e602906126838 = 2801929382390 := by decide
theorem cert_e602906126838 : check e602906126838 [[],[]] .smaller = true := by decide
def e602906127582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e602906127582 : Closed e602906127582 ∧ code e602906127582 = 2801929383134 := by decide
theorem cert_e602906127582 : check e602906127582 [[],[]] .smaller = true := by decide
def e602906127598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e602906127598 : Closed e602906127598 ∧ code e602906127598 = 2801929383150 := by decide
theorem cert_e602906127598 : check e602906127598 [[],[]] .smaller = true := by decide
def e602906127606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e602906127606 : Closed e602906127606 ∧ code e602906127606 = 2801929383158 := by decide
theorem cert_e602906127606 : check e602906127606 [[],[]] .smaller = true := by decide
def e602906127610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e602906127610 : Closed e602906127610 ∧ code e602906127610 = 2801929383162 := by decide
theorem cert_e602906127610 : check e602906127610 [[],[]] .smaller = true := by decide
def e602906127990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e602906127990 : Closed e602906127990 ∧ code e602906127990 = 2801929383542 := by decide
theorem cert_e602906127990 : check e602906127990 [[],[]] .smaller = true := by decide
def e602906128182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e602906128182 : Closed e602906128182 ∧ code e602906128182 = 2801929383734 := by decide
theorem cert_e602906128182 : check e602906128182 [[],[]] .smaller = true := by decide
def e602906128186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e602906128186 : Closed e602906128186 ∧ code e602906128186 = 2801929383738 := by decide
theorem cert_e602906128186 : check e602906128186 [[],[]] .smaller = true := by decide
def e602906129246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e602906129246 : Closed e602906129246 ∧ code e602906129246 = 2801929384798 := by decide
theorem cert_e602906129246 : check e602906129246 [[],[]] .smaller = true := by decide
def e602906129262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e602906129262 : Closed e602906129262 ∧ code e602906129262 = 2801929384814 := by decide
theorem cert_e602906129262 : check e602906129262 [[],[]] .smaller = true := by decide
def e602906129270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e602906129270 : Closed e602906129270 ∧ code e602906129270 = 2801929384822 := by decide
theorem cert_e602906129270 : check e602906129270 [[],[]] .smaller = true := by decide
def e602906129274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e602906129274 : Closed e602906129274 ∧ code e602906129274 = 2801929384826 := by decide
theorem cert_e602906129274 : check e602906129274 [[],[]] .smaller = true := by decide
def e602906129326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e602906129326 : Closed e602906129326 ∧ code e602906129326 = 2801929384878 := by decide
theorem cert_e602906129326 : check e602906129326 [[],[]] .smaller = true := by decide
def e602906129338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e602906129338 : Closed e602906129338 ∧ code e602906129338 = 2801929384890 := by decide
theorem cert_e602906129338 : check e602906129338 [[],[]] .smaller = true := by decide
def e602906129366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e602906129366 : Closed e602906129366 ∧ code e602906129366 = 2801929384918 := by decide
theorem cert_e602906129366 : check e602906129366 [[],[]] .smaller = true := by decide
def e602906129370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e602906129370 : Closed e602906129370 ∧ code e602906129370 = 2801929384922 := by decide
theorem cert_e602906129370 : check e602906129370 [[],[]] .smaller = true := by decide
def e602906129386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e602906129386 : Closed e602906129386 ∧ code e602906129386 = 2801929384938 := by decide
theorem cert_e602906129386 : check e602906129386 [[],[]] .smaller = true := by decide
def e602906129630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e602906129630 : Closed e602906129630 ∧ code e602906129630 = 2801929385182 := by decide
theorem cert_e602906129630 : check e602906129630 [[],[]] .smaller = true := by decide
def e602906129646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e602906129646 : Closed e602906129646 ∧ code e602906129646 = 2801929385198 := by decide
theorem cert_e602906129646 : check e602906129646 [[],[]] .smaller = true := by decide
def e602906129654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e602906129654 : Closed e602906129654 ∧ code e602906129654 = 2801929385206 := by decide
theorem cert_e602906129654 : check e602906129654 [[],[]] .smaller = true := by decide
def e602906129658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e602906129658 : Closed e602906129658 ∧ code e602906129658 = 2801929385210 := by decide
theorem cert_e602906129658 : check e602906129658 [[],[]] .smaller = true := by decide
def e602906130030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e602906130030 : Closed e602906130030 ∧ code e602906130030 = 2801929385582 := by decide
theorem cert_e602906130030 : check e602906130030 [[],[]] .smaller = true := by decide
def e602906130042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e602906130042 : Closed e602906130042 ∧ code e602906130042 = 2801929385594 := by decide
theorem cert_e602906130042 : check e602906130042 [[],[]] .smaller = true := by decide
def e602906130230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e602906130230 : Closed e602906130230 ∧ code e602906130230 = 2801929385782 := by decide
theorem cert_e602906130230 : check e602906130230 [[],[]] .smaller = true := by decide
def e602906130234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e602906130234 : Closed e602906130234 ∧ code e602906130234 = 2801929385786 := by decide
theorem cert_e602906130234 : check e602906130234 [[],[]] .smaller = true := by decide
def e602906130330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e602906130330 : Closed e602906130330 ∧ code e602906130330 = 2801929385882 := by decide
theorem cert_e602906130330 : check e602906130330 [[],[]] .smaller = true := by decide
def e602906130870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e602906130870 : Closed e602906130870 ∧ code e602906130870 = 2801929386422 := by decide
theorem cert_e602906130870 : check e602906130870 [[],[]] .smaller = true := by decide
def e602906130902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e602906130902 : Closed e602906130902 ∧ code e602906130902 = 2801929386454 := by decide
theorem cert_e602906130902 : check e602906130902 [[],[]] .smaller = true := by decide
def e602906130906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e602906130906 : Closed e602906130906 ∧ code e602906130906 = 2801929386458 := by decide
theorem cert_e602906130906 : check e602906130906 [[],[]] .smaller = true := by decide
def e602906131062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e602906131062 : Closed e602906131062 ∧ code e602906131062 = 2801929386614 := by decide
theorem cert_e602906131062 : check e602906131062 [[],[]] .smaller = true := by decide
def e602906131254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e602906131254 : Closed e602906131254 ∧ code e602906131254 = 2801929386806 := by decide
theorem cert_e602906131254 : check e602906131254 [[],[]] .smaller = true := by decide
def e602906131258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e602906131258 : Closed e602906131258 ∧ code e602906131258 = 2801929386810 := by decide
theorem cert_e602906131258 : check e602906131258 [[],[]] .smaller = true := by decide
def e602906131670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e602906131670 : Closed e602906131670 ∧ code e602906131670 = 2801929387222 := by decide
theorem cert_e602906131670 : check e602906131670 [[],[]] .smaller = true := by decide
def e602906131674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e602906131674 : Closed e602906131674 ∧ code e602906131674 = 2801929387226 := by decide
theorem cert_e602906131674 : check e602906131674 [[],[]] .smaller = true := by decide
def e602906131690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e602906131690 : Closed e602906131690 ∧ code e602906131690 = 2801929387242 := by decide
theorem cert_e602906131690 : check e602906131690 [[],[]] .smaller = true := by decide
def e602906131766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e602906131766 : Closed e602906131766 ∧ code e602906131766 = 2801929387318 := by decide
theorem cert_e602906131766 : check e602906131766 [[],[]] .smaller = true := by decide
def e602906131770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e602906131770 : Closed e602906131770 ∧ code e602906131770 = 2801929387322 := by decide
theorem cert_e602906131770 : check e602906131770 [[],[]] .smaller = true := by decide
def e602906131866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e602906131866 : Closed e602906131866 ∧ code e602906131866 = 2801929387418 := by decide
theorem cert_e602906131866 : check e602906131866 [[],[]] .smaller = true := by decide
def e602906138334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e602906138334 : Closed e602906138334 ∧ code e602906138334 = 2801929393886 := by decide
theorem cert_e602906138334 : check e602906138334 [[],[]] .smaller = true := by decide
def e602906138358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e602906138358 : Closed e602906138358 ∧ code e602906138358 = 2801929393910 := by decide
theorem cert_e602906138358 : check e602906138358 [[],[]] .smaller = true := by decide
def e602906138462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e602906138462 : Closed e602906138462 ∧ code e602906138462 = 2801929394014 := by decide
theorem cert_e602906138462 : check e602906138462 [[],[]] .smaller = true := by decide
def e602906138478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e602906138478 : Closed e602906138478 ∧ code e602906138478 = 2801929394030 := by decide
theorem cert_e602906138478 : check e602906138478 [[],[]] .smaller = true := by decide
def e602906138486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e602906138486 : Closed e602906138486 ∧ code e602906138486 = 2801929394038 := by decide
theorem cert_e602906138486 : check e602906138486 [[],[]] .smaller = true := by decide
def e602906138490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e602906138490 : Closed e602906138490 ∧ code e602906138490 = 2801929394042 := by decide
theorem cert_e602906138490 : check e602906138490 [[],[]] .smaller = true := by decide
def e602906138550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e602906138550 : Closed e602906138550 ∧ code e602906138550 = 2801929394102 := by decide
theorem cert_e602906138550 : check e602906138550 [[],[]] .smaller = true := by decide
def e602906138582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e602906138582 : Closed e602906138582 ∧ code e602906138582 = 2801929394134 := by decide
theorem cert_e602906138582 : check e602906138582 [[],[]] .smaller = true := by decide
def e602906138586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e602906138586 : Closed e602906138586 ∧ code e602906138586 = 2801929394138 := by decide
theorem cert_e602906138586 : check e602906138586 [[],[]] .smaller = true := by decide
def e602906139102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e602906139102 : Closed e602906139102 ∧ code e602906139102 = 2801929394654 := by decide
theorem cert_e602906139102 : check e602906139102 [[],[]] .smaller = true := by decide
def e602906139126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e602906139126 : Closed e602906139126 ∧ code e602906139126 = 2801929394678 := by decide
theorem cert_e602906139126 : check e602906139126 [[],[]] .smaller = true := by decide
def e602906139870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e602906139870 : Closed e602906139870 ∧ code e602906139870 = 2801929395422 := by decide
theorem cert_e602906139870 : check e602906139870 [[],[]] .smaller = true := by decide
def e602906139886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e602906139886 : Closed e602906139886 ∧ code e602906139886 = 2801929395438 := by decide
theorem cert_e602906139886 : check e602906139886 [[],[]] .smaller = true := by decide
def e602906139894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e602906139894 : Closed e602906139894 ∧ code e602906139894 = 2801929395446 := by decide
theorem cert_e602906139894 : check e602906139894 [[],[]] .smaller = true := by decide
def e602906139898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e602906139898 : Closed e602906139898 ∧ code e602906139898 = 2801929395450 := by decide
theorem cert_e602906139898 : check e602906139898 [[],[]] .smaller = true := by decide
def e602906140278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e602906140278 : Closed e602906140278 ∧ code e602906140278 = 2801929395830 := by decide
theorem cert_e602906140278 : check e602906140278 [[],[]] .smaller = true := by decide
def e602906140470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e602906140470 : Closed e602906140470 ∧ code e602906140470 = 2801929396022 := by decide
theorem cert_e602906140470 : check e602906140470 [[],[]] .smaller = true := by decide
def e602906140474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e602906140474 : Closed e602906140474 ∧ code e602906140474 = 2801929396026 := by decide
theorem cert_e602906140474 : check e602906140474 [[],[]] .smaller = true := by decide
def e602906151774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e602906151774 : Closed e602906151774 ∧ code e602906151774 = 2801929407326 := by decide
theorem cert_e602906151774 : check e602906151774 [[],[]] .smaller = true := by decide
def e602906151790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e602906151790 : Closed e602906151790 ∧ code e602906151790 = 2801929407342 := by decide
theorem cert_e602906151790 : check e602906151790 [[],[]] .smaller = true := by decide
def e602906151798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e602906151798 : Closed e602906151798 ∧ code e602906151798 = 2801929407350 := by decide
theorem cert_e602906151798 : check e602906151798 [[],[]] .smaller = true := by decide
def e602906151802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e602906151802 : Closed e602906151802 ∧ code e602906151802 = 2801929407354 := by decide
theorem cert_e602906151802 : check e602906151802 [[],[]] .smaller = true := by decide
def e602906151854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e602906151854 : Closed e602906151854 ∧ code e602906151854 = 2801929407406 := by decide
theorem cert_e602906151854 : check e602906151854 [[],[]] .smaller = true := by decide
def e602906151866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e602906151866 : Closed e602906151866 ∧ code e602906151866 = 2801929407418 := by decide
theorem cert_e602906151866 : check e602906151866 [[],[]] .smaller = true := by decide
def e602906151894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e602906151894 : Closed e602906151894 ∧ code e602906151894 = 2801929407446 := by decide
theorem cert_e602906151894 : check e602906151894 [[],[]] .smaller = true := by decide
def e602906151898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e602906151898 : Closed e602906151898 ∧ code e602906151898 = 2801929407450 := by decide
theorem cert_e602906151898 : check e602906151898 [[],[]] .smaller = true := by decide
def e602906151914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e602906151914 : Closed e602906151914 ∧ code e602906151914 = 2801929407466 := by decide
theorem cert_e602906151914 : check e602906151914 [[],[]] .smaller = true := by decide
def e602906152158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e602906152158 : Closed e602906152158 ∧ code e602906152158 = 2801929407710 := by decide
theorem cert_e602906152158 : check e602906152158 [[],[]] .smaller = true := by decide
def e602906152174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e602906152174 : Closed e602906152174 ∧ code e602906152174 = 2801929407726 := by decide
theorem cert_e602906152174 : check e602906152174 [[],[]] .smaller = true := by decide
def e602906152182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e602906152182 : Closed e602906152182 ∧ code e602906152182 = 2801929407734 := by decide
theorem cert_e602906152182 : check e602906152182 [[],[]] .smaller = true := by decide
def e602906152186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e602906152186 : Closed e602906152186 ∧ code e602906152186 = 2801929407738 := by decide
theorem cert_e602906152186 : check e602906152186 [[],[]] .smaller = true := by decide
def e602906152558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e602906152558 : Closed e602906152558 ∧ code e602906152558 = 2801929408110 := by decide
theorem cert_e602906152558 : check e602906152558 [[],[]] .smaller = true := by decide
def e602906152570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e602906152570 : Closed e602906152570 ∧ code e602906152570 = 2801929408122 := by decide
theorem cert_e602906152570 : check e602906152570 [[],[]] .smaller = true := by decide
def e602906152758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e602906152758 : Closed e602906152758 ∧ code e602906152758 = 2801929408310 := by decide
theorem cert_e602906152758 : check e602906152758 [[],[]] .smaller = true := by decide
def e602906152762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e602906152762 : Closed e602906152762 ∧ code e602906152762 = 2801929408314 := by decide
theorem cert_e602906152762 : check e602906152762 [[],[]] .smaller = true := by decide
def e602906152858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e602906152858 : Closed e602906152858 ∧ code e602906152858 = 2801929408410 := by decide
theorem cert_e602906152858 : check e602906152858 [[],[]] .smaller = true := by decide
def e602906158518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e602906158518 : Closed e602906158518 ∧ code e602906158518 = 2801929414070 := by decide
theorem cert_e602906158518 : check e602906158518 [[],[]] .smaller = true := by decide
def e602906158550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e602906158550 : Closed e602906158550 ∧ code e602906158550 = 2801929414102 := by decide
theorem cert_e602906158550 : check e602906158550 [[],[]] .smaller = true := by decide
def e602906158554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e602906158554 : Closed e602906158554 ∧ code e602906158554 = 2801929414106 := by decide
theorem cert_e602906158554 : check e602906158554 [[],[]] .smaller = true := by decide
def e602906158710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e602906158710 : Closed e602906158710 ∧ code e602906158710 = 2801929414262 := by decide
theorem cert_e602906158710 : check e602906158710 [[],[]] .smaller = true := by decide
def e602906158902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e602906158902 : Closed e602906158902 ∧ code e602906158902 = 2801929414454 := by decide
theorem cert_e602906158902 : check e602906158902 [[],[]] .smaller = true := by decide
def e602906158906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e602906158906 : Closed e602906158906 ∧ code e602906158906 = 2801929414458 := by decide
theorem cert_e602906158906 : check e602906158906 [[],[]] .smaller = true := by decide
def e602906161878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e602906161878 : Closed e602906161878 ∧ code e602906161878 = 2801929417430 := by decide
theorem cert_e602906161878 : check e602906161878 [[],[]] .smaller = true := by decide
def e602906161882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e602906161882 : Closed e602906161882 ∧ code e602906161882 = 2801929417434 := by decide
theorem cert_e602906161882 : check e602906161882 [[],[]] .smaller = true := by decide
def e602906161898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e602906161898 : Closed e602906161898 ∧ code e602906161898 = 2801929417450 := by decide
theorem cert_e602906161898 : check e602906161898 [[],[]] .smaller = true := by decide
def e602906161974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e602906161974 : Closed e602906161974 ∧ code e602906161974 = 2801929417526 := by decide
theorem cert_e602906161974 : check e602906161974 [[],[]] .smaller = true := by decide
def e602906161978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e602906161978 : Closed e602906161978 ∧ code e602906161978 = 2801929417530 := by decide
theorem cert_e602906161978 : check e602906161978 [[],[]] .smaller = true := by decide
def e602906162074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e602906162074 : Closed e602906162074 ∧ code e602906162074 = 2801929417626 := by decide
theorem cert_e602906162074 : check e602906162074 [[],[]] .smaller = true := by decide
def e602906387310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e602906387310 : Closed e602906387310 ∧ code e602906387310 = 2801929642862 := by decide
theorem cert_e602906387310 : check e602906387310 [[],[]] .smaller = true := by decide
def e602906387318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e602906387318 : Closed e602906387318 ∧ code e602906387318 = 2801929642870 := by decide
theorem cert_e602906387318 : check e602906387318 [[],[]] .smaller = true := by decide
def e602906387374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e602906387374 : Closed e602906387374 ∧ code e602906387374 = 2801929642926 := by decide
theorem cert_e602906387374 : check e602906387374 [[],[]] .smaller = true := by decide
def e602906387386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e602906387386 : Closed e602906387386 ∧ code e602906387386 = 2801929642938 := by decide
theorem cert_e602906387386 : check e602906387386 [[],[]] .smaller = true := by decide
def e602906387414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e602906387414 : Closed e602906387414 ∧ code e602906387414 = 2801929642966 := by decide
theorem cert_e602906387414 : check e602906387414 [[],[]] .smaller = true := by decide
def e602906387418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e602906387418 : Closed e602906387418 ∧ code e602906387418 = 2801929642970 := by decide
theorem cert_e602906387418 : check e602906387418 [[],[]] .smaller = true := by decide
def e602906388718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e602906388718 : Closed e602906388718 ∧ code e602906388718 = 2801929644270 := by decide
theorem cert_e602906388718 : check e602906388718 [[],[]] .smaller = true := by decide
def e602906388726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e602906388726 : Closed e602906388726 ∧ code e602906388726 = 2801929644278 := by decide
theorem cert_e602906388726 : check e602906388726 [[],[]] .smaller = true := by decide
def e602906389278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e602906389278 : Closed e602906389278 ∧ code e602906389278 = 2801929644830 := by decide
theorem cert_e602906389278 : check e602906389278 [[],[]] .smaller = true := by decide
def e602906389390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e602906389390 : Closed e602906389390 ∧ code e602906389390 = 2801929644942 := by decide
theorem cert_e602906389390 : check e602906389390 [[],[]] .smaller = true := by decide
def e602906389614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e602906389614 : Closed e602906389614 ∧ code e602906389614 = 2801929645166 := by decide
theorem cert_e602906389614 : check e602906389614 [[],[]] .smaller = true := by decide
def e602906389626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e602906389626 : Closed e602906389626 ∧ code e602906389626 = 2801929645178 := by decide
theorem cert_e602906389626 : check e602906389626 [[],[]] .smaller = true := by decide
def e602906389790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e602906389790 : Closed e602906389790 ∧ code e602906389790 = 2801929645342 := by decide
theorem cert_e602906389790 : check e602906389790 [[],[]] .smaller = true := by decide
def e602906389958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e602906389958 : Closed e602906389958 ∧ code e602906389958 = 2801929645510 := by decide
theorem cert_e602906389958 : check e602906389958 [[],[]] .smaller = true := by decide
def e602906390070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e602906390070 : Closed e602906390070 ∧ code e602906390070 = 2801929645622 := by decide
theorem cert_e602906390070 : check e602906390070 [[],[]] .smaller = true := by decide
def e602906390074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e602906390074 : Closed e602906390074 ∧ code e602906390074 = 2801929645626 := by decide
theorem cert_e602906390074 : check e602906390074 [[],[]] .smaller = true := by decide
def e602906390158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e602906390158 : Closed e602906390158 ∧ code e602906390158 = 2801929645710 := by decide
theorem cert_e602906390158 : check e602906390158 [[],[]] .smaller = true := by decide
def e602906390214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e602906390214 : Closed e602906390214 ∧ code e602906390214 = 2801929645766 := by decide
theorem cert_e602906390214 : check e602906390214 [[],[]] .smaller = true := by decide
def e602906390958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e602906390958 : Closed e602906390958 ∧ code e602906390958 = 2801929646510 := by decide
theorem cert_e602906390958 : check e602906390958 [[],[]] .smaller = true := by decide
def e602906390970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e602906390970 : Closed e602906390970 ∧ code e602906390970 = 2801929646522 := by decide
theorem cert_e602906390970 : check e602906390970 [[],[]] .smaller = true := by decide
def e602906391018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e602906391018 : Closed e602906391018 ∧ code e602906391018 = 2801929646570 := by decide
theorem cert_e602906391018 : check e602906391018 [[],[]] .smaller = true := by decide
def e602906391662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e602906391662 : Closed e602906391662 ∧ code e602906391662 = 2801929647214 := by decide
theorem cert_e602906391662 : check e602906391662 [[],[]] .smaller = true := by decide
def e602906391674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e602906391674 : Closed e602906391674 ∧ code e602906391674 = 2801929647226 := by decide
theorem cert_e602906391674 : check e602906391674 [[],[]] .smaller = true := by decide
def e602906391838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e602906391838 : Closed e602906391838 ∧ code e602906391838 = 2801929647390 := by decide
theorem cert_e602906391838 : check e602906391838 [[],[]] .smaller = true := by decide
def e602906392006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e602906392006 : Closed e602906392006 ∧ code e602906392006 = 2801929647558 := by decide
theorem cert_e602906392006 : check e602906392006 [[],[]] .smaller = true := by decide
def e602906392346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e602906392346 : Closed e602906392346 ∧ code e602906392346 = 2801929647898 := by decide
theorem cert_e602906392346 : check e602906392346 [[],[]] .smaller = true := by decide
def e602906392390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e602906392390 : Closed e602906392390 ∧ code e602906392390 = 2801929647942 := by decide
theorem cert_e602906392390 : check e602906392390 [[],[]] .smaller = true := by decide
def e602906392790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e602906392790 : Closed e602906392790 ∧ code e602906392790 = 2801929648342 := by decide
theorem cert_e602906392790 : check e602906392790 [[],[]] .smaller = true := by decide
def e602906392794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e602906392794 : Closed e602906392794 ∧ code e602906392794 = 2801929648346 := by decide
theorem cert_e602906392794 : check e602906392794 [[],[]] .smaller = true := by decide
def e602906392810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e602906392810 : Closed e602906392810 ∧ code e602906392810 = 2801929648362 := by decide
theorem cert_e602906392810 : check e602906392810 [[],[]] .smaller = true := by decide
def e602906393142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e602906393142 : Closed e602906393142 ∧ code e602906393142 = 2801929648694 := by decide
theorem cert_e602906393142 : check e602906393142 [[],[]] .smaller = true := by decide
def e602906393146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e602906393146 : Closed e602906393146 ∧ code e602906393146 = 2801929648698 := by decide
theorem cert_e602906393146 : check e602906393146 [[],[]] .smaller = true := by decide
def e602906393230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e602906393230 : Closed e602906393230 ∧ code e602906393230 = 2801929648782 := by decide
theorem cert_e602906393230 : check e602906393230 [[],[]] .smaller = true := by decide
def e602906393286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e602906393286 : Closed e602906393286 ∧ code e602906393286 = 2801929648838 := by decide
theorem cert_e602906393286 : check e602906393286 [[],[]] .smaller = true := by decide
def e602906393370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e602906393370 : Closed e602906393370 ∧ code e602906393370 = 2801929648922 := by decide
theorem cert_e602906393370 : check e602906393370 [[],[]] .smaller = true := by decide
def e602906393414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e602906393414 : Closed e602906393414 ∧ code e602906393414 = 2801929648966 := by decide
theorem cert_e602906393414 : check e602906393414 [[],[]] .smaller = true := by decide
def e602906397934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e602906397934 : Closed e602906397934 ∧ code e602906397934 = 2801929653486 := by decide
theorem cert_e602906397934 : check e602906397934 [[],[]] .smaller = true := by decide
def e602906397942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e602906397942 : Closed e602906397942 ∧ code e602906397942 = 2801929653494 := by decide
theorem cert_e602906397942 : check e602906397942 [[],[]] .smaller = true := by decide
def e602906398318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e602906398318 : Closed e602906398318 ∧ code e602906398318 = 2801929653870 := by decide
theorem cert_e602906398318 : check e602906398318 [[],[]] .smaller = true := by decide
def e602906398330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e602906398330 : Closed e602906398330 ∧ code e602906398330 = 2801929653882 := by decide
theorem cert_e602906398330 : check e602906398330 [[],[]] .smaller = true := by decide
def e602906398518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e602906398518 : Closed e602906398518 ∧ code e602906398518 = 2801929654070 := by decide
theorem cert_e602906398518 : check e602906398518 [[],[]] .smaller = true := by decide
def e602906398522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e602906398522 : Closed e602906398522 ∧ code e602906398522 = 2801929654074 := by decide
theorem cert_e602906398522 : check e602906398522 [[],[]] .smaller = true := by decide
def e602906401006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e602906401006 : Closed e602906401006 ∧ code e602906401006 = 2801929656558 := by decide
theorem cert_e602906401006 : check e602906401006 [[],[]] .smaller = true := by decide
def e602906401014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e602906401014 : Closed e602906401014 ∧ code e602906401014 = 2801929656566 := by decide
theorem cert_e602906401014 : check e602906401014 [[],[]] .smaller = true := by decide
def e602906401566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e602906401566 : Closed e602906401566 ∧ code e602906401566 = 2801929657118 := by decide
theorem cert_e602906401566 : check e602906401566 [[],[]] .smaller = true := by decide
def e602906401678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e602906401678 : Closed e602906401678 ∧ code e602906401678 = 2801929657230 := by decide
theorem cert_e602906401678 : check e602906401678 [[],[]] .smaller = true := by decide
def e602906401902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e602906401902 : Closed e602906401902 ∧ code e602906401902 = 2801929657454 := by decide
theorem cert_e602906401902 : check e602906401902 [[],[]] .smaller = true := by decide
def e602906401914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e602906401914 : Closed e602906401914 ∧ code e602906401914 = 2801929657466 := by decide
theorem cert_e602906401914 : check e602906401914 [[],[]] .smaller = true := by decide
def e602906402078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e602906402078 : Closed e602906402078 ∧ code e602906402078 = 2801929657630 := by decide
theorem cert_e602906402078 : check e602906402078 [[],[]] .smaller = true := by decide
def e602906402246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e602906402246 : Closed e602906402246 ∧ code e602906402246 = 2801929657798 := by decide
theorem cert_e602906402246 : check e602906402246 [[],[]] .smaller = true := by decide
def e602906402358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e602906402358 : Closed e602906402358 ∧ code e602906402358 = 2801929657910 := by decide
theorem cert_e602906402358 : check e602906402358 [[],[]] .smaller = true := by decide
def e602906402362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e602906402362 : Closed e602906402362 ∧ code e602906402362 = 2801929657914 := by decide
theorem cert_e602906402362 : check e602906402362 [[],[]] .smaller = true := by decide
def e602906402446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e602906402446 : Closed e602906402446 ∧ code e602906402446 = 2801929657998 := by decide
theorem cert_e602906402446 : check e602906402446 [[],[]] .smaller = true := by decide
def e602906402502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e602906402502 : Closed e602906402502 ∧ code e602906402502 = 2801929658054 := by decide
theorem cert_e602906402502 : check e602906402502 [[],[]] .smaller = true := by decide
def e602906404638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e602906404638 : Closed e602906404638 ∧ code e602906404638 = 2801929660190 := by decide
theorem cert_e602906404638 : check e602906404638 [[],[]] .smaller = true := by decide
def e602906404750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e602906404750 : Closed e602906404750 ∧ code e602906404750 = 2801929660302 := by decide
theorem cert_e602906404750 : check e602906404750 [[],[]] .smaller = true := by decide
end Blc.Floor41
