import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605594333102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605594333102 : Closed e605594333102 ∧ code e605594333102 = 2804617588654 := by decide
theorem cert_e605594333102 : check e605594333102 [[],[]] .smaller = true := by decide
def e605594333114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605594333114 : Closed e605594333114 ∧ code e605594333114 = 2804617588666 := by decide
theorem cert_e605594333114 : check e605594333114 [[],[]] .smaller = true := by decide
def e605594334174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605594334174 : Closed e605594334174 ∧ code e605594334174 = 2804617589726 := by decide
theorem cert_e605594334174 : check e605594334174 [[],[]] .smaller = true := by decide
def e605594334190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605594334190 : Closed e605594334190 ∧ code e605594334190 = 2804617589742 := by decide
theorem cert_e605594334190 : check e605594334190 [[],[]] .smaller = true := by decide
def e605594335726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e605594335726 : Closed e605594335726 ∧ code e605594335726 = 2804617591278 := by decide
theorem cert_e605594335726 : check e605594335726 [[],[]] .smaller = true := by decide
def e605594336478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605594336478 : Closed e605594336478 ∧ code e605594336478 = 2804617592030 := by decide
theorem cert_e605594336478 : check e605594336478 [[],[]] .smaller = true := by decide
def e605594336494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e605594336494 : Closed e605594336494 ∧ code e605594336494 = 2804617592046 := by decide
theorem cert_e605594336494 : check e605594336494 [[],[]] .smaller = true := by decide
def e605594336502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e605594336502 : Closed e605594336502 ∧ code e605594336502 = 2804617592054 := by decide
theorem cert_e605594336502 : check e605594336502 [[],[]] .smaller = true := by decide
def e605594336506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605594336506 : Closed e605594336506 ∧ code e605594336506 = 2804617592058 := by decide
theorem cert_e605594336506 : check e605594336506 [[],[]] .smaller = true := by decide
def e605594336878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605594336878 : Closed e605594336878 ∧ code e605594336878 = 2804617592430 := by decide
theorem cert_e605594336878 : check e605594336878 [[],[]] .smaller = true := by decide
def e605594336890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605594336890 : Closed e605594336890 ∧ code e605594336890 = 2804617592442 := by decide
theorem cert_e605594336890 : check e605594336890 [[],[]] .smaller = true := by decide
def e605594365014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e605594365014 : Closed e605594365014 ∧ code e605594365014 = 2804617620566 := by decide
theorem cert_e605594365014 : check e605594365014 [[],[]] .smaller = true := by decide
def e605594365018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e605594365018 : Closed e605594365018 ∧ code e605594365018 = 2804617620570 := by decide
theorem cert_e605594365018 : check e605594365018 [[],[]] .smaller = true := by decide
def e605594365206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e605594365206 : Closed e605594365206 ∧ code e605594365206 = 2804617620758 := by decide
theorem cert_e605594365206 : check e605594365206 [[],[]] .smaller = true := by decide
def e605594365278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e605594365278 : Closed e605594365278 ∧ code e605594365278 = 2804617620830 := by decide
theorem cert_e605594365278 : check e605594365278 [[],[]] .three = true := by decide
def e605594365282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e605594365282 : Closed e605594365282 ∧ code e605594365282 = 2804617620834 := by decide
theorem cert_e605594365282 : check e605594365282 [[],[]] .smaller = true := by decide
def e605594365294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605594365294 : Closed e605594365294 ∧ code e605594365294 = 2804617620846 := by decide
theorem cert_e605594365294 : check e605594365294 [[],[]] .smaller = true := by decide
def e605594365302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605594365302 : Closed e605594365302 ∧ code e605594365302 = 2804617620854 := by decide
theorem cert_e605594365302 : check e605594365302 [[],[]] .smaller = true := by decide
def e605594365306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e605594365306 : Closed e605594365306 ∧ code e605594365306 = 2804617620858 := by decide
theorem cert_e605594365306 : check e605594365306 [[],[]] .three = true := by decide
def e605594365322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605594365322 : Closed e605594365322 ∧ code e605594365322 = 2804617620874 := by decide
theorem cert_e605594365322 : check e605594365322 [[],[]] .smaller = true := by decide
def e605594365346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605594365346 : Closed e605594365346 ∧ code e605594365346 = 2804617620898 := by decide
theorem cert_e605594365346 : check e605594365346 [[],[]] .smaller = true := by decide
def e605594365358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605594365358 : Closed e605594365358 ∧ code e605594365358 = 2804617620910 := by decide
theorem cert_e605594365358 : check e605594365358 [[],[]] .smaller = true := by decide
def e605594365366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1))))))))
theorem wire_e605594365366 : Closed e605594365366 ∧ code e605594365366 = 2804617620918 := by decide
theorem cert_e605594365366 : check e605594365366 [[],[]] .smaller = true := by decide
def e605594365370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605594365370 : Closed e605594365370 ∧ code e605594365370 = 2804617620922 := by decide
theorem cert_e605594365370 : check e605594365370 [[],[]] .smaller = true := by decide
def e605594365398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605594365398 : Closed e605594365398 ∧ code e605594365398 = 2804617620950 := by decide
theorem cert_e605594365398 : check e605594365398 [[],[]] .smaller = true := by decide
def e605594365402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605594365402 : Closed e605594365402 ∧ code e605594365402 = 2804617620954 := by decide
theorem cert_e605594365402 : check e605594365402 [[],[]] .smaller = true := by decide
def e605594365418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e605594365418 : Closed e605594365418 ∧ code e605594365418 = 2804617620970 := by decide
theorem cert_e605594365418 : check e605594365418 [[],[]] .three = true := by decide
def e605594365482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e605594365482 : Closed e605594365482 ∧ code e605594365482 = 2804617621034 := by decide
theorem cert_e605594365482 : check e605594365482 [[],[]] .smaller = true := by decide
def e605594365578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605594365578 : Closed e605594365578 ∧ code e605594365578 = 2804617621130 := by decide
theorem cert_e605594365578 : check e605594365578 [[],[]] .smaller = true := by decide
def e605594365602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605594365602 : Closed e605594365602 ∧ code e605594365602 = 2804617621154 := by decide
theorem cert_e605594365602 : check e605594365602 [[],[]] .smaller = true := by decide
def e605594365614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605594365614 : Closed e605594365614 ∧ code e605594365614 = 2804617621166 := by decide
theorem cert_e605594365614 : check e605594365614 [[],[]] .smaller = true := by decide
def e605594365622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e605594365622 : Closed e605594365622 ∧ code e605594365622 = 2804617621174 := by decide
theorem cert_e605594365622 : check e605594365622 [[],[]] .smaller = true := by decide
def e605594365626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605594365626 : Closed e605594365626 ∧ code e605594365626 = 2804617621178 := by decide
theorem cert_e605594365626 : check e605594365626 [[],[]] .smaller = true := by decide
def e605594365654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e605594365654 : Closed e605594365654 ∧ code e605594365654 = 2804617621206 := by decide
theorem cert_e605594365654 : check e605594365654 [[],[]] .smaller = true := by decide
def e605594365658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e605594365658 : Closed e605594365658 ∧ code e605594365658 = 2804617621210 := by decide
theorem cert_e605594365658 : check e605594365658 [[],[]] .smaller = true := by decide
def e605594365674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605594365674 : Closed e605594365674 ∧ code e605594365674 = 2804617621226 := by decide
theorem cert_e605594365674 : check e605594365674 [[],[]] .smaller = true := by decide
def e605594365782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605594365782 : Closed e605594365782 ∧ code e605594365782 = 2804617621334 := by decide
theorem cert_e605594365782 : check e605594365782 [[],[]] .smaller = true := by decide
def e605594365786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605594365786 : Closed e605594365786 ∧ code e605594365786 = 2804617621338 := by decide
theorem cert_e605594365786 : check e605594365786 [[],[]] .smaller = true := by decide
def e605594365802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605594365802 : Closed e605594365802 ∧ code e605594365802 = 2804617621354 := by decide
theorem cert_e605594365802 : check e605594365802 [[],[]] .smaller = true := by decide
def e605594365866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605594365866 : Closed e605594365866 ∧ code e605594365866 = 2804617621418 := by decide
theorem cert_e605594365866 : check e605594365866 [[],[]] .three = true := by decide
def e605594366070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e605594366070 : Closed e605594366070 ∧ code e605594366070 = 2804617621622 := by decide
theorem cert_e605594366070 : check e605594366070 [[],[]] .smaller = true := by decide
def e605594366074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e605594366074 : Closed e605594366074 ∧ code e605594366074 = 2804617621626 := by decide
theorem cert_e605594366074 : check e605594366074 [[],[]] .smaller = true := by decide
def e605594366166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e605594366166 : Closed e605594366166 ∧ code e605594366166 = 2804617621718 := by decide
theorem cert_e605594366166 : check e605594366166 [[],[]] .smaller = true := by decide
def e605594366262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e605594366262 : Closed e605594366262 ∧ code e605594366262 = 2804617621814 := by decide
theorem cert_e605594366262 : check e605594366262 [[],[]] .smaller = true := by decide
def e605594366266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e605594366266 : Closed e605594366266 ∧ code e605594366266 = 2804617621818 := by decide
theorem cert_e605594366266 : check e605594366266 [[],[]] .smaller = true := by decide
def e605594366350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e605594366350 : Closed e605594366350 ∧ code e605594366350 = 2804617621902 := by decide
theorem cert_e605594366350 : check e605594366350 [[],[]] .smaller = true := by decide
def e605594366406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e605594366406 : Closed e605594366406 ∧ code e605594366406 = 2804617621958 := by decide
theorem cert_e605594366406 : check e605594366406 [[],[]] .smaller = true := by decide
def e605594366742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605594366742 : Closed e605594366742 ∧ code e605594366742 = 2804617622294 := by decide
theorem cert_e605594366742 : check e605594366742 [[],[]] .smaller = true := by decide
def e605594366814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e605594366814 : Closed e605594366814 ∧ code e605594366814 = 2804617622366 := by decide
theorem cert_e605594366814 : check e605594366814 [[],[]] .three = true := by decide
def e605594366818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e605594366818 : Closed e605594366818 ∧ code e605594366818 = 2804617622370 := by decide
theorem cert_e605594366818 : check e605594366818 [[],[]] .smaller = true := by decide
def e605594366830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605594366830 : Closed e605594366830 ∧ code e605594366830 = 2804617622382 := by decide
theorem cert_e605594366830 : check e605594366830 [[],[]] .smaller = true := by decide
def e605594366838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605594366838 : Closed e605594366838 ∧ code e605594366838 = 2804617622390 := by decide
theorem cert_e605594366838 : check e605594366838 [[],[]] .smaller = true := by decide
def e605594366842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e605594366842 : Closed e605594366842 ∧ code e605594366842 = 2804617622394 := by decide
theorem cert_e605594366842 : check e605594366842 [[],[]] .three = true := by decide
def e605594366858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605594366858 : Closed e605594366858 ∧ code e605594366858 = 2804617622410 := by decide
theorem cert_e605594366858 : check e605594366858 [[],[]] .smaller = true := by decide
def e605594366882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e605594366882 : Closed e605594366882 ∧ code e605594366882 = 2804617622434 := by decide
theorem cert_e605594366882 : check e605594366882 [[],[]] .smaller = true := by decide
def e605594366894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605594366894 : Closed e605594366894 ∧ code e605594366894 = 2804617622446 := by decide
theorem cert_e605594366894 : check e605594366894 [[],[]] .smaller = true := by decide
def e605594366902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))))))
theorem wire_e605594366902 : Closed e605594366902 ∧ code e605594366902 = 2804617622454 := by decide
theorem cert_e605594366902 : check e605594366902 [[],[]] .smaller = true := by decide
def e605594366906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605594366906 : Closed e605594366906 ∧ code e605594366906 = 2804617622458 := by decide
theorem cert_e605594366906 : check e605594366906 [[],[]] .smaller = true := by decide
def e605594366934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605594366934 : Closed e605594366934 ∧ code e605594366934 = 2804617622486 := by decide
theorem cert_e605594366934 : check e605594366934 [[],[]] .smaller = true := by decide
def e605594366938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605594366938 : Closed e605594366938 ∧ code e605594366938 = 2804617622490 := by decide
theorem cert_e605594366938 : check e605594366938 [[],[]] .smaller = true := by decide
def e605594366954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e605594366954 : Closed e605594366954 ∧ code e605594366954 = 2804617622506 := by decide
theorem cert_e605594366954 : check e605594366954 [[],[]] .three = true := by decide
def e605594367006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e605594367006 : Closed e605594367006 ∧ code e605594367006 = 2804617622558 := by decide
theorem cert_e605594367006 : check e605594367006 [[],[]] .smaller = true := by decide
def e605594367198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605594367198 : Closed e605594367198 ∧ code e605594367198 = 2804617622750 := by decide
theorem cert_e605594367198 : check e605594367198 [[],[]] .three = true := by decide
def e605594367202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e605594367202 : Closed e605594367202 ∧ code e605594367202 = 2804617622754 := by decide
theorem cert_e605594367202 : check e605594367202 [[],[]] .smaller = true := by decide
def e605594367214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605594367214 : Closed e605594367214 ∧ code e605594367214 = 2804617622766 := by decide
theorem cert_e605594367214 : check e605594367214 [[],[]] .smaller = true := by decide
def e605594367222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605594367222 : Closed e605594367222 ∧ code e605594367222 = 2804617622774 := by decide
theorem cert_e605594367222 : check e605594367222 [[],[]] .smaller = true := by decide
def e605594367226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605594367226 : Closed e605594367226 ∧ code e605594367226 = 2804617622778 := by decide
theorem cert_e605594367226 : check e605594367226 [[],[]] .three = true := by decide
def e605594367502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e605594367502 : Closed e605594367502 ∧ code e605594367502 = 2804617623054 := by decide
theorem cert_e605594367502 : check e605594367502 [[],[]] .smaller = true := by decide
def e605594367514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605594367514 : Closed e605594367514 ∧ code e605594367514 = 2804617623066 := by decide
theorem cert_e605594367514 : check e605594367514 [[],[]] .smaller = true := by decide
def e605594367586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605594367586 : Closed e605594367586 ∧ code e605594367586 = 2804617623138 := by decide
theorem cert_e605594367586 : check e605594367586 [[],[]] .smaller = true := by decide
def e605594367598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605594367598 : Closed e605594367598 ∧ code e605594367598 = 2804617623150 := by decide
theorem cert_e605594367598 : check e605594367598 [[],[]] .smaller = true := by decide
def e605594367606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605594367606 : Closed e605594367606 ∧ code e605594367606 = 2804617623158 := by decide
theorem cert_e605594367606 : check e605594367606 [[],[]] .smaller = true := by decide
def e605594367610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605594367610 : Closed e605594367610 ∧ code e605594367610 = 2804617623162 := by decide
theorem cert_e605594367610 : check e605594367610 [[],[]] .smaller = true := by decide
def e605594367798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605594367798 : Closed e605594367798 ∧ code e605594367798 = 2804617623350 := by decide
theorem cert_e605594367798 : check e605594367798 [[],[]] .smaller = true := by decide
def e605594367802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605594367802 : Closed e605594367802 ∧ code e605594367802 = 2804617623354 := by decide
theorem cert_e605594367802 : check e605594367802 [[],[]] .smaller = true := by decide
def e605594367898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605594367898 : Closed e605594367898 ∧ code e605594367898 = 2804617623450 := by decide
theorem cert_e605594367898 : check e605594367898 [[],[]] .three = true := by decide
def e605594368058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0))))))))
theorem wire_e605594368058 : Closed e605594368058 ∧ code e605594368058 = 2804617623610 := by decide
theorem cert_e605594368058 : check e605594368058 [[],[]] .smaller = true := by decide
def e605594368106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e605594368106 : Closed e605594368106 ∧ code e605594368106 = 2804617623658 := by decide
theorem cert_e605594368106 : check e605594368106 [[],[]] .smaller = true := by decide
def e605594368154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e605594368154 : Closed e605594368154 ∧ code e605594368154 = 2804617623706 := by decide
theorem cert_e605594368154 : check e605594368154 [[],[]] .smaller = true := by decide
def e605594368198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1)))))))))
theorem wire_e605594368198 : Closed e605594368198 ∧ code e605594368198 = 2804617623750 := by decide
theorem cert_e605594368198 : check e605594368198 [[],[]] .smaller = true := by decide
def e605594368394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605594368394 : Closed e605594368394 ∧ code e605594368394 = 2804617623946 := by decide
theorem cert_e605594368394 : check e605594368394 [[],[]] .smaller = true := by decide
def e605594368418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e605594368418 : Closed e605594368418 ∧ code e605594368418 = 2804617623970 := by decide
theorem cert_e605594368418 : check e605594368418 [[],[]] .smaller = true := by decide
def e605594368430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605594368430 : Closed e605594368430 ∧ code e605594368430 = 2804617623982 := by decide
theorem cert_e605594368430 : check e605594368430 [[],[]] .smaller = true := by decide
def e605594368438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e605594368438 : Closed e605594368438 ∧ code e605594368438 = 2804617623990 := by decide
theorem cert_e605594368438 : check e605594368438 [[],[]] .smaller = true := by decide
def e605594368442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605594368442 : Closed e605594368442 ∧ code e605594368442 = 2804617623994 := by decide
theorem cert_e605594368442 : check e605594368442 [[],[]] .smaller = true := by decide
def e605594368470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e605594368470 : Closed e605594368470 ∧ code e605594368470 = 2804617624022 := by decide
theorem cert_e605594368470 : check e605594368470 [[],[]] .smaller = true := by decide
def e605594368474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e605594368474 : Closed e605594368474 ∧ code e605594368474 = 2804617624026 := by decide
theorem cert_e605594368474 : check e605594368474 [[],[]] .smaller = true := by decide
def e605594368490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605594368490 : Closed e605594368490 ∧ code e605594368490 = 2804617624042 := by decide
theorem cert_e605594368490 : check e605594368490 [[],[]] .smaller = true := by decide
def e605594368526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2))))))))))
theorem wire_e605594368526 : Closed e605594368526 ∧ code e605594368526 = 2804617624078 := by decide
theorem cert_e605594368526 : check e605594368526 [[],[]] .smaller = true := by decide
def e605594368538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605594368538 : Closed e605594368538 ∧ code e605594368538 = 2804617624090 := by decide
theorem cert_e605594368538 : check e605594368538 [[],[]] .smaller = true := by decide
def e605594368610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605594368610 : Closed e605594368610 ∧ code e605594368610 = 2804617624162 := by decide
theorem cert_e605594368610 : check e605594368610 [[],[]] .smaller = true := by decide
def e605594368622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605594368622 : Closed e605594368622 ∧ code e605594368622 = 2804617624174 := by decide
theorem cert_e605594368622 : check e605594368622 [[],[]] .smaller = true := by decide
def e605594368630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605594368630 : Closed e605594368630 ∧ code e605594368630 = 2804617624182 := by decide
theorem cert_e605594368630 : check e605594368630 [[],[]] .smaller = true := by decide
def e605594368634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605594368634 : Closed e605594368634 ∧ code e605594368634 = 2804617624186 := by decide
theorem cert_e605594368634 : check e605594368634 [[],[]] .smaller = true := by decide
def e605594368822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605594368822 : Closed e605594368822 ∧ code e605594368822 = 2804617624374 := by decide
theorem cert_e605594368822 : check e605594368822 [[],[]] .smaller = true := by decide
def e605594368826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605594368826 : Closed e605594368826 ∧ code e605594368826 = 2804617624378 := by decide
theorem cert_e605594368826 : check e605594368826 [[],[]] .smaller = true := by decide
def e605594368922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605594368922 : Closed e605594368922 ∧ code e605594368922 = 2804617624474 := by decide
theorem cert_e605594368922 : check e605594368922 [[],[]] .smaller = true := by decide
def e605594368990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 3))))))))
theorem wire_e605594368990 : Closed e605594368990 ∧ code e605594368990 = 2804617624542 := by decide
theorem cert_e605594368990 : check e605594368990 [[],[]] .three = true := by decide
def e605594369238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605594369238 : Closed e605594369238 ∧ code e605594369238 = 2804617624790 := by decide
theorem cert_e605594369238 : check e605594369238 [[],[]] .smaller = true := by decide
def e605594369242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605594369242 : Closed e605594369242 ∧ code e605594369242 = 2804617624794 := by decide
theorem cert_e605594369242 : check e605594369242 [[],[]] .smaller = true := by decide
def e605594369258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605594369258 : Closed e605594369258 ∧ code e605594369258 = 2804617624810 := by decide
theorem cert_e605594369258 : check e605594369258 [[],[]] .smaller = true := by decide
def e605594369334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605594369334 : Closed e605594369334 ∧ code e605594369334 = 2804617624886 := by decide
theorem cert_e605594369334 : check e605594369334 [[],[]] .smaller = true := by decide
def e605594369338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605594369338 : Closed e605594369338 ∧ code e605594369338 = 2804617624890 := by decide
theorem cert_e605594369338 : check e605594369338 [[],[]] .smaller = true := by decide
def e605594369434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605594369434 : Closed e605594369434 ∧ code e605594369434 = 2804617624986 := by decide
theorem cert_e605594369434 : check e605594369434 [[],[]] .smaller = true := by decide
def e605594369642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605594369642 : Closed e605594369642 ∧ code e605594369642 = 2804617625194 := by decide
theorem cert_e605594369642 : check e605594369642 [[],[]] .three = true := by decide
def e605594369690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605594369690 : Closed e605594369690 ∧ code e605594369690 = 2804617625242 := by decide
theorem cert_e605594369690 : check e605594369690 [[],[]] .three = true := by decide
def e605594369758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 3))))))))
theorem wire_e605594369758 : Closed e605594369758 ∧ code e605594369758 = 2804617625310 := by decide
theorem cert_e605594369758 : check e605594369758 [[],[]] .three = true := by decide
def e605594369782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 3)) (.var 1))))))))
theorem wire_e605594369782 : Closed e605594369782 ∧ code e605594369782 = 2804617625334 := by decide
theorem cert_e605594369782 : check e605594369782 [[],[]] .three = true := by decide
def e605594371006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e605594371006 : Closed e605594371006 ∧ code e605594371006 = 2804617626558 := by decide
theorem cert_e605594371006 : check e605594371006 [[],[]] .three = true := by decide
def e605594371038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e605594371038 : Closed e605594371038 ∧ code e605594371038 = 2804617626590 := by decide
theorem cert_e605594371038 : check e605594371038 [[],[]] .smaller = true := by decide
def e605594371054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e605594371054 : Closed e605594371054 ∧ code e605594371054 = 2804617626606 := by decide
theorem cert_e605594371054 : check e605594371054 [[],[]] .smaller = true := by decide
def e605594371062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e605594371062 : Closed e605594371062 ∧ code e605594371062 = 2804617626614 := by decide
theorem cert_e605594371062 : check e605594371062 [[],[]] .three = true := by decide
def e605594372886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e605594372886 : Closed e605594372886 ∧ code e605594372886 = 2804617628438 := by decide
theorem cert_e605594372886 : check e605594372886 [[],[]] .smaller = true := by decide
def e605594372958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e605594372958 : Closed e605594372958 ∧ code e605594372958 = 2804617628510 := by decide
theorem cert_e605594372958 : check e605594372958 [[],[]] .three = true := by decide
def e605594372962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e605594372962 : Closed e605594372962 ∧ code e605594372962 = 2804617628514 := by decide
theorem cert_e605594372962 : check e605594372962 [[],[]] .smaller = true := by decide
def e605594372974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605594372974 : Closed e605594372974 ∧ code e605594372974 = 2804617628526 := by decide
theorem cert_e605594372974 : check e605594372974 [[],[]] .smaller = true := by decide
def e605594372982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605594372982 : Closed e605594372982 ∧ code e605594372982 = 2804617628534 := by decide
theorem cert_e605594372982 : check e605594372982 [[],[]] .smaller = true := by decide
def e605594372986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e605594372986 : Closed e605594372986 ∧ code e605594372986 = 2804617628538 := by decide
theorem cert_e605594372986 : check e605594372986 [[],[]] .three = true := by decide
def e605594373002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e605594373002 : Closed e605594373002 ∧ code e605594373002 = 2804617628554 := by decide
theorem cert_e605594373002 : check e605594373002 [[],[]] .smaller = true := by decide
def e605594373026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e605594373026 : Closed e605594373026 ∧ code e605594373026 = 2804617628578 := by decide
theorem cert_e605594373026 : check e605594373026 [[],[]] .smaller = true := by decide
def e605594373038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605594373038 : Closed e605594373038 ∧ code e605594373038 = 2804617628590 := by decide
theorem cert_e605594373038 : check e605594373038 [[],[]] .smaller = true := by decide
def e605594373046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1)))))))))
theorem wire_e605594373046 : Closed e605594373046 ∧ code e605594373046 = 2804617628598 := by decide
theorem cert_e605594373046 : check e605594373046 [[],[]] .smaller = true := by decide
def e605594373050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605594373050 : Closed e605594373050 ∧ code e605594373050 = 2804617628602 := by decide
theorem cert_e605594373050 : check e605594373050 [[],[]] .smaller = true := by decide
def e605594373078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605594373078 : Closed e605594373078 ∧ code e605594373078 = 2804617628630 := by decide
theorem cert_e605594373078 : check e605594373078 [[],[]] .smaller = true := by decide
def e605594373082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605594373082 : Closed e605594373082 ∧ code e605594373082 = 2804617628634 := by decide
theorem cert_e605594373082 : check e605594373082 [[],[]] .smaller = true := by decide
def e605594373098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e605594373098 : Closed e605594373098 ∧ code e605594373098 = 2804617628650 := by decide
theorem cert_e605594373098 : check e605594373098 [[],[]] .three = true := by decide
def e605594373150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e605594373150 : Closed e605594373150 ∧ code e605594373150 = 2804617628702 := by decide
theorem cert_e605594373150 : check e605594373150 [[],[]] .smaller = true := by decide
def e605594373342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e605594373342 : Closed e605594373342 ∧ code e605594373342 = 2804617628894 := by decide
theorem cert_e605594373342 : check e605594373342 [[],[]] .three = true := by decide
def e605594373346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e605594373346 : Closed e605594373346 ∧ code e605594373346 = 2804617628898 := by decide
theorem cert_e605594373346 : check e605594373346 [[],[]] .smaller = true := by decide
def e605594373358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605594373358 : Closed e605594373358 ∧ code e605594373358 = 2804617628910 := by decide
theorem cert_e605594373358 : check e605594373358 [[],[]] .smaller = true := by decide
def e605594373366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605594373366 : Closed e605594373366 ∧ code e605594373366 = 2804617628918 := by decide
theorem cert_e605594373366 : check e605594373366 [[],[]] .smaller = true := by decide
def e605594373370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e605594373370 : Closed e605594373370 ∧ code e605594373370 = 2804617628922 := by decide
theorem cert_e605594373370 : check e605594373370 [[],[]] .three = true := by decide
def e605594373646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e605594373646 : Closed e605594373646 ∧ code e605594373646 = 2804617629198 := by decide
theorem cert_e605594373646 : check e605594373646 [[],[]] .smaller = true := by decide
def e605594373658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e605594373658 : Closed e605594373658 ∧ code e605594373658 = 2804617629210 := by decide
theorem cert_e605594373658 : check e605594373658 [[],[]] .smaller = true := by decide
def e605594373730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e605594373730 : Closed e605594373730 ∧ code e605594373730 = 2804617629282 := by decide
theorem cert_e605594373730 : check e605594373730 [[],[]] .smaller = true := by decide
def e605594373742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605594373742 : Closed e605594373742 ∧ code e605594373742 = 2804617629294 := by decide
theorem cert_e605594373742 : check e605594373742 [[],[]] .smaller = true := by decide
def e605594373750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1))))))))))
theorem wire_e605594373750 : Closed e605594373750 ∧ code e605594373750 = 2804617629302 := by decide
theorem cert_e605594373750 : check e605594373750 [[],[]] .smaller = true := by decide
def e605594373754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605594373754 : Closed e605594373754 ∧ code e605594373754 = 2804617629306 := by decide
theorem cert_e605594373754 : check e605594373754 [[],[]] .smaller = true := by decide
def e605594373942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605594373942 : Closed e605594373942 ∧ code e605594373942 = 2804617629494 := by decide
theorem cert_e605594373942 : check e605594373942 [[],[]] .smaller = true := by decide
def e605594373946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605594373946 : Closed e605594373946 ∧ code e605594373946 = 2804617629498 := by decide
theorem cert_e605594373946 : check e605594373946 [[],[]] .smaller = true := by decide
def e605594374042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e605594374042 : Closed e605594374042 ∧ code e605594374042 = 2804617629594 := by decide
theorem cert_e605594374042 : check e605594374042 [[],[]] .three = true := by decide
def e605594378718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605594378718 : Closed e605594378718 ∧ code e605594378718 = 2804617634270 := by decide
theorem cert_e605594378718 : check e605594378718 [[],[]] .smaller = true := by decide
def e605594378742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605594378742 : Closed e605594378742 ∧ code e605594378742 = 2804617634294 := by decide
theorem cert_e605594378742 : check e605594378742 [[],[]] .smaller = true := by decide
def e605594379658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e605594379658 : Closed e605594379658 ∧ code e605594379658 = 2804617635210 := by decide
theorem cert_e605594379658 : check e605594379658 [[],[]] .smaller = true := by decide
def e605594379682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e605594379682 : Closed e605594379682 ∧ code e605594379682 = 2804617635234 := by decide
theorem cert_e605594379682 : check e605594379682 [[],[]] .smaller = true := by decide
def e605594379694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605594379694 : Closed e605594379694 ∧ code e605594379694 = 2804617635246 := by decide
theorem cert_e605594379694 : check e605594379694 [[],[]] .smaller = true := by decide
def e605594379702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605594379702 : Closed e605594379702 ∧ code e605594379702 = 2804617635254 := by decide
theorem cert_e605594379702 : check e605594379702 [[],[]] .smaller = true := by decide
def e605594379706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605594379706 : Closed e605594379706 ∧ code e605594379706 = 2804617635258 := by decide
theorem cert_e605594379706 : check e605594379706 [[],[]] .smaller = true := by decide
def e605594379734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605594379734 : Closed e605594379734 ∧ code e605594379734 = 2804617635286 := by decide
theorem cert_e605594379734 : check e605594379734 [[],[]] .smaller = true := by decide
def e605594379738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605594379738 : Closed e605594379738 ∧ code e605594379738 = 2804617635290 := by decide
theorem cert_e605594379738 : check e605594379738 [[],[]] .smaller = true := by decide
def e605594379754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605594379754 : Closed e605594379754 ∧ code e605594379754 = 2804617635306 := by decide
theorem cert_e605594379754 : check e605594379754 [[],[]] .smaller = true := by decide
def e605594379790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2)))))))))))
theorem wire_e605594379790 : Closed e605594379790 ∧ code e605594379790 = 2804617635342 := by decide
theorem cert_e605594379790 : check e605594379790 [[],[]] .smaller = true := by decide
def e605594379802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e605594379802 : Closed e605594379802 ∧ code e605594379802 = 2804617635354 := by decide
theorem cert_e605594379802 : check e605594379802 [[],[]] .smaller = true := by decide
def e605594379874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e605594379874 : Closed e605594379874 ∧ code e605594379874 = 2804617635426 := by decide
theorem cert_e605594379874 : check e605594379874 [[],[]] .smaller = true := by decide
def e605594379886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605594379886 : Closed e605594379886 ∧ code e605594379886 = 2804617635438 := by decide
theorem cert_e605594379886 : check e605594379886 [[],[]] .smaller = true := by decide
def e605594379894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605594379894 : Closed e605594379894 ∧ code e605594379894 = 2804617635446 := by decide
theorem cert_e605594379894 : check e605594379894 [[],[]] .smaller = true := by decide
def e605594379898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605594379898 : Closed e605594379898 ∧ code e605594379898 = 2804617635450 := by decide
theorem cert_e605594379898 : check e605594379898 [[],[]] .smaller = true := by decide
def e605594380086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605594380086 : Closed e605594380086 ∧ code e605594380086 = 2804617635638 := by decide
theorem cert_e605594380086 : check e605594380086 [[],[]] .smaller = true := by decide
def e605594380090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605594380090 : Closed e605594380090 ∧ code e605594380090 = 2804617635642 := by decide
theorem cert_e605594380090 : check e605594380090 [[],[]] .smaller = true := by decide
def e605594380186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605594380186 : Closed e605594380186 ∧ code e605594380186 = 2804617635738 := by decide
theorem cert_e605594380186 : check e605594380186 [[],[]] .smaller = true := by decide
end Blc.Floor41
