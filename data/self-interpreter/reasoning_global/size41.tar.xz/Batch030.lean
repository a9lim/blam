import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e565606133166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e565606133166 : Closed e565606133166 ∧ code e565606133166 = 2764629388718 := by decide
theorem cert_e565606133166 : check e565606133166 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606133178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e565606133178 : Closed e565606133178 ∧ code e565606133178 = 2764629388730 := by decide
theorem cert_e565606133178 : check e565606133178 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606133206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e565606133206 : Closed e565606133206 ∧ code e565606133206 = 2764629388758 := by decide
def e565606133210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e565606133210 : Closed e565606133210 ∧ code e565606133210 = 2764629388762 := by decide
theorem cert_e565606133210 : check e565606133210 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606133422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e565606133422 : Closed e565606133422 ∧ code e565606133422 = 2764629388974 := by decide
theorem cert_e565606133422 : check e565606133422 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e565606133434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e565606133434 : Closed e565606133434 ∧ code e565606133434 = 2764629388986 := by decide
def e565606133482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e565606133482 : Closed e565606133482 ∧ code e565606133482 = 2764629389034 := by decide
private def t_e565606133482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem cert_e565606133482 : ¬ IsSelfInterpreter e565606133482 :=
  wSource (t := t_e565606133482) (replay_sound (ps := []) (t := e565606133482) (by decide)) (by decide)
def e565606133590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e565606133590 : Closed e565606133590 ∧ code e565606133590 = 2764629389142 := by decide
theorem cert_e565606133590 : check e565606133590 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606133594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e565606133594 : Closed e565606133594 ∧ code e565606133594 = 2764629389146 := by decide
theorem cert_e565606133594 : check e565606133594 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606133610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e565606133610 : Closed e565606133610 ∧ code e565606133610 = 2764629389162 := by decide
private def t_e565606133610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem cert_e565606133610 : ¬ IsSelfInterpreter e565606133610 :=
  wSource (t := t_e565606133610) (replay_sound (ps := []) (t := e565606133610) (by decide)) (by decide)
def e565606134638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e565606134638 : Closed e565606134638 ∧ code e565606134638 = 2764629390190 := by decide
theorem cert_e565606134638 : check e565606134638 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e565606134646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e565606134646 : Closed e565606134646 ∧ code e565606134646 = 2764629390198 := by decide
theorem cert_e565606134646 : check e565606134646 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606134702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e565606134702 : Closed e565606134702 ∧ code e565606134702 = 2764629390254 := by decide
theorem cert_e565606134702 : check e565606134702 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606134714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e565606134714 : Closed e565606134714 ∧ code e565606134714 = 2764629390266 := by decide
theorem cert_e565606134714 : check e565606134714 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e565606134742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e565606134742 : Closed e565606134742 ∧ code e565606134742 = 2764629390294 := by decide
theorem cert_e565606134742 : check e565606134742 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606134746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e565606134746 : Closed e565606134746 ∧ code e565606134746 = 2764629390298 := by decide
theorem cert_e565606134746 : check e565606134746 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e565606135022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e565606135022 : Closed e565606135022 ∧ code e565606135022 = 2764629390574 := by decide
theorem cert_e565606135022 : check e565606135022 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606135030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e565606135030 : Closed e565606135030 ∧ code e565606135030 = 2764629390582 := by decide
theorem cert_e565606135030 : check e565606135030 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606135406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e565606135406 : Closed e565606135406 ∧ code e565606135406 = 2764629390958 := by decide
theorem cert_e565606135406 : check e565606135406 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606135418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e565606135418 : Closed e565606135418 ∧ code e565606135418 = 2764629390970 := by decide
theorem cert_e565606135418 : check e565606135418 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e565606135606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e565606135606 : Closed e565606135606 ∧ code e565606135606 = 2764629391158 := by decide
theorem cert_e565606135606 : check e565606135606 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606135610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e565606135610 : Closed e565606135610 ∧ code e565606135610 = 2764629391162 := by decide
theorem cert_e565606135610 : check e565606135610 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606136238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e565606136238 : Closed e565606136238 ∧ code e565606136238 = 2764629391790 := by decide
theorem cert_e565606136238 : check e565606136238 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606136250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e565606136250 : Closed e565606136250 ∧ code e565606136250 = 2764629391802 := by decide
theorem cert_e565606136250 : check e565606136250 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e565606136298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e565606136298 : Closed e565606136298 ∧ code e565606136298 = 2764629391850 := by decide
theorem cert_e565606136298 : check e565606136298 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606136430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e565606136430 : Closed e565606136430 ∧ code e565606136430 = 2764629391982 := by decide
theorem cert_e565606136430 : check e565606136430 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e565606136442 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e565606136442 : Closed e565606136442 ∧ code e565606136442 = 2764629391994 := by decide
theorem cert_e565606136442 : check e565606136442 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606136730 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e565606136730 : Closed e565606136730 ∧ code e565606136730 = 2764629392282 := by decide
private def t_e565606136730 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem cert_e565606136730 : ¬ IsSelfInterpreter e565606136730 :=
  wSource (t := t_e565606136730) (replay_sound (ps := []) (t := e565606136730) (by decide)) (by decide)
def e565606137046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e565606137046 : Closed e565606137046 ∧ code e565606137046 = 2764629392598 := by decide
theorem cert_e565606137046 : check e565606137046 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[],[.left],[.left,.left],[.left],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e565606137050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e565606137050 : Closed e565606137050 ∧ code e565606137050 = 2764629392602 := by decide
theorem cert_e565606137050 : check e565606137050 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606137066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e565606137066 : Closed e565606137066 ∧ code e565606137066 = 2764629392618 := by decide
def e565606137142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e565606137142 : Closed e565606137142 ∧ code e565606137142 = 2764629392694 := by decide
theorem cert_e565606137142 : check e565606137142 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606137146 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e565606137146 : Closed e565606137146 ∧ code e565606137146 = 2764629392698 := by decide
theorem cert_e565606137146 : check e565606137146 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e565606137242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e565606137242 : Closed e565606137242 ∧ code e565606137242 = 2764629392794 := by decide
private def t_e565606137242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem cert_e565606137242 : ¬ IsSelfInterpreter e565606137242 :=
  wSource (t := t_e565606137242) (replay_sound (ps := []) (t := e565606137242) (by decide)) (by decide)
def e565606138846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e565606138846 : Closed e565606138846 ∧ code e565606138846 = 2764629394398 := by decide
theorem cert_e565606138846 : check e565606138846 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left],[.left],[]] .identityHead = true := by decide
def e565606138862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e565606138862 : Closed e565606138862 ∧ code e565606138862 = 2764629394414 := by decide
theorem cert_e565606138862 : check e565606138862 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e565606140782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e565606140782 : Closed e565606140782 ∧ code e565606140782 = 2764629396334 := by decide
theorem cert_e565606140782 : check e565606140782 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e565606140790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e565606140790 : Closed e565606140790 ∧ code e565606140790 = 2764629396342 := by decide
theorem cert_e565606140790 : check e565606140790 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e565606140846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e565606140846 : Closed e565606140846 ∧ code e565606140846 = 2764629396398 := by decide
def e565606140858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e565606140858 : Closed e565606140858 ∧ code e565606140858 = 2764629396410 := by decide
def e565606140886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e565606140886 : Closed e565606140886 ∧ code e565606140886 = 2764629396438 := by decide
theorem cert_e565606140886 : check e565606140886 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606140890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e565606140890 : Closed e565606140890 ∧ code e565606140890 = 2764629396442 := by decide
def e565606141166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e565606141166 : Closed e565606141166 ∧ code e565606141166 = 2764629396718 := by decide
theorem cert_e565606141166 : check e565606141166 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e565606141174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e565606141174 : Closed e565606141174 ∧ code e565606141174 = 2764629396726 := by decide
theorem cert_e565606141174 : check e565606141174 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e565606141550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e565606141550 : Closed e565606141550 ∧ code e565606141550 = 2764629397102 := by decide
theorem cert_e565606141550 : check e565606141550 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606141562 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e565606141562 : Closed e565606141562 ∧ code e565606141562 = 2764629397114 := by decide
theorem cert_e565606141562 : check e565606141562 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[.left],[.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[],[],[.under],[.under]] .identityHead = true := by decide
def e565606141750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e565606141750 : Closed e565606141750 ∧ code e565606141750 = 2764629397302 := by decide
theorem cert_e565606141750 : check e565606141750 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e565606141754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e565606141754 : Closed e565606141754 ∧ code e565606141754 = 2764629397306 := by decide
def e565606146526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e565606146526 : Closed e565606146526 ∧ code e565606146526 = 2764629402078 := by decide
theorem cert_e565606146526 : check e565606146526 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e565606146550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e565606146550 : Closed e565606146550 ∧ code e565606146550 = 2764629402102 := by decide
theorem cert_e565606146550 : check e565606146550 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e565606147502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e565606147502 : Closed e565606147502 ∧ code e565606147502 = 2764629403054 := by decide
theorem cert_e565606147502 : check e565606147502 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e565606147514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e565606147514 : Closed e565606147514 ∧ code e565606147514 = 2764629403066 := by decide
theorem cert_e565606147514 : check e565606147514 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e565606147562 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e565606147562 : Closed e565606147562 ∧ code e565606147562 = 2764629403114 := by decide
theorem cert_e565606147562 : check e565606147562 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e565606147694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e565606147694 : Closed e565606147694 ∧ code e565606147694 = 2764629403246 := by decide
theorem cert_e565606147694 : check e565606147694 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e565606147706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e565606147706 : Closed e565606147706 ∧ code e565606147706 = 2764629403258 := by decide
theorem cert_e565606147706 : check e565606147706 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e565606147994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e565606147994 : Closed e565606147994 ∧ code e565606147994 = 2764629403546 := by decide
theorem cert_e565606147994 : check e565606147994 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e565606150382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e565606150382 : Closed e565606150382 ∧ code e565606150382 = 2764629405934 := by decide
theorem cert_e565606150382 : check e565606150382 [[],[.under],[.under],[.under],[.under,.under],[.under,.under]] .chain = true := by decide
def e565606150390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e565606150390 : Closed e565606150390 ∧ code e565606150390 = 2764629405942 := by decide
theorem cert_e565606150390 : check e565606150390 [[],[.under],[.under],[.under],[.under,.under],[.under,.under]] .chain = true := by decide
def e565606150870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e565606150870 : Closed e565606150870 ∧ code e565606150870 = 2764629406422 := by decide
theorem cert_e565606150870 : check e565606150870 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e565606150874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e565606150874 : Closed e565606150874 ∧ code e565606150874 = 2764629406426 := by decide
def e565606150890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e565606150890 : Closed e565606150890 ∧ code e565606150890 = 2764629406442 := by decide
def e565606150966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e565606150966 : Closed e565606150966 ∧ code e565606150966 = 2764629406518 := by decide
theorem cert_e565606150966 : check e565606150966 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.under,.under,.left],[.under,.under,.under,.left,.left,.left],[.under,.under,.under,.left,.left,.left,.left],[.under,.under,.under,.left,.left,.left],[.under,.under,.under,.left,.left,.left],[.under,.under,.under,.left,.left],[.under,.under,.under,.left,.left],[.under,.under,.under,.left,.left,.left],[.under,.under,.under,.left,.left],[.under,.under,.under,.left,.left],[.under,.under,.under,.left],[.under,.under,.under,.left],[.under,.under,.under,.left,.left,.left],[.under,.under,.under,.left,.left,.left,.left],[.under,.under,.under,.left,.left,.left],[.under,.under,.under,.left,.left],[.under,.under,.under,.left],[.under,.under,.under]] .identityHead = true := by decide
def e565606150970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e565606150970 : Closed e565606150970 ∧ code e565606150970 = 2764629406522 := by decide
def e565606151066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e565606151066 : Closed e565606151066 ∧ code e565606151066 = 2764629406618 := by decide
theorem cert_e565606151066 : check e565606151066 [[],[.under],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e565606288238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e565606288238 : Closed e565606288238 ∧ code e565606288238 = 2764629543790 := by decide
private def t_e565606288238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e565606288238 : ¬ IsSelfInterpreter e565606288238 :=
  wSource (t := t_e565606288238) (replay_sound (ps := []) (t := e565606288238) (by decide)) (by decide)
def e565606288246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e565606288246 : Closed e565606288246 ∧ code e565606288246 = 2764629543798 := by decide
private def t_e565606288246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e565606288246 : ¬ IsSelfInterpreter e565606288246 :=
  wSource (t := t_e565606288246) (replay_sound (ps := []) (t := e565606288246) (by decide)) (by decide)
def e565606288302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e565606288302 : Closed e565606288302 ∧ code e565606288302 = 2764629543854 := by decide
private def t_e565606288302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e565606288302 : ¬ IsSelfInterpreter e565606288302 :=
  wSource (t := t_e565606288302) (replay_sound (ps := []) (t := e565606288302) (by decide)) (by decide)
def e565606288314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e565606288314 : Closed e565606288314 ∧ code e565606288314 = 2764629543866 := by decide
private def t_e565606288314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e565606288314 : ¬ IsSelfInterpreter e565606288314 :=
  wSource (t := t_e565606288314) (replay_sound (ps := []) (t := e565606288314) (by decide)) (by decide)
def e565606288342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e565606288342 : Closed e565606288342 ∧ code e565606288342 = 2764629543894 := by decide
private def t_e565606288342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e565606288342 : ¬ IsSelfInterpreter e565606288342 :=
  wSource (t := t_e565606288342) (replay_sound (ps := []) (t := e565606288342) (by decide)) (by decide)
def e565606288346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e565606288346 : Closed e565606288346 ∧ code e565606288346 = 2764629543898 := by decide
private def t_e565606288346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e565606288346 : ¬ IsSelfInterpreter e565606288346 :=
  wSource (t := t_e565606288346) (replay_sound (ps := []) (t := e565606288346) (by decide)) (by decide)
def e565606288622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e565606288622 : Closed e565606288622 ∧ code e565606288622 = 2764629544174 := by decide
private def t_e565606288622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e565606288622 : ¬ IsSelfInterpreter e565606288622 :=
  wSource (t := t_e565606288622) (replay_sound (ps := []) (t := e565606288622) (by decide)) (by decide)
def e565606288630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e565606288630 : Closed e565606288630 ∧ code e565606288630 = 2764629544182 := by decide
private def t_e565606288630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e565606288630 : ¬ IsSelfInterpreter e565606288630 :=
  wSource (t := t_e565606288630) (replay_sound (ps := []) (t := e565606288630) (by decide)) (by decide)
def e565606289006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e565606289006 : Closed e565606289006 ∧ code e565606289006 = 2764629544558 := by decide
private def t_e565606289006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e565606289006 : ¬ IsSelfInterpreter e565606289006 :=
  wSource (t := t_e565606289006) (replay_sound (ps := []) (t := e565606289006) (by decide)) (by decide)
def e565606289018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e565606289018 : Closed e565606289018 ∧ code e565606289018 = 2764629544570 := by decide
private def t_e565606289018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e565606289018 : ¬ IsSelfInterpreter e565606289018 :=
  wSource (t := t_e565606289018) (replay_sound (ps := []) (t := e565606289018) (by decide)) (by decide)
def e565606289206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e565606289206 : Closed e565606289206 ∧ code e565606289206 = 2764629544758 := by decide
private def t_e565606289206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e565606289206 : ¬ IsSelfInterpreter e565606289206 :=
  wSource (t := t_e565606289206) (replay_sound (ps := []) (t := e565606289206) (by decide)) (by decide)
def e565606289210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e565606289210 : Closed e565606289210 ∧ code e565606289210 = 2764629544762 := by decide
private def t_e565606289210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e565606289210 : ¬ IsSelfInterpreter e565606289210 :=
  wSource (t := t_e565606289210) (replay_sound (ps := []) (t := e565606289210) (by decide)) (by decide)
def e565606878062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e565606878062 : Closed e565606878062 ∧ code e565606878062 = 2764630133614 := by decide
def e565606878070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e565606878070 : Closed e565606878070 ∧ code e565606878070 = 2764630133622 := by decide
def e565606878126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e565606878126 : Closed e565606878126 ∧ code e565606878126 = 2764630133678 := by decide
def e565606878138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e565606878138 : Closed e565606878138 ∧ code e565606878138 = 2764630133690 := by decide
private def t_e565606878138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e565606878138 : ¬ IsSelfInterpreter e565606878138 :=
  wSource (t := t_e565606878138) (replay_sound (ps := []) (t := e565606878138) (by decide)) (by decide)
def e565606878166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e565606878166 : Closed e565606878166 ∧ code e565606878166 = 2764630133718 := by decide
def e565606878170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e565606878170 : Closed e565606878170 ∧ code e565606878170 = 2764630133722 := by decide
private def t_e565606878170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e565606878170 : ¬ IsSelfInterpreter e565606878170 :=
  wSource (t := t_e565606878170) (replay_sound (ps := []) (t := e565606878170) (by decide)) (by decide)
def e565606878446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e565606878446 : Closed e565606878446 ∧ code e565606878446 = 2764630133998 := by decide
def e565606878454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e565606878454 : Closed e565606878454 ∧ code e565606878454 = 2764630134006 := by decide
def e565606878830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e565606878830 : Closed e565606878830 ∧ code e565606878830 = 2764630134382 := by decide
def e565606878842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e565606878842 : Closed e565606878842 ∧ code e565606878842 = 2764630134394 := by decide
def e565606879030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e565606879030 : Closed e565606879030 ∧ code e565606879030 = 2764630134582 := by decide
def e565606879034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e565606879034 : Closed e565606879034 ∧ code e565606879034 = 2764630134586 := by decide
def e595938699802 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e595938699802 : Closed e595938699802 ∧ code e595938699802 = 2794961955354 := by decide
theorem cert_e595938699802 : check e595938699802 [[]] .width = true := by decide
def e595938732570 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e595938732570 : Closed e595938732570 ∧ code e595938732570 = 2794961988122 := by decide
theorem cert_e595938732570 : check e595938732570 [[]] .width = true := by decide
def e595938961946 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e595938961946 : Closed e595938961946 ∧ code e595938961946 = 2794962217498 := by decide
theorem cert_e595938961946 : check e595938961946 [[]] .width = true := by decide
def e595939011098 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e595939011098 : Closed e595939011098 ∧ code e595939011098 = 2794962266650 := by decide
private def t_e595939011098 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e595939011098 : ¬ IsSelfInterpreter e595939011098 :=
  wSource (t := t_e595939011098) (replay_sound (ps := []) (t := e595939011098) (by decide)) (by decide)
def e595939125786 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e595939125786 : Closed e595939125786 ∧ code e595939125786 = 2794962381338 := by decide
theorem cert_e595939125786 : check e595939125786 [[]] .width = true := by decide
def e595939142170 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e595939142170 : Closed e595939142170 ∧ code e595939142170 = 2794962397722 := by decide
private def t_e595939142170 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e595939142170 : ¬ IsSelfInterpreter e595939142170 :=
  wSource (t := t_e595939142170) (replay_sound (ps := []) (t := e595939142170) (by decide)) (by decide)
def e595940272666 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e595940272666 : Closed e595940272666 ∧ code e595940272666 = 2794963528218 := by decide
theorem cert_e595940272666 : check e595940272666 [[]] .width = true := by decide
def e595940305434 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e595940305434 : Closed e595940305434 ∧ code e595940305434 = 2794963560986 := by decide
theorem cert_e595940305434 : check e595940305434 [[]] .width = true := by decide
def e595941845530 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e595941845530 : Closed e595941845530 ∧ code e595941845530 = 2794965101082 := by decide
theorem cert_e595941845530 : check e595941845530 [[]] .width = true := by decide
def e595941894682 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e595941894682 : Closed e595941894682 ∧ code e595941894682 = 2794965150234 := by decide
theorem cert_e595941894682 : check e595941894682 [[]] .width = true := by decide
def e595942664730 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e595942664730 : Closed e595942664730 ∧ code e595942664730 = 2794965920282 := by decide
theorem cert_e595942664730 : check e595942664730 [[]] .width = true := by decide
def e595942681114 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e595942681114 : Closed e595942681114 ∧ code e595942681114 = 2794965936666 := by decide
theorem cert_e595942681114 : check e595942681114 [[]] .width = true := by decide
def e596198144538 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596198144538 : Closed e596198144538 ∧ code e596198144538 = 2795221400090 := by decide
private def t_e596198144538 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596198144538 : ¬ IsSelfInterpreter e596198144538 :=
  wSource (t := t_e596198144538) (replay_sound (ps := []) (t := e596198144538) (by decide)) (by decide)
def e596198152730 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596198152730 : Closed e596198152730 ∧ code e596198152730 = 2795221408282 := by decide
private def t_e596198152730 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596198152730 : ¬ IsSelfInterpreter e596198152730 :=
  wSource (t := t_e596198152730) (replay_sound (ps := []) (t := e596198152730) (by decide)) (by decide)
def e596198210074 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596198210074 : Closed e596198210074 ∧ code e596198210074 = 2795221465626 := by decide
private def t_e596198210074 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596198210074 : ¬ IsSelfInterpreter e596198210074 :=
  wSource (t := t_e596198210074) (replay_sound (ps := []) (t := e596198210074) (by decide)) (by decide)
def e596198222362 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596198222362 : Closed e596198222362 ∧ code e596198222362 = 2795221477914 := by decide
private def t_e596198222362 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596198222362 : ¬ IsSelfInterpreter e596198222362 :=
  wSource (t := t_e596198222362) (replay_sound (ps := []) (t := e596198222362) (by decide)) (by decide)
def e596198251034 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596198251034 : Closed e596198251034 ∧ code e596198251034 = 2795221506586 := by decide
private def t_e596198251034 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596198251034 : ¬ IsSelfInterpreter e596198251034 :=
  wSource (t := t_e596198251034) (replay_sound (ps := []) (t := e596198251034) (by decide)) (by decide)
def e596198255130 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596198255130 : Closed e596198255130 ∧ code e596198255130 = 2795221510682 := by decide
private def t_e596198255130 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596198255130 : ¬ IsSelfInterpreter e596198255130 :=
  wSource (t := t_e596198255130) (replay_sound (ps := []) (t := e596198255130) (by decide)) (by decide)
def e596198537754 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596198537754 : Closed e596198537754 ∧ code e596198537754 = 2795221793306 := by decide
private def t_e596198537754 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596198537754 : ¬ IsSelfInterpreter e596198537754 :=
  wSource (t := t_e596198537754) (replay_sound (ps := []) (t := e596198537754) (by decide)) (by decide)
def e596198545946 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596198545946 : Closed e596198545946 ∧ code e596198545946 = 2795221801498 := by decide
private def t_e596198545946 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596198545946 : ¬ IsSelfInterpreter e596198545946 :=
  wSource (t := t_e596198545946) (replay_sound (ps := []) (t := e596198545946) (by decide)) (by decide)
def e596198930970 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596198930970 : Closed e596198930970 ∧ code e596198930970 = 2795222186522 := by decide
private def t_e596198930970 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596198930970 : ¬ IsSelfInterpreter e596198930970 :=
  wSource (t := t_e596198930970) (replay_sound (ps := []) (t := e596198930970) (by decide)) (by decide)
def e596198943258 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596198943258 : Closed e596198943258 ∧ code e596198943258 = 2795222198810 := by decide
private def t_e596198943258 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596198943258 : ¬ IsSelfInterpreter e596198943258 :=
  wSource (t := t_e596198943258) (replay_sound (ps := []) (t := e596198943258) (by decide)) (by decide)
def e596199135770 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596199135770 : Closed e596199135770 ∧ code e596199135770 = 2795222391322 := by decide
private def t_e596199135770 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596199135770 : ¬ IsSelfInterpreter e596199135770 :=
  wSource (t := t_e596199135770) (replay_sound (ps := []) (t := e596199135770) (by decide)) (by decide)
def e596199139866 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596199139866 : Closed e596199139866 ∧ code e596199139866 = 2795222395418 := by decide
private def t_e596199139866 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596199139866 : ¬ IsSelfInterpreter e596199139866 :=
  wSource (t := t_e596199139866) (replay_sound (ps := []) (t := e596199139866) (by decide)) (by decide)
def e596263005722 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596263005722 : Closed e596263005722 ∧ code e596263005722 = 2795286261274 := by decide
private def t_e596263005722 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596263005722 : ¬ IsSelfInterpreter e596263005722 :=
  wSource (t := t_e596263005722) (replay_sound (ps := []) (t := e596263005722) (by decide)) (by decide)
def e596263007770 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596263007770 : Closed e596263007770 ∧ code e596263007770 = 2795286263322 := by decide
private def t_e596263007770 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596263007770 : ¬ IsSelfInterpreter e596263007770 :=
  wSource (t := t_e596263007770) (replay_sound (ps := []) (t := e596263007770) (by decide)) (by decide)
def e596263022106 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596263022106 : Closed e596263022106 ∧ code e596263022106 = 2795286277658 := by decide
private def t_e596263022106 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596263022106 : ¬ IsSelfInterpreter e596263022106 :=
  wSource (t := t_e596263022106) (replay_sound (ps := []) (t := e596263022106) (by decide)) (by decide)
def e596263025178 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596263025178 : Closed e596263025178 ∧ code e596263025178 = 2795286280730 := by decide
private def t_e596263025178 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596263025178 : ¬ IsSelfInterpreter e596263025178 :=
  wSource (t := t_e596263025178) (replay_sound (ps := []) (t := e596263025178) (by decide)) (by decide)
def e596263032346 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596263032346 : Closed e596263032346 ∧ code e596263032346 = 2795286287898 := by decide
private def t_e596263032346 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596263032346 : ¬ IsSelfInterpreter e596263032346 :=
  wSource (t := t_e596263032346) (replay_sound (ps := []) (t := e596263032346) (by decide)) (by decide)
def e596263033370 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596263033370 : Closed e596263033370 ∧ code e596263033370 = 2795286288922 := by decide
private def t_e596263033370 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596263033370 : ¬ IsSelfInterpreter e596263033370 :=
  wSource (t := t_e596263033370) (replay_sound (ps := []) (t := e596263033370) (by decide)) (by decide)
def e596263104026 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596263104026 : Closed e596263104026 ∧ code e596263104026 = 2795286359578 := by decide
private def t_e596263104026 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596263104026 : ¬ IsSelfInterpreter e596263104026 :=
  wSource (t := t_e596263104026) (replay_sound (ps := []) (t := e596263104026) (by decide)) (by decide)
def e596263106074 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596263106074 : Closed e596263106074 ∧ code e596263106074 = 2795286361626 := by decide
private def t_e596263106074 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596263106074 : ¬ IsSelfInterpreter e596263106074 :=
  wSource (t := t_e596263106074) (replay_sound (ps := []) (t := e596263106074) (by decide)) (by decide)
def e596263202330 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596263202330 : Closed e596263202330 ∧ code e596263202330 = 2795286457882 := by decide
private def t_e596263202330 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596263202330 : ¬ IsSelfInterpreter e596263202330 :=
  wSource (t := t_e596263202330) (replay_sound (ps := []) (t := e596263202330) (by decide)) (by decide)
def e596263205402 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596263205402 : Closed e596263205402 ∧ code e596263205402 = 2795286460954 := by decide
private def t_e596263205402 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596263205402 : ¬ IsSelfInterpreter e596263205402 :=
  wSource (t := t_e596263205402) (replay_sound (ps := []) (t := e596263205402) (by decide)) (by decide)
def e596263253530 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596263253530 : Closed e596263253530 ∧ code e596263253530 = 2795286509082 := by decide
private def t_e596263253530 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596263253530 : ¬ IsSelfInterpreter e596263253530 :=
  wSource (t := t_e596263253530) (replay_sound (ps := []) (t := e596263253530) (by decide)) (by decide)
def e596263254554 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e596263254554 : Closed e596263254554 ∧ code e596263254554 = 2795286510106 := by decide
private def t_e596263254554 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e596263254554 : ¬ IsSelfInterpreter e596263254554 :=
  wSource (t := t_e596263254554) (replay_sound (ps := []) (t := e596263254554) (by decide)) (by decide)
def e596279078254 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e596279078254 : Closed e596279078254 ∧ code e596279078254 = 2795302333806 := by decide
def e596279078262 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e596279078262 : Closed e596279078262 ∧ code e596279078262 = 2795302333814 := by decide
def e596279078318 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e596279078318 : Closed e596279078318 ∧ code e596279078318 = 2795302333870 := by decide
def e596279078330 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e596279078330 : Closed e596279078330 ∧ code e596279078330 = 2795302333882 := by decide
def e596279078358 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e596279078358 : Closed e596279078358 ∧ code e596279078358 = 2795302333910 := by decide
def e596279078362 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e596279078362 : Closed e596279078362 ∧ code e596279078362 = 2795302333914 := by decide
def e596279078574 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e596279078574 : Closed e596279078574 ∧ code e596279078574 = 2795302334126 := by decide
def e596279078586 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e596279078586 : Closed e596279078586 ∧ code e596279078586 = 2795302334138 := by decide
def e596279078634 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e596279078634 : Closed e596279078634 ∧ code e596279078634 = 2795302334186 := by decide
def e596279078742 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e596279078742 : Closed e596279078742 ∧ code e596279078742 = 2795302334294 := by decide
def e596279078746 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e596279078746 : Closed e596279078746 ∧ code e596279078746 = 2795302334298 := by decide
def e596279078762 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e596279078762 : Closed e596279078762 ∧ code e596279078762 = 2795302334314 := by decide
def e596279079790 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e596279079790 : Closed e596279079790 ∧ code e596279079790 = 2795302335342 := by decide
theorem cert_e596279079790 : check e596279079790 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e596279079798 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e596279079798 : Closed e596279079798 ∧ code e596279079798 = 2795302335350 := by decide
theorem cert_e596279079798 : check e596279079798 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e596279079854 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e596279079854 : Closed e596279079854 ∧ code e596279079854 = 2795302335406 := by decide
theorem cert_e596279079854 : check e596279079854 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e596279079866 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e596279079866 : Closed e596279079866 ∧ code e596279079866 = 2795302335418 := by decide
theorem cert_e596279079866 : check e596279079866 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e596279079894 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e596279079894 : Closed e596279079894 ∧ code e596279079894 = 2795302335446 := by decide
theorem cert_e596279079894 : check e596279079894 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e596279079898 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e596279079898 : Closed e596279079898 ∧ code e596279079898 = 2795302335450 := by decide
theorem cert_e596279079898 : check e596279079898 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e596279080174 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e596279080174 : Closed e596279080174 ∧ code e596279080174 = 2795302335726 := by decide
theorem cert_e596279080174 : check e596279080174 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e596279080182 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e596279080182 : Closed e596279080182 ∧ code e596279080182 = 2795302335734 := by decide
theorem cert_e596279080182 : check e596279080182 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e596279080558 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e596279080558 : Closed e596279080558 ∧ code e596279080558 = 2795302336110 := by decide
theorem cert_e596279080558 : check e596279080558 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e596279080570 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e596279080570 : Closed e596279080570 ∧ code e596279080570 = 2795302336122 := by decide
theorem cert_e596279080570 : check e596279080570 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e596279080758 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e596279080758 : Closed e596279080758 ∧ code e596279080758 = 2795302336310 := by decide
theorem cert_e596279080758 : check e596279080758 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e596279080762 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e596279080762 : Closed e596279080762 ∧ code e596279080762 = 2795302336314 := by decide
theorem cert_e596279080762 : check e596279080762 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e596279081390 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e596279081390 : Closed e596279081390 ∧ code e596279081390 = 2795302336942 := by decide
theorem cert_e596279081390 : check e596279081390 [[],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e596279081402 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e596279081402 : Closed e596279081402 ∧ code e596279081402 = 2795302336954 := by decide
theorem cert_e596279081402 : checkPay e596279081402 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.right]] = true := by decide
def e596279081450 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e596279081450 : Closed e596279081450 ∧ code e596279081450 = 2795302337002 := by decide
theorem cert_e596279081450 : checkPay e596279081450 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left,.right],[.left,.right,.under,.under,.left,.right]] = true := by decide
def e596279081582 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e596279081582 : Closed e596279081582 ∧ code e596279081582 = 2795302337134 := by decide
theorem cert_e596279081582 : check e596279081582 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e596279081594 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e596279081594 : Closed e596279081594 ∧ code e596279081594 = 2795302337146 := by decide
theorem cert_e596279081594 : check e596279081594 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e596279081882 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e596279081882 : Closed e596279081882 ∧ code e596279081882 = 2795302337434 := by decide
theorem cert_e596279081882 : check e596279081882 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e596279082198 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e596279082198 : Closed e596279082198 ∧ code e596279082198 = 2795302337750 := by decide
theorem cert_e596279082198 : check e596279082198 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e596279082202 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e596279082202 : Closed e596279082202 ∧ code e596279082202 = 2795302337754 := by decide
theorem cert_e596279082202 : check e596279082202 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e596279082218 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e596279082218 : Closed e596279082218 ∧ code e596279082218 = 2795302337770 := by decide
theorem cert_e596279082218 : check e596279082218 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e596279082294 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e596279082294 : Closed e596279082294 ∧ code e596279082294 = 2795302337846 := by decide
theorem cert_e596279082294 : checkPay e596279082294 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e596279082298 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e596279082298 : Closed e596279082298 ∧ code e596279082298 = 2795302337850 := by decide
theorem cert_e596279082298 : checkPay e596279082298 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e596279082394 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e596279082394 : Closed e596279082394 ∧ code e596279082394 = 2795302337946 := by decide
theorem cert_e596279082394 : check e596279082394 [[],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
end Blc.Floor41
