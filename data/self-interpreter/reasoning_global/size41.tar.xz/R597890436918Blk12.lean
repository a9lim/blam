import R597890436918Data
namespace Certgen.R597890436918
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl144 : FloorIndex.rangeOK validState 144 12 = true := by decide +kernel
theorem bl156 : FloorIndex.rangeOK validState 156 12 = true := by decide +kernel
theorem bl168 : FloorIndex.rangeOK validState 168 12 = true := by decide +kernel
theorem bl180 : FloorIndex.rangeOK validState 180 12 = true := by decide +kernel
theorem bl192 : FloorIndex.rangeOK validState 192 12 = true := by decide +kernel
theorem bl204 : FloorIndex.rangeOK validState 204 12 = true := by decide +kernel
end Certgen.R597890436918
