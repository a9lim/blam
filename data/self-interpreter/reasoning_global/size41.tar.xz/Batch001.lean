import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e149619308342 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e149619308342 : Closed e149619308342 ∧ code e149619308342 = 2348642563894 := by decide
theorem cert_e149619308342 : check e149619308342 [[.under],[.under,.left]] .chain = true := by decide
def e149619308346 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e149619308346 : Closed e149619308346 ∧ code e149619308346 = 2348642563898 := by decide
theorem cert_e149619308346 : check e149619308346 [[.under],[.under,.left]] .chain = true := by decide
def e149619308982 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e149619308982 : Closed e149619308982 ∧ code e149619308982 = 2348642564534 := by decide
theorem cert_e149619308982 : check e149619308982 [[.under],[.under,.left]] .chain = true := by decide
def e149619309014 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e149619309014 : Closed e149619309014 ∧ code e149619309014 = 2348642564566 := by decide
theorem cert_e149619309014 : check e149619309014 [[.under],[.under,.left]] .chain = true := by decide
def e149619309018 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e149619309018 : Closed e149619309018 ∧ code e149619309018 = 2348642564570 := by decide
theorem cert_e149619309018 : check e149619309018 [[.under],[.under,.left]] .chain = true := by decide
def e149619309174 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e149619309174 : Closed e149619309174 ∧ code e149619309174 = 2348642564726 := by decide
theorem cert_e149619309174 : check e149619309174 [[.under],[.under,.left]] .chain = true := by decide
def e149619309366 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e149619309366 : Closed e149619309366 ∧ code e149619309366 = 2348642564918 := by decide
theorem cert_e149619309366 : check e149619309366 [[.under],[.under,.left]] .chain = true := by decide
def e149619309370 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e149619309370 : Closed e149619309370 ∧ code e149619309370 = 2348642564922 := by decide
theorem cert_e149619309370 : check e149619309370 [[.under],[.under,.left]] .chain = true := by decide
def e149619316590 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e149619316590 : Closed e149619316590 ∧ code e149619316590 = 2348642572142 := by decide
theorem cert_e149619316590 : check e149619316590 [[.under],[.under,.left]] .chain = true := by decide
def e149619316598 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e149619316598 : Closed e149619316598 ∧ code e149619316598 = 2348642572150 := by decide
theorem cert_e149619316598 : check e149619316598 [[.under],[.under,.left]] .chain = true := by decide
def e149619316662 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e149619316662 : Closed e149619316662 ∧ code e149619316662 = 2348642572214 := by decide
theorem cert_e149619316662 : check e149619316662 [[.under],[.under,.left]] .chain = true := by decide
def e149619317998 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e149619317998 : Closed e149619317998 ∧ code e149619317998 = 2348642573550 := by decide
theorem cert_e149619317998 : check e149619317998 [[.under],[.under,.left]] .chain = true := by decide
def e149619318006 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e149619318006 : Closed e149619318006 ∧ code e149619318006 = 2348642573558 := by decide
theorem cert_e149619318006 : check e149619318006 [[.under],[.under,.left]] .chain = true := by decide
def e149619318390 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e149619318390 : Closed e149619318390 ∧ code e149619318390 = 2348642573942 := by decide
theorem cert_e149619318390 : check e149619318390 [[.under],[.under,.left]] .chain = true := by decide
def e149619329902 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e149619329902 : Closed e149619329902 ∧ code e149619329902 = 2348642585454 := by decide
theorem cert_e149619329902 : check e149619329902 [[.under],[.under,.left]] .chain = true := by decide
def e149619329910 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e149619329910 : Closed e149619329910 ∧ code e149619329910 = 2348642585462 := by decide
theorem cert_e149619329910 : check e149619329910 [[.under],[.under,.left]] .chain = true := by decide
def e149619329966 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e149619329966 : Closed e149619329966 ∧ code e149619329966 = 2348642585518 := by decide
theorem cert_e149619329966 : check e149619329966 [[.under],[.under,.left]] .chain = true := by decide
def e149619329978 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e149619329978 : Closed e149619329978 ∧ code e149619329978 = 2348642585530 := by decide
theorem cert_e149619329978 : check e149619329978 [[.under],[.under,.left]] .chain = true := by decide
def e149619330006 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e149619330006 : Closed e149619330006 ∧ code e149619330006 = 2348642585558 := by decide
theorem cert_e149619330006 : check e149619330006 [[.under],[.under,.left]] .chain = true := by decide
def e149619330010 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e149619330010 : Closed e149619330010 ∧ code e149619330010 = 2348642585562 := by decide
theorem cert_e149619330010 : check e149619330010 [[.under],[.under,.left]] .chain = true := by decide
def e149619330286 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e149619330286 : Closed e149619330286 ∧ code e149619330286 = 2348642585838 := by decide
theorem cert_e149619330286 : check e149619330286 [[.under],[.under,.left]] .chain = true := by decide
def e149619330294 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e149619330294 : Closed e149619330294 ∧ code e149619330294 = 2348642585846 := by decide
theorem cert_e149619330294 : check e149619330294 [[.under],[.under,.left]] .chain = true := by decide
def e149619330670 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e149619330670 : Closed e149619330670 ∧ code e149619330670 = 2348642586222 := by decide
theorem cert_e149619330670 : check e149619330670 [[.under],[.under,.left]] .chain = true := by decide
def e149619330682 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e149619330682 : Closed e149619330682 ∧ code e149619330682 = 2348642586234 := by decide
theorem cert_e149619330682 : check e149619330682 [[.under],[.under,.left]] .chain = true := by decide
def e149619330870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e149619330870 : Closed e149619330870 ∧ code e149619330870 = 2348642586422 := by decide
theorem cert_e149619330870 : check e149619330870 [[.under],[.under,.left]] .chain = true := by decide
def e149619330874 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e149619330874 : Closed e149619330874 ∧ code e149619330874 = 2348642586426 := by decide
theorem cert_e149619330874 : check e149619330874 [[.under],[.under,.left]] .chain = true := by decide
def e149619336630 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e149619336630 : Closed e149619336630 ∧ code e149619336630 = 2348642592182 := by decide
theorem cert_e149619336630 : check e149619336630 [[.under],[.under,.left]] .chain = true := by decide
def e149619336662 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e149619336662 : Closed e149619336662 ∧ code e149619336662 = 2348642592214 := by decide
theorem cert_e149619336662 : check e149619336662 [[.under],[.under,.left]] .chain = true := by decide
def e149619336666 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e149619336666 : Closed e149619336666 ∧ code e149619336666 = 2348642592218 := by decide
theorem cert_e149619336666 : check e149619336666 [[.under],[.under,.left]] .chain = true := by decide
def e149619336822 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e149619336822 : Closed e149619336822 ∧ code e149619336822 = 2348642592374 := by decide
theorem cert_e149619336822 : check e149619336822 [[.under],[.under,.left]] .chain = true := by decide
def e149619337014 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e149619337014 : Closed e149619337014 ∧ code e149619337014 = 2348642592566 := by decide
theorem cert_e149619337014 : check e149619337014 [[.under],[.under,.left]] .chain = true := by decide
def e149619337018 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e149619337018 : Closed e149619337018 ∧ code e149619337018 = 2348642592570 := by decide
theorem cert_e149619337018 : check e149619337018 [[.under],[.under,.left]] .chain = true := by decide
def e149619673966 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e149619673966 : Closed e149619673966 ∧ code e149619673966 = 2348642929518 := by decide
theorem cert_e149619673966 : check e149619673966 [[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e149619673974 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e149619673974 : Closed e149619673974 ∧ code e149619673974 = 2348642929526 := by decide
private def t_e149619673974 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e149619673974 : ¬ IsSelfInterpreter e149619673974 :=
  wSource (t := t_e149619673974) (replay_sound (ps := []) (t := e149619673974) (by decide)) (by decide)
def e149619674030 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e149619674030 : Closed e149619674030 ∧ code e149619674030 = 2348642929582 := by decide
theorem cert_e149619674030 : checkPay e149619674030 [[.left],[.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left]] = true := by decide
def e149619674042 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e149619674042 : Closed e149619674042 ∧ code e149619674042 = 2348642929594 := by decide
theorem cert_e149619674042 : checkPay e149619674042 [[.left],[.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e149619674070 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e149619674070 : Closed e149619674070 ∧ code e149619674070 = 2348642929622 := by decide
private def t_e149619674070 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e149619674070 : ¬ IsSelfInterpreter e149619674070 :=
  wSource (t := t_e149619674070) (replay_sound (ps := []) (t := e149619674070) (by decide)) (by decide)
def e149619674074 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e149619674074 : Closed e149619674074 ∧ code e149619674074 = 2348642929626 := by decide
theorem cert_e149619674074 : check e149619674074 [[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e149619674350 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e149619674350 : Closed e149619674350 ∧ code e149619674350 = 2348642929902 := by decide
theorem cert_e149619674350 : checkPay e149619674350 [[.left],[.left],[.left,.left],[.left],[.left],[],[],[]] 0 [] = true := by decide
def e149619674358 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e149619674358 : Closed e149619674358 ∧ code e149619674358 = 2348642929910 := by decide
theorem cert_e149619674358 : check e149619674358 [[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e149619674734 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e149619674734 : Closed e149619674734 ∧ code e149619674734 = 2348642930286 := by decide
theorem cert_e149619674734 : check e149619674734 [[.under],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e149619674746 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e149619674746 : Closed e149619674746 ∧ code e149619674746 = 2348642930298 := by decide
theorem cert_e149619674746 : check e149619674746 [[.under],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e149619674934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e149619674934 : Closed e149619674934 ∧ code e149619674934 = 2348642930486 := by decide
theorem cert_e149619674934 : check e149619674934 [[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e149619674938 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e149619674938 : Closed e149619674938 ∧ code e149619674938 = 2348642930490 := by decide
theorem cert_e149619674938 : check e149619674938 [[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e149686410094 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e149686410094 : Closed e149686410094 ∧ code e149686410094 = 2348709665646 := by decide
theorem cert_e149686410094 : check e149686410094 [[.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e149686410102 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e149686410102 : Closed e149686410102 ∧ code e149686410102 = 2348709665654 := by decide
theorem cert_e149686410102 : check e149686410102 [[.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e149686410166 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e149686410166 : Closed e149686410166 ∧ code e149686410166 = 2348709665718 := by decide
theorem cert_e149686410166 : check e149686410166 [[.left],[.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e149686410606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e149686410606 : Closed e149686410606 ∧ code e149686410606 = 2348709666158 := by decide
def e149686410614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e149686410614 : Closed e149686410614 ∧ code e149686410614 = 2348709666166 := by decide
theorem cert_e149686410614 : check e149686410614 [[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e149686410670 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e149686410670 : Closed e149686410670 ∧ code e149686410670 = 2348709666222 := by decide
theorem cert_e149686410670 : check e149686410670 [[.under],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e149686410682 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e149686410682 : Closed e149686410682 ∧ code e149686410682 = 2348709666234 := by decide
theorem cert_e149686410682 : check e149686410682 [[.under],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e149686410710 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e149686410710 : Closed e149686410710 ∧ code e149686410710 = 2348709666262 := by decide
theorem cert_e149686410710 : check e149686410710 [[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e149686410714 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e149686410714 : Closed e149686410714 ∧ code e149686410714 = 2348709666266 := by decide
def e149686410934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e149686410934 : Closed e149686410934 ∧ code e149686410934 = 2348709666486 := by decide
theorem cert_e149686410934 : check e149686410934 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e149686410966 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e149686410966 : Closed e149686410966 ∧ code e149686410966 = 2348709666518 := by decide
theorem cert_e149686410966 : check e149686410966 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e149686410970 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e149686410970 : Closed e149686410970 ∧ code e149686410970 = 2348709666522 := by decide
theorem cert_e149686410970 : check e149686410970 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e149686413166 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e149686413166 : Closed e149686413166 ∧ code e149686413166 = 2348709668718 := by decide
theorem cert_e149686413166 : checkPay e149686413166 [[.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e149686413174 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e149686413174 : Closed e149686413174 ∧ code e149686413174 = 2348709668726 := by decide
theorem cert_e149686413174 : check e149686413174 [[.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e149686413238 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e149686413238 : Closed e149686413238 ∧ code e149686413238 = 2348709668790 := by decide
theorem cert_e149686413238 : check e149686413238 [[.left],[.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e149686414574 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e149686414574 : Closed e149686414574 ∧ code e149686414574 = 2348709670126 := by decide
theorem cert_e149686414574 : check e149686414574 [[.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e149686414582 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e149686414582 : Closed e149686414582 ∧ code e149686414582 = 2348709670134 := by decide
theorem cert_e149686414582 : check e149686414582 [[.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e149686414966 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e149686414966 : Closed e149686414966 ∧ code e149686414966 = 2348709670518 := by decide
theorem cert_e149686414966 : check e149686414966 [[.left],[.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e149686416238 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e149686416238 : Closed e149686416238 ∧ code e149686416238 = 2348709671790 := by decide
theorem cert_e149686416238 : check e149686416238 [[.under],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e149686416246 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e149686416246 : Closed e149686416246 ∧ code e149686416246 = 2348709671798 := by decide
theorem cert_e149686416246 : check e149686416246 [[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e149686416302 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e149686416302 : Closed e149686416302 ∧ code e149686416302 = 2348709671854 := by decide
theorem cert_e149686416302 : check e149686416302 [[.under],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e149686416314 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e149686416314 : Closed e149686416314 ∧ code e149686416314 = 2348709671866 := by decide
theorem cert_e149686416314 : check e149686416314 [[.under],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e149686416342 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e149686416342 : Closed e149686416342 ∧ code e149686416342 = 2348709671894 := by decide
theorem cert_e149686416342 : check e149686416342 [[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e149686416346 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e149686416346 : Closed e149686416346 ∧ code e149686416346 = 2348709671898 := by decide
theorem cert_e149686416346 : check e149686416346 [[.under],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e149686416622 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e149686416622 : Closed e149686416622 ∧ code e149686416622 = 2348709672174 := by decide
theorem cert_e149686416622 : check e149686416622 [[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e149686416630 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e149686416630 : Closed e149686416630 ∧ code e149686416630 = 2348709672182 := by decide
theorem cert_e149686416630 : check e149686416630 [[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e149686417006 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e149686417006 : Closed e149686417006 ∧ code e149686417006 = 2348709672558 := by decide
theorem cert_e149686417006 : check e149686417006 [[.under],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e149686417018 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e149686417018 : Closed e149686417018 ∧ code e149686417018 = 2348709672570 := by decide
theorem cert_e149686417018 : check e149686417018 [[.under],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e149686417206 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e149686417206 : Closed e149686417206 ∧ code e149686417206 = 2348709672758 := by decide
theorem cert_e149686417206 : check e149686417206 [[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e149686417210 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e149686417210 : Closed e149686417210 ∧ code e149686417210 = 2348709672762 := by decide
theorem cert_e149686417210 : check e149686417210 [[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e149686417846 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e149686417846 : Closed e149686417846 ∧ code e149686417846 = 2348709673398 := by decide
theorem cert_e149686417846 : checkPay e149686417846 [[.left],[.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left],[.under]] = true := by decide
def e149686417878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e149686417878 : Closed e149686417878 ∧ code e149686417878 = 2348709673430 := by decide
theorem cert_e149686417878 : checkPay e149686417878 [[.left],[.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left]] = true := by decide
def e149686417882 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e149686417882 : Closed e149686417882 ∧ code e149686417882 = 2348709673434 := by decide
theorem cert_e149686417882 : checkPay e149686417882 [[.left],[.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left],[.under,.under]] = true := by decide
def e149686418038 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e149686418038 : Closed e149686418038 ∧ code e149686418038 = 2348709673590 := by decide
theorem cert_e149686418038 : checkPay e149686418038 [[.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e149686418230 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e149686418230 : Closed e149686418230 ∧ code e149686418230 = 2348709673782 := by decide
theorem cert_e149686418230 : checkPay e149686418230 [[.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e149686418234 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e149686418234 : Closed e149686418234 ∧ code e149686418234 = 2348709673786 := by decide
theorem cert_e149686418234 : checkPay e149686418234 [[.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e149686425454 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e149686425454 : Closed e149686425454 ∧ code e149686425454 = 2348709681006 := by decide
theorem cert_e149686425454 : checkPay e149686425454 [[.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e149686425462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e149686425462 : Closed e149686425462 ∧ code e149686425462 = 2348709681014 := by decide
theorem cert_e149686425462 : check e149686425462 [[.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e149686425526 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e149686425526 : Closed e149686425526 ∧ code e149686425526 = 2348709681078 := by decide
theorem cert_e149686425526 : check e149686425526 [[.left],[.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e149686426862 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e149686426862 : Closed e149686426862 ∧ code e149686426862 = 2348709682414 := by decide
theorem cert_e149686426862 : check e149686426862 [[.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e149686426870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e149686426870 : Closed e149686426870 ∧ code e149686426870 = 2348709682422 := by decide
theorem cert_e149686426870 : check e149686426870 [[.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left]] .identityHead = true := by decide
def e149686427254 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e149686427254 : Closed e149686427254 ∧ code e149686427254 = 2348709682806 := by decide
theorem cert_e149686427254 : check e149686427254 [[.left],[.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e149686438766 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e149686438766 : Closed e149686438766 ∧ code e149686438766 = 2348709694318 := by decide
theorem cert_e149686438766 : check e149686438766 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e149686438774 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e149686438774 : Closed e149686438774 ∧ code e149686438774 = 2348709694326 := by decide
theorem cert_e149686438774 : check e149686438774 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e149686438830 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e149686438830 : Closed e149686438830 ∧ code e149686438830 = 2348709694382 := by decide
theorem cert_e149686438830 : check e149686438830 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e149686438842 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e149686438842 : Closed e149686438842 ∧ code e149686438842 = 2348709694394 := by decide
theorem cert_e149686438842 : check e149686438842 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e149686438870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e149686438870 : Closed e149686438870 ∧ code e149686438870 = 2348709694422 := by decide
theorem cert_e149686438870 : check e149686438870 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e149686438874 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e149686438874 : Closed e149686438874 ∧ code e149686438874 = 2348709694426 := by decide
theorem cert_e149686438874 : check e149686438874 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e149686439150 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e149686439150 : Closed e149686439150 ∧ code e149686439150 = 2348709694702 := by decide
theorem cert_e149686439150 : check e149686439150 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e149686439158 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e149686439158 : Closed e149686439158 ∧ code e149686439158 = 2348709694710 := by decide
theorem cert_e149686439158 : check e149686439158 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e149686439534 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e149686439534 : Closed e149686439534 ∧ code e149686439534 = 2348709695086 := by decide
theorem cert_e149686439534 : check e149686439534 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e149686439546 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e149686439546 : Closed e149686439546 ∧ code e149686439546 = 2348709695098 := by decide
theorem cert_e149686439546 : check e149686439546 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e149686439734 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e149686439734 : Closed e149686439734 ∧ code e149686439734 = 2348709695286 := by decide
theorem cert_e149686439734 : check e149686439734 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e149686439738 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e149686439738 : Closed e149686439738 ∧ code e149686439738 = 2348709695290 := by decide
theorem cert_e149686439738 : check e149686439738 [[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e149686445494 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e149686445494 : Closed e149686445494 ∧ code e149686445494 = 2348709701046 := by decide
theorem cert_e149686445494 : check e149686445494 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e149686445526 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e149686445526 : Closed e149686445526 ∧ code e149686445526 = 2348709701078 := by decide
theorem cert_e149686445526 : check e149686445526 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e149686445530 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e149686445530 : Closed e149686445530 ∧ code e149686445530 = 2348709701082 := by decide
theorem cert_e149686445530 : check e149686445530 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e149686445686 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e149686445686 : Closed e149686445686 ∧ code e149686445686 = 2348709701238 := by decide
theorem cert_e149686445686 : check e149686445686 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e149686445878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e149686445878 : Closed e149686445878 ∧ code e149686445878 = 2348709701430 := by decide
theorem cert_e149686445878 : check e149686445878 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e149686445882 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e149686445882 : Closed e149686445882 ∧ code e149686445882 = 2348709701434 := by decide
theorem cert_e149686445882 : check e149686445882 [[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e149686782830 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e149686782830 : Closed e149686782830 ∧ code e149686782830 = 2348710038382 := by decide
theorem cert_e149686782830 : check e149686782830 [[.under],[.under,.left]] .chain = true := by decide
def e149686782838 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e149686782838 : Closed e149686782838 ∧ code e149686782838 = 2348710038390 := by decide
theorem cert_e149686782838 : check e149686782838 [[.under],[.under,.left]] .chain = true := by decide
def e149686782894 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e149686782894 : Closed e149686782894 ∧ code e149686782894 = 2348710038446 := by decide
theorem cert_e149686782894 : check e149686782894 [[.under],[.under,.left]] .chain = true := by decide
def e149686782906 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e149686782906 : Closed e149686782906 ∧ code e149686782906 = 2348710038458 := by decide
theorem cert_e149686782906 : check e149686782906 [[.under],[.under,.left]] .chain = true := by decide
def e149686782934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e149686782934 : Closed e149686782934 ∧ code e149686782934 = 2348710038486 := by decide
theorem cert_e149686782934 : check e149686782934 [[.under],[.under,.left]] .chain = true := by decide
def e149686782938 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e149686782938 : Closed e149686782938 ∧ code e149686782938 = 2348710038490 := by decide
theorem cert_e149686782938 : check e149686782938 [[.under],[.under,.left]] .chain = true := by decide
def e149686783214 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e149686783214 : Closed e149686783214 ∧ code e149686783214 = 2348710038766 := by decide
theorem cert_e149686783214 : check e149686783214 [[.under],[.under,.left]] .chain = true := by decide
def e149686783222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e149686783222 : Closed e149686783222 ∧ code e149686783222 = 2348710038774 := by decide
theorem cert_e149686783222 : check e149686783222 [[.under],[.under,.left]] .chain = true := by decide
def e149686783598 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e149686783598 : Closed e149686783598 ∧ code e149686783598 = 2348710039150 := by decide
theorem cert_e149686783598 : check e149686783598 [[.under],[.under,.left]] .chain = true := by decide
def e149686783610 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e149686783610 : Closed e149686783610 ∧ code e149686783610 = 2348710039162 := by decide
theorem cert_e149686783610 : check e149686783610 [[.under],[.under,.left]] .chain = true := by decide
def e149686783798 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e149686783798 : Closed e149686783798 ∧ code e149686783798 = 2348710039350 := by decide
theorem cert_e149686783798 : check e149686783798 [[.under],[.under,.left]] .chain = true := by decide
def e149686783802 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e149686783802 : Closed e149686783802 ∧ code e149686783802 = 2348710039354 := by decide
theorem cert_e149686783802 : check e149686783802 [[.under],[.under,.left]] .chain = true := by decide
def e149954845550 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e149954845550 : Closed e149954845550 ∧ code e149954845550 = 2348978101102 := by decide
theorem cert_e149954845550 : check e149954845550 [[.under]] .sourceHead = true := by decide
def e149954845558 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e149954845558 : Closed e149954845558 ∧ code e149954845558 = 2348978101110 := by decide
theorem cert_e149954845558 : check e149954845558 [[.under]] .sourceHead = true := by decide
def e149954845622 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e149954845622 : Closed e149954845622 ∧ code e149954845622 = 2348978101174 := by decide
theorem cert_e149954845622 : check e149954845622 [[.under]] .sourceHead = true := by decide
def e149954846062 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e149954846062 : Closed e149954846062 ∧ code e149954846062 = 2348978101614 := by decide
theorem cert_e149954846062 : check e149954846062 [[.under]] .sourceHead = true := by decide
def e149954846070 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e149954846070 : Closed e149954846070 ∧ code e149954846070 = 2348978101622 := by decide
theorem cert_e149954846070 : check e149954846070 [[.under]] .sourceHead = true := by decide
def e149954846126 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e149954846126 : Closed e149954846126 ∧ code e149954846126 = 2348978101678 := by decide
theorem cert_e149954846126 : check e149954846126 [[.under]] .sourceHead = true := by decide
def e149954846138 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e149954846138 : Closed e149954846138 ∧ code e149954846138 = 2348978101690 := by decide
theorem cert_e149954846138 : check e149954846138 [[.under]] .sourceHead = true := by decide
def e149954846166 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e149954846166 : Closed e149954846166 ∧ code e149954846166 = 2348978101718 := by decide
theorem cert_e149954846166 : check e149954846166 [[.under]] .sourceHead = true := by decide
def e149954846170 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e149954846170 : Closed e149954846170 ∧ code e149954846170 = 2348978101722 := by decide
theorem cert_e149954846170 : check e149954846170 [[.under]] .sourceHead = true := by decide
def e149954846390 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e149954846390 : Closed e149954846390 ∧ code e149954846390 = 2348978101942 := by decide
theorem cert_e149954846390 : check e149954846390 [[.under]] .sourceHead = true := by decide
def e149954846422 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e149954846422 : Closed e149954846422 ∧ code e149954846422 = 2348978101974 := by decide
theorem cert_e149954846422 : check e149954846422 [[.under]] .sourceHead = true := by decide
def e149954846426 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e149954846426 : Closed e149954846426 ∧ code e149954846426 = 2348978101978 := by decide
theorem cert_e149954846426 : check e149954846426 [[.under]] .sourceHead = true := by decide
def e149954848622 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e149954848622 : Closed e149954848622 ∧ code e149954848622 = 2348978104174 := by decide
theorem cert_e149954848622 : check e149954848622 [[.under]] .sourceHead = true := by decide
def e149954848630 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e149954848630 : Closed e149954848630 ∧ code e149954848630 = 2348978104182 := by decide
theorem cert_e149954848630 : check e149954848630 [[.under]] .sourceHead = true := by decide
def e149954848694 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e149954848694 : Closed e149954848694 ∧ code e149954848694 = 2348978104246 := by decide
theorem cert_e149954848694 : check e149954848694 [[.under]] .sourceHead = true := by decide
def e149954850030 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e149954850030 : Closed e149954850030 ∧ code e149954850030 = 2348978105582 := by decide
theorem cert_e149954850030 : check e149954850030 [[.under]] .sourceHead = true := by decide
def e149954850038 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e149954850038 : Closed e149954850038 ∧ code e149954850038 = 2348978105590 := by decide
theorem cert_e149954850038 : check e149954850038 [[.under]] .sourceHead = true := by decide
def e149954850422 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e149954850422 : Closed e149954850422 ∧ code e149954850422 = 2348978105974 := by decide
theorem cert_e149954850422 : check e149954850422 [[.under]] .sourceHead = true := by decide
def e149954851694 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e149954851694 : Closed e149954851694 ∧ code e149954851694 = 2348978107246 := by decide
theorem cert_e149954851694 : check e149954851694 [[.under]] .sourceHead = true := by decide
def e149954851702 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e149954851702 : Closed e149954851702 ∧ code e149954851702 = 2348978107254 := by decide
theorem cert_e149954851702 : check e149954851702 [[.under]] .sourceHead = true := by decide
def e149954851758 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e149954851758 : Closed e149954851758 ∧ code e149954851758 = 2348978107310 := by decide
theorem cert_e149954851758 : check e149954851758 [[.under]] .sourceHead = true := by decide
def e149954851770 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e149954851770 : Closed e149954851770 ∧ code e149954851770 = 2348978107322 := by decide
theorem cert_e149954851770 : check e149954851770 [[.under]] .sourceHead = true := by decide
def e149954851798 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e149954851798 : Closed e149954851798 ∧ code e149954851798 = 2348978107350 := by decide
theorem cert_e149954851798 : check e149954851798 [[.under]] .sourceHead = true := by decide
def e149954851802 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e149954851802 : Closed e149954851802 ∧ code e149954851802 = 2348978107354 := by decide
theorem cert_e149954851802 : check e149954851802 [[.under]] .sourceHead = true := by decide
def e149954852078 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e149954852078 : Closed e149954852078 ∧ code e149954852078 = 2348978107630 := by decide
theorem cert_e149954852078 : check e149954852078 [[.under]] .sourceHead = true := by decide
def e149954852086 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e149954852086 : Closed e149954852086 ∧ code e149954852086 = 2348978107638 := by decide
theorem cert_e149954852086 : check e149954852086 [[.under]] .sourceHead = true := by decide
def e149954852462 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e149954852462 : Closed e149954852462 ∧ code e149954852462 = 2348978108014 := by decide
theorem cert_e149954852462 : check e149954852462 [[.under]] .sourceHead = true := by decide
def e149954852474 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e149954852474 : Closed e149954852474 ∧ code e149954852474 = 2348978108026 := by decide
theorem cert_e149954852474 : check e149954852474 [[.under]] .sourceHead = true := by decide
def e149954852662 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e149954852662 : Closed e149954852662 ∧ code e149954852662 = 2348978108214 := by decide
theorem cert_e149954852662 : check e149954852662 [[.under]] .sourceHead = true := by decide
def e149954852666 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e149954852666 : Closed e149954852666 ∧ code e149954852666 = 2348978108218 := by decide
theorem cert_e149954852666 : check e149954852666 [[.under]] .sourceHead = true := by decide
def e149954853302 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e149954853302 : Closed e149954853302 ∧ code e149954853302 = 2348978108854 := by decide
theorem cert_e149954853302 : check e149954853302 [[.under]] .sourceHead = true := by decide
def e149954853334 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e149954853334 : Closed e149954853334 ∧ code e149954853334 = 2348978108886 := by decide
theorem cert_e149954853334 : check e149954853334 [[.under]] .sourceHead = true := by decide
def e149954853338 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e149954853338 : Closed e149954853338 ∧ code e149954853338 = 2348978108890 := by decide
theorem cert_e149954853338 : check e149954853338 [[.under]] .sourceHead = true := by decide
def e149954853494 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e149954853494 : Closed e149954853494 ∧ code e149954853494 = 2348978109046 := by decide
theorem cert_e149954853494 : check e149954853494 [[.under]] .sourceHead = true := by decide
def e149954853686 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e149954853686 : Closed e149954853686 ∧ code e149954853686 = 2348978109238 := by decide
theorem cert_e149954853686 : check e149954853686 [[.under]] .sourceHead = true := by decide
def e149954853690 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e149954853690 : Closed e149954853690 ∧ code e149954853690 = 2348978109242 := by decide
theorem cert_e149954853690 : check e149954853690 [[.under]] .sourceHead = true := by decide
def e149954860910 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e149954860910 : Closed e149954860910 ∧ code e149954860910 = 2348978116462 := by decide
theorem cert_e149954860910 : check e149954860910 [[.under]] .sourceHead = true := by decide
def e149954860918 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e149954860918 : Closed e149954860918 ∧ code e149954860918 = 2348978116470 := by decide
theorem cert_e149954860918 : check e149954860918 [[.under]] .sourceHead = true := by decide
def e149954860982 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e149954860982 : Closed e149954860982 ∧ code e149954860982 = 2348978116534 := by decide
theorem cert_e149954860982 : check e149954860982 [[.under]] .sourceHead = true := by decide
def e149954862318 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e149954862318 : Closed e149954862318 ∧ code e149954862318 = 2348978117870 := by decide
theorem cert_e149954862318 : check e149954862318 [[.under]] .sourceHead = true := by decide
def e149954862326 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e149954862326 : Closed e149954862326 ∧ code e149954862326 = 2348978117878 := by decide
theorem cert_e149954862326 : check e149954862326 [[.under]] .sourceHead = true := by decide
def e149954862710 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e149954862710 : Closed e149954862710 ∧ code e149954862710 = 2348978118262 := by decide
theorem cert_e149954862710 : check e149954862710 [[.under]] .sourceHead = true := by decide
def e149954874222 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e149954874222 : Closed e149954874222 ∧ code e149954874222 = 2348978129774 := by decide
theorem cert_e149954874222 : check e149954874222 [[.under]] .sourceHead = true := by decide
def e149954874230 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e149954874230 : Closed e149954874230 ∧ code e149954874230 = 2348978129782 := by decide
theorem cert_e149954874230 : check e149954874230 [[.under]] .sourceHead = true := by decide
end Blc.Floor41
