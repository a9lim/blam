import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e604785855318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e604785855318 : Closed e604785855318 ∧ code e604785855318 = 2803809110870 := by decide
theorem cert_e604785855318 : check e604785855318 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785855322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e604785855322 : Closed e604785855322 ∧ code e604785855322 = 2803809110874 := by decide
theorem cert_e604785855322 : check e604785855322 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785855338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e604785855338 : Closed e604785855338 ∧ code e604785855338 = 2803809110890 := by decide
theorem cert_e604785855338 : check e604785855338 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785855402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e604785855402 : Closed e604785855402 ∧ code e604785855402 = 2803809110954 := by decide
theorem cert_e604785855402 : check e604785855402 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785855606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e604785855606 : Closed e604785855606 ∧ code e604785855606 = 2803809111158 := by decide
theorem cert_e604785855606 : check e604785855606 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785855702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e604785855702 : Closed e604785855702 ∧ code e604785855702 = 2803809111254 := by decide
theorem cert_e604785855702 : check e604785855702 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785855706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e604785855706 : Closed e604785855706 ∧ code e604785855706 = 2803809111258 := by decide
theorem cert_e604785855706 : check e604785855706 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785855722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e604785855722 : Closed e604785855722 ∧ code e604785855722 = 2803809111274 := by decide
theorem cert_e604785855722 : check e604785855722 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785855798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e604785855798 : Closed e604785855798 ∧ code e604785855798 = 2803809111350 := by decide
theorem cert_e604785855798 : check e604785855798 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785855802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e604785855802 : Closed e604785855802 ∧ code e604785855802 = 2803809111354 := by decide
theorem cert_e604785855802 : check e604785855802 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785855886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e604785855886 : Closed e604785855886 ∧ code e604785855886 = 2803809111438 := by decide
theorem cert_e604785855886 : check e604785855886 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785855898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e604785855898 : Closed e604785855898 ∧ code e604785855898 = 2803809111450 := by decide
theorem cert_e604785855898 : check e604785855898 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785856054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e604785856054 : Closed e604785856054 ∧ code e604785856054 = 2803809111606 := by decide
theorem cert_e604785856054 : check e604785856054 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785856058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e604785856058 : Closed e604785856058 ∧ code e604785856058 = 2803809111610 := by decide
theorem cert_e604785856058 : check e604785856058 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785856106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e604785856106 : Closed e604785856106 ∧ code e604785856106 = 2803809111658 := by decide
theorem cert_e604785856106 : check e604785856106 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785856142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e604785856142 : Closed e604785856142 ∧ code e604785856142 = 2803809111694 := by decide
theorem cert_e604785856142 : check e604785856142 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785856154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e604785856154 : Closed e604785856154 ∧ code e604785856154 = 2803809111706 := by decide
theorem cert_e604785856154 : check e604785856154 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785856198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e604785856198 : Closed e604785856198 ∧ code e604785856198 = 2803809111750 := by decide
theorem cert_e604785856198 : check e604785856198 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785856750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e604785856750 : Closed e604785856750 ∧ code e604785856750 = 2803809112302 := by decide
theorem cert_e604785856750 : check e604785856750 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785856758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e604785856758 : Closed e604785856758 ∧ code e604785856758 = 2803809112310 := by decide
theorem cert_e604785856758 : check e604785856758 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785857238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e604785857238 : Closed e604785857238 ∧ code e604785857238 = 2803809112790 := by decide
theorem cert_e604785857238 : check e604785857238 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785857242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e604785857242 : Closed e604785857242 ∧ code e604785857242 = 2803809112794 := by decide
theorem cert_e604785857242 : check e604785857242 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785857258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e604785857258 : Closed e604785857258 ∧ code e604785857258 = 2803809112810 := by decide
theorem cert_e604785857258 : check e604785857258 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785857334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e604785857334 : Closed e604785857334 ∧ code e604785857334 = 2803809112886 := by decide
theorem cert_e604785857334 : check e604785857334 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785857338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e604785857338 : Closed e604785857338 ∧ code e604785857338 = 2803809112890 := by decide
theorem cert_e604785857338 : check e604785857338 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785857422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e604785857422 : Closed e604785857422 ∧ code e604785857422 = 2803809112974 := by decide
theorem cert_e604785857422 : check e604785857422 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785857434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e604785857434 : Closed e604785857434 ∧ code e604785857434 = 2803809112986 := by decide
theorem cert_e604785857434 : check e604785857434 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785858678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e604785858678 : Closed e604785858678 ∧ code e604785858678 = 2803809114230 := by decide
theorem cert_e604785858678 : check e604785858678 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785858922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e604785858922 : Closed e604785858922 ∧ code e604785858922 = 2803809114474 := by decide
theorem cert_e604785858922 : check e604785858922 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785858958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e604785858958 : Closed e604785858958 ∧ code e604785858958 = 2803809114510 := by decide
theorem cert_e604785858958 : check e604785858958 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785858970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e604785858970 : Closed e604785858970 ∧ code e604785858970 = 2803809114522 := by decide
theorem cert_e604785858970 : check e604785858970 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785859014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e604785859014 : Closed e604785859014 ∧ code e604785859014 = 2803809114566 := by decide
theorem cert_e604785859014 : check e604785859014 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e604785871726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e604785871726 : Closed e604785871726 ∧ code e604785871726 = 2803809127278 := by decide
theorem cert_e604785871726 : check e604785871726 [[],[]] .smaller = true := by decide
def e604785871734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e604785871734 : Closed e604785871734 ∧ code e604785871734 = 2803809127286 := by decide
theorem cert_e604785871734 : check e604785871734 [[],[]] .smaller = true := by decide
def e604785871790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e604785871790 : Closed e604785871790 ∧ code e604785871790 = 2803809127342 := by decide
theorem cert_e604785871790 : check e604785871790 [[],[]] .smaller = true := by decide
def e604785871802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e604785871802 : Closed e604785871802 ∧ code e604785871802 = 2803809127354 := by decide
theorem cert_e604785871802 : check e604785871802 [[],[]] .smaller = true := by decide
def e604785871830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e604785871830 : Closed e604785871830 ∧ code e604785871830 = 2803809127382 := by decide
theorem cert_e604785871830 : check e604785871830 [[],[]] .smaller = true := by decide
def e604785871834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e604785871834 : Closed e604785871834 ∧ code e604785871834 = 2803809127386 := by decide
theorem cert_e604785871834 : check e604785871834 [[],[]] .smaller = true := by decide
def e604785872110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e604785872110 : Closed e604785872110 ∧ code e604785872110 = 2803809127662 := by decide
theorem cert_e604785872110 : check e604785872110 [[],[]] .smaller = true := by decide
def e604785872118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e604785872118 : Closed e604785872118 ∧ code e604785872118 = 2803809127670 := by decide
theorem cert_e604785872118 : check e604785872118 [[],[]] .smaller = true := by decide
def e604785872494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e604785872494 : Closed e604785872494 ∧ code e604785872494 = 2803809128046 := by decide
theorem cert_e604785872494 : check e604785872494 [[],[]] .smaller = true := by decide
def e604785872506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e604785872506 : Closed e604785872506 ∧ code e604785872506 = 2803809128058 := by decide
theorem cert_e604785872506 : check e604785872506 [[],[]] .smaller = true := by decide
def e604785872694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e604785872694 : Closed e604785872694 ∧ code e604785872694 = 2803809128246 := by decide
theorem cert_e604785872694 : check e604785872694 [[],[]] .smaller = true := by decide
def e604785872698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e604785872698 : Closed e604785872698 ∧ code e604785872698 = 2803809128250 := by decide
theorem cert_e604785872698 : check e604785872698 [[],[]] .smaller = true := by decide
def e604785913198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e604785913198 : Closed e604785913198 ∧ code e604785913198 = 2803809168750 := by decide
theorem cert_e604785913198 : check e604785913198 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e604785913206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e604785913206 : Closed e604785913206 ∧ code e604785913206 = 2803809168758 := by decide
theorem cert_e604785913206 : check e604785913206 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e604785913262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e604785913262 : Closed e604785913262 ∧ code e604785913262 = 2803809168814 := by decide
theorem cert_e604785913262 : check e604785913262 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604785913274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e604785913274 : Closed e604785913274 ∧ code e604785913274 = 2803809168826 := by decide
theorem cert_e604785913274 : check e604785913274 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604785913302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e604785913302 : Closed e604785913302 ∧ code e604785913302 = 2803809168854 := by decide
theorem cert_e604785913302 : check e604785913302 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e604785913306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e604785913306 : Closed e604785913306 ∧ code e604785913306 = 2803809168858 := by decide
theorem cert_e604785913306 : check e604785913306 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e604785913518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e604785913518 : Closed e604785913518 ∧ code e604785913518 = 2803809169070 := by decide
theorem cert_e604785913518 : check e604785913518 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785913530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e604785913530 : Closed e604785913530 ∧ code e604785913530 = 2803809169082 := by decide
theorem cert_e604785913530 : check e604785913530 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785913578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e604785913578 : Closed e604785913578 ∧ code e604785913578 = 2803809169130 := by decide
theorem cert_e604785913578 : check e604785913578 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785913686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e604785913686 : Closed e604785913686 ∧ code e604785913686 = 2803809169238 := by decide
theorem cert_e604785913686 : check e604785913686 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e604785913690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e604785913690 : Closed e604785913690 ∧ code e604785913690 = 2803809169242 := by decide
theorem cert_e604785913690 : check e604785913690 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785913706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e604785913706 : Closed e604785913706 ∧ code e604785913706 = 2803809169258 := by decide
theorem cert_e604785913706 : check e604785913706 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e604785914734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e604785914734 : Closed e604785914734 ∧ code e604785914734 = 2803809170286 := by decide
theorem cert_e604785914734 : check e604785914734 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e604785914742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e604785914742 : Closed e604785914742 ∧ code e604785914742 = 2803809170294 := by decide
theorem cert_e604785914742 : check e604785914742 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e604785914798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e604785914798 : Closed e604785914798 ∧ code e604785914798 = 2803809170350 := by decide
theorem cert_e604785914798 : check e604785914798 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e604785914810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e604785914810 : Closed e604785914810 ∧ code e604785914810 = 2803809170362 := by decide
theorem cert_e604785914810 : check e604785914810 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e604785914838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e604785914838 : Closed e604785914838 ∧ code e604785914838 = 2803809170390 := by decide
theorem cert_e604785914838 : check e604785914838 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[]] .identityHead = true := by decide
def e604785914842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e604785914842 : Closed e604785914842 ∧ code e604785914842 = 2803809170394 := by decide
theorem cert_e604785914842 : check e604785914842 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e604785915118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e604785915118 : Closed e604785915118 ∧ code e604785915118 = 2803809170670 := by decide
theorem cert_e604785915118 : check e604785915118 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785915126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e604785915126 : Closed e604785915126 ∧ code e604785915126 = 2803809170678 := by decide
theorem cert_e604785915126 : check e604785915126 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785915502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e604785915502 : Closed e604785915502 ∧ code e604785915502 = 2803809171054 := by decide
theorem cert_e604785915502 : check e604785915502 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e604785915514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e604785915514 : Closed e604785915514 ∧ code e604785915514 = 2803809171066 := by decide
theorem cert_e604785915514 : check e604785915514 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e604785915702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e604785915702 : Closed e604785915702 ∧ code e604785915702 = 2803809171254 := by decide
theorem cert_e604785915702 : check e604785915702 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785915706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e604785915706 : Closed e604785915706 ∧ code e604785915706 = 2803809171258 := by decide
theorem cert_e604785915706 : check e604785915706 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785916142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))
theorem wire_e604785916142 : Closed e604785916142 ∧ code e604785916142 = 2803809171694 := by decide
theorem cert_e604785916142 : check e604785916142 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785916150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))
theorem wire_e604785916150 : Closed e604785916150 ∧ code e604785916150 = 2803809171702 := by decide
theorem cert_e604785916150 : check e604785916150 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785916334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e604785916334 : Closed e604785916334 ∧ code e604785916334 = 2803809171886 := by decide
theorem cert_e604785916334 : check e604785916334 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785916346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e604785916346 : Closed e604785916346 ∧ code e604785916346 = 2803809171898 := by decide
theorem cert_e604785916346 : check e604785916346 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785916394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e604785916394 : Closed e604785916394 ∧ code e604785916394 = 2803809171946 := by decide
theorem cert_e604785916394 : check e604785916394 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785916526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e604785916526 : Closed e604785916526 ∧ code e604785916526 = 2803809172078 := by decide
theorem cert_e604785916526 : check e604785916526 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785916538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e604785916538 : Closed e604785916538 ∧ code e604785916538 = 2803809172090 := by decide
theorem cert_e604785916538 : check e604785916538 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785916702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))
theorem wire_e604785916702 : Closed e604785916702 ∧ code e604785916702 = 2803809172254 := by decide
theorem cert_e604785916702 : check e604785916702 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785916814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))
theorem wire_e604785916814 : Closed e604785916814 ∧ code e604785916814 = 2803809172366 := by decide
theorem cert_e604785916814 : check e604785916814 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785916826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e604785916826 : Closed e604785916826 ∧ code e604785916826 = 2803809172378 := by decide
theorem cert_e604785916826 : check e604785916826 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785917046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))
theorem wire_e604785917046 : Closed e604785917046 ∧ code e604785917046 = 2803809172598 := by decide
theorem cert_e604785917046 : check e604785917046 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e604785917142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e604785917142 : Closed e604785917142 ∧ code e604785917142 = 2803809172694 := by decide
theorem cert_e604785917142 : check e604785917142 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e604785917146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e604785917146 : Closed e604785917146 ∧ code e604785917146 = 2803809172698 := by decide
theorem cert_e604785917146 : check e604785917146 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e604785917162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e604785917162 : Closed e604785917162 ∧ code e604785917162 = 2803809172714 := by decide
theorem cert_e604785917162 : check e604785917162 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e604785917238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e604785917238 : Closed e604785917238 ∧ code e604785917238 = 2803809172790 := by decide
theorem cert_e604785917238 : check e604785917238 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785917242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e604785917242 : Closed e604785917242 ∧ code e604785917242 = 2803809172794 := by decide
theorem cert_e604785917242 : check e604785917242 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e604785917326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))
theorem wire_e604785917326 : Closed e604785917326 ∧ code e604785917326 = 2803809172878 := by decide
theorem cert_e604785917326 : checkPay e604785917326 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] 0 [] = true := by decide
def e604785917338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e604785917338 : Closed e604785917338 ∧ code e604785917338 = 2803809172890 := by decide
theorem cert_e604785917338 : check e604785917338 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785918942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e604785918942 : Closed e604785918942 ∧ code e604785918942 = 2803809174494 := by decide
theorem cert_e604785918942 : check e604785918942 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785918958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e604785918958 : Closed e604785918958 ∧ code e604785918958 = 2803809174510 := by decide
theorem cert_e604785918958 : check e604785918958 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604785920878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e604785920878 : Closed e604785920878 ∧ code e604785920878 = 2803809176430 := by decide
theorem cert_e604785920878 : check e604785920878 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e604785920886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e604785920886 : Closed e604785920886 ∧ code e604785920886 = 2803809176438 := by decide
theorem cert_e604785920886 : check e604785920886 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604785920942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e604785920942 : Closed e604785920942 ∧ code e604785920942 = 2803809176494 := by decide
theorem cert_e604785920942 : check e604785920942 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e604785920954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e604785920954 : Closed e604785920954 ∧ code e604785920954 = 2803809176506 := by decide
theorem cert_e604785920954 : check e604785920954 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e604785920982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e604785920982 : Closed e604785920982 ∧ code e604785920982 = 2803809176534 := by decide
theorem cert_e604785920982 : check e604785920982 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604785920986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e604785920986 : Closed e604785920986 ∧ code e604785920986 = 2803809176538 := by decide
theorem cert_e604785920986 : check e604785920986 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e604785921262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e604785921262 : Closed e604785921262 ∧ code e604785921262 = 2803809176814 := by decide
theorem cert_e604785921262 : check e604785921262 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604785921270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e604785921270 : Closed e604785921270 ∧ code e604785921270 = 2803809176822 := by decide
theorem cert_e604785921270 : check e604785921270 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604785921646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e604785921646 : Closed e604785921646 ∧ code e604785921646 = 2803809177198 := by decide
theorem cert_e604785921646 : check e604785921646 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e604785921658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e604785921658 : Closed e604785921658 ∧ code e604785921658 = 2803809177210 := by decide
theorem cert_e604785921658 : check e604785921658 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e604785921846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e604785921846 : Closed e604785921846 ∧ code e604785921846 = 2803809177398 := by decide
theorem cert_e604785921846 : check e604785921846 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e604785921850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e604785921850 : Closed e604785921850 ∧ code e604785921850 = 2803809177402 := by decide
theorem cert_e604785921850 : check e604785921850 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e604785926622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e604785926622 : Closed e604785926622 ∧ code e604785926622 = 2803809182174 := by decide
theorem cert_e604785926622 : check e604785926622 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785926646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e604785926646 : Closed e604785926646 ∧ code e604785926646 = 2803809182198 := by decide
theorem cert_e604785926646 : check e604785926646 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785927598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e604785927598 : Closed e604785927598 ∧ code e604785927598 = 2803809183150 := by decide
theorem cert_e604785927598 : check e604785927598 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785927610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e604785927610 : Closed e604785927610 ∧ code e604785927610 = 2803809183162 := by decide
theorem cert_e604785927610 : check e604785927610 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785927658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e604785927658 : Closed e604785927658 ∧ code e604785927658 = 2803809183210 := by decide
theorem cert_e604785927658 : check e604785927658 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785927790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e604785927790 : Closed e604785927790 ∧ code e604785927790 = 2803809183342 := by decide
theorem cert_e604785927790 : check e604785927790 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785927802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e604785927802 : Closed e604785927802 ∧ code e604785927802 = 2803809183354 := by decide
theorem cert_e604785927802 : check e604785927802 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785927966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e604785927966 : Closed e604785927966 ∧ code e604785927966 = 2803809183518 := by decide
theorem cert_e604785927966 : check e604785927966 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785928078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e604785928078 : Closed e604785928078 ∧ code e604785928078 = 2803809183630 := by decide
theorem cert_e604785928078 : check e604785928078 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785928090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e604785928090 : Closed e604785928090 ∧ code e604785928090 = 2803809183642 := by decide
theorem cert_e604785928090 : check e604785928090 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604785930478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e604785930478 : Closed e604785930478 ∧ code e604785930478 = 2803809186030 := by decide
theorem cert_e604785930478 : check e604785930478 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e604785930486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e604785930486 : Closed e604785930486 ∧ code e604785930486 = 2803809186038 := by decide
theorem cert_e604785930486 : check e604785930486 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e604785930966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e604785930966 : Closed e604785930966 ∧ code e604785930966 = 2803809186518 := by decide
theorem cert_e604785930966 : check e604785930966 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e604785930970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e604785930970 : Closed e604785930970 ∧ code e604785930970 = 2803809186522 := by decide
theorem cert_e604785930970 : check e604785930970 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e604785930986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e604785930986 : Closed e604785930986 ∧ code e604785930986 = 2803809186538 := by decide
theorem cert_e604785930986 : check e604785930986 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e604785931062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e604785931062 : Closed e604785931062 ∧ code e604785931062 = 2803809186614 := by decide
theorem cert_e604785931062 : check e604785931062 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e604785931066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e604785931066 : Closed e604785931066 ∧ code e604785931066 = 2803809186618 := by decide
theorem cert_e604785931066 : check e604785931066 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e604785931150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e604785931150 : Closed e604785931150 ∧ code e604785931150 = 2803809186702 := by decide
theorem cert_e604785931150 : check e604785931150 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e604785931162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e604785931162 : Closed e604785931162 ∧ code e604785931162 = 2803809186714 := by decide
theorem cert_e604785931162 : check e604785931162 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e604786022062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e604786022062 : Closed e604786022062 ∧ code e604786022062 = 2803809277614 := by decide
theorem cert_e604786022062 : check e604786022062 [[],[]] .sourceHead = true := by decide
def e604786022074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e604786022074 : Closed e604786022074 ∧ code e604786022074 = 2803809277626 := by decide
theorem cert_e604786022074 : check e604786022074 [[],[]] .sourceHead = true := by decide
def e604786022122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e604786022122 : Closed e604786022122 ∧ code e604786022122 = 2803809277674 := by decide
theorem cert_e604786022122 : check e604786022122 [[],[]] .sourceHead = true := by decide
def e604786022314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e604786022314 : Closed e604786022314 ∧ code e604786022314 = 2803809277866 := by decide
theorem cert_e604786022314 : check e604786022314 [[],[]] .sourceHead = true := by decide
def e604786022638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e604786022638 : Closed e604786022638 ∧ code e604786022638 = 2803809278190 := by decide
theorem cert_e604786022638 : check e604786022638 [[],[]] .sourceHead = true := by decide
def e604786022646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e604786022646 : Closed e604786022646 ∧ code e604786022646 = 2803809278198 := by decide
theorem cert_e604786022646 : check e604786022646 [[],[]] .sourceHead = true := by decide
def e604786022830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e604786022830 : Closed e604786022830 ∧ code e604786022830 = 2803809278382 := by decide
theorem cert_e604786022830 : check e604786022830 [[],[]] .sourceHead = true := by decide
def e604786022842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e604786022842 : Closed e604786022842 ∧ code e604786022842 = 2803809278394 := by decide
theorem cert_e604786022842 : check e604786022842 [[],[]] .sourceHead = true := by decide
def e604786022890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e604786022890 : Closed e604786022890 ∧ code e604786022890 = 2803809278442 := by decide
theorem cert_e604786022890 : check e604786022890 [[],[]] .sourceHead = true := by decide
def e604786023022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e604786023022 : Closed e604786023022 ∧ code e604786023022 = 2803809278574 := by decide
theorem cert_e604786023022 : check e604786023022 [[],[]] .sourceHead = true := by decide
def e604786023034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e604786023034 : Closed e604786023034 ∧ code e604786023034 = 2803809278586 := by decide
theorem cert_e604786023034 : check e604786023034 [[],[]] .sourceHead = true := by decide
def e604786023198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e604786023198 : Closed e604786023198 ∧ code e604786023198 = 2803809278750 := by decide
theorem cert_e604786023198 : check e604786023198 [[],[]] .sourceHead = true := by decide
def e604786023310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e604786023310 : Closed e604786023310 ∧ code e604786023310 = 2803809278862 := by decide
theorem cert_e604786023310 : check e604786023310 [[],[]] .sourceHead = true := by decide
def e604786023322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e604786023322 : Closed e604786023322 ∧ code e604786023322 = 2803809278874 := by decide
theorem cert_e604786023322 : check e604786023322 [[],[]] .sourceHead = true := by decide
def e604786023534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e604786023534 : Closed e604786023534 ∧ code e604786023534 = 2803809279086 := by decide
theorem cert_e604786023534 : check e604786023534 [[],[]] .sourceHead = true := by decide
def e604786023546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e604786023546 : Closed e604786023546 ∧ code e604786023546 = 2803809279098 := by decide
theorem cert_e604786023546 : check e604786023546 [[],[]] .sourceHead = true := by decide
def e604786023710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e604786023710 : Closed e604786023710 ∧ code e604786023710 = 2803809279262 := by decide
theorem cert_e604786023710 : check e604786023710 [[],[]] .sourceHead = true := by decide
def e604786023878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e604786023878 : Closed e604786023878 ∧ code e604786023878 = 2803809279430 := by decide
theorem cert_e604786023878 : check e604786023878 [[],[]] .sourceHead = true := by decide
def e604786023990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e604786023990 : Closed e604786023990 ∧ code e604786023990 = 2803809279542 := by decide
theorem cert_e604786023990 : check e604786023990 [[],[]] .sourceHead = true := by decide
def e604786023994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e604786023994 : Closed e604786023994 ∧ code e604786023994 = 2803809279546 := by decide
theorem cert_e604786023994 : check e604786023994 [[],[]] .sourceHead = true := by decide
def e604786024042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e604786024042 : Closed e604786024042 ∧ code e604786024042 = 2803809279594 := by decide
theorem cert_e604786024042 : check e604786024042 [[],[]] .sourceHead = true := by decide
def e604786024078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e604786024078 : Closed e604786024078 ∧ code e604786024078 = 2803809279630 := by decide
theorem cert_e604786024078 : check e604786024078 [[],[]] .sourceHead = true := by decide
def e604786024090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e604786024090 : Closed e604786024090 ∧ code e604786024090 = 2803809279642 := by decide
theorem cert_e604786024090 : check e604786024090 [[],[]] .sourceHead = true := by decide
def e604786024134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e604786024134 : Closed e604786024134 ∧ code e604786024134 = 2803809279686 := by decide
theorem cert_e604786024134 : check e604786024134 [[],[]] .sourceHead = true := by decide
def e604786024926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e604786024926 : Closed e604786024926 ∧ code e604786024926 = 2803809280478 := by decide
theorem cert_e604786024926 : check e604786024926 [[],[]] .sourceHead = true := by decide
def e604786024950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e604786024950 : Closed e604786024950 ∧ code e604786024950 = 2803809280502 := by decide
theorem cert_e604786024950 : check e604786024950 [[],[]] .sourceHead = true := by decide
def e604786025902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e604786025902 : Closed e604786025902 ∧ code e604786025902 = 2803809281454 := by decide
theorem cert_e604786025902 : check e604786025902 [[],[]] .sourceHead = true := by decide
def e604786025914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e604786025914 : Closed e604786025914 ∧ code e604786025914 = 2803809281466 := by decide
theorem cert_e604786025914 : check e604786025914 [[],[]] .sourceHead = true := by decide
def e604786025962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e604786025962 : Closed e604786025962 ∧ code e604786025962 = 2803809281514 := by decide
theorem cert_e604786025962 : check e604786025962 [[],[]] .sourceHead = true := by decide
def e604786026094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e604786026094 : Closed e604786026094 ∧ code e604786026094 = 2803809281646 := by decide
theorem cert_e604786026094 : check e604786026094 [[],[]] .sourceHead = true := by decide
def e604786026106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e604786026106 : Closed e604786026106 ∧ code e604786026106 = 2803809281658 := by decide
theorem cert_e604786026106 : check e604786026106 [[],[]] .sourceHead = true := by decide
def e604786026270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e604786026270 : Closed e604786026270 ∧ code e604786026270 = 2803809281822 := by decide
theorem cert_e604786026270 : check e604786026270 [[],[]] .sourceHead = true := by decide
def e604786026382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e604786026382 : Closed e604786026382 ∧ code e604786026382 = 2803809281934 := by decide
theorem cert_e604786026382 : check e604786026382 [[],[]] .sourceHead = true := by decide
def e604786026394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e604786026394 : Closed e604786026394 ∧ code e604786026394 = 2803809281946 := by decide
theorem cert_e604786026394 : check e604786026394 [[],[]] .sourceHead = true := by decide
def e604786029342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e604786029342 : Closed e604786029342 ∧ code e604786029342 = 2803809284894 := by decide
theorem cert_e604786029342 : check e604786029342 [[],[]] .sourceHead = true := by decide
def e604786029510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e604786029510 : Closed e604786029510 ∧ code e604786029510 = 2803809285062 := by decide
theorem cert_e604786029510 : check e604786029510 [[],[]] .sourceHead = true := by decide
def e604786030710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e604786030710 : Closed e604786030710 ∧ code e604786030710 = 2803809286262 := by decide
theorem cert_e604786030710 : check e604786030710 [[],[]] .sourceHead = true := by decide
def e604786030954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e604786030954 : Closed e604786030954 ∧ code e604786030954 = 2803809286506 := by decide
theorem cert_e604786030954 : check e604786030954 [[],[]] .sourceHead = true := by decide
def e604786030990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e604786030990 : Closed e604786030990 ∧ code e604786030990 = 2803809286542 := by decide
theorem cert_e604786030990 : check e604786030990 [[],[]] .sourceHead = true := by decide
def e604786031002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e604786031002 : Closed e604786031002 ∧ code e604786031002 = 2803809286554 := by decide
theorem cert_e604786031002 : check e604786031002 [[],[]] .sourceHead = true := by decide
def e604786031046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e604786031046 : Closed e604786031046 ∧ code e604786031046 = 2803809286598 := by decide
theorem cert_e604786031046 : check e604786031046 [[],[]] .sourceHead = true := by decide
end Blc.Floor41
