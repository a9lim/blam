import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e596279085934 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e596279085934 : Closed e596279085934 ∧ code e596279085934 = 2795302341486 := by decide
theorem cert_e596279085934 : check e596279085934 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e596279085942 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e596279085942 : Closed e596279085942 ∧ code e596279085942 = 2795302341494 := by decide
theorem cert_e596279085942 : check e596279085942 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e596279085998 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e596279085998 : Closed e596279085998 ∧ code e596279085998 = 2795302341550 := by decide
theorem cert_e596279085998 : check e596279085998 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e596279086010 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e596279086010 : Closed e596279086010 ∧ code e596279086010 = 2795302341562 := by decide
theorem cert_e596279086010 : check e596279086010 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e596279086038 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e596279086038 : Closed e596279086038 ∧ code e596279086038 = 2795302341590 := by decide
theorem cert_e596279086038 : check e596279086038 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e596279086042 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e596279086042 : Closed e596279086042 ∧ code e596279086042 = 2795302341594 := by decide
theorem cert_e596279086042 : check e596279086042 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e596279086318 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e596279086318 : Closed e596279086318 ∧ code e596279086318 = 2795302341870 := by decide
theorem cert_e596279086318 : check e596279086318 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e596279086326 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e596279086326 : Closed e596279086326 ∧ code e596279086326 = 2795302341878 := by decide
theorem cert_e596279086326 : check e596279086326 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e596279086702 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e596279086702 : Closed e596279086702 ∧ code e596279086702 = 2795302342254 := by decide
theorem cert_e596279086702 : check e596279086702 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e596279086714 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e596279086714 : Closed e596279086714 ∧ code e596279086714 = 2795302342266 := by decide
theorem cert_e596279086714 : check e596279086714 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e596279086902 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e596279086902 : Closed e596279086902 ∧ code e596279086902 = 2795302342454 := by decide
theorem cert_e596279086902 : check e596279086902 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e596279086906 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e596279086906 : Closed e596279086906 ∧ code e596279086906 = 2795302342458 := by decide
theorem cert_e596279086906 : check e596279086906 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e596279092654 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e596279092654 : Closed e596279092654 ∧ code e596279092654 = 2795302348206 := by decide
theorem cert_e596279092654 : check e596279092654 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e596279092666 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e596279092666 : Closed e596279092666 ∧ code e596279092666 = 2795302348218 := by decide
theorem cert_e596279092666 : check e596279092666 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e596279092714 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e596279092714 : Closed e596279092714 ∧ code e596279092714 = 2795302348266 := by decide
theorem cert_e596279092714 : check e596279092714 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e596279092846 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e596279092846 : Closed e596279092846 ∧ code e596279092846 = 2795302348398 := by decide
theorem cert_e596279092846 : check e596279092846 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e596279092858 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e596279092858 : Closed e596279092858 ∧ code e596279092858 = 2795302348410 := by decide
theorem cert_e596279092858 : check e596279092858 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e596279093146 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e596279093146 : Closed e596279093146 ∧ code e596279093146 = 2795302348698 := by decide
theorem cert_e596279093146 : check e596279093146 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e596279096022 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e596279096022 : Closed e596279096022 ∧ code e596279096022 = 2795302351574 := by decide
theorem cert_e596279096022 : check e596279096022 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e596279096026 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e596279096026 : Closed e596279096026 ∧ code e596279096026 = 2795302351578 := by decide
theorem cert_e596279096026 : check e596279096026 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e596279096042 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e596279096042 : Closed e596279096042 ∧ code e596279096042 = 2795302351594 := by decide
theorem cert_e596279096042 : check e596279096042 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e596279096118 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e596279096118 : Closed e596279096118 ∧ code e596279096118 = 2795302351670 := by decide
theorem cert_e596279096118 : check e596279096118 [[],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e596279096122 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e596279096122 : Closed e596279096122 ∧ code e596279096122 = 2795302351674 := by decide
theorem cert_e596279096122 : check e596279096122 [[],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e596279096218 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e596279096218 : Closed e596279096218 ∧ code e596279096218 = 2795302351770 := by decide
theorem cert_e596279096218 : check e596279096218 [[],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e596279233390 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e596279233390 : Closed e596279233390 ∧ code e596279233390 = 2795302488942 := by decide
theorem cert_e596279233390 : check e596279233390 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e596279233398 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e596279233398 : Closed e596279233398 ∧ code e596279233398 = 2795302488950 := by decide
theorem cert_e596279233398 : check e596279233398 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e596279233454 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e596279233454 : Closed e596279233454 ∧ code e596279233454 = 2795302489006 := by decide
theorem cert_e596279233454 : check e596279233454 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e596279233466 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e596279233466 : Closed e596279233466 ∧ code e596279233466 = 2795302489018 := by decide
theorem cert_e596279233466 : check e596279233466 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e596279233494 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e596279233494 : Closed e596279233494 ∧ code e596279233494 = 2795302489046 := by decide
theorem cert_e596279233494 : check e596279233494 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e596279233498 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e596279233498 : Closed e596279233498 ∧ code e596279233498 = 2795302489050 := by decide
theorem cert_e596279233498 : check e596279233498 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e596279233774 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e596279233774 : Closed e596279233774 ∧ code e596279233774 = 2795302489326 := by decide
theorem cert_e596279233774 : check e596279233774 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e596279233782 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e596279233782 : Closed e596279233782 ∧ code e596279233782 = 2795302489334 := by decide
theorem cert_e596279233782 : check e596279233782 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e596279234158 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e596279234158 : Closed e596279234158 ∧ code e596279234158 = 2795302489710 := by decide
theorem cert_e596279234158 : check e596279234158 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e596279234170 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e596279234170 : Closed e596279234170 ∧ code e596279234170 = 2795302489722 := by decide
theorem cert_e596279234170 : check e596279234170 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e596279234358 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e596279234358 : Closed e596279234358 ∧ code e596279234358 = 2795302489910 := by decide
theorem cert_e596279234358 : check e596279234358 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e596279234362 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e596279234362 : Closed e596279234362 ∧ code e596279234362 = 2795302489914 := by decide
theorem cert_e596279234362 : check e596279234362 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e596279823214 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e596279823214 : Closed e596279823214 ∧ code e596279823214 = 2795303078766 := by decide
def e596279823222 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e596279823222 : Closed e596279823222 ∧ code e596279823222 = 2795303078774 := by decide
def e596279823278 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e596279823278 : Closed e596279823278 ∧ code e596279823278 = 2795303078830 := by decide
def e596279823290 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e596279823290 : Closed e596279823290 ∧ code e596279823290 = 2795303078842 := by decide
private def t_e596279823290 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e596279823290 : ¬ IsSelfInterpreter e596279823290 :=
  wSource (t := t_e596279823290) (replay_sound (ps := []) (t := e596279823290) (by decide)) (by decide)
def e596279823318 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e596279823318 : Closed e596279823318 ∧ code e596279823318 = 2795303078870 := by decide
def e596279823322 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e596279823322 : Closed e596279823322 ∧ code e596279823322 = 2795303078874 := by decide
private def t_e596279823322 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e596279823322 : ¬ IsSelfInterpreter e596279823322 :=
  wSource (t := t_e596279823322) (replay_sound (ps := []) (t := e596279823322) (by decide)) (by decide)
def e596279823598 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e596279823598 : Closed e596279823598 ∧ code e596279823598 = 2795303079150 := by decide
def e596279823606 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e596279823606 : Closed e596279823606 ∧ code e596279823606 = 2795303079158 := by decide
def e596279823982 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e596279823982 : Closed e596279823982 ∧ code e596279823982 = 2795303079534 := by decide
theorem cert_e596279823982 : check e596279823982 [[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e596279823994 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e596279823994 : Closed e596279823994 ∧ code e596279823994 = 2795303079546 := by decide
def e596279824182 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e596279824182 : Closed e596279824182 ∧ code e596279824182 = 2795303079734 := by decide
def e596279824186 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e596279824186 : Closed e596279824186 ∧ code e596279824186 = 2795303079738 := by decide
def e597003450906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597003450906 : Closed e597003450906 ∧ code e597003450906 = 2796026706458 := by decide
theorem cert_e597003450906 : check e597003450906 [[],[.left]] .chain = true := by decide
def e597003459098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597003459098 : Closed e597003459098 ∧ code e597003459098 = 2796026714650 := by decide
theorem cert_e597003459098 : check e597003459098 [[],[.left]] .chain = true := by decide
def e597003516442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597003516442 : Closed e597003516442 ∧ code e597003516442 = 2796026771994 := by decide
theorem cert_e597003516442 : check e597003516442 [[],[.left]] .chain = true := by decide
def e597003528730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597003528730 : Closed e597003528730 ∧ code e597003528730 = 2796026784282 := by decide
theorem cert_e597003528730 : check e597003528730 [[],[.left]] .chain = true := by decide
def e597003557402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597003557402 : Closed e597003557402 ∧ code e597003557402 = 2796026812954 := by decide
theorem cert_e597003557402 : check e597003557402 [[],[.left]] .chain = true := by decide
def e597003561498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597003561498 : Closed e597003561498 ∧ code e597003561498 = 2796026817050 := by decide
theorem cert_e597003561498 : check e597003561498 [[],[.left]] .chain = true := by decide
def e597003844122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597003844122 : Closed e597003844122 ∧ code e597003844122 = 2796027099674 := by decide
theorem cert_e597003844122 : check e597003844122 [[],[.left]] .chain = true := by decide
def e597003852314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597003852314 : Closed e597003852314 ∧ code e597003852314 = 2796027107866 := by decide
theorem cert_e597003852314 : check e597003852314 [[],[.left]] .chain = true := by decide
def e597004237338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597004237338 : Closed e597004237338 ∧ code e597004237338 = 2796027492890 := by decide
theorem cert_e597004237338 : check e597004237338 [[],[.left]] .chain = true := by decide
def e597004249626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597004249626 : Closed e597004249626 ∧ code e597004249626 = 2796027505178 := by decide
theorem cert_e597004249626 : check e597004249626 [[],[.left]] .chain = true := by decide
def e597004442138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597004442138 : Closed e597004442138 ∧ code e597004442138 = 2796027697690 := by decide
theorem cert_e597004442138 : check e597004442138 [[],[.left]] .chain = true := by decide
def e597004446234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597004446234 : Closed e597004446234 ∧ code e597004446234 = 2796027701786 := by decide
theorem cert_e597004446234 : check e597004446234 [[],[.left]] .chain = true := by decide
def e597012441114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597012441114 : Closed e597012441114 ∧ code e597012441114 = 2796035696666 := by decide
theorem cert_e597012441114 : check e597012441114 [[],[.left]] .smaller = true := by decide
def e597012473882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597012473882 : Closed e597012473882 ∧ code e597012473882 = 2796035729434 := by decide
theorem cert_e597012473882 : check e597012473882 [[],[.left]] .smaller = true := by decide
def e597012478490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597012478490 : Closed e597012478490 ∧ code e597012478490 = 2796035734042 := by decide
theorem cert_e597012478490 : check e597012478490 [[]] .width = true := by decide
def e597012494874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597012494874 : Closed e597012494874 ∧ code e597012494874 = 2796035750426 := by decide
theorem cert_e597012494874 : check e597012494874 [[]] .width = true := by decide
def e597012703258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597012703258 : Closed e597012703258 ∧ code e597012703258 = 2796035958810 := by decide
theorem cert_e597012703258 : check e597012703258 [[],[.left]] .smaller = true := by decide
def e597012752410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597012752410 : Closed e597012752410 ∧ code e597012752410 = 2796036007962 := by decide
theorem cert_e597012752410 : check e597012752410 [[],[.left]] .smaller = true := by decide
def e597012867098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597012867098 : Closed e597012867098 ∧ code e597012867098 = 2796036122650 := by decide
theorem cert_e597012867098 : check e597012867098 [[],[.left]] .smaller = true := by decide
def e597012871706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597012871706 : Closed e597012871706 ∧ code e597012871706 = 2796036127258 := by decide
theorem cert_e597012871706 : check e597012871706 [[]] .width = true := by decide
def e597012883482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597012883482 : Closed e597012883482 ∧ code e597012883482 = 2796036139034 := by decide
theorem cert_e597012883482 : check e597012883482 [[],[.left]] .smaller = true := by decide
def e597012900378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597012900378 : Closed e597012900378 ∧ code e597012900378 = 2796036155930 := by decide
private def t_e597012900378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597012900378 : ¬ IsSelfInterpreter e597012900378 :=
  wSource (t := t_e597012900378) (replay_sound (ps := []) (t := e597012900378) (by decide)) (by decide)
def e597012953626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597012953626 : Closed e597012953626 ∧ code e597012953626 = 2796036209178 := by decide
theorem cert_e597012953626 : check e597012953626 [[]] .width = true := by decide
def e597012965914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597012965914 : Closed e597012965914 ∧ code e597012965914 = 2796036221466 := by decide
private def t_e597012965914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597012965914 : ¬ IsSelfInterpreter e597012965914 :=
  wSource (t := t_e597012965914) (replay_sound (ps := []) (t := e597012965914) (by decide)) (by decide)
def e597014013978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597014013978 : Closed e597014013978 ∧ code e597014013978 = 2796037269530 := by decide
theorem cert_e597014013978 : check e597014013978 [[],[.left]] .smaller = true := by decide
def e597014046746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597014046746 : Closed e597014046746 ∧ code e597014046746 = 2796037302298 := by decide
theorem cert_e597014046746 : check e597014046746 [[],[.left]] .smaller = true := by decide
def e597014051354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597014051354 : Closed e597014051354 ∧ code e597014051354 = 2796037306906 := by decide
theorem cert_e597014051354 : check e597014051354 [[]] .width = true := by decide
def e597014067738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597014067738 : Closed e597014067738 ∧ code e597014067738 = 2796037323290 := by decide
theorem cert_e597014067738 : check e597014067738 [[]] .width = true := by decide
def e597015586842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597015586842 : Closed e597015586842 ∧ code e597015586842 = 2796038842394 := by decide
theorem cert_e597015586842 : check e597015586842 [[],[.left]] .smaller = true := by decide
def e597015635994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597015635994 : Closed e597015635994 ∧ code e597015635994 = 2796038891546 := by decide
theorem cert_e597015635994 : check e597015635994 [[],[.left]] .smaller = true := by decide
def e597016406042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597016406042 : Closed e597016406042 ∧ code e597016406042 = 2796039661594 := by decide
theorem cert_e597016406042 : check e597016406042 [[],[.left]] .smaller = true := by decide
def e597016410650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597016410650 : Closed e597016410650 ∧ code e597016410650 = 2796039666202 := by decide
theorem cert_e597016410650 : check e597016410650 [[]] .width = true := by decide
def e597016422426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597016422426 : Closed e597016422426 ∧ code e597016422426 = 2796039677978 := by decide
theorem cert_e597016422426 : check e597016422426 [[],[.left]] .smaller = true := by decide
def e597016439322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597016439322 : Closed e597016439322 ∧ code e597016439322 = 2796039694874 := by decide
theorem cert_e597016439322 : check e597016439322 [[]] .width = true := by decide
def e597016820250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597016820250 : Closed e597016820250 ∧ code e597016820250 = 2796040075802 := by decide
theorem cert_e597016820250 : check e597016820250 [[]] .width = true := by decide
def e597016832538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597016832538 : Closed e597016832538 ∧ code e597016832538 = 2796040088090 := by decide
theorem cert_e597016832538 : check e597016832538 [[]] .width = true := by decide
def e597045918234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597045918234 : Closed e597045918234 ∧ code e597045918234 = 2796069173786 := by decide
theorem cert_e597045918234 : check e597045918234 [[]] .width = true := by decide
def e597045926426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597045926426 : Closed e597045926426 ∧ code e597045926426 = 2796069181978 := by decide
theorem cert_e597045926426 : check e597045926426 [[]] .width = true := by decide
def e597045983770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597045983770 : Closed e597045983770 ∧ code e597045983770 = 2796069239322 := by decide
theorem cert_e597045983770 : check e597045983770 [[]] .width = true := by decide
def e597045996058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597045996058 : Closed e597045996058 ∧ code e597045996058 = 2796069251610 := by decide
theorem cert_e597045996058 : check e597045996058 [[]] .width = true := by decide
def e597046024730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597046024730 : Closed e597046024730 ∧ code e597046024730 = 2796069280282 := by decide
theorem cert_e597046024730 : check e597046024730 [[]] .width = true := by decide
def e597046028826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597046028826 : Closed e597046028826 ∧ code e597046028826 = 2796069284378 := by decide
theorem cert_e597046028826 : check e597046028826 [[]] .width = true := by decide
def e597046245914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597046245914 : Closed e597046245914 ∧ code e597046245914 = 2796069501466 := by decide
theorem cert_e597046245914 : check e597046245914 [[]] .width = true := by decide
def e597046258202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597046258202 : Closed e597046258202 ∧ code e597046258202 = 2796069513754 := by decide
theorem cert_e597046258202 : check e597046258202 [[]] .width = true := by decide
def e597046307354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597046307354 : Closed e597046307354 ∧ code e597046307354 = 2796069562906 := by decide
private def t_e597046307354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597046307354 : ¬ IsSelfInterpreter e597046307354 :=
  wSource (t := t_e597046307354) (replay_sound (ps := []) (t := e597046307354) (by decide)) (by decide)
def e597046417946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597046417946 : Closed e597046417946 ∧ code e597046417946 = 2796069673498 := by decide
theorem cert_e597046417946 : check e597046417946 [[]] .width = true := by decide
def e597046422042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597046422042 : Closed e597046422042 ∧ code e597046422042 = 2796069677594 := by decide
theorem cert_e597046422042 : check e597046422042 [[]] .width = true := by decide
def e597046438426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597046438426 : Closed e597046438426 ∧ code e597046438426 = 2796069693978 := by decide
private def t_e597046438426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597046438426 : ¬ IsSelfInterpreter e597046438426 :=
  wSource (t := t_e597046438426) (replay_sound (ps := []) (t := e597046438426) (by decide)) (by decide)
def e597047491098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597047491098 : Closed e597047491098 ∧ code e597047491098 = 2796070746650 := by decide
theorem cert_e597047491098 : check e597047491098 [[]] .width = true := by decide
def e597047499290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597047499290 : Closed e597047499290 ∧ code e597047499290 = 2796070754842 := by decide
theorem cert_e597047499290 : check e597047499290 [[]] .width = true := by decide
def e597047556634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597047556634 : Closed e597047556634 ∧ code e597047556634 = 2796070812186 := by decide
theorem cert_e597047556634 : check e597047556634 [[]] .width = true := by decide
def e597047568922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597047568922 : Closed e597047568922 ∧ code e597047568922 = 2796070824474 := by decide
theorem cert_e597047568922 : check e597047568922 [[]] .width = true := by decide
def e597047597594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597047597594 : Closed e597047597594 ∧ code e597047597594 = 2796070853146 := by decide
theorem cert_e597047597594 : check e597047597594 [[]] .width = true := by decide
def e597047601690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597047601690 : Closed e597047601690 ∧ code e597047601690 = 2796070857242 := by decide
theorem cert_e597047601690 : check e597047601690 [[]] .width = true := by decide
def e597047884314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597047884314 : Closed e597047884314 ∧ code e597047884314 = 2796071139866 := by decide
theorem cert_e597047884314 : check e597047884314 [[]] .width = true := by decide
def e597047892506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597047892506 : Closed e597047892506 ∧ code e597047892506 = 2796071148058 := by decide
theorem cert_e597047892506 : check e597047892506 [[]] .width = true := by decide
def e597048277530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597048277530 : Closed e597048277530 ∧ code e597048277530 = 2796071533082 := by decide
theorem cert_e597048277530 : check e597048277530 [[]] .width = true := by decide
def e597048289818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597048289818 : Closed e597048289818 ∧ code e597048289818 = 2796071545370 := by decide
theorem cert_e597048289818 : check e597048289818 [[]] .width = true := by decide
def e597048395802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597048395802 : Closed e597048395802 ∧ code e597048395802 = 2796071651354 := by decide
theorem cert_e597048395802 : check e597048395802 [[]] .width = true := by decide
def e597048400410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597048400410 : Closed e597048400410 ∧ code e597048400410 = 2796071655962 := by decide
theorem cert_e597048400410 : check e597048400410 [[]] .width = true := by decide
def e597048401946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597048401946 : Closed e597048401946 ∧ code e597048401946 = 2796071657498 := by decide
theorem cert_e597048401946 : check e597048401946 [[]] .width = true := by decide
def e597048402038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e597048402038 : Closed e597048402038 ∧ code e597048402038 = 2796071657590 := by decide
theorem cert_e597048402038 : check e597048402038 [[]] .width = true := by decide
def e597048402282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e597048402282 : Closed e597048402282 ∧ code e597048402282 = 2796071657834 := by decide
theorem cert_e597048402282 : check e597048402282 [[]] .width = true := by decide
def e597048402330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e597048402330 : Closed e597048402330 ∧ code e597048402330 = 2796071657882 := by decide
theorem cert_e597048402330 : check e597048402330 [[]] .width = true := by decide
def e597048482330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597048482330 : Closed e597048482330 ∧ code e597048482330 = 2796071737882 := by decide
theorem cert_e597048482330 : check e597048482330 [[]] .width = true := by decide
def e597048486426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597048486426 : Closed e597048486426 ∧ code e597048486426 = 2796071741978 := by decide
theorem cert_e597048486426 : check e597048486426 [[]] .width = true := by decide
def e597048526874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597048526874 : Closed e597048526874 ∧ code e597048526874 = 2796071782426 := by decide
theorem cert_e597048526874 : check e597048526874 [[]] .width = true := by decide
def e597048531482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597048531482 : Closed e597048531482 ∧ code e597048531482 = 2796071787034 := by decide
theorem cert_e597048531482 : check e597048531482 [[]] .width = true := by decide
def e597048533018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597048533018 : Closed e597048533018 ∧ code e597048533018 = 2796071788570 := by decide
theorem cert_e597048533018 : check e597048533018 [[]] .width = true := by decide
def e597048533110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e597048533110 : Closed e597048533110 ∧ code e597048533110 = 2796071788662 := by decide
theorem cert_e597048533110 : check e597048533110 [[]] .width = true := by decide
def e597048533354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e597048533354 : Closed e597048533354 ∧ code e597048533354 = 2796071788906 := by decide
theorem cert_e597048533354 : check e597048533354 [[]] .width = true := by decide
def e597048533402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e597048533402 : Closed e597048533402 ∧ code e597048533402 = 2796071788954 := by decide
theorem cert_e597048533402 : check e597048533402 [[]] .width = true := by decide
def e597049129498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597049129498 : Closed e597049129498 ∧ code e597049129498 = 2796072385050 := by decide
theorem cert_e597049129498 : check e597049129498 [[]] .width = true := by decide
def e597049141786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597049141786 : Closed e597049141786 ∧ code e597049141786 = 2796072397338 := by decide
theorem cert_e597049141786 : check e597049141786 [[]] .width = true := by decide
def e597049190938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597049190938 : Closed e597049190938 ∧ code e597049190938 = 2796072446490 := by decide
theorem cert_e597049190938 : check e597049190938 [[]] .width = true := by decide
def e597049326106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597049326106 : Closed e597049326106 ∧ code e597049326106 = 2796072581658 := by decide
theorem cert_e597049326106 : check e597049326106 [[]] .width = true := by decide
def e597049338394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597049338394 : Closed e597049338394 ∧ code e597049338394 = 2796072593946 := by decide
theorem cert_e597049338394 : check e597049338394 [[]] .width = true := by decide
def e597049444378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597049444378 : Closed e597049444378 ∧ code e597049444378 = 2796072699930 := by decide
theorem cert_e597049444378 : check e597049444378 [[]] .width = true := by decide
def e597049448986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597049448986 : Closed e597049448986 ∧ code e597049448986 = 2796072704538 := by decide
theorem cert_e597049448986 : check e597049448986 [[]] .width = true := by decide
def e597049450522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597049450522 : Closed e597049450522 ∧ code e597049450522 = 2796072706074 := by decide
theorem cert_e597049450522 : check e597049450522 [[]] .width = true := by decide
def e597049450614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e597049450614 : Closed e597049450614 ∧ code e597049450614 = 2796072706166 := by decide
theorem cert_e597049450614 : check e597049450614 [[]] .width = true := by decide
def e597049450858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e597049450858 : Closed e597049450858 ∧ code e597049450858 = 2796072706410 := by decide
theorem cert_e597049450858 : check e597049450858 [[]] .width = true := by decide
def e597049450906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e597049450906 : Closed e597049450906 ∧ code e597049450906 = 2796072706458 := by decide
theorem cert_e597049450906 : check e597049450906 [[]] .width = true := by decide
def e597049633306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597049633306 : Closed e597049633306 ∧ code e597049633306 = 2796072888858 := by decide
private def t_e597049633306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597049633306 : ¬ IsSelfInterpreter e597049633306 :=
  wSource (t := t_e597049633306) (replay_sound (ps := []) (t := e597049633306) (by decide)) (by decide)
def e597049640986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597049640986 : Closed e597049640986 ∧ code e597049640986 = 2796072896538 := by decide
theorem cert_e597049640986 : check e597049640986 [[]] .width = true := by decide
def e597049645594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597049645594 : Closed e597049645594 ∧ code e597049645594 = 2796072901146 := by decide
private def t_e597049645594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597049645594 : ¬ IsSelfInterpreter e597049645594 :=
  wSource (t := t_e597049645594) (replay_sound (ps := []) (t := e597049645594) (by decide)) (by decide)
def e597049647130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597049647130 : Closed e597049647130 ∧ code e597049647130 = 2796072902682 := by decide
theorem cert_e597049647130 : check e597049647130 [[]] .width = true := by decide
def e597049647222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e597049647222 : Closed e597049647222 ∧ code e597049647222 = 2796072902774 := by decide
private def t_e597049647222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e597049647222 : ¬ IsSelfInterpreter e597049647222 :=
  wSource (t := t_e597049647222) (replay_sound (ps := []) (t := e597049647222) (by decide)) (by decide)
def e597049647466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e597049647466 : Closed e597049647466 ∧ code e597049647466 = 2796072903018 := by decide
private def t_e597049647466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e597049647466 : ¬ IsSelfInterpreter e597049647466 :=
  wSource (t := t_e597049647466) (replay_sound (ps := []) (t := e597049647466) (by decide)) (by decide)
def e597049647514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e597049647514 : Closed e597049647514 ∧ code e597049647514 = 2796072903066 := by decide
private def t_e597049647514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e597049647514 : ¬ IsSelfInterpreter e597049647514 :=
  wSource (t := t_e597049647514) (replay_sound (ps := []) (t := e597049647514) (by decide)) (by decide)
def e597049956890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597049956890 : Closed e597049956890 ∧ code e597049956890 = 2796073212442 := by decide
theorem cert_e597049956890 : check e597049956890 [[]] .width = true := by decide
def e597049960986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597049960986 : Closed e597049960986 ∧ code e597049960986 = 2796073216538 := by decide
theorem cert_e597049960986 : check e597049960986 [[]] .width = true := by decide
def e597049977370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597049977370 : Closed e597049977370 ∧ code e597049977370 = 2796073232922 := by decide
theorem cert_e597049977370 : check e597049977370 [[]] .width = true := by decide
def e597050055194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597050055194 : Closed e597050055194 ∧ code e597050055194 = 2796073310746 := by decide
theorem cert_e597050055194 : check e597050055194 [[]] .width = true := by decide
def e597050059290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597050059290 : Closed e597050059290 ∧ code e597050059290 = 2796073314842 := by decide
theorem cert_e597050059290 : check e597050059290 [[]] .width = true := by decide
def e597050099738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597050099738 : Closed e597050099738 ∧ code e597050099738 = 2796073355290 := by decide
theorem cert_e597050099738 : check e597050099738 [[]] .width = true := by decide
def e597050104346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597050104346 : Closed e597050104346 ∧ code e597050104346 = 2796073359898 := by decide
theorem cert_e597050104346 : check e597050104346 [[]] .width = true := by decide
def e597050105882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597050105882 : Closed e597050105882 ∧ code e597050105882 = 2796073361434 := by decide
theorem cert_e597050105882 : check e597050105882 [[]] .width = true := by decide
def e597050105974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e597050105974 : Closed e597050105974 ∧ code e597050105974 = 2796073361526 := by decide
theorem cert_e597050105974 : check e597050105974 [[]] .width = true := by decide
def e597050106218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e597050106218 : Closed e597050106218 ∧ code e597050106218 = 2796073361770 := by decide
theorem cert_e597050106218 : check e597050106218 [[]] .width = true := by decide
def e597050106266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e597050106266 : Closed e597050106266 ∧ code e597050106266 = 2796073361818 := by decide
theorem cert_e597050106266 : check e597050106266 [[]] .width = true := by decide
def e597050157594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597050157594 : Closed e597050157594 ∧ code e597050157594 = 2796073413146 := by decide
private def t_e597050157594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597050157594 : ¬ IsSelfInterpreter e597050157594 :=
  wSource (t := t_e597050157594) (replay_sound (ps := []) (t := e597050157594) (by decide)) (by decide)
def e597050165274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e597050165274 : Closed e597050165274 ∧ code e597050165274 = 2796073420826 := by decide
theorem cert_e597050165274 : check e597050165274 [[]] .width = true := by decide
def e597050169882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597050169882 : Closed e597050169882 ∧ code e597050169882 = 2796073425434 := by decide
private def t_e597050169882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e597050169882 : ¬ IsSelfInterpreter e597050169882 :=
  wSource (t := t_e597050169882) (replay_sound (ps := []) (t := e597050169882) (by decide)) (by decide)
def e597050171418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597050171418 : Closed e597050171418 ∧ code e597050171418 = 2796073426970 := by decide
theorem cert_e597050171418 : check e597050171418 [[]] .width = true := by decide
def e597050171510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e597050171510 : Closed e597050171510 ∧ code e597050171510 = 2796073427062 := by decide
private def t_e597050171510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e597050171510 : ¬ IsSelfInterpreter e597050171510 :=
  wSource (t := t_e597050171510) (replay_sound (ps := []) (t := e597050171510) (by decide)) (by decide)
def e597050171754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e597050171754 : Closed e597050171754 ∧ code e597050171754 = 2796073427306 := by decide
private def t_e597050171754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e597050171754 : ¬ IsSelfInterpreter e597050171754 :=
  wSource (t := t_e597050171754) (replay_sound (ps := []) (t := e597050171754) (by decide)) (by decide)
def e597050171802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e597050171802 : Closed e597050171802 ∧ code e597050171802 = 2796073427354 := by decide
private def t_e597050171802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e597050171802 : ¬ IsSelfInterpreter e597050171802 :=
  wSource (t := t_e597050171802) (replay_sound (ps := []) (t := e597050171802) (by decide)) (by decide)
def e597051800090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597051800090 : Closed e597051800090 ∧ code e597051800090 = 2796075055642 := by decide
theorem cert_e597051800090 : check e597051800090 [[]] .width = true := by decide
def e597051816474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597051816474 : Closed e597051816474 ∧ code e597051816474 = 2796075072026 := by decide
theorem cert_e597051816474 : check e597051816474 [[]] .width = true := by decide
def e597053782554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597053782554 : Closed e597053782554 ∧ code e597053782554 = 2796077038106 := by decide
theorem cert_e597053782554 : check e597053782554 [[]] .width = true := by decide
def e597053790746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e597053790746 : Closed e597053790746 ∧ code e597053790746 = 2796077046298 := by decide
theorem cert_e597053790746 : check e597053790746 [[]] .width = true := by decide
end Blc.Floor41
