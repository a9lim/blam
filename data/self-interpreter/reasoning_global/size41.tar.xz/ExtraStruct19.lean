import Extra41
import Batch139
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness605775123418
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u3 u4
private def u6 := Term.app u1 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u13 := Term.app u4 u0
private def u14 := Term.app u1 u4
private theorem sou3 : SO u3 := SO.var 2
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.app sou3 sou4
private theorem sou6 : SO u6 := SO.app sou1 sou5
private theorem sou13 : SO u13 := SO.app sou4 sou0
private theorem sou7 : SO u7 := SO.lam (r := u13) (g := u14) sou6 sou13 (by decide) (by decide)
private theorem sou8 : SO u8 := SO.lam (r := u0) (g := u7) sou7 sou0 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou10 : SO u10 := SO.app sou9 sou0
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
private theorem sou12 : SO u12 := SO.app sou2 sou11
theorem nege605775123418 : ¬ IsSelfInterpreter e605775123418 := by
  exact rawSO [] (t := u12) (by decide) sou12
#print axioms nege605775123418
end Witness605775123418
namespace Witness605775124922
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u0 u3
private def u5 := Term.var 2
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775124922 : ¬ IsSelfInterpreter e605775124922 := by
  intro he
  have h : replay [] e605775124922 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775124922
end Witness605775124922
namespace Witness605775124970
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u0 u3
private def u5 := Term.var 2
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775124970 : ¬ IsSelfInterpreter e605775124970 := by
  intro he
  have h : replay [] e605775124970 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775124970
end Witness605775124970
namespace Witness605775125402
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u0 u3
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u1
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
theorem nege605775125402 : ¬ IsSelfInterpreter e605775125402 := by
  intro he
  have h : replay [] e605775125402 = some u12 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u12) (by decide) (by decide) hj
#print axioms nege605775125402
end Witness605775125402
namespace Witness605775125722
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u0 u3
private def u5 := Term.var 1
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775125722 : ¬ IsSelfInterpreter e605775125722 := by
  intro he
  have h : replay [] e605775125722 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775125722
end Witness605775125722
namespace Witness605775125738
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u0 u3
private def u5 := Term.var 1
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775125738 : ¬ IsSelfInterpreter e605775125738 := by
  intro he
  have h : replay [] e605775125738 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775125738
end Witness605775125738
namespace Witness605775128250
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u3 u1
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
theorem nege605775128250 : ¬ IsSelfInterpreter e605775128250 := by
  intro he
  have h : replay [] e605775128250 = some u12 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u12) (by decide) (by decide) hj
#print axioms nege605775128250
end Witness605775128250
namespace Witness605775128298
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.app u0 u4
private def u6 := Term.app u3 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775128298 : ¬ IsSelfInterpreter e605775128298 := by
  intro he
  have h : replay [] e605775128298 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775128298
end Witness605775128298
end Blc.Floor41
