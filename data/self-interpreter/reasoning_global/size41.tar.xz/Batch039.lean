import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598342809466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e598342809466 : Closed e598342809466 ∧ code e598342809466 = 2797366065018 := by decide
theorem cert_e598342809466 : check e598342809466 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342809518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e598342809518 : Closed e598342809518 ∧ code e598342809518 = 2797366065070 := by decide
theorem cert_e598342809518 : check e598342809518 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342809526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e598342809526 : Closed e598342809526 ∧ code e598342809526 = 2797366065078 := by decide
theorem cert_e598342809526 : check e598342809526 [[],[.left],[]] .chain = true := by decide
def e598342809530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e598342809530 : Closed e598342809530 ∧ code e598342809530 = 2797366065082 := by decide
theorem cert_e598342809530 : check e598342809530 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342810334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e598342810334 : Closed e598342810334 ∧ code e598342810334 = 2797366065886 := by decide
theorem cert_e598342810334 : check e598342810334 [[],[.left],[]] .chain = true := by decide
def e598342810350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e598342810350 : Closed e598342810350 ∧ code e598342810350 = 2797366065902 := by decide
theorem cert_e598342810350 : check e598342810350 [[],[.left],[]] .sourceHead = true := by decide
def e598342810358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e598342810358 : Closed e598342810358 ∧ code e598342810358 = 2797366065910 := by decide
theorem cert_e598342810358 : check e598342810358 [[],[.left],[]] .chain = true := by decide
def e598342810462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e598342810462 : Closed e598342810462 ∧ code e598342810462 = 2797366066014 := by decide
theorem cert_e598342810462 : check e598342810462 [[],[.left],[]] .chain = true := by decide
def e598342810490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e598342810490 : Closed e598342810490 ∧ code e598342810490 = 2797366066042 := by decide
theorem cert_e598342810490 : check e598342810490 [[],[.left],[]] .chain = true := by decide
def e598342810542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e598342810542 : Closed e598342810542 ∧ code e598342810542 = 2797366066094 := by decide
theorem cert_e598342810542 : check e598342810542 [[],[.left],[]] .sourceHead = true := by decide
def e598342810554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e598342810554 : Closed e598342810554 ∧ code e598342810554 = 2797366066106 := by decide
theorem cert_e598342810554 : check e598342810554 [[],[.left],[]] .sourceHead = true := by decide
def e598342810582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e598342810582 : Closed e598342810582 ∧ code e598342810582 = 2797366066134 := by decide
theorem cert_e598342810582 : check e598342810582 [[],[.left],[]] .chain = true := by decide
def e598342810586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e598342810586 : Closed e598342810586 ∧ code e598342810586 = 2797366066138 := by decide
theorem cert_e598342810586 : check e598342810586 [[],[.left],[]] .chain = true := by decide
def e598342810974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e598342810974 : Closed e598342810974 ∧ code e598342810974 = 2797366066526 := by decide
theorem cert_e598342810974 : check e598342810974 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e598342810990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e598342810990 : Closed e598342810990 ∧ code e598342810990 = 2797366066542 := by decide
theorem cert_e598342810990 : check e598342810990 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e598342810998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e598342810998 : Closed e598342810998 ∧ code e598342810998 = 2797366066550 := by decide
theorem cert_e598342810998 : check e598342810998 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342811002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e598342811002 : Closed e598342811002 ∧ code e598342811002 = 2797366066554 := by decide
theorem cert_e598342811002 : check e598342811002 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e598342811054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e598342811054 : Closed e598342811054 ∧ code e598342811054 = 2797366066606 := by decide
theorem cert_e598342811054 : check e598342811054 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e598342811066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e598342811066 : Closed e598342811066 ∧ code e598342811066 = 2797366066618 := by decide
theorem cert_e598342811066 : check e598342811066 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342811094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e598342811094 : Closed e598342811094 ∧ code e598342811094 = 2797366066646 := by decide
theorem cert_e598342811094 : check e598342811094 [[],[.left],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e598342811098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e598342811098 : Closed e598342811098 ∧ code e598342811098 = 2797366066650 := by decide
theorem cert_e598342811098 : check e598342811098 [[],[.left],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e598342811114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e598342811114 : Closed e598342811114 ∧ code e598342811114 = 2797366066666 := by decide
theorem cert_e598342811114 : check e598342811114 [[],[.left],[],[.under,.under,.left,.left]] .chain = true := by decide
def e598342811310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e598342811310 : Closed e598342811310 ∧ code e598342811310 = 2797366066862 := by decide
theorem cert_e598342811310 : check e598342811310 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e598342811318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e598342811318 : Closed e598342811318 ∧ code e598342811318 = 2797366066870 := by decide
theorem cert_e598342811318 : check e598342811318 [[],[.left],[]] .chain = true := by decide
def e598342811322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e598342811322 : Closed e598342811322 ∧ code e598342811322 = 2797366066874 := by decide
theorem cert_e598342811322 : check e598342811322 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e598342811350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e598342811350 : Closed e598342811350 ∧ code e598342811350 = 2797366066902 := by decide
theorem cert_e598342811350 : check e598342811350 [[],[.left],[]] .chain = true := by decide
def e598342811354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e598342811354 : Closed e598342811354 ∧ code e598342811354 = 2797366066906 := by decide
theorem cert_e598342811354 : check e598342811354 [[],[.left],[]] .chain = true := by decide
def e598342811370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e598342811370 : Closed e598342811370 ∧ code e598342811370 = 2797366066922 := by decide
theorem cert_e598342811370 : check e598342811370 [[],[.left],[],[.under,.under,.left,.left]] .chain = true := by decide
def e598342815198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e598342815198 : Closed e598342815198 ∧ code e598342815198 = 2797366070750 := by decide
theorem cert_e598342815198 : check e598342815198 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e598342815214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e598342815214 : Closed e598342815214 ∧ code e598342815214 = 2797366070766 := by decide
theorem cert_e598342815214 : check e598342815214 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342815454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e598342815454 : Closed e598342815454 ∧ code e598342815454 = 2797366071006 := by decide
theorem cert_e598342815454 : check e598342815454 [[],[.left],[]] .chain = true := by decide
def e598342815470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e598342815470 : Closed e598342815470 ∧ code e598342815470 = 2797366071022 := by decide
theorem cert_e598342815470 : check e598342815470 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e598342815478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e598342815478 : Closed e598342815478 ∧ code e598342815478 = 2797366071030 := by decide
theorem cert_e598342815478 : check e598342815478 [[],[.left],[]] .chain = true := by decide
def e598342815582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e598342815582 : Closed e598342815582 ∧ code e598342815582 = 2797366071134 := by decide
theorem cert_e598342815582 : check e598342815582 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e598342815598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e598342815598 : Closed e598342815598 ∧ code e598342815598 = 2797366071150 := by decide
theorem cert_e598342815598 : check e598342815598 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e598342815606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e598342815606 : Closed e598342815606 ∧ code e598342815606 = 2797366071158 := by decide
theorem cert_e598342815606 : checkPay e598342815606 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e598342815610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e598342815610 : Closed e598342815610 ∧ code e598342815610 = 2797366071162 := by decide
theorem cert_e598342815610 : check e598342815610 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342815662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e598342815662 : Closed e598342815662 ∧ code e598342815662 = 2797366071214 := by decide
theorem cert_e598342815662 : check e598342815662 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e598342815670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e598342815670 : Closed e598342815670 ∧ code e598342815670 = 2797366071222 := by decide
theorem cert_e598342815670 : check e598342815670 [[],[.left],[]] .chain = true := by decide
def e598342815674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e598342815674 : Closed e598342815674 ∧ code e598342815674 = 2797366071226 := by decide
theorem cert_e598342815674 : check e598342815674 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342816734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e598342816734 : Closed e598342816734 ∧ code e598342816734 = 2797366072286 := by decide
theorem cert_e598342816734 : check e598342816734 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342816750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e598342816750 : Closed e598342816750 ∧ code e598342816750 = 2797366072302 := by decide
theorem cert_e598342816750 : check e598342816750 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342818270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e598342818270 : Closed e598342818270 ∧ code e598342818270 = 2797366073822 := by decide
theorem cert_e598342818270 : check e598342818270 [[],[.left],[]] .chain = true := by decide
def e598342818286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e598342818286 : Closed e598342818286 ∧ code e598342818286 = 2797366073838 := by decide
theorem cert_e598342818286 : check e598342818286 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e598342818294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e598342818294 : Closed e598342818294 ∧ code e598342818294 = 2797366073846 := by decide
theorem cert_e598342818294 : check e598342818294 [[],[.left],[]] .chain = true := by decide
def e598342819038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e598342819038 : Closed e598342819038 ∧ code e598342819038 = 2797366074590 := by decide
theorem cert_e598342819038 : check e598342819038 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342819054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e598342819054 : Closed e598342819054 ∧ code e598342819054 = 2797366074606 := by decide
theorem cert_e598342819054 : check e598342819054 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342819062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e598342819062 : Closed e598342819062 ∧ code e598342819062 = 2797366074614 := by decide
theorem cert_e598342819062 : check e598342819062 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342819066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e598342819066 : Closed e598342819066 ∧ code e598342819066 = 2797366074618 := by decide
theorem cert_e598342819066 : check e598342819066 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342819438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e598342819438 : Closed e598342819438 ∧ code e598342819438 = 2797366074990 := by decide
theorem cert_e598342819438 : check e598342819438 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342819446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e598342819446 : Closed e598342819446 ∧ code e598342819446 = 2797366074998 := by decide
theorem cert_e598342819446 : check e598342819446 [[],[.left],[]] .chain = true := by decide
def e598342819450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e598342819450 : Closed e598342819450 ∧ code e598342819450 = 2797366075002 := by decide
theorem cert_e598342819450 : check e598342819450 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342821598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e598342821598 : Closed e598342821598 ∧ code e598342821598 = 2797366077150 := by decide
theorem cert_e598342821598 : check e598342821598 [[],[.left],[]] .chain = true := by decide
def e598342821614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e598342821614 : Closed e598342821614 ∧ code e598342821614 = 2797366077166 := by decide
theorem cert_e598342821614 : checkPay e598342821614 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e598342821622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e598342821622 : Closed e598342821622 ∧ code e598342821622 = 2797366077174 := by decide
theorem cert_e598342821622 : check e598342821622 [[],[.left],[]] .chain = true := by decide
def e598342821726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e598342821726 : Closed e598342821726 ∧ code e598342821726 = 2797366077278 := by decide
theorem cert_e598342821726 : check e598342821726 [[],[.left],[]] .chain = true := by decide
def e598342821754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e598342821754 : Closed e598342821754 ∧ code e598342821754 = 2797366077306 := by decide
theorem cert_e598342821754 : check e598342821754 [[],[.left],[]] .chain = true := by decide
def e598342821806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e598342821806 : Closed e598342821806 ∧ code e598342821806 = 2797366077358 := by decide
theorem cert_e598342821806 : checkPay e598342821806 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e598342821818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e598342821818 : Closed e598342821818 ∧ code e598342821818 = 2797366077370 := by decide
theorem cert_e598342821818 : checkPay e598342821818 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e598342821846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e598342821846 : Closed e598342821846 ∧ code e598342821846 = 2797366077398 := by decide
theorem cert_e598342821846 : check e598342821846 [[],[.left],[]] .chain = true := by decide
def e598342821850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e598342821850 : Closed e598342821850 ∧ code e598342821850 = 2797366077402 := by decide
theorem cert_e598342821850 : check e598342821850 [[],[.left],[]] .chain = true := by decide
def e598342822366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e598342822366 : Closed e598342822366 ∧ code e598342822366 = 2797366077918 := by decide
theorem cert_e598342822366 : check e598342822366 [[],[.left],[]] .chain = true := by decide
def e598342822382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e598342822382 : Closed e598342822382 ∧ code e598342822382 = 2797366077934 := by decide
theorem cert_e598342822382 : checkPay e598342822382 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e598342822390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e598342822390 : Closed e598342822390 ∧ code e598342822390 = 2797366077942 := by decide
theorem cert_e598342822390 : check e598342822390 [[],[.left],[]] .chain = true := by decide
def e598342823134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e598342823134 : Closed e598342823134 ∧ code e598342823134 = 2797366078686 := by decide
theorem cert_e598342823134 : check e598342823134 [[],[.left],[]] .chain = true := by decide
def e598342823162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e598342823162 : Closed e598342823162 ∧ code e598342823162 = 2797366078714 := by decide
theorem cert_e598342823162 : check e598342823162 [[],[.left],[]] .chain = true := by decide
def e598342823534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e598342823534 : Closed e598342823534 ∧ code e598342823534 = 2797366079086 := by decide
theorem cert_e598342823534 : checkPay e598342823534 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e598342823546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e598342823546 : Closed e598342823546 ∧ code e598342823546 = 2797366079098 := by decide
theorem cert_e598342823546 : checkPay e598342823546 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e598342823734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e598342823734 : Closed e598342823734 ∧ code e598342823734 = 2797366079286 := by decide
theorem cert_e598342823734 : check e598342823734 [[],[.left],[]] .chain = true := by decide
def e598342823738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e598342823738 : Closed e598342823738 ∧ code e598342823738 = 2797366079290 := by decide
theorem cert_e598342823738 : check e598342823738 [[],[.left],[]] .chain = true := by decide
def e598342824798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e598342824798 : Closed e598342824798 ∧ code e598342824798 = 2797366080350 := by decide
theorem cert_e598342824798 : check e598342824798 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342824814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e598342824814 : Closed e598342824814 ∧ code e598342824814 = 2797366080366 := by decide
theorem cert_e598342824814 : check e598342824814 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342824822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e598342824822 : Closed e598342824822 ∧ code e598342824822 = 2797366080374 := by decide
theorem cert_e598342824822 : check e598342824822 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e598342824826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e598342824826 : Closed e598342824826 ∧ code e598342824826 = 2797366080378 := by decide
theorem cert_e598342824826 : check e598342824826 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e598342824878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e598342824878 : Closed e598342824878 ∧ code e598342824878 = 2797366080430 := by decide
theorem cert_e598342824878 : check e598342824878 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342824890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e598342824890 : Closed e598342824890 ∧ code e598342824890 = 2797366080442 := by decide
theorem cert_e598342824890 : check e598342824890 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e598342824918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e598342824918 : Closed e598342824918 ∧ code e598342824918 = 2797366080470 := by decide
theorem cert_e598342824918 : check e598342824918 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e598342824922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e598342824922 : Closed e598342824922 ∧ code e598342824922 = 2797366080474 := by decide
theorem cert_e598342824922 : check e598342824922 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e598342824938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e598342824938 : Closed e598342824938 ∧ code e598342824938 = 2797366080490 := by decide
theorem cert_e598342824938 : check e598342824938 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e598342825182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e598342825182 : Closed e598342825182 ∧ code e598342825182 = 2797366080734 := by decide
theorem cert_e598342825182 : check e598342825182 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342825198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e598342825198 : Closed e598342825198 ∧ code e598342825198 = 2797366080750 := by decide
theorem cert_e598342825198 : check e598342825198 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342825206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e598342825206 : Closed e598342825206 ∧ code e598342825206 = 2797366080758 := by decide
theorem cert_e598342825206 : check e598342825206 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342825210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e598342825210 : Closed e598342825210 ∧ code e598342825210 = 2797366080762 := by decide
theorem cert_e598342825210 : check e598342825210 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342825582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e598342825582 : Closed e598342825582 ∧ code e598342825582 = 2797366081134 := by decide
theorem cert_e598342825582 : check e598342825582 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342825594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e598342825594 : Closed e598342825594 ∧ code e598342825594 = 2797366081146 := by decide
theorem cert_e598342825594 : check e598342825594 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342825782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e598342825782 : Closed e598342825782 ∧ code e598342825782 = 2797366081334 := by decide
theorem cert_e598342825782 : check e598342825782 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e598342825786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e598342825786 : Closed e598342825786 ∧ code e598342825786 = 2797366081338 := by decide
theorem cert_e598342825786 : check e598342825786 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e598342825882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e598342825882 : Closed e598342825882 ∧ code e598342825882 = 2797366081434 := by decide
theorem cert_e598342825882 : check e598342825882 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e598342826414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e598342826414 : Closed e598342826414 ∧ code e598342826414 = 2797366081966 := by decide
theorem cert_e598342826414 : check e598342826414 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342826422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e598342826422 : Closed e598342826422 ∧ code e598342826422 = 2797366081974 := by decide
theorem cert_e598342826422 : check e598342826422 [[],[.left],[]] .chain = true := by decide
def e598342826426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e598342826426 : Closed e598342826426 ∧ code e598342826426 = 2797366081978 := by decide
theorem cert_e598342826426 : check e598342826426 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e598342826454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e598342826454 : Closed e598342826454 ∧ code e598342826454 = 2797366082006 := by decide
theorem cert_e598342826454 : check e598342826454 [[],[.left],[]] .chain = true := by decide
def e598342826458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e598342826458 : Closed e598342826458 ∧ code e598342826458 = 2797366082010 := by decide
theorem cert_e598342826458 : check e598342826458 [[],[.left],[]] .chain = true := by decide
def e598342826474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e598342826474 : Closed e598342826474 ∧ code e598342826474 = 2797366082026 := by decide
theorem cert_e598342826474 : check e598342826474 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e598342826606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e598342826606 : Closed e598342826606 ∧ code e598342826606 = 2797366082158 := by decide
theorem cert_e598342826606 : check e598342826606 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342826614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e598342826614 : Closed e598342826614 ∧ code e598342826614 = 2797366082166 := by decide
theorem cert_e598342826614 : check e598342826614 [[],[.left],[]] .chain = true := by decide
def e598342826618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e598342826618 : Closed e598342826618 ∧ code e598342826618 = 2797366082170 := by decide
theorem cert_e598342826618 : check e598342826618 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e598342826806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e598342826806 : Closed e598342826806 ∧ code e598342826806 = 2797366082358 := by decide
theorem cert_e598342826806 : check e598342826806 [[],[.left],[]] .chain = true := by decide
def e598342826810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e598342826810 : Closed e598342826810 ∧ code e598342826810 = 2797366082362 := by decide
theorem cert_e598342826810 : check e598342826810 [[],[.left],[]] .chain = true := by decide
def e598342826906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e598342826906 : Closed e598342826906 ∧ code e598342826906 = 2797366082458 := by decide
theorem cert_e598342826906 : check e598342826906 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e598342830958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e598342830958 : Closed e598342830958 ∧ code e598342830958 = 2797366086510 := by decide
theorem cert_e598342830958 : check e598342830958 [[],[.left],[]] .smaller = true := by decide
def e598342830966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e598342830966 : Closed e598342830966 ∧ code e598342830966 = 2797366086518 := by decide
theorem cert_e598342830966 : check e598342830966 [[],[.left],[]] .smaller = true := by decide
def e598342831022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e598342831022 : Closed e598342831022 ∧ code e598342831022 = 2797366086574 := by decide
theorem cert_e598342831022 : check e598342831022 [[],[.left],[]] .smaller = true := by decide
def e598342831034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e598342831034 : Closed e598342831034 ∧ code e598342831034 = 2797366086586 := by decide
theorem cert_e598342831034 : check e598342831034 [[],[.left],[]] .smaller = true := by decide
def e598342831062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e598342831062 : Closed e598342831062 ∧ code e598342831062 = 2797366086614 := by decide
theorem cert_e598342831062 : check e598342831062 [[],[.left],[]] .smaller = true := by decide
def e598342831066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e598342831066 : Closed e598342831066 ∧ code e598342831066 = 2797366086618 := by decide
theorem cert_e598342831066 : check e598342831066 [[],[.left],[]] .smaller = true := by decide
def e598342831342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e598342831342 : Closed e598342831342 ∧ code e598342831342 = 2797366086894 := by decide
theorem cert_e598342831342 : check e598342831342 [[],[.left],[]] .smaller = true := by decide
def e598342831350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e598342831350 : Closed e598342831350 ∧ code e598342831350 = 2797366086902 := by decide
theorem cert_e598342831350 : check e598342831350 [[],[.left],[]] .smaller = true := by decide
def e598342831726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e598342831726 : Closed e598342831726 ∧ code e598342831726 = 2797366087278 := by decide
theorem cert_e598342831726 : check e598342831726 [[],[.left],[]] .smaller = true := by decide
def e598342831738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e598342831738 : Closed e598342831738 ∧ code e598342831738 = 2797366087290 := by decide
theorem cert_e598342831738 : check e598342831738 [[],[.left],[]] .smaller = true := by decide
def e598342831926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e598342831926 : Closed e598342831926 ∧ code e598342831926 = 2797366087478 := by decide
theorem cert_e598342831926 : check e598342831926 [[],[.left],[]] .smaller = true := by decide
def e598342831930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e598342831930 : Closed e598342831930 ∧ code e598342831930 = 2797366087482 := by decide
theorem cert_e598342831930 : check e598342831930 [[],[.left],[]] .smaller = true := by decide
def e598342839774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e598342839774 : Closed e598342839774 ∧ code e598342839774 = 2797366095326 := by decide
theorem cert_e598342839774 : check e598342839774 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e598342839790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e598342839790 : Closed e598342839790 ∧ code e598342839790 = 2797366095342 := by decide
theorem cert_e598342839790 : check e598342839790 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e598342840030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e598342840030 : Closed e598342840030 ∧ code e598342840030 = 2797366095582 := by decide
theorem cert_e598342840030 : check e598342840030 [[],[.left],[]] .chain = true := by decide
def e598342840046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e598342840046 : Closed e598342840046 ∧ code e598342840046 = 2797366095598 := by decide
theorem cert_e598342840046 : check e598342840046 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e598342840054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e598342840054 : Closed e598342840054 ∧ code e598342840054 = 2797366095606 := by decide
theorem cert_e598342840054 : check e598342840054 [[],[.left],[]] .chain = true := by decide
def e598342840158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e598342840158 : Closed e598342840158 ∧ code e598342840158 = 2797366095710 := by decide
theorem cert_e598342840158 : check e598342840158 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e598342840174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e598342840174 : Closed e598342840174 ∧ code e598342840174 = 2797366095726 := by decide
theorem cert_e598342840174 : check e598342840174 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342840182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e598342840182 : Closed e598342840182 ∧ code e598342840182 = 2797366095734 := by decide
theorem cert_e598342840182 : check e598342840182 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e598342840186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e598342840186 : Closed e598342840186 ∧ code e598342840186 = 2797366095738 := by decide
theorem cert_e598342840186 : check e598342840186 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342840238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e598342840238 : Closed e598342840238 ∧ code e598342840238 = 2797366095790 := by decide
theorem cert_e598342840238 : check e598342840238 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342840246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e598342840246 : Closed e598342840246 ∧ code e598342840246 = 2797366095798 := by decide
theorem cert_e598342840246 : check e598342840246 [[],[.left],[]] .chain = true := by decide
def e598342840250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e598342840250 : Closed e598342840250 ∧ code e598342840250 = 2797366095802 := by decide
theorem cert_e598342840250 : check e598342840250 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e598342841310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e598342841310 : Closed e598342841310 ∧ code e598342841310 = 2797366096862 := by decide
theorem cert_e598342841310 : check e598342841310 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.under]] .identityHead = true := by decide
def e598342841326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e598342841326 : Closed e598342841326 ∧ code e598342841326 = 2797366096878 := by decide
theorem cert_e598342841326 : check e598342841326 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.under]] .identityHead = true := by decide
def e598342842846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e598342842846 : Closed e598342842846 ∧ code e598342842846 = 2797366098398 := by decide
theorem cert_e598342842846 : check e598342842846 [[],[.left],[]] .chain = true := by decide
def e598342842862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e598342842862 : Closed e598342842862 ∧ code e598342842862 = 2797366098414 := by decide
theorem cert_e598342842862 : check e598342842862 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e598342842870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e598342842870 : Closed e598342842870 ∧ code e598342842870 = 2797366098422 := by decide
theorem cert_e598342842870 : check e598342842870 [[],[.left],[]] .chain = true := by decide
def e598342843614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e598342843614 : Closed e598342843614 ∧ code e598342843614 = 2797366099166 := by decide
theorem cert_e598342843614 : check e598342843614 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342843630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e598342843630 : Closed e598342843630 ∧ code e598342843630 = 2797366099182 := by decide
theorem cert_e598342843630 : check e598342843630 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342843638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e598342843638 : Closed e598342843638 ∧ code e598342843638 = 2797366099190 := by decide
theorem cert_e598342843638 : check e598342843638 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342843642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e598342843642 : Closed e598342843642 ∧ code e598342843642 = 2797366099194 := by decide
theorem cert_e598342843642 : check e598342843642 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342844014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e598342844014 : Closed e598342844014 ∧ code e598342844014 = 2797366099566 := by decide
theorem cert_e598342844014 : check e598342844014 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342844022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e598342844022 : Closed e598342844022 ∧ code e598342844022 = 2797366099574 := by decide
theorem cert_e598342844022 : check e598342844022 [[],[.left],[]] .chain = true := by decide
def e598342844026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e598342844026 : Closed e598342844026 ∧ code e598342844026 = 2797366099578 := by decide
theorem cert_e598342844026 : check e598342844026 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e598342866654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e598342866654 : Closed e598342866654 ∧ code e598342866654 = 2797366122206 := by decide
theorem cert_e598342866654 : check e598342866654 [[],[.left],[]] .chain = true := by decide
def e598342866670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e598342866670 : Closed e598342866670 ∧ code e598342866670 = 2797366122222 := by decide
theorem cert_e598342866670 : check e598342866670 [[],[.left],[]] .sourceHead = true := by decide
def e598342866678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e598342866678 : Closed e598342866678 ∧ code e598342866678 = 2797366122230 := by decide
theorem cert_e598342866678 : check e598342866678 [[],[.left],[]] .chain = true := by decide
def e598342866782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e598342866782 : Closed e598342866782 ∧ code e598342866782 = 2797366122334 := by decide
theorem cert_e598342866782 : check e598342866782 [[],[.left],[]] .chain = true := by decide
def e598342866810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e598342866810 : Closed e598342866810 ∧ code e598342866810 = 2797366122362 := by decide
theorem cert_e598342866810 : check e598342866810 [[],[.left],[]] .chain = true := by decide
def e598342866862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e598342866862 : Closed e598342866862 ∧ code e598342866862 = 2797366122414 := by decide
theorem cert_e598342866862 : check e598342866862 [[],[.left],[]] .sourceHead = true := by decide
def e598342866874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e598342866874 : Closed e598342866874 ∧ code e598342866874 = 2797366122426 := by decide
theorem cert_e598342866874 : check e598342866874 [[],[.left],[]] .sourceHead = true := by decide
def e598342866902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e598342866902 : Closed e598342866902 ∧ code e598342866902 = 2797366122454 := by decide
theorem cert_e598342866902 : check e598342866902 [[],[.left],[]] .chain = true := by decide
def e598342866906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e598342866906 : Closed e598342866906 ∧ code e598342866906 = 2797366122458 := by decide
theorem cert_e598342866906 : check e598342866906 [[],[.left],[]] .chain = true := by decide
def e598342867422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e598342867422 : Closed e598342867422 ∧ code e598342867422 = 2797366122974 := by decide
theorem cert_e598342867422 : check e598342867422 [[],[.left],[]] .chain = true := by decide
def e598342867438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e598342867438 : Closed e598342867438 ∧ code e598342867438 = 2797366122990 := by decide
theorem cert_e598342867438 : check e598342867438 [[],[.left],[]] .sourceHead = true := by decide
def e598342867446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e598342867446 : Closed e598342867446 ∧ code e598342867446 = 2797366122998 := by decide
theorem cert_e598342867446 : check e598342867446 [[],[.left],[]] .chain = true := by decide
def e598342868190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e598342868190 : Closed e598342868190 ∧ code e598342868190 = 2797366123742 := by decide
theorem cert_e598342868190 : check e598342868190 [[],[.left],[]] .chain = true := by decide
def e598342868218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e598342868218 : Closed e598342868218 ∧ code e598342868218 = 2797366123770 := by decide
theorem cert_e598342868218 : check e598342868218 [[],[.left],[]] .chain = true := by decide
def e598342868590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e598342868590 : Closed e598342868590 ∧ code e598342868590 = 2797366124142 := by decide
theorem cert_e598342868590 : check e598342868590 [[],[.left],[]] .sourceHead = true := by decide
def e598342868602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e598342868602 : Closed e598342868602 ∧ code e598342868602 = 2797366124154 := by decide
theorem cert_e598342868602 : check e598342868602 [[],[.left],[]] .sourceHead = true := by decide
def e598342868790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e598342868790 : Closed e598342868790 ∧ code e598342868790 = 2797366124342 := by decide
theorem cert_e598342868790 : check e598342868790 [[],[.left],[]] .chain = true := by decide
def e598342868794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e598342868794 : Closed e598342868794 ∧ code e598342868794 = 2797366124346 := by decide
theorem cert_e598342868794 : check e598342868794 [[],[.left],[]] .chain = true := by decide
def e598342880094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e598342880094 : Closed e598342880094 ∧ code e598342880094 = 2797366135646 := by decide
theorem cert_e598342880094 : check e598342880094 [[],[.left],[],[.under,.under]] .three = true := by decide
def e598342880110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598342880110 : Closed e598342880110 ∧ code e598342880110 = 2797366135662 := by decide
theorem cert_e598342880110 : check e598342880110 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e598342880118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598342880118 : Closed e598342880118 ∧ code e598342880118 = 2797366135670 := by decide
theorem cert_e598342880118 : check e598342880118 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e598342880122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e598342880122 : Closed e598342880122 ∧ code e598342880122 = 2797366135674 := by decide
theorem cert_e598342880122 : check e598342880122 [[],[.left],[],[.under,.under]] .three = true := by decide
def e598342880174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598342880174 : Closed e598342880174 ∧ code e598342880174 = 2797366135726 := by decide
theorem cert_e598342880174 : check e598342880174 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e598342880186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598342880186 : Closed e598342880186 ∧ code e598342880186 = 2797366135738 := by decide
theorem cert_e598342880186 : check e598342880186 [[],[.left],[],[.under,.under]] .smaller = true := by decide
end Blc.Floor41
