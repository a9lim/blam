import Extra41
import Batch139
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness605775128490
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.app u4 u0
private def u6 := Term.app u3 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775128490 : ¬ IsSelfInterpreter e605775128490 := by
  intro he
  have h : replay [] e605775128490 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775128490
end Witness605775128490
namespace Witness605775129018
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u3 u0
private def u5 := Term.var 2
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775129018 : ¬ IsSelfInterpreter e605775129018 := by
  intro he
  have h : replay [] e605775129018 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775129018
end Witness605775129018
namespace Witness605775129066
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u3 u0
private def u5 := Term.var 2
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775129066 : ¬ IsSelfInterpreter e605775129066 := by
  intro he
  have h : replay [] e605775129066 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775129066
end Witness605775129066
namespace Witness605775129498
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u3 u0
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u1
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
theorem nege605775129498 : ¬ IsSelfInterpreter e605775129498 := by
  intro he
  have h : replay [] e605775129498 = some u12 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u12) (by decide) (by decide) hj
#print axioms nege605775129498
end Witness605775129498
namespace Witness605775131498
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u0 u4
private def u6 := Term.app u3 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775131498 : ¬ IsSelfInterpreter e605775131498 := by
  intro he
  have h : replay [] e605775131498 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775131498
end Witness605775131498
namespace Witness605775131562
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u4 u0
private def u6 := Term.app u3 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775131562 : ¬ IsSelfInterpreter e605775131562 := by
  intro he
  have h : replay [] e605775131562 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775131562
end Witness605775131562
namespace Witness605775131866
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u0
private def u5 := Term.var 1
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775131866 : ¬ IsSelfInterpreter e605775131866 := by
  intro he
  have h : replay [] e605775131866 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775131866
end Witness605775131866
namespace Witness605775131882
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u0
private def u5 := Term.var 1
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775131882 : ¬ IsSelfInterpreter e605775131882 := by
  intro he
  have h : replay [] e605775131882 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775131882
end Witness605775131882
end Blc.Floor41
