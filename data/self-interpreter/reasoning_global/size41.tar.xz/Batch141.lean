import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605791777726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 4))))))))))
theorem wire_e605791777726 : Closed e605791777726 ∧ code e605791777726 = 2804815033278 := by decide
theorem cert_e605791777726 : check e605791777726 [[],[],[],[]] .three = true := by decide
def e605791777782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.var 1))))))))))
theorem wire_e605791777782 : Closed e605791777782 ∧ code e605791777782 = 2804815033334 := by decide
theorem cert_e605791777782 : check e605791777782 [[],[],[],[]] .three = true := by decide
def e605791779262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 4))))))))))
theorem wire_e605791779262 : Closed e605791779262 ∧ code e605791779262 = 2804815034814 := by decide
theorem cert_e605791779262 : check e605791779262 [[],[],[],[]] .three = true := by decide
def e605791779322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 4) (.var 0))))))))))
theorem wire_e605791779322 : Closed e605791779322 ∧ code e605791779322 = 2804815034874 := by decide
theorem cert_e605791779322 : check e605791779322 [[],[],[],[]] .three = true := by decide
def e605791780062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 3))))))))))
theorem wire_e605791780062 : Closed e605791780062 ∧ code e605791780062 = 2804815035614 := by decide
theorem cert_e605791780062 : check e605791780062 [[],[],[],[]] .three = true := by decide
def e605791780078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 2))))))))))
theorem wire_e605791780078 : Closed e605791780078 ∧ code e605791780078 = 2804815035630 := by decide
theorem cert_e605791780078 : check e605791780078 [[],[],[],[]] .three = true := by decide
def e605791780086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.var 1))))))))))
theorem wire_e605791780086 : Closed e605791780086 ∧ code e605791780086 = 2804815035638 := by decide
theorem cert_e605791780086 : check e605791780086 [[],[],[],[]] .three = true := by decide
def e605791780090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 3) (.var 0))))))))))
theorem wire_e605791780090 : Closed e605791780090 ∧ code e605791780090 = 2804815035642 := by decide
theorem cert_e605791780090 : check e605791780090 [[],[],[],[]] .three = true := by decide
def e605791892958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e605791892958 : Closed e605791892958 ∧ code e605791892958 = 2804815148510 := by decide
theorem cert_e605791892958 : check e605791892958 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e605791892974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e605791892974 : Closed e605791892974 ∧ code e605791892974 = 2804815148526 := by decide
theorem cert_e605791892974 : check e605791892974 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605791893214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e605791893214 : Closed e605791893214 ∧ code e605791893214 = 2804815148766 := by decide
theorem cert_e605791893214 : check e605791893214 [[],[],[],[]] .chain = true := by decide
def e605791893230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e605791893230 : Closed e605791893230 ∧ code e605791893230 = 2804815148782 := by decide
theorem cert_e605791893230 : check e605791893230 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605791893238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e605791893238 : Closed e605791893238 ∧ code e605791893238 = 2804815148790 := by decide
theorem cert_e605791893238 : check e605791893238 [[],[],[],[]] .chain = true := by decide
def e605791893342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e605791893342 : Closed e605791893342 ∧ code e605791893342 = 2804815148894 := by decide
theorem cert_e605791893342 : check e605791893342 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e605791893358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e605791893358 : Closed e605791893358 ∧ code e605791893358 = 2804815148910 := by decide
theorem cert_e605791893358 : check e605791893358 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605791893366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e605791893366 : Closed e605791893366 ∧ code e605791893366 = 2804815148918 := by decide
theorem cert_e605791893366 : check e605791893366 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791893370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e605791893370 : Closed e605791893370 ∧ code e605791893370 = 2804815148922 := by decide
theorem cert_e605791893370 : check e605791893370 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791893422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e605791893422 : Closed e605791893422 ∧ code e605791893422 = 2804815148974 := by decide
theorem cert_e605791893422 : check e605791893422 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791893430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e605791893430 : Closed e605791893430 ∧ code e605791893430 = 2804815148982 := by decide
theorem cert_e605791893430 : check e605791893430 [[],[],[],[]] .chain = true := by decide
def e605791893434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e605791893434 : Closed e605791893434 ∧ code e605791893434 = 2804815148986 := by decide
theorem cert_e605791893434 : check e605791893434 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791894238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e605791894238 : Closed e605791894238 ∧ code e605791894238 = 2804815149790 := by decide
theorem cert_e605791894238 : check e605791894238 [[],[],[],[]] .chain = true := by decide
def e605791894254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e605791894254 : Closed e605791894254 ∧ code e605791894254 = 2804815149806 := by decide
theorem cert_e605791894254 : check e605791894254 [[],[],[],[]] .sourceHead = true := by decide
def e605791894262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e605791894262 : Closed e605791894262 ∧ code e605791894262 = 2804815149814 := by decide
theorem cert_e605791894262 : check e605791894262 [[],[],[],[]] .chain = true := by decide
def e605791894366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e605791894366 : Closed e605791894366 ∧ code e605791894366 = 2804815149918 := by decide
theorem cert_e605791894366 : check e605791894366 [[],[],[],[]] .chain = true := by decide
def e605791894394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e605791894394 : Closed e605791894394 ∧ code e605791894394 = 2804815149946 := by decide
theorem cert_e605791894394 : check e605791894394 [[],[],[],[]] .chain = true := by decide
def e605791894446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e605791894446 : Closed e605791894446 ∧ code e605791894446 = 2804815149998 := by decide
theorem cert_e605791894446 : check e605791894446 [[],[],[],[]] .sourceHead = true := by decide
def e605791894458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e605791894458 : Closed e605791894458 ∧ code e605791894458 = 2804815150010 := by decide
theorem cert_e605791894458 : check e605791894458 [[],[],[],[]] .sourceHead = true := by decide
def e605791894486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e605791894486 : Closed e605791894486 ∧ code e605791894486 = 2804815150038 := by decide
theorem cert_e605791894486 : check e605791894486 [[],[],[],[]] .chain = true := by decide
def e605791894490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e605791894490 : Closed e605791894490 ∧ code e605791894490 = 2804815150042 := by decide
theorem cert_e605791894490 : check e605791894490 [[],[],[],[]] .chain = true := by decide
def e605791894878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e605791894878 : Closed e605791894878 ∧ code e605791894878 = 2804815150430 := by decide
theorem cert_e605791894878 : check e605791894878 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left,.left]] .identityHead = true := by decide
def e605791894894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605791894894 : Closed e605791894894 ∧ code e605791894894 = 2804815150446 := by decide
theorem cert_e605791894894 : check e605791894894 [[],[],[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605791894902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605791894902 : Closed e605791894902 ∧ code e605791894902 = 2804815150454 := by decide
theorem cert_e605791894902 : check e605791894902 [[],[],[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605791894906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e605791894906 : Closed e605791894906 ∧ code e605791894906 = 2804815150458 := by decide
theorem cert_e605791894906 : check e605791894906 [[],[],[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e605791894958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605791894958 : Closed e605791894958 ∧ code e605791894958 = 2804815150510 := by decide
theorem cert_e605791894958 : check e605791894958 [[],[],[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605791894970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605791894970 : Closed e605791894970 ∧ code e605791894970 = 2804815150522 := by decide
theorem cert_e605791894970 : check e605791894970 [[],[],[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605791894998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605791894998 : Closed e605791894998 ∧ code e605791894998 = 2804815150550 := by decide
private def t_e605791894998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem cert_e605791894998 : ¬ IsSelfInterpreter e605791894998 :=
  wSource (t := t_e605791894998) (replay_sound (ps := []) (t := e605791894998) (by decide)) (by decide)
def e605791895002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605791895002 : Closed e605791895002 ∧ code e605791895002 = 2804815150554 := by decide
private def t_e605791895002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem cert_e605791895002 : ¬ IsSelfInterpreter e605791895002 :=
  wSource (t := t_e605791895002) (replay_sound (ps := []) (t := e605791895002) (by decide)) (by decide)
def e605791895018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e605791895018 : Closed e605791895018 ∧ code e605791895018 = 2804815150570 := by decide
private def t_e605791895018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem cert_e605791895018 : ¬ IsSelfInterpreter e605791895018 :=
  wSource (t := t_e605791895018) (replay_sound (ps := []) (t := e605791895018) (by decide)) (by decide)
def e605791895214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605791895214 : Closed e605791895214 ∧ code e605791895214 = 2804815150766 := by decide
theorem cert_e605791895214 : check e605791895214 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.under,.under,.under,.under,.left,.left],[.under,.under,.under,.under,.left],[.under,.under,.under,.under],[.under,.under,.under,.under,.left,.left]] .identityHead = true := by decide
def e605791895222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e605791895222 : Closed e605791895222 ∧ code e605791895222 = 2804815150774 := by decide
theorem cert_e605791895222 : check e605791895222 [[],[],[],[]] .chain = true := by decide
def e605791895226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605791895226 : Closed e605791895226 ∧ code e605791895226 = 2804815150778 := by decide
theorem cert_e605791895226 : check e605791895226 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791895254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e605791895254 : Closed e605791895254 ∧ code e605791895254 = 2804815150806 := by decide
theorem cert_e605791895254 : check e605791895254 [[],[],[],[]] .chain = true := by decide
def e605791895258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e605791895258 : Closed e605791895258 ∧ code e605791895258 = 2804815150810 := by decide
theorem cert_e605791895258 : check e605791895258 [[],[],[],[]] .chain = true := by decide
def e605791895274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605791895274 : Closed e605791895274 ∧ code e605791895274 = 2804815150826 := by decide
private def t_e605791895274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem cert_e605791895274 : ¬ IsSelfInterpreter e605791895274 :=
  wSource (t := t_e605791895274) (replay_sound (ps := []) (t := e605791895274) (by decide)) (by decide)
def e605791899102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e605791899102 : Closed e605791899102 ∧ code e605791899102 = 2804815154654 := by decide
theorem cert_e605791899102 : check e605791899102 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791899118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e605791899118 : Closed e605791899118 ∧ code e605791899118 = 2804815154670 := by decide
theorem cert_e605791899118 : check e605791899118 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605791899358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e605791899358 : Closed e605791899358 ∧ code e605791899358 = 2804815154910 := by decide
theorem cert_e605791899358 : check e605791899358 [[],[],[],[]] .chain = true := by decide
def e605791899374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e605791899374 : Closed e605791899374 ∧ code e605791899374 = 2804815154926 := by decide
theorem cert_e605791899374 : check e605791899374 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605791899382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e605791899382 : Closed e605791899382 ∧ code e605791899382 = 2804815154934 := by decide
theorem cert_e605791899382 : check e605791899382 [[],[],[],[]] .chain = true := by decide
def e605791899486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e605791899486 : Closed e605791899486 ∧ code e605791899486 = 2804815155038 := by decide
theorem cert_e605791899486 : check e605791899486 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791899502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e605791899502 : Closed e605791899502 ∧ code e605791899502 = 2804815155054 := by decide
theorem cert_e605791899502 : check e605791899502 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e605791899510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e605791899510 : Closed e605791899510 ∧ code e605791899510 = 2804815155062 := by decide
theorem cert_e605791899510 : check e605791899510 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e605791899514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e605791899514 : Closed e605791899514 ∧ code e605791899514 = 2804815155066 := by decide
theorem cert_e605791899514 : check e605791899514 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e605791899566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e605791899566 : Closed e605791899566 ∧ code e605791899566 = 2804815155118 := by decide
theorem cert_e605791899566 : check e605791899566 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791899574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e605791899574 : Closed e605791899574 ∧ code e605791899574 = 2804815155126 := by decide
theorem cert_e605791899574 : check e605791899574 [[],[],[],[]] .chain = true := by decide
def e605791899578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e605791899578 : Closed e605791899578 ∧ code e605791899578 = 2804815155130 := by decide
theorem cert_e605791899578 : check e605791899578 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e605791900638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e605791900638 : Closed e605791900638 ∧ code e605791900638 = 2804815156190 := by decide
theorem cert_e605791900638 : check e605791900638 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791900654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e605791900654 : Closed e605791900654 ∧ code e605791900654 = 2804815156206 := by decide
theorem cert_e605791900654 : check e605791900654 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791902174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605791902174 : Closed e605791902174 ∧ code e605791902174 = 2804815157726 := by decide
theorem cert_e605791902174 : check e605791902174 [[],[],[],[]] .chain = true := by decide
def e605791902190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e605791902190 : Closed e605791902190 ∧ code e605791902190 = 2804815157742 := by decide
theorem cert_e605791902190 : check e605791902190 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605791902198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605791902198 : Closed e605791902198 ∧ code e605791902198 = 2804815157750 := by decide
theorem cert_e605791902198 : check e605791902198 [[],[],[],[]] .chain = true := by decide
def e605791902942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605791902942 : Closed e605791902942 ∧ code e605791902942 = 2804815158494 := by decide
theorem cert_e605791902942 : check e605791902942 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791902958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605791902958 : Closed e605791902958 ∧ code e605791902958 = 2804815158510 := by decide
theorem cert_e605791902958 : check e605791902958 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791902966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605791902966 : Closed e605791902966 ∧ code e605791902966 = 2804815158518 := by decide
theorem cert_e605791902966 : check e605791902966 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791902970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605791902970 : Closed e605791902970 ∧ code e605791902970 = 2804815158522 := by decide
theorem cert_e605791902970 : check e605791902970 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e605791903342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605791903342 : Closed e605791903342 ∧ code e605791903342 = 2804815158894 := by decide
theorem cert_e605791903342 : check e605791903342 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791903350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605791903350 : Closed e605791903350 ∧ code e605791903350 = 2804815158902 := by decide
theorem cert_e605791903350 : check e605791903350 [[],[],[],[]] .chain = true := by decide
def e605791903354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605791903354 : Closed e605791903354 ∧ code e605791903354 = 2804815158906 := by decide
theorem cert_e605791903354 : check e605791903354 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791904734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 3))))))))
theorem wire_e605791904734 : Closed e605791904734 ∧ code e605791904734 = 2804815160286 := by decide
theorem cert_e605791904734 : checkPay e605791904734 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605791904750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 2))))))))
theorem wire_e605791904750 : Closed e605791904750 ∧ code e605791904750 = 2804815160302 := by decide
theorem cert_e605791904750 : checkPay e605791904750 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605791905502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e605791905502 : Closed e605791905502 ∧ code e605791905502 = 2804815161054 := by decide
theorem cert_e605791905502 : check e605791905502 [[],[],[],[]] .chain = true := by decide
def e605791905518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e605791905518 : Closed e605791905518 ∧ code e605791905518 = 2804815161070 := by decide
theorem cert_e605791905518 : checkPay e605791905518 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left]] = true := by decide
def e605791905526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e605791905526 : Closed e605791905526 ∧ code e605791905526 = 2804815161078 := by decide
theorem cert_e605791905526 : check e605791905526 [[],[],[],[]] .chain = true := by decide
def e605791905630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e605791905630 : Closed e605791905630 ∧ code e605791905630 = 2804815161182 := by decide
theorem cert_e605791905630 : check e605791905630 [[],[],[],[]] .chain = true := by decide
def e605791905658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e605791905658 : Closed e605791905658 ∧ code e605791905658 = 2804815161210 := by decide
theorem cert_e605791905658 : check e605791905658 [[],[],[],[]] .chain = true := by decide
def e605791905710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e605791905710 : Closed e605791905710 ∧ code e605791905710 = 2804815161262 := by decide
theorem cert_e605791905710 : checkPay e605791905710 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e605791905722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e605791905722 : Closed e605791905722 ∧ code e605791905722 = 2804815161274 := by decide
theorem cert_e605791905722 : checkPay e605791905722 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e605791905750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e605791905750 : Closed e605791905750 ∧ code e605791905750 = 2804815161302 := by decide
theorem cert_e605791905750 : check e605791905750 [[],[],[],[]] .chain = true := by decide
def e605791905754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e605791905754 : Closed e605791905754 ∧ code e605791905754 = 2804815161306 := by decide
theorem cert_e605791905754 : check e605791905754 [[],[],[],[]] .chain = true := by decide
def e605791906270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605791906270 : Closed e605791906270 ∧ code e605791906270 = 2804815161822 := by decide
theorem cert_e605791906270 : check e605791906270 [[],[],[],[]] .chain = true := by decide
def e605791906286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e605791906286 : Closed e605791906286 ∧ code e605791906286 = 2804815161838 := by decide
theorem cert_e605791906286 : checkPay e605791906286 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605791906294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605791906294 : Closed e605791906294 ∧ code e605791906294 = 2804815161846 := by decide
theorem cert_e605791906294 : check e605791906294 [[],[],[],[]] .chain = true := by decide
def e605791907038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605791907038 : Closed e605791907038 ∧ code e605791907038 = 2804815162590 := by decide
theorem cert_e605791907038 : check e605791907038 [[],[],[],[]] .chain = true := by decide
def e605791907066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605791907066 : Closed e605791907066 ∧ code e605791907066 = 2804815162618 := by decide
theorem cert_e605791907066 : check e605791907066 [[],[],[],[]] .chain = true := by decide
def e605791907390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e605791907390 : Closed e605791907390 ∧ code e605791907390 = 2804815162942 := by decide
theorem cert_e605791907390 : checkPay e605791907390 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605791907438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605791907438 : Closed e605791907438 ∧ code e605791907438 = 2804815162990 := by decide
theorem cert_e605791907438 : checkPay e605791907438 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605791907450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605791907450 : Closed e605791907450 ∧ code e605791907450 = 2804815163002 := by decide
theorem cert_e605791907450 : checkPay e605791907450 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605791907614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e605791907614 : Closed e605791907614 ∧ code e605791907614 = 2804815163166 := by decide
theorem cert_e605791907614 : checkPay e605791907614 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605791907638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605791907638 : Closed e605791907638 ∧ code e605791907638 = 2804815163190 := by decide
theorem cert_e605791907638 : check e605791907638 [[],[],[],[]] .chain = true := by decide
def e605791907642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605791907642 : Closed e605791907642 ∧ code e605791907642 = 2804815163194 := by decide
theorem cert_e605791907642 : check e605791907642 [[],[],[],[]] .chain = true := by decide
def e605791908318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 3))))))))
theorem wire_e605791908318 : Closed e605791908318 ∧ code e605791908318 = 2804815163870 := by decide
theorem cert_e605791908318 : check e605791908318 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605791908342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 1))))))))
theorem wire_e605791908342 : Closed e605791908342 ∧ code e605791908342 = 2804815163894 := by decide
theorem cert_e605791908342 : check e605791908342 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605791908702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e605791908702 : Closed e605791908702 ∧ code e605791908702 = 2804815164254 := by decide
theorem cert_e605791908702 : check e605791908702 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605791908718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605791908718 : Closed e605791908718 ∧ code e605791908718 = 2804815164270 := by decide
theorem cert_e605791908718 : check e605791908718 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e605791908726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605791908726 : Closed e605791908726 ∧ code e605791908726 = 2804815164278 := by decide
theorem cert_e605791908726 : check e605791908726 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605791908730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e605791908730 : Closed e605791908730 ∧ code e605791908730 = 2804815164282 := by decide
theorem cert_e605791908730 : check e605791908730 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605791908782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605791908782 : Closed e605791908782 ∧ code e605791908782 = 2804815164334 := by decide
theorem cert_e605791908782 : check e605791908782 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e605791908794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605791908794 : Closed e605791908794 ∧ code e605791908794 = 2804815164346 := by decide
theorem cert_e605791908794 : check e605791908794 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605791908822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605791908822 : Closed e605791908822 ∧ code e605791908822 = 2804815164374 := by decide
theorem cert_e605791908822 : check e605791908822 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605791908826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605791908826 : Closed e605791908826 ∧ code e605791908826 = 2804815164378 := by decide
theorem cert_e605791908826 : check e605791908826 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605791908842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e605791908842 : Closed e605791908842 ∧ code e605791908842 = 2804815164394 := by decide
theorem cert_e605791908842 : check e605791908842 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605791909086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605791909086 : Closed e605791909086 ∧ code e605791909086 = 2804815164638 := by decide
theorem cert_e605791909086 : check e605791909086 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605791909102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605791909102 : Closed e605791909102 ∧ code e605791909102 = 2804815164654 := by decide
theorem cert_e605791909102 : check e605791909102 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e605791909110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605791909110 : Closed e605791909110 ∧ code e605791909110 = 2804815164662 := by decide
theorem cert_e605791909110 : check e605791909110 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e605791909114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605791909114 : Closed e605791909114 ∧ code e605791909114 = 2804815164666 := by decide
theorem cert_e605791909114 : check e605791909114 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605791909438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e605791909438 : Closed e605791909438 ∧ code e605791909438 = 2804815164990 := by decide
theorem cert_e605791909438 : check e605791909438 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605791909486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605791909486 : Closed e605791909486 ∧ code e605791909486 = 2804815165038 := by decide
theorem cert_e605791909486 : check e605791909486 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e605791909498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605791909498 : Closed e605791909498 ∧ code e605791909498 = 2804815165050 := by decide
theorem cert_e605791909498 : check e605791909498 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e605791909686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605791909686 : Closed e605791909686 ∧ code e605791909686 = 2804815165238 := by decide
private def t_e605791909686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem cert_e605791909686 : ¬ IsSelfInterpreter e605791909686 :=
  wSource (t := t_e605791909686) (replay_sound (ps := []) (t := e605791909686) (by decide)) (by decide)
def e605791909690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605791909690 : Closed e605791909690 ∧ code e605791909690 = 2804815165242 := by decide
private def t_e605791909690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem cert_e605791909690 : ¬ IsSelfInterpreter e605791909690 :=
  wSource (t := t_e605791909690) (replay_sound (ps := []) (t := e605791909690) (by decide)) (by decide)
def e605791909774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e605791909774 : Closed e605791909774 ∧ code e605791909774 = 2804815165326 := by decide
private def t_e605791909774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 2)))))))))
theorem cert_e605791909774 : ¬ IsSelfInterpreter e605791909774 :=
  wSource (t := t_e605791909774) (replay_sound (ps := []) (t := e605791909774) (by decide)) (by decide)
def e605791909786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605791909786 : Closed e605791909786 ∧ code e605791909786 = 2804815165338 := by decide
private def t_e605791909786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem cert_e605791909786 : ¬ IsSelfInterpreter e605791909786 :=
  wSource (t := t_e605791909786) (replay_sound (ps := []) (t := e605791909786) (by decide)) (by decide)
def e605791910126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605791910126 : Closed e605791910126 ∧ code e605791910126 = 2804815165678 := by decide
theorem cert_e605791910126 : check e605791910126 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e605791910134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605791910134 : Closed e605791910134 ∧ code e605791910134 = 2804815165686 := by decide
theorem cert_e605791910134 : check e605791910134 [[],[],[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e605791910318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605791910318 : Closed e605791910318 ∧ code e605791910318 = 2804815165870 := by decide
theorem cert_e605791910318 : check e605791910318 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left]] .identityHead = true := by decide
def e605791910326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e605791910326 : Closed e605791910326 ∧ code e605791910326 = 2804815165878 := by decide
theorem cert_e605791910326 : check e605791910326 [[],[],[],[]] .chain = true := by decide
def e605791910330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605791910330 : Closed e605791910330 ∧ code e605791910330 = 2804815165882 := by decide
def e605791910358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e605791910358 : Closed e605791910358 ∧ code e605791910358 = 2804815165910 := by decide
theorem cert_e605791910358 : check e605791910358 [[],[],[],[]] .chain = true := by decide
def e605791910362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e605791910362 : Closed e605791910362 ∧ code e605791910362 = 2804815165914 := by decide
theorem cert_e605791910362 : check e605791910362 [[],[],[],[]] .chain = true := by decide
def e605791910378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605791910378 : Closed e605791910378 ∧ code e605791910378 = 2804815165930 := by decide
theorem cert_e605791910378 : check e605791910378 [[],[],[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e605791910510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605791910510 : Closed e605791910510 ∧ code e605791910510 = 2804815166062 := by decide
theorem cert_e605791910510 : check e605791910510 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791910518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605791910518 : Closed e605791910518 ∧ code e605791910518 = 2804815166070 := by decide
theorem cert_e605791910518 : check e605791910518 [[],[],[],[]] .chain = true := by decide
def e605791910522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605791910522 : Closed e605791910522 ∧ code e605791910522 = 2804815166074 := by decide
theorem cert_e605791910522 : check e605791910522 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left]] .identityHead = true := by decide
def e605791910686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605791910686 : Closed e605791910686 ∧ code e605791910686 = 2804815166238 := by decide
theorem cert_e605791910686 : check e605791910686 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e605791910710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605791910710 : Closed e605791910710 ∧ code e605791910710 = 2804815166262 := by decide
theorem cert_e605791910710 : check e605791910710 [[],[],[],[]] .chain = true := by decide
def e605791910714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605791910714 : Closed e605791910714 ∧ code e605791910714 = 2804815166266 := by decide
theorem cert_e605791910714 : check e605791910714 [[],[],[],[]] .chain = true := by decide
def e605791910798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605791910798 : Closed e605791910798 ∧ code e605791910798 = 2804815166350 := by decide
private def t_e605791910798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 2)))))))))
theorem cert_e605791910798 : ¬ IsSelfInterpreter e605791910798 :=
  wSource (t := t_e605791910798) (replay_sound (ps := []) (t := e605791910798) (by decide)) (by decide)
def e605791910810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605791910810 : Closed e605791910810 ∧ code e605791910810 = 2804815166362 := by decide
private def t_e605791910810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem cert_e605791910810 : ¬ IsSelfInterpreter e605791910810 :=
  wSource (t := t_e605791910810) (replay_sound (ps := []) (t := e605791910810) (by decide)) (by decide)
def e605791914862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605791914862 : Closed e605791914862 ∧ code e605791914862 = 2804815170414 := by decide
theorem cert_e605791914862 : check e605791914862 [[],[],[],[]] .smaller = true := by decide
def e605791914870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605791914870 : Closed e605791914870 ∧ code e605791914870 = 2804815170422 := by decide
theorem cert_e605791914870 : check e605791914870 [[],[],[],[]] .smaller = true := by decide
def e605791914926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605791914926 : Closed e605791914926 ∧ code e605791914926 = 2804815170478 := by decide
theorem cert_e605791914926 : check e605791914926 [[],[],[],[]] .smaller = true := by decide
def e605791914938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605791914938 : Closed e605791914938 ∧ code e605791914938 = 2804815170490 := by decide
theorem cert_e605791914938 : check e605791914938 [[],[],[],[]] .smaller = true := by decide
def e605791914966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605791914966 : Closed e605791914966 ∧ code e605791914966 = 2804815170518 := by decide
theorem cert_e605791914966 : check e605791914966 [[],[],[],[]] .smaller = true := by decide
def e605791914970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605791914970 : Closed e605791914970 ∧ code e605791914970 = 2804815170522 := by decide
theorem cert_e605791914970 : check e605791914970 [[],[],[],[]] .smaller = true := by decide
def e605791915246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605791915246 : Closed e605791915246 ∧ code e605791915246 = 2804815170798 := by decide
theorem cert_e605791915246 : check e605791915246 [[],[],[],[]] .smaller = true := by decide
def e605791915254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605791915254 : Closed e605791915254 ∧ code e605791915254 = 2804815170806 := by decide
theorem cert_e605791915254 : check e605791915254 [[],[],[],[]] .smaller = true := by decide
def e605791915630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605791915630 : Closed e605791915630 ∧ code e605791915630 = 2804815171182 := by decide
theorem cert_e605791915630 : check e605791915630 [[],[],[],[]] .smaller = true := by decide
def e605791915642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605791915642 : Closed e605791915642 ∧ code e605791915642 = 2804815171194 := by decide
theorem cert_e605791915642 : check e605791915642 [[],[],[],[]] .smaller = true := by decide
def e605791915830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605791915830 : Closed e605791915830 ∧ code e605791915830 = 2804815171382 := by decide
theorem cert_e605791915830 : check e605791915830 [[],[],[],[]] .smaller = true := by decide
def e605791915834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605791915834 : Closed e605791915834 ∧ code e605791915834 = 2804815171386 := by decide
theorem cert_e605791915834 : check e605791915834 [[],[],[],[]] .smaller = true := by decide
def e605791915966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e605791915966 : Closed e605791915966 ∧ code e605791915966 = 2804815171518 := by decide
theorem cert_e605791915966 : check e605791915966 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e605791915998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e605791915998 : Closed e605791915998 ∧ code e605791915998 = 2804815171550 := by decide
theorem cert_e605791915998 : check e605791915998 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[.left],[]] .identityHead = true := by decide
def e605791923678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605791923678 : Closed e605791923678 ∧ code e605791923678 = 2804815179230 := by decide
theorem cert_e605791923678 : check e605791923678 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791923694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605791923694 : Closed e605791923694 ∧ code e605791923694 = 2804815179246 := by decide
theorem cert_e605791923694 : check e605791923694 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791923934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e605791923934 : Closed e605791923934 ∧ code e605791923934 = 2804815179486 := by decide
theorem cert_e605791923934 : check e605791923934 [[],[],[],[]] .chain = true := by decide
def e605791923950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e605791923950 : Closed e605791923950 ∧ code e605791923950 = 2804815179502 := by decide
theorem cert_e605791923950 : check e605791923950 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605791923958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e605791923958 : Closed e605791923958 ∧ code e605791923958 = 2804815179510 := by decide
theorem cert_e605791923958 : check e605791923958 [[],[],[],[]] .chain = true := by decide
def e605791924062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605791924062 : Closed e605791924062 ∧ code e605791924062 = 2804815179614 := by decide
theorem cert_e605791924062 : check e605791924062 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605791924078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e605791924078 : Closed e605791924078 ∧ code e605791924078 = 2804815179630 := by decide
theorem cert_e605791924078 : checkPay e605791924078 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605791924086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e605791924086 : Closed e605791924086 ∧ code e605791924086 = 2804815179638 := by decide
theorem cert_e605791924086 : check e605791924086 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605791924090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605791924090 : Closed e605791924090 ∧ code e605791924090 = 2804815179642 := by decide
theorem cert_e605791924090 : check e605791924090 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e605791924142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605791924142 : Closed e605791924142 ∧ code e605791924142 = 2804815179694 := by decide
theorem cert_e605791924142 : check e605791924142 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e605791924150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e605791924150 : Closed e605791924150 ∧ code e605791924150 = 2804815179702 := by decide
theorem cert_e605791924150 : check e605791924150 [[],[],[],[]] .chain = true := by decide
def e605791924154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605791924154 : Closed e605791924154 ∧ code e605791924154 = 2804815179706 := by decide
theorem cert_e605791924154 : check e605791924154 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605791925214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605791925214 : Closed e605791925214 ∧ code e605791925214 = 2804815180766 := by decide
theorem cert_e605791925214 : check e605791925214 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e605791925230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605791925230 : Closed e605791925230 ∧ code e605791925230 = 2804815180782 := by decide
theorem cert_e605791925230 : check e605791925230 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e605791926750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e605791926750 : Closed e605791926750 ∧ code e605791926750 = 2804815182302 := by decide
theorem cert_e605791926750 : check e605791926750 [[],[],[],[]] .chain = true := by decide
def e605791926766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e605791926766 : Closed e605791926766 ∧ code e605791926766 = 2804815182318 := by decide
theorem cert_e605791926766 : check e605791926766 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605791926774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e605791926774 : Closed e605791926774 ∧ code e605791926774 = 2804815182326 := by decide
theorem cert_e605791926774 : check e605791926774 [[],[],[],[]] .chain = true := by decide
def e605791927518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605791927518 : Closed e605791927518 ∧ code e605791927518 = 2804815183070 := by decide
theorem cert_e605791927518 : check e605791927518 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
end Blc.Floor41
