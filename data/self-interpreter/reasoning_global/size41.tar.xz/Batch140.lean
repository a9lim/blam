import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605779177134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605779177134 : Closed e605779177134 ∧ code e605779177134 = 2804802432686 := by decide
private def t_e605779177134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem cert_e605779177134 : ¬ IsSelfInterpreter e605779177134 :=
  wSource (t := t_e605779177134) (replay_sound (ps := []) (t := e605779177134) (by decide)) (by decide)
def e605779177146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605779177146 : Closed e605779177146 ∧ code e605779177146 = 2804802432698 := by decide
private def t_e605779177146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem cert_e605779177146 : ¬ IsSelfInterpreter e605779177146 :=
  wSource (t := t_e605779177146) (replay_sound (ps := []) (t := e605779177146) (by decide)) (by decide)
def e605779177194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605779177194 : Closed e605779177194 ∧ code e605779177194 = 2804802432746 := by decide
private def t_e605779177194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem cert_e605779177194 : ¬ IsSelfInterpreter e605779177194 :=
  wSource (t := t_e605779177194) (replay_sound (ps := []) (t := e605779177194) (by decide)) (by decide)
def e605779177302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605779177302 : Closed e605779177302 ∧ code e605779177302 = 2804802432854 := by decide
private def t_e605779177302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem cert_e605779177302 : ¬ IsSelfInterpreter e605779177302 :=
  wSource (t := t_e605779177302) (replay_sound (ps := []) (t := e605779177302) (by decide)) (by decide)
def e605779177306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605779177306 : Closed e605779177306 ∧ code e605779177306 = 2804802432858 := by decide
private def t_e605779177306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem cert_e605779177306 : ¬ IsSelfInterpreter e605779177306 :=
  wSource (t := t_e605779177306) (replay_sound (ps := []) (t := e605779177306) (by decide)) (by decide)
def e605779177322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605779177322 : Closed e605779177322 ∧ code e605779177322 = 2804802432874 := by decide
private def t_e605779177322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem cert_e605779177322 : ¬ IsSelfInterpreter e605779177322 :=
  wSource (t := t_e605779177322) (replay_sound (ps := []) (t := e605779177322) (by decide)) (by decide)
def e605779178350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605779178350 : Closed e605779178350 ∧ code e605779178350 = 2804802433902 := by decide
private def t_e605779178350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem cert_e605779178350 : ¬ IsSelfInterpreter e605779178350 :=
  wSource (t := t_e605779178350) (replay_sound (ps := []) (t := e605779178350) (by decide)) (by decide)
def e605779178358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605779178358 : Closed e605779178358 ∧ code e605779178358 = 2804802433910 := by decide
private def t_e605779178358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem cert_e605779178358 : ¬ IsSelfInterpreter e605779178358 :=
  wSource (t := t_e605779178358) (replay_sound (ps := []) (t := e605779178358) (by decide)) (by decide)
def e605779178414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605779178414 : Closed e605779178414 ∧ code e605779178414 = 2804802433966 := by decide
private def t_e605779178414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem cert_e605779178414 : ¬ IsSelfInterpreter e605779178414 :=
  wSource (t := t_e605779178414) (replay_sound (ps := []) (t := e605779178414) (by decide)) (by decide)
def e605779178426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605779178426 : Closed e605779178426 ∧ code e605779178426 = 2804802433978 := by decide
private def t_e605779178426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem cert_e605779178426 : ¬ IsSelfInterpreter e605779178426 :=
  wSource (t := t_e605779178426) (replay_sound (ps := []) (t := e605779178426) (by decide)) (by decide)
def e605779178454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605779178454 : Closed e605779178454 ∧ code e605779178454 = 2804802434006 := by decide
private def t_e605779178454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem cert_e605779178454 : ¬ IsSelfInterpreter e605779178454 :=
  wSource (t := t_e605779178454) (replay_sound (ps := []) (t := e605779178454) (by decide)) (by decide)
def e605779178458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605779178458 : Closed e605779178458 ∧ code e605779178458 = 2804802434010 := by decide
private def t_e605779178458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem cert_e605779178458 : ¬ IsSelfInterpreter e605779178458 :=
  wSource (t := t_e605779178458) (replay_sound (ps := []) (t := e605779178458) (by decide)) (by decide)
def e605779178734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605779178734 : Closed e605779178734 ∧ code e605779178734 = 2804802434286 := by decide
private def t_e605779178734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem cert_e605779178734 : ¬ IsSelfInterpreter e605779178734 :=
  wSource (t := t_e605779178734) (replay_sound (ps := []) (t := e605779178734) (by decide)) (by decide)
def e605779178742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605779178742 : Closed e605779178742 ∧ code e605779178742 = 2804802434294 := by decide
private def t_e605779178742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem cert_e605779178742 : ¬ IsSelfInterpreter e605779178742 :=
  wSource (t := t_e605779178742) (replay_sound (ps := []) (t := e605779178742) (by decide)) (by decide)
def e605779179118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605779179118 : Closed e605779179118 ∧ code e605779179118 = 2804802434670 := by decide
private def t_e605779179118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem cert_e605779179118 : ¬ IsSelfInterpreter e605779179118 :=
  wSource (t := t_e605779179118) (replay_sound (ps := []) (t := e605779179118) (by decide)) (by decide)
def e605779179130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605779179130 : Closed e605779179130 ∧ code e605779179130 = 2804802434682 := by decide
private def t_e605779179130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem cert_e605779179130 : ¬ IsSelfInterpreter e605779179130 :=
  wSource (t := t_e605779179130) (replay_sound (ps := []) (t := e605779179130) (by decide)) (by decide)
def e605779179318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605779179318 : Closed e605779179318 ∧ code e605779179318 = 2804802434870 := by decide
private def t_e605779179318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e605779179318 : ¬ IsSelfInterpreter e605779179318 :=
  wSource (t := t_e605779179318) (replay_sound (ps := []) (t := e605779179318) (by decide)) (by decide)
def e605779179322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605779179322 : Closed e605779179322 ∧ code e605779179322 = 2804802434874 := by decide
private def t_e605779179322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e605779179322 : ¬ IsSelfInterpreter e605779179322 :=
  wSource (t := t_e605779179322) (replay_sound (ps := []) (t := e605779179322) (by decide)) (by decide)
def e605779179950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605779179950 : Closed e605779179950 ∧ code e605779179950 = 2804802435502 := by decide
private def t_e605779179950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem cert_e605779179950 : ¬ IsSelfInterpreter e605779179950 :=
  wSource (t := t_e605779179950) (replay_sound (ps := []) (t := e605779179950) (by decide)) (by decide)
def e605779179962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605779179962 : Closed e605779179962 ∧ code e605779179962 = 2804802435514 := by decide
private def t_e605779179962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem cert_e605779179962 : ¬ IsSelfInterpreter e605779179962 :=
  wSource (t := t_e605779179962) (replay_sound (ps := []) (t := e605779179962) (by decide)) (by decide)
def e605779180010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605779180010 : Closed e605779180010 ∧ code e605779180010 = 2804802435562 := by decide
private def t_e605779180010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem cert_e605779180010 : ¬ IsSelfInterpreter e605779180010 :=
  wSource (t := t_e605779180010) (replay_sound (ps := []) (t := e605779180010) (by decide)) (by decide)
def e605779180142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605779180142 : Closed e605779180142 ∧ code e605779180142 = 2804802435694 := by decide
private def t_e605779180142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem cert_e605779180142 : ¬ IsSelfInterpreter e605779180142 :=
  wSource (t := t_e605779180142) (replay_sound (ps := []) (t := e605779180142) (by decide)) (by decide)
def e605779180154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605779180154 : Closed e605779180154 ∧ code e605779180154 = 2804802435706 := by decide
private def t_e605779180154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem cert_e605779180154 : ¬ IsSelfInterpreter e605779180154 :=
  wSource (t := t_e605779180154) (replay_sound (ps := []) (t := e605779180154) (by decide)) (by decide)
def e605779180442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605779180442 : Closed e605779180442 ∧ code e605779180442 = 2804802435994 := by decide
private def t_e605779180442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem cert_e605779180442 : ¬ IsSelfInterpreter e605779180442 :=
  wSource (t := t_e605779180442) (replay_sound (ps := []) (t := e605779180442) (by decide)) (by decide)
def e605779180758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605779180758 : Closed e605779180758 ∧ code e605779180758 = 2804802436310 := by decide
private def t_e605779180758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem cert_e605779180758 : ¬ IsSelfInterpreter e605779180758 :=
  wSource (t := t_e605779180758) (replay_sound (ps := []) (t := e605779180758) (by decide)) (by decide)
def e605779180762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605779180762 : Closed e605779180762 ∧ code e605779180762 = 2804802436314 := by decide
private def t_e605779180762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem cert_e605779180762 : ¬ IsSelfInterpreter e605779180762 :=
  wSource (t := t_e605779180762) (replay_sound (ps := []) (t := e605779180762) (by decide)) (by decide)
def e605779180778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605779180778 : Closed e605779180778 ∧ code e605779180778 = 2804802436330 := by decide
private def t_e605779180778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem cert_e605779180778 : ¬ IsSelfInterpreter e605779180778 :=
  wSource (t := t_e605779180778) (replay_sound (ps := []) (t := e605779180778) (by decide)) (by decide)
def e605779180854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605779180854 : Closed e605779180854 ∧ code e605779180854 = 2804802436406 := by decide
private def t_e605779180854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem cert_e605779180854 : ¬ IsSelfInterpreter e605779180854 :=
  wSource (t := t_e605779180854) (replay_sound (ps := []) (t := e605779180854) (by decide)) (by decide)
def e605779180858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605779180858 : Closed e605779180858 ∧ code e605779180858 = 2804802436410 := by decide
private def t_e605779180858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem cert_e605779180858 : ¬ IsSelfInterpreter e605779180858 :=
  wSource (t := t_e605779180858) (replay_sound (ps := []) (t := e605779180858) (by decide)) (by decide)
def e605779180954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605779180954 : Closed e605779180954 ∧ code e605779180954 = 2804802436506 := by decide
private def t_e605779180954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem cert_e605779180954 : ¬ IsSelfInterpreter e605779180954 :=
  wSource (t := t_e605779180954) (replay_sound (ps := []) (t := e605779180954) (by decide)) (by decide)
def e605779182558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e605779182558 : Closed e605779182558 ∧ code e605779182558 = 2804802438110 := by decide
private def t_e605779182558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem cert_e605779182558 : ¬ IsSelfInterpreter e605779182558 :=
  wSource (t := t_e605779182558) (replay_sound (ps := []) (t := e605779182558) (by decide)) (by decide)
def e605779182574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e605779182574 : Closed e605779182574 ∧ code e605779182574 = 2804802438126 := by decide
private def t_e605779182574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem cert_e605779182574 : ¬ IsSelfInterpreter e605779182574 :=
  wSource (t := t_e605779182574) (replay_sound (ps := []) (t := e605779182574) (by decide)) (by decide)
def e605779184494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605779184494 : Closed e605779184494 ∧ code e605779184494 = 2804802440046 := by decide
private def t_e605779184494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e605779184494 : ¬ IsSelfInterpreter e605779184494 :=
  wSource (t := t_e605779184494) (replay_sound (ps := []) (t := e605779184494) (by decide)) (by decide)
def e605779184502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605779184502 : Closed e605779184502 ∧ code e605779184502 = 2804802440054 := by decide
private def t_e605779184502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e605779184502 : ¬ IsSelfInterpreter e605779184502 :=
  wSource (t := t_e605779184502) (replay_sound (ps := []) (t := e605779184502) (by decide)) (by decide)
def e605779184558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605779184558 : Closed e605779184558 ∧ code e605779184558 = 2804802440110 := by decide
private def t_e605779184558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e605779184558 : ¬ IsSelfInterpreter e605779184558 :=
  wSource (t := t_e605779184558) (replay_sound (ps := []) (t := e605779184558) (by decide)) (by decide)
def e605779184570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605779184570 : Closed e605779184570 ∧ code e605779184570 = 2804802440122 := by decide
private def t_e605779184570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e605779184570 : ¬ IsSelfInterpreter e605779184570 :=
  wSource (t := t_e605779184570) (replay_sound (ps := []) (t := e605779184570) (by decide)) (by decide)
def e605779184598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605779184598 : Closed e605779184598 ∧ code e605779184598 = 2804802440150 := by decide
private def t_e605779184598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e605779184598 : ¬ IsSelfInterpreter e605779184598 :=
  wSource (t := t_e605779184598) (replay_sound (ps := []) (t := e605779184598) (by decide)) (by decide)
def e605779184602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605779184602 : Closed e605779184602 ∧ code e605779184602 = 2804802440154 := by decide
private def t_e605779184602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e605779184602 : ¬ IsSelfInterpreter e605779184602 :=
  wSource (t := t_e605779184602) (replay_sound (ps := []) (t := e605779184602) (by decide)) (by decide)
def e605779184878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605779184878 : Closed e605779184878 ∧ code e605779184878 = 2804802440430 := by decide
private def t_e605779184878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e605779184878 : ¬ IsSelfInterpreter e605779184878 :=
  wSource (t := t_e605779184878) (replay_sound (ps := []) (t := e605779184878) (by decide)) (by decide)
def e605779184886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605779184886 : Closed e605779184886 ∧ code e605779184886 = 2804802440438 := by decide
private def t_e605779184886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e605779184886 : ¬ IsSelfInterpreter e605779184886 :=
  wSource (t := t_e605779184886) (replay_sound (ps := []) (t := e605779184886) (by decide)) (by decide)
def e605779185262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605779185262 : Closed e605779185262 ∧ code e605779185262 = 2804802440814 := by decide
private def t_e605779185262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e605779185262 : ¬ IsSelfInterpreter e605779185262 :=
  wSource (t := t_e605779185262) (replay_sound (ps := []) (t := e605779185262) (by decide)) (by decide)
def e605779185274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605779185274 : Closed e605779185274 ∧ code e605779185274 = 2804802440826 := by decide
private def t_e605779185274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e605779185274 : ¬ IsSelfInterpreter e605779185274 :=
  wSource (t := t_e605779185274) (replay_sound (ps := []) (t := e605779185274) (by decide)) (by decide)
def e605779185462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605779185462 : Closed e605779185462 ∧ code e605779185462 = 2804802441014 := by decide
private def t_e605779185462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e605779185462 : ¬ IsSelfInterpreter e605779185462 :=
  wSource (t := t_e605779185462) (replay_sound (ps := []) (t := e605779185462) (by decide)) (by decide)
def e605779185466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605779185466 : Closed e605779185466 ∧ code e605779185466 = 2804802441018 := by decide
private def t_e605779185466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e605779185466 : ¬ IsSelfInterpreter e605779185466 :=
  wSource (t := t_e605779185466) (replay_sound (ps := []) (t := e605779185466) (by decide)) (by decide)
def e605779190238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605779190238 : Closed e605779190238 ∧ code e605779190238 = 2804802445790 := by decide
private def t_e605779190238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem cert_e605779190238 : ¬ IsSelfInterpreter e605779190238 :=
  wSource (t := t_e605779190238) (replay_sound (ps := []) (t := e605779190238) (by decide)) (by decide)
def e605779190262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605779190262 : Closed e605779190262 ∧ code e605779190262 = 2804802445814 := by decide
private def t_e605779190262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem cert_e605779190262 : ¬ IsSelfInterpreter e605779190262 :=
  wSource (t := t_e605779190262) (replay_sound (ps := []) (t := e605779190262) (by decide)) (by decide)
def e605779191214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605779191214 : Closed e605779191214 ∧ code e605779191214 = 2804802446766 := by decide
private def t_e605779191214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem cert_e605779191214 : ¬ IsSelfInterpreter e605779191214 :=
  wSource (t := t_e605779191214) (replay_sound (ps := []) (t := e605779191214) (by decide)) (by decide)
def e605779191226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605779191226 : Closed e605779191226 ∧ code e605779191226 = 2804802446778 := by decide
private def t_e605779191226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem cert_e605779191226 : ¬ IsSelfInterpreter e605779191226 :=
  wSource (t := t_e605779191226) (replay_sound (ps := []) (t := e605779191226) (by decide)) (by decide)
def e605779191274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605779191274 : Closed e605779191274 ∧ code e605779191274 = 2804802446826 := by decide
private def t_e605779191274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem cert_e605779191274 : ¬ IsSelfInterpreter e605779191274 :=
  wSource (t := t_e605779191274) (replay_sound (ps := []) (t := e605779191274) (by decide)) (by decide)
def e605779191406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605779191406 : Closed e605779191406 ∧ code e605779191406 = 2804802446958 := by decide
private def t_e605779191406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem cert_e605779191406 : ¬ IsSelfInterpreter e605779191406 :=
  wSource (t := t_e605779191406) (replay_sound (ps := []) (t := e605779191406) (by decide)) (by decide)
def e605779191418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605779191418 : Closed e605779191418 ∧ code e605779191418 = 2804802446970 := by decide
private def t_e605779191418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem cert_e605779191418 : ¬ IsSelfInterpreter e605779191418 :=
  wSource (t := t_e605779191418) (replay_sound (ps := []) (t := e605779191418) (by decide)) (by decide)
def e605779191706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605779191706 : Closed e605779191706 ∧ code e605779191706 = 2804802447258 := by decide
private def t_e605779191706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem cert_e605779191706 : ¬ IsSelfInterpreter e605779191706 :=
  wSource (t := t_e605779191706) (replay_sound (ps := []) (t := e605779191706) (by decide)) (by decide)
def e605779194094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605779194094 : Closed e605779194094 ∧ code e605779194094 = 2804802449646 := by decide
private def t_e605779194094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem cert_e605779194094 : ¬ IsSelfInterpreter e605779194094 :=
  wSource (t := t_e605779194094) (replay_sound (ps := []) (t := e605779194094) (by decide)) (by decide)
def e605779194102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605779194102 : Closed e605779194102 ∧ code e605779194102 = 2804802449654 := by decide
private def t_e605779194102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem cert_e605779194102 : ¬ IsSelfInterpreter e605779194102 :=
  wSource (t := t_e605779194102) (replay_sound (ps := []) (t := e605779194102) (by decide)) (by decide)
def e605779194582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605779194582 : Closed e605779194582 ∧ code e605779194582 = 2804802450134 := by decide
private def t_e605779194582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem cert_e605779194582 : ¬ IsSelfInterpreter e605779194582 :=
  wSource (t := t_e605779194582) (replay_sound (ps := []) (t := e605779194582) (by decide)) (by decide)
def e605779194586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605779194586 : Closed e605779194586 ∧ code e605779194586 = 2804802450138 := by decide
private def t_e605779194586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem cert_e605779194586 : ¬ IsSelfInterpreter e605779194586 :=
  wSource (t := t_e605779194586) (replay_sound (ps := []) (t := e605779194586) (by decide)) (by decide)
def e605779194602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605779194602 : Closed e605779194602 ∧ code e605779194602 = 2804802450154 := by decide
private def t_e605779194602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem cert_e605779194602 : ¬ IsSelfInterpreter e605779194602 :=
  wSource (t := t_e605779194602) (replay_sound (ps := []) (t := e605779194602) (by decide)) (by decide)
def e605779194678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605779194678 : Closed e605779194678 ∧ code e605779194678 = 2804802450230 := by decide
private def t_e605779194678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem cert_e605779194678 : ¬ IsSelfInterpreter e605779194678 :=
  wSource (t := t_e605779194678) (replay_sound (ps := []) (t := e605779194678) (by decide)) (by decide)
def e605779194682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605779194682 : Closed e605779194682 ∧ code e605779194682 = 2804802450234 := by decide
private def t_e605779194682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem cert_e605779194682 : ¬ IsSelfInterpreter e605779194682 :=
  wSource (t := t_e605779194682) (replay_sound (ps := []) (t := e605779194682) (by decide)) (by decide)
def e605779194778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605779194778 : Closed e605779194778 ∧ code e605779194778 = 2804802450330 := by decide
private def t_e605779194778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem cert_e605779194778 : ¬ IsSelfInterpreter e605779194778 :=
  wSource (t := t_e605779194778) (replay_sound (ps := []) (t := e605779194778) (by decide)) (by decide)
def e605779331950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605779331950 : Closed e605779331950 ∧ code e605779331950 = 2804802587502 := by decide
private def t_e605779331950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e605779331950 : ¬ IsSelfInterpreter e605779331950 :=
  wSource (t := t_e605779331950) (replay_sound (ps := []) (t := e605779331950) (by decide)) (by decide)
def e605779331958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605779331958 : Closed e605779331958 ∧ code e605779331958 = 2804802587510 := by decide
private def t_e605779331958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e605779331958 : ¬ IsSelfInterpreter e605779331958 :=
  wSource (t := t_e605779331958) (replay_sound (ps := []) (t := e605779331958) (by decide)) (by decide)
def e605779332014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605779332014 : Closed e605779332014 ∧ code e605779332014 = 2804802587566 := by decide
private def t_e605779332014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e605779332014 : ¬ IsSelfInterpreter e605779332014 :=
  wSource (t := t_e605779332014) (replay_sound (ps := []) (t := e605779332014) (by decide)) (by decide)
def e605779332026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605779332026 : Closed e605779332026 ∧ code e605779332026 = 2804802587578 := by decide
private def t_e605779332026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e605779332026 : ¬ IsSelfInterpreter e605779332026 :=
  wSource (t := t_e605779332026) (replay_sound (ps := []) (t := e605779332026) (by decide)) (by decide)
def e605779332054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605779332054 : Closed e605779332054 ∧ code e605779332054 = 2804802587606 := by decide
private def t_e605779332054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e605779332054 : ¬ IsSelfInterpreter e605779332054 :=
  wSource (t := t_e605779332054) (replay_sound (ps := []) (t := e605779332054) (by decide)) (by decide)
def e605779332058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605779332058 : Closed e605779332058 ∧ code e605779332058 = 2804802587610 := by decide
private def t_e605779332058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e605779332058 : ¬ IsSelfInterpreter e605779332058 :=
  wSource (t := t_e605779332058) (replay_sound (ps := []) (t := e605779332058) (by decide)) (by decide)
def e605779332334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605779332334 : Closed e605779332334 ∧ code e605779332334 = 2804802587886 := by decide
private def t_e605779332334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e605779332334 : ¬ IsSelfInterpreter e605779332334 :=
  wSource (t := t_e605779332334) (replay_sound (ps := []) (t := e605779332334) (by decide)) (by decide)
def e605779332342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605779332342 : Closed e605779332342 ∧ code e605779332342 = 2804802587894 := by decide
private def t_e605779332342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e605779332342 : ¬ IsSelfInterpreter e605779332342 :=
  wSource (t := t_e605779332342) (replay_sound (ps := []) (t := e605779332342) (by decide)) (by decide)
def e605779332718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605779332718 : Closed e605779332718 ∧ code e605779332718 = 2804802588270 := by decide
private def t_e605779332718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e605779332718 : ¬ IsSelfInterpreter e605779332718 :=
  wSource (t := t_e605779332718) (replay_sound (ps := []) (t := e605779332718) (by decide)) (by decide)
def e605779332730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605779332730 : Closed e605779332730 ∧ code e605779332730 = 2804802588282 := by decide
private def t_e605779332730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e605779332730 : ¬ IsSelfInterpreter e605779332730 :=
  wSource (t := t_e605779332730) (replay_sound (ps := []) (t := e605779332730) (by decide)) (by decide)
def e605779332918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605779332918 : Closed e605779332918 ∧ code e605779332918 = 2804802588470 := by decide
private def t_e605779332918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e605779332918 : ¬ IsSelfInterpreter e605779332918 :=
  wSource (t := t_e605779332918) (replay_sound (ps := []) (t := e605779332918) (by decide)) (by decide)
def e605779332922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605779332922 : Closed e605779332922 ∧ code e605779332922 = 2804802588474 := by decide
private def t_e605779332922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e605779332922 : ¬ IsSelfInterpreter e605779332922 :=
  wSource (t := t_e605779332922) (replay_sound (ps := []) (t := e605779332922) (by decide)) (by decide)
def e605779921774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605779921774 : Closed e605779921774 ∧ code e605779921774 = 2804803177326 := by decide
private def t_e605779921774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e605779921774 : ¬ IsSelfInterpreter e605779921774 :=
  wSource (t := t_e605779921774) (replay_sound (ps := []) (t := e605779921774) (by decide)) (by decide)
def e605779921782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605779921782 : Closed e605779921782 ∧ code e605779921782 = 2804803177334 := by decide
private def t_e605779921782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e605779921782 : ¬ IsSelfInterpreter e605779921782 :=
  wSource (t := t_e605779921782) (replay_sound (ps := []) (t := e605779921782) (by decide)) (by decide)
def e605779921838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605779921838 : Closed e605779921838 ∧ code e605779921838 = 2804803177390 := by decide
private def t_e605779921838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e605779921838 : ¬ IsSelfInterpreter e605779921838 :=
  wSource (t := t_e605779921838) (replay_sound (ps := []) (t := e605779921838) (by decide)) (by decide)
def e605779921850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605779921850 : Closed e605779921850 ∧ code e605779921850 = 2804803177402 := by decide
private def t_e605779921850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e605779921850 : ¬ IsSelfInterpreter e605779921850 :=
  wSource (t := t_e605779921850) (replay_sound (ps := []) (t := e605779921850) (by decide)) (by decide)
def e605779921878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605779921878 : Closed e605779921878 ∧ code e605779921878 = 2804803177430 := by decide
private def t_e605779921878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e605779921878 : ¬ IsSelfInterpreter e605779921878 :=
  wSource (t := t_e605779921878) (replay_sound (ps := []) (t := e605779921878) (by decide)) (by decide)
def e605779921882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605779921882 : Closed e605779921882 ∧ code e605779921882 = 2804803177434 := by decide
private def t_e605779921882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e605779921882 : ¬ IsSelfInterpreter e605779921882 :=
  wSource (t := t_e605779921882) (replay_sound (ps := []) (t := e605779921882) (by decide)) (by decide)
def e605779922158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605779922158 : Closed e605779922158 ∧ code e605779922158 = 2804803177710 := by decide
private def t_e605779922158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e605779922158 : ¬ IsSelfInterpreter e605779922158 :=
  wSource (t := t_e605779922158) (replay_sound (ps := []) (t := e605779922158) (by decide)) (by decide)
def e605779922166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605779922166 : Closed e605779922166 ∧ code e605779922166 = 2804803177718 := by decide
private def t_e605779922166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e605779922166 : ¬ IsSelfInterpreter e605779922166 :=
  wSource (t := t_e605779922166) (replay_sound (ps := []) (t := e605779922166) (by decide)) (by decide)
def e605779922542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605779922542 : Closed e605779922542 ∧ code e605779922542 = 2804803178094 := by decide
private def t_e605779922542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e605779922542 : ¬ IsSelfInterpreter e605779922542 :=
  wSource (t := t_e605779922542) (replay_sound (ps := []) (t := e605779922542) (by decide)) (by decide)
def e605779922554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605779922554 : Closed e605779922554 ∧ code e605779922554 = 2804803178106 := by decide
private def t_e605779922554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e605779922554 : ¬ IsSelfInterpreter e605779922554 :=
  wSource (t := t_e605779922554) (replay_sound (ps := []) (t := e605779922554) (by decide)) (by decide)
def e605779922742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605779922742 : Closed e605779922742 ∧ code e605779922742 = 2804803178294 := by decide
private def t_e605779922742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e605779922742 : ¬ IsSelfInterpreter e605779922742 :=
  wSource (t := t_e605779922742) (replay_sound (ps := []) (t := e605779922742) (by decide)) (by decide)
def e605779922746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605779922746 : Closed e605779922746 ∧ code e605779922746 = 2804803178298 := by decide
private def t_e605779922746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e605779922746 : ¬ IsSelfInterpreter e605779922746 :=
  wSource (t := t_e605779922746) (replay_sound (ps := []) (t := e605779922746) (by decide)) (by decide)
def e605791759726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e605791759726 : Closed e605791759726 ∧ code e605791759726 = 2804815015278 := by decide
theorem cert_e605791759726 : check e605791759726 [[],[],[],[]] .smaller = true := by decide
def e605791759734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e605791759734 : Closed e605791759734 ∧ code e605791759734 = 2804815015286 := by decide
theorem cert_e605791759734 : check e605791759734 [[],[],[],[]] .smaller = true := by decide
def e605791759790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e605791759790 : Closed e605791759790 ∧ code e605791759790 = 2804815015342 := by decide
theorem cert_e605791759790 : check e605791759790 [[],[],[],[]] .smaller = true := by decide
def e605791759802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e605791759802 : Closed e605791759802 ∧ code e605791759802 = 2804815015354 := by decide
theorem cert_e605791759802 : check e605791759802 [[],[],[],[]] .smaller = true := by decide
def e605791759830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e605791759830 : Closed e605791759830 ∧ code e605791759830 = 2804815015382 := by decide
theorem cert_e605791759830 : check e605791759830 [[],[],[],[]] .smaller = true := by decide
def e605791759834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e605791759834 : Closed e605791759834 ∧ code e605791759834 = 2804815015386 := by decide
theorem cert_e605791759834 : check e605791759834 [[],[],[],[]] .smaller = true := by decide
def e605791760046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e605791760046 : Closed e605791760046 ∧ code e605791760046 = 2804815015598 := by decide
theorem cert_e605791760046 : check e605791760046 [[],[],[],[]] .smaller = true := by decide
def e605791760058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e605791760058 : Closed e605791760058 ∧ code e605791760058 = 2804815015610 := by decide
theorem cert_e605791760058 : check e605791760058 [[],[],[],[]] .smaller = true := by decide
def e605791760106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e605791760106 : Closed e605791760106 ∧ code e605791760106 = 2804815015658 := by decide
theorem cert_e605791760106 : check e605791760106 [[],[],[],[]] .smaller = true := by decide
def e605791760214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e605791760214 : Closed e605791760214 ∧ code e605791760214 = 2804815015766 := by decide
theorem cert_e605791760214 : check e605791760214 [[],[],[],[]] .smaller = true := by decide
def e605791760218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e605791760218 : Closed e605791760218 ∧ code e605791760218 = 2804815015770 := by decide
theorem cert_e605791760218 : check e605791760218 [[],[],[],[]] .smaller = true := by decide
def e605791760234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e605791760234 : Closed e605791760234 ∧ code e605791760234 = 2804815015786 := by decide
theorem cert_e605791760234 : check e605791760234 [[],[],[],[]] .smaller = true := by decide
def e605791761262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e605791761262 : Closed e605791761262 ∧ code e605791761262 = 2804815016814 := by decide
theorem cert_e605791761262 : check e605791761262 [[],[],[],[]] .smaller = true := by decide
def e605791761270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e605791761270 : Closed e605791761270 ∧ code e605791761270 = 2804815016822 := by decide
theorem cert_e605791761270 : check e605791761270 [[],[],[],[]] .smaller = true := by decide
def e605791761326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e605791761326 : Closed e605791761326 ∧ code e605791761326 = 2804815016878 := by decide
theorem cert_e605791761326 : check e605791761326 [[],[],[],[]] .smaller = true := by decide
def e605791761338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e605791761338 : Closed e605791761338 ∧ code e605791761338 = 2804815016890 := by decide
theorem cert_e605791761338 : check e605791761338 [[],[],[],[]] .smaller = true := by decide
def e605791761366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e605791761366 : Closed e605791761366 ∧ code e605791761366 = 2804815016918 := by decide
theorem cert_e605791761366 : check e605791761366 [[],[],[],[]] .smaller = true := by decide
def e605791761370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e605791761370 : Closed e605791761370 ∧ code e605791761370 = 2804815016922 := by decide
theorem cert_e605791761370 : check e605791761370 [[],[],[],[]] .smaller = true := by decide
def e605791761646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e605791761646 : Closed e605791761646 ∧ code e605791761646 = 2804815017198 := by decide
theorem cert_e605791761646 : check e605791761646 [[],[],[],[]] .smaller = true := by decide
def e605791761654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e605791761654 : Closed e605791761654 ∧ code e605791761654 = 2804815017206 := by decide
theorem cert_e605791761654 : check e605791761654 [[],[],[],[]] .smaller = true := by decide
def e605791762030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605791762030 : Closed e605791762030 ∧ code e605791762030 = 2804815017582 := by decide
theorem cert_e605791762030 : check e605791762030 [[],[],[],[]] .smaller = true := by decide
def e605791762042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605791762042 : Closed e605791762042 ∧ code e605791762042 = 2804815017594 := by decide
theorem cert_e605791762042 : check e605791762042 [[],[],[],[]] .smaller = true := by decide
def e605791762230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605791762230 : Closed e605791762230 ∧ code e605791762230 = 2804815017782 := by decide
theorem cert_e605791762230 : check e605791762230 [[],[],[],[]] .smaller = true := by decide
def e605791762234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605791762234 : Closed e605791762234 ∧ code e605791762234 = 2804815017786 := by decide
theorem cert_e605791762234 : check e605791762234 [[],[],[],[]] .smaller = true := by decide
def e605791762366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 4)))))))))
theorem wire_e605791762366 : Closed e605791762366 ∧ code e605791762366 = 2804815017918 := by decide
theorem cert_e605791762366 : check e605791762366 [[],[],[],[]] .three = true := by decide
def e605791762398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 3)))))))))
theorem wire_e605791762398 : Closed e605791762398 ∧ code e605791762398 = 2804815017950 := by decide
theorem cert_e605791762398 : check e605791762398 [[],[],[],[]] .three = true := by decide
def e605791762862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e605791762862 : Closed e605791762862 ∧ code e605791762862 = 2804815018414 := by decide
theorem cert_e605791762862 : check e605791762862 [[],[],[],[]] .smaller = true := by decide
def e605791762874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e605791762874 : Closed e605791762874 ∧ code e605791762874 = 2804815018426 := by decide
theorem cert_e605791762874 : check e605791762874 [[],[],[],[]] .smaller = true := by decide
def e605791762922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e605791762922 : Closed e605791762922 ∧ code e605791762922 = 2804815018474 := by decide
theorem cert_e605791762922 : check e605791762922 [[],[],[],[]] .smaller = true := by decide
def e605791763054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605791763054 : Closed e605791763054 ∧ code e605791763054 = 2804815018606 := by decide
theorem cert_e605791763054 : check e605791763054 [[],[],[],[]] .smaller = true := by decide
def e605791763066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605791763066 : Closed e605791763066 ∧ code e605791763066 = 2804815018618 := by decide
theorem cert_e605791763066 : check e605791763066 [[],[],[],[]] .smaller = true := by decide
def e605791763354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605791763354 : Closed e605791763354 ∧ code e605791763354 = 2804815018906 := by decide
theorem cert_e605791763354 : check e605791763354 [[],[],[],[]] .smaller = true := by decide
def e605791763390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 4)))))))))
theorem wire_e605791763390 : Closed e605791763390 ∧ code e605791763390 = 2804815018942 := by decide
theorem cert_e605791763390 : check e605791763390 [[],[],[],[]] .three = true := by decide
def e605791763438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 2)))))))))
theorem wire_e605791763438 : Closed e605791763438 ∧ code e605791763438 = 2804815018990 := by decide
theorem cert_e605791763438 : check e605791763438 [[],[],[],[]] .three = true := by decide
def e605791763670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e605791763670 : Closed e605791763670 ∧ code e605791763670 = 2804815019222 := by decide
theorem cert_e605791763670 : check e605791763670 [[],[],[],[]] .smaller = true := by decide
def e605791763674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e605791763674 : Closed e605791763674 ∧ code e605791763674 = 2804815019226 := by decide
theorem cert_e605791763674 : check e605791763674 [[],[],[],[]] .smaller = true := by decide
def e605791763690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e605791763690 : Closed e605791763690 ∧ code e605791763690 = 2804815019242 := by decide
theorem cert_e605791763690 : check e605791763690 [[],[],[],[]] .smaller = true := by decide
def e605791763766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605791763766 : Closed e605791763766 ∧ code e605791763766 = 2804815019318 := by decide
theorem cert_e605791763766 : check e605791763766 [[],[],[],[]] .smaller = true := by decide
def e605791763770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605791763770 : Closed e605791763770 ∧ code e605791763770 = 2804815019322 := by decide
theorem cert_e605791763770 : check e605791763770 [[],[],[],[]] .smaller = true := by decide
def e605791763866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605791763866 : Closed e605791763866 ∧ code e605791763866 = 2804815019418 := by decide
theorem cert_e605791763866 : check e605791763866 [[],[],[],[]] .smaller = true := by decide
def e605791763902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 4)))))))))
theorem wire_e605791763902 : Closed e605791763902 ∧ code e605791763902 = 2804815019454 := by decide
theorem cert_e605791763902 : check e605791763902 [[],[],[],[]] .three = true := by decide
def e605791763958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 1)))))))))
theorem wire_e605791763958 : Closed e605791763958 ∧ code e605791763958 = 2804815019510 := by decide
theorem cert_e605791763958 : check e605791763958 [[],[],[],[]] .three = true := by decide
def e605791764158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 4)))))))))
theorem wire_e605791764158 : Closed e605791764158 ∧ code e605791764158 = 2804815019710 := by decide
theorem cert_e605791764158 : check e605791764158 [[],[],[],[]] .three = true := by decide
def e605791764218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 4)) (.var 0)))))))))
theorem wire_e605791764218 : Closed e605791764218 ∧ code e605791764218 = 2804815019770 := by decide
private def t_e605791764218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 4)) (.var 0)))))))))
theorem cert_e605791764218 : ¬ IsSelfInterpreter e605791764218 :=
  wSource (t := t_e605791764218) (replay_sound (ps := []) (t := e605791764218) (by decide)) (by decide)
def e605791764318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 3)))))))))
theorem wire_e605791764318 : Closed e605791764318 ∧ code e605791764318 = 2804815019870 := by decide
theorem cert_e605791764318 : check e605791764318 [[],[],[],[]] .three = true := by decide
def e605791764334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2)))))))))
theorem wire_e605791764334 : Closed e605791764334 ∧ code e605791764334 = 2804815019886 := by decide
theorem cert_e605791764334 : check e605791764334 [[],[],[],[]] .three = true := by decide
def e605791764342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 1)))))))))
theorem wire_e605791764342 : Closed e605791764342 ∧ code e605791764342 = 2804815019894 := by decide
theorem cert_e605791764342 : check e605791764342 [[],[],[],[]] .three = true := by decide
def e605791764346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 3)) (.var 0)))))))))
theorem wire_e605791764346 : Closed e605791764346 ∧ code e605791764346 = 2804815019898 := by decide
private def t_e605791764346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 3)) (.var 0)))))))))
theorem cert_e605791764346 : ¬ IsSelfInterpreter e605791764346 :=
  wSource (t := t_e605791764346) (replay_sound (ps := []) (t := e605791764346) (by decide)) (by decide)
def e605791767406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605791767406 : Closed e605791767406 ∧ code e605791767406 = 2804815022958 := by decide
theorem cert_e605791767406 : check e605791767406 [[],[],[],[]] .smaller = true := by decide
def e605791767414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605791767414 : Closed e605791767414 ∧ code e605791767414 = 2804815022966 := by decide
theorem cert_e605791767414 : check e605791767414 [[],[],[],[]] .smaller = true := by decide
def e605791767470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605791767470 : Closed e605791767470 ∧ code e605791767470 = 2804815023022 := by decide
theorem cert_e605791767470 : check e605791767470 [[],[],[],[]] .smaller = true := by decide
def e605791767482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605791767482 : Closed e605791767482 ∧ code e605791767482 = 2804815023034 := by decide
theorem cert_e605791767482 : check e605791767482 [[],[],[],[]] .smaller = true := by decide
def e605791767510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605791767510 : Closed e605791767510 ∧ code e605791767510 = 2804815023062 := by decide
theorem cert_e605791767510 : check e605791767510 [[],[],[],[]] .smaller = true := by decide
def e605791767514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605791767514 : Closed e605791767514 ∧ code e605791767514 = 2804815023066 := by decide
theorem cert_e605791767514 : check e605791767514 [[],[],[],[]] .smaller = true := by decide
def e605791767790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605791767790 : Closed e605791767790 ∧ code e605791767790 = 2804815023342 := by decide
theorem cert_e605791767790 : check e605791767790 [[],[],[],[]] .smaller = true := by decide
def e605791767798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605791767798 : Closed e605791767798 ∧ code e605791767798 = 2804815023350 := by decide
theorem cert_e605791767798 : check e605791767798 [[],[],[],[]] .smaller = true := by decide
def e605791768174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605791768174 : Closed e605791768174 ∧ code e605791768174 = 2804815023726 := by decide
theorem cert_e605791768174 : check e605791768174 [[],[],[],[]] .smaller = true := by decide
def e605791768186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605791768186 : Closed e605791768186 ∧ code e605791768186 = 2804815023738 := by decide
theorem cert_e605791768186 : check e605791768186 [[],[],[],[]] .smaller = true := by decide
def e605791768374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605791768374 : Closed e605791768374 ∧ code e605791768374 = 2804815023926 := by decide
theorem cert_e605791768374 : check e605791768374 [[],[],[],[]] .smaller = true := by decide
def e605791768378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605791768378 : Closed e605791768378 ∧ code e605791768378 = 2804815023930 := by decide
theorem cert_e605791768378 : check e605791768378 [[],[],[],[]] .smaller = true := by decide
def e605791768510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 4))))))))))
theorem wire_e605791768510 : Closed e605791768510 ∧ code e605791768510 = 2804815024062 := by decide
theorem cert_e605791768510 : check e605791768510 [[],[],[],[]] .three = true := by decide
def e605791768542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 3))))))))))
theorem wire_e605791768542 : Closed e605791768542 ∧ code e605791768542 = 2804815024094 := by decide
theorem cert_e605791768542 : check e605791768542 [[],[],[],[]] .three = true := by decide
def e605791774126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e605791774126 : Closed e605791774126 ∧ code e605791774126 = 2804815029678 := by decide
theorem cert_e605791774126 : check e605791774126 [[],[],[],[]] .smaller = true := by decide
def e605791774138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e605791774138 : Closed e605791774138 ∧ code e605791774138 = 2804815029690 := by decide
theorem cert_e605791774138 : check e605791774138 [[],[],[],[]] .smaller = true := by decide
def e605791774186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e605791774186 : Closed e605791774186 ∧ code e605791774186 = 2804815029738 := by decide
theorem cert_e605791774186 : check e605791774186 [[],[],[],[]] .smaller = true := by decide
def e605791774318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605791774318 : Closed e605791774318 ∧ code e605791774318 = 2804815029870 := by decide
theorem cert_e605791774318 : check e605791774318 [[],[],[],[]] .smaller = true := by decide
def e605791774330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605791774330 : Closed e605791774330 ∧ code e605791774330 = 2804815029882 := by decide
theorem cert_e605791774330 : check e605791774330 [[],[],[],[]] .smaller = true := by decide
def e605791774618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605791774618 : Closed e605791774618 ∧ code e605791774618 = 2804815030170 := by decide
theorem cert_e605791774618 : check e605791774618 [[],[],[],[]] .smaller = true := by decide
def e605791774654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 4))))))))))
theorem wire_e605791774654 : Closed e605791774654 ∧ code e605791774654 = 2804815030206 := by decide
theorem cert_e605791774654 : check e605791774654 [[],[],[],[]] .three = true := by decide
def e605791774702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 2))))))))))
theorem wire_e605791774702 : Closed e605791774702 ∧ code e605791774702 = 2804815030254 := by decide
theorem cert_e605791774702 : check e605791774702 [[],[],[],[]] .three = true := by decide
def e605791777494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e605791777494 : Closed e605791777494 ∧ code e605791777494 = 2804815033046 := by decide
theorem cert_e605791777494 : check e605791777494 [[],[],[],[]] .smaller = true := by decide
def e605791777498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e605791777498 : Closed e605791777498 ∧ code e605791777498 = 2804815033050 := by decide
theorem cert_e605791777498 : check e605791777498 [[],[],[],[]] .smaller = true := by decide
def e605791777514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e605791777514 : Closed e605791777514 ∧ code e605791777514 = 2804815033066 := by decide
theorem cert_e605791777514 : check e605791777514 [[],[],[],[]] .smaller = true := by decide
def e605791777590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605791777590 : Closed e605791777590 ∧ code e605791777590 = 2804815033142 := by decide
theorem cert_e605791777590 : check e605791777590 [[],[],[],[]] .smaller = true := by decide
def e605791777594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605791777594 : Closed e605791777594 ∧ code e605791777594 = 2804815033146 := by decide
theorem cert_e605791777594 : check e605791777594 [[],[],[],[]] .smaller = true := by decide
def e605791777690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605791777690 : Closed e605791777690 ∧ code e605791777690 = 2804815033242 := by decide
theorem cert_e605791777690 : check e605791777690 [[],[],[],[]] .smaller = true := by decide
end Blc.Floor41
