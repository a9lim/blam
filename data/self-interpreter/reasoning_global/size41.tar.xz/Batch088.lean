import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605593586550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605593586550 : Closed e605593586550 ∧ code e605593586550 = 2804616842102 := by decide
theorem cert_e605593586550 : check e605593586550 [[],[]] .smaller = true := by decide
def e605593586606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605593586606 : Closed e605593586606 ∧ code e605593586606 = 2804616842158 := by decide
theorem cert_e605593586606 : check e605593586606 [[],[]] .smaller = true := by decide
def e605593586618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605593586618 : Closed e605593586618 ∧ code e605593586618 = 2804616842170 := by decide
theorem cert_e605593586618 : check e605593586618 [[],[]] .smaller = true := by decide
def e605593586646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605593586646 : Closed e605593586646 ∧ code e605593586646 = 2804616842198 := by decide
theorem cert_e605593586646 : check e605593586646 [[],[]] .smaller = true := by decide
def e605593586650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605593586650 : Closed e605593586650 ∧ code e605593586650 = 2804616842202 := by decide
theorem cert_e605593586650 : check e605593586650 [[],[]] .smaller = true := by decide
def e605593586926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605593586926 : Closed e605593586926 ∧ code e605593586926 = 2804616842478 := by decide
theorem cert_e605593586926 : check e605593586926 [[],[]] .smaller = true := by decide
def e605593586934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605593586934 : Closed e605593586934 ∧ code e605593586934 = 2804616842486 := by decide
theorem cert_e605593586934 : check e605593586934 [[],[]] .smaller = true := by decide
def e605593587262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e605593587262 : Closed e605593587262 ∧ code e605593587262 = 2804616842814 := by decide
theorem cert_e605593587262 : check e605593587262 [[],[]] .smaller = true := by decide
def e605593587310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605593587310 : Closed e605593587310 ∧ code e605593587310 = 2804616842862 := by decide
theorem cert_e605593587310 : check e605593587310 [[],[]] .smaller = true := by decide
def e605593587322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605593587322 : Closed e605593587322 ∧ code e605593587322 = 2804616842874 := by decide
theorem cert_e605593587322 : check e605593587322 [[],[]] .smaller = true := by decide
def e605593587510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605593587510 : Closed e605593587510 ∧ code e605593587510 = 2804616843062 := by decide
theorem cert_e605593587510 : check e605593587510 [[],[]] .smaller = true := by decide
def e605593587514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605593587514 : Closed e605593587514 ∧ code e605593587514 = 2804616843066 := by decide
theorem cert_e605593587514 : check e605593587514 [[],[]] .smaller = true := by decide
def e605593587598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e605593587598 : Closed e605593587598 ∧ code e605593587598 = 2804616843150 := by decide
theorem cert_e605593587598 : check e605593587598 [[],[]] .smaller = true := by decide
def e605593592286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e605593592286 : Closed e605593592286 ∧ code e605593592286 = 2804616847838 := by decide
theorem cert_e605593592286 : check e605593592286 [[],[]] .smaller = true := by decide
def e605593592310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e605593592310 : Closed e605593592310 ∧ code e605593592310 = 2804616847862 := by decide
theorem cert_e605593592310 : check e605593592310 [[],[]] .smaller = true := by decide
def e605593593262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e605593593262 : Closed e605593593262 ∧ code e605593593262 = 2804616848814 := by decide
theorem cert_e605593593262 : check e605593593262 [[],[]] .smaller = true := by decide
def e605593593274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e605593593274 : Closed e605593593274 ∧ code e605593593274 = 2804616848826 := by decide
theorem cert_e605593593274 : check e605593593274 [[],[]] .smaller = true := by decide
def e605593593322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e605593593322 : Closed e605593593322 ∧ code e605593593322 = 2804616848874 := by decide
theorem cert_e605593593322 : check e605593593322 [[],[]] .smaller = true := by decide
def e605593593406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e605593593406 : Closed e605593593406 ∧ code e605593593406 = 2804616848958 := by decide
theorem cert_e605593593406 : check e605593593406 [[],[]] .smaller = true := by decide
def e605593593454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605593593454 : Closed e605593593454 ∧ code e605593593454 = 2804616849006 := by decide
theorem cert_e605593593454 : check e605593593454 [[],[]] .smaller = true := by decide
def e605593593466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605593593466 : Closed e605593593466 ∧ code e605593593466 = 2804616849018 := by decide
theorem cert_e605593593466 : check e605593593466 [[],[]] .smaller = true := by decide
def e605593593754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605593593754 : Closed e605593593754 ∧ code e605593593754 = 2804616849306 := by decide
theorem cert_e605593593754 : check e605593593754 [[],[]] .smaller = true := by decide
def e605593593790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 4))))))))))
theorem wire_e605593593790 : Closed e605593593790 ∧ code e605593593790 = 2804616849342 := by decide
theorem cert_e605593593790 : check e605593593790 [[],[]] .three = true := by decide
def e605593593798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e605593593798 : Closed e605593593798 ∧ code e605593593798 = 2804616849350 := by decide
theorem cert_e605593593798 : check e605593593798 [[],[]] .smaller = true := by decide
def e605593593838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 4) (.var 2))))))))))
theorem wire_e605593593838 : Closed e605593593838 ∧ code e605593593838 = 2804616849390 := by decide
theorem cert_e605593593838 : check e605593593838 [[],[]] .three = true := by decide
def e605593596142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e605593596142 : Closed e605593596142 ∧ code e605593596142 = 2804616851694 := by decide
theorem cert_e605593596142 : check e605593596142 [[],[]] .smaller = true := by decide
def e605593596150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e605593596150 : Closed e605593596150 ∧ code e605593596150 = 2804616851702 := by decide
theorem cert_e605593596150 : check e605593596150 [[],[]] .smaller = true := by decide
def e605593596630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e605593596630 : Closed e605593596630 ∧ code e605593596630 = 2804616852182 := by decide
theorem cert_e605593596630 : check e605593596630 [[],[]] .smaller = true := by decide
def e605593596634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e605593596634 : Closed e605593596634 ∧ code e605593596634 = 2804616852186 := by decide
theorem cert_e605593596634 : check e605593596634 [[],[]] .smaller = true := by decide
def e605593596650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e605593596650 : Closed e605593596650 ∧ code e605593596650 = 2804616852202 := by decide
theorem cert_e605593596650 : check e605593596650 [[],[]] .smaller = true := by decide
def e605593596726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605593596726 : Closed e605593596726 ∧ code e605593596726 = 2804616852278 := by decide
theorem cert_e605593596726 : check e605593596726 [[],[]] .smaller = true := by decide
def e605593596730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605593596730 : Closed e605593596730 ∧ code e605593596730 = 2804616852282 := by decide
theorem cert_e605593596730 : check e605593596730 [[],[]] .smaller = true := by decide
def e605593596826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605593596826 : Closed e605593596826 ∧ code e605593596826 = 2804616852378 := by decide
theorem cert_e605593596826 : check e605593596826 [[],[]] .smaller = true := by decide
def e605593596862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 4))))))))))
theorem wire_e605593596862 : Closed e605593596862 ∧ code e605593596862 = 2804616852414 := by decide
theorem cert_e605593596862 : check e605593596862 [[],[]] .three = true := by decide
def e605593596894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.var 3))))))))))
theorem wire_e605593596894 : Closed e605593596894 ∧ code e605593596894 = 2804616852446 := by decide
theorem cert_e605593596894 : check e605593596894 [[],[]] .smaller = true := by decide
def e605593596910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 2))))))))))
theorem wire_e605593596910 : Closed e605593596910 ∧ code e605593596910 = 2804616852462 := by decide
theorem cert_e605593596910 : check e605593596910 [[],[]] .smaller = true := by decide
def e605593596918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 4) (.var 1))))))))))
theorem wire_e605593596918 : Closed e605593596918 ∧ code e605593596918 = 2804616852470 := by decide
theorem cert_e605593596918 : check e605593596918 [[],[]] .three = true := by decide
def e605593598350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e605593598350 : Closed e605593598350 ∧ code e605593598350 = 2804616853902 := by decide
theorem cert_e605593598350 : check e605593598350 [[],[]] .smaller = true := by decide
def e605593598406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e605593598406 : Closed e605593598406 ∧ code e605593598406 = 2804616853958 := by decide
theorem cert_e605593598406 : check e605593598406 [[],[]] .smaller = true := by decide
def e605593598446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 2))))))))))
theorem wire_e605593598446 : Closed e605593598446 ∧ code e605593598446 = 2804616853998 := by decide
theorem cert_e605593598446 : check e605593598446 [[],[]] .smaller = true := by decide
def e605593599214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 1) (.var 2))))))))))
theorem wire_e605593599214 : Closed e605593599214 ∧ code e605593599214 = 2804616854766 := by decide
theorem cert_e605593599214 : check e605593599214 [[],[]] .three = true := by decide
def e605593599222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 2) (.var 1))))))))))
theorem wire_e605593599222 : Closed e605593599222 ∧ code e605593599222 = 2804616854774 := by decide
theorem cert_e605593599222 : check e605593599222 [[],[]] .three = true := by decide
def e605593679086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e605593679086 : Closed e605593679086 ∧ code e605593679086 = 2804616934638 := by decide
theorem cert_e605593679086 : check e605593679086 [[],[]] .smaller = true := by decide
def e605593679094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e605593679094 : Closed e605593679094 ∧ code e605593679094 = 2804616934646 := by decide
theorem cert_e605593679094 : check e605593679094 [[],[]] .smaller = true := by decide
def e605593710958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e605593710958 : Closed e605593710958 ∧ code e605593710958 = 2804616966510 := by decide
theorem cert_e605593710958 : check e605593710958 [[],[]] .smaller = true := by decide
def e605593710966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e605593710966 : Closed e605593710966 ∧ code e605593710966 = 2804616966518 := by decide
theorem cert_e605593710966 : check e605593710966 [[],[]] .smaller = true := by decide
def e605593712094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e605593712094 : Closed e605593712094 ∧ code e605593712094 = 2804616967646 := by decide
theorem cert_e605593712094 : check e605593712094 [[],[]] .three = true := by decide
def e605593712110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e605593712110 : Closed e605593712110 ∧ code e605593712110 = 2804616967662 := by decide
theorem cert_e605593712110 : check e605593712110 [[],[]] .three = true := by decide
def e605593712174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605593712174 : Closed e605593712174 ∧ code e605593712174 = 2804616967726 := by decide
theorem cert_e605593712174 : check e605593712174 [[],[]] .smaller = true := by decide
def e605593712350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e605593712350 : Closed e605593712350 ∧ code e605593712350 = 2804616967902 := by decide
theorem cert_e605593712350 : check e605593712350 [[],[]] .three = true := by decide
def e605593712354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605593712354 : Closed e605593712354 ∧ code e605593712354 = 2804616967906 := by decide
theorem cert_e605593712354 : check e605593712354 [[],[]] .smaller = true := by decide
def e605593712366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e605593712366 : Closed e605593712366 ∧ code e605593712366 = 2804616967918 := by decide
theorem cert_e605593712366 : check e605593712366 [[],[]] .smaller = true := by decide
def e605593712374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e605593712374 : Closed e605593712374 ∧ code e605593712374 = 2804616967926 := by decide
theorem cert_e605593712374 : check e605593712374 [[],[]] .three = true := by decide
def e605593712406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e605593712406 : Closed e605593712406 ∧ code e605593712406 = 2804616967958 := by decide
theorem cert_e605593712406 : check e605593712406 [[],[]] .smaller = true := by decide
def e605593712478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e605593712478 : Closed e605593712478 ∧ code e605593712478 = 2804616968030 := by decide
theorem cert_e605593712478 : check e605593712478 [[],[]] .three = true := by decide
def e605593712482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e605593712482 : Closed e605593712482 ∧ code e605593712482 = 2804616968034 := by decide
theorem cert_e605593712482 : check e605593712482 [[],[]] .smaller = true := by decide
def e605593712494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e605593712494 : Closed e605593712494 ∧ code e605593712494 = 2804616968046 := by decide
theorem cert_e605593712494 : check e605593712494 [[],[]] .smaller = true := by decide
def e605593712502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e605593712502 : Closed e605593712502 ∧ code e605593712502 = 2804616968054 := by decide
theorem cert_e605593712502 : check e605593712502 [[],[]] .smaller = true := by decide
def e605593712506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e605593712506 : Closed e605593712506 ∧ code e605593712506 = 2804616968058 := by decide
theorem cert_e605593712506 : check e605593712506 [[],[]] .three = true := by decide
def e605593712558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e605593712558 : Closed e605593712558 ∧ code e605593712558 = 2804616968110 := by decide
theorem cert_e605593712558 : check e605593712558 [[],[]] .three = true := by decide
def e605593712566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e605593712566 : Closed e605593712566 ∧ code e605593712566 = 2804616968118 := by decide
theorem cert_e605593712566 : check e605593712566 [[],[]] .three = true := by decide
def e605593712570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e605593712570 : Closed e605593712570 ∧ code e605593712570 = 2804616968122 := by decide
theorem cert_e605593712570 : check e605593712570 [[],[]] .three = true := by decide
def e605593712814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e605593712814 : Closed e605593712814 ∧ code e605593712814 = 2804616968366 := by decide
theorem cert_e605593712814 : check e605593712814 [[],[]] .smaller = true := by decide
def e605593712826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e605593712826 : Closed e605593712826 ∧ code e605593712826 = 2804616968378 := by decide
theorem cert_e605593712826 : check e605593712826 [[],[]] .smaller = true := by decide
def e605593713198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605593713198 : Closed e605593713198 ∧ code e605593713198 = 2804616968750 := by decide
theorem cert_e605593713198 : check e605593713198 [[],[]] .smaller = true := by decide
def e605593713374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e605593713374 : Closed e605593713374 ∧ code e605593713374 = 2804616968926 := by decide
theorem cert_e605593713374 : check e605593713374 [[],[]] .three = true := by decide
def e605593713378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605593713378 : Closed e605593713378 ∧ code e605593713378 = 2804616968930 := by decide
theorem cert_e605593713378 : check e605593713378 [[],[]] .smaller = true := by decide
def e605593713390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e605593713390 : Closed e605593713390 ∧ code e605593713390 = 2804616968942 := by decide
theorem cert_e605593713390 : check e605593713390 [[],[]] .smaller = true := by decide
def e605593713398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e605593713398 : Closed e605593713398 ∧ code e605593713398 = 2804616968950 := by decide
theorem cert_e605593713398 : check e605593713398 [[],[]] .three = true := by decide
def e605593713502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e605593713502 : Closed e605593713502 ∧ code e605593713502 = 2804616969054 := by decide
theorem cert_e605593713502 : check e605593713502 [[],[]] .three = true := by decide
def e605593713518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e605593713518 : Closed e605593713518 ∧ code e605593713518 = 2804616969070 := by decide
theorem cert_e605593713518 : check e605593713518 [[],[]] .smaller = true := by decide
def e605593713526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e605593713526 : Closed e605593713526 ∧ code e605593713526 = 2804616969078 := by decide
theorem cert_e605593713526 : check e605593713526 [[],[]] .smaller = true := by decide
def e605593713530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e605593713530 : Closed e605593713530 ∧ code e605593713530 = 2804616969082 := by decide
theorem cert_e605593713530 : check e605593713530 [[],[]] .three = true := by decide
def e605593713546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605593713546 : Closed e605593713546 ∧ code e605593713546 = 2804616969098 := by decide
theorem cert_e605593713546 : check e605593713546 [[],[]] .smaller = true := by decide
def e605593713570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605593713570 : Closed e605593713570 ∧ code e605593713570 = 2804616969122 := by decide
theorem cert_e605593713570 : check e605593713570 [[],[]] .smaller = true := by decide
def e605593713582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e605593713582 : Closed e605593713582 ∧ code e605593713582 = 2804616969134 := by decide
theorem cert_e605593713582 : check e605593713582 [[],[]] .smaller = true := by decide
def e605593713590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e605593713590 : Closed e605593713590 ∧ code e605593713590 = 2804616969142 := by decide
theorem cert_e605593713590 : check e605593713590 [[],[]] .smaller = true := by decide
def e605593713594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e605593713594 : Closed e605593713594 ∧ code e605593713594 = 2804616969146 := by decide
theorem cert_e605593713594 : check e605593713594 [[],[]] .smaller = true := by decide
def e605593713622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e605593713622 : Closed e605593713622 ∧ code e605593713622 = 2804616969174 := by decide
theorem cert_e605593713622 : check e605593713622 [[],[]] .three = true := by decide
def e605593713626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e605593713626 : Closed e605593713626 ∧ code e605593713626 = 2804616969178 := by decide
theorem cert_e605593713626 : check e605593713626 [[],[]] .three = true := by decide
def e605593713750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e605593713750 : Closed e605593713750 ∧ code e605593713750 = 2804616969302 := by decide
theorem cert_e605593713750 : check e605593713750 [[],[]] .smaller = true := by decide
def e605593713754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e605593713754 : Closed e605593713754 ∧ code e605593713754 = 2804616969306 := by decide
theorem cert_e605593713754 : check e605593713754 [[],[]] .smaller = true := by decide
def e605593713942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e605593713942 : Closed e605593713942 ∧ code e605593713942 = 2804616969494 := by decide
theorem cert_e605593713942 : check e605593713942 [[],[]] .smaller = true := by decide
def e605593714014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e605593714014 : Closed e605593714014 ∧ code e605593714014 = 2804616969566 := by decide
theorem cert_e605593714014 : check e605593714014 [[],[]] .three = true := by decide
def e605593714018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e605593714018 : Closed e605593714018 ∧ code e605593714018 = 2804616969570 := by decide
theorem cert_e605593714018 : check e605593714018 [[],[]] .smaller = true := by decide
def e605593714030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605593714030 : Closed e605593714030 ∧ code e605593714030 = 2804616969582 := by decide
theorem cert_e605593714030 : check e605593714030 [[],[]] .smaller = true := by decide
def e605593714038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605593714038 : Closed e605593714038 ∧ code e605593714038 = 2804616969590 := by decide
theorem cert_e605593714038 : check e605593714038 [[],[]] .smaller = true := by decide
def e605593714042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e605593714042 : Closed e605593714042 ∧ code e605593714042 = 2804616969594 := by decide
theorem cert_e605593714042 : check e605593714042 [[],[]] .three = true := by decide
def e605593714058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605593714058 : Closed e605593714058 ∧ code e605593714058 = 2804616969610 := by decide
theorem cert_e605593714058 : check e605593714058 [[],[]] .smaller = true := by decide
def e605593714082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605593714082 : Closed e605593714082 ∧ code e605593714082 = 2804616969634 := by decide
theorem cert_e605593714082 : check e605593714082 [[],[]] .smaller = true := by decide
def e605593714094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605593714094 : Closed e605593714094 ∧ code e605593714094 = 2804616969646 := by decide
theorem cert_e605593714094 : check e605593714094 [[],[]] .smaller = true := by decide
def e605593714102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1))))))))
theorem wire_e605593714102 : Closed e605593714102 ∧ code e605593714102 = 2804616969654 := by decide
theorem cert_e605593714102 : check e605593714102 [[],[]] .smaller = true := by decide
def e605593714106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605593714106 : Closed e605593714106 ∧ code e605593714106 = 2804616969658 := by decide
theorem cert_e605593714106 : check e605593714106 [[],[]] .smaller = true := by decide
def e605593714134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605593714134 : Closed e605593714134 ∧ code e605593714134 = 2804616969686 := by decide
theorem cert_e605593714134 : check e605593714134 [[],[]] .smaller = true := by decide
def e605593714138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605593714138 : Closed e605593714138 ∧ code e605593714138 = 2804616969690 := by decide
theorem cert_e605593714138 : check e605593714138 [[],[]] .smaller = true := by decide
def e605593714154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e605593714154 : Closed e605593714154 ∧ code e605593714154 = 2804616969706 := by decide
theorem cert_e605593714154 : check e605593714154 [[],[]] .three = true := by decide
def e605593714350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605593714350 : Closed e605593714350 ∧ code e605593714350 = 2804616969902 := by decide
theorem cert_e605593714350 : check e605593714350 [[],[]] .three = true := by decide
def e605593714358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e605593714358 : Closed e605593714358 ∧ code e605593714358 = 2804616969910 := by decide
theorem cert_e605593714358 : check e605593714358 [[],[]] .three = true := by decide
def e605593714362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605593714362 : Closed e605593714362 ∧ code e605593714362 = 2804616969914 := by decide
theorem cert_e605593714362 : check e605593714362 [[],[]] .three = true := by decide
def e605593714390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e605593714390 : Closed e605593714390 ∧ code e605593714390 = 2804616969942 := by decide
theorem cert_e605593714390 : check e605593714390 [[],[]] .three = true := by decide
def e605593714394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e605593714394 : Closed e605593714394 ∧ code e605593714394 = 2804616969946 := by decide
theorem cert_e605593714394 : check e605593714394 [[],[]] .three = true := by decide
def e605593714410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605593714410 : Closed e605593714410 ∧ code e605593714410 = 2804616969962 := by decide
theorem cert_e605593714410 : check e605593714410 [[],[]] .three = true := by decide
def e605593715182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2))))))))
theorem wire_e605593715182 : Closed e605593715182 ∧ code e605593715182 = 2804616970734 := by decide
theorem cert_e605593715182 : check e605593715182 [[],[]] .smaller = true := by decide
def e605593715190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1))))))))
theorem wire_e605593715190 : Closed e605593715190 ∧ code e605593715190 = 2804616970742 := by decide
theorem cert_e605593715190 : check e605593715190 [[],[]] .smaller = true := by decide
def e605593715950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e605593715950 : Closed e605593715950 ∧ code e605593715950 = 2804616971502 := by decide
theorem cert_e605593715950 : check e605593715950 [[],[]] .smaller = true := by decide
def e605593715958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e605593715958 : Closed e605593715958 ∧ code e605593715958 = 2804616971510 := by decide
theorem cert_e605593715958 : check e605593715958 [[],[]] .smaller = true := by decide
def e605593716510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3)))))))))
theorem wire_e605593716510 : Closed e605593716510 ∧ code e605593716510 = 2804616972062 := by decide
theorem cert_e605593716510 : check e605593716510 [[],[]] .smaller = true := by decide
def e605593716622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2)))))))))
theorem wire_e605593716622 : Closed e605593716622 ∧ code e605593716622 = 2804616972174 := by decide
theorem cert_e605593716622 : check e605593716622 [[],[]] .smaller = true := by decide
def e605593718238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e605593718238 : Closed e605593718238 ∧ code e605593718238 = 2804616973790 := by decide
theorem cert_e605593718238 : check e605593718238 [[],[]] .three = true := by decide
def e605593718254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e605593718254 : Closed e605593718254 ∧ code e605593718254 = 2804616973806 := by decide
theorem cert_e605593718254 : check e605593718254 [[],[]] .three = true := by decide
def e605593718318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605593718318 : Closed e605593718318 ∧ code e605593718318 = 2804616973870 := by decide
theorem cert_e605593718318 : check e605593718318 [[],[]] .smaller = true := by decide
def e605593718494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e605593718494 : Closed e605593718494 ∧ code e605593718494 = 2804616974046 := by decide
theorem cert_e605593718494 : check e605593718494 [[],[]] .three = true := by decide
def e605593718498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e605593718498 : Closed e605593718498 ∧ code e605593718498 = 2804616974050 := by decide
theorem cert_e605593718498 : check e605593718498 [[],[]] .smaller = true := by decide
def e605593718510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e605593718510 : Closed e605593718510 ∧ code e605593718510 = 2804616974062 := by decide
theorem cert_e605593718510 : check e605593718510 [[],[]] .smaller = true := by decide
def e605593718518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e605593718518 : Closed e605593718518 ∧ code e605593718518 = 2804616974070 := by decide
theorem cert_e605593718518 : check e605593718518 [[],[]] .three = true := by decide
def e605593718550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605593718550 : Closed e605593718550 ∧ code e605593718550 = 2804616974102 := by decide
theorem cert_e605593718550 : check e605593718550 [[],[]] .smaller = true := by decide
def e605593718622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e605593718622 : Closed e605593718622 ∧ code e605593718622 = 2804616974174 := by decide
theorem cert_e605593718622 : check e605593718622 [[],[]] .three = true := by decide
def e605593718626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e605593718626 : Closed e605593718626 ∧ code e605593718626 = 2804616974178 := by decide
theorem cert_e605593718626 : check e605593718626 [[],[]] .smaller = true := by decide
def e605593718638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e605593718638 : Closed e605593718638 ∧ code e605593718638 = 2804616974190 := by decide
theorem cert_e605593718638 : check e605593718638 [[],[]] .smaller = true := by decide
def e605593718646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e605593718646 : Closed e605593718646 ∧ code e605593718646 = 2804616974198 := by decide
theorem cert_e605593718646 : check e605593718646 [[],[]] .smaller = true := by decide
def e605593718650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e605593718650 : Closed e605593718650 ∧ code e605593718650 = 2804616974202 := by decide
theorem cert_e605593718650 : check e605593718650 [[],[]] .three = true := by decide
def e605593718702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e605593718702 : Closed e605593718702 ∧ code e605593718702 = 2804616974254 := by decide
theorem cert_e605593718702 : check e605593718702 [[],[]] .three = true := by decide
def e605593718710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e605593718710 : Closed e605593718710 ∧ code e605593718710 = 2804616974262 := by decide
theorem cert_e605593718710 : check e605593718710 [[],[]] .three = true := by decide
def e605593718714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e605593718714 : Closed e605593718714 ∧ code e605593718714 = 2804616974266 := by decide
theorem cert_e605593718714 : check e605593718714 [[],[]] .three = true := by decide
def e605593719774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e605593719774 : Closed e605593719774 ∧ code e605593719774 = 2804616975326 := by decide
theorem cert_e605593719774 : check e605593719774 [[],[]] .three = true := by decide
def e605593719790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e605593719790 : Closed e605593719790 ∧ code e605593719790 = 2804616975342 := by decide
theorem cert_e605593719790 : check e605593719790 [[],[]] .three = true := by decide
def e605593720894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4))))))))))
theorem wire_e605593720894 : Closed e605593720894 ∧ code e605593720894 = 2804616976446 := by decide
theorem cert_e605593720894 : check e605593720894 [[],[]] .smaller = true := by decide
def e605593721310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605593721310 : Closed e605593721310 ∧ code e605593721310 = 2804616976862 := by decide
theorem cert_e605593721310 : check e605593721310 [[],[]] .three = true := by decide
def e605593721314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605593721314 : Closed e605593721314 ∧ code e605593721314 = 2804616976866 := by decide
theorem cert_e605593721314 : check e605593721314 [[],[]] .smaller = true := by decide
def e605593721326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e605593721326 : Closed e605593721326 ∧ code e605593721326 = 2804616976878 := by decide
theorem cert_e605593721326 : check e605593721326 [[],[]] .smaller = true := by decide
def e605593721334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605593721334 : Closed e605593721334 ∧ code e605593721334 = 2804616976886 := by decide
theorem cert_e605593721334 : check e605593721334 [[],[]] .three = true := by decide
def e605593721886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3))))))))))
theorem wire_e605593721886 : Closed e605593721886 ∧ code e605593721886 = 2804616977438 := by decide
theorem cert_e605593721886 : check e605593721886 [[],[]] .smaller = true := by decide
def e605593722078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605593722078 : Closed e605593722078 ∧ code e605593722078 = 2804616977630 := by decide
theorem cert_e605593722078 : check e605593722078 [[],[]] .three = true := by decide
def e605593722082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e605593722082 : Closed e605593722082 ∧ code e605593722082 = 2804616977634 := by decide
theorem cert_e605593722082 : check e605593722082 [[],[]] .smaller = true := by decide
def e605593722094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605593722094 : Closed e605593722094 ∧ code e605593722094 = 2804616977646 := by decide
theorem cert_e605593722094 : check e605593722094 [[],[]] .smaller = true := by decide
def e605593722102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605593722102 : Closed e605593722102 ∧ code e605593722102 = 2804616977654 := by decide
theorem cert_e605593722102 : check e605593722102 [[],[]] .smaller = true := by decide
def e605593722106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605593722106 : Closed e605593722106 ∧ code e605593722106 = 2804616977658 := by decide
theorem cert_e605593722106 : check e605593722106 [[],[]] .three = true := by decide
def e605593722478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593722478 : Closed e605593722478 ∧ code e605593722478 = 2804616978030 := by decide
theorem cert_e605593722478 : check e605593722478 [[],[]] .three = true := by decide
def e605593722486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605593722486 : Closed e605593722486 ∧ code e605593722486 = 2804616978038 := by decide
theorem cert_e605593722486 : check e605593722486 [[],[]] .three = true := by decide
def e605593722490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593722490 : Closed e605593722490 ∧ code e605593722490 = 2804616978042 := by decide
theorem cert_e605593722490 : check e605593722490 [[],[]] .three = true := by decide
def e605593723118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2))))))))
theorem wire_e605593723118 : Closed e605593723118 ∧ code e605593723118 = 2804616978670 := by decide
theorem cert_e605593723118 : check e605593723118 [[],[]] .smaller = true := by decide
def e605593723130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0))))))))
theorem wire_e605593723130 : Closed e605593723130 ∧ code e605593723130 = 2804616978682 := by decide
theorem cert_e605593723130 : check e605593723130 [[],[]] .smaller = true := by decide
def e605593723310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e605593723310 : Closed e605593723310 ∧ code e605593723310 = 2804616978862 := by decide
theorem cert_e605593723310 : check e605593723310 [[],[]] .smaller = true := by decide
def e605593723502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593723502 : Closed e605593723502 ∧ code e605593723502 = 2804616979054 := by decide
theorem cert_e605593723502 : check e605593723502 [[],[]] .smaller = true := by decide
def e605593723514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593723514 : Closed e605593723514 ∧ code e605593723514 = 2804616979066 := by decide
theorem cert_e605593723514 : check e605593723514 [[],[]] .smaller = true := by decide
def e605593723678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3)))))))))
theorem wire_e605593723678 : Closed e605593723678 ∧ code e605593723678 = 2804616979230 := by decide
theorem cert_e605593723678 : check e605593723678 [[],[]] .smaller = true := by decide
def e605593723846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1)))))))))
theorem wire_e605593723846 : Closed e605593723846 ∧ code e605593723846 = 2804616979398 := by decide
theorem cert_e605593723846 : check e605593723846 [[],[]] .smaller = true := by decide
def e605593724462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605593724462 : Closed e605593724462 ∧ code e605593724462 = 2804616980014 := by decide
theorem cert_e605593724462 : check e605593724462 [[],[]] .smaller = true := by decide
def e605593724638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e605593724638 : Closed e605593724638 ∧ code e605593724638 = 2804616980190 := by decide
theorem cert_e605593724638 : check e605593724638 [[],[]] .three = true := by decide
def e605593724642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e605593724642 : Closed e605593724642 ∧ code e605593724642 = 2804616980194 := by decide
theorem cert_e605593724642 : check e605593724642 [[],[]] .smaller = true := by decide
def e605593724654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e605593724654 : Closed e605593724654 ∧ code e605593724654 = 2804616980206 := by decide
theorem cert_e605593724654 : check e605593724654 [[],[]] .smaller = true := by decide
def e605593724662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e605593724662 : Closed e605593724662 ∧ code e605593724662 = 2804616980214 := by decide
theorem cert_e605593724662 : check e605593724662 [[],[]] .three = true := by decide
def e605593724766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e605593724766 : Closed e605593724766 ∧ code e605593724766 = 2804616980318 := by decide
theorem cert_e605593724766 : check e605593724766 [[],[]] .three = true := by decide
def e605593724782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e605593724782 : Closed e605593724782 ∧ code e605593724782 = 2804616980334 := by decide
theorem cert_e605593724782 : check e605593724782 [[],[]] .smaller = true := by decide
def e605593724790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e605593724790 : Closed e605593724790 ∧ code e605593724790 = 2804616980342 := by decide
theorem cert_e605593724790 : check e605593724790 [[],[]] .smaller = true := by decide
def e605593724794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e605593724794 : Closed e605593724794 ∧ code e605593724794 = 2804616980346 := by decide
theorem cert_e605593724794 : check e605593724794 [[],[]] .three = true := by decide
def e605593724810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605593724810 : Closed e605593724810 ∧ code e605593724810 = 2804616980362 := by decide
theorem cert_e605593724810 : check e605593724810 [[],[]] .smaller = true := by decide
def e605593724834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e605593724834 : Closed e605593724834 ∧ code e605593724834 = 2804616980386 := by decide
theorem cert_e605593724834 : check e605593724834 [[],[]] .smaller = true := by decide
def e605593724846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e605593724846 : Closed e605593724846 ∧ code e605593724846 = 2804616980398 := by decide
theorem cert_e605593724846 : check e605593724846 [[],[]] .smaller = true := by decide
def e605593724854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e605593724854 : Closed e605593724854 ∧ code e605593724854 = 2804616980406 := by decide
theorem cert_e605593724854 : check e605593724854 [[],[]] .smaller = true := by decide
end Blc.Floor41
