import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605641715330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e605641715330 : Closed e605641715330 ∧ code e605641715330 = 2804664970882 := by decide
theorem cert_e605641715330 : check e605641715330 [[],[]] .chain = true := by decide
def e605641715342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605641715342 : Closed e605641715342 ∧ code e605641715342 = 2804664970894 := by decide
theorem cert_e605641715342 : check e605641715342 [[],[]] .chain = true := by decide
def e605641715354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605641715354 : Closed e605641715354 ∧ code e605641715354 = 2804664970906 := by decide
theorem cert_e605641715354 : check e605641715354 [[],[]] .chain = true := by decide
def e605641715398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605641715398 : Closed e605641715398 ∧ code e605641715398 = 2804664970950 := by decide
theorem cert_e605641715398 : check e605641715398 [[],[]] .chain = true := by decide
def e605641715950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605641715950 : Closed e605641715950 ∧ code e605641715950 = 2804664971502 := by decide
theorem cert_e605641715950 : check e605641715950 [[],[]] .chain = true := by decide
def e605641715958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605641715958 : Closed e605641715958 ∧ code e605641715958 = 2804664971510 := by decide
theorem cert_e605641715958 : check e605641715958 [[],[]] .chain = true := by decide
def e605641716438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605641716438 : Closed e605641716438 ∧ code e605641716438 = 2804664971990 := by decide
theorem cert_e605641716438 : check e605641716438 [[],[]] .chain = true := by decide
def e605641716442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605641716442 : Closed e605641716442 ∧ code e605641716442 = 2804664971994 := by decide
theorem cert_e605641716442 : check e605641716442 [[],[]] .chain = true := by decide
def e605641716458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605641716458 : Closed e605641716458 ∧ code e605641716458 = 2804664972010 := by decide
theorem cert_e605641716458 : check e605641716458 [[],[]] .chain = true := by decide
def e605641716534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605641716534 : Closed e605641716534 ∧ code e605641716534 = 2804664972086 := by decide
theorem cert_e605641716534 : check e605641716534 [[],[]] .chain = true := by decide
def e605641716538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605641716538 : Closed e605641716538 ∧ code e605641716538 = 2804664972090 := by decide
theorem cert_e605641716538 : check e605641716538 [[],[]] .chain = true := by decide
def e605641716610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e605641716610 : Closed e605641716610 ∧ code e605641716610 = 2804664972162 := by decide
theorem cert_e605641716610 : check e605641716610 [[],[]] .chain = true := by decide
def e605641716622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e605641716622 : Closed e605641716622 ∧ code e605641716622 = 2804664972174 := by decide
theorem cert_e605641716622 : check e605641716622 [[],[]] .chain = true := by decide
def e605641716634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605641716634 : Closed e605641716634 ∧ code e605641716634 = 2804664972186 := by decide
theorem cert_e605641716634 : check e605641716634 [[],[]] .chain = true := by decide
def e605641717878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605641717878 : Closed e605641717878 ∧ code e605641717878 = 2804664973430 := by decide
theorem cert_e605641717878 : check e605641717878 [[],[]] .chain = true := by decide
def e605641718122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605641718122 : Closed e605641718122 ∧ code e605641718122 = 2804664973674 := by decide
theorem cert_e605641718122 : check e605641718122 [[],[]] .chain = true := by decide
def e605641718146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e605641718146 : Closed e605641718146 ∧ code e605641718146 = 2804664973698 := by decide
theorem cert_e605641718146 : check e605641718146 [[],[]] .chain = true := by decide
def e605641718158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605641718158 : Closed e605641718158 ∧ code e605641718158 = 2804664973710 := by decide
theorem cert_e605641718158 : check e605641718158 [[],[]] .chain = true := by decide
def e605641718170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605641718170 : Closed e605641718170 ∧ code e605641718170 = 2804664973722 := by decide
theorem cert_e605641718170 : check e605641718170 [[],[]] .chain = true := by decide
def e605641718214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605641718214 : Closed e605641718214 ∧ code e605641718214 = 2804664973766 := by decide
theorem cert_e605641718214 : check e605641718214 [[],[]] .chain = true := by decide
def e605643615674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e605643615674 : Closed e605643615674 ∧ code e605643615674 = 2804666871226 := by decide
theorem cert_e605643615674 : check e605643615674 [[],[]] .chain = true := by decide
def e605643615706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e605643615706 : Closed e605643615706 ∧ code e605643615706 = 2804666871258 := by decide
theorem cert_e605643615706 : check e605643615706 [[],[]] .chain = true := by decide
def e605643615930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e605643615930 : Closed e605643615930 ∧ code e605643615930 = 2804666871482 := by decide
theorem cert_e605643615930 : check e605643615930 [[],[]] .chain = true := by decide
def e605643615978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e605643615978 : Closed e605643615978 ∧ code e605643615978 = 2804666871530 := by decide
theorem cert_e605643615978 : check e605643615978 [[],[]] .chain = true := by decide
def e605643616090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e605643616090 : Closed e605643616090 ∧ code e605643616090 = 2804666871642 := by decide
theorem cert_e605643616090 : check e605643616090 [[],[]] .chain = true := by decide
def e605643616106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e605643616106 : Closed e605643616106 ∧ code e605643616106 = 2804666871658 := by decide
theorem cert_e605643616106 : check e605643616106 [[],[]] .chain = true := by decide
def e605643617210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e605643617210 : Closed e605643617210 ∧ code e605643617210 = 2804666872762 := by decide
theorem cert_e605643617210 : check e605643617210 [[],[]] .chain = true := by decide
def e605643617242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e605643617242 : Closed e605643617242 ∧ code e605643617242 = 2804666872794 := by decide
theorem cert_e605643617242 : check e605643617242 [[],[]] .chain = true := by decide
def e605643618746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e605643618746 : Closed e605643618746 ∧ code e605643618746 = 2804666874298 := by decide
theorem cert_e605643618746 : check e605643618746 [[],[]] .chain = true := by decide
def e605643618794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e605643618794 : Closed e605643618794 ∧ code e605643618794 = 2804666874346 := by decide
theorem cert_e605643618794 : check e605643618794 [[],[]] .chain = true := by decide
def e605643619546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e605643619546 : Closed e605643619546 ∧ code e605643619546 = 2804666875098 := by decide
theorem cert_e605643619546 : check e605643619546 [[],[]] .chain = true := by decide
def e605643619562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e605643619562 : Closed e605643619562 ∧ code e605643619562 = 2804666875114 := by decide
theorem cert_e605643619562 : check e605643619562 [[],[]] .chain = true := by decide
def e605643672430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605643672430 : Closed e605643672430 ∧ code e605643672430 = 2804666927982 := by decide
theorem cert_e605643672430 : check e605643672430 [[],[]] .chain = true := by decide
def e605643672438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605643672438 : Closed e605643672438 ∧ code e605643672438 = 2804666927990 := by decide
theorem cert_e605643672438 : check e605643672438 [[],[]] .chain = true := by decide
def e605643672494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605643672494 : Closed e605643672494 ∧ code e605643672494 = 2804666928046 := by decide
theorem cert_e605643672494 : check e605643672494 [[],[]] .chain = true := by decide
def e605643672506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605643672506 : Closed e605643672506 ∧ code e605643672506 = 2804666928058 := by decide
theorem cert_e605643672506 : check e605643672506 [[],[]] .chain = true := by decide
def e605643672534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605643672534 : Closed e605643672534 ∧ code e605643672534 = 2804666928086 := by decide
theorem cert_e605643672534 : check e605643672534 [[],[]] .chain = true := by decide
def e605643672538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605643672538 : Closed e605643672538 ∧ code e605643672538 = 2804666928090 := by decide
theorem cert_e605643672538 : check e605643672538 [[],[]] .chain = true := by decide
def e605643672814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605643672814 : Closed e605643672814 ∧ code e605643672814 = 2804666928366 := by decide
theorem cert_e605643672814 : check e605643672814 [[],[]] .chain = true := by decide
def e605643672822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605643672822 : Closed e605643672822 ∧ code e605643672822 = 2804666928374 := by decide
theorem cert_e605643672822 : check e605643672822 [[],[]] .chain = true := by decide
def e605643673198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605643673198 : Closed e605643673198 ∧ code e605643673198 = 2804666928750 := by decide
theorem cert_e605643673198 : check e605643673198 [[],[]] .chain = true := by decide
def e605643673210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605643673210 : Closed e605643673210 ∧ code e605643673210 = 2804666928762 := by decide
theorem cert_e605643673210 : check e605643673210 [[],[]] .chain = true := by decide
def e605643673398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605643673398 : Closed e605643673398 ∧ code e605643673398 = 2804666928950 := by decide
theorem cert_e605643673398 : check e605643673398 [[],[]] .chain = true := by decide
def e605643673402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605643673402 : Closed e605643673402 ∧ code e605643673402 = 2804666928954 := by decide
theorem cert_e605643673402 : check e605643673402 [[],[]] .chain = true := by decide
def e605643869038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605643869038 : Closed e605643869038 ∧ code e605643869038 = 2804667124590 := by decide
theorem cert_e605643869038 : check e605643869038 [[],[]] .smaller = true := by decide
def e605643869046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605643869046 : Closed e605643869046 ∧ code e605643869046 = 2804667124598 := by decide
theorem cert_e605643869046 : check e605643869046 [[],[]] .smaller = true := by decide
def e605643869102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605643869102 : Closed e605643869102 ∧ code e605643869102 = 2804667124654 := by decide
theorem cert_e605643869102 : check e605643869102 [[],[]] .smaller = true := by decide
def e605643869114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605643869114 : Closed e605643869114 ∧ code e605643869114 = 2804667124666 := by decide
theorem cert_e605643869114 : check e605643869114 [[],[]] .smaller = true := by decide
def e605643869142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605643869142 : Closed e605643869142 ∧ code e605643869142 = 2804667124694 := by decide
theorem cert_e605643869142 : check e605643869142 [[],[]] .smaller = true := by decide
def e605643869146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605643869146 : Closed e605643869146 ∧ code e605643869146 = 2804667124698 := by decide
theorem cert_e605643869146 : check e605643869146 [[],[]] .smaller = true := by decide
def e605643869422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605643869422 : Closed e605643869422 ∧ code e605643869422 = 2804667124974 := by decide
theorem cert_e605643869422 : check e605643869422 [[],[]] .smaller = true := by decide
def e605643869430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605643869430 : Closed e605643869430 ∧ code e605643869430 = 2804667124982 := by decide
theorem cert_e605643869430 : check e605643869430 [[],[]] .smaller = true := by decide
def e605643869806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605643869806 : Closed e605643869806 ∧ code e605643869806 = 2804667125358 := by decide
theorem cert_e605643869806 : check e605643869806 [[],[]] .smaller = true := by decide
def e605643869818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605643869818 : Closed e605643869818 ∧ code e605643869818 = 2804667125370 := by decide
theorem cert_e605643869818 : check e605643869818 [[],[]] .smaller = true := by decide
def e605643870006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605643870006 : Closed e605643870006 ∧ code e605643870006 = 2804667125558 := by decide
theorem cert_e605643870006 : check e605643870006 [[],[]] .smaller = true := by decide
def e605643870010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605643870010 : Closed e605643870010 ∧ code e605643870010 = 2804667125562 := by decide
theorem cert_e605643870010 : check e605643870010 [[],[]] .smaller = true := by decide
def e605643877854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605643877854 : Closed e605643877854 ∧ code e605643877854 = 2804667133406 := by decide
theorem cert_e605643877854 : check e605643877854 [[],[]] .chain = true := by decide
def e605643877870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605643877870 : Closed e605643877870 ∧ code e605643877870 = 2804667133422 := by decide
theorem cert_e605643877870 : check e605643877870 [[],[]] .chain = true := by decide
def e605643878238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605643878238 : Closed e605643878238 ∧ code e605643878238 = 2804667133790 := by decide
theorem cert_e605643878238 : check e605643878238 [[],[]] .chain = true := by decide
def e605643878266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605643878266 : Closed e605643878266 ∧ code e605643878266 = 2804667133818 := by decide
theorem cert_e605643878266 : check e605643878266 [[],[]] .chain = true := by decide
def e605643878318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605643878318 : Closed e605643878318 ∧ code e605643878318 = 2804667133870 := by decide
theorem cert_e605643878318 : check e605643878318 [[],[]] .chain = true := by decide
def e605643878330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605643878330 : Closed e605643878330 ∧ code e605643878330 = 2804667133882 := by decide
theorem cert_e605643878330 : check e605643878330 [[],[]] .chain = true := by decide
def e605643879390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605643879390 : Closed e605643879390 ∧ code e605643879390 = 2804667134942 := by decide
theorem cert_e605643879390 : check e605643879390 [[],[]] .chain = true := by decide
def e605643879406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605643879406 : Closed e605643879406 ∧ code e605643879406 = 2804667134958 := by decide
theorem cert_e605643879406 : check e605643879406 [[],[]] .chain = true := by decide
def e605643881694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605643881694 : Closed e605643881694 ∧ code e605643881694 = 2804667137246 := by decide
theorem cert_e605643881694 : check e605643881694 [[],[]] .chain = true := by decide
def e605643881722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605643881722 : Closed e605643881722 ∧ code e605643881722 = 2804667137274 := by decide
theorem cert_e605643881722 : check e605643881722 [[],[]] .chain = true := by decide
def e605643882094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605643882094 : Closed e605643882094 ∧ code e605643882094 = 2804667137646 := by decide
theorem cert_e605643882094 : check e605643882094 [[],[]] .chain = true := by decide
def e605643882106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605643882106 : Closed e605643882106 ∧ code e605643882106 = 2804667137658 := by decide
theorem cert_e605643882106 : check e605643882106 [[],[]] .chain = true := by decide
def e605643910510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605643910510 : Closed e605643910510 ∧ code e605643910510 = 2804667166062 := by decide
theorem cert_e605643910510 : check e605643910510 [[],[]] .chain = true := by decide
def e605643910518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605643910518 : Closed e605643910518 ∧ code e605643910518 = 2804667166070 := by decide
theorem cert_e605643910518 : check e605643910518 [[],[]] .chain = true := by decide
def e605643910574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605643910574 : Closed e605643910574 ∧ code e605643910574 = 2804667166126 := by decide
theorem cert_e605643910574 : check e605643910574 [[],[]] .chain = true := by decide
def e605643910586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605643910586 : Closed e605643910586 ∧ code e605643910586 = 2804667166138 := by decide
theorem cert_e605643910586 : check e605643910586 [[],[]] .chain = true := by decide
def e605643910614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605643910614 : Closed e605643910614 ∧ code e605643910614 = 2804667166166 := by decide
theorem cert_e605643910614 : check e605643910614 [[],[]] .chain = true := by decide
def e605643910618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605643910618 : Closed e605643910618 ∧ code e605643910618 = 2804667166170 := by decide
theorem cert_e605643910618 : check e605643910618 [[],[]] .chain = true := by decide
def e605643910830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605643910830 : Closed e605643910830 ∧ code e605643910830 = 2804667166382 := by decide
theorem cert_e605643910830 : check e605643910830 [[],[]] .chain = true := by decide
def e605643910842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605643910842 : Closed e605643910842 ∧ code e605643910842 = 2804667166394 := by decide
theorem cert_e605643910842 : check e605643910842 [[],[]] .chain = true := by decide
def e605643910890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605643910890 : Closed e605643910890 ∧ code e605643910890 = 2804667166442 := by decide
theorem cert_e605643910890 : check e605643910890 [[],[]] .chain = true := by decide
def e605643910998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605643910998 : Closed e605643910998 ∧ code e605643910998 = 2804667166550 := by decide
theorem cert_e605643910998 : check e605643910998 [[],[]] .chain = true := by decide
def e605643911002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605643911002 : Closed e605643911002 ∧ code e605643911002 = 2804667166554 := by decide
theorem cert_e605643911002 : check e605643911002 [[],[]] .chain = true := by decide
def e605643911018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605643911018 : Closed e605643911018 ∧ code e605643911018 = 2804667166570 := by decide
theorem cert_e605643911018 : check e605643911018 [[],[]] .chain = true := by decide
def e605643912046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605643912046 : Closed e605643912046 ∧ code e605643912046 = 2804667167598 := by decide
theorem cert_e605643912046 : check e605643912046 [[],[]] .chain = true := by decide
def e605643912054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605643912054 : Closed e605643912054 ∧ code e605643912054 = 2804667167606 := by decide
theorem cert_e605643912054 : check e605643912054 [[],[]] .chain = true := by decide
def e605643912110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605643912110 : Closed e605643912110 ∧ code e605643912110 = 2804667167662 := by decide
theorem cert_e605643912110 : check e605643912110 [[],[]] .chain = true := by decide
def e605643912122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605643912122 : Closed e605643912122 ∧ code e605643912122 = 2804667167674 := by decide
theorem cert_e605643912122 : check e605643912122 [[],[]] .chain = true := by decide
def e605643912150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605643912150 : Closed e605643912150 ∧ code e605643912150 = 2804667167702 := by decide
theorem cert_e605643912150 : check e605643912150 [[],[]] .chain = true := by decide
def e605643912154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605643912154 : Closed e605643912154 ∧ code e605643912154 = 2804667167706 := by decide
theorem cert_e605643912154 : check e605643912154 [[],[]] .chain = true := by decide
def e605643912430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605643912430 : Closed e605643912430 ∧ code e605643912430 = 2804667167982 := by decide
theorem cert_e605643912430 : check e605643912430 [[],[]] .chain = true := by decide
def e605643912438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605643912438 : Closed e605643912438 ∧ code e605643912438 = 2804667167990 := by decide
theorem cert_e605643912438 : check e605643912438 [[],[]] .chain = true := by decide
def e605643912814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605643912814 : Closed e605643912814 ∧ code e605643912814 = 2804667168366 := by decide
theorem cert_e605643912814 : check e605643912814 [[],[]] .chain = true := by decide
def e605643912826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605643912826 : Closed e605643912826 ∧ code e605643912826 = 2804667168378 := by decide
theorem cert_e605643912826 : check e605643912826 [[],[]] .chain = true := by decide
def e605643913014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605643913014 : Closed e605643913014 ∧ code e605643913014 = 2804667168566 := by decide
theorem cert_e605643913014 : check e605643913014 [[],[]] .chain = true := by decide
def e605643913018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605643913018 : Closed e605643913018 ∧ code e605643913018 = 2804667168570 := by decide
theorem cert_e605643913018 : check e605643913018 [[],[]] .chain = true := by decide
def e605643913646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605643913646 : Closed e605643913646 ∧ code e605643913646 = 2804667169198 := by decide
theorem cert_e605643913646 : check e605643913646 [[],[]] .chain = true := by decide
def e605643913658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605643913658 : Closed e605643913658 ∧ code e605643913658 = 2804667169210 := by decide
theorem cert_e605643913658 : check e605643913658 [[],[]] .chain = true := by decide
def e605643913706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605643913706 : Closed e605643913706 ∧ code e605643913706 = 2804667169258 := by decide
theorem cert_e605643913706 : check e605643913706 [[],[]] .chain = true := by decide
def e605643913838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605643913838 : Closed e605643913838 ∧ code e605643913838 = 2804667169390 := by decide
theorem cert_e605643913838 : check e605643913838 [[],[]] .chain = true := by decide
def e605643913850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605643913850 : Closed e605643913850 ∧ code e605643913850 = 2804667169402 := by decide
theorem cert_e605643913850 : check e605643913850 [[],[]] .chain = true := by decide
def e605643914138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605643914138 : Closed e605643914138 ∧ code e605643914138 = 2804667169690 := by decide
theorem cert_e605643914138 : check e605643914138 [[],[]] .chain = true := by decide
def e605643914454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605643914454 : Closed e605643914454 ∧ code e605643914454 = 2804667170006 := by decide
theorem cert_e605643914454 : check e605643914454 [[],[]] .chain = true := by decide
def e605643914458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605643914458 : Closed e605643914458 ∧ code e605643914458 = 2804667170010 := by decide
theorem cert_e605643914458 : check e605643914458 [[],[]] .chain = true := by decide
def e605643914474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605643914474 : Closed e605643914474 ∧ code e605643914474 = 2804667170026 := by decide
theorem cert_e605643914474 : check e605643914474 [[],[]] .chain = true := by decide
def e605643914550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605643914550 : Closed e605643914550 ∧ code e605643914550 = 2804667170102 := by decide
theorem cert_e605643914550 : check e605643914550 [[],[]] .chain = true := by decide
def e605643914554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605643914554 : Closed e605643914554 ∧ code e605643914554 = 2804667170106 := by decide
theorem cert_e605643914554 : check e605643914554 [[],[]] .chain = true := by decide
def e605643914650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605643914650 : Closed e605643914650 ∧ code e605643914650 = 2804667170202 := by decide
theorem cert_e605643914650 : check e605643914650 [[],[]] .chain = true := by decide
def e605643916254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e605643916254 : Closed e605643916254 ∧ code e605643916254 = 2804667171806 := by decide
theorem cert_e605643916254 : check e605643916254 [[],[]] .chain = true := by decide
def e605643916270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e605643916270 : Closed e605643916270 ∧ code e605643916270 = 2804667171822 := by decide
theorem cert_e605643916270 : check e605643916270 [[],[]] .chain = true := by decide
def e605643918190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605643918190 : Closed e605643918190 ∧ code e605643918190 = 2804667173742 := by decide
theorem cert_e605643918190 : check e605643918190 [[],[]] .chain = true := by decide
def e605643918198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605643918198 : Closed e605643918198 ∧ code e605643918198 = 2804667173750 := by decide
theorem cert_e605643918198 : check e605643918198 [[],[]] .chain = true := by decide
def e605643918254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605643918254 : Closed e605643918254 ∧ code e605643918254 = 2804667173806 := by decide
theorem cert_e605643918254 : check e605643918254 [[],[]] .chain = true := by decide
def e605643918266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605643918266 : Closed e605643918266 ∧ code e605643918266 = 2804667173818 := by decide
theorem cert_e605643918266 : check e605643918266 [[],[]] .chain = true := by decide
def e605643918294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605643918294 : Closed e605643918294 ∧ code e605643918294 = 2804667173846 := by decide
theorem cert_e605643918294 : check e605643918294 [[],[]] .chain = true := by decide
def e605643918298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605643918298 : Closed e605643918298 ∧ code e605643918298 = 2804667173850 := by decide
theorem cert_e605643918298 : check e605643918298 [[],[]] .chain = true := by decide
def e605643918574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605643918574 : Closed e605643918574 ∧ code e605643918574 = 2804667174126 := by decide
theorem cert_e605643918574 : check e605643918574 [[],[]] .chain = true := by decide
def e605643918582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605643918582 : Closed e605643918582 ∧ code e605643918582 = 2804667174134 := by decide
theorem cert_e605643918582 : check e605643918582 [[],[]] .chain = true := by decide
def e605643918958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605643918958 : Closed e605643918958 ∧ code e605643918958 = 2804667174510 := by decide
theorem cert_e605643918958 : check e605643918958 [[],[]] .chain = true := by decide
def e605643918970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605643918970 : Closed e605643918970 ∧ code e605643918970 = 2804667174522 := by decide
theorem cert_e605643918970 : check e605643918970 [[],[]] .chain = true := by decide
def e605643919158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605643919158 : Closed e605643919158 ∧ code e605643919158 = 2804667174710 := by decide
theorem cert_e605643919158 : check e605643919158 [[],[]] .chain = true := by decide
def e605643919162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605643919162 : Closed e605643919162 ∧ code e605643919162 = 2804667174714 := by decide
theorem cert_e605643919162 : check e605643919162 [[],[]] .chain = true := by decide
def e605643923934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605643923934 : Closed e605643923934 ∧ code e605643923934 = 2804667179486 := by decide
theorem cert_e605643923934 : check e605643923934 [[],[]] .chain = true := by decide
def e605643923958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605643923958 : Closed e605643923958 ∧ code e605643923958 = 2804667179510 := by decide
theorem cert_e605643923958 : check e605643923958 [[],[]] .chain = true := by decide
def e605643924910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605643924910 : Closed e605643924910 ∧ code e605643924910 = 2804667180462 := by decide
theorem cert_e605643924910 : check e605643924910 [[],[]] .chain = true := by decide
def e605643924922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605643924922 : Closed e605643924922 ∧ code e605643924922 = 2804667180474 := by decide
theorem cert_e605643924922 : check e605643924922 [[],[]] .chain = true := by decide
def e605643924970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605643924970 : Closed e605643924970 ∧ code e605643924970 = 2804667180522 := by decide
theorem cert_e605643924970 : check e605643924970 [[],[]] .chain = true := by decide
def e605643925102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605643925102 : Closed e605643925102 ∧ code e605643925102 = 2804667180654 := by decide
theorem cert_e605643925102 : check e605643925102 [[],[]] .chain = true := by decide
def e605643925114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605643925114 : Closed e605643925114 ∧ code e605643925114 = 2804667180666 := by decide
theorem cert_e605643925114 : check e605643925114 [[],[]] .chain = true := by decide
def e605643925402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605643925402 : Closed e605643925402 ∧ code e605643925402 = 2804667180954 := by decide
theorem cert_e605643925402 : check e605643925402 [[],[]] .chain = true := by decide
def e605643927790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605643927790 : Closed e605643927790 ∧ code e605643927790 = 2804667183342 := by decide
theorem cert_e605643927790 : check e605643927790 [[],[]] .chain = true := by decide
def e605643927798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605643927798 : Closed e605643927798 ∧ code e605643927798 = 2804667183350 := by decide
theorem cert_e605643927798 : check e605643927798 [[],[]] .chain = true := by decide
def e605643928278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605643928278 : Closed e605643928278 ∧ code e605643928278 = 2804667183830 := by decide
theorem cert_e605643928278 : check e605643928278 [[],[]] .chain = true := by decide
def e605643928282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605643928282 : Closed e605643928282 ∧ code e605643928282 = 2804667183834 := by decide
theorem cert_e605643928282 : check e605643928282 [[],[]] .chain = true := by decide
def e605643928298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605643928298 : Closed e605643928298 ∧ code e605643928298 = 2804667183850 := by decide
theorem cert_e605643928298 : check e605643928298 [[],[]] .chain = true := by decide
def e605643928374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605643928374 : Closed e605643928374 ∧ code e605643928374 = 2804667183926 := by decide
theorem cert_e605643928374 : check e605643928374 [[],[]] .chain = true := by decide
def e605643928378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605643928378 : Closed e605643928378 ∧ code e605643928378 = 2804667183930 := by decide
theorem cert_e605643928378 : check e605643928378 [[],[]] .chain = true := by decide
def e605643928474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605643928474 : Closed e605643928474 ∧ code e605643928474 = 2804667184026 := by decide
theorem cert_e605643928474 : check e605643928474 [[],[]] .chain = true := by decide
def e605644065646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605644065646 : Closed e605644065646 ∧ code e605644065646 = 2804667321198 := by decide
theorem cert_e605644065646 : check e605644065646 [[],[]] .chain = true := by decide
def e605644065654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605644065654 : Closed e605644065654 ∧ code e605644065654 = 2804667321206 := by decide
theorem cert_e605644065654 : check e605644065654 [[],[]] .chain = true := by decide
def e605644065710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605644065710 : Closed e605644065710 ∧ code e605644065710 = 2804667321262 := by decide
theorem cert_e605644065710 : check e605644065710 [[],[]] .chain = true := by decide
def e605644065722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605644065722 : Closed e605644065722 ∧ code e605644065722 = 2804667321274 := by decide
theorem cert_e605644065722 : check e605644065722 [[],[]] .chain = true := by decide
def e605644065750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605644065750 : Closed e605644065750 ∧ code e605644065750 = 2804667321302 := by decide
theorem cert_e605644065750 : check e605644065750 [[],[]] .chain = true := by decide
def e605644065754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605644065754 : Closed e605644065754 ∧ code e605644065754 = 2804667321306 := by decide
theorem cert_e605644065754 : check e605644065754 [[],[]] .chain = true := by decide
def e605644066030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605644066030 : Closed e605644066030 ∧ code e605644066030 = 2804667321582 := by decide
theorem cert_e605644066030 : check e605644066030 [[],[]] .chain = true := by decide
def e605644066038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605644066038 : Closed e605644066038 ∧ code e605644066038 = 2804667321590 := by decide
theorem cert_e605644066038 : check e605644066038 [[],[]] .chain = true := by decide
def e605644066414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605644066414 : Closed e605644066414 ∧ code e605644066414 = 2804667321966 := by decide
theorem cert_e605644066414 : check e605644066414 [[],[]] .chain = true := by decide
def e605644066426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605644066426 : Closed e605644066426 ∧ code e605644066426 = 2804667321978 := by decide
theorem cert_e605644066426 : check e605644066426 [[],[]] .chain = true := by decide
def e605644066614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605644066614 : Closed e605644066614 ∧ code e605644066614 = 2804667322166 := by decide
theorem cert_e605644066614 : check e605644066614 [[],[]] .chain = true := by decide
def e605644066618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605644066618 : Closed e605644066618 ∧ code e605644066618 = 2804667322170 := by decide
theorem cert_e605644066618 : check e605644066618 [[],[]] .chain = true := by decide
def e605644396254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605644396254 : Closed e605644396254 ∧ code e605644396254 = 2804667651806 := by decide
theorem cert_e605644396254 : check e605644396254 [[],[]] .sourceHead = true := by decide
def e605644396278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605644396278 : Closed e605644396278 ∧ code e605644396278 = 2804667651830 := by decide
theorem cert_e605644396278 : check e605644396278 [[],[]] .sourceHead = true := by decide
def e605644396382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605644396382 : Closed e605644396382 ∧ code e605644396382 = 2804667651934 := by decide
theorem cert_e605644396382 : check e605644396382 [[],[]] .sourceHead = true := by decide
def e605644396410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605644396410 : Closed e605644396410 ∧ code e605644396410 = 2804667651962 := by decide
theorem cert_e605644396410 : check e605644396410 [[],[]] .sourceHead = true := by decide
def e605644396502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605644396502 : Closed e605644396502 ∧ code e605644396502 = 2804667652054 := by decide
theorem cert_e605644396502 : check e605644396502 [[],[]] .sourceHead = true := by decide
def e605644396506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605644396506 : Closed e605644396506 ∧ code e605644396506 = 2804667652058 := by decide
theorem cert_e605644396506 : check e605644396506 [[],[]] .sourceHead = true := by decide
def e605644397022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605644397022 : Closed e605644397022 ∧ code e605644397022 = 2804667652574 := by decide
theorem cert_e605644397022 : check e605644397022 [[],[]] .sourceHead = true := by decide
def e605644397046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605644397046 : Closed e605644397046 ∧ code e605644397046 = 2804667652598 := by decide
theorem cert_e605644397046 : check e605644397046 [[],[]] .sourceHead = true := by decide
def e605644397790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605644397790 : Closed e605644397790 ∧ code e605644397790 = 2804667653342 := by decide
theorem cert_e605644397790 : check e605644397790 [[],[]] .sourceHead = true := by decide
def e605644397818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605644397818 : Closed e605644397818 ∧ code e605644397818 = 2804667653370 := by decide
theorem cert_e605644397818 : check e605644397818 [[],[]] .sourceHead = true := by decide
def e605644398390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605644398390 : Closed e605644398390 ∧ code e605644398390 = 2804667653942 := by decide
theorem cert_e605644398390 : check e605644398390 [[],[]] .sourceHead = true := by decide
def e605644398394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605644398394 : Closed e605644398394 ∧ code e605644398394 = 2804667653946 := by decide
theorem cert_e605644398394 : check e605644398394 [[],[]] .sourceHead = true := by decide
def e605644413166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605644413166 : Closed e605644413166 ∧ code e605644413166 = 2804667668718 := by decide
theorem cert_e605644413166 : check e605644413166 [[],[]] .sourceHead = true := by decide
def e605644413174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605644413174 : Closed e605644413174 ∧ code e605644413174 = 2804667668726 := by decide
theorem cert_e605644413174 : check e605644413174 [[],[]] .sourceHead = true := by decide
end Blc.Floor41
