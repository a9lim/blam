import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605641467502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605641467502 : Closed e605641467502 ∧ code e605641467502 = 2804664723054 := by decide
theorem cert_e605641467502 : check e605641467502 [[],[]] .chain = true := by decide
def e605641467514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605641467514 : Closed e605641467514 ∧ code e605641467514 = 2804664723066 := by decide
theorem cert_e605641467514 : check e605641467514 [[],[]] .chain = true := by decide
def e605641467678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605641467678 : Closed e605641467678 ∧ code e605641467678 = 2804664723230 := by decide
theorem cert_e605641467678 : check e605641467678 [[],[]] .chain = true := by decide
def e605641467778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e605641467778 : Closed e605641467778 ∧ code e605641467778 = 2804664723330 := by decide
theorem cert_e605641467778 : check e605641467778 [[],[]] .chain = true := by decide
def e605641467790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605641467790 : Closed e605641467790 ∧ code e605641467790 = 2804664723342 := by decide
theorem cert_e605641467790 : check e605641467790 [[],[]] .chain = true := by decide
def e605641467802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605641467802 : Closed e605641467802 ∧ code e605641467802 = 2804664723354 := by decide
theorem cert_e605641467802 : check e605641467802 [[],[]] .chain = true := by decide
def e605641470190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605641470190 : Closed e605641470190 ∧ code e605641470190 = 2804664725742 := by decide
theorem cert_e605641470190 : check e605641470190 [[],[]] .chain = true := by decide
def e605641470198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605641470198 : Closed e605641470198 ∧ code e605641470198 = 2804664725750 := by decide
theorem cert_e605641470198 : check e605641470198 [[],[]] .chain = true := by decide
def e605641470678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605641470678 : Closed e605641470678 ∧ code e605641470678 = 2804664726230 := by decide
theorem cert_e605641470678 : check e605641470678 [[],[]] .chain = true := by decide
def e605641470682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605641470682 : Closed e605641470682 ∧ code e605641470682 = 2804664726234 := by decide
theorem cert_e605641470682 : check e605641470682 [[],[]] .chain = true := by decide
def e605641470698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605641470698 : Closed e605641470698 ∧ code e605641470698 = 2804664726250 := by decide
theorem cert_e605641470698 : check e605641470698 [[],[]] .chain = true := by decide
def e605641470774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605641470774 : Closed e605641470774 ∧ code e605641470774 = 2804664726326 := by decide
theorem cert_e605641470774 : check e605641470774 [[],[]] .chain = true := by decide
def e605641470778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605641470778 : Closed e605641470778 ∧ code e605641470778 = 2804664726330 := by decide
theorem cert_e605641470778 : check e605641470778 [[],[]] .chain = true := by decide
def e605641470850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e605641470850 : Closed e605641470850 ∧ code e605641470850 = 2804664726402 := by decide
theorem cert_e605641470850 : check e605641470850 [[],[]] .chain = true := by decide
def e605641470862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e605641470862 : Closed e605641470862 ∧ code e605641470862 = 2804664726414 := by decide
theorem cert_e605641470862 : check e605641470862 [[],[]] .chain = true := by decide
def e605641470874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605641470874 : Closed e605641470874 ∧ code e605641470874 = 2804664726426 := by decide
theorem cert_e605641470874 : check e605641470874 [[],[]] .chain = true := by decide
def e605641474670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e605641474670 : Closed e605641474670 ∧ code e605641474670 = 2804664730222 := by decide
theorem cert_e605641474670 : check e605641474670 [[],[]] .chain = true := by decide
def e605641474682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e605641474682 : Closed e605641474682 ∧ code e605641474682 = 2804664730234 := by decide
theorem cert_e605641474682 : check e605641474682 [[],[]] .chain = true := by decide
def e605641475950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e605641475950 : Closed e605641475950 ∧ code e605641475950 = 2804664731502 := by decide
theorem cert_e605641475950 : check e605641475950 [[],[]] .chain = true := by decide
def e605641475962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e605641475962 : Closed e605641475962 ∧ code e605641475962 = 2804664731514 := by decide
theorem cert_e605641475962 : check e605641475962 [[],[]] .chain = true := by decide
def e605641476058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e605641476058 : Closed e605641476058 ∧ code e605641476058 = 2804664731610 := by decide
theorem cert_e605641476058 : check e605641476058 [[],[]] .chain = true := by decide
def e605641477358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e605641477358 : Closed e605641477358 ∧ code e605641477358 = 2804664732910 := by decide
theorem cert_e605641477358 : check e605641477358 [[],[]] .chain = true := by decide
def e605641477366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e605641477366 : Closed e605641477366 ∧ code e605641477366 = 2804664732918 := by decide
theorem cert_e605641477366 : check e605641477366 [[],[]] .chain = true := by decide
def e605641477742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e605641477742 : Closed e605641477742 ∧ code e605641477742 = 2804664733294 := by decide
theorem cert_e605641477742 : check e605641477742 [[],[]] .chain = true := by decide
def e605641477754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e605641477754 : Closed e605641477754 ∧ code e605641477754 = 2804664733306 := by decide
theorem cert_e605641477754 : check e605641477754 [[],[]] .chain = true := by decide
def e605641477942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e605641477942 : Closed e605641477942 ∧ code e605641477942 = 2804664733494 := by decide
theorem cert_e605641477942 : check e605641477942 [[],[]] .chain = true := by decide
def e605641477946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e605641477946 : Closed e605641477946 ∧ code e605641477946 = 2804664733498 := by decide
theorem cert_e605641477946 : check e605641477946 [[],[]] .chain = true := by decide
def e605641479854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e605641479854 : Closed e605641479854 ∧ code e605641479854 = 2804664735406 := by decide
theorem cert_e605641479854 : check e605641479854 [[],[]] .chain = true := by decide
def e605641479866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e605641479866 : Closed e605641479866 ∧ code e605641479866 = 2804664735418 := by decide
theorem cert_e605641479866 : check e605641479866 [[],[]] .chain = true := by decide
def e605641479914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e605641479914 : Closed e605641479914 ∧ code e605641479914 = 2804664735466 := by decide
theorem cert_e605641479914 : check e605641479914 [[],[]] .chain = true := by decide
def e605641480106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e605641480106 : Closed e605641480106 ∧ code e605641480106 = 2804664735658 := by decide
theorem cert_e605641480106 : check e605641480106 [[],[]] .chain = true := by decide
def e605641480238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e605641480238 : Closed e605641480238 ∧ code e605641480238 = 2804664735790 := by decide
theorem cert_e605641480238 : check e605641480238 [[],[]] .chain = true := by decide
def e605641480430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e605641480430 : Closed e605641480430 ∧ code e605641480430 = 2804664735982 := by decide
theorem cert_e605641480430 : check e605641480430 [[],[]] .chain = true := by decide
def e605641480438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e605641480438 : Closed e605641480438 ∧ code e605641480438 = 2804664735990 := by decide
theorem cert_e605641480438 : check e605641480438 [[],[]] .chain = true := by decide
def e605641480622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e605641480622 : Closed e605641480622 ∧ code e605641480622 = 2804664736174 := by decide
theorem cert_e605641480622 : check e605641480622 [[],[]] .chain = true := by decide
def e605641480634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605641480634 : Closed e605641480634 ∧ code e605641480634 = 2804664736186 := by decide
theorem cert_e605641480634 : check e605641480634 [[],[]] .chain = true := by decide
def e605641480682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605641480682 : Closed e605641480682 ∧ code e605641480682 = 2804664736234 := by decide
theorem cert_e605641480682 : check e605641480682 [[],[]] .chain = true := by decide
def e605641480814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605641480814 : Closed e605641480814 ∧ code e605641480814 = 2804664736366 := by decide
theorem cert_e605641480814 : check e605641480814 [[],[]] .chain = true := by decide
def e605641480826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605641480826 : Closed e605641480826 ∧ code e605641480826 = 2804664736378 := by decide
theorem cert_e605641480826 : check e605641480826 [[],[]] .chain = true := by decide
def e605641480990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e605641480990 : Closed e605641480990 ∧ code e605641480990 = 2804664736542 := by decide
theorem cert_e605641480990 : check e605641480990 [[],[]] .chain = true := by decide
def e605641481090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e605641481090 : Closed e605641481090 ∧ code e605641481090 = 2804664736642 := by decide
theorem cert_e605641481090 : check e605641481090 [[],[]] .chain = true := by decide
def e605641481102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e605641481102 : Closed e605641481102 ∧ code e605641481102 = 2804664736654 := by decide
theorem cert_e605641481102 : check e605641481102 [[],[]] .chain = true := by decide
def e605641481114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605641481114 : Closed e605641481114 ∧ code e605641481114 = 2804664736666 := by decide
theorem cert_e605641481114 : check e605641481114 [[],[]] .chain = true := by decide
def e605641481326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e605641481326 : Closed e605641481326 ∧ code e605641481326 = 2804664736878 := by decide
theorem cert_e605641481326 : check e605641481326 [[],[]] .chain = true := by decide
def e605641481338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e605641481338 : Closed e605641481338 ∧ code e605641481338 = 2804664736890 := by decide
theorem cert_e605641481338 : check e605641481338 [[],[]] .chain = true := by decide
def e605641481502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e605641481502 : Closed e605641481502 ∧ code e605641481502 = 2804664737054 := by decide
theorem cert_e605641481502 : check e605641481502 [[],[]] .chain = true := by decide
def e605641481670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e605641481670 : Closed e605641481670 ∧ code e605641481670 = 2804664737222 := by decide
theorem cert_e605641481670 : check e605641481670 [[],[]] .chain = true := by decide
def e605641481738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605641481738 : Closed e605641481738 ∧ code e605641481738 = 2804664737290 := by decide
theorem cert_e605641481738 : check e605641481738 [[],[]] .chain = true := by decide
def e605641481782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605641481782 : Closed e605641481782 ∧ code e605641481782 = 2804664737334 := by decide
theorem cert_e605641481782 : check e605641481782 [[],[]] .chain = true := by decide
def e605641481786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605641481786 : Closed e605641481786 ∧ code e605641481786 = 2804664737338 := by decide
theorem cert_e605641481786 : check e605641481786 [[],[]] .chain = true := by decide
def e605641481834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605641481834 : Closed e605641481834 ∧ code e605641481834 = 2804664737386 := by decide
theorem cert_e605641481834 : check e605641481834 [[],[]] .chain = true := by decide
def e605641481858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e605641481858 : Closed e605641481858 ∧ code e605641481858 = 2804664737410 := by decide
theorem cert_e605641481858 : check e605641481858 [[],[]] .chain = true := by decide
def e605641481870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605641481870 : Closed e605641481870 ∧ code e605641481870 = 2804664737422 := by decide
theorem cert_e605641481870 : check e605641481870 [[],[]] .chain = true := by decide
def e605641481882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605641481882 : Closed e605641481882 ∧ code e605641481882 = 2804664737434 := by decide
theorem cert_e605641481882 : check e605641481882 [[],[]] .chain = true := by decide
def e605641481926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605641481926 : Closed e605641481926 ∧ code e605641481926 = 2804664737478 := by decide
theorem cert_e605641481926 : check e605641481926 [[],[]] .chain = true := by decide
def e605641482718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605641482718 : Closed e605641482718 ∧ code e605641482718 = 2804664738270 := by decide
theorem cert_e605641482718 : check e605641482718 [[],[]] .chain = true := by decide
def e605641482742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605641482742 : Closed e605641482742 ∧ code e605641482742 = 2804664738294 := by decide
theorem cert_e605641482742 : check e605641482742 [[],[]] .chain = true := by decide
def e605641483694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605641483694 : Closed e605641483694 ∧ code e605641483694 = 2804664739246 := by decide
theorem cert_e605641483694 : check e605641483694 [[],[]] .chain = true := by decide
def e605641483706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605641483706 : Closed e605641483706 ∧ code e605641483706 = 2804664739258 := by decide
theorem cert_e605641483706 : check e605641483706 [[],[]] .chain = true := by decide
def e605641483754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605641483754 : Closed e605641483754 ∧ code e605641483754 = 2804664739306 := by decide
theorem cert_e605641483754 : check e605641483754 [[],[]] .chain = true := by decide
def e605641483886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605641483886 : Closed e605641483886 ∧ code e605641483886 = 2804664739438 := by decide
theorem cert_e605641483886 : check e605641483886 [[],[]] .chain = true := by decide
def e605641483898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605641483898 : Closed e605641483898 ∧ code e605641483898 = 2804664739450 := by decide
theorem cert_e605641483898 : check e605641483898 [[],[]] .chain = true := by decide
def e605641484062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605641484062 : Closed e605641484062 ∧ code e605641484062 = 2804664739614 := by decide
theorem cert_e605641484062 : check e605641484062 [[],[]] .chain = true := by decide
def e605641484162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e605641484162 : Closed e605641484162 ∧ code e605641484162 = 2804664739714 := by decide
theorem cert_e605641484162 : check e605641484162 [[],[]] .chain = true := by decide
def e605641484174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605641484174 : Closed e605641484174 ∧ code e605641484174 = 2804664739726 := by decide
theorem cert_e605641484174 : check e605641484174 [[],[]] .chain = true := by decide
def e605641484186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605641484186 : Closed e605641484186 ∧ code e605641484186 = 2804664739738 := by decide
theorem cert_e605641484186 : check e605641484186 [[],[]] .chain = true := by decide
def e605641487134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605641487134 : Closed e605641487134 ∧ code e605641487134 = 2804664742686 := by decide
theorem cert_e605641487134 : check e605641487134 [[],[]] .chain = true := by decide
def e605641487302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605641487302 : Closed e605641487302 ∧ code e605641487302 = 2804664742854 := by decide
theorem cert_e605641487302 : check e605641487302 [[],[]] .chain = true := by decide
def e605641488502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605641488502 : Closed e605641488502 ∧ code e605641488502 = 2804664744054 := by decide
theorem cert_e605641488502 : check e605641488502 [[],[]] .chain = true := by decide
def e605641488746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605641488746 : Closed e605641488746 ∧ code e605641488746 = 2804664744298 := by decide
theorem cert_e605641488746 : check e605641488746 [[],[]] .chain = true := by decide
def e605641488770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605641488770 : Closed e605641488770 ∧ code e605641488770 = 2804664744322 := by decide
theorem cert_e605641488770 : check e605641488770 [[],[]] .chain = true := by decide
def e605641488782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605641488782 : Closed e605641488782 ∧ code e605641488782 = 2804664744334 := by decide
theorem cert_e605641488782 : check e605641488782 [[],[]] .chain = true := by decide
def e605641488794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605641488794 : Closed e605641488794 ∧ code e605641488794 = 2804664744346 := by decide
theorem cert_e605641488794 : check e605641488794 [[],[]] .chain = true := by decide
def e605641488838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605641488838 : Closed e605641488838 ∧ code e605641488838 = 2804664744390 := by decide
theorem cert_e605641488838 : check e605641488838 [[],[]] .chain = true := by decide
def e605641490742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e605641490742 : Closed e605641490742 ∧ code e605641490742 = 2804664746294 := by decide
theorem cert_e605641490742 : check e605641490742 [[],[]] .chain = true := by decide
def e605641490746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e605641490746 : Closed e605641490746 ∧ code e605641490746 = 2804664746298 := by decide
theorem cert_e605641490746 : check e605641490746 [[],[]] .chain = true := by decide
def e605641491382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e605641491382 : Closed e605641491382 ∧ code e605641491382 = 2804664746934 := by decide
theorem cert_e605641491382 : check e605641491382 [[],[]] .chain = true := by decide
def e605641491386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e605641491386 : Closed e605641491386 ∧ code e605641491386 = 2804664746938 := by decide
theorem cert_e605641491386 : check e605641491386 [[],[]] .chain = true := by decide
def e605641491418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e605641491418 : Closed e605641491418 ∧ code e605641491418 = 2804664746970 := by decide
theorem cert_e605641491418 : check e605641491418 [[],[]] .chain = true := by decide
def e605641492086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e605641492086 : Closed e605641492086 ∧ code e605641492086 = 2804664747638 := by decide
theorem cert_e605641492086 : check e605641492086 [[],[]] .chain = true := by decide
def e605641492278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e605641492278 : Closed e605641492278 ∧ code e605641492278 = 2804664747830 := by decide
theorem cert_e605641492278 : check e605641492278 [[],[]] .chain = true := by decide
def e605641492282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e605641492282 : Closed e605641492282 ∧ code e605641492282 = 2804664747834 := by decide
theorem cert_e605641492282 : check e605641492282 [[],[]] .chain = true := by decide
def e605641493334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e605641493334 : Closed e605641493334 ∧ code e605641493334 = 2804664748886 := by decide
theorem cert_e605641493334 : check e605641493334 [[],[]] .chain = true := by decide
def e605641493338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e605641493338 : Closed e605641493338 ∧ code e605641493338 = 2804664748890 := by decide
theorem cert_e605641493338 : check e605641493338 [[],[]] .chain = true := by decide
def e605641493354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e605641493354 : Closed e605641493354 ∧ code e605641493354 = 2804664748906 := by decide
theorem cert_e605641493354 : check e605641493354 [[],[]] .chain = true := by decide
def e605641493418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e605641493418 : Closed e605641493418 ∧ code e605641493418 = 2804664748970 := by decide
theorem cert_e605641493418 : check e605641493418 [[],[]] .chain = true := by decide
def e605641493526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e605641493526 : Closed e605641493526 ∧ code e605641493526 = 2804664749078 := by decide
theorem cert_e605641493526 : check e605641493526 [[],[]] .chain = true := by decide
def e605641493622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e605641493622 : Closed e605641493622 ∧ code e605641493622 = 2804664749174 := by decide
theorem cert_e605641493622 : check e605641493622 [[],[]] .chain = true := by decide
def e605641493718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e605641493718 : Closed e605641493718 ∧ code e605641493718 = 2804664749270 := by decide
theorem cert_e605641493718 : check e605641493718 [[],[]] .chain = true := by decide
def e605641493722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e605641493722 : Closed e605641493722 ∧ code e605641493722 = 2804664749274 := by decide
theorem cert_e605641493722 : check e605641493722 [[],[]] .chain = true := by decide
def e605641493738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e605641493738 : Closed e605641493738 ∧ code e605641493738 = 2804664749290 := by decide
theorem cert_e605641493738 : check e605641493738 [[],[]] .chain = true := by decide
def e605641493814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e605641493814 : Closed e605641493814 ∧ code e605641493814 = 2804664749366 := by decide
theorem cert_e605641493814 : check e605641493814 [[],[]] .chain = true := by decide
def e605641493818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e605641493818 : Closed e605641493818 ∧ code e605641493818 = 2804664749370 := by decide
theorem cert_e605641493818 : check e605641493818 [[],[]] .chain = true := by decide
def e605641493890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e605641493890 : Closed e605641493890 ∧ code e605641493890 = 2804664749442 := by decide
theorem cert_e605641493890 : check e605641493890 [[],[]] .chain = true := by decide
def e605641493902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e605641493902 : Closed e605641493902 ∧ code e605641493902 = 2804664749454 := by decide
theorem cert_e605641493902 : check e605641493902 [[],[]] .chain = true := by decide
def e605641493914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e605641493914 : Closed e605641493914 ∧ code e605641493914 = 2804664749466 := by decide
theorem cert_e605641493914 : check e605641493914 [[],[]] .chain = true := by decide
def e605641494026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605641494026 : Closed e605641494026 ∧ code e605641494026 = 2804664749578 := by decide
theorem cert_e605641494026 : check e605641494026 [[],[]] .chain = true := by decide
def e605641494070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605641494070 : Closed e605641494070 ∧ code e605641494070 = 2804664749622 := by decide
theorem cert_e605641494070 : check e605641494070 [[],[]] .chain = true := by decide
def e605641494074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605641494074 : Closed e605641494074 ∧ code e605641494074 = 2804664749626 := by decide
theorem cert_e605641494074 : check e605641494074 [[],[]] .chain = true := by decide
def e605641494122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605641494122 : Closed e605641494122 ∧ code e605641494122 = 2804664749674 := by decide
theorem cert_e605641494122 : check e605641494122 [[],[]] .chain = true := by decide
def e605641494146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e605641494146 : Closed e605641494146 ∧ code e605641494146 = 2804664749698 := by decide
theorem cert_e605641494146 : check e605641494146 [[],[]] .chain = true := by decide
def e605641494158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605641494158 : Closed e605641494158 ∧ code e605641494158 = 2804664749710 := by decide
theorem cert_e605641494158 : check e605641494158 [[],[]] .chain = true := by decide
def e605641494170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605641494170 : Closed e605641494170 ∧ code e605641494170 = 2804664749722 := by decide
theorem cert_e605641494170 : check e605641494170 [[],[]] .chain = true := by decide
def e605641494214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605641494214 : Closed e605641494214 ∧ code e605641494214 = 2804664749766 := by decide
theorem cert_e605641494214 : check e605641494214 [[],[]] .chain = true := by decide
def e605641494766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605641494766 : Closed e605641494766 ∧ code e605641494766 = 2804664750318 := by decide
theorem cert_e605641494766 : check e605641494766 [[],[]] .chain = true := by decide
def e605641494774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605641494774 : Closed e605641494774 ∧ code e605641494774 = 2804664750326 := by decide
theorem cert_e605641494774 : check e605641494774 [[],[]] .chain = true := by decide
def e605641495254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605641495254 : Closed e605641495254 ∧ code e605641495254 = 2804664750806 := by decide
theorem cert_e605641495254 : check e605641495254 [[],[]] .chain = true := by decide
def e605641495258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605641495258 : Closed e605641495258 ∧ code e605641495258 = 2804664750810 := by decide
theorem cert_e605641495258 : check e605641495258 [[],[]] .chain = true := by decide
def e605641495274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605641495274 : Closed e605641495274 ∧ code e605641495274 = 2804664750826 := by decide
theorem cert_e605641495274 : check e605641495274 [[],[]] .chain = true := by decide
def e605641495350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605641495350 : Closed e605641495350 ∧ code e605641495350 = 2804664750902 := by decide
theorem cert_e605641495350 : check e605641495350 [[],[]] .chain = true := by decide
def e605641495354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605641495354 : Closed e605641495354 ∧ code e605641495354 = 2804664750906 := by decide
theorem cert_e605641495354 : check e605641495354 [[],[]] .chain = true := by decide
def e605641495426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e605641495426 : Closed e605641495426 ∧ code e605641495426 = 2804664750978 := by decide
theorem cert_e605641495426 : check e605641495426 [[],[]] .chain = true := by decide
def e605641495438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e605641495438 : Closed e605641495438 ∧ code e605641495438 = 2804664750990 := by decide
theorem cert_e605641495438 : check e605641495438 [[],[]] .chain = true := by decide
def e605641495450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605641495450 : Closed e605641495450 ∧ code e605641495450 = 2804664751002 := by decide
theorem cert_e605641495450 : check e605641495450 [[],[]] .chain = true := by decide
def e605641496694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605641496694 : Closed e605641496694 ∧ code e605641496694 = 2804664752246 := by decide
theorem cert_e605641496694 : check e605641496694 [[],[]] .chain = true := by decide
def e605641496938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605641496938 : Closed e605641496938 ∧ code e605641496938 = 2804664752490 := by decide
theorem cert_e605641496938 : check e605641496938 [[],[]] .chain = true := by decide
def e605641496962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605641496962 : Closed e605641496962 ∧ code e605641496962 = 2804664752514 := by decide
theorem cert_e605641496962 : check e605641496962 [[],[]] .chain = true := by decide
def e605641496974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605641496974 : Closed e605641496974 ∧ code e605641496974 = 2804664752526 := by decide
theorem cert_e605641496974 : check e605641496974 [[],[]] .chain = true := by decide
def e605641496986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605641496986 : Closed e605641496986 ∧ code e605641496986 = 2804664752538 := by decide
theorem cert_e605641496986 : check e605641496986 [[],[]] .chain = true := by decide
def e605641497030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605641497030 : Closed e605641497030 ∧ code e605641497030 = 2804664752582 := by decide
theorem cert_e605641497030 : check e605641497030 [[],[]] .chain = true := by decide
def e605641509742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605641509742 : Closed e605641509742 ∧ code e605641509742 = 2804664765294 := by decide
theorem cert_e605641509742 : check e605641509742 [[],[]] .smaller = true := by decide
def e605641509750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605641509750 : Closed e605641509750 ∧ code e605641509750 = 2804664765302 := by decide
theorem cert_e605641509750 : check e605641509750 [[],[]] .smaller = true := by decide
def e605641509806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605641509806 : Closed e605641509806 ∧ code e605641509806 = 2804664765358 := by decide
theorem cert_e605641509806 : check e605641509806 [[],[]] .smaller = true := by decide
def e605641509818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605641509818 : Closed e605641509818 ∧ code e605641509818 = 2804664765370 := by decide
theorem cert_e605641509818 : check e605641509818 [[],[]] .smaller = true := by decide
def e605641509846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605641509846 : Closed e605641509846 ∧ code e605641509846 = 2804664765398 := by decide
theorem cert_e605641509846 : check e605641509846 [[],[]] .smaller = true := by decide
def e605641509850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605641509850 : Closed e605641509850 ∧ code e605641509850 = 2804664765402 := by decide
theorem cert_e605641509850 : check e605641509850 [[],[]] .smaller = true := by decide
def e605641510126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605641510126 : Closed e605641510126 ∧ code e605641510126 = 2804664765678 := by decide
theorem cert_e605641510126 : check e605641510126 [[],[]] .smaller = true := by decide
def e605641510134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605641510134 : Closed e605641510134 ∧ code e605641510134 = 2804664765686 := by decide
theorem cert_e605641510134 : check e605641510134 [[],[]] .smaller = true := by decide
def e605641510510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605641510510 : Closed e605641510510 ∧ code e605641510510 = 2804664766062 := by decide
theorem cert_e605641510510 : check e605641510510 [[],[]] .smaller = true := by decide
def e605641510522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605641510522 : Closed e605641510522 ∧ code e605641510522 = 2804664766074 := by decide
theorem cert_e605641510522 : check e605641510522 [[],[]] .smaller = true := by decide
def e605641510710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605641510710 : Closed e605641510710 ∧ code e605641510710 = 2804664766262 := by decide
theorem cert_e605641510710 : check e605641510710 [[],[]] .smaller = true := by decide
def e605641510714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605641510714 : Closed e605641510714 ∧ code e605641510714 = 2804664766266 := by decide
theorem cert_e605641510714 : check e605641510714 [[],[]] .smaller = true := by decide
def e605641510846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e605641510846 : Closed e605641510846 ∧ code e605641510846 = 2804664766398 := by decide
theorem cert_e605641510846 : check e605641510846 [[],[]] .chain = true := by decide
def e605641510878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e605641510878 : Closed e605641510878 ∧ code e605641510878 = 2804664766430 := by decide
theorem cert_e605641510878 : check e605641510878 [[],[]] .chain = true := by decide
def e605641518558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605641518558 : Closed e605641518558 ∧ code e605641518558 = 2804664774110 := by decide
theorem cert_e605641518558 : check e605641518558 [[],[]] .chain = true := by decide
def e605641518574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605641518574 : Closed e605641518574 ∧ code e605641518574 = 2804664774126 := by decide
theorem cert_e605641518574 : check e605641518574 [[],[]] .chain = true := by decide
def e605641518942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605641518942 : Closed e605641518942 ∧ code e605641518942 = 2804664774494 := by decide
theorem cert_e605641518942 : check e605641518942 [[],[]] .chain = true := by decide
def e605641518970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605641518970 : Closed e605641518970 ∧ code e605641518970 = 2804664774522 := by decide
theorem cert_e605641518970 : check e605641518970 [[],[]] .chain = true := by decide
def e605641519022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605641519022 : Closed e605641519022 ∧ code e605641519022 = 2804664774574 := by decide
theorem cert_e605641519022 : check e605641519022 [[],[]] .chain = true := by decide
def e605641519034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605641519034 : Closed e605641519034 ∧ code e605641519034 = 2804664774586 := by decide
theorem cert_e605641519034 : check e605641519034 [[],[]] .chain = true := by decide
def e605641520094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605641520094 : Closed e605641520094 ∧ code e605641520094 = 2804664775646 := by decide
theorem cert_e605641520094 : check e605641520094 [[],[]] .chain = true := by decide
def e605641520110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605641520110 : Closed e605641520110 ∧ code e605641520110 = 2804664775662 := by decide
theorem cert_e605641520110 : check e605641520110 [[],[]] .chain = true := by decide
def e605641522398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605641522398 : Closed e605641522398 ∧ code e605641522398 = 2804664777950 := by decide
theorem cert_e605641522398 : check e605641522398 [[],[]] .chain = true := by decide
def e605641522426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605641522426 : Closed e605641522426 ∧ code e605641522426 = 2804664777978 := by decide
theorem cert_e605641522426 : check e605641522426 [[],[]] .chain = true := by decide
def e605641522798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605641522798 : Closed e605641522798 ∧ code e605641522798 = 2804664778350 := by decide
theorem cert_e605641522798 : check e605641522798 [[],[]] .chain = true := by decide
def e605641522810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605641522810 : Closed e605641522810 ∧ code e605641522810 = 2804664778362 := by decide
theorem cert_e605641522810 : check e605641522810 [[],[]] .chain = true := by decide
def e605641551214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605641551214 : Closed e605641551214 ∧ code e605641551214 = 2804664806766 := by decide
theorem cert_e605641551214 : check e605641551214 [[],[]] .chain = true := by decide
def e605641551222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605641551222 : Closed e605641551222 ∧ code e605641551222 = 2804664806774 := by decide
theorem cert_e605641551222 : check e605641551222 [[],[]] .chain = true := by decide
def e605641551278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605641551278 : Closed e605641551278 ∧ code e605641551278 = 2804664806830 := by decide
theorem cert_e605641551278 : check e605641551278 [[],[]] .chain = true := by decide
def e605641551290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605641551290 : Closed e605641551290 ∧ code e605641551290 = 2804664806842 := by decide
theorem cert_e605641551290 : check e605641551290 [[],[]] .chain = true := by decide
def e605641551318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605641551318 : Closed e605641551318 ∧ code e605641551318 = 2804664806870 := by decide
theorem cert_e605641551318 : check e605641551318 [[],[]] .chain = true := by decide
def e605641551322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605641551322 : Closed e605641551322 ∧ code e605641551322 = 2804664806874 := by decide
theorem cert_e605641551322 : check e605641551322 [[],[]] .chain = true := by decide
def e605641551534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605641551534 : Closed e605641551534 ∧ code e605641551534 = 2804664807086 := by decide
theorem cert_e605641551534 : check e605641551534 [[],[]] .chain = true := by decide
def e605641551546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605641551546 : Closed e605641551546 ∧ code e605641551546 = 2804664807098 := by decide
theorem cert_e605641551546 : check e605641551546 [[],[]] .chain = true := by decide
def e605641551594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605641551594 : Closed e605641551594 ∧ code e605641551594 = 2804664807146 := by decide
theorem cert_e605641551594 : check e605641551594 [[],[]] .chain = true := by decide
def e605641551702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605641551702 : Closed e605641551702 ∧ code e605641551702 = 2804664807254 := by decide
theorem cert_e605641551702 : check e605641551702 [[],[]] .chain = true := by decide
def e605641551706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605641551706 : Closed e605641551706 ∧ code e605641551706 = 2804664807258 := by decide
theorem cert_e605641551706 : check e605641551706 [[],[]] .chain = true := by decide
def e605641551722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605641551722 : Closed e605641551722 ∧ code e605641551722 = 2804664807274 := by decide
theorem cert_e605641551722 : check e605641551722 [[],[]] .chain = true := by decide
def e605641552750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605641552750 : Closed e605641552750 ∧ code e605641552750 = 2804664808302 := by decide
theorem cert_e605641552750 : check e605641552750 [[],[]] .chain = true := by decide
def e605641552758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605641552758 : Closed e605641552758 ∧ code e605641552758 = 2804664808310 := by decide
theorem cert_e605641552758 : check e605641552758 [[],[]] .chain = true := by decide
end Blc.Floor41
