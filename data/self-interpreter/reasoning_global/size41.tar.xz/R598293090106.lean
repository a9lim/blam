import CodeBridge
import R598293090106Blk0
import R598293090106Blk6
import R598293090106Blk12
import R598293090106Blk18
import R598293090106Blk24
import R598293090106Blk30
import R598293090106Blk36
namespace Certgen.R598293090106
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Floor41 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit147 : Term := .var 0
def lit138 : Term := .var 1
def lit76 : Term := .var 2
def lit130 : Term := .lam lit147
def lit137 : Term := .lam lit138
def lit145 : Term := .app lit147 lit147
def lit129 : Term := .lam lit130
def lit82 : Term := .app lit138 lit147
def lit136 : Term := .lam lit137
def lit144 : Term := .lam lit145
def lit127 : Term := .app lit147 lit129
def lit134 : Term := .app lit147 lit136
def lit75 : Term := .app lit76 lit82
def lit74 : Term := .lam lit75
def lit73 : Term := .lam lit74
def lit139 : Term := .app lit144 lit144
def lit71 : Term := .app lit147 lit73
def lit86 : Term := .app lit147 lit139
def lit70 : Term := .lam lit71
def lit85 : Term := .lam lit86
def lit133 : Term := .app lit134 lit139
def lit132 : Term := .lam lit133
def lit126 : Term := .app lit127 lit132
def lit125 : Term := .lam lit126
def lit59 : Term := .app lit70 lit70
def lit58 : Term := .app lit59 lit138
def lit57 : Term := .app lit58 lit147
def lit119 : Term := .app lit134 lit125
def lit118 : Term := .lam lit119
def lit112 : Term := .app lit134 lit118
def lit111 : Term := .lam lit112
def lit46 : Term := .app lit70 lit57
def lit45 : Term := .lam lit46
def lit44 : Term := .lam lit45
def lit105 : Term := .app lit134 lit111
def lit104 : Term := .lam lit105
def lit43 : Term := .app lit44 lit82
def lit42 : Term := .lam lit43
def lit41 : Term := .lam lit42
def lit98 : Term := .app lit134 lit104
def lit97 : Term := .lam lit98
def lit2 : Term := .app lit44 lit41
def lit1 : Term := .app lit2 lit85
def lit0 : Term := .app lit1 lit97
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub147 : model.term 147 = lit147 := model.var_eq 147 0 (by rfl)
theorem sub146 : model.term 146 = lit147 := model.var_eq 146 0 (by rfl)
theorem sub145 : model.term 145 = lit145 := by rw [model.app_eq 145 146 147 (by rfl), sub146, sub147]; rfl
theorem sub144 : model.term 144 = lit144 := by rw [model.lam_eq 144 145 (by rfl), sub145]; rfl
theorem sub143 : model.term 143 = lit147 := model.var_eq 143 0 (by rfl)
theorem sub142 : model.term 142 = lit147 := model.var_eq 142 0 (by rfl)
theorem sub141 : model.term 141 = lit145 := by rw [model.app_eq 141 142 143 (by rfl), sub142, sub143]; rfl
theorem sub140 : model.term 140 = lit144 := by rw [model.lam_eq 140 141 (by rfl), sub141]; rfl
theorem sub139 : model.term 139 = lit139 := by rw [model.app_eq 139 140 144 (by rfl), sub140, sub144]; rfl
theorem sub138 : model.term 138 = lit138 := model.var_eq 138 1 (by rfl)
theorem sub137 : model.term 137 = lit137 := by rw [model.lam_eq 137 138 (by rfl), sub138]; rfl
theorem sub136 : model.term 136 = lit136 := by rw [model.lam_eq 136 137 (by rfl), sub137]; rfl
theorem sub135 : model.term 135 = lit147 := model.var_eq 135 0 (by rfl)
theorem sub134 : model.term 134 = lit134 := by rw [model.app_eq 134 135 136 (by rfl), sub135, sub136]; rfl
theorem sub133 : model.term 133 = lit133 := by rw [model.app_eq 133 134 139 (by rfl), sub134, sub139]; rfl
theorem sub132 : model.term 132 = lit132 := by rw [model.lam_eq 132 133 (by rfl), sub133]; rfl
theorem sub131 : model.term 131 = lit147 := model.var_eq 131 0 (by rfl)
theorem sub130 : model.term 130 = lit130 := by rw [model.lam_eq 130 131 (by rfl), sub131]; rfl
theorem sub129 : model.term 129 = lit129 := by rw [model.lam_eq 129 130 (by rfl), sub130]; rfl
theorem sub128 : model.term 128 = lit147 := model.var_eq 128 0 (by rfl)
theorem sub127 : model.term 127 = lit127 := by rw [model.app_eq 127 128 129 (by rfl), sub128, sub129]; rfl
theorem sub126 : model.term 126 = lit126 := by rw [model.app_eq 126 127 132 (by rfl), sub127, sub132]; rfl
theorem sub125 : model.term 125 = lit125 := by rw [model.lam_eq 125 126 (by rfl), sub126]; rfl
theorem sub124 : model.term 124 = lit138 := model.var_eq 124 1 (by rfl)
theorem sub123 : model.term 123 = lit137 := by rw [model.lam_eq 123 124 (by rfl), sub124]; rfl
theorem sub122 : model.term 122 = lit136 := by rw [model.lam_eq 122 123 (by rfl), sub123]; rfl
theorem sub121 : model.term 121 = lit147 := model.var_eq 121 0 (by rfl)
theorem sub120 : model.term 120 = lit134 := by rw [model.app_eq 120 121 122 (by rfl), sub121, sub122]; rfl
theorem sub119 : model.term 119 = lit119 := by rw [model.app_eq 119 120 125 (by rfl), sub120, sub125]; rfl
theorem sub118 : model.term 118 = lit118 := by rw [model.lam_eq 118 119 (by rfl), sub119]; rfl
theorem sub117 : model.term 117 = lit138 := model.var_eq 117 1 (by rfl)
theorem sub116 : model.term 116 = lit137 := by rw [model.lam_eq 116 117 (by rfl), sub117]; rfl
theorem sub115 : model.term 115 = lit136 := by rw [model.lam_eq 115 116 (by rfl), sub116]; rfl
theorem sub114 : model.term 114 = lit147 := model.var_eq 114 0 (by rfl)
theorem sub113 : model.term 113 = lit134 := by rw [model.app_eq 113 114 115 (by rfl), sub114, sub115]; rfl
theorem sub112 : model.term 112 = lit112 := by rw [model.app_eq 112 113 118 (by rfl), sub113, sub118]; rfl
theorem sub111 : model.term 111 = lit111 := by rw [model.lam_eq 111 112 (by rfl), sub112]; rfl
theorem sub110 : model.term 110 = lit138 := model.var_eq 110 1 (by rfl)
theorem sub109 : model.term 109 = lit137 := by rw [model.lam_eq 109 110 (by rfl), sub110]; rfl
theorem sub108 : model.term 108 = lit136 := by rw [model.lam_eq 108 109 (by rfl), sub109]; rfl
theorem sub107 : model.term 107 = lit147 := model.var_eq 107 0 (by rfl)
theorem sub106 : model.term 106 = lit134 := by rw [model.app_eq 106 107 108 (by rfl), sub107, sub108]; rfl
theorem sub105 : model.term 105 = lit105 := by rw [model.app_eq 105 106 111 (by rfl), sub106, sub111]; rfl
theorem sub104 : model.term 104 = lit104 := by rw [model.lam_eq 104 105 (by rfl), sub105]; rfl
theorem sub103 : model.term 103 = lit138 := model.var_eq 103 1 (by rfl)
theorem sub102 : model.term 102 = lit137 := by rw [model.lam_eq 102 103 (by rfl), sub103]; rfl
theorem sub101 : model.term 101 = lit136 := by rw [model.lam_eq 101 102 (by rfl), sub102]; rfl
theorem sub100 : model.term 100 = lit147 := model.var_eq 100 0 (by rfl)
theorem sub99 : model.term 99 = lit134 := by rw [model.app_eq 99 100 101 (by rfl), sub100, sub101]; rfl
theorem sub98 : model.term 98 = lit98 := by rw [model.app_eq 98 99 104 (by rfl), sub99, sub104]; rfl
theorem sub97 : model.term 97 = lit97 := by rw [model.lam_eq 97 98 (by rfl), sub98]; rfl
theorem sub96 : model.term 96 = lit147 := model.var_eq 96 0 (by rfl)
theorem sub95 : model.term 95 = lit147 := model.var_eq 95 0 (by rfl)
theorem sub94 : model.term 94 = lit145 := by rw [model.app_eq 94 95 96 (by rfl), sub95, sub96]; rfl
theorem sub93 : model.term 93 = lit144 := by rw [model.lam_eq 93 94 (by rfl), sub94]; rfl
theorem sub92 : model.term 92 = lit147 := model.var_eq 92 0 (by rfl)
theorem sub91 : model.term 91 = lit147 := model.var_eq 91 0 (by rfl)
theorem sub90 : model.term 90 = lit145 := by rw [model.app_eq 90 91 92 (by rfl), sub91, sub92]; rfl
theorem sub89 : model.term 89 = lit144 := by rw [model.lam_eq 89 90 (by rfl), sub90]; rfl
theorem sub88 : model.term 88 = lit139 := by rw [model.app_eq 88 89 93 (by rfl), sub89, sub93]; rfl
theorem sub87 : model.term 87 = lit147 := model.var_eq 87 0 (by rfl)
theorem sub86 : model.term 86 = lit86 := by rw [model.app_eq 86 87 88 (by rfl), sub87, sub88]; rfl
theorem sub85 : model.term 85 = lit85 := by rw [model.lam_eq 85 86 (by rfl), sub86]; rfl
theorem sub84 : model.term 84 = lit147 := model.var_eq 84 0 (by rfl)
theorem sub83 : model.term 83 = lit138 := model.var_eq 83 1 (by rfl)
theorem sub82 : model.term 82 = lit82 := by rw [model.app_eq 82 83 84 (by rfl), sub83, sub84]; rfl
theorem sub81 : model.term 81 = lit147 := model.var_eq 81 0 (by rfl)
theorem sub80 : model.term 80 = lit138 := model.var_eq 80 1 (by rfl)
theorem sub79 : model.term 79 = lit147 := model.var_eq 79 0 (by rfl)
theorem sub78 : model.term 78 = lit138 := model.var_eq 78 1 (by rfl)
theorem sub77 : model.term 77 = lit82 := by rw [model.app_eq 77 78 79 (by rfl), sub78, sub79]; rfl
theorem sub76 : model.term 76 = lit76 := model.var_eq 76 2 (by rfl)
theorem sub75 : model.term 75 = lit75 := by rw [model.app_eq 75 76 77 (by rfl), sub76, sub77]; rfl
theorem sub74 : model.term 74 = lit74 := by rw [model.lam_eq 74 75 (by rfl), sub75]; rfl
theorem sub73 : model.term 73 = lit73 := by rw [model.lam_eq 73 74 (by rfl), sub74]; rfl
theorem sub72 : model.term 72 = lit147 := model.var_eq 72 0 (by rfl)
theorem sub71 : model.term 71 = lit71 := by rw [model.app_eq 71 72 73 (by rfl), sub72, sub73]; rfl
theorem sub70 : model.term 70 = lit70 := by rw [model.lam_eq 70 71 (by rfl), sub71]; rfl
theorem sub69 : model.term 69 = lit147 := model.var_eq 69 0 (by rfl)
theorem sub68 : model.term 68 = lit138 := model.var_eq 68 1 (by rfl)
theorem sub67 : model.term 67 = lit82 := by rw [model.app_eq 67 68 69 (by rfl), sub68, sub69]; rfl
theorem sub66 : model.term 66 = lit76 := model.var_eq 66 2 (by rfl)
theorem sub65 : model.term 65 = lit75 := by rw [model.app_eq 65 66 67 (by rfl), sub66, sub67]; rfl
theorem sub64 : model.term 64 = lit74 := by rw [model.lam_eq 64 65 (by rfl), sub65]; rfl
theorem sub63 : model.term 63 = lit73 := by rw [model.lam_eq 63 64 (by rfl), sub64]; rfl
theorem sub62 : model.term 62 = lit147 := model.var_eq 62 0 (by rfl)
theorem sub61 : model.term 61 = lit71 := by rw [model.app_eq 61 62 63 (by rfl), sub62, sub63]; rfl
theorem sub60 : model.term 60 = lit70 := by rw [model.lam_eq 60 61 (by rfl), sub61]; rfl
theorem sub59 : model.term 59 = lit59 := by rw [model.app_eq 59 60 70 (by rfl), sub60, sub70]; rfl
theorem sub58 : model.term 58 = lit58 := by rw [model.app_eq 58 59 80 (by rfl), sub59, sub80]; rfl
theorem sub57 : model.term 57 = lit57 := by rw [model.app_eq 57 58 81 (by rfl), sub58, sub81]; rfl
theorem sub56 : model.term 56 = lit147 := model.var_eq 56 0 (by rfl)
theorem sub55 : model.term 55 = lit138 := model.var_eq 55 1 (by rfl)
theorem sub54 : model.term 54 = lit82 := by rw [model.app_eq 54 55 56 (by rfl), sub55, sub56]; rfl
theorem sub53 : model.term 53 = lit76 := model.var_eq 53 2 (by rfl)
theorem sub52 : model.term 52 = lit75 := by rw [model.app_eq 52 53 54 (by rfl), sub53, sub54]; rfl
theorem sub51 : model.term 51 = lit74 := by rw [model.lam_eq 51 52 (by rfl), sub52]; rfl
theorem sub50 : model.term 50 = lit73 := by rw [model.lam_eq 50 51 (by rfl), sub51]; rfl
theorem sub49 : model.term 49 = lit147 := model.var_eq 49 0 (by rfl)
theorem sub48 : model.term 48 = lit71 := by rw [model.app_eq 48 49 50 (by rfl), sub49, sub50]; rfl
theorem sub47 : model.term 47 = lit70 := by rw [model.lam_eq 47 48 (by rfl), sub48]; rfl
theorem sub46 : model.term 46 = lit46 := by rw [model.app_eq 46 47 57 (by rfl), sub47, sub57]; rfl
theorem sub45 : model.term 45 = lit45 := by rw [model.lam_eq 45 46 (by rfl), sub46]; rfl
theorem sub44 : model.term 44 = lit44 := by rw [model.lam_eq 44 45 (by rfl), sub45]; rfl
theorem sub43 : model.term 43 = lit43 := by rw [model.app_eq 43 44 82 (by rfl), sub44, sub82]; rfl
theorem sub42 : model.term 42 = lit42 := by rw [model.lam_eq 42 43 (by rfl), sub43]; rfl
theorem sub41 : model.term 41 = lit41 := by rw [model.lam_eq 41 42 (by rfl), sub42]; rfl
theorem sub40 : model.term 40 = lit147 := model.var_eq 40 0 (by rfl)
theorem sub39 : model.term 39 = lit138 := model.var_eq 39 1 (by rfl)
theorem sub38 : model.term 38 = lit147 := model.var_eq 38 0 (by rfl)
theorem sub37 : model.term 37 = lit138 := model.var_eq 37 1 (by rfl)
theorem sub36 : model.term 36 = lit82 := by rw [model.app_eq 36 37 38 (by rfl), sub37, sub38]; rfl
theorem sub35 : model.term 35 = lit76 := model.var_eq 35 2 (by rfl)
theorem sub34 : model.term 34 = lit75 := by rw [model.app_eq 34 35 36 (by rfl), sub35, sub36]; rfl
theorem sub33 : model.term 33 = lit74 := by rw [model.lam_eq 33 34 (by rfl), sub34]; rfl
theorem sub32 : model.term 32 = lit73 := by rw [model.lam_eq 32 33 (by rfl), sub33]; rfl
theorem sub31 : model.term 31 = lit147 := model.var_eq 31 0 (by rfl)
theorem sub30 : model.term 30 = lit71 := by rw [model.app_eq 30 31 32 (by rfl), sub31, sub32]; rfl
theorem sub29 : model.term 29 = lit70 := by rw [model.lam_eq 29 30 (by rfl), sub30]; rfl
theorem sub28 : model.term 28 = lit147 := model.var_eq 28 0 (by rfl)
theorem sub27 : model.term 27 = lit138 := model.var_eq 27 1 (by rfl)
theorem sub26 : model.term 26 = lit82 := by rw [model.app_eq 26 27 28 (by rfl), sub27, sub28]; rfl
theorem sub25 : model.term 25 = lit76 := model.var_eq 25 2 (by rfl)
theorem sub24 : model.term 24 = lit75 := by rw [model.app_eq 24 25 26 (by rfl), sub25, sub26]; rfl
theorem sub23 : model.term 23 = lit74 := by rw [model.lam_eq 23 24 (by rfl), sub24]; rfl
theorem sub22 : model.term 22 = lit73 := by rw [model.lam_eq 22 23 (by rfl), sub23]; rfl
theorem sub21 : model.term 21 = lit147 := model.var_eq 21 0 (by rfl)
theorem sub20 : model.term 20 = lit71 := by rw [model.app_eq 20 21 22 (by rfl), sub21, sub22]; rfl
theorem sub19 : model.term 19 = lit70 := by rw [model.lam_eq 19 20 (by rfl), sub20]; rfl
theorem sub18 : model.term 18 = lit59 := by rw [model.app_eq 18 19 29 (by rfl), sub19, sub29]; rfl
theorem sub17 : model.term 17 = lit58 := by rw [model.app_eq 17 18 39 (by rfl), sub18, sub39]; rfl
theorem sub16 : model.term 16 = lit57 := by rw [model.app_eq 16 17 40 (by rfl), sub17, sub40]; rfl
theorem sub15 : model.term 15 = lit147 := model.var_eq 15 0 (by rfl)
theorem sub14 : model.term 14 = lit138 := model.var_eq 14 1 (by rfl)
theorem sub13 : model.term 13 = lit82 := by rw [model.app_eq 13 14 15 (by rfl), sub14, sub15]; rfl
theorem sub12 : model.term 12 = lit76 := model.var_eq 12 2 (by rfl)
theorem sub11 : model.term 11 = lit75 := by rw [model.app_eq 11 12 13 (by rfl), sub12, sub13]; rfl
theorem sub10 : model.term 10 = lit74 := by rw [model.lam_eq 10 11 (by rfl), sub11]; rfl
theorem sub9 : model.term 9 = lit73 := by rw [model.lam_eq 9 10 (by rfl), sub10]; rfl
theorem sub8 : model.term 8 = lit147 := model.var_eq 8 0 (by rfl)
theorem sub7 : model.term 7 = lit71 := by rw [model.app_eq 7 8 9 (by rfl), sub8, sub9]; rfl
theorem sub6 : model.term 6 = lit70 := by rw [model.lam_eq 6 7 (by rfl), sub7]; rfl
theorem sub5 : model.term 5 = lit46 := by rw [model.app_eq 5 6 16 (by rfl), sub6, sub16]; rfl
theorem sub4 : model.term 4 = lit45 := by rw [model.lam_eq 4 5 (by rfl), sub5]; rfl
theorem sub3 : model.term 3 = lit44 := by rw [model.lam_eq 3 4 (by rfl), sub4]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 41 (by rfl), sub3, sub41]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 85 (by rfl), sub2, sub85]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 97 (by rfl), sub1, sub97]; rfl
theorem allValid (i : Nat) (h : i < 438) : validState i = true := by
 by_cases h216 : i < 216
 · by_cases h108 : i < 108
   · by_cases h48 : i < 48
     · by_cases h24 : i < 24
       · by_cases h12 : i < 12
         · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
       · by_cases h36 : i < 36
         · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
     · by_cases h72 : i < 72
       · by_cases h60 : i < 60
         · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
       · by_cases h84 : i < 84
         · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
         · by_cases h96 : i < 96
           · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
   · by_cases h156 : i < 156
     · by_cases h132 : i < 132
       · by_cases h120 : i < 120
         · exact FloorIndex.rangeOK_at bl108 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl120 (by omega) (by omega)
       · by_cases h144 : i < 144
         · exact FloorIndex.rangeOK_at bl132 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl144 (by omega) (by omega)
     · by_cases h180 : i < 180
       · by_cases h168 : i < 168
         · exact FloorIndex.rangeOK_at bl156 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl168 (by omega) (by omega)
       · by_cases h192 : i < 192
         · exact FloorIndex.rangeOK_at bl180 (by omega) (by omega)
         · by_cases h204 : i < 204
           · exact FloorIndex.rangeOK_at bl192 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl204 (by omega) (by omega)
 · by_cases h324 : i < 324
   · by_cases h264 : i < 264
     · by_cases h240 : i < 240
       · by_cases h228 : i < 228
         · exact FloorIndex.rangeOK_at bl216 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl228 (by omega) (by omega)
       · by_cases h252 : i < 252
         · exact FloorIndex.rangeOK_at bl240 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl252 (by omega) (by omega)
     · by_cases h288 : i < 288
       · by_cases h276 : i < 276
         · exact FloorIndex.rangeOK_at bl264 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl276 (by omega) (by omega)
       · by_cases h300 : i < 300
         · exact FloorIndex.rangeOK_at bl288 (by omega) (by omega)
         · by_cases h312 : i < 312
           · exact FloorIndex.rangeOK_at bl300 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl312 (by omega) (by omega)
   · by_cases h384 : i < 384
     · by_cases h348 : i < 348
       · by_cases h336 : i < 336
         · exact FloorIndex.rangeOK_at bl324 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl336 (by omega) (by omega)
       · by_cases h360 : i < 360
         · exact FloorIndex.rangeOK_at bl348 (by omega) (by omega)
         · by_cases h372 : i < 372
           · exact FloorIndex.rangeOK_at bl360 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl372 (by omega) (by omega)
     · by_cases h408 : i < 408
       · by_cases h396 : i < 396
         · exact FloorIndex.rangeOK_at bl384 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl396 (by omega) (by omega)
       · by_cases h420 : i < 420
         · exact FloorIndex.rangeOK_at bl408 (by omega) (by omega)
         · by_cases h432 : i < 432
           · exact FloorIndex.rangeOK_at bl420 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl432 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 438
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e598293090106 := by
 intro he
 have hp : replay [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.right],[.left,.left,.right,.under],[.left,.left]] (call e598293090106 (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) []) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 3) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R598293090106
