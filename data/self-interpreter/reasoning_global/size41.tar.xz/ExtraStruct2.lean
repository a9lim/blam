import Extra41
import Batch030
import Batch031
import Batch034
import Batch035
import Batch038
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness596279078634
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.app u2 u0
private def u4 := Term.lam u3
private def u5 := Term.var 1
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.app u7 u0
private def u9 := Term.app u8 u0
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u4 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := SO.app sou2 sou0
private theorem sou4 : SO u4 := so_closed_lam (by decide) sou3
private def u14 := Term.app u0 u5
private def u15 := Term.app u5 u0
private def u16 := Term.app u15 u0
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.var 2
private theorem sou7 : SO u7 := SO.app sou5 sou6
private theorem sou8 : SO u8 := SO.app sou7 sou0
private theorem sou9 : SO u9 := SO.app sou8 sou0
private theorem sou14 : SO u14 := SO.app sou0 sou5
private theorem sou10 : SO u10 := SO.lam (r := u14) (g := u16) sou9 sou14 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.lam (r := u0) (g := u10) sou10 sou0 (by decide) (by decide)
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou4 sou12
theorem nege596279078634 : ¬ IsSelfInterpreter e596279078634 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege596279078634
end Witness596279078634
namespace Witness596279078762
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.app u2 u0
private def u4 := Term.lam u3
private def u5 := Term.var 2
private def u6 := Term.var 1
private def u7 := Term.app u5 u6
private def u8 := Term.app u7 u0
private def u9 := Term.app u8 u0
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u4 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := SO.app sou2 sou0
private theorem sou4 : SO u4 := so_closed_lam (by decide) sou3
private def u14 := Term.app u6 u0
private def u15 := Term.app u14 u0
private theorem sou5 : SO u5 := SO.var 2
private theorem sou6 : SO u6 := SO.var 1
private theorem sou7 : SO u7 := SO.app sou5 sou6
private theorem sou8 : SO u8 := SO.app sou7 sou0
private theorem sou9 : SO u9 := SO.app sou8 sou0
private theorem sou14 : SO u14 := SO.app sou6 sou0
private theorem sou10 : SO u10 := SO.lam (r := u14) (g := u15) sou9 sou14 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.lam (r := u0) (g := u10) sou10 sou0 (by decide) (by decide)
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou4 sou12
theorem nege596279078762 : ¬ IsSelfInterpreter e596279078762 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege596279078762
end Witness596279078762
namespace Witness596279823598
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.app u2 u0
private def u4 := Term.lam u3
private def u5 := Term.var 1
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u4 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := SO.app sou2 sou0
private theorem sou4 : SO u4 := so_closed_lam (by decide) sou3
private def u14 := Term.app u0 u5
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.var 2
private theorem sou7 : SO u7 := SO.app sou5 sou6
private theorem sou8 : SO u8 := SO.app sou0 sou7
private theorem sou14 : SO u14 := SO.app sou0 sou5
private theorem sou9 : SO u9 := SO.lam (r := u14) (g := u14) sou8 sou14 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou4 sou12
theorem nege596279823598 : ¬ IsSelfInterpreter e596279823598 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege596279823598
end Witness596279823598
namespace Witness596279823606
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.app u2 u0
private def u4 := Term.lam u3
private def u5 := Term.var 2
private def u6 := Term.var 1
private def u7 := Term.app u5 u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u4 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := SO.app sou2 sou0
private theorem sou4 : SO u4 := so_closed_lam (by decide) sou3
private def u14 := Term.app u6 u0
private def u15 := Term.app u0 u6
private theorem sou5 : SO u5 := SO.var 2
private theorem sou6 : SO u6 := SO.var 1
private theorem sou7 : SO u7 := SO.app sou5 sou6
private theorem sou8 : SO u8 := SO.app sou0 sou7
private theorem sou14 : SO u14 := SO.app sou6 sou0
private theorem sou9 : SO u9 := SO.lam (r := u14) (g := u15) sou8 sou14 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou4 sou12
theorem nege596279823606 : ¬ IsSelfInterpreter e596279823606 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege596279823606
end Witness596279823606
namespace Witness597436751322
private def u0 := Term.var 0
private def u1 := Term.var 1
private def u2 := Term.lam u1
private def u3 := Term.app u0 u2
private def u4 := Term.app u3 u0
private def u5 := Term.lam u4
private def u6 := Term.var 2
private def u7 := Term.app u1 u6
private def u8 := Term.app u7 u1
private def u9 := Term.app u8 u0
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u5 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.var 1
private theorem sou2 : SO u2 := so_dead (by decide) sou1
private theorem sou3 : SO u3 := SO.app sou0 sou2
private theorem sou4 : SO u4 := SO.app sou3 sou0
private theorem sou5 : SO u5 := so_closed_lam (by decide) sou4
private def u14 := Term.app u0 u1
private def u15 := Term.app u14 u0
private def u16 := Term.app u1 u0
private theorem sou6 : SO u6 := SO.var 2
private theorem sou7 : SO u7 := SO.app sou1 sou6
private theorem sou8 : SO u8 := SO.app sou7 sou1
private theorem sou9 : SO u9 := SO.app sou8 sou0
private theorem sou14 : SO u14 := SO.app sou0 sou1
private theorem sou15 : SO u15 := SO.app sou14 sou0
private theorem sou10 : SO u10 := SO.lam (r := u15) (g := u16) sou9 sou15 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.lam (r := u0) (g := u10) sou10 sou0 (by decide) (by decide)
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou5 sou12
theorem nege597436751322 : ¬ IsSelfInterpreter e597436751322 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege597436751322
end Witness597436751322
namespace Witness597890436334
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u0 u1
private def u3 := Term.app u2 u0
private def u4 := Term.lam u3
private def u5 := Term.var 1
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u4 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou0 sou1
private theorem sou3 : SO u3 := SO.app sou2 sou0
private theorem sou4 : SO u4 := so_closed_lam (by decide) sou3
private def u14 := Term.app u0 u5
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.var 2
private theorem sou7 : SO u7 := SO.app sou5 sou6
private theorem sou8 : SO u8 := SO.app sou0 sou7
private theorem sou14 : SO u14 := SO.app sou0 sou5
private theorem sou9 : SO u9 := SO.lam (r := u14) (g := u14) sou8 sou14 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou4 sou12
theorem nege597890436334 : ¬ IsSelfInterpreter e597890436334 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege597890436334
end Witness597890436334
namespace Witness597890436342
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u0 u1
private def u3 := Term.app u2 u0
private def u4 := Term.lam u3
private def u5 := Term.var 2
private def u6 := Term.var 1
private def u7 := Term.app u5 u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u4 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou0 sou1
private theorem sou3 : SO u3 := SO.app sou2 sou0
private theorem sou4 : SO u4 := so_closed_lam (by decide) sou3
private def u14 := Term.app u6 u0
private def u15 := Term.app u0 u6
private theorem sou5 : SO u5 := SO.var 2
private theorem sou6 : SO u6 := SO.var 1
private theorem sou7 : SO u7 := SO.app sou5 sou6
private theorem sou8 : SO u8 := SO.app sou0 sou7
private theorem sou14 : SO u14 := SO.app sou6 sou0
private theorem sou9 : SO u9 := SO.lam (r := u14) (g := u15) sou8 sou14 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou4 sou12
theorem nege597890436342 : ¬ IsSelfInterpreter e597890436342 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege597890436342
end Witness597890436342
namespace Witness598292499318
private def u0 := Term.var 0
private def u1 := Term.var 2
private def u2 := Term.app u0 u1
private def u3 := Term.var 1
private def u4 := Term.app u2 u3
private def u5 := Term.lam u4
private def u6 := Term.app u0 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u8 u8
private def u10 := Term.app u9 u9
theorem nege598292499318 : ¬ IsSelfInterpreter e598292499318 := by
  intro he
  have h : replay [[]] e598292499318 = some u10 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u10) (by decide) (by decide) hj
#print axioms nege598292499318
end Witness598292499318
end Blc.Floor41
