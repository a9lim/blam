import Extra41
import Batch030
import Batch031
import Batch033
import Batch034
import Batch035
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness596279078742
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u4 u1
private def u6 := Term.app u5 u0
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u10 u9
private def u12 := Term.app u11 u9
private def u13 := Term.app u12 u0
private def u14 := Term.lam u0
private def u15 := Term.lam u14
private def u16 := Term.app u1 u15
private def u17 := Term.lam u2
private def u18 := Term.app u1 u17
private def u19 := Term.var 4
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u16 u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u26
private def u28 := Term.app u13 u27
private def u29 := Term.app u0 u17
private def u30 := Term.app u29 u1
private def u31 := Term.app u9 u1
private def u32 := Term.app u31 u1
private def u33 := Term.app u32 u0
private def u34 := Term.lam u33
private def u35 := Term.lam u34
private def u36 := Term.app u35 u9
private def u37 := Term.app u36 u9
private def u38 := Term.app u37 u0
private def u39 := Term.app u38 u27
theorem nege596279078742 : ¬ IsSelfInterpreter e596279078742 := by
  intro he
  have hv : NFt u30 := by decide
  have reach : Betas (Floor40.call e596279078742 u0 u2 u1 []) u30 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left]] (Floor40.call e596279078742 u0 u2 u1 []) = some u28 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u28) (u := u39) [] (by decide) (replay_sound (ps := [[.left,.left,.left],[.left,.left]]) (by decide)) j hj
#print axioms nege596279078742
end Witness596279078742
namespace Witness596279078746
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u4 u0
private def u6 := Term.app u5 u1
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u10 u9
private def u12 := Term.app u11 u9
private def u13 := Term.app u12 u0
private def u14 := Term.lam u0
private def u15 := Term.lam u14
private def u16 := Term.app u1 u15
private def u17 := Term.lam u2
private def u18 := Term.app u1 u17
private def u19 := Term.var 4
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u16 u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u26
private def u28 := Term.app u13 u27
private def u29 := Term.app u0 u17
private def u30 := Term.app u29 u1
private def u31 := Term.app u9 u1
private def u32 := Term.app u31 u0
private def u33 := Term.app u32 u1
private def u34 := Term.lam u33
private def u35 := Term.lam u34
private def u36 := Term.app u35 u9
private def u37 := Term.app u36 u9
private def u38 := Term.app u37 u0
private def u39 := Term.app u38 u27
theorem nege596279078746 : ¬ IsSelfInterpreter e596279078746 := by
  intro he
  have hv : NFt u30 := by decide
  have reach : Betas (Floor40.call e596279078746 u0 u2 u1 []) u30 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left]] (Floor40.call e596279078746 u0 u2 u1 []) = some u28 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u28) (u := u39) [] (by decide) (replay_sound (ps := [[.left,.left,.left],[.left,.left]]) (by decide)) j hj
#print axioms nege596279078746
end Witness596279078746
namespace Witness596279823222
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u1 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.lam u12
private def u14 := Term.app u9 u13
private def u15 := Term.app u14 u9
private def u16 := Term.app u15 u9
private def u17 := Term.app u16 u0
private def u18 := Term.lam u0
private def u19 := Term.lam u18
private def u20 := Term.app u1 u19
private def u21 := Term.lam u2
private def u22 := Term.app u1 u21
private def u23 := Term.var 4
private def u24 := Term.app u20 u23
private def u25 := Term.lam u24
private def u26 := Term.app u22 u25
private def u27 := Term.lam u26
private def u28 := Term.app u20 u27
private def u29 := Term.lam u28
private def u30 := Term.app u20 u29
private def u31 := Term.lam u30
private def u32 := Term.app u17 u31
private def u33 := Term.app u0 u21
private def u34 := Term.app u33 u1
private def u35 := Term.app u1 u13
private def u36 := Term.app u35 u0
private def u37 := Term.lam u36
private def u38 := Term.lam u37
private def u39 := Term.app u13 u38
private def u40 := Term.app u39 u9
private def u41 := Term.app u40 u9
private def u42 := Term.app u41 u0
private def u43 := Term.app u42 u31
theorem nege596279823222 : ¬ IsSelfInterpreter e596279823222 := by
  intro he
  have hv : NFt u34 := by decide
  have reach : Betas (Floor40.call e596279823222 u0 u2 u1 []) u34 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left,.left]] (Floor40.call e596279823222 u0 u2 u1 []) = some u32 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u32) (u := u43) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]]) (by decide)) j hj
#print axioms nege596279823222
end Witness596279823222
namespace Witness596279823278
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u0 u1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u3 u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u9 u12
private def u14 := Term.app u13 u9
private def u15 := Term.app u14 u9
private def u16 := Term.app u15 u0
private def u17 := Term.lam u0
private def u18 := Term.lam u17
private def u19 := Term.app u1 u18
private def u20 := Term.lam u2
private def u21 := Term.app u1 u20
private def u22 := Term.var 4
private def u23 := Term.app u19 u22
private def u24 := Term.lam u23
private def u25 := Term.app u21 u24
private def u26 := Term.lam u25
private def u27 := Term.app u19 u26
private def u28 := Term.lam u27
private def u29 := Term.app u19 u28
private def u30 := Term.lam u29
private def u31 := Term.app u16 u30
private def u32 := Term.app u0 u20
private def u33 := Term.app u32 u1
private def u34 := Term.app u3 u12
private def u35 := Term.lam u34
private def u36 := Term.lam u35
private def u37 := Term.app u12 u36
private def u38 := Term.app u37 u9
private def u39 := Term.app u38 u9
private def u40 := Term.app u39 u0
private def u41 := Term.app u40 u30
theorem nege596279823278 : ¬ IsSelfInterpreter e596279823278 := by
  intro he
  have hv : NFt u33 := by decide
  have reach : Betas (Floor40.call e596279823278 u0 u2 u1 []) u33 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left,.left]] (Floor40.call e596279823278 u0 u2 u1 []) = some u31 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u31) (u := u41) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]]) (by decide)) j hj
#print axioms nege596279823278
end Witness596279823278
namespace Witness596279823318
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.app u8 u0
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u11 u1
private def u13 := Term.app u12 u0
private def u14 := Term.lam u13
private def u15 := Term.lam u14
private def u16 := Term.app u11 u15
private def u17 := Term.var 3
private def u18 := Term.app u17 u1
private def u19 := Term.app u18 u0
private def u20 := Term.lam u19
private def u21 := Term.lam u20
private def u22 := Term.app u0 u21
private def u23 := Term.app u22 u1
private def u24 := Term.lam u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u8
private def u28 := Term.app u26 u27
private def u29 := Term.app u28 u0
private def u30 := Term.lam u0
private def u31 := Term.lam u30
private def u32 := Term.app u1 u31
private def u33 := Term.lam u2
private def u34 := Term.app u1 u33
private def u35 := Term.var 4
private def u36 := Term.app u32 u35
private def u37 := Term.lam u36
private def u38 := Term.app u34 u37
private def u39 := Term.lam u38
private def u40 := Term.app u32 u39
private def u41 := Term.lam u40
private def u42 := Term.app u32 u41
private def u43 := Term.lam u42
private def u44 := Term.app u29 u43
private def u45 := Term.app u0 u33
private def u46 := Term.app u45 u1
private def u47 := Term.app u8 u15
private def u48 := Term.lam u47
private def u49 := Term.app u48 u25
private def u50 := Term.app u49 u27
private def u51 := Term.app u50 u0
private def u52 := Term.app u51 u43
theorem nege596279823318 : ¬ IsSelfInterpreter e596279823318 := by
  intro he
  have hv : NFt u46 := by decide
  have reach : Betas (Floor40.call e596279823318 u0 u2 u1 []) u46 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.under,.right,.under,.under,.left],[.left,.left,.left,.left,.under,.right,.under,.under],[.left,.left,.left],[.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left]] (Floor40.call e596279823318 u0 u2 u1 []) = some u44 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u44) (u := u52) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left,.under,.right,.under,.under,.left],[.left,.left,.left,.left,.under,.right,.under,.under],[.left,.left,.left],[.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left,.right,.under,.under],[.left,.left,.left,.left],[.left,.left,.left]]) (by decide)) j hj
#print axioms nege596279823318
end Witness596279823318
namespace Witness597436751214
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u0 u1
private def u4 := Term.app u3 u0
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u9 u10
private def u12 := Term.app u11 u9
private def u13 := Term.app u12 u0
private def u14 := Term.lam u0
private def u15 := Term.lam u14
private def u16 := Term.app u1 u15
private def u17 := Term.lam u2
private def u18 := Term.app u1 u17
private def u19 := Term.var 4
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u16 u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u26
private def u28 := Term.app u13 u27
private def u29 := Term.app u0 u17
private def u30 := Term.app u29 u1
private def u31 := Term.app u4 u10
private def u32 := Term.lam u31
private def u33 := Term.lam u32
private def u34 := Term.app u33 u9
private def u35 := Term.app u34 u0
private def u36 := Term.app u35 u27
theorem nege597436751214 : ¬ IsSelfInterpreter e597436751214 := by
  intro he
  have hv : NFt u30 := by decide
  have reach : Betas (Floor40.call e597436751214 u0 u2 u1 []) u30 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left]] (Floor40.call e597436751214 u0 u2 u1 []) = some u28 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u28) (u := u36) [] (by decide) (replay_sound (ps := [[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left]]) (by decide)) j hj
#print axioms nege597436751214
end Witness597436751214
namespace Witness597889691482
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u4 u0
private def u6 := Term.app u5 u1
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u10 u0
private def u12 := Term.app u11 u9
private def u13 := Term.app u12 u0
private def u14 := Term.lam u0
private def u15 := Term.lam u14
private def u16 := Term.app u1 u15
private def u17 := Term.lam u2
private def u18 := Term.app u1 u17
private def u19 := Term.var 4
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u16 u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u26
private def u28 := Term.app u13 u27
private def u29 := Term.app u0 u17
private def u30 := Term.app u29 u1
private def u31 := Term.app u9 u1
private def u32 := Term.app u31 u0
private def u33 := Term.app u32 u1
private def u34 := Term.lam u33
private def u35 := Term.lam u34
private def u36 := Term.app u35 u0
private def u37 := Term.app u36 u9
private def u38 := Term.app u37 u0
private def u39 := Term.app u38 u27
theorem nege597889691482 : ¬ IsSelfInterpreter e597889691482 := by
  intro he
  have hv : NFt u30 := by decide
  have reach : Betas (Floor40.call e597889691482 u0 u2 u1 []) u30 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left],[.left,.left],[.left]] (Floor40.call e597889691482 u0 u2 u1 []) = some u28 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u28) (u := u39) [] (by decide) (replay_sound (ps := [[.left,.left,.left],[.left,.left]]) (by decide)) j hj
#print axioms nege597889691482
end Witness597889691482
namespace Witness597890435958
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u1 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.lam u12
private def u14 := Term.app u9 u13
private def u15 := Term.app u14 u9
private def u16 := Term.app u1 u13
private def u17 := Term.app u16 u0
private def u18 := Term.lam u17
private def u19 := Term.lam u18
private def u20 := Term.app u15 u19
private def u21 := Term.app u20 u9
private def u22 := Term.app u21 u0
private def u23 := Term.lam u0
private def u24 := Term.lam u23
private def u25 := Term.app u1 u24
private def u26 := Term.lam u2
private def u27 := Term.app u1 u26
private def u28 := Term.var 4
private def u29 := Term.app u25 u28
private def u30 := Term.lam u29
private def u31 := Term.app u27 u30
private def u32 := Term.lam u31
private def u33 := Term.app u25 u32
private def u34 := Term.lam u33
private def u35 := Term.app u25 u34
private def u36 := Term.lam u35
private def u37 := Term.app u22 u36
private def u38 := Term.app u0 u26
private def u39 := Term.app u38 u1
private def u40 := Term.app u13 u19
private def u41 := Term.app u40 u9
private def u42 := Term.app u41 u19
private def u43 := Term.app u42 u9
private def u44 := Term.app u43 u0
private def u45 := Term.app u44 u36
theorem nege597890435958 : ¬ IsSelfInterpreter e597890435958 := by
  intro he
  have hv : NFt u39 := by decide
  have reach : Betas (Floor40.call e597890435958 u0 u2 u1 []) u39 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left]] (Floor40.call e597890435958 u0 u2 u1 []) = some u37 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u37) (u := u45) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]]) (by decide)) j hj
#print axioms nege597890435958
end Witness597890435958
end Blc.Floor41
