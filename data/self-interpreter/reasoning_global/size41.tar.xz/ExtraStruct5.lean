import Extra41
import Batch042
import Batch043
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness598345526970
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.app u4 u0
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege598345526970 : ¬ IsSelfInterpreter e598345526970 := by
  intro he
  have h : replay [] e598345526970 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 2 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege598345526970
end Witness598345526970
namespace Witness598345527018
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u14 := Term.app u0 u4
private def u15 := Term.app u4 u0
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.var 2
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou6 sou0
private theorem sou14 : SO u14 := SO.app sou0 sou4
private theorem sou8 : SO u8 := SO.lam (r := u14) (g := u15) sou7 sou14 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou10 : SO u10 := SO.app sou9 sou0
private theorem sou11 : SO u11 := SO.lam (r := u0) (g := u10) sou10 sou0 (by decide) (by decide)
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege598345527018 : ¬ IsSelfInterpreter e598345527018 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege598345527018
end Witness598345527018
namespace Witness598345527130
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.app u4 u0
private def u6 := Term.var 1
private def u7 := Term.app u5 u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege598345527130 : ¬ IsSelfInterpreter e598345527130 := by
  intro he
  have h : replay [] e598345527130 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 2 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege598345527130
end Witness598345527130
namespace Witness598345527146
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u14 := Term.app u5 u0
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou6 sou0
private theorem sou14 : SO u14 := SO.app sou5 sou0
private theorem sou8 : SO u8 := SO.lam (r := u14) (g := u14) sou7 sou14 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou10 : SO u10 := SO.app sou9 sou0
private theorem sou11 : SO u11 := SO.lam (r := u0) (g := u10) sou10 sou0 (by decide) (by decide)
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege598345527146 : ¬ IsSelfInterpreter e598345527146 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege598345527146
end Witness598345527146
namespace Witness598345528250
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u14 := Term.app u0 u4
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.var 2
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou0 sou6
private theorem sou14 : SO u14 := SO.app sou0 sou4
private theorem sou8 : SO u8 := SO.lam (r := u14) (g := u14) sou7 sou14 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou10 : SO u10 := SO.app sou9 sou0
private theorem sou11 : SO u11 := SO.lam (r := u0) (g := u10) sou10 sou0 (by decide) (by decide)
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege598345528250 : ¬ IsSelfInterpreter e598345528250 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege598345528250
end Witness598345528250
namespace Witness598345528282
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u14 := Term.app u5 u0
private def u15 := Term.app u0 u5
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou0 sou6
private theorem sou14 : SO u14 := SO.app sou5 sou0
private theorem sou8 : SO u8 := SO.lam (r := u14) (g := u15) sou7 sou14 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou10 : SO u10 := SO.app sou9 sou0
private theorem sou11 : SO u11 := SO.lam (r := u0) (g := u10) sou10 sou0 (by decide) (by decide)
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege598345528282 : ¬ IsSelfInterpreter e598345528282 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege598345528282
end Witness598345528282
namespace Witness598345529786
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.var 2
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege598345529786 : ¬ IsSelfInterpreter e598345529786 := by
  intro he
  have h : replay [] e598345529786 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 2 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege598345529786
end Witness598345529786
namespace Witness598345529834
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.var 2
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege598345529834 : ¬ IsSelfInterpreter e598345529834 := by
  intro he
  have h : replay [] e598345529834 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 2 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege598345529834
end Witness598345529834
end Blc.Floor41
