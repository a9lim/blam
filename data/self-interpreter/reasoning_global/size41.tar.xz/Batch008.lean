import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e189042421274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189042421274 : Closed e189042421274 ∧ code e189042421274 = 2388065676826 := by decide
theorem cert_e189042421274 : check e189042421274 [] .sourceHead = true := by decide
def e189042424346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189042424346 : Closed e189042424346 ∧ code e189042424346 = 2388065679898 := by decide
theorem cert_e189042424346 : check e189042424346 [] .sourceHead = true := by decide
def e189042472474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189042472474 : Closed e189042472474 ∧ code e189042472474 = 2388065728026 := by decide
theorem cert_e189042472474 : check e189042472474 [] .sourceHead = true := by decide
def e189042473498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189042473498 : Closed e189042473498 ∧ code e189042473498 = 2388065729050 := by decide
theorem cert_e189042473498 : check e189042473498 [] .sourceHead = true := by decide
def e189180636698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189180636698 : Closed e189180636698 ∧ code e189180636698 = 2388203892250 := by decide
theorem cert_e189180636698 : check e189180636698 [] .sourceHead = true := by decide
def e189180638746 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189180638746 : Closed e189180638746 ∧ code e189180638746 = 2388203894298 := by decide
theorem cert_e189180638746 : check e189180638746 [] .sourceHead = true := by decide
def e189180653082 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189180653082 : Closed e189180653082 ∧ code e189180653082 = 2388203908634 := by decide
theorem cert_e189180653082 : check e189180653082 [] .sourceHead = true := by decide
def e189180656154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189180656154 : Closed e189180656154 ∧ code e189180656154 = 2388203911706 := by decide
theorem cert_e189180656154 : check e189180656154 [] .sourceHead = true := by decide
def e189180663322 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189180663322 : Closed e189180663322 ∧ code e189180663322 = 2388203918874 := by decide
theorem cert_e189180663322 : check e189180663322 [] .sourceHead = true := by decide
def e189180664346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189180664346 : Closed e189180664346 ∧ code e189180664346 = 2388203919898 := by decide
theorem cert_e189180664346 : check e189180664346 [] .sourceHead = true := by decide
def e189180735002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189180735002 : Closed e189180735002 ∧ code e189180735002 = 2388203990554 := by decide
theorem cert_e189180735002 : check e189180735002 [] .sourceHead = true := by decide
def e189180737050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189180737050 : Closed e189180737050 ∧ code e189180737050 = 2388203992602 := by decide
theorem cert_e189180737050 : check e189180737050 [] .sourceHead = true := by decide
def e189180833306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189180833306 : Closed e189180833306 ∧ code e189180833306 = 2388204088858 := by decide
theorem cert_e189180833306 : check e189180833306 [] .sourceHead = true := by decide
def e189180836378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189180836378 : Closed e189180836378 ∧ code e189180836378 = 2388204091930 := by decide
theorem cert_e189180836378 : check e189180836378 [] .sourceHead = true := by decide
def e189180884506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189180884506 : Closed e189180884506 ∧ code e189180884506 = 2388204140058 := by decide
theorem cert_e189180884506 : check e189180884506 [] .sourceHead = true := by decide
def e189180885530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189180885530 : Closed e189180885530 ∧ code e189180885530 = 2388204141082 := by decide
theorem cert_e189180885530 : check e189180885530 [] .sourceHead = true := by decide
def e189182883866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189182883866 : Closed e189182883866 ∧ code e189182883866 = 2388206139418 := by decide
theorem cert_e189182883866 : check e189182883866 [] .sourceHead = true := by decide
def e189182892058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189182892058 : Closed e189182892058 ∧ code e189182892058 = 2388206147610 := by decide
theorem cert_e189182892058 : check e189182892058 [] .sourceHead = true := by decide
def e189182949402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189182949402 : Closed e189182949402 ∧ code e189182949402 = 2388206204954 := by decide
theorem cert_e189182949402 : check e189182949402 [] .sourceHead = true := by decide
def e189182961690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189182961690 : Closed e189182961690 ∧ code e189182961690 = 2388206217242 := by decide
theorem cert_e189182961690 : check e189182961690 [] .sourceHead = true := by decide
def e189182990362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189182990362 : Closed e189182990362 ∧ code e189182990362 = 2388206245914 := by decide
theorem cert_e189182990362 : check e189182990362 [] .sourceHead = true := by decide
def e189182994458 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189182994458 : Closed e189182994458 ∧ code e189182994458 = 2388206250010 := by decide
theorem cert_e189182994458 : check e189182994458 [] .sourceHead = true := by decide
def e189183277082 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189183277082 : Closed e189183277082 ∧ code e189183277082 = 2388206532634 := by decide
theorem cert_e189183277082 : check e189183277082 [] .sourceHead = true := by decide
def e189183285274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189183285274 : Closed e189183285274 ∧ code e189183285274 = 2388206540826 := by decide
theorem cert_e189183285274 : check e189183285274 [] .sourceHead = true := by decide
def e189183670298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189183670298 : Closed e189183670298 ∧ code e189183670298 = 2388206925850 := by decide
theorem cert_e189183670298 : check e189183670298 [] .sourceHead = true := by decide
def e189183682586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189183682586 : Closed e189183682586 ∧ code e189183682586 = 2388206938138 := by decide
theorem cert_e189183682586 : check e189183682586 [] .sourceHead = true := by decide
def e189183875098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189183875098 : Closed e189183875098 ∧ code e189183875098 = 2388207130650 := by decide
theorem cert_e189183875098 : check e189183875098 [] .sourceHead = true := by decide
def e189183879194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189183879194 : Closed e189183879194 ∧ code e189183879194 = 2388207134746 := by decide
theorem cert_e189183879194 : check e189183879194 [] .sourceHead = true := by decide
def e189196709230 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e189196709230 : Closed e189196709230 ∧ code e189196709230 = 2388219964782 := by decide
theorem cert_e189196709230 : check e189196709230 [] .sourceHead = true := by decide
def e189196709238 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e189196709238 : Closed e189196709238 ∧ code e189196709238 = 2388219964790 := by decide
theorem cert_e189196709238 : check e189196709238 [] .sourceHead = true := by decide
def e189196709294 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e189196709294 : Closed e189196709294 ∧ code e189196709294 = 2388219964846 := by decide
theorem cert_e189196709294 : check e189196709294 [] .sourceHead = true := by decide
def e189196709306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e189196709306 : Closed e189196709306 ∧ code e189196709306 = 2388219964858 := by decide
theorem cert_e189196709306 : check e189196709306 [] .sourceHead = true := by decide
def e189196709334 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e189196709334 : Closed e189196709334 ∧ code e189196709334 = 2388219964886 := by decide
theorem cert_e189196709334 : check e189196709334 [] .sourceHead = true := by decide
def e189196709338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e189196709338 : Closed e189196709338 ∧ code e189196709338 = 2388219964890 := by decide
theorem cert_e189196709338 : check e189196709338 [] .sourceHead = true := by decide
def e189196709550 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e189196709550 : Closed e189196709550 ∧ code e189196709550 = 2388219965102 := by decide
theorem cert_e189196709550 : check e189196709550 [] .sourceHead = true := by decide
def e189196709562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e189196709562 : Closed e189196709562 ∧ code e189196709562 = 2388219965114 := by decide
theorem cert_e189196709562 : check e189196709562 [] .sourceHead = true := by decide
def e189196709610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e189196709610 : Closed e189196709610 ∧ code e189196709610 = 2388219965162 := by decide
theorem cert_e189196709610 : check e189196709610 [] .sourceHead = true := by decide
def e189196709718 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e189196709718 : Closed e189196709718 ∧ code e189196709718 = 2388219965270 := by decide
theorem cert_e189196709718 : check e189196709718 [] .sourceHead = true := by decide
def e189196709722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e189196709722 : Closed e189196709722 ∧ code e189196709722 = 2388219965274 := by decide
theorem cert_e189196709722 : check e189196709722 [] .sourceHead = true := by decide
def e189196709738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e189196709738 : Closed e189196709738 ∧ code e189196709738 = 2388219965290 := by decide
theorem cert_e189196709738 : check e189196709738 [] .sourceHead = true := by decide
def e189196710766 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e189196710766 : Closed e189196710766 ∧ code e189196710766 = 2388219966318 := by decide
theorem cert_e189196710766 : check e189196710766 [] .sourceHead = true := by decide
def e189196710774 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e189196710774 : Closed e189196710774 ∧ code e189196710774 = 2388219966326 := by decide
theorem cert_e189196710774 : check e189196710774 [] .sourceHead = true := by decide
def e189196710830 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e189196710830 : Closed e189196710830 ∧ code e189196710830 = 2388219966382 := by decide
theorem cert_e189196710830 : check e189196710830 [] .sourceHead = true := by decide
def e189196710842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e189196710842 : Closed e189196710842 ∧ code e189196710842 = 2388219966394 := by decide
theorem cert_e189196710842 : check e189196710842 [] .sourceHead = true := by decide
def e189196710870 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e189196710870 : Closed e189196710870 ∧ code e189196710870 = 2388219966422 := by decide
theorem cert_e189196710870 : check e189196710870 [] .sourceHead = true := by decide
def e189196710874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e189196710874 : Closed e189196710874 ∧ code e189196710874 = 2388219966426 := by decide
theorem cert_e189196710874 : check e189196710874 [] .sourceHead = true := by decide
def e189196711150 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e189196711150 : Closed e189196711150 ∧ code e189196711150 = 2388219966702 := by decide
theorem cert_e189196711150 : check e189196711150 [] .sourceHead = true := by decide
def e189196711158 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e189196711158 : Closed e189196711158 ∧ code e189196711158 = 2388219966710 := by decide
theorem cert_e189196711158 : check e189196711158 [] .sourceHead = true := by decide
def e189196711534 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e189196711534 : Closed e189196711534 ∧ code e189196711534 = 2388219967086 := by decide
theorem cert_e189196711534 : check e189196711534 [] .sourceHead = true := by decide
def e189196711546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e189196711546 : Closed e189196711546 ∧ code e189196711546 = 2388219967098 := by decide
theorem cert_e189196711546 : check e189196711546 [] .sourceHead = true := by decide
def e189196711734 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e189196711734 : Closed e189196711734 ∧ code e189196711734 = 2388219967286 := by decide
theorem cert_e189196711734 : check e189196711734 [] .sourceHead = true := by decide
def e189196711738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e189196711738 : Closed e189196711738 ∧ code e189196711738 = 2388219967290 := by decide
theorem cert_e189196711738 : check e189196711738 [] .sourceHead = true := by decide
def e189196712366 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e189196712366 : Closed e189196712366 ∧ code e189196712366 = 2388219967918 := by decide
theorem cert_e189196712366 : check e189196712366 [] .sourceHead = true := by decide
def e189196712378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e189196712378 : Closed e189196712378 ∧ code e189196712378 = 2388219967930 := by decide
theorem cert_e189196712378 : check e189196712378 [] .sourceHead = true := by decide
def e189196712426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e189196712426 : Closed e189196712426 ∧ code e189196712426 = 2388219967978 := by decide
theorem cert_e189196712426 : check e189196712426 [] .sourceHead = true := by decide
def e189196712558 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e189196712558 : Closed e189196712558 ∧ code e189196712558 = 2388219968110 := by decide
theorem cert_e189196712558 : check e189196712558 [] .sourceHead = true := by decide
def e189196712570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e189196712570 : Closed e189196712570 ∧ code e189196712570 = 2388219968122 := by decide
theorem cert_e189196712570 : check e189196712570 [] .sourceHead = true := by decide
def e189196712858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e189196712858 : Closed e189196712858 ∧ code e189196712858 = 2388219968410 := by decide
theorem cert_e189196712858 : check e189196712858 [] .sourceHead = true := by decide
def e189196713174 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e189196713174 : Closed e189196713174 ∧ code e189196713174 = 2388219968726 := by decide
theorem cert_e189196713174 : check e189196713174 [] .sourceHead = true := by decide
def e189196713178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e189196713178 : Closed e189196713178 ∧ code e189196713178 = 2388219968730 := by decide
theorem cert_e189196713178 : check e189196713178 [] .sourceHead = true := by decide
def e189196713194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e189196713194 : Closed e189196713194 ∧ code e189196713194 = 2388219968746 := by decide
theorem cert_e189196713194 : check e189196713194 [] .sourceHead = true := by decide
def e189196713270 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e189196713270 : Closed e189196713270 ∧ code e189196713270 = 2388219968822 := by decide
theorem cert_e189196713270 : check e189196713270 [] .sourceHead = true := by decide
def e189196713274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e189196713274 : Closed e189196713274 ∧ code e189196713274 = 2388219968826 := by decide
theorem cert_e189196713274 : check e189196713274 [] .sourceHead = true := by decide
def e189196713370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e189196713370 : Closed e189196713370 ∧ code e189196713370 = 2388219968922 := by decide
theorem cert_e189196713370 : check e189196713370 [] .sourceHead = true := by decide
def e189196716910 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e189196716910 : Closed e189196716910 ∧ code e189196716910 = 2388219972462 := by decide
theorem cert_e189196716910 : check e189196716910 [] .sourceHead = true := by decide
def e189196716918 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e189196716918 : Closed e189196716918 ∧ code e189196716918 = 2388219972470 := by decide
theorem cert_e189196716918 : check e189196716918 [] .sourceHead = true := by decide
def e189196716974 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e189196716974 : Closed e189196716974 ∧ code e189196716974 = 2388219972526 := by decide
theorem cert_e189196716974 : check e189196716974 [] .sourceHead = true := by decide
def e189196716986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e189196716986 : Closed e189196716986 ∧ code e189196716986 = 2388219972538 := by decide
theorem cert_e189196716986 : check e189196716986 [] .sourceHead = true := by decide
def e189196717014 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e189196717014 : Closed e189196717014 ∧ code e189196717014 = 2388219972566 := by decide
theorem cert_e189196717014 : check e189196717014 [] .sourceHead = true := by decide
def e189196717018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e189196717018 : Closed e189196717018 ∧ code e189196717018 = 2388219972570 := by decide
theorem cert_e189196717018 : check e189196717018 [] .sourceHead = true := by decide
def e189196717294 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e189196717294 : Closed e189196717294 ∧ code e189196717294 = 2388219972846 := by decide
theorem cert_e189196717294 : check e189196717294 [] .sourceHead = true := by decide
def e189196717302 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e189196717302 : Closed e189196717302 ∧ code e189196717302 = 2388219972854 := by decide
theorem cert_e189196717302 : check e189196717302 [] .sourceHead = true := by decide
def e189196717678 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e189196717678 : Closed e189196717678 ∧ code e189196717678 = 2388219973230 := by decide
theorem cert_e189196717678 : check e189196717678 [] .sourceHead = true := by decide
def e189196717690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e189196717690 : Closed e189196717690 ∧ code e189196717690 = 2388219973242 := by decide
theorem cert_e189196717690 : check e189196717690 [] .sourceHead = true := by decide
def e189196717878 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e189196717878 : Closed e189196717878 ∧ code e189196717878 = 2388219973430 := by decide
theorem cert_e189196717878 : check e189196717878 [] .sourceHead = true := by decide
def e189196717882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e189196717882 : Closed e189196717882 ∧ code e189196717882 = 2388219973434 := by decide
theorem cert_e189196717882 : check e189196717882 [] .sourceHead = true := by decide
def e189196723630 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e189196723630 : Closed e189196723630 ∧ code e189196723630 = 2388219979182 := by decide
theorem cert_e189196723630 : check e189196723630 [] .sourceHead = true := by decide
def e189196723642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e189196723642 : Closed e189196723642 ∧ code e189196723642 = 2388219979194 := by decide
theorem cert_e189196723642 : check e189196723642 [] .sourceHead = true := by decide
def e189196723690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e189196723690 : Closed e189196723690 ∧ code e189196723690 = 2388219979242 := by decide
theorem cert_e189196723690 : check e189196723690 [] .sourceHead = true := by decide
def e189196723822 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e189196723822 : Closed e189196723822 ∧ code e189196723822 = 2388219979374 := by decide
theorem cert_e189196723822 : check e189196723822 [] .sourceHead = true := by decide
def e189196723834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e189196723834 : Closed e189196723834 ∧ code e189196723834 = 2388219979386 := by decide
theorem cert_e189196723834 : check e189196723834 [] .sourceHead = true := by decide
def e189196724122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e189196724122 : Closed e189196724122 ∧ code e189196724122 = 2388219979674 := by decide
theorem cert_e189196724122 : check e189196724122 [] .sourceHead = true := by decide
def e189196726998 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e189196726998 : Closed e189196726998 ∧ code e189196726998 = 2388219982550 := by decide
theorem cert_e189196726998 : check e189196726998 [] .sourceHead = true := by decide
def e189196727002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e189196727002 : Closed e189196727002 ∧ code e189196727002 = 2388219982554 := by decide
theorem cert_e189196727002 : check e189196727002 [] .sourceHead = true := by decide
def e189196727018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e189196727018 : Closed e189196727018 ∧ code e189196727018 = 2388219982570 := by decide
theorem cert_e189196727018 : check e189196727018 [] .sourceHead = true := by decide
def e189196727094 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e189196727094 : Closed e189196727094 ∧ code e189196727094 = 2388219982646 := by decide
theorem cert_e189196727094 : check e189196727094 [] .sourceHead = true := by decide
def e189196727098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e189196727098 : Closed e189196727098 ∧ code e189196727098 = 2388219982650 := by decide
theorem cert_e189196727098 : check e189196727098 [] .sourceHead = true := by decide
def e189196727194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e189196727194 : Closed e189196727194 ∧ code e189196727194 = 2388219982746 := by decide
theorem cert_e189196727194 : check e189196727194 [] .sourceHead = true := by decide
def e189196864366 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e189196864366 : Closed e189196864366 ∧ code e189196864366 = 2388220119918 := by decide
theorem cert_e189196864366 : check e189196864366 [] .sourceHead = true := by decide
def e189196864374 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e189196864374 : Closed e189196864374 ∧ code e189196864374 = 2388220119926 := by decide
theorem cert_e189196864374 : check e189196864374 [] .sourceHead = true := by decide
def e189196864430 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e189196864430 : Closed e189196864430 ∧ code e189196864430 = 2388220119982 := by decide
theorem cert_e189196864430 : check e189196864430 [] .sourceHead = true := by decide
def e189196864442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e189196864442 : Closed e189196864442 ∧ code e189196864442 = 2388220119994 := by decide
theorem cert_e189196864442 : check e189196864442 [] .sourceHead = true := by decide
def e189196864470 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e189196864470 : Closed e189196864470 ∧ code e189196864470 = 2388220120022 := by decide
theorem cert_e189196864470 : check e189196864470 [] .sourceHead = true := by decide
def e189196864474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e189196864474 : Closed e189196864474 ∧ code e189196864474 = 2388220120026 := by decide
theorem cert_e189196864474 : check e189196864474 [] .sourceHead = true := by decide
def e189196864750 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e189196864750 : Closed e189196864750 ∧ code e189196864750 = 2388220120302 := by decide
theorem cert_e189196864750 : check e189196864750 [] .sourceHead = true := by decide
def e189196864758 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e189196864758 : Closed e189196864758 ∧ code e189196864758 = 2388220120310 := by decide
theorem cert_e189196864758 : check e189196864758 [] .sourceHead = true := by decide
def e189196865134 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e189196865134 : Closed e189196865134 ∧ code e189196865134 = 2388220120686 := by decide
theorem cert_e189196865134 : check e189196865134 [] .sourceHead = true := by decide
def e189196865146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e189196865146 : Closed e189196865146 ∧ code e189196865146 = 2388220120698 := by decide
theorem cert_e189196865146 : check e189196865146 [] .sourceHead = true := by decide
def e189196865334 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e189196865334 : Closed e189196865334 ∧ code e189196865334 = 2388220120886 := by decide
theorem cert_e189196865334 : check e189196865334 [] .sourceHead = true := by decide
def e189196865338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e189196865338 : Closed e189196865338 ∧ code e189196865338 = 2388220120890 := by decide
theorem cert_e189196865338 : check e189196865338 [] .sourceHead = true := by decide
def e189197454190 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e189197454190 : Closed e189197454190 ∧ code e189197454190 = 2388220709742 := by decide
theorem cert_e189197454190 : check e189197454190 [] .sourceHead = true := by decide
def e189197454198 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e189197454198 : Closed e189197454198 ∧ code e189197454198 = 2388220709750 := by decide
theorem cert_e189197454198 : check e189197454198 [] .sourceHead = true := by decide
def e189197454254 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e189197454254 : Closed e189197454254 ∧ code e189197454254 = 2388220709806 := by decide
theorem cert_e189197454254 : check e189197454254 [] .sourceHead = true := by decide
def e189197454266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e189197454266 : Closed e189197454266 ∧ code e189197454266 = 2388220709818 := by decide
theorem cert_e189197454266 : check e189197454266 [] .sourceHead = true := by decide
def e189197454294 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e189197454294 : Closed e189197454294 ∧ code e189197454294 = 2388220709846 := by decide
theorem cert_e189197454294 : check e189197454294 [] .sourceHead = true := by decide
def e189197454298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e189197454298 : Closed e189197454298 ∧ code e189197454298 = 2388220709850 := by decide
theorem cert_e189197454298 : check e189197454298 [] .sourceHead = true := by decide
def e189197454574 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e189197454574 : Closed e189197454574 ∧ code e189197454574 = 2388220710126 := by decide
theorem cert_e189197454574 : check e189197454574 [] .sourceHead = true := by decide
def e189197454582 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e189197454582 : Closed e189197454582 ∧ code e189197454582 = 2388220710134 := by decide
theorem cert_e189197454582 : check e189197454582 [] .sourceHead = true := by decide
def e189197454958 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e189197454958 : Closed e189197454958 ∧ code e189197454958 = 2388220710510 := by decide
theorem cert_e189197454958 : check e189197454958 [] .sourceHead = true := by decide
def e189197454970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e189197454970 : Closed e189197454970 ∧ code e189197454970 = 2388220710522 := by decide
theorem cert_e189197454970 : check e189197454970 [] .sourceHead = true := by decide
def e189197455158 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e189197455158 : Closed e189197455158 ∧ code e189197455158 = 2388220710710 := by decide
theorem cert_e189197455158 : check e189197455158 [] .sourceHead = true := by decide
def e189197455162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e189197455162 : Closed e189197455162 ∧ code e189197455162 = 2388220710714 := by decide
theorem cert_e189197455162 : check e189197455162 [] .sourceHead = true := by decide
def e189786863642 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189786863642 : Closed e189786863642 ∧ code e189786863642 = 2388810119194 := by decide
theorem cert_e189786863642 : check e189786863642 [] .sourceHead = true := by decide
def e189786871834 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189786871834 : Closed e189786871834 ∧ code e189786871834 = 2388810127386 := by decide
theorem cert_e189786871834 : check e189786871834 [] .sourceHead = true := by decide
def e189786929178 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189786929178 : Closed e189786929178 ∧ code e189786929178 = 2388810184730 := by decide
theorem cert_e189786929178 : check e189786929178 [] .sourceHead = true := by decide
def e189786941466 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189786941466 : Closed e189786941466 ∧ code e189786941466 = 2388810197018 := by decide
theorem cert_e189786941466 : check e189786941466 [] .sourceHead = true := by decide
def e189786970138 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189786970138 : Closed e189786970138 ∧ code e189786970138 = 2388810225690 := by decide
theorem cert_e189786970138 : check e189786970138 [] .sourceHead = true := by decide
def e189786974234 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189786974234 : Closed e189786974234 ∧ code e189786974234 = 2388810229786 := by decide
theorem cert_e189786974234 : check e189786974234 [] .sourceHead = true := by decide
def e189787256858 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189787256858 : Closed e189787256858 ∧ code e189787256858 = 2388810512410 := by decide
theorem cert_e189787256858 : check e189787256858 [] .sourceHead = true := by decide
def e189787265050 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189787265050 : Closed e189787265050 ∧ code e189787265050 = 2388810520602 := by decide
theorem cert_e189787265050 : check e189787265050 [] .sourceHead = true := by decide
def e189787650074 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189787650074 : Closed e189787650074 ∧ code e189787650074 = 2388810905626 := by decide
theorem cert_e189787650074 : check e189787650074 [] .sourceHead = true := by decide
def e189787662362 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189787662362 : Closed e189787662362 ∧ code e189787662362 = 2388810917914 := by decide
theorem cert_e189787662362 : check e189787662362 [] .sourceHead = true := by decide
def e189787854874 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189787854874 : Closed e189787854874 ∧ code e189787854874 = 2388811110426 := by decide
theorem cert_e189787854874 : check e189787854874 [] .sourceHead = true := by decide
def e189787858970 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189787858970 : Closed e189787858970 ∧ code e189787858970 = 2388811114522 := by decide
theorem cert_e189787858970 : check e189787858970 [] .sourceHead = true := by decide
def e189851020654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e189851020654 : Closed e189851020654 ∧ code e189851020654 = 2388874276206 := by decide
theorem cert_e189851020654 : check e189851020654 [] .sourceHead = true := by decide
def e189851020662 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e189851020662 : Closed e189851020662 ∧ code e189851020662 = 2388874276214 := by decide
theorem cert_e189851020662 : check e189851020662 [] .sourceHead = true := by decide
def e189851020718 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e189851020718 : Closed e189851020718 ∧ code e189851020718 = 2388874276270 := by decide
theorem cert_e189851020718 : check e189851020718 [] .sourceHead = true := by decide
def e189851020730 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e189851020730 : Closed e189851020730 ∧ code e189851020730 = 2388874276282 := by decide
theorem cert_e189851020730 : check e189851020730 [] .sourceHead = true := by decide
def e189851020758 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e189851020758 : Closed e189851020758 ∧ code e189851020758 = 2388874276310 := by decide
theorem cert_e189851020758 : check e189851020758 [] .sourceHead = true := by decide
def e189851020762 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e189851020762 : Closed e189851020762 ∧ code e189851020762 = 2388874276314 := by decide
theorem cert_e189851020762 : check e189851020762 [] .sourceHead = true := by decide
def e189851020974 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e189851020974 : Closed e189851020974 ∧ code e189851020974 = 2388874276526 := by decide
theorem cert_e189851020974 : check e189851020974 [] .sourceHead = true := by decide
def e189851020986 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e189851020986 : Closed e189851020986 ∧ code e189851020986 = 2388874276538 := by decide
theorem cert_e189851020986 : check e189851020986 [] .sourceHead = true := by decide
def e189851021034 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e189851021034 : Closed e189851021034 ∧ code e189851021034 = 2388874276586 := by decide
theorem cert_e189851021034 : check e189851021034 [] .sourceHead = true := by decide
def e189851021142 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e189851021142 : Closed e189851021142 ∧ code e189851021142 = 2388874276694 := by decide
theorem cert_e189851021142 : check e189851021142 [] .sourceHead = true := by decide
def e189851021146 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e189851021146 : Closed e189851021146 ∧ code e189851021146 = 2388874276698 := by decide
theorem cert_e189851021146 : check e189851021146 [] .sourceHead = true := by decide
def e189851021162 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e189851021162 : Closed e189851021162 ∧ code e189851021162 = 2388874276714 := by decide
theorem cert_e189851021162 : check e189851021162 [] .sourceHead = true := by decide
def e189851022190 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e189851022190 : Closed e189851022190 ∧ code e189851022190 = 2388874277742 := by decide
theorem cert_e189851022190 : check e189851022190 [] .sourceHead = true := by decide
def e189851022198 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e189851022198 : Closed e189851022198 ∧ code e189851022198 = 2388874277750 := by decide
theorem cert_e189851022198 : check e189851022198 [] .sourceHead = true := by decide
def e189851022254 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e189851022254 : Closed e189851022254 ∧ code e189851022254 = 2388874277806 := by decide
theorem cert_e189851022254 : check e189851022254 [] .sourceHead = true := by decide
def e189851022266 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e189851022266 : Closed e189851022266 ∧ code e189851022266 = 2388874277818 := by decide
theorem cert_e189851022266 : check e189851022266 [] .sourceHead = true := by decide
def e189851022294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e189851022294 : Closed e189851022294 ∧ code e189851022294 = 2388874277846 := by decide
theorem cert_e189851022294 : check e189851022294 [] .sourceHead = true := by decide
def e189851022298 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e189851022298 : Closed e189851022298 ∧ code e189851022298 = 2388874277850 := by decide
theorem cert_e189851022298 : check e189851022298 [] .sourceHead = true := by decide
def e189851022574 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e189851022574 : Closed e189851022574 ∧ code e189851022574 = 2388874278126 := by decide
theorem cert_e189851022574 : check e189851022574 [] .sourceHead = true := by decide
def e189851022582 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e189851022582 : Closed e189851022582 ∧ code e189851022582 = 2388874278134 := by decide
theorem cert_e189851022582 : check e189851022582 [] .sourceHead = true := by decide
def e189851022958 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e189851022958 : Closed e189851022958 ∧ code e189851022958 = 2388874278510 := by decide
theorem cert_e189851022958 : check e189851022958 [] .sourceHead = true := by decide
def e189851022970 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e189851022970 : Closed e189851022970 ∧ code e189851022970 = 2388874278522 := by decide
theorem cert_e189851022970 : check e189851022970 [] .sourceHead = true := by decide
def e189851023158 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e189851023158 : Closed e189851023158 ∧ code e189851023158 = 2388874278710 := by decide
theorem cert_e189851023158 : check e189851023158 [] .sourceHead = true := by decide
def e189851023162 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e189851023162 : Closed e189851023162 ∧ code e189851023162 = 2388874278714 := by decide
theorem cert_e189851023162 : check e189851023162 [] .sourceHead = true := by decide
def e189851023790 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e189851023790 : Closed e189851023790 ∧ code e189851023790 = 2388874279342 := by decide
theorem cert_e189851023790 : check e189851023790 [] .sourceHead = true := by decide
def e189851023802 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e189851023802 : Closed e189851023802 ∧ code e189851023802 = 2388874279354 := by decide
theorem cert_e189851023802 : check e189851023802 [] .sourceHead = true := by decide
def e189851023850 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e189851023850 : Closed e189851023850 ∧ code e189851023850 = 2388874279402 := by decide
theorem cert_e189851023850 : check e189851023850 [] .sourceHead = true := by decide
def e189851023982 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e189851023982 : Closed e189851023982 ∧ code e189851023982 = 2388874279534 := by decide
theorem cert_e189851023982 : check e189851023982 [] .sourceHead = true := by decide
def e189851023994 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e189851023994 : Closed e189851023994 ∧ code e189851023994 = 2388874279546 := by decide
theorem cert_e189851023994 : check e189851023994 [] .sourceHead = true := by decide
def e189851024282 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e189851024282 : Closed e189851024282 ∧ code e189851024282 = 2388874279834 := by decide
theorem cert_e189851024282 : check e189851024282 [] .sourceHead = true := by decide
def e189851024598 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e189851024598 : Closed e189851024598 ∧ code e189851024598 = 2388874280150 := by decide
theorem cert_e189851024598 : check e189851024598 [] .sourceHead = true := by decide
def e189851024602 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e189851024602 : Closed e189851024602 ∧ code e189851024602 = 2388874280154 := by decide
theorem cert_e189851024602 : check e189851024602 [] .sourceHead = true := by decide
def e189851024618 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e189851024618 : Closed e189851024618 ∧ code e189851024618 = 2388874280170 := by decide
theorem cert_e189851024618 : check e189851024618 [] .sourceHead = true := by decide
def e189851024694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e189851024694 : Closed e189851024694 ∧ code e189851024694 = 2388874280246 := by decide
theorem cert_e189851024694 : check e189851024694 [] .sourceHead = true := by decide
def e189851024698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e189851024698 : Closed e189851024698 ∧ code e189851024698 = 2388874280250 := by decide
theorem cert_e189851024698 : check e189851024698 [] .sourceHead = true := by decide
def e189851024794 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e189851024794 : Closed e189851024794 ∧ code e189851024794 = 2388874280346 := by decide
theorem cert_e189851024794 : check e189851024794 [] .sourceHead = true := by decide
end Blc.Floor41
