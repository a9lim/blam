import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e602113024362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e602113024362 : Closed e602113024362 ∧ code e602113024362 = 2801136279914 := by decide
private def t_e602113024362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e602113024362 : ¬ IsSelfInterpreter e602113024362 :=
  wSource (t := t_e602113024362) (replay_sound (ps := []) (t := e602113024362) (by decide)) (by decide)
def e602113024410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e602113024410 : Closed e602113024410 ∧ code e602113024410 = 2801136279962 := by decide
private def t_e602113024410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e602113024410 : ¬ IsSelfInterpreter e602113024410 :=
  wSource (t := t_e602113024410) (replay_sound (ps := []) (t := e602113024410) (by decide)) (by decide)
def e602113138714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602113138714 : Closed e602113138714 ∧ code e602113138714 = 2801136394266 := by decide
theorem cert_e602113138714 : check e602113138714 [[]] .width = true := by decide
def e602113138806 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e602113138806 : Closed e602113138806 ∧ code e602113138806 = 2801136394358 := by decide
private def t_e602113138806 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e602113138806 : ¬ IsSelfInterpreter e602113138806 :=
  wSource (t := t_e602113138806) (replay_sound (ps := []) (t := e602113138806) (by decide)) (by decide)
def e602113139050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e602113139050 : Closed e602113139050 ∧ code e602113139050 = 2801136394602 := by decide
private def t_e602113139050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e602113139050 : ¬ IsSelfInterpreter e602113139050 :=
  wSource (t := t_e602113139050) (replay_sound (ps := []) (t := e602113139050) (by decide)) (by decide)
def e602113139098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e602113139098 : Closed e602113139098 ∧ code e602113139098 = 2801136394650 := by decide
private def t_e602113139098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e602113139098 : ¬ IsSelfInterpreter e602113139098 :=
  wSource (t := t_e602113139098) (replay_sound (ps := []) (t := e602113139098) (by decide)) (by decide)
def e602113155098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602113155098 : Closed e602113155098 ∧ code e602113155098 = 2801136410650 := by decide
theorem cert_e602113155098 : check e602113155098 [[]] .width = true := by decide
def e602113155190 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e602113155190 : Closed e602113155190 ∧ code e602113155190 = 2801136410742 := by decide
private def t_e602113155190 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e602113155190 : ¬ IsSelfInterpreter e602113155190 :=
  wSource (t := t_e602113155190) (replay_sound (ps := []) (t := e602113155190) (by decide)) (by decide)
def e602113155434 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e602113155434 : Closed e602113155434 ∧ code e602113155434 = 2801136410986 := by decide
private def t_e602113155434 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e602113155434 : ¬ IsSelfInterpreter e602113155434 :=
  wSource (t := t_e602113155434) (replay_sound (ps := []) (t := e602113155434) (by decide)) (by decide)
def e602113155482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e602113155482 : Closed e602113155482 ∧ code e602113155482 = 2801136411034 := by decide
private def t_e602113155482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e602113155482 : ¬ IsSelfInterpreter e602113155482 :=
  wSource (t := t_e602113155482) (replay_sound (ps := []) (t := e602113155482) (by decide)) (by decide)
def e602114285594 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602114285594 : Closed e602114285594 ∧ code e602114285594 = 2801137541146 := by decide
theorem cert_e602114285594 : check e602114285594 [[]] .width = true := by decide
def e602114285686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e602114285686 : Closed e602114285686 ∧ code e602114285686 = 2801137541238 := by decide
private def t_e602114285686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e602114285686 : ¬ IsSelfInterpreter e602114285686 :=
  wSource (t := t_e602114285686) (replay_sound (ps := []) (t := e602114285686) (by decide)) (by decide)
def e602114285930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e602114285930 : Closed e602114285930 ∧ code e602114285930 = 2801137541482 := by decide
private def t_e602114285930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e602114285930 : ¬ IsSelfInterpreter e602114285930 :=
  wSource (t := t_e602114285930) (replay_sound (ps := []) (t := e602114285930) (by decide)) (by decide)
def e602114285978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e602114285978 : Closed e602114285978 ∧ code e602114285978 = 2801137541530 := by decide
private def t_e602114285978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e602114285978 : ¬ IsSelfInterpreter e602114285978 :=
  wSource (t := t_e602114285978) (replay_sound (ps := []) (t := e602114285978) (by decide)) (by decide)
def e602114318362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602114318362 : Closed e602114318362 ∧ code e602114318362 = 2801137573914 := by decide
theorem cert_e602114318362 : check e602114318362 [[]] .width = true := by decide
def e602114318454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e602114318454 : Closed e602114318454 ∧ code e602114318454 = 2801137574006 := by decide
private def t_e602114318454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e602114318454 : ¬ IsSelfInterpreter e602114318454 :=
  wSource (t := t_e602114318454) (replay_sound (ps := []) (t := e602114318454) (by decide)) (by decide)
def e602114318698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e602114318698 : Closed e602114318698 ∧ code e602114318698 = 2801137574250 := by decide
private def t_e602114318698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e602114318698 : ¬ IsSelfInterpreter e602114318698 :=
  wSource (t := t_e602114318698) (replay_sound (ps := []) (t := e602114318698) (by decide)) (by decide)
def e602114318746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e602114318746 : Closed e602114318746 ∧ code e602114318746 = 2801137574298 := by decide
private def t_e602114318746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e602114318746 : ¬ IsSelfInterpreter e602114318746 :=
  wSource (t := t_e602114318746) (replay_sound (ps := []) (t := e602114318746) (by decide)) (by decide)
def e602115858458 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602115858458 : Closed e602115858458 ∧ code e602115858458 = 2801139114010 := by decide
theorem cert_e602115858458 : check e602115858458 [[]] .width = true := by decide
def e602115858550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e602115858550 : Closed e602115858550 ∧ code e602115858550 = 2801139114102 := by decide
private def t_e602115858550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e602115858550 : ¬ IsSelfInterpreter e602115858550 :=
  wSource (t := t_e602115858550) (replay_sound (ps := []) (t := e602115858550) (by decide)) (by decide)
def e602115858794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e602115858794 : Closed e602115858794 ∧ code e602115858794 = 2801139114346 := by decide
private def t_e602115858794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e602115858794 : ¬ IsSelfInterpreter e602115858794 :=
  wSource (t := t_e602115858794) (replay_sound (ps := []) (t := e602115858794) (by decide)) (by decide)
def e602115858842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e602115858842 : Closed e602115858842 ∧ code e602115858842 = 2801139114394 := by decide
private def t_e602115858842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e602115858842 : ¬ IsSelfInterpreter e602115858842 :=
  wSource (t := t_e602115858842) (replay_sound (ps := []) (t := e602115858842) (by decide)) (by decide)
def e602115907610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602115907610 : Closed e602115907610 ∧ code e602115907610 = 2801139163162 := by decide
theorem cert_e602115907610 : check e602115907610 [[]] .width = true := by decide
def e602115907702 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e602115907702 : Closed e602115907702 ∧ code e602115907702 = 2801139163254 := by decide
private def t_e602115907702 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e602115907702 : ¬ IsSelfInterpreter e602115907702 :=
  wSource (t := t_e602115907702) (replay_sound (ps := []) (t := e602115907702) (by decide)) (by decide)
def e602115907946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e602115907946 : Closed e602115907946 ∧ code e602115907946 = 2801139163498 := by decide
private def t_e602115907946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e602115907946 : ¬ IsSelfInterpreter e602115907946 :=
  wSource (t := t_e602115907946) (replay_sound (ps := []) (t := e602115907946) (by decide)) (by decide)
def e602115907994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e602115907994 : Closed e602115907994 ∧ code e602115907994 = 2801139163546 := by decide
private def t_e602115907994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e602115907994 : ¬ IsSelfInterpreter e602115907994 :=
  wSource (t := t_e602115907994) (replay_sound (ps := []) (t := e602115907994) (by decide)) (by decide)
def e602116677658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602116677658 : Closed e602116677658 ∧ code e602116677658 = 2801139933210 := by decide
theorem cert_e602116677658 : check e602116677658 [[]] .width = true := by decide
def e602116677750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e602116677750 : Closed e602116677750 ∧ code e602116677750 = 2801139933302 := by decide
private def t_e602116677750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e602116677750 : ¬ IsSelfInterpreter e602116677750 :=
  wSource (t := t_e602116677750) (replay_sound (ps := []) (t := e602116677750) (by decide)) (by decide)
def e602116677994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e602116677994 : Closed e602116677994 ∧ code e602116677994 = 2801139933546 := by decide
private def t_e602116677994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e602116677994 : ¬ IsSelfInterpreter e602116677994 :=
  wSource (t := t_e602116677994) (replay_sound (ps := []) (t := e602116677994) (by decide)) (by decide)
def e602116678042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e602116678042 : Closed e602116678042 ∧ code e602116678042 = 2801139933594 := by decide
private def t_e602116678042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e602116678042 : ¬ IsSelfInterpreter e602116678042 :=
  wSource (t := t_e602116678042) (replay_sound (ps := []) (t := e602116678042) (by decide)) (by decide)
def e602116694042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602116694042 : Closed e602116694042 ∧ code e602116694042 = 2801139949594 := by decide
theorem cert_e602116694042 : check e602116694042 [[]] .width = true := by decide
def e602116694134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e602116694134 : Closed e602116694134 ∧ code e602116694134 = 2801139949686 := by decide
private def t_e602116694134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e602116694134 : ¬ IsSelfInterpreter e602116694134 :=
  wSource (t := t_e602116694134) (replay_sound (ps := []) (t := e602116694134) (by decide)) (by decide)
def e602116694378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e602116694378 : Closed e602116694378 ∧ code e602116694378 = 2801139949930 := by decide
private def t_e602116694378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e602116694378 : ¬ IsSelfInterpreter e602116694378 :=
  wSource (t := t_e602116694378) (replay_sound (ps := []) (t := e602116694378) (by decide)) (by decide)
def e602116694426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e602116694426 : Closed e602116694426 ∧ code e602116694426 = 2801139949978 := by decide
private def t_e602116694426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e602116694426 : ¬ IsSelfInterpreter e602116694426 :=
  wSource (t := t_e602116694426) (replay_sound (ps := []) (t := e602116694426) (by decide)) (by decide)
def e602201480046 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e602201480046 : Closed e602201480046 ∧ code e602201480046 = 2801224735598 := by decide
theorem cert_e602201480046 : check e602201480046 [[],[]] .chain = true := by decide
def e602201480054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e602201480054 : Closed e602201480054 ∧ code e602201480054 = 2801224735606 := by decide
theorem cert_e602201480054 : check e602201480054 [[],[]] .chain = true := by decide
def e602201480118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e602201480118 : Closed e602201480118 ∧ code e602201480118 = 2801224735670 := by decide
theorem cert_e602201480118 : check e602201480118 [[],[]] .chain = true := by decide
def e602201480558 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e602201480558 : Closed e602201480558 ∧ code e602201480558 = 2801224736110 := by decide
theorem cert_e602201480558 : check e602201480558 [[],[]] .chain = true := by decide
def e602201480566 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e602201480566 : Closed e602201480566 ∧ code e602201480566 = 2801224736118 := by decide
theorem cert_e602201480566 : check e602201480566 [[],[]] .chain = true := by decide
def e602201480622 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e602201480622 : Closed e602201480622 ∧ code e602201480622 = 2801224736174 := by decide
theorem cert_e602201480622 : check e602201480622 [[],[]] .chain = true := by decide
def e602201480634 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e602201480634 : Closed e602201480634 ∧ code e602201480634 = 2801224736186 := by decide
theorem cert_e602201480634 : check e602201480634 [[],[]] .chain = true := by decide
def e602201480662 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e602201480662 : Closed e602201480662 ∧ code e602201480662 = 2801224736214 := by decide
theorem cert_e602201480662 : check e602201480662 [[],[]] .chain = true := by decide
def e602201480666 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e602201480666 : Closed e602201480666 ∧ code e602201480666 = 2801224736218 := by decide
theorem cert_e602201480666 : check e602201480666 [[],[]] .chain = true := by decide
def e602201480886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e602201480886 : Closed e602201480886 ∧ code e602201480886 = 2801224736438 := by decide
theorem cert_e602201480886 : check e602201480886 [[],[]] .chain = true := by decide
def e602201480918 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e602201480918 : Closed e602201480918 ∧ code e602201480918 = 2801224736470 := by decide
theorem cert_e602201480918 : check e602201480918 [[],[]] .chain = true := by decide
def e602201480922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e602201480922 : Closed e602201480922 ∧ code e602201480922 = 2801224736474 := by decide
theorem cert_e602201480922 : check e602201480922 [[],[]] .chain = true := by decide
def e602201483118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e602201483118 : Closed e602201483118 ∧ code e602201483118 = 2801224738670 := by decide
theorem cert_e602201483118 : check e602201483118 [[],[]] .chain = true := by decide
def e602201483126 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e602201483126 : Closed e602201483126 ∧ code e602201483126 = 2801224738678 := by decide
theorem cert_e602201483126 : check e602201483126 [[],[]] .chain = true := by decide
def e602201483190 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e602201483190 : Closed e602201483190 ∧ code e602201483190 = 2801224738742 := by decide
theorem cert_e602201483190 : check e602201483190 [[],[]] .chain = true := by decide
def e602201484526 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e602201484526 : Closed e602201484526 ∧ code e602201484526 = 2801224740078 := by decide
theorem cert_e602201484526 : check e602201484526 [[],[]] .chain = true := by decide
def e602201484534 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e602201484534 : Closed e602201484534 ∧ code e602201484534 = 2801224740086 := by decide
theorem cert_e602201484534 : check e602201484534 [[],[]] .chain = true := by decide
def e602201484918 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e602201484918 : Closed e602201484918 ∧ code e602201484918 = 2801224740470 := by decide
theorem cert_e602201484918 : check e602201484918 [[],[]] .chain = true := by decide
def e602201486190 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e602201486190 : Closed e602201486190 ∧ code e602201486190 = 2801224741742 := by decide
theorem cert_e602201486190 : check e602201486190 [[],[]] .chain = true := by decide
def e602201486198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e602201486198 : Closed e602201486198 ∧ code e602201486198 = 2801224741750 := by decide
theorem cert_e602201486198 : check e602201486198 [[],[]] .chain = true := by decide
def e602201486254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e602201486254 : Closed e602201486254 ∧ code e602201486254 = 2801224741806 := by decide
theorem cert_e602201486254 : check e602201486254 [[],[]] .chain = true := by decide
def e602201486266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e602201486266 : Closed e602201486266 ∧ code e602201486266 = 2801224741818 := by decide
theorem cert_e602201486266 : check e602201486266 [[],[]] .chain = true := by decide
def e602201486294 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e602201486294 : Closed e602201486294 ∧ code e602201486294 = 2801224741846 := by decide
theorem cert_e602201486294 : check e602201486294 [[],[]] .chain = true := by decide
def e602201486298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e602201486298 : Closed e602201486298 ∧ code e602201486298 = 2801224741850 := by decide
theorem cert_e602201486298 : check e602201486298 [[],[]] .chain = true := by decide
def e602201486574 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e602201486574 : Closed e602201486574 ∧ code e602201486574 = 2801224742126 := by decide
theorem cert_e602201486574 : check e602201486574 [[],[]] .chain = true := by decide
def e602201486582 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e602201486582 : Closed e602201486582 ∧ code e602201486582 = 2801224742134 := by decide
theorem cert_e602201486582 : check e602201486582 [[],[]] .chain = true := by decide
def e602201486958 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e602201486958 : Closed e602201486958 ∧ code e602201486958 = 2801224742510 := by decide
theorem cert_e602201486958 : check e602201486958 [[],[]] .chain = true := by decide
def e602201486970 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e602201486970 : Closed e602201486970 ∧ code e602201486970 = 2801224742522 := by decide
theorem cert_e602201486970 : check e602201486970 [[],[]] .chain = true := by decide
def e602201487158 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e602201487158 : Closed e602201487158 ∧ code e602201487158 = 2801224742710 := by decide
theorem cert_e602201487158 : check e602201487158 [[],[]] .chain = true := by decide
def e602201487162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e602201487162 : Closed e602201487162 ∧ code e602201487162 = 2801224742714 := by decide
theorem cert_e602201487162 : check e602201487162 [[],[]] .chain = true := by decide
def e602201487798 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e602201487798 : Closed e602201487798 ∧ code e602201487798 = 2801224743350 := by decide
theorem cert_e602201487798 : check e602201487798 [[],[]] .chain = true := by decide
def e602201487830 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e602201487830 : Closed e602201487830 ∧ code e602201487830 = 2801224743382 := by decide
theorem cert_e602201487830 : check e602201487830 [[],[]] .chain = true := by decide
def e602201487834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e602201487834 : Closed e602201487834 ∧ code e602201487834 = 2801224743386 := by decide
theorem cert_e602201487834 : check e602201487834 [[],[]] .chain = true := by decide
def e602201487990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e602201487990 : Closed e602201487990 ∧ code e602201487990 = 2801224743542 := by decide
theorem cert_e602201487990 : check e602201487990 [[],[]] .chain = true := by decide
def e602201488182 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e602201488182 : Closed e602201488182 ∧ code e602201488182 = 2801224743734 := by decide
theorem cert_e602201488182 : check e602201488182 [[],[]] .chain = true := by decide
def e602201488186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e602201488186 : Closed e602201488186 ∧ code e602201488186 = 2801224743738 := by decide
theorem cert_e602201488186 : check e602201488186 [[],[]] .chain = true := by decide
def e602201495406 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e602201495406 : Closed e602201495406 ∧ code e602201495406 = 2801224750958 := by decide
theorem cert_e602201495406 : check e602201495406 [[],[]] .chain = true := by decide
def e602201495414 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e602201495414 : Closed e602201495414 ∧ code e602201495414 = 2801224750966 := by decide
theorem cert_e602201495414 : check e602201495414 [[],[]] .chain = true := by decide
def e602201495478 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e602201495478 : Closed e602201495478 ∧ code e602201495478 = 2801224751030 := by decide
theorem cert_e602201495478 : check e602201495478 [[],[]] .chain = true := by decide
def e602201496814 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e602201496814 : Closed e602201496814 ∧ code e602201496814 = 2801224752366 := by decide
theorem cert_e602201496814 : check e602201496814 [[],[]] .chain = true := by decide
def e602201496822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e602201496822 : Closed e602201496822 ∧ code e602201496822 = 2801224752374 := by decide
theorem cert_e602201496822 : check e602201496822 [[],[]] .chain = true := by decide
def e602201497206 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e602201497206 : Closed e602201497206 ∧ code e602201497206 = 2801224752758 := by decide
theorem cert_e602201497206 : check e602201497206 [[],[]] .chain = true := by decide
def e602201508718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e602201508718 : Closed e602201508718 ∧ code e602201508718 = 2801224764270 := by decide
theorem cert_e602201508718 : check e602201508718 [[],[]] .chain = true := by decide
def e602201508726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e602201508726 : Closed e602201508726 ∧ code e602201508726 = 2801224764278 := by decide
theorem cert_e602201508726 : check e602201508726 [[],[]] .chain = true := by decide
def e602201508782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e602201508782 : Closed e602201508782 ∧ code e602201508782 = 2801224764334 := by decide
theorem cert_e602201508782 : check e602201508782 [[],[]] .chain = true := by decide
def e602201508794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e602201508794 : Closed e602201508794 ∧ code e602201508794 = 2801224764346 := by decide
theorem cert_e602201508794 : check e602201508794 [[],[]] .chain = true := by decide
def e602201508822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e602201508822 : Closed e602201508822 ∧ code e602201508822 = 2801224764374 := by decide
theorem cert_e602201508822 : check e602201508822 [[],[]] .chain = true := by decide
def e602201508826 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e602201508826 : Closed e602201508826 ∧ code e602201508826 = 2801224764378 := by decide
theorem cert_e602201508826 : check e602201508826 [[],[]] .chain = true := by decide
def e602201509102 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e602201509102 : Closed e602201509102 ∧ code e602201509102 = 2801224764654 := by decide
theorem cert_e602201509102 : check e602201509102 [[],[]] .chain = true := by decide
def e602201509110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e602201509110 : Closed e602201509110 ∧ code e602201509110 = 2801224764662 := by decide
theorem cert_e602201509110 : check e602201509110 [[],[]] .chain = true := by decide
def e602201509486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e602201509486 : Closed e602201509486 ∧ code e602201509486 = 2801224765038 := by decide
theorem cert_e602201509486 : check e602201509486 [[],[]] .chain = true := by decide
def e602201509498 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e602201509498 : Closed e602201509498 ∧ code e602201509498 = 2801224765050 := by decide
theorem cert_e602201509498 : check e602201509498 [[],[]] .chain = true := by decide
def e602201509686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e602201509686 : Closed e602201509686 ∧ code e602201509686 = 2801224765238 := by decide
theorem cert_e602201509686 : check e602201509686 [[],[]] .chain = true := by decide
def e602201509690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e602201509690 : Closed e602201509690 ∧ code e602201509690 = 2801224765242 := by decide
theorem cert_e602201509690 : check e602201509690 [[],[]] .chain = true := by decide
def e602201515446 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e602201515446 : Closed e602201515446 ∧ code e602201515446 = 2801224770998 := by decide
theorem cert_e602201515446 : check e602201515446 [[],[]] .chain = true := by decide
def e602201515478 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e602201515478 : Closed e602201515478 ∧ code e602201515478 = 2801224771030 := by decide
theorem cert_e602201515478 : check e602201515478 [[],[]] .chain = true := by decide
def e602201515482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e602201515482 : Closed e602201515482 ∧ code e602201515482 = 2801224771034 := by decide
theorem cert_e602201515482 : check e602201515482 [[],[]] .chain = true := by decide
def e602201515638 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e602201515638 : Closed e602201515638 ∧ code e602201515638 = 2801224771190 := by decide
theorem cert_e602201515638 : check e602201515638 [[],[]] .chain = true := by decide
def e602201515830 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e602201515830 : Closed e602201515830 ∧ code e602201515830 = 2801224771382 := by decide
theorem cert_e602201515830 : check e602201515830 [[],[]] .chain = true := by decide
def e602201515834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e602201515834 : Closed e602201515834 ∧ code e602201515834 = 2801224771386 := by decide
theorem cert_e602201515834 : check e602201515834 [[],[]] .chain = true := by decide
def e602201852782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e602201852782 : Closed e602201852782 ∧ code e602201852782 = 2801225108334 := by decide
theorem cert_e602201852782 : check e602201852782 [[],[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e602201852790 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e602201852790 : Closed e602201852790 ∧ code e602201852790 = 2801225108342 := by decide
private def t_e602201852790 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e602201852790 : ¬ IsSelfInterpreter e602201852790 :=
  wSource (t := t_e602201852790) (replay_sound (ps := []) (t := e602201852790) (by decide)) (by decide)
def e602201852846 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e602201852846 : Closed e602201852846 ∧ code e602201852846 = 2801225108398 := by decide
theorem cert_e602201852846 : check e602201852846 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e602201852858 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e602201852858 : Closed e602201852858 ∧ code e602201852858 = 2801225108410 := by decide
theorem cert_e602201852858 : check e602201852858 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e602201852886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e602201852886 : Closed e602201852886 ∧ code e602201852886 = 2801225108438 := by decide
private def t_e602201852886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e602201852886 : ¬ IsSelfInterpreter e602201852886 :=
  wSource (t := t_e602201852886) (replay_sound (ps := []) (t := e602201852886) (by decide)) (by decide)
def e602201852890 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e602201852890 : Closed e602201852890 ∧ code e602201852890 = 2801225108442 := by decide
theorem cert_e602201852890 : check e602201852890 [[],[],[.under],[.under],[.under,.left]] .sourceHead = true := by decide
def e602201853166 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e602201853166 : Closed e602201853166 ∧ code e602201853166 = 2801225108718 := by decide
theorem cert_e602201853166 : checkPay e602201853166 [[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[]] 0 [] = true := by decide
def e602201853174 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e602201853174 : Closed e602201853174 ∧ code e602201853174 = 2801225108726 := by decide
theorem cert_e602201853174 : checkPay e602201853174 [[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[],[.left]] 0 [] = true := by decide
def e602201853550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e602201853550 : Closed e602201853550 ∧ code e602201853550 = 2801225109102 := by decide
theorem cert_e602201853550 : check e602201853550 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e602201853562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e602201853562 : Closed e602201853562 ∧ code e602201853562 = 2801225109114 := by decide
theorem cert_e602201853562 : check e602201853562 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e602201853750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e602201853750 : Closed e602201853750 ∧ code e602201853750 = 2801225109302 := by decide
theorem cert_e602201853750 : check e602201853750 [[],[],[.under],[.under],[.under],[.under,.left]] .chain = true := by decide
def e602201853754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e602201853754 : Closed e602201853754 ∧ code e602201853754 = 2801225109306 := by decide
theorem cert_e602201853754 : check e602201853754 [[],[],[.under],[.under],[.under]] .sourceHead = true := by decide
def e602236444186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602236444186 : Closed e602236444186 ∧ code e602236444186 = 2801259699738 := by decide
theorem cert_e602236444186 : check e602236444186 [[]] .width = true := by decide
def e602236450330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602236450330 : Closed e602236450330 ∧ code e602236450330 = 2801259705882 := by decide
theorem cert_e602236450330 : check e602236450330 [[]] .width = true := by decide
def e602236476954 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602236476954 : Closed e602236476954 ∧ code e602236476954 = 2801259732506 := by decide
theorem cert_e602236476954 : check e602236476954 [[]] .width = true := by decide
def e602236484122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602236484122 : Closed e602236484122 ∧ code e602236484122 = 2801259739674 := by decide
private def t_e602236484122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e602236484122 : ¬ IsSelfInterpreter e602236484122 :=
  wSource (t := t_e602236484122) (replay_sound (ps := []) (t := e602236484122) (by decide)) (by decide)
def e602236507674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602236507674 : Closed e602236507674 ∧ code e602236507674 = 2801259763226 := by decide
theorem cert_e602236507674 : check e602236507674 [[]] .width = true := by decide
def e602236508698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602236508698 : Closed e602236508698 ∧ code e602236508698 = 2801259764250 := by decide
private def t_e602236508698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e602236508698 : ¬ IsSelfInterpreter e602236508698 :=
  wSource (t := t_e602236508698) (replay_sound (ps := []) (t := e602236508698) (by decide)) (by decide)
def e602236640794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602236640794 : Closed e602236640794 ∧ code e602236640794 = 2801259896346 := by decide
theorem cert_e602236640794 : check e602236640794 [[]] .width = true := by decide
def e602236646938 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602236646938 : Closed e602236646938 ∧ code e602236646938 = 2801259902490 := by decide
theorem cert_e602236646938 : check e602236646938 [[]] .width = true := by decide
def e602236837402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602236837402 : Closed e602236837402 ∧ code e602236837402 = 2801260092954 := by decide
theorem cert_e602236837402 : check e602236837402 [[]] .width = true := by decide
def e602236844570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602236844570 : Closed e602236844570 ∧ code e602236844570 = 2801260100122 := by decide
theorem cert_e602236844570 : check e602236844570 [[]] .width = true := by decide
def e602236991002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602236991002 : Closed e602236991002 ∧ code e602236991002 = 2801260246554 := by decide
theorem cert_e602236991002 : check e602236991002 [[]] .width = true := by decide
def e602236992026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602236992026 : Closed e602236992026 ∧ code e602236992026 = 2801260247578 := by decide
theorem cert_e602236992026 : check e602236992026 [[]] .width = true := by decide
def e602240773658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602240773658 : Closed e602240773658 ∧ code e602240773658 = 2801264029210 := by decide
theorem cert_e602240773658 : check e602240773658 [[]] .width = true := by decide
def e602240775706 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602240775706 : Closed e602240775706 ∧ code e602240775706 = 2801264031258 := by decide
theorem cert_e602240775706 : check e602240775706 [[]] .width = true := by decide
def e602240917018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602240917018 : Closed e602240917018 ∧ code e602240917018 = 2801264172570 := by decide
private def t_e602240917018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e602240917018 : ¬ IsSelfInterpreter e602240917018 :=
  wSource (t := t_e602240917018) (replay_sound (ps := []) (t := e602240917018) (by decide)) (by decide)
def e602240938182 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e602240938182 : Closed e602240938182 ∧ code e602240938182 = 2801264193734 := by decide
theorem cert_e602240938182 : check e602240938182 [[]] .width = true := by decide
def e602240945690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602240945690 : Closed e602240945690 ∧ code e602240945690 = 2801264201242 := by decide
private def t_e602240945690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e602240945690 : ¬ IsSelfInterpreter e602240945690 :=
  wSource (t := t_e602240945690) (replay_sound (ps := []) (t := e602240945690) (by decide)) (by decide)
def e602240954566 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e602240954566 : Closed e602240954566 ∧ code e602240954566 = 2801264210118 := by decide
theorem cert_e602240954566 : check e602240954566 [[]] .width = true := by decide
def e602241003034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602241003034 : Closed e602241003034 ∧ code e602241003034 = 2801264258586 := by decide
theorem cert_e602241003034 : check e602241003034 [[]] .width = true := by decide
def e602241006106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602241006106 : Closed e602241006106 ∧ code e602241006106 = 2801264261658 := by decide
theorem cert_e602241006106 : check e602241006106 [[]] .width = true := by decide
def e602241048090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602241048090 : Closed e602241048090 ∧ code e602241048090 = 2801264303642 := by decide
private def t_e602241048090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e602241048090 : ¬ IsSelfInterpreter e602241048090 :=
  wSource (t := t_e602241048090) (replay_sound (ps := []) (t := e602241048090) (by decide)) (by decide)
def e602241069254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e602241069254 : Closed e602241069254 ∧ code e602241069254 = 2801264324806 := by decide
theorem cert_e602241069254 : check e602241069254 [[]] .width = true := by decide
def e602241091098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602241091098 : Closed e602241091098 ∧ code e602241091098 = 2801264346650 := by decide
private def t_e602241091098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e602241091098 : ¬ IsSelfInterpreter e602241091098 :=
  wSource (t := t_e602241091098) (replay_sound (ps := []) (t := e602241091098) (by decide)) (by decide)
def e602241093830 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e602241093830 : Closed e602241093830 ∧ code e602241093830 = 2801264349382 := by decide
theorem cert_e602241093830 : check e602241093830 [[]] .width = true := by decide
def e602241119770 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602241119770 : Closed e602241119770 ∧ code e602241119770 = 2801264375322 := by decide
theorem cert_e602241119770 : check e602241119770 [[]] .width = true := by decide
def e602241120794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602241120794 : Closed e602241120794 ∧ code e602241120794 = 2801264376346 := by decide
theorem cert_e602241120794 : check e602241120794 [[]] .width = true := by decide
def e602241142298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602241142298 : Closed e602241142298 ∧ code e602241142298 = 2801264397850 := by decide
private def t_e602241142298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e602241142298 : ¬ IsSelfInterpreter e602241142298 :=
  wSource (t := t_e602241142298) (replay_sound (ps := []) (t := e602241142298) (by decide)) (by decide)
def e602241151174 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e602241151174 : Closed e602241151174 ∧ code e602241151174 = 2801264406726 := by decide
theorem cert_e602241151174 : check e602241151174 [[]] .width = true := by decide
def e602241156634 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602241156634 : Closed e602241156634 ∧ code e602241156634 = 2801264412186 := by decide
private def t_e602241156634 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e602241156634 : ¬ IsSelfInterpreter e602241156634 :=
  wSource (t := t_e602241156634) (replay_sound (ps := []) (t := e602241156634) (by decide)) (by decide)
def e602241159366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e602241159366 : Closed e602241159366 ∧ code e602241159366 = 2801264414918 := by decide
theorem cert_e602241159366 : check e602241159366 [[]] .width = true := by decide
def e602241703450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602241703450 : Closed e602241703450 ∧ code e602241703450 = 2801264959002 := by decide
theorem cert_e602241703450 : check e602241703450 [[]] .width = true := by decide
def e602241724614 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e602241724614 : Closed e602241724614 ∧ code e602241724614 = 2801264980166 := by decide
theorem cert_e602241724614 : check e602241724614 [[]] .width = true := by decide
def e602241732122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602241732122 : Closed e602241732122 ∧ code e602241732122 = 2801264987674 := by decide
theorem cert_e602241732122 : check e602241732122 [[]] .width = true := by decide
def e602241740998 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e602241740998 : Closed e602241740998 ∧ code e602241740998 = 2801264996550 := by decide
theorem cert_e602241740998 : check e602241740998 [[]] .width = true := by decide
def e602242489882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602242489882 : Closed e602242489882 ∧ code e602242489882 = 2801265745434 := by decide
theorem cert_e602242489882 : check e602242489882 [[]] .width = true := by decide
def e602242511046 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e602242511046 : Closed e602242511046 ∧ code e602242511046 = 2801265766598 := by decide
theorem cert_e602242511046 : check e602242511046 [[]] .width = true := by decide
def e602242532890 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602242532890 : Closed e602242532890 ∧ code e602242532890 = 2801265788442 := by decide
theorem cert_e602242532890 : check e602242532890 [[]] .width = true := by decide
def e602242535622 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e602242535622 : Closed e602242535622 ∧ code e602242535622 = 2801265791174 := by decide
theorem cert_e602242535622 : check e602242535622 [[]] .width = true := by decide
def e602242911770 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602242911770 : Closed e602242911770 ∧ code e602242911770 = 2801266167322 := by decide
theorem cert_e602242911770 : check e602242911770 [[]] .width = true := by decide
def e602242920646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e602242920646 : Closed e602242920646 ∧ code e602242920646 = 2801266176198 := by decide
theorem cert_e602242920646 : check e602242920646 [[]] .width = true := by decide
def e602242926106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e602242926106 : Closed e602242926106 ∧ code e602242926106 = 2801266181658 := by decide
theorem cert_e602242926106 : check e602242926106 [[]] .width = true := by decide
def e602242928838 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e602242928838 : Closed e602242928838 ∧ code e602242928838 = 2801266184390 := by decide
theorem cert_e602242928838 : check e602242928838 [[]] .width = true := by decide
def e602268588910 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e602268588910 : Closed e602268588910 ∧ code e602268588910 = 2801291844462 := by decide
theorem cert_e602268588910 : check e602268588910 [[],[]] .chain = true := by decide
def e602268588918 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e602268588918 : Closed e602268588918 ∧ code e602268588918 = 2801291844470 := by decide
theorem cert_e602268588918 : check e602268588918 [[],[]] .chain = true := by decide
def e602268588982 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e602268588982 : Closed e602268588982 ∧ code e602268588982 = 2801291844534 := by decide
theorem cert_e602268588982 : check e602268588982 [[],[]] .chain = true := by decide
def e602268589422 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e602268589422 : Closed e602268589422 ∧ code e602268589422 = 2801291844974 := by decide
theorem cert_e602268589422 : check e602268589422 [[],[]] .chain = true := by decide
def e602268589430 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e602268589430 : Closed e602268589430 ∧ code e602268589430 = 2801291844982 := by decide
theorem cert_e602268589430 : check e602268589430 [[],[]] .chain = true := by decide
def e602268589486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e602268589486 : Closed e602268589486 ∧ code e602268589486 = 2801291845038 := by decide
theorem cert_e602268589486 : check e602268589486 [[],[]] .chain = true := by decide
def e602268589498 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e602268589498 : Closed e602268589498 ∧ code e602268589498 = 2801291845050 := by decide
theorem cert_e602268589498 : check e602268589498 [[],[]] .chain = true := by decide
def e602268589526 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e602268589526 : Closed e602268589526 ∧ code e602268589526 = 2801291845078 := by decide
theorem cert_e602268589526 : check e602268589526 [[],[]] .chain = true := by decide
def e602268589530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e602268589530 : Closed e602268589530 ∧ code e602268589530 = 2801291845082 := by decide
theorem cert_e602268589530 : check e602268589530 [[],[]] .chain = true := by decide
def e602268589750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e602268589750 : Closed e602268589750 ∧ code e602268589750 = 2801291845302 := by decide
theorem cert_e602268589750 : check e602268589750 [[],[]] .chain = true := by decide
def e602268589782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e602268589782 : Closed e602268589782 ∧ code e602268589782 = 2801291845334 := by decide
theorem cert_e602268589782 : check e602268589782 [[],[]] .chain = true := by decide
def e602268589786 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e602268589786 : Closed e602268589786 ∧ code e602268589786 = 2801291845338 := by decide
theorem cert_e602268589786 : check e602268589786 [[],[]] .chain = true := by decide
end Blc.Floor41
