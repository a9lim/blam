import Extra41
import Batch044
import Batch061
import Batch064
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness598355273134
private def u0 := Term.var 1
private def u1 := Term.lam u0
private def u2 := Term.lam u1
private def u3 := Term.var 0
private def u4 := Term.lam u3
private def u5 := Term.app u3 u3
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u3 u10
private def u12 := Term.lam u11
private def u13 := Term.app u12 u12
private def u14 := Term.app u13 u12
private def u15 := Term.app u14 u2
private def u16 := Term.app u3 u2
private def u17 := Term.lam u4
private def u18 := Term.app u3 u17
private def u19 := Term.var 4
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u16 u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u26
private def u28 := Term.app u15 u27
private def u29 := Term.app u5 u12
private def u30 := Term.app u0 u29
private def u31 := Term.lam u30
private def u32 := Term.lam u31
private def u33 := Term.app u12 u32
private def u34 := Term.app u33 u12
private def u35 := Term.app u34 u2
private def u36 := Term.app u35 u27
theorem nege598355273134 : ¬ IsSelfInterpreter e598355273134 := by
  intro he
  have hv : NFt u17 := by decide
  have reach : Betas (Floor40.call e598355273134 u2 u4 u3 []) u17 := reachesNF [[.left],[]] he (by decide) (by decide) hv
  have hr : replay [[.left,.left]] (Floor40.call e598355273134 u2 u4 u3 []) = some u28 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u28) (u := u36) [] (by decide) (replay_sound (ps := [[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.under],[.left,.left],[.left],[.left,.right,.left],[.left,.right]]) (by decide)) j hj
#print axioms nege598355273134
end Witness598355273134
namespace Witness598355273146
private def u0 := Term.var 0
private def u1 := Term.lam u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.app u0 u4
private def u6 := Term.app u5 u0
private def u7 := Term.app u3 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.lam u10
private def u12 := Term.app u11 u11
private def u13 := Term.app u12 u11
private def u14 := Term.app u13 u2
private def u15 := Term.lam u3
private def u16 := Term.lam u15
private def u17 := Term.app u0 u16
private def u18 := Term.app u0 u2
private def u19 := Term.var 4
private def u20 := Term.app u17 u19
private def u21 := Term.lam u20
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u17 u23
private def u25 := Term.lam u24
private def u26 := Term.app u17 u25
private def u27 := Term.lam u26
private def u28 := Term.app u14 u27
private def u29 := Term.app u0 u11
private def u30 := Term.app u29 u0
private def u31 := Term.app u3 u30
private def u32 := Term.lam u31
private def u33 := Term.lam u32
private def u34 := Term.app u11 u33
private def u35 := Term.app u34 u11
private def u36 := Term.app u35 u2
private def u37 := Term.app u36 u27
theorem nege598355273146 : ¬ IsSelfInterpreter e598355273146 := by
  intro he
  have hv : NFt u0 := by decide
  have reach : Betas (Floor40.call e598355273146 u2 u1 u0 []) u0 := reachesNF [[.left],[]] he (by decide) (by decide) hv
  have hr : replay [[.left,.left]] (Floor40.call e598355273146 u2 u1 u0 []) = some u28 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u28) (u := u37) [] (by decide) (replay_sound (ps := [[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.under],[.left,.left],[.left],[.left,.right,.left],[.left,.right]]) (by decide)) j hj
#print axioms nege598355273146
end Witness598355273146
namespace Witness598355273338
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u1 u4
private def u6 := Term.app u0 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u1
private def u12 := Term.app u1 u11
private def u13 := Term.app u0 u12
private def u14 := Term.lam u13
private def u15 := Term.lam u14
private def u16 := Term.app u15 u0
private def u17 := Term.app u0 u16
private def u18 := Term.app u15 u17
private def u19 := Term.app u17 u18
private def u20 := Term.app u10 u10
private def u21 := Term.app u20 u19
private def u22 := Term.app u19 u21
private def u23 := Term.app u20 u22
private def u24 := Term.app u22 u23
private def u25 := Term.lam u0
private def u26 := Term.lam u25
private def u27 := Term.app u1 u26
private def u28 := Term.lam u2
private def u29 := Term.app u1 u28
private def u30 := Term.var 4
private def u31 := Term.app u27 u30
private def u32 := Term.lam u31
private def u33 := Term.app u29 u32
private def u34 := Term.lam u33
private def u35 := Term.app u27 u34
private def u36 := Term.lam u35
private def u37 := Term.app u27 u36
private def u38 := Term.lam u37
private def u39 := Term.app u20 u1
private def u40 := Term.app u1 u39
private def u41 := Term.app u0 u40
private def u42 := Term.lam u41
private def u43 := Term.lam u42
private def u44 := Term.app u43 u38
private def u45 := Term.app u38 u44
private def u46 := Term.app u24 u45
private def u47 := Term.app u0 u28
private def u48 := Term.app u47 u1
theorem nege598355273338 : ¬ IsSelfInterpreter e598355273338 := by
  intro he
  have hv : NFt u48 := by decide
  have reach : Betas (Floor40.call e598355273338 u0 u2 u1 []) u48 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left],[]] (Floor40.call e598355273338 u0 u2 u1 []) = some u46 := by decide
  exact mismatches hv reach hr 3 (by decide)
#print axioms nege598355273338
end Witness598355273338
namespace Witness604332886902
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u1 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.lam u12
private def u14 := Term.app u9 u13
private def u15 := Term.app u14 u9
private def u16 := Term.app u9 u9
private def u17 := Term.app u16 u9
private def u18 := Term.app u1 u17
private def u19 := Term.app u18 u0
private def u20 := Term.lam u19
private def u21 := Term.lam u20
private def u22 := Term.app u15 u21
private def u23 := Term.app u22 u0
private def u24 := Term.lam u0
private def u25 := Term.lam u24
private def u26 := Term.app u1 u25
private def u27 := Term.lam u2
private def u28 := Term.app u1 u27
private def u29 := Term.var 4
private def u30 := Term.app u26 u29
private def u31 := Term.lam u30
private def u32 := Term.app u28 u31
private def u33 := Term.lam u32
private def u34 := Term.app u26 u33
private def u35 := Term.lam u34
private def u36 := Term.app u26 u35
private def u37 := Term.lam u36
private def u38 := Term.app u23 u37
private def u39 := Term.app u0 u27
private def u40 := Term.app u39 u1
private def u41 := Term.app u1 u13
private def u42 := Term.app u41 u0
private def u43 := Term.lam u42
private def u44 := Term.lam u43
private def u45 := Term.app u13 u44
private def u46 := Term.app u45 u9
private def u47 := Term.app u46 u21
private def u48 := Term.app u47 u0
private def u49 := Term.app u48 u37
theorem nege604332886902 : ¬ IsSelfInterpreter e604332886902 := by
  intro he
  have hv : NFt u40 := by decide
  have reach : Betas (Floor40.call e604332886902 u0 u2 u1 []) u40 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left,.left,.left,.left]] (Floor40.call e604332886902 u0 u2 u1 []) = some u38 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u38) (u := u49) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]]) (by decide)) j hj
#print axioms nege604332886902
end Witness604332886902
namespace Witness604332886958
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u0 u1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u3 u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u9 u12
private def u14 := Term.app u13 u9
private def u15 := Term.app u9 u9
private def u16 := Term.app u15 u9
private def u17 := Term.app u3 u16
private def u18 := Term.lam u17
private def u19 := Term.lam u18
private def u20 := Term.app u14 u19
private def u21 := Term.app u20 u0
private def u22 := Term.lam u0
private def u23 := Term.lam u22
private def u24 := Term.app u1 u23
private def u25 := Term.lam u2
private def u26 := Term.app u1 u25
private def u27 := Term.var 4
private def u28 := Term.app u24 u27
private def u29 := Term.lam u28
private def u30 := Term.app u26 u29
private def u31 := Term.lam u30
private def u32 := Term.app u24 u31
private def u33 := Term.lam u32
private def u34 := Term.app u24 u33
private def u35 := Term.lam u34
private def u36 := Term.app u21 u35
private def u37 := Term.app u0 u25
private def u38 := Term.app u37 u1
private def u39 := Term.app u3 u12
private def u40 := Term.lam u39
private def u41 := Term.lam u40
private def u42 := Term.app u12 u41
private def u43 := Term.app u42 u9
private def u44 := Term.app u43 u19
private def u45 := Term.app u44 u0
private def u46 := Term.app u45 u35
theorem nege604332886958 : ¬ IsSelfInterpreter e604332886958 := by
  intro he
  have hv : NFt u38 := by decide
  have reach : Betas (Floor40.call e604332886958 u0 u2 u1 []) u38 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left,.left,.left,.left]] (Floor40.call e604332886958 u0 u2 u1 []) = some u36 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u36) (u := u46) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]]) (by decide)) j hj
#print axioms nege604332886958
end Witness604332886958
namespace Witness604332886998
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.app u8 u0
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u11 u1
private def u13 := Term.app u12 u0
private def u14 := Term.lam u13
private def u15 := Term.lam u14
private def u16 := Term.app u11 u15
private def u17 := Term.var 3
private def u18 := Term.app u17 u1
private def u19 := Term.app u18 u0
private def u20 := Term.lam u19
private def u21 := Term.lam u20
private def u22 := Term.app u0 u21
private def u23 := Term.app u22 u1
private def u24 := Term.lam u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u8
private def u28 := Term.app u27 u27
private def u29 := Term.app u28 u27
private def u30 := Term.app u29 u1
private def u31 := Term.app u30 u0
private def u32 := Term.lam u31
private def u33 := Term.lam u32
private def u34 := Term.app u26 u33
private def u35 := Term.app u34 u0
private def u36 := Term.lam u0
private def u37 := Term.lam u36
private def u38 := Term.app u1 u37
private def u39 := Term.lam u2
private def u40 := Term.app u1 u39
private def u41 := Term.var 4
private def u42 := Term.app u38 u41
private def u43 := Term.lam u42
private def u44 := Term.app u40 u43
private def u45 := Term.lam u44
private def u46 := Term.app u38 u45
private def u47 := Term.lam u46
private def u48 := Term.app u38 u47
private def u49 := Term.lam u48
private def u50 := Term.app u35 u49
private def u51 := Term.app u0 u39
private def u52 := Term.app u51 u1
private def u53 := Term.app u8 u15
private def u54 := Term.lam u53
private def u55 := Term.app u54 u25
private def u56 := Term.app u55 u33
private def u57 := Term.app u56 u0
private def u58 := Term.app u57 u49
theorem nege604332886998 : ¬ IsSelfInterpreter e604332886998 := by
  intro he
  have hv : NFt u52 := by decide
  have reach : Betas (Floor40.call e604332886998 u0 u2 u1 []) u52 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.under,.right,.under,.under,.left],[.left,.left,.left,.left,.under,.right,.under,.under],[.left,.left,.left],[.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left]] (Floor40.call e604332886998 u0 u2 u1 []) = some u50 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u50) (u := u58) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left,.under,.right,.under,.under,.left],[.left,.left,.left,.left,.under,.right,.under,.under],[.left,.left,.left],[.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left,.right,.under,.under],[.left,.left,.left,.left],[.left,.left,.left]]) (by decide)) j hj
#print axioms nege604332886998
end Witness604332886998
namespace Witness604735540086
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u1 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.lam u12
private def u14 := Term.app u9 u13
private def u15 := Term.app u14 u9
private def u16 := Term.app u1 u13
private def u17 := Term.app u16 u0
private def u18 := Term.lam u17
private def u19 := Term.lam u18
private def u20 := Term.app u15 u19
private def u21 := Term.app u9 u9
private def u22 := Term.app u9 u21
private def u23 := Term.app u1 u22
private def u24 := Term.app u23 u0
private def u25 := Term.lam u24
private def u26 := Term.lam u25
private def u27 := Term.app u20 u26
private def u28 := Term.app u27 u0
private def u29 := Term.lam u0
private def u30 := Term.lam u29
private def u31 := Term.app u1 u30
private def u32 := Term.lam u2
private def u33 := Term.app u1 u32
private def u34 := Term.var 4
private def u35 := Term.app u31 u34
private def u36 := Term.lam u35
private def u37 := Term.app u33 u36
private def u38 := Term.lam u37
private def u39 := Term.app u31 u38
private def u40 := Term.lam u39
private def u41 := Term.app u31 u40
private def u42 := Term.lam u41
private def u43 := Term.app u28 u42
private def u44 := Term.app u0 u32
private def u45 := Term.app u44 u1
private def u46 := Term.app u13 u19
private def u47 := Term.app u46 u9
private def u48 := Term.app u47 u19
private def u49 := Term.app u48 u26
private def u50 := Term.app u49 u0
private def u51 := Term.app u50 u42
theorem nege604735540086 : ¬ IsSelfInterpreter e604735540086 := by
  intro he
  have hv : NFt u45 := by decide
  have reach : Betas (Floor40.call e604735540086 u0 u2 u1 []) u45 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left]] (Floor40.call e604735540086 u0 u2 u1 []) = some u43 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u43) (u := u51) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]]) (by decide)) j hj
#print axioms nege604735540086
end Witness604735540086
namespace Witness604735540142
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u0 u1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u3 u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u9 u12
private def u14 := Term.app u13 u9
private def u15 := Term.app u14 u12
private def u16 := Term.app u9 u9
private def u17 := Term.app u9 u16
private def u18 := Term.app u3 u17
private def u19 := Term.lam u18
private def u20 := Term.lam u19
private def u21 := Term.app u15 u20
private def u22 := Term.app u21 u0
private def u23 := Term.lam u0
private def u24 := Term.lam u23
private def u25 := Term.app u1 u24
private def u26 := Term.lam u2
private def u27 := Term.app u1 u26
private def u28 := Term.var 4
private def u29 := Term.app u25 u28
private def u30 := Term.lam u29
private def u31 := Term.app u27 u30
private def u32 := Term.lam u31
private def u33 := Term.app u25 u32
private def u34 := Term.lam u33
private def u35 := Term.app u25 u34
private def u36 := Term.lam u35
private def u37 := Term.app u22 u36
private def u38 := Term.app u0 u26
private def u39 := Term.app u38 u1
private def u40 := Term.app u3 u12
private def u41 := Term.lam u40
private def u42 := Term.lam u41
private def u43 := Term.app u12 u42
private def u44 := Term.app u43 u9
private def u45 := Term.app u44 u12
private def u46 := Term.app u45 u20
private def u47 := Term.app u46 u0
private def u48 := Term.app u47 u36
theorem nege604735540142 : ¬ IsSelfInterpreter e604735540142 := by
  intro he
  have hv : NFt u39 := by decide
  have reach : Betas (Floor40.call e604735540142 u0 u2 u1 []) u39 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left]] (Floor40.call e604735540142 u0 u2 u1 []) = some u37 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u37) (u := u48) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]]) (by decide)) j hj
#print axioms nege604735540142
end Witness604735540142
end Blc.Floor41
