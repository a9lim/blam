import CodeBridge
import Batch043
namespace Certgen.R598354180586
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 45,.app 2 33,.app 3 15,.lam 4,.app 5 14,.app 6 7,.var 0,.lam 8,.lam 9,.app 10 11,.var 1,.app 12 13,.var 2,.var 0,.var 0,.lam 16,.lam 17,.app 18 19,.var 1,.app 20 32,.lam 21,.app 22 31,.app 23 24,.var 0,.lam 25,.lam 26,.app 27 28,.var 1,.app 29 30,.var 2,.var 0,.var 0,.var 0,.lam 34,.app 35 44,.app 36 37,.var 0,.lam 38,.lam 39,.app 40 41,.var 1,.app 42 43,.var 2,.var 0,.var 0,.lam 46,.app 47 56,.app 48 49,.var 0,.lam 50,.lam 51,.app 52 53,.var 1,.app 54 55,.var 2,.var 0,.var 0]
def values : Array (List AClo) := #[[⟨7,[5]⟩,⟨24,[2,1,0]⟩],[⟨14,[5]⟩,⟨31,[2,1,0]⟩],[⟨32,[1,0]⟩],[⟨19,[1,0]⟩],[⟨11,[4,3,5]⟩,⟨28,[4,3,2,1,0]⟩,⟨33,[]⟩],[⟨15,[]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨45,[]⟩,0⟩],[⟨⟨33,[]⟩,1⟩],[⟨⟨19,[1,0]⟩,2⟩,⟨⟨19,[1,0]⟩,8⟩,⟨⟨19,[1,0]⟩,11⟩],[⟨⟨32,[1,0]⟩,8⟩,⟨⟨32,[1,0]⟩,11⟩],[⟨⟨15,[]⟩,2⟩],[⟨⟨31,[2,1,0]⟩,8⟩,⟨⟨31,[2,1,0]⟩,11⟩],[⟨⟨24,[2,1,0]⟩,6⟩],[⟨⟨28,[4,3,2,1,0]⟩,1⟩],[⟨⟨14,[5]⟩,2⟩],[⟨⟨7,[5]⟩,9⟩],[⟨⟨11,[4,3,5]⟩,1⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[]⟩,2⟩,⟨⟨3,[]⟩,5⟩,⟨⟨4,[5]⟩,2⟩,⟨⟨5,[5]⟩,9⟩,⟨⟨6,[5]⟩,10⟩,⟨⟨7,[5]⟩,3⟩,⟨⟨8,[3,5]⟩,2⟩,⟨⟨8,[3,5]⟩,8⟩,⟨⟨8,[3,5]⟩,11⟩,⟨⟨9,[4,3,5]⟩,1⟩,⟨⟨10,[4,3,5]⟩,11⟩,⟨⟨14,[5]⟩,7⟩,⟨⟨15,[]⟩,7⟩,⟨⟨15,[]⟩,10⟩,⟨⟨16,[0]⟩,6⟩,⟨⟨16,[0]⟩,9⟩,⟨⟨17,[1,0]⟩,2⟩,⟨⟨17,[1,0]⟩,8⟩,⟨⟨17,[1,0]⟩,11⟩,⟨⟨18,[1,0]⟩,3⟩,⟨⟨19,[1,0]⟩,8⟩,⟨⟨19,[1,0]⟩,11⟩,⟨⟨20,[1,0]⟩,4⟩,⟨⟨21,[2,1,0]⟩,8⟩,⟨⟨21,[2,1,0]⟩,11⟩,⟨⟨22,[2,1,0]⟩,6⟩,⟨⟨23,[2,1,0]⟩,7⟩,⟨⟨24,[2,1,0]⟩,3⟩,⟨⟨25,[3,2,1,0]⟩,2⟩,⟨⟨25,[3,2,1,0]⟩,8⟩,⟨⟨25,[3,2,1,0]⟩,11⟩,⟨⟨26,[4,3,2,1,0]⟩,1⟩,⟨⟨27,[4,3,2,1,0]⟩,8⟩,⟨⟨31,[2,1,0]⟩,7⟩,⟨⟨32,[1,0]⟩,7⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[4],[5],[6],[15],[8,9,10],[11],[11],[11],[12],[23],[14],[16],[17],[19,20],[18],[21],[21],[21],[7,29],[24],[24],[25,26],[27],[27],[28],[36],[30,31,32],[33],[33],[33],[34],[22],[36],[13,35]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem block24 : checkRange P V K states hints 24 12=true := by decide
theorem block36 : checkRange P V K states hints 36 1=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<37 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 by_cases h12 : i<24
 · exact range_sound block12 i (by omega) h12 hi
 by_cases h24 : i<36
 · exact range_sound block24 i (by omega) h24 hi
 exact range_sound block36 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Floor41 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit56 : Term := .var 0
def lit52 : Term := .var 1
def lit54 : Term := .var 2
def lit53 : Term := .app lit54 lit56
def lit51 : Term := .app lit52 lit53
def lit50 : Term := .lam lit51
def lit49 : Term := .lam lit50
def lit47 : Term := .app lit56 lit49
def lit46 : Term := .app lit47 lit56
def lit45 : Term := .lam lit46
def lit19 : Term := .app lit45 lit56
def lit17 : Term := .app lit52 lit19
def lit16 : Term := .lam lit17
def lit15 : Term := .lam lit16
def lit2 : Term := .app lit45 lit15
def lit1 : Term := .app lit2 lit45
def lit0 : Term := .app lit1 lit45
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub56 : model.term 56 = lit56 := model.var_eq 56 0 (by rfl)
theorem sub55 : model.term 55 = lit56 := model.var_eq 55 0 (by rfl)
theorem sub54 : model.term 54 = lit54 := model.var_eq 54 2 (by rfl)
theorem sub53 : model.term 53 = lit53 := by rw [model.app_eq 53 54 55 (by rfl), sub54, sub55]; rfl
theorem sub52 : model.term 52 = lit52 := model.var_eq 52 1 (by rfl)
theorem sub51 : model.term 51 = lit51 := by rw [model.app_eq 51 52 53 (by rfl), sub52, sub53]; rfl
theorem sub50 : model.term 50 = lit50 := by rw [model.lam_eq 50 51 (by rfl), sub51]; rfl
theorem sub49 : model.term 49 = lit49 := by rw [model.lam_eq 49 50 (by rfl), sub50]; rfl
theorem sub48 : model.term 48 = lit56 := model.var_eq 48 0 (by rfl)
theorem sub47 : model.term 47 = lit47 := by rw [model.app_eq 47 48 49 (by rfl), sub48, sub49]; rfl
theorem sub46 : model.term 46 = lit46 := by rw [model.app_eq 46 47 56 (by rfl), sub47, sub56]; rfl
theorem sub45 : model.term 45 = lit45 := by rw [model.lam_eq 45 46 (by rfl), sub46]; rfl
theorem sub44 : model.term 44 = lit56 := model.var_eq 44 0 (by rfl)
theorem sub43 : model.term 43 = lit56 := model.var_eq 43 0 (by rfl)
theorem sub42 : model.term 42 = lit54 := model.var_eq 42 2 (by rfl)
theorem sub41 : model.term 41 = lit53 := by rw [model.app_eq 41 42 43 (by rfl), sub42, sub43]; rfl
theorem sub40 : model.term 40 = lit52 := model.var_eq 40 1 (by rfl)
theorem sub39 : model.term 39 = lit51 := by rw [model.app_eq 39 40 41 (by rfl), sub40, sub41]; rfl
theorem sub38 : model.term 38 = lit50 := by rw [model.lam_eq 38 39 (by rfl), sub39]; rfl
theorem sub37 : model.term 37 = lit49 := by rw [model.lam_eq 37 38 (by rfl), sub38]; rfl
theorem sub36 : model.term 36 = lit56 := model.var_eq 36 0 (by rfl)
theorem sub35 : model.term 35 = lit47 := by rw [model.app_eq 35 36 37 (by rfl), sub36, sub37]; rfl
theorem sub34 : model.term 34 = lit46 := by rw [model.app_eq 34 35 44 (by rfl), sub35, sub44]; rfl
theorem sub33 : model.term 33 = lit45 := by rw [model.lam_eq 33 34 (by rfl), sub34]; rfl
theorem sub32 : model.term 32 = lit56 := model.var_eq 32 0 (by rfl)
theorem sub31 : model.term 31 = lit56 := model.var_eq 31 0 (by rfl)
theorem sub30 : model.term 30 = lit56 := model.var_eq 30 0 (by rfl)
theorem sub29 : model.term 29 = lit54 := model.var_eq 29 2 (by rfl)
theorem sub28 : model.term 28 = lit53 := by rw [model.app_eq 28 29 30 (by rfl), sub29, sub30]; rfl
theorem sub27 : model.term 27 = lit52 := model.var_eq 27 1 (by rfl)
theorem sub26 : model.term 26 = lit51 := by rw [model.app_eq 26 27 28 (by rfl), sub27, sub28]; rfl
theorem sub25 : model.term 25 = lit50 := by rw [model.lam_eq 25 26 (by rfl), sub26]; rfl
theorem sub24 : model.term 24 = lit49 := by rw [model.lam_eq 24 25 (by rfl), sub25]; rfl
theorem sub23 : model.term 23 = lit56 := model.var_eq 23 0 (by rfl)
theorem sub22 : model.term 22 = lit47 := by rw [model.app_eq 22 23 24 (by rfl), sub23, sub24]; rfl
theorem sub21 : model.term 21 = lit46 := by rw [model.app_eq 21 22 31 (by rfl), sub22, sub31]; rfl
theorem sub20 : model.term 20 = lit45 := by rw [model.lam_eq 20 21 (by rfl), sub21]; rfl
theorem sub19 : model.term 19 = lit19 := by rw [model.app_eq 19 20 32 (by rfl), sub20, sub32]; rfl
theorem sub18 : model.term 18 = lit52 := model.var_eq 18 1 (by rfl)
theorem sub17 : model.term 17 = lit17 := by rw [model.app_eq 17 18 19 (by rfl), sub18, sub19]; rfl
theorem sub16 : model.term 16 = lit16 := by rw [model.lam_eq 16 17 (by rfl), sub17]; rfl
theorem sub15 : model.term 15 = lit15 := by rw [model.lam_eq 15 16 (by rfl), sub16]; rfl
theorem sub14 : model.term 14 = lit56 := model.var_eq 14 0 (by rfl)
theorem sub13 : model.term 13 = lit56 := model.var_eq 13 0 (by rfl)
theorem sub12 : model.term 12 = lit54 := model.var_eq 12 2 (by rfl)
theorem sub11 : model.term 11 = lit53 := by rw [model.app_eq 11 12 13 (by rfl), sub12, sub13]; rfl
theorem sub10 : model.term 10 = lit52 := model.var_eq 10 1 (by rfl)
theorem sub9 : model.term 9 = lit51 := by rw [model.app_eq 9 10 11 (by rfl), sub10, sub11]; rfl
theorem sub8 : model.term 8 = lit50 := by rw [model.lam_eq 8 9 (by rfl), sub9]; rfl
theorem sub7 : model.term 7 = lit49 := by rw [model.lam_eq 7 8 (by rfl), sub8]; rfl
theorem sub6 : model.term 6 = lit56 := model.var_eq 6 0 (by rfl)
theorem sub5 : model.term 5 = lit47 := by rw [model.app_eq 5 6 7 (by rfl), sub6, sub7]; rfl
theorem sub4 : model.term 4 = lit46 := by rw [model.app_eq 4 5 14 (by rfl), sub5, sub14]; rfl
theorem sub3 : model.term 3 = lit45 := by rw [model.lam_eq 3 4 (by rfl), sub4]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 15 (by rfl), sub3, sub15]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 33 (by rfl), sub2, sub33]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 45 (by rfl), sub1, sub45]; rfl
theorem excluded : ¬ IsSelfInterpreter e598354180586 := by
 intro he
 have hp : replay [[],[.left]] e598354180586 = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (rawCount he) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R598354180586
