import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e553899986542 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e553899986542 : Closed e553899986542 ∧ code e553899986542 = 2752923242094 := by decide
theorem cert_e553899986542 : check e553899986542 [[],[.under,.under]] .three = true := by decide
def e553899986554 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e553899986554 : Closed e553899986554 ∧ code e553899986554 = 2752923242106 := by decide
theorem cert_e553899986554 : check e553899986554 [[],[.under,.under]] .three = true := by decide
def e553899986742 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e553899986742 : Closed e553899986742 ∧ code e553899986742 = 2752923242294 := by decide
theorem cert_e553899986742 : check e553899986742 [[],[.under,.under]] .three = true := by decide
def e553899986746 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e553899986746 : Closed e553899986746 ∧ code e553899986746 = 2752923242298 := by decide
theorem cert_e553899986746 : check e553899986746 [[],[.under,.under]] .three = true := by decide
def e553900575598 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e553900575598 : Closed e553900575598 ∧ code e553900575598 = 2752923831150 := by decide
theorem cert_e553900575598 : check e553900575598 [[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e553900575606 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e553900575606 : Closed e553900575606 ∧ code e553900575606 = 2752923831158 := by decide
theorem cert_e553900575606 : check e553900575606 [[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e553900575662 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e553900575662 : Closed e553900575662 ∧ code e553900575662 = 2752923831214 := by decide
theorem cert_e553900575662 : check e553900575662 [[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e553900575674 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e553900575674 : Closed e553900575674 ∧ code e553900575674 = 2752923831226 := by decide
private def t_e553900575674 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e553900575674 : ¬ IsSelfInterpreter e553900575674 :=
  wSource (t := t_e553900575674) (replay_sound (ps := []) (t := e553900575674) (by decide)) (by decide)
def e553900575702 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e553900575702 : Closed e553900575702 ∧ code e553900575702 = 2752923831254 := by decide
theorem cert_e553900575702 : check e553900575702 [[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e553900575706 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e553900575706 : Closed e553900575706 ∧ code e553900575706 = 2752923831258 := by decide
private def t_e553900575706 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e553900575706 : ¬ IsSelfInterpreter e553900575706 :=
  wSource (t := t_e553900575706) (replay_sound (ps := []) (t := e553900575706) (by decide)) (by decide)
def e553900575982 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e553900575982 : Closed e553900575982 ∧ code e553900575982 = 2752923831534 := by decide
theorem cert_e553900575982 : check e553900575982 [[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e553900575990 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e553900575990 : Closed e553900575990 ∧ code e553900575990 = 2752923831542 := by decide
theorem cert_e553900575990 : check e553900575990 [[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e553900576366 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e553900576366 : Closed e553900576366 ∧ code e553900576366 = 2752923831918 := by decide
theorem cert_e553900576366 : check e553900576366 [[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e553900576378 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e553900576378 : Closed e553900576378 ∧ code e553900576378 = 2752923831930 := by decide
theorem cert_e553900576378 : check e553900576378 [[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e553900576566 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e553900576566 : Closed e553900576566 ∧ code e553900576566 = 2752923832118 := by decide
theorem cert_e553900576566 : check e553900576566 [[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e553900576570 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e553900576570 : Closed e553900576570 ∧ code e553900576570 = 2752923832122 := by decide
theorem cert_e553900576570 : check e553900576570 [[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e561614926022 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561614926022 : Closed e561614926022 ∧ code e561614926022 = 2760638181574 := by decide
theorem cert_e561614926022 : check e561614926022 [[]] .width = true := by decide
def e561615057094 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561615057094 : Closed e561615057094 ∧ code e561615057094 = 2760638312646 := by decide
theorem cert_e561615057094 : check e561615057094 [[]] .width = true := by decide
def e561615974598 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561615974598 : Closed e561615974598 ∧ code e561615974598 = 2760639230150 := by decide
theorem cert_e561615974598 : check e561615974598 [[]] .width = true := by decide
def e561616171206 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561616171206 : Closed e561616171206 ∧ code e561616171206 = 2760639426758 := by decide
theorem cert_e561616171206 : check e561616171206 [[]] .width = true := by decide
def e561616629958 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561616629958 : Closed e561616629958 ∧ code e561616629958 = 2760639885510 := by decide
theorem cert_e561616629958 : check e561616629958 [[]] .width = true := by decide
def e561616695494 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561616695494 : Closed e561616695494 ∧ code e561616695494 = 2760639951046 := by decide
theorem cert_e561616695494 : check e561616695494 [[]] .width = true := by decide
def e561621217478 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561621217478 : Closed e561621217478 ∧ code e561621217478 = 2760644473030 := by decide
theorem cert_e561621217478 : check e561621217478 [[]] .width = true := by decide
def e561621348550 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561621348550 : Closed e561621348550 ∧ code e561621348550 = 2760644604102 := by decide
theorem cert_e561621348550 : check e561621348550 [[]] .width = true := by decide
def e561627508934 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561627508934 : Closed e561627508934 ∧ code e561627508934 = 2760650764486 := by decide
theorem cert_e561627508934 : check e561627508934 [[]] .width = true := by decide
def e561627705542 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561627705542 : Closed e561627705542 ∧ code e561627705542 = 2760650961094 := by decide
theorem cert_e561627705542 : check e561627705542 [[]] .width = true := by decide
def e561630785734 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561630785734 : Closed e561630785734 ∧ code e561630785734 = 2760654041286 := by decide
theorem cert_e561630785734 : check e561630785734 [[]] .width = true := by decide
def e561630851270 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561630851270 : Closed e561630851270 ∧ code e561630851270 = 2760654106822 := by decide
theorem cert_e561630851270 : check e561630851270 [[]] .width = true := by decide
def e561975619782 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561975619782 : Closed e561975619782 ∧ code e561975619782 = 2760998875334 := by decide
theorem cert_e561975619782 : check e561975619782 [[]] .width = true := by decide
def e561975636166 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561975636166 : Closed e561975636166 ∧ code e561975636166 = 2760998891718 := by decide
theorem cert_e561975636166 : check e561975636166 [[]] .width = true := by decide
def e561975750854 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561975750854 : Closed e561975750854 ∧ code e561975750854 = 2760999006406 := by decide
theorem cert_e561975750854 : check e561975750854 [[]] .width = true := by decide
def e561975775430 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561975775430 : Closed e561975775430 ∧ code e561975775430 = 2760999030982 := by decide
theorem cert_e561975775430 : check e561975775430 [[]] .width = true := by decide
def e561975832774 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561975832774 : Closed e561975832774 ∧ code e561975832774 = 2760999088326 := by decide
theorem cert_e561975832774 : check e561975832774 [[]] .width = true := by decide
def e561975840966 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561975840966 : Closed e561975840966 ∧ code e561975840966 = 2760999096518 := by decide
theorem cert_e561975840966 : check e561975840966 [[]] .width = true := by decide
def e561976406214 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561976406214 : Closed e561976406214 ∧ code e561976406214 = 2760999661766 := by decide
theorem cert_e561976406214 : check e561976406214 [[]] .width = true := by decide
def e561976422598 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561976422598 : Closed e561976422598 ∧ code e561976422598 = 2760999678150 := by decide
theorem cert_e561976422598 : check e561976422598 [[]] .width = true := by decide
def e561977192646 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561977192646 : Closed e561977192646 ∧ code e561977192646 = 2761000448198 := by decide
theorem cert_e561977192646 : check e561977192646 [[]] .width = true := by decide
def e561977217222 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561977217222 : Closed e561977217222 ∧ code e561977217222 = 2761000472774 := by decide
theorem cert_e561977217222 : check e561977217222 [[]] .width = true := by decide
def e561977602246 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561977602246 : Closed e561977602246 ∧ code e561977602246 = 2761000857798 := by decide
theorem cert_e561977602246 : check e561977602246 [[]] .width = true := by decide
def e561977610438 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e561977610438 : Closed e561977610438 ∧ code e561977610438 = 2761000865990 := by decide
theorem cert_e561977610438 : check e561977610438 [[]] .width = true := by decide
def e562020003182 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e562020003182 : Closed e562020003182 ∧ code e562020003182 = 2761043258734 := by decide
theorem cert_e562020003182 : check e562020003182 [[]] .sourceHead = true := by decide
def e562020003190 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e562020003190 : Closed e562020003190 ∧ code e562020003190 = 2761043258742 := by decide
theorem cert_e562020003190 : check e562020003190 [[]] .sourceHead = true := by decide
def e562020003246 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e562020003246 : Closed e562020003246 ∧ code e562020003246 = 2761043258798 := by decide
theorem cert_e562020003246 : check e562020003246 [[]] .sourceHead = true := by decide
def e562020003258 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e562020003258 : Closed e562020003258 ∧ code e562020003258 = 2761043258810 := by decide
theorem cert_e562020003258 : check e562020003258 [[]] .sourceHead = true := by decide
def e562020003286 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e562020003286 : Closed e562020003286 ∧ code e562020003286 = 2761043258838 := by decide
theorem cert_e562020003286 : check e562020003286 [[]] .sourceHead = true := by decide
def e562020003290 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e562020003290 : Closed e562020003290 ∧ code e562020003290 = 2761043258842 := by decide
theorem cert_e562020003290 : check e562020003290 [[]] .sourceHead = true := by decide
def e562020003502 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e562020003502 : Closed e562020003502 ∧ code e562020003502 = 2761043259054 := by decide
theorem cert_e562020003502 : check e562020003502 [[]] .sourceHead = true := by decide
def e562020003514 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e562020003514 : Closed e562020003514 ∧ code e562020003514 = 2761043259066 := by decide
theorem cert_e562020003514 : check e562020003514 [[]] .sourceHead = true := by decide
def e562020003562 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e562020003562 : Closed e562020003562 ∧ code e562020003562 = 2761043259114 := by decide
theorem cert_e562020003562 : check e562020003562 [[]] .sourceHead = true := by decide
def e562020003670 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e562020003670 : Closed e562020003670 ∧ code e562020003670 = 2761043259222 := by decide
theorem cert_e562020003670 : check e562020003670 [[]] .sourceHead = true := by decide
def e562020003674 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e562020003674 : Closed e562020003674 ∧ code e562020003674 = 2761043259226 := by decide
theorem cert_e562020003674 : check e562020003674 [[]] .sourceHead = true := by decide
def e562020003690 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e562020003690 : Closed e562020003690 ∧ code e562020003690 = 2761043259242 := by decide
theorem cert_e562020003690 : check e562020003690 [[]] .sourceHead = true := by decide
def e562020004718 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e562020004718 : Closed e562020004718 ∧ code e562020004718 = 2761043260270 := by decide
theorem cert_e562020004718 : check e562020004718 [[]] .sourceHead = true := by decide
def e562020004726 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e562020004726 : Closed e562020004726 ∧ code e562020004726 = 2761043260278 := by decide
theorem cert_e562020004726 : check e562020004726 [[]] .sourceHead = true := by decide
def e562020004782 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e562020004782 : Closed e562020004782 ∧ code e562020004782 = 2761043260334 := by decide
theorem cert_e562020004782 : check e562020004782 [[]] .sourceHead = true := by decide
def e562020004794 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e562020004794 : Closed e562020004794 ∧ code e562020004794 = 2761043260346 := by decide
theorem cert_e562020004794 : check e562020004794 [[]] .sourceHead = true := by decide
def e562020004822 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e562020004822 : Closed e562020004822 ∧ code e562020004822 = 2761043260374 := by decide
theorem cert_e562020004822 : check e562020004822 [[]] .sourceHead = true := by decide
def e562020004826 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e562020004826 : Closed e562020004826 ∧ code e562020004826 = 2761043260378 := by decide
theorem cert_e562020004826 : check e562020004826 [[]] .sourceHead = true := by decide
def e562020005102 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e562020005102 : Closed e562020005102 ∧ code e562020005102 = 2761043260654 := by decide
theorem cert_e562020005102 : check e562020005102 [[]] .sourceHead = true := by decide
def e562020005110 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e562020005110 : Closed e562020005110 ∧ code e562020005110 = 2761043260662 := by decide
theorem cert_e562020005110 : check e562020005110 [[]] .sourceHead = true := by decide
def e562020005486 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e562020005486 : Closed e562020005486 ∧ code e562020005486 = 2761043261038 := by decide
theorem cert_e562020005486 : check e562020005486 [[]] .sourceHead = true := by decide
def e562020005498 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e562020005498 : Closed e562020005498 ∧ code e562020005498 = 2761043261050 := by decide
theorem cert_e562020005498 : check e562020005498 [[]] .sourceHead = true := by decide
def e562020005686 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e562020005686 : Closed e562020005686 ∧ code e562020005686 = 2761043261238 := by decide
theorem cert_e562020005686 : check e562020005686 [[]] .sourceHead = true := by decide
def e562020005690 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e562020005690 : Closed e562020005690 ∧ code e562020005690 = 2761043261242 := by decide
theorem cert_e562020005690 : check e562020005690 [[]] .sourceHead = true := by decide
def e562020006318 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e562020006318 : Closed e562020006318 ∧ code e562020006318 = 2761043261870 := by decide
theorem cert_e562020006318 : check e562020006318 [[]] .sourceHead = true := by decide
def e562020006330 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e562020006330 : Closed e562020006330 ∧ code e562020006330 = 2761043261882 := by decide
theorem cert_e562020006330 : check e562020006330 [[]] .sourceHead = true := by decide
def e562020006378 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e562020006378 : Closed e562020006378 ∧ code e562020006378 = 2761043261930 := by decide
theorem cert_e562020006378 : check e562020006378 [[]] .sourceHead = true := by decide
def e562020006510 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e562020006510 : Closed e562020006510 ∧ code e562020006510 = 2761043262062 := by decide
theorem cert_e562020006510 : check e562020006510 [[]] .sourceHead = true := by decide
def e562020006522 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e562020006522 : Closed e562020006522 ∧ code e562020006522 = 2761043262074 := by decide
theorem cert_e562020006522 : check e562020006522 [[]] .sourceHead = true := by decide
def e562020006810 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e562020006810 : Closed e562020006810 ∧ code e562020006810 = 2761043262362 := by decide
theorem cert_e562020006810 : check e562020006810 [[]] .sourceHead = true := by decide
def e562020007126 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e562020007126 : Closed e562020007126 ∧ code e562020007126 = 2761043262678 := by decide
theorem cert_e562020007126 : check e562020007126 [[]] .sourceHead = true := by decide
def e562020007130 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e562020007130 : Closed e562020007130 ∧ code e562020007130 = 2761043262682 := by decide
theorem cert_e562020007130 : check e562020007130 [[]] .sourceHead = true := by decide
def e562020007146 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e562020007146 : Closed e562020007146 ∧ code e562020007146 = 2761043262698 := by decide
theorem cert_e562020007146 : check e562020007146 [[]] .sourceHead = true := by decide
def e562020007222 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e562020007222 : Closed e562020007222 ∧ code e562020007222 = 2761043262774 := by decide
theorem cert_e562020007222 : check e562020007222 [[]] .sourceHead = true := by decide
def e562020007226 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e562020007226 : Closed e562020007226 ∧ code e562020007226 = 2761043262778 := by decide
theorem cert_e562020007226 : check e562020007226 [[]] .sourceHead = true := by decide
def e562020007322 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e562020007322 : Closed e562020007322 ∧ code e562020007322 = 2761043262874 := by decide
theorem cert_e562020007322 : check e562020007322 [[]] .sourceHead = true := by decide
def e562020010862 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e562020010862 : Closed e562020010862 ∧ code e562020010862 = 2761043266414 := by decide
theorem cert_e562020010862 : check e562020010862 [[]] .sourceHead = true := by decide
def e562020010870 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e562020010870 : Closed e562020010870 ∧ code e562020010870 = 2761043266422 := by decide
theorem cert_e562020010870 : check e562020010870 [[]] .sourceHead = true := by decide
def e562020010926 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e562020010926 : Closed e562020010926 ∧ code e562020010926 = 2761043266478 := by decide
theorem cert_e562020010926 : check e562020010926 [[]] .sourceHead = true := by decide
def e562020010938 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e562020010938 : Closed e562020010938 ∧ code e562020010938 = 2761043266490 := by decide
theorem cert_e562020010938 : check e562020010938 [[]] .sourceHead = true := by decide
def e562020010966 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e562020010966 : Closed e562020010966 ∧ code e562020010966 = 2761043266518 := by decide
theorem cert_e562020010966 : check e562020010966 [[]] .sourceHead = true := by decide
def e562020010970 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e562020010970 : Closed e562020010970 ∧ code e562020010970 = 2761043266522 := by decide
theorem cert_e562020010970 : check e562020010970 [[]] .sourceHead = true := by decide
def e562020011246 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e562020011246 : Closed e562020011246 ∧ code e562020011246 = 2761043266798 := by decide
theorem cert_e562020011246 : check e562020011246 [[]] .sourceHead = true := by decide
def e562020011254 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e562020011254 : Closed e562020011254 ∧ code e562020011254 = 2761043266806 := by decide
theorem cert_e562020011254 : check e562020011254 [[]] .sourceHead = true := by decide
def e562020011630 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e562020011630 : Closed e562020011630 ∧ code e562020011630 = 2761043267182 := by decide
theorem cert_e562020011630 : check e562020011630 [[]] .sourceHead = true := by decide
def e562020011642 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e562020011642 : Closed e562020011642 ∧ code e562020011642 = 2761043267194 := by decide
theorem cert_e562020011642 : check e562020011642 [[]] .sourceHead = true := by decide
def e562020011830 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e562020011830 : Closed e562020011830 ∧ code e562020011830 = 2761043267382 := by decide
theorem cert_e562020011830 : check e562020011830 [[]] .sourceHead = true := by decide
def e562020011834 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e562020011834 : Closed e562020011834 ∧ code e562020011834 = 2761043267386 := by decide
theorem cert_e562020011834 : check e562020011834 [[]] .sourceHead = true := by decide
def e562020017582 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e562020017582 : Closed e562020017582 ∧ code e562020017582 = 2761043273134 := by decide
theorem cert_e562020017582 : check e562020017582 [[]] .sourceHead = true := by decide
def e562020017594 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e562020017594 : Closed e562020017594 ∧ code e562020017594 = 2761043273146 := by decide
theorem cert_e562020017594 : check e562020017594 [[]] .sourceHead = true := by decide
def e562020017642 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e562020017642 : Closed e562020017642 ∧ code e562020017642 = 2761043273194 := by decide
theorem cert_e562020017642 : check e562020017642 [[]] .sourceHead = true := by decide
def e562020017774 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e562020017774 : Closed e562020017774 ∧ code e562020017774 = 2761043273326 := by decide
theorem cert_e562020017774 : check e562020017774 [[]] .sourceHead = true := by decide
def e562020017786 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e562020017786 : Closed e562020017786 ∧ code e562020017786 = 2761043273338 := by decide
theorem cert_e562020017786 : check e562020017786 [[]] .sourceHead = true := by decide
def e562020018074 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e562020018074 : Closed e562020018074 ∧ code e562020018074 = 2761043273626 := by decide
theorem cert_e562020018074 : check e562020018074 [[]] .sourceHead = true := by decide
def e562020020950 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e562020020950 : Closed e562020020950 ∧ code e562020020950 = 2761043276502 := by decide
theorem cert_e562020020950 : check e562020020950 [[]] .sourceHead = true := by decide
def e562020020954 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e562020020954 : Closed e562020020954 ∧ code e562020020954 = 2761043276506 := by decide
theorem cert_e562020020954 : check e562020020954 [[]] .sourceHead = true := by decide
def e562020020970 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e562020020970 : Closed e562020020970 ∧ code e562020020970 = 2761043276522 := by decide
theorem cert_e562020020970 : check e562020020970 [[]] .sourceHead = true := by decide
def e562020021046 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e562020021046 : Closed e562020021046 ∧ code e562020021046 = 2761043276598 := by decide
theorem cert_e562020021046 : check e562020021046 [[]] .sourceHead = true := by decide
def e562020021050 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e562020021050 : Closed e562020021050 ∧ code e562020021050 = 2761043276602 := by decide
theorem cert_e562020021050 : check e562020021050 [[]] .sourceHead = true := by decide
def e562020021146 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e562020021146 : Closed e562020021146 ∧ code e562020021146 = 2761043276698 := by decide
theorem cert_e562020021146 : check e562020021146 [[]] .sourceHead = true := by decide
def e562020158318 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e562020158318 : Closed e562020158318 ∧ code e562020158318 = 2761043413870 := by decide
theorem cert_e562020158318 : check e562020158318 [[]] .sourceHead = true := by decide
def e562020158326 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e562020158326 : Closed e562020158326 ∧ code e562020158326 = 2761043413878 := by decide
theorem cert_e562020158326 : check e562020158326 [[]] .sourceHead = true := by decide
def e562020158382 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e562020158382 : Closed e562020158382 ∧ code e562020158382 = 2761043413934 := by decide
theorem cert_e562020158382 : check e562020158382 [[]] .sourceHead = true := by decide
def e562020158394 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e562020158394 : Closed e562020158394 ∧ code e562020158394 = 2761043413946 := by decide
theorem cert_e562020158394 : check e562020158394 [[]] .sourceHead = true := by decide
def e562020158422 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e562020158422 : Closed e562020158422 ∧ code e562020158422 = 2761043413974 := by decide
theorem cert_e562020158422 : check e562020158422 [[]] .sourceHead = true := by decide
def e562020158426 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e562020158426 : Closed e562020158426 ∧ code e562020158426 = 2761043413978 := by decide
theorem cert_e562020158426 : check e562020158426 [[]] .sourceHead = true := by decide
def e562020158702 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e562020158702 : Closed e562020158702 ∧ code e562020158702 = 2761043414254 := by decide
theorem cert_e562020158702 : check e562020158702 [[]] .sourceHead = true := by decide
def e562020158710 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e562020158710 : Closed e562020158710 ∧ code e562020158710 = 2761043414262 := by decide
theorem cert_e562020158710 : check e562020158710 [[]] .sourceHead = true := by decide
def e562020159086 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e562020159086 : Closed e562020159086 ∧ code e562020159086 = 2761043414638 := by decide
theorem cert_e562020159086 : check e562020159086 [[]] .sourceHead = true := by decide
def e562020159098 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e562020159098 : Closed e562020159098 ∧ code e562020159098 = 2761043414650 := by decide
theorem cert_e562020159098 : check e562020159098 [[]] .sourceHead = true := by decide
def e562020159286 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e562020159286 : Closed e562020159286 ∧ code e562020159286 = 2761043414838 := by decide
theorem cert_e562020159286 : check e562020159286 [[]] .sourceHead = true := by decide
def e562020159290 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e562020159290 : Closed e562020159290 ∧ code e562020159290 = 2761043414842 := by decide
theorem cert_e562020159290 : check e562020159290 [[]] .sourceHead = true := by decide
def e562020748142 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e562020748142 : Closed e562020748142 ∧ code e562020748142 = 2761044003694 := by decide
theorem cert_e562020748142 : check e562020748142 [[]] .sourceHead = true := by decide
def e562020748150 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e562020748150 : Closed e562020748150 ∧ code e562020748150 = 2761044003702 := by decide
theorem cert_e562020748150 : check e562020748150 [[]] .sourceHead = true := by decide
def e562020748206 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e562020748206 : Closed e562020748206 ∧ code e562020748206 = 2761044003758 := by decide
theorem cert_e562020748206 : check e562020748206 [[]] .sourceHead = true := by decide
def e562020748218 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e562020748218 : Closed e562020748218 ∧ code e562020748218 = 2761044003770 := by decide
theorem cert_e562020748218 : check e562020748218 [[]] .sourceHead = true := by decide
def e562020748246 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e562020748246 : Closed e562020748246 ∧ code e562020748246 = 2761044003798 := by decide
theorem cert_e562020748246 : check e562020748246 [[]] .sourceHead = true := by decide
def e562020748250 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e562020748250 : Closed e562020748250 ∧ code e562020748250 = 2761044003802 := by decide
theorem cert_e562020748250 : check e562020748250 [[]] .sourceHead = true := by decide
def e562020748526 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e562020748526 : Closed e562020748526 ∧ code e562020748526 = 2761044004078 := by decide
theorem cert_e562020748526 : check e562020748526 [[]] .sourceHead = true := by decide
def e562020748534 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e562020748534 : Closed e562020748534 ∧ code e562020748534 = 2761044004086 := by decide
theorem cert_e562020748534 : check e562020748534 [[]] .sourceHead = true := by decide
def e562020748910 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e562020748910 : Closed e562020748910 ∧ code e562020748910 = 2761044004462 := by decide
theorem cert_e562020748910 : check e562020748910 [[]] .sourceHead = true := by decide
def e562020748922 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e562020748922 : Closed e562020748922 ∧ code e562020748922 = 2761044004474 := by decide
theorem cert_e562020748922 : check e562020748922 [[]] .sourceHead = true := by decide
def e562020749110 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e562020749110 : Closed e562020749110 ∧ code e562020749110 = 2761044004662 := by decide
theorem cert_e562020749110 : check e562020749110 [[]] .sourceHead = true := by decide
def e562020749114 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e562020749114 : Closed e562020749114 ∧ code e562020749114 = 2761044004666 := by decide
theorem cert_e562020749114 : check e562020749114 [[]] .sourceHead = true := by decide
def e562127818950 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562127818950 : Closed e562127818950 ∧ code e562127818950 = 2761151074502 := by decide
theorem cert_e562127818950 : check e562127818950 [[]] .width = true := by decide
def e562127820826 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562127820826 : Closed e562127820826 ∧ code e562127820826 = 2761151076378 := by decide
theorem cert_e562127820826 : check e562127820826 [[]] .width = true := by decide
def e562127884486 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562127884486 : Closed e562127884486 ∧ code e562127884486 = 2761151140038 := by decide
theorem cert_e562127884486 : check e562127884486 [[]] .width = true := by decide
def e562127886362 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562127886362 : Closed e562127886362 ∧ code e562127886362 = 2761151141914 := by decide
theorem cert_e562127886362 : check e562127886362 [[]] .width = true := by decide
def e562128343238 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562128343238 : Closed e562128343238 ∧ code e562128343238 = 2761151598790 := by decide
theorem cert_e562128343238 : check e562128343238 [[]] .width = true := by decide
def e562128345114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562128345114 : Closed e562128345114 ∧ code e562128345114 = 2761151600666 := by decide
theorem cert_e562128345114 : check e562128345114 [[]] .width = true := by decide
def e562128441542 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562128441542 : Closed e562128441542 ∧ code e562128441542 = 2761151697094 := by decide
theorem cert_e562128441542 : check e562128441542 [[]] .width = true := by decide
def e562128443418 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562128443418 : Closed e562128443418 ∧ code e562128443418 = 2761151698970 := by decide
theorem cert_e562128443418 : check e562128443418 [[]] .width = true := by decide
def e562128670918 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562128670918 : Closed e562128670918 ∧ code e562128670918 = 2761151926470 := by decide
theorem cert_e562128670918 : check e562128670918 [[]] .width = true := by decide
def e562128672794 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562128672794 : Closed e562128672794 ∧ code e562128672794 = 2761151928346 := by decide
theorem cert_e562128672794 : check e562128672794 [[]] .width = true := by decide
def e562128703686 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562128703686 : Closed e562128703686 ∧ code e562128703686 = 2761151959238 := by decide
theorem cert_e562128703686 : check e562128703686 [[]] .width = true := by decide
def e562128705562 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562128705562 : Closed e562128705562 ∧ code e562128705562 = 2761151961114 := by decide
theorem cert_e562128705562 : check e562128705562 [[]] .width = true := by decide
def e562130964678 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562130964678 : Closed e562130964678 ∧ code e562130964678 = 2761154220230 := by decide
theorem cert_e562130964678 : check e562130964678 [[]] .width = true := by decide
def e562130966554 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562130966554 : Closed e562130966554 ∧ code e562130966554 = 2761154222106 := by decide
theorem cert_e562130966554 : check e562130966554 [[]] .width = true := by decide
def e562131030214 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562131030214 : Closed e562131030214 ∧ code e562131030214 = 2761154285766 := by decide
theorem cert_e562131030214 : check e562131030214 [[]] .width = true := by decide
def e562131032090 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562131032090 : Closed e562131032090 ∧ code e562131032090 = 2761154287642 := by decide
theorem cert_e562131032090 : check e562131032090 [[]] .width = true := by decide
def e562134110406 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562134110406 : Closed e562134110406 ∧ code e562134110406 = 2761157365958 := by decide
theorem cert_e562134110406 : check e562134110406 [[]] .width = true := by decide
def e562134112282 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562134112282 : Closed e562134112282 ∧ code e562134112282 = 2761157367834 := by decide
theorem cert_e562134112282 : check e562134112282 [[]] .width = true := by decide
def e562134208710 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562134208710 : Closed e562134208710 ∧ code e562134208710 = 2761157464262 := by decide
theorem cert_e562134208710 : check e562134208710 [[]] .width = true := by decide
def e562134210586 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562134210586 : Closed e562134210586 ∧ code e562134210586 = 2761157466138 := by decide
theorem cert_e562134210586 : check e562134210586 [[]] .width = true := by decide
def e562135748806 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562135748806 : Closed e562135748806 ∧ code e562135748806 = 2761159004358 := by decide
theorem cert_e562135748806 : check e562135748806 [[]] .width = true := by decide
def e562135750682 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562135750682 : Closed e562135750682 ∧ code e562135750682 = 2761159006234 := by decide
theorem cert_e562135750682 : check e562135750682 [[]] .width = true := by decide
def e562135781574 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562135781574 : Closed e562135781574 ∧ code e562135781574 = 2761159037126 := by decide
theorem cert_e562135781574 : check e562135781574 [[]] .width = true := by decide
def e562135783450 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e562135783450 : Closed e562135783450 ∧ code e562135783450 = 2761159039002 := by decide
theorem cert_e562135783450 : check e562135783450 [[]] .width = true := by decide
def e562244055238 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562244055238 : Closed e562244055238 ∧ code e562244055238 = 2761267310790 := by decide
theorem cert_e562244055238 : check e562244055238 [[]] .width = true := by decide
def e562244071622 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562244071622 : Closed e562244071622 ∧ code e562244071622 = 2761267327174 := by decide
theorem cert_e562244071622 : check e562244071622 [[]] .width = true := by decide
def e562244186310 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562244186310 : Closed e562244186310 ∧ code e562244186310 = 2761267441862 := by decide
theorem cert_e562244186310 : check e562244186310 [[]] .width = true := by decide
def e562244210886 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562244210886 : Closed e562244210886 ∧ code e562244210886 = 2761267466438 := by decide
theorem cert_e562244210886 : check e562244210886 [[]] .width = true := by decide
def e562244268230 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562244268230 : Closed e562244268230 ∧ code e562244268230 = 2761267523782 := by decide
theorem cert_e562244268230 : check e562244268230 [[]] .width = true := by decide
def e562244276422 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562244276422 : Closed e562244276422 ∧ code e562244276422 = 2761267531974 := by decide
theorem cert_e562244276422 : check e562244276422 [[]] .width = true := by decide
def e562244841670 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562244841670 : Closed e562244841670 ∧ code e562244841670 = 2761268097222 := by decide
theorem cert_e562244841670 : check e562244841670 [[]] .width = true := by decide
def e562244858054 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562244858054 : Closed e562244858054 ∧ code e562244858054 = 2761268113606 := by decide
theorem cert_e562244858054 : check e562244858054 [[]] .width = true := by decide
def e562245628102 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562245628102 : Closed e562245628102 ∧ code e562245628102 = 2761268883654 := by decide
theorem cert_e562245628102 : check e562245628102 [[]] .width = true := by decide
def e562245652678 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562245652678 : Closed e562245652678 ∧ code e562245652678 = 2761268908230 := by decide
theorem cert_e562245652678 : check e562245652678 [[]] .width = true := by decide
def e562246037702 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562246037702 : Closed e562246037702 ∧ code e562246037702 = 2761269293254 := by decide
theorem cert_e562246037702 : check e562246037702 [[]] .width = true := by decide
def e562246045894 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e562246045894 : Closed e562246045894 ∧ code e562246045894 = 2761269301446 := by decide
theorem cert_e562246045894 : check e562246045894 [[]] .width = true := by decide
end Blc.Floor41
