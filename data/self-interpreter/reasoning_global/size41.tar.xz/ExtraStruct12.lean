import Extra41
import Batch044
import Batch070
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness598356004086
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u14 := Term.app u5 u0
private def u15 := Term.app u0 u5
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou0 sou6
private theorem sou14 : SO u14 := SO.app sou5 sou0
private theorem sou8 : SO u8 := SO.lam (r := u14) (g := u15) sou7 sou14 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.lam (r := u0) (g := u8) sou8 sou0 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege598356004086 : ¬ IsSelfInterpreter e598356004086 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege598356004086
end Witness598356004086
namespace Witness598356004662
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege598356004662 : ¬ IsSelfInterpreter e598356004662 := by
  intro he
  have h : replay [] e598356004662 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege598356004662
end Witness598356004662
namespace Witness598356004666
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege598356004666 : ¬ IsSelfInterpreter e598356004666 := by
  intro he
  have h : replay [] e598356004666 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege598356004666
end Witness598356004666
namespace Witness604796628410
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u0 u1
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.app u0 u4
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege604796628410 : ¬ IsSelfInterpreter e604796628410 := by
  intro he
  have h : replay [] e604796628410 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege604796628410
end Witness604796628410
namespace Witness604796628666
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u0 u1
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.app u4 u0
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege604796628666 : ¬ IsSelfInterpreter e604796628666 := by
  intro he
  have h : replay [] e604796628666 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege604796628666
end Witness604796628666
namespace Witness604796629946
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u0 u1
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou0 sou1
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u14 := Term.app u0 u4
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.var 2
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou0 sou6
private theorem sou14 : SO u14 := SO.app sou0 sou4
private theorem sou8 : SO u8 := SO.lam (r := u14) (g := u14) sou7 sou14 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.lam (r := u0) (g := u8) sou8 sou0 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := SO.app sou10 sou0
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege604796629946 : ¬ IsSelfInterpreter e604796629946 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege604796629946
end Witness604796629946
namespace Witness604796629978
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u0 u1
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou0 sou1
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u14 := Term.app u5 u0
private def u15 := Term.app u0 u5
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou0 sou6
private theorem sou14 : SO u14 := SO.app sou5 sou0
private theorem sou8 : SO u8 := SO.lam (r := u14) (g := u15) sou7 sou14 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.lam (r := u0) (g := u8) sou8 sou0 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := SO.app sou10 sou0
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege604796629978 : ¬ IsSelfInterpreter e604796629978 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege604796629978
end Witness604796629978
namespace Witness604796632282
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u0 u1
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege604796632282 : ¬ IsSelfInterpreter e604796632282 := by
  intro he
  have h : replay [] e604796632282 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege604796632282
end Witness604796632282
end Blc.Floor41
