import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e151448914902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e151448914902 : Closed e151448914902 ∧ code e151448914902 = 2350472170454 := by decide
theorem cert_e151448914902 : check e151448914902 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e151448914906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e151448914906 : Closed e151448914906 ∧ code e151448914906 = 2350472170458 := by decide
theorem cert_e151448914906 : check e151448914906 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e151448915182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e151448915182 : Closed e151448915182 ∧ code e151448915182 = 2350472170734 := by decide
theorem cert_e151448915182 : check e151448915182 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e151448915190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e151448915190 : Closed e151448915190 ∧ code e151448915190 = 2350472170742 := by decide
theorem cert_e151448915190 : check e151448915190 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e151448915566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e151448915566 : Closed e151448915566 ∧ code e151448915566 = 2350472171118 := by decide
theorem cert_e151448915566 : check e151448915566 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e151448915578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e151448915578 : Closed e151448915578 ∧ code e151448915578 = 2350472171130 := by decide
theorem cert_e151448915578 : check e151448915578 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e151448915766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e151448915766 : Closed e151448915766 ∧ code e151448915766 = 2350472171318 := by decide
theorem cert_e151448915766 : check e151448915766 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e151448915770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e151448915770 : Closed e151448915770 ∧ code e151448915770 = 2350472171322 := by decide
theorem cert_e151448915770 : check e151448915770 [[.under],[.under],[.under],[.under]] .sourceHead = true := by decide
def e151456406382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e151456406382 : Closed e151456406382 ∧ code e151456406382 = 2350479661934 := by decide
theorem cert_e151456406382 : check e151456406382 [[.under],[.under]] .chain = true := by decide
def e151456406390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e151456406390 : Closed e151456406390 ∧ code e151456406390 = 2350479661942 := by decide
theorem cert_e151456406390 : check e151456406390 [[.under],[.under]] .chain = true := by decide
def e151456406454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e151456406454 : Closed e151456406454 ∧ code e151456406454 = 2350479662006 := by decide
theorem cert_e151456406454 : check e151456406454 [[.under],[.under]] .chain = true := by decide
def e151456406894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e151456406894 : Closed e151456406894 ∧ code e151456406894 = 2350479662446 := by decide
theorem cert_e151456406894 : check e151456406894 [[.under],[.under]] .chain = true := by decide
def e151456406902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e151456406902 : Closed e151456406902 ∧ code e151456406902 = 2350479662454 := by decide
theorem cert_e151456406902 : check e151456406902 [[.under],[.under]] .chain = true := by decide
def e151456406958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e151456406958 : Closed e151456406958 ∧ code e151456406958 = 2350479662510 := by decide
theorem cert_e151456406958 : check e151456406958 [[.under],[.under]] .chain = true := by decide
def e151456406970 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e151456406970 : Closed e151456406970 ∧ code e151456406970 = 2350479662522 := by decide
theorem cert_e151456406970 : check e151456406970 [[.under],[.under]] .chain = true := by decide
def e151456406998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e151456406998 : Closed e151456406998 ∧ code e151456406998 = 2350479662550 := by decide
theorem cert_e151456406998 : check e151456406998 [[.under],[.under]] .chain = true := by decide
def e151456407002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e151456407002 : Closed e151456407002 ∧ code e151456407002 = 2350479662554 := by decide
theorem cert_e151456407002 : check e151456407002 [[.under],[.under]] .chain = true := by decide
def e151456407222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e151456407222 : Closed e151456407222 ∧ code e151456407222 = 2350479662774 := by decide
theorem cert_e151456407222 : check e151456407222 [[.under],[.under]] .chain = true := by decide
def e151456407254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e151456407254 : Closed e151456407254 ∧ code e151456407254 = 2350479662806 := by decide
theorem cert_e151456407254 : check e151456407254 [[.under],[.under]] .chain = true := by decide
def e151456407258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e151456407258 : Closed e151456407258 ∧ code e151456407258 = 2350479662810 := by decide
theorem cert_e151456407258 : check e151456407258 [[.under],[.under]] .chain = true := by decide
def e151456409454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e151456409454 : Closed e151456409454 ∧ code e151456409454 = 2350479665006 := by decide
theorem cert_e151456409454 : check e151456409454 [[.under],[.under]] .chain = true := by decide
def e151456409462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e151456409462 : Closed e151456409462 ∧ code e151456409462 = 2350479665014 := by decide
theorem cert_e151456409462 : check e151456409462 [[.under],[.under]] .chain = true := by decide
def e151456409526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e151456409526 : Closed e151456409526 ∧ code e151456409526 = 2350479665078 := by decide
theorem cert_e151456409526 : check e151456409526 [[.under],[.under]] .chain = true := by decide
def e151456410862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e151456410862 : Closed e151456410862 ∧ code e151456410862 = 2350479666414 := by decide
theorem cert_e151456410862 : check e151456410862 [[.under],[.under]] .chain = true := by decide
def e151456410870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e151456410870 : Closed e151456410870 ∧ code e151456410870 = 2350479666422 := by decide
theorem cert_e151456410870 : check e151456410870 [[.under],[.under]] .chain = true := by decide
def e151456411254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e151456411254 : Closed e151456411254 ∧ code e151456411254 = 2350479666806 := by decide
theorem cert_e151456411254 : check e151456411254 [[.under],[.under]] .chain = true := by decide
def e151456412526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e151456412526 : Closed e151456412526 ∧ code e151456412526 = 2350479668078 := by decide
theorem cert_e151456412526 : check e151456412526 [[.under],[.under]] .chain = true := by decide
def e151456412534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e151456412534 : Closed e151456412534 ∧ code e151456412534 = 2350479668086 := by decide
theorem cert_e151456412534 : check e151456412534 [[.under],[.under]] .chain = true := by decide
def e151456412590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e151456412590 : Closed e151456412590 ∧ code e151456412590 = 2350479668142 := by decide
theorem cert_e151456412590 : check e151456412590 [[.under],[.under]] .chain = true := by decide
def e151456412602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e151456412602 : Closed e151456412602 ∧ code e151456412602 = 2350479668154 := by decide
theorem cert_e151456412602 : check e151456412602 [[.under],[.under]] .chain = true := by decide
def e151456412630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e151456412630 : Closed e151456412630 ∧ code e151456412630 = 2350479668182 := by decide
theorem cert_e151456412630 : check e151456412630 [[.under],[.under]] .chain = true := by decide
def e151456412634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e151456412634 : Closed e151456412634 ∧ code e151456412634 = 2350479668186 := by decide
theorem cert_e151456412634 : check e151456412634 [[.under],[.under]] .chain = true := by decide
def e151456412910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e151456412910 : Closed e151456412910 ∧ code e151456412910 = 2350479668462 := by decide
theorem cert_e151456412910 : check e151456412910 [[.under],[.under]] .chain = true := by decide
def e151456412918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e151456412918 : Closed e151456412918 ∧ code e151456412918 = 2350479668470 := by decide
theorem cert_e151456412918 : check e151456412918 [[.under],[.under]] .chain = true := by decide
def e151456413294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e151456413294 : Closed e151456413294 ∧ code e151456413294 = 2350479668846 := by decide
theorem cert_e151456413294 : check e151456413294 [[.under],[.under]] .chain = true := by decide
def e151456413306 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e151456413306 : Closed e151456413306 ∧ code e151456413306 = 2350479668858 := by decide
theorem cert_e151456413306 : check e151456413306 [[.under],[.under]] .chain = true := by decide
def e151456413494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e151456413494 : Closed e151456413494 ∧ code e151456413494 = 2350479669046 := by decide
theorem cert_e151456413494 : check e151456413494 [[.under],[.under]] .chain = true := by decide
def e151456413498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e151456413498 : Closed e151456413498 ∧ code e151456413498 = 2350479669050 := by decide
theorem cert_e151456413498 : check e151456413498 [[.under],[.under]] .chain = true := by decide
def e151456414134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e151456414134 : Closed e151456414134 ∧ code e151456414134 = 2350479669686 := by decide
theorem cert_e151456414134 : check e151456414134 [[.under],[.under]] .chain = true := by decide
def e151456414166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e151456414166 : Closed e151456414166 ∧ code e151456414166 = 2350479669718 := by decide
theorem cert_e151456414166 : check e151456414166 [[.under],[.under]] .chain = true := by decide
def e151456414170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e151456414170 : Closed e151456414170 ∧ code e151456414170 = 2350479669722 := by decide
theorem cert_e151456414170 : check e151456414170 [[.under],[.under]] .chain = true := by decide
def e151456414326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e151456414326 : Closed e151456414326 ∧ code e151456414326 = 2350479669878 := by decide
theorem cert_e151456414326 : check e151456414326 [[.under],[.under]] .chain = true := by decide
def e151456414518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e151456414518 : Closed e151456414518 ∧ code e151456414518 = 2350479670070 := by decide
theorem cert_e151456414518 : check e151456414518 [[.under],[.under]] .chain = true := by decide
def e151456414522 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e151456414522 : Closed e151456414522 ∧ code e151456414522 = 2350479670074 := by decide
theorem cert_e151456414522 : check e151456414522 [[.under],[.under]] .chain = true := by decide
def e151456421742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e151456421742 : Closed e151456421742 ∧ code e151456421742 = 2350479677294 := by decide
theorem cert_e151456421742 : check e151456421742 [[.under],[.under]] .chain = true := by decide
def e151456421750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e151456421750 : Closed e151456421750 ∧ code e151456421750 = 2350479677302 := by decide
theorem cert_e151456421750 : check e151456421750 [[.under],[.under]] .chain = true := by decide
def e151456421814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e151456421814 : Closed e151456421814 ∧ code e151456421814 = 2350479677366 := by decide
theorem cert_e151456421814 : check e151456421814 [[.under],[.under]] .chain = true := by decide
def e151456423150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e151456423150 : Closed e151456423150 ∧ code e151456423150 = 2350479678702 := by decide
theorem cert_e151456423150 : check e151456423150 [[.under],[.under]] .chain = true := by decide
def e151456423158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e151456423158 : Closed e151456423158 ∧ code e151456423158 = 2350479678710 := by decide
theorem cert_e151456423158 : check e151456423158 [[.under],[.under]] .chain = true := by decide
def e151456423542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e151456423542 : Closed e151456423542 ∧ code e151456423542 = 2350479679094 := by decide
theorem cert_e151456423542 : check e151456423542 [[.under],[.under]] .chain = true := by decide
def e151456435054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e151456435054 : Closed e151456435054 ∧ code e151456435054 = 2350479690606 := by decide
theorem cert_e151456435054 : check e151456435054 [[.under],[.under]] .chain = true := by decide
def e151456435062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e151456435062 : Closed e151456435062 ∧ code e151456435062 = 2350479690614 := by decide
theorem cert_e151456435062 : check e151456435062 [[.under],[.under]] .chain = true := by decide
def e151456435118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e151456435118 : Closed e151456435118 ∧ code e151456435118 = 2350479690670 := by decide
theorem cert_e151456435118 : check e151456435118 [[.under],[.under]] .chain = true := by decide
def e151456435130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e151456435130 : Closed e151456435130 ∧ code e151456435130 = 2350479690682 := by decide
theorem cert_e151456435130 : check e151456435130 [[.under],[.under]] .chain = true := by decide
def e151456435158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e151456435158 : Closed e151456435158 ∧ code e151456435158 = 2350479690710 := by decide
theorem cert_e151456435158 : check e151456435158 [[.under],[.under]] .chain = true := by decide
def e151456435162 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e151456435162 : Closed e151456435162 ∧ code e151456435162 = 2350479690714 := by decide
theorem cert_e151456435162 : check e151456435162 [[.under],[.under]] .chain = true := by decide
def e151456435438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e151456435438 : Closed e151456435438 ∧ code e151456435438 = 2350479690990 := by decide
theorem cert_e151456435438 : check e151456435438 [[.under],[.under]] .chain = true := by decide
def e151456435446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e151456435446 : Closed e151456435446 ∧ code e151456435446 = 2350479690998 := by decide
theorem cert_e151456435446 : check e151456435446 [[.under],[.under]] .chain = true := by decide
def e151456435822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e151456435822 : Closed e151456435822 ∧ code e151456435822 = 2350479691374 := by decide
theorem cert_e151456435822 : check e151456435822 [[.under],[.under]] .chain = true := by decide
def e151456435834 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e151456435834 : Closed e151456435834 ∧ code e151456435834 = 2350479691386 := by decide
theorem cert_e151456435834 : check e151456435834 [[.under],[.under]] .chain = true := by decide
def e151456436022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e151456436022 : Closed e151456436022 ∧ code e151456436022 = 2350479691574 := by decide
theorem cert_e151456436022 : check e151456436022 [[.under],[.under]] .chain = true := by decide
def e151456436026 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e151456436026 : Closed e151456436026 ∧ code e151456436026 = 2350479691578 := by decide
theorem cert_e151456436026 : check e151456436026 [[.under],[.under]] .chain = true := by decide
def e151456441782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e151456441782 : Closed e151456441782 ∧ code e151456441782 = 2350479697334 := by decide
theorem cert_e151456441782 : check e151456441782 [[.under],[.under]] .chain = true := by decide
def e151456441814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e151456441814 : Closed e151456441814 ∧ code e151456441814 = 2350479697366 := by decide
theorem cert_e151456441814 : check e151456441814 [[.under],[.under]] .chain = true := by decide
def e151456441818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e151456441818 : Closed e151456441818 ∧ code e151456441818 = 2350479697370 := by decide
theorem cert_e151456441818 : check e151456441818 [[.under],[.under]] .chain = true := by decide
def e151456441974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e151456441974 : Closed e151456441974 ∧ code e151456441974 = 2350479697526 := by decide
theorem cert_e151456441974 : check e151456441974 [[.under],[.under]] .chain = true := by decide
def e151456442166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e151456442166 : Closed e151456442166 ∧ code e151456442166 = 2350479697718 := by decide
theorem cert_e151456442166 : check e151456442166 [[.under],[.under]] .chain = true := by decide
def e151456442170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e151456442170 : Closed e151456442170 ∧ code e151456442170 = 2350479697722 := by decide
theorem cert_e151456442170 : check e151456442170 [[.under],[.under]] .chain = true := by decide
def e151456779118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e151456779118 : Closed e151456779118 ∧ code e151456779118 = 2350480034670 := by decide
theorem cert_e151456779118 : check e151456779118 [[.under],[.under]] .sourceHead = true := by decide
def e151456779126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e151456779126 : Closed e151456779126 ∧ code e151456779126 = 2350480034678 := by decide
theorem cert_e151456779126 : check e151456779126 [[.under],[.under]] .sourceHead = true := by decide
def e151456779182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e151456779182 : Closed e151456779182 ∧ code e151456779182 = 2350480034734 := by decide
theorem cert_e151456779182 : check e151456779182 [[.under],[.under]] .sourceHead = true := by decide
def e151456779194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e151456779194 : Closed e151456779194 ∧ code e151456779194 = 2350480034746 := by decide
theorem cert_e151456779194 : check e151456779194 [[.under],[.under]] .sourceHead = true := by decide
def e151456779222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e151456779222 : Closed e151456779222 ∧ code e151456779222 = 2350480034774 := by decide
theorem cert_e151456779222 : check e151456779222 [[.under],[.under]] .sourceHead = true := by decide
def e151456779226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e151456779226 : Closed e151456779226 ∧ code e151456779226 = 2350480034778 := by decide
theorem cert_e151456779226 : check e151456779226 [[.under],[.under]] .sourceHead = true := by decide
def e151456779502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e151456779502 : Closed e151456779502 ∧ code e151456779502 = 2350480035054 := by decide
theorem cert_e151456779502 : check e151456779502 [[.under],[.under]] .sourceHead = true := by decide
def e151456779510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e151456779510 : Closed e151456779510 ∧ code e151456779510 = 2350480035062 := by decide
theorem cert_e151456779510 : check e151456779510 [[.under],[.under]] .sourceHead = true := by decide
def e151456779886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e151456779886 : Closed e151456779886 ∧ code e151456779886 = 2350480035438 := by decide
theorem cert_e151456779886 : check e151456779886 [[.under],[.under]] .sourceHead = true := by decide
def e151456779898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e151456779898 : Closed e151456779898 ∧ code e151456779898 = 2350480035450 := by decide
theorem cert_e151456779898 : check e151456779898 [[.under],[.under]] .sourceHead = true := by decide
def e151456780086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e151456780086 : Closed e151456780086 ∧ code e151456780086 = 2350480035638 := by decide
theorem cert_e151456780086 : check e151456780086 [[.under],[.under]] .sourceHead = true := by decide
def e151456780090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e151456780090 : Closed e151456780090 ∧ code e151456780090 = 2350480035642 := by decide
theorem cert_e151456780090 : check e151456780090 [[.under],[.under]] .sourceHead = true := by decide
def e151598968174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e151598968174 : Closed e151598968174 ∧ code e151598968174 = 2350622223726 := by decide
theorem cert_e151598968174 : check e151598968174 [[.under]] .sourceHead = true := by decide
def e151598968182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e151598968182 : Closed e151598968182 ∧ code e151598968182 = 2350622223734 := by decide
theorem cert_e151598968182 : check e151598968182 [[.under]] .sourceHead = true := by decide
def e151598968238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e151598968238 : Closed e151598968238 ∧ code e151598968238 = 2350622223790 := by decide
theorem cert_e151598968238 : check e151598968238 [[.under]] .sourceHead = true := by decide
def e151598968250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e151598968250 : Closed e151598968250 ∧ code e151598968250 = 2350622223802 := by decide
theorem cert_e151598968250 : check e151598968250 [[.under]] .sourceHead = true := by decide
def e151598968278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e151598968278 : Closed e151598968278 ∧ code e151598968278 = 2350622223830 := by decide
theorem cert_e151598968278 : check e151598968278 [[.under]] .sourceHead = true := by decide
def e151598968282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e151598968282 : Closed e151598968282 ∧ code e151598968282 = 2350622223834 := by decide
theorem cert_e151598968282 : check e151598968282 [[.under]] .sourceHead = true := by decide
def e151598968494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e151598968494 : Closed e151598968494 ∧ code e151598968494 = 2350622224046 := by decide
theorem cert_e151598968494 : check e151598968494 [[.under]] .sourceHead = true := by decide
def e151598968506 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e151598968506 : Closed e151598968506 ∧ code e151598968506 = 2350622224058 := by decide
theorem cert_e151598968506 : check e151598968506 [[.under]] .sourceHead = true := by decide
def e151598968554 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e151598968554 : Closed e151598968554 ∧ code e151598968554 = 2350622224106 := by decide
theorem cert_e151598968554 : check e151598968554 [[.under]] .sourceHead = true := by decide
def e151598968662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e151598968662 : Closed e151598968662 ∧ code e151598968662 = 2350622224214 := by decide
theorem cert_e151598968662 : check e151598968662 [[.under]] .sourceHead = true := by decide
def e151598968666 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e151598968666 : Closed e151598968666 ∧ code e151598968666 = 2350622224218 := by decide
theorem cert_e151598968666 : check e151598968666 [[.under]] .sourceHead = true := by decide
def e151598968682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e151598968682 : Closed e151598968682 ∧ code e151598968682 = 2350622224234 := by decide
theorem cert_e151598968682 : check e151598968682 [[.under]] .sourceHead = true := by decide
def e151598969710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e151598969710 : Closed e151598969710 ∧ code e151598969710 = 2350622225262 := by decide
theorem cert_e151598969710 : check e151598969710 [[.under]] .sourceHead = true := by decide
def e151598969718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e151598969718 : Closed e151598969718 ∧ code e151598969718 = 2350622225270 := by decide
theorem cert_e151598969718 : check e151598969718 [[.under]] .sourceHead = true := by decide
def e151598969774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e151598969774 : Closed e151598969774 ∧ code e151598969774 = 2350622225326 := by decide
theorem cert_e151598969774 : check e151598969774 [[.under]] .sourceHead = true := by decide
def e151598969786 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e151598969786 : Closed e151598969786 ∧ code e151598969786 = 2350622225338 := by decide
theorem cert_e151598969786 : check e151598969786 [[.under]] .sourceHead = true := by decide
def e151598969814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e151598969814 : Closed e151598969814 ∧ code e151598969814 = 2350622225366 := by decide
theorem cert_e151598969814 : check e151598969814 [[.under]] .sourceHead = true := by decide
def e151598969818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e151598969818 : Closed e151598969818 ∧ code e151598969818 = 2350622225370 := by decide
theorem cert_e151598969818 : check e151598969818 [[.under]] .sourceHead = true := by decide
def e151598970094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e151598970094 : Closed e151598970094 ∧ code e151598970094 = 2350622225646 := by decide
theorem cert_e151598970094 : check e151598970094 [[.under]] .sourceHead = true := by decide
def e151598970102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e151598970102 : Closed e151598970102 ∧ code e151598970102 = 2350622225654 := by decide
theorem cert_e151598970102 : check e151598970102 [[.under]] .sourceHead = true := by decide
def e151598970478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e151598970478 : Closed e151598970478 ∧ code e151598970478 = 2350622226030 := by decide
theorem cert_e151598970478 : check e151598970478 [[.under]] .sourceHead = true := by decide
def e151598970490 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e151598970490 : Closed e151598970490 ∧ code e151598970490 = 2350622226042 := by decide
theorem cert_e151598970490 : check e151598970490 [[.under]] .sourceHead = true := by decide
def e151598970678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e151598970678 : Closed e151598970678 ∧ code e151598970678 = 2350622226230 := by decide
theorem cert_e151598970678 : check e151598970678 [[.under]] .sourceHead = true := by decide
def e151598970682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e151598970682 : Closed e151598970682 ∧ code e151598970682 = 2350622226234 := by decide
theorem cert_e151598970682 : check e151598970682 [[.under]] .sourceHead = true := by decide
def e151598971310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e151598971310 : Closed e151598971310 ∧ code e151598971310 = 2350622226862 := by decide
theorem cert_e151598971310 : check e151598971310 [[.under]] .sourceHead = true := by decide
def e151598971322 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e151598971322 : Closed e151598971322 ∧ code e151598971322 = 2350622226874 := by decide
theorem cert_e151598971322 : check e151598971322 [[.under]] .sourceHead = true := by decide
def e151598971370 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e151598971370 : Closed e151598971370 ∧ code e151598971370 = 2350622226922 := by decide
theorem cert_e151598971370 : check e151598971370 [[.under]] .sourceHead = true := by decide
def e151598971502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e151598971502 : Closed e151598971502 ∧ code e151598971502 = 2350622227054 := by decide
theorem cert_e151598971502 : check e151598971502 [[.under]] .sourceHead = true := by decide
def e151598971514 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e151598971514 : Closed e151598971514 ∧ code e151598971514 = 2350622227066 := by decide
theorem cert_e151598971514 : check e151598971514 [[.under]] .sourceHead = true := by decide
def e151598971802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e151598971802 : Closed e151598971802 ∧ code e151598971802 = 2350622227354 := by decide
theorem cert_e151598971802 : check e151598971802 [[.under]] .sourceHead = true := by decide
def e151598972118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e151598972118 : Closed e151598972118 ∧ code e151598972118 = 2350622227670 := by decide
theorem cert_e151598972118 : check e151598972118 [[.under]] .sourceHead = true := by decide
def e151598972122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e151598972122 : Closed e151598972122 ∧ code e151598972122 = 2350622227674 := by decide
theorem cert_e151598972122 : check e151598972122 [[.under]] .sourceHead = true := by decide
def e151598972138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e151598972138 : Closed e151598972138 ∧ code e151598972138 = 2350622227690 := by decide
theorem cert_e151598972138 : check e151598972138 [[.under]] .sourceHead = true := by decide
def e151598972214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e151598972214 : Closed e151598972214 ∧ code e151598972214 = 2350622227766 := by decide
theorem cert_e151598972214 : check e151598972214 [[.under]] .sourceHead = true := by decide
def e151598972218 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e151598972218 : Closed e151598972218 ∧ code e151598972218 = 2350622227770 := by decide
theorem cert_e151598972218 : check e151598972218 [[.under]] .sourceHead = true := by decide
def e151598972314 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e151598972314 : Closed e151598972314 ∧ code e151598972314 = 2350622227866 := by decide
theorem cert_e151598972314 : check e151598972314 [[.under]] .sourceHead = true := by decide
def e151598975854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e151598975854 : Closed e151598975854 ∧ code e151598975854 = 2350622231406 := by decide
theorem cert_e151598975854 : check e151598975854 [[.under]] .sourceHead = true := by decide
def e151598975862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e151598975862 : Closed e151598975862 ∧ code e151598975862 = 2350622231414 := by decide
theorem cert_e151598975862 : check e151598975862 [[.under]] .sourceHead = true := by decide
def e151598975918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e151598975918 : Closed e151598975918 ∧ code e151598975918 = 2350622231470 := by decide
theorem cert_e151598975918 : check e151598975918 [[.under]] .sourceHead = true := by decide
def e151598975930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e151598975930 : Closed e151598975930 ∧ code e151598975930 = 2350622231482 := by decide
theorem cert_e151598975930 : check e151598975930 [[.under]] .sourceHead = true := by decide
def e151598975958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e151598975958 : Closed e151598975958 ∧ code e151598975958 = 2350622231510 := by decide
theorem cert_e151598975958 : check e151598975958 [[.under]] .sourceHead = true := by decide
def e151598975962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e151598975962 : Closed e151598975962 ∧ code e151598975962 = 2350622231514 := by decide
theorem cert_e151598975962 : check e151598975962 [[.under]] .sourceHead = true := by decide
def e151598976238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e151598976238 : Closed e151598976238 ∧ code e151598976238 = 2350622231790 := by decide
theorem cert_e151598976238 : check e151598976238 [[.under]] .sourceHead = true := by decide
def e151598976246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e151598976246 : Closed e151598976246 ∧ code e151598976246 = 2350622231798 := by decide
theorem cert_e151598976246 : check e151598976246 [[.under]] .sourceHead = true := by decide
def e151598976622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e151598976622 : Closed e151598976622 ∧ code e151598976622 = 2350622232174 := by decide
theorem cert_e151598976622 : check e151598976622 [[.under]] .sourceHead = true := by decide
def e151598976634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e151598976634 : Closed e151598976634 ∧ code e151598976634 = 2350622232186 := by decide
theorem cert_e151598976634 : check e151598976634 [[.under]] .sourceHead = true := by decide
def e151598976822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e151598976822 : Closed e151598976822 ∧ code e151598976822 = 2350622232374 := by decide
theorem cert_e151598976822 : check e151598976822 [[.under]] .sourceHead = true := by decide
def e151598976826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e151598976826 : Closed e151598976826 ∧ code e151598976826 = 2350622232378 := by decide
theorem cert_e151598976826 : check e151598976826 [[.under]] .sourceHead = true := by decide
def e151598982574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e151598982574 : Closed e151598982574 ∧ code e151598982574 = 2350622238126 := by decide
theorem cert_e151598982574 : check e151598982574 [[.under]] .sourceHead = true := by decide
def e151598982586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e151598982586 : Closed e151598982586 ∧ code e151598982586 = 2350622238138 := by decide
theorem cert_e151598982586 : check e151598982586 [[.under]] .sourceHead = true := by decide
def e151598982634 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e151598982634 : Closed e151598982634 ∧ code e151598982634 = 2350622238186 := by decide
theorem cert_e151598982634 : check e151598982634 [[.under]] .sourceHead = true := by decide
def e151598982766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e151598982766 : Closed e151598982766 ∧ code e151598982766 = 2350622238318 := by decide
theorem cert_e151598982766 : check e151598982766 [[.under]] .sourceHead = true := by decide
def e151598982778 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e151598982778 : Closed e151598982778 ∧ code e151598982778 = 2350622238330 := by decide
theorem cert_e151598982778 : check e151598982778 [[.under]] .sourceHead = true := by decide
def e151598983066 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e151598983066 : Closed e151598983066 ∧ code e151598983066 = 2350622238618 := by decide
theorem cert_e151598983066 : check e151598983066 [[.under]] .sourceHead = true := by decide
def e151598985942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e151598985942 : Closed e151598985942 ∧ code e151598985942 = 2350622241494 := by decide
theorem cert_e151598985942 : check e151598985942 [[.under]] .sourceHead = true := by decide
def e151598985946 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e151598985946 : Closed e151598985946 ∧ code e151598985946 = 2350622241498 := by decide
theorem cert_e151598985946 : check e151598985946 [[.under]] .sourceHead = true := by decide
def e151598985962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e151598985962 : Closed e151598985962 ∧ code e151598985962 = 2350622241514 := by decide
theorem cert_e151598985962 : check e151598985962 [[.under]] .sourceHead = true := by decide
def e151598986038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e151598986038 : Closed e151598986038 ∧ code e151598986038 = 2350622241590 := by decide
theorem cert_e151598986038 : check e151598986038 [[.under]] .sourceHead = true := by decide
def e151598986042 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e151598986042 : Closed e151598986042 ∧ code e151598986042 = 2350622241594 := by decide
theorem cert_e151598986042 : check e151598986042 [[.under]] .sourceHead = true := by decide
def e151598986138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e151598986138 : Closed e151598986138 ∧ code e151598986138 = 2350622241690 := by decide
theorem cert_e151598986138 : check e151598986138 [[.under]] .sourceHead = true := by decide
def e151599101678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e151599101678 : Closed e151599101678 ∧ code e151599101678 = 2350622357230 := by decide
theorem cert_e151599101678 : check e151599101678 [[.under]] .sourceHead = true := by decide
def e151599101806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e151599101806 : Closed e151599101806 ∧ code e151599101806 = 2350622357358 := by decide
theorem cert_e151599101806 : check e151599101806 [[.under]] .sourceHead = true := by decide
def e151599101814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e151599101814 : Closed e151599101814 ∧ code e151599101814 = 2350622357366 := by decide
theorem cert_e151599101814 : check e151599101814 [[.under]] .sourceHead = true := by decide
def e151599102702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e151599102702 : Closed e151599102702 ∧ code e151599102702 = 2350622358254 := by decide
theorem cert_e151599102702 : check e151599102702 [[.under]] .sourceHead = true := by decide
def e151599102894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e151599102894 : Closed e151599102894 ∧ code e151599102894 = 2350622358446 := by decide
theorem cert_e151599102894 : check e151599102894 [[.under]] .sourceHead = true := by decide
def e151599102906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e151599102906 : Closed e151599102906 ∧ code e151599102906 = 2350622358458 := by decide
theorem cert_e151599102906 : check e151599102906 [[.under]] .sourceHead = true := by decide
def e151599103342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e151599103342 : Closed e151599103342 ∧ code e151599103342 = 2350622358894 := by decide
theorem cert_e151599103342 : check e151599103342 [[.under]] .sourceHead = true := by decide
def e151599103350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e151599103350 : Closed e151599103350 ∧ code e151599103350 = 2350622358902 := by decide
theorem cert_e151599103350 : check e151599103350 [[.under]] .sourceHead = true := by decide
def e151599103406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e151599103406 : Closed e151599103406 ∧ code e151599103406 = 2350622358958 := by decide
theorem cert_e151599103406 : check e151599103406 [[.under]] .sourceHead = true := by decide
def e151599103418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e151599103418 : Closed e151599103418 ∧ code e151599103418 = 2350622358970 := by decide
theorem cert_e151599103418 : check e151599103418 [[.under]] .sourceHead = true := by decide
def e151599103446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e151599103446 : Closed e151599103446 ∧ code e151599103446 = 2350622358998 := by decide
theorem cert_e151599103446 : check e151599103446 [[.under]] .sourceHead = true := by decide
def e151599103450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e151599103450 : Closed e151599103450 ∧ code e151599103450 = 2350622359002 := by decide
theorem cert_e151599103450 : check e151599103450 [[.under]] .sourceHead = true := by decide
def e151599107822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e151599107822 : Closed e151599107822 ∧ code e151599107822 = 2350622363374 := by decide
theorem cert_e151599107822 : check e151599107822 [[.under]] .sourceHead = true := by decide
def e151599107950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e151599107950 : Closed e151599107950 ∧ code e151599107950 = 2350622363502 := by decide
theorem cert_e151599107950 : check e151599107950 [[.under]] .sourceHead = true := by decide
def e151599107958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e151599107958 : Closed e151599107958 ∧ code e151599107958 = 2350622363510 := by decide
theorem cert_e151599107958 : check e151599107958 [[.under]] .sourceHead = true := by decide
def e151599110638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e151599110638 : Closed e151599110638 ∧ code e151599110638 = 2350622366190 := by decide
theorem cert_e151599110638 : check e151599110638 [[.under]] .sourceHead = true := by decide
def e151599111406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e151599111406 : Closed e151599111406 ∧ code e151599111406 = 2350622366958 := by decide
theorem cert_e151599111406 : check e151599111406 [[.under]] .sourceHead = true := by decide
def e151599111414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e151599111414 : Closed e151599111414 ∧ code e151599111414 = 2350622366966 := by decide
theorem cert_e151599111414 : check e151599111414 [[.under]] .sourceHead = true := by decide
def e151599113966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e151599113966 : Closed e151599113966 ∧ code e151599113966 = 2350622369518 := by decide
theorem cert_e151599113966 : check e151599113966 [[.under]] .sourceHead = true := by decide
def e151599114158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e151599114158 : Closed e151599114158 ∧ code e151599114158 = 2350622369710 := by decide
theorem cert_e151599114158 : check e151599114158 [[.under]] .sourceHead = true := by decide
end Blc.Floor41
