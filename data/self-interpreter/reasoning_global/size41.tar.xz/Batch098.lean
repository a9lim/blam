import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605601761006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e605601761006 : Closed e605601761006 ∧ code e605601761006 = 2804625016558 := by decide
theorem cert_e605601761006 : check e605601761006 [[],[]] .chain = true := by decide
def e605601761014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))) (.var 1))))))
theorem wire_e605601761014 : Closed e605601761014 ∧ code e605601761014 = 2804625016566 := by decide
theorem cert_e605601761014 : check e605601761014 [[],[]] .chain = true := by decide
def e605601761134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e605601761134 : Closed e605601761134 ∧ code e605601761134 = 2804625016686 := by decide
theorem cert_e605601761134 : check e605601761134 [[],[]] .chain = true := by decide
def e605601761146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e605601761146 : Closed e605601761146 ∧ code e605601761146 = 2804625016698 := by decide
theorem cert_e605601761146 : check e605601761146 [[],[]] .chain = true := by decide
def e605601761198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e605601761198 : Closed e605601761198 ∧ code e605601761198 = 2804625016750 := by decide
theorem cert_e605601761198 : check e605601761198 [[],[]] .chain = true := by decide
def e605601761238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))) (.var 1))))))
theorem wire_e605601761238 : Closed e605601761238 ∧ code e605601761238 = 2804625016790 := by decide
theorem cert_e605601761238 : check e605601761238 [[],[]] .chain = true := by decide
def e605601761242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e605601761242 : Closed e605601761242 ∧ code e605601761242 = 2804625016794 := by decide
theorem cert_e605601761242 : check e605601761242 [[],[]] .chain = true := by decide
def e605601761774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e605601761774 : Closed e605601761774 ∧ code e605601761774 = 2804625017326 := by decide
theorem cert_e605601761774 : check e605601761774 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601762542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e605601762542 : Closed e605601762542 ∧ code e605601762542 = 2804625018094 := by decide
theorem cert_e605601762542 : check e605601762542 [[],[]] .chain = true := by decide
def e605601762550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e605601762550 : Closed e605601762550 ∧ code e605601762550 = 2804625018102 := by decide
theorem cert_e605601762550 : check e605601762550 [[],[]] .chain = true := by decide
def e605601762926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e605601762926 : Closed e605601762926 ∧ code e605601762926 = 2804625018478 := by decide
theorem cert_e605601762926 : check e605601762926 [[],[]] .chain = true := by decide
def e605601762938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e605601762938 : Closed e605601762938 ∧ code e605601762938 = 2804625018490 := by decide
theorem cert_e605601762938 : check e605601762938 [[],[]] .chain = true := by decide
def e605601763102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 3)))))))
theorem wire_e605601763102 : Closed e605601763102 ∧ code e605601763102 = 2804625018654 := by decide
theorem cert_e605601763102 : check e605601763102 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601763126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601763126 : Closed e605601763126 ∧ code e605601763126 = 2804625018678 := by decide
theorem cert_e605601763126 : check e605601763126 [[],[]] .chain = true := by decide
def e605601763130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601763130 : Closed e605601763130 ∧ code e605601763130 = 2804625018682 := by decide
theorem cert_e605601763130 : check e605601763130 [[],[]] .chain = true := by decide
def e605601765038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e605601765038 : Closed e605601765038 ∧ code e605601765038 = 2804625020590 := by decide
theorem cert_e605601765038 : check e605601765038 [[],[]] .chain = true := by decide
def e605601765050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e605601765050 : Closed e605601765050 ∧ code e605601765050 = 2804625020602 := by decide
theorem cert_e605601765050 : check e605601765050 [[],[]] .chain = true := by decide
def e605601765098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e605601765098 : Closed e605601765098 ∧ code e605601765098 = 2804625020650 := by decide
theorem cert_e605601765098 : check e605601765098 [[],[]] .chain = true := by decide
def e605601765290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e605601765290 : Closed e605601765290 ∧ code e605601765290 = 2804625020842 := by decide
theorem cert_e605601765290 : check e605601765290 [[],[]] .chain = true := by decide
def e605601765422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e605601765422 : Closed e605601765422 ∧ code e605601765422 = 2804625020974 := by decide
theorem cert_e605601765422 : check e605601765422 [[],[]] .chain = true := by decide
def e605601765614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e605601765614 : Closed e605601765614 ∧ code e605601765614 = 2804625021166 := by decide
theorem cert_e605601765614 : check e605601765614 [[],[]] .chain = true := by decide
def e605601765622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e605601765622 : Closed e605601765622 ∧ code e605601765622 = 2804625021174 := by decide
theorem cert_e605601765622 : check e605601765622 [[],[]] .chain = true := by decide
def e605601765806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e605601765806 : Closed e605601765806 ∧ code e605601765806 = 2804625021358 := by decide
theorem cert_e605601765806 : check e605601765806 [[],[]] .chain = true := by decide
def e605601765818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e605601765818 : Closed e605601765818 ∧ code e605601765818 = 2804625021370 := by decide
theorem cert_e605601765818 : check e605601765818 [[],[]] .chain = true := by decide
def e605601765866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e605601765866 : Closed e605601765866 ∧ code e605601765866 = 2804625021418 := by decide
theorem cert_e605601765866 : check e605601765866 [[],[]] .chain = true := by decide
def e605601765998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e605601765998 : Closed e605601765998 ∧ code e605601765998 = 2804625021550 := by decide
theorem cert_e605601765998 : check e605601765998 [[],[]] .chain = true := by decide
def e605601766010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e605601766010 : Closed e605601766010 ∧ code e605601766010 = 2804625021562 := by decide
theorem cert_e605601766010 : check e605601766010 [[],[]] .chain = true := by decide
def e605601766174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e605601766174 : Closed e605601766174 ∧ code e605601766174 = 2804625021726 := by decide
theorem cert_e605601766174 : check e605601766174 [[],[]] .chain = true := by decide
def e605601766274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e605601766274 : Closed e605601766274 ∧ code e605601766274 = 2804625021826 := by decide
theorem cert_e605601766274 : check e605601766274 [[],[]] .chain = true := by decide
def e605601766286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e605601766286 : Closed e605601766286 ∧ code e605601766286 = 2804625021838 := by decide
theorem cert_e605601766286 : check e605601766286 [[],[]] .chain = true := by decide
def e605601766298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601766298 : Closed e605601766298 ∧ code e605601766298 = 2804625021850 := by decide
theorem cert_e605601766298 : check e605601766298 [[],[]] .chain = true := by decide
def e605601766510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e605601766510 : Closed e605601766510 ∧ code e605601766510 = 2804625022062 := by decide
theorem cert_e605601766510 : check e605601766510 [[],[]] .chain = true := by decide
def e605601766522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e605601766522 : Closed e605601766522 ∧ code e605601766522 = 2804625022074 := by decide
theorem cert_e605601766522 : check e605601766522 [[],[]] .chain = true := by decide
def e605601766686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e605601766686 : Closed e605601766686 ∧ code e605601766686 = 2804625022238 := by decide
theorem cert_e605601766686 : check e605601766686 [[],[]] .chain = true := by decide
def e605601766854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e605601766854 : Closed e605601766854 ∧ code e605601766854 = 2804625022406 := by decide
theorem cert_e605601766854 : check e605601766854 [[],[]] .chain = true := by decide
def e605601766922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e605601766922 : Closed e605601766922 ∧ code e605601766922 = 2804625022474 := by decide
theorem cert_e605601766922 : check e605601766922 [[],[]] .chain = true := by decide
def e605601766958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 2))))))
theorem wire_e605601766958 : Closed e605601766958 ∧ code e605601766958 = 2804625022510 := by decide
theorem cert_e605601766958 : check e605601766958 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601766966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e605601766966 : Closed e605601766966 ∧ code e605601766966 = 2804625022518 := by decide
theorem cert_e605601766966 : check e605601766966 [[],[]] .chain = true := by decide
def e605601766970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e605601766970 : Closed e605601766970 ∧ code e605601766970 = 2804625022522 := by decide
theorem cert_e605601766970 : check e605601766970 [[],[]] .chain = true := by decide
def e605601767018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e605601767018 : Closed e605601767018 ∧ code e605601767018 = 2804625022570 := by decide
theorem cert_e605601767018 : check e605601767018 [[],[]] .chain = true := by decide
def e605601767042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e605601767042 : Closed e605601767042 ∧ code e605601767042 = 2804625022594 := by decide
theorem cert_e605601767042 : check e605601767042 [[],[]] .chain = true := by decide
def e605601767054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e605601767054 : Closed e605601767054 ∧ code e605601767054 = 2804625022606 := by decide
theorem cert_e605601767054 : check e605601767054 [[],[]] .chain = true := by decide
def e605601767066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601767066 : Closed e605601767066 ∧ code e605601767066 = 2804625022618 := by decide
theorem cert_e605601767066 : check e605601767066 [[],[]] .chain = true := by decide
def e605601767110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e605601767110 : Closed e605601767110 ∧ code e605601767110 = 2804625022662 := by decide
theorem cert_e605601767110 : check e605601767110 [[],[]] .chain = true := by decide
def e605601767138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.lam (.var 0)))))))
theorem wire_e605601767138 : Closed e605601767138 ∧ code e605601767138 = 2804625022690 := by decide
theorem cert_e605601767138 : check e605601767138 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601767150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 2))))))
theorem wire_e605601767150 : Closed e605601767150 ∧ code e605601767150 = 2804625022702 := by decide
theorem cert_e605601767150 : check e605601767150 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601767902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e605601767902 : Closed e605601767902 ∧ code e605601767902 = 2804625023454 := by decide
theorem cert_e605601767902 : check e605601767902 [[],[]] .chain = true := by decide
def e605601767926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e605601767926 : Closed e605601767926 ∧ code e605601767926 = 2804625023478 := by decide
theorem cert_e605601767926 : check e605601767926 [[],[]] .chain = true := by decide
def e605601768878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e605601768878 : Closed e605601768878 ∧ code e605601768878 = 2804625024430 := by decide
theorem cert_e605601768878 : check e605601768878 [[],[]] .chain = true := by decide
def e605601768890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e605601768890 : Closed e605601768890 ∧ code e605601768890 = 2804625024442 := by decide
theorem cert_e605601768890 : check e605601768890 [[],[]] .chain = true := by decide
def e605601768938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e605601768938 : Closed e605601768938 ∧ code e605601768938 = 2804625024490 := by decide
theorem cert_e605601768938 : check e605601768938 [[],[]] .chain = true := by decide
def e605601769070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e605601769070 : Closed e605601769070 ∧ code e605601769070 = 2804625024622 := by decide
theorem cert_e605601769070 : check e605601769070 [[],[]] .chain = true := by decide
def e605601769082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e605601769082 : Closed e605601769082 ∧ code e605601769082 = 2804625024634 := by decide
theorem cert_e605601769082 : check e605601769082 [[],[]] .chain = true := by decide
def e605601769246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e605601769246 : Closed e605601769246 ∧ code e605601769246 = 2804625024798 := by decide
theorem cert_e605601769246 : check e605601769246 [[],[]] .chain = true := by decide
def e605601769346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e605601769346 : Closed e605601769346 ∧ code e605601769346 = 2804625024898 := by decide
theorem cert_e605601769346 : check e605601769346 [[],[]] .chain = true := by decide
def e605601769358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e605601769358 : Closed e605601769358 ∧ code e605601769358 = 2804625024910 := by decide
theorem cert_e605601769358 : check e605601769358 [[],[]] .chain = true := by decide
def e605601769370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e605601769370 : Closed e605601769370 ∧ code e605601769370 = 2804625024922 := by decide
theorem cert_e605601769370 : check e605601769370 [[],[]] .chain = true := by decide
def e605601771742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e605601771742 : Closed e605601771742 ∧ code e605601771742 = 2804625027294 := by decide
theorem cert_e605601771742 : check e605601771742 [[],[]] .chain = true := by decide
def e605601771770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e605601771770 : Closed e605601771770 ∧ code e605601771770 = 2804625027322 := by decide
theorem cert_e605601771770 : check e605601771770 [[],[]] .chain = true := by decide
def e605601772318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e605601772318 : Closed e605601772318 ∧ code e605601772318 = 2804625027870 := by decide
theorem cert_e605601772318 : check e605601772318 [[],[]] .chain = true := by decide
def e605601772486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e605601772486 : Closed e605601772486 ∧ code e605601772486 = 2804625028038 := by decide
theorem cert_e605601772486 : check e605601772486 [[],[]] .chain = true := by decide
def e605601773594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605601773594 : Closed e605601773594 ∧ code e605601773594 = 2804625029146 := by decide
theorem cert_e605601773594 : check e605601773594 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601773630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 4))))))))
theorem wire_e605601773630 : Closed e605601773630 ∧ code e605601773630 = 2804625029182 := by decide
theorem cert_e605601773630 : check e605601773630 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601773678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e605601773678 : Closed e605601773678 ∧ code e605601773678 = 2804625029230 := by decide
theorem cert_e605601773678 : check e605601773678 [[],[]] .chain = true := by decide
def e605601773686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e605601773686 : Closed e605601773686 ∧ code e605601773686 = 2804625029238 := by decide
theorem cert_e605601773686 : check e605601773686 [[],[]] .chain = true := by decide
def e605601773690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e605601773690 : Closed e605601773690 ∧ code e605601773690 = 2804625029242 := by decide
theorem cert_e605601773690 : check e605601773690 [[],[]] .chain = true := by decide
def e605601773930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e605601773930 : Closed e605601773930 ∧ code e605601773930 = 2804625029482 := by decide
theorem cert_e605601773930 : check e605601773930 [[],[]] .chain = true := by decide
def e605601773954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e605601773954 : Closed e605601773954 ∧ code e605601773954 = 2804625029506 := by decide
theorem cert_e605601773954 : check e605601773954 [[],[]] .chain = true := by decide
def e605601773966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e605601773966 : Closed e605601773966 ∧ code e605601773966 = 2804625029518 := by decide
theorem cert_e605601773966 : check e605601773966 [[],[]] .chain = true := by decide
def e605601773978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e605601773978 : Closed e605601773978 ∧ code e605601773978 = 2804625029530 := by decide
theorem cert_e605601773978 : check e605601773978 [[],[]] .chain = true := by decide
def e605601774022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e605601774022 : Closed e605601774022 ∧ code e605601774022 = 2804625029574 := by decide
theorem cert_e605601774022 : check e605601774022 [[],[]] .chain = true := by decide
def e605601774050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e605601774050 : Closed e605601774050 ∧ code e605601774050 = 2804625029602 := by decide
theorem cert_e605601774050 : check e605601774050 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601774062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 2)))))))
theorem wire_e605601774062 : Closed e605601774062 ∧ code e605601774062 = 2804625029614 := by decide
theorem cert_e605601774062 : check e605601774062 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601775830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e605601775830 : Closed e605601775830 ∧ code e605601775830 = 2804625031382 := by decide
theorem cert_e605601775830 : check e605601775830 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601775926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601775926 : Closed e605601775926 ∧ code e605601775926 = 2804625031478 := by decide
theorem cert_e605601775926 : check e605601775926 [[],[]] .chain = true := by decide
def e605601775930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601775930 : Closed e605601775930 ∧ code e605601775930 = 2804625031482 := by decide
theorem cert_e605601775930 : check e605601775930 [[],[]] .chain = true := by decide
def e605601776110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e605601776110 : Closed e605601776110 ∧ code e605601776110 = 2804625031662 := by decide
theorem cert_e605601776110 : checkPay e605601776110 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e605601776118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e605601776118 : Closed e605601776118 ∧ code e605601776118 = 2804625031670 := by decide
theorem cert_e605601776118 : check e605601776118 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601776502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e605601776502 : Closed e605601776502 ∧ code e605601776502 = 2804625032054 := by decide
theorem cert_e605601776502 : check e605601776502 [[],[]] .chain = true := by decide
def e605601776566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e605601776566 : Closed e605601776566 ∧ code e605601776566 = 2804625032118 := by decide
theorem cert_e605601776566 : check e605601776566 [[],[]] .chain = true := by decide
def e605601776570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e605601776570 : Closed e605601776570 ∧ code e605601776570 = 2804625032122 := by decide
theorem cert_e605601776570 : check e605601776570 [[],[]] .chain = true := by decide
def e605601776598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e605601776598 : Closed e605601776598 ∧ code e605601776598 = 2804625032150 := by decide
theorem cert_e605601776598 : check e605601776598 [[],[]] .chain = true := by decide
def e605601776602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e605601776602 : Closed e605601776602 ∧ code e605601776602 = 2804625032154 := by decide
theorem cert_e605601776602 : check e605601776602 [[],[]] .chain = true := by decide
def e605601776878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e605601776878 : Closed e605601776878 ∧ code e605601776878 = 2804625032430 := by decide
theorem cert_e605601776878 : check e605601776878 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601776886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e605601776886 : Closed e605601776886 ∧ code e605601776886 = 2804625032438 := by decide
theorem cert_e605601776886 : check e605601776886 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605601777270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e605601777270 : Closed e605601777270 ∧ code e605601777270 = 2804625032822 := by decide
theorem cert_e605601777270 : check e605601777270 [[],[]] .chain = true := by decide
def e605601777438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e605601777438 : Closed e605601777438 ∧ code e605601777438 = 2804625032990 := by decide
theorem cert_e605601777438 : check e605601777438 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e605601777462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601777462 : Closed e605601777462 ∧ code e605601777462 = 2804625033014 := by decide
theorem cert_e605601777462 : check e605601777462 [[],[]] .chain = true := by decide
def e605601777466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601777466 : Closed e605601777466 ∧ code e605601777466 = 2804625033018 := by decide
theorem cert_e605601777466 : check e605601777466 [[],[]] .chain = true := by decide
def e605601777550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e605601777550 : Closed e605601777550 ∧ code e605601777550 = 2804625033102 := by decide
theorem cert_e605601777550 : checkPay e605601777550 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] 0 [] = true := by decide
def e605601778518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e605601778518 : Closed e605601778518 ∧ code e605601778518 = 2804625034070 := by decide
theorem cert_e605601778518 : check e605601778518 [[],[]] .chain = true := by decide
def e605601778522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e605601778522 : Closed e605601778522 ∧ code e605601778522 = 2804625034074 := by decide
theorem cert_e605601778522 : check e605601778522 [[],[]] .chain = true := by decide
def e605601778538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e605601778538 : Closed e605601778538 ∧ code e605601778538 = 2804625034090 := by decide
theorem cert_e605601778538 : check e605601778538 [[],[]] .chain = true := by decide
def e605601778602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e605601778602 : Closed e605601778602 ∧ code e605601778602 = 2804625034154 := by decide
theorem cert_e605601778602 : check e605601778602 [[],[]] .chain = true := by decide
def e605601778710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e605601778710 : Closed e605601778710 ∧ code e605601778710 = 2804625034262 := by decide
theorem cert_e605601778710 : check e605601778710 [[],[]] .chain = true := by decide
def e605601778806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e605601778806 : Closed e605601778806 ∧ code e605601778806 = 2804625034358 := by decide
theorem cert_e605601778806 : check e605601778806 [[],[]] .chain = true := by decide
def e605601778902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e605601778902 : Closed e605601778902 ∧ code e605601778902 = 2804625034454 := by decide
theorem cert_e605601778902 : check e605601778902 [[],[]] .chain = true := by decide
def e605601778906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e605601778906 : Closed e605601778906 ∧ code e605601778906 = 2804625034458 := by decide
theorem cert_e605601778906 : check e605601778906 [[],[]] .chain = true := by decide
def e605601778922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e605601778922 : Closed e605601778922 ∧ code e605601778922 = 2804625034474 := by decide
theorem cert_e605601778922 : check e605601778922 [[],[]] .chain = true := by decide
def e605601778998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601778998 : Closed e605601778998 ∧ code e605601778998 = 2804625034550 := by decide
theorem cert_e605601778998 : check e605601778998 [[],[]] .chain = true := by decide
def e605601779002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601779002 : Closed e605601779002 ∧ code e605601779002 = 2804625034554 := by decide
theorem cert_e605601779002 : check e605601779002 [[],[]] .chain = true := by decide
def e605601779074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e605601779074 : Closed e605601779074 ∧ code e605601779074 = 2804625034626 := by decide
theorem cert_e605601779074 : check e605601779074 [[],[]] .chain = true := by decide
def e605601779086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e605601779086 : Closed e605601779086 ∧ code e605601779086 = 2804625034638 := by decide
theorem cert_e605601779086 : check e605601779086 [[],[]] .chain = true := by decide
def e605601779098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601779098 : Closed e605601779098 ∧ code e605601779098 = 2804625034650 := by decide
theorem cert_e605601779098 : check e605601779098 [[],[]] .chain = true := by decide
def e605601779210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e605601779210 : Closed e605601779210 ∧ code e605601779210 = 2804625034762 := by decide
theorem cert_e605601779210 : check e605601779210 [[],[]] .chain = true := by decide
def e605601779246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e605601779246 : Closed e605601779246 ∧ code e605601779246 = 2804625034798 := by decide
theorem cert_e605601779246 : check e605601779246 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605601779254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e605601779254 : Closed e605601779254 ∧ code e605601779254 = 2804625034806 := by decide
theorem cert_e605601779254 : check e605601779254 [[],[]] .chain = true := by decide
def e605601779258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e605601779258 : Closed e605601779258 ∧ code e605601779258 = 2804625034810 := by decide
theorem cert_e605601779258 : check e605601779258 [[],[]] .chain = true := by decide
def e605601779306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e605601779306 : Closed e605601779306 ∧ code e605601779306 = 2804625034858 := by decide
theorem cert_e605601779306 : check e605601779306 [[],[]] .chain = true := by decide
def e605601779330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e605601779330 : Closed e605601779330 ∧ code e605601779330 = 2804625034882 := by decide
theorem cert_e605601779330 : check e605601779330 [[],[]] .chain = true := by decide
def e605601779342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e605601779342 : Closed e605601779342 ∧ code e605601779342 = 2804625034894 := by decide
theorem cert_e605601779342 : check e605601779342 [[],[]] .chain = true := by decide
def e605601779354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601779354 : Closed e605601779354 ∧ code e605601779354 = 2804625034906 := by decide
theorem cert_e605601779354 : check e605601779354 [[],[]] .chain = true := by decide
def e605601779398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e605601779398 : Closed e605601779398 ∧ code e605601779398 = 2804625034950 := by decide
theorem cert_e605601779398 : check e605601779398 [[],[]] .chain = true := by decide
def e605601779426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e605601779426 : Closed e605601779426 ∧ code e605601779426 = 2804625034978 := by decide
theorem cert_e605601779426 : check e605601779426 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605601779438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e605601779438 : Closed e605601779438 ∧ code e605601779438 = 2804625034990 := by decide
theorem cert_e605601779438 : check e605601779438 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605601779478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e605601779478 : Closed e605601779478 ∧ code e605601779478 = 2804625035030 := by decide
theorem cert_e605601779478 : check e605601779478 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601779554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e605601779554 : Closed e605601779554 ∧ code e605601779554 = 2804625035106 := by decide
theorem cert_e605601779554 : check e605601779554 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e605601779566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e605601779566 : Closed e605601779566 ∧ code e605601779566 = 2804625035118 := by decide
theorem cert_e605601779566 : check e605601779566 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e605601779574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e605601779574 : Closed e605601779574 ∧ code e605601779574 = 2804625035126 := by decide
theorem cert_e605601779574 : check e605601779574 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601779950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e605601779950 : Closed e605601779950 ∧ code e605601779950 = 2804625035502 := by decide
theorem cert_e605601779950 : check e605601779950 [[],[]] .chain = true := by decide
def e605601779958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e605601779958 : Closed e605601779958 ∧ code e605601779958 = 2804625035510 := by decide
theorem cert_e605601779958 : check e605601779958 [[],[]] .chain = true := by decide
def e605601780438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e605601780438 : Closed e605601780438 ∧ code e605601780438 = 2804625035990 := by decide
theorem cert_e605601780438 : check e605601780438 [[],[]] .chain = true := by decide
def e605601780442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e605601780442 : Closed e605601780442 ∧ code e605601780442 = 2804625035994 := by decide
theorem cert_e605601780442 : check e605601780442 [[],[]] .chain = true := by decide
def e605601780458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e605601780458 : Closed e605601780458 ∧ code e605601780458 = 2804625036010 := by decide
theorem cert_e605601780458 : check e605601780458 [[],[]] .chain = true := by decide
def e605601780534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e605601780534 : Closed e605601780534 ∧ code e605601780534 = 2804625036086 := by decide
theorem cert_e605601780534 : check e605601780534 [[],[]] .chain = true := by decide
def e605601780538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e605601780538 : Closed e605601780538 ∧ code e605601780538 = 2804625036090 := by decide
theorem cert_e605601780538 : check e605601780538 [[],[]] .chain = true := by decide
def e605601780610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e605601780610 : Closed e605601780610 ∧ code e605601780610 = 2804625036162 := by decide
theorem cert_e605601780610 : check e605601780610 [[],[]] .chain = true := by decide
def e605601780622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e605601780622 : Closed e605601780622 ∧ code e605601780622 = 2804625036174 := by decide
theorem cert_e605601780622 : check e605601780622 [[],[]] .chain = true := by decide
def e605601780634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e605601780634 : Closed e605601780634 ∧ code e605601780634 = 2804625036186 := by decide
theorem cert_e605601780634 : check e605601780634 [[],[]] .chain = true := by decide
def e605601781786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605601781786 : Closed e605601781786 ∧ code e605601781786 = 2804625037338 := by decide
theorem cert_e605601781786 : check e605601781786 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605601781822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e605601781822 : Closed e605601781822 ∧ code e605601781822 = 2804625037374 := by decide
theorem cert_e605601781822 : check e605601781822 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605601781870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e605601781870 : Closed e605601781870 ∧ code e605601781870 = 2804625037422 := by decide
theorem cert_e605601781870 : check e605601781870 [[],[]] .chain = true := by decide
def e605601781878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e605601781878 : Closed e605601781878 ∧ code e605601781878 = 2804625037430 := by decide
theorem cert_e605601781878 : check e605601781878 [[],[]] .chain = true := by decide
def e605601781882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e605601781882 : Closed e605601781882 ∧ code e605601781882 = 2804625037434 := by decide
theorem cert_e605601781882 : check e605601781882 [[],[]] .chain = true := by decide
def e605601782122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e605601782122 : Closed e605601782122 ∧ code e605601782122 = 2804625037674 := by decide
theorem cert_e605601782122 : check e605601782122 [[],[]] .chain = true := by decide
def e605601782146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e605601782146 : Closed e605601782146 ∧ code e605601782146 = 2804625037698 := by decide
theorem cert_e605601782146 : check e605601782146 [[],[]] .chain = true := by decide
def e605601782158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e605601782158 : Closed e605601782158 ∧ code e605601782158 = 2804625037710 := by decide
theorem cert_e605601782158 : check e605601782158 [[],[]] .chain = true := by decide
def e605601782170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e605601782170 : Closed e605601782170 ∧ code e605601782170 = 2804625037722 := by decide
theorem cert_e605601782170 : check e605601782170 [[],[]] .chain = true := by decide
def e605601782214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e605601782214 : Closed e605601782214 ∧ code e605601782214 = 2804625037766 := by decide
theorem cert_e605601782214 : check e605601782214 [[],[]] .chain = true := by decide
def e605601782242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e605601782242 : Closed e605601782242 ∧ code e605601782242 = 2804625037794 := by decide
theorem cert_e605601782242 : check e605601782242 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605601782254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e605601782254 : Closed e605601782254 ∧ code e605601782254 = 2804625037806 := by decide
theorem cert_e605601782254 : check e605601782254 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605601782814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e605601782814 : Closed e605601782814 ∧ code e605601782814 = 2804625038366 := by decide
theorem cert_e605601782814 : check e605601782814 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601783010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e605601783010 : Closed e605601783010 ∧ code e605601783010 = 2804625038562 := by decide
theorem cert_e605601783010 : check e605601783010 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601783022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e605601783022 : Closed e605601783022 ∧ code e605601783022 = 2804625038574 := by decide
theorem cert_e605601783022 : check e605601783022 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605601783030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e605601783030 : Closed e605601783030 ∧ code e605601783030 = 2804625038582 := by decide
theorem cert_e605601783030 : check e605601783030 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605601793710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e605601793710 : Closed e605601793710 ∧ code e605601793710 = 2804625049262 := by decide
theorem cert_e605601793710 : check e605601793710 [[],[]] .sourceHead = true := by decide
def e605601793722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e605601793722 : Closed e605601793722 ∧ code e605601793722 = 2804625049274 := by decide
theorem cert_e605601793722 : check e605601793722 [[],[]] .sourceHead = true := by decide
def e605601794478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e605601794478 : Closed e605601794478 ∧ code e605601794478 = 2804625050030 := by decide
theorem cert_e605601794478 : check e605601794478 [[],[]] .chain = true := by decide
def e605601794490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e605601794490 : Closed e605601794490 ∧ code e605601794490 = 2804625050042 := by decide
theorem cert_e605601794490 : check e605601794490 [[],[]] .chain = true := by decide
def e605601794538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e605601794538 : Closed e605601794538 ∧ code e605601794538 = 2804625050090 := by decide
theorem cert_e605601794538 : check e605601794538 [[],[]] .chain = true := by decide
def e605601794670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601794670 : Closed e605601794670 ∧ code e605601794670 = 2804625050222 := by decide
theorem cert_e605601794670 : check e605601794670 [[],[]] .chain = true := by decide
def e605601794682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601794682 : Closed e605601794682 ∧ code e605601794682 = 2804625050234 := by decide
theorem cert_e605601794682 : check e605601794682 [[],[]] .chain = true := by decide
def e605601794970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601794970 : Closed e605601794970 ∧ code e605601794970 = 2804625050522 := by decide
theorem cert_e605601794970 : check e605601794970 [[],[]] .chain = true := by decide
def e605601795822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.var 2))))))
theorem wire_e605601795822 : Closed e605601795822 ∧ code e605601795822 = 2804625051374 := by decide
theorem cert_e605601795822 : check e605601795822 [[],[]] .sourceHead = true := by decide
def e605601796014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.var 2))))))
theorem wire_e605601796014 : Closed e605601796014 ∧ code e605601796014 = 2804625051566 := by decide
theorem cert_e605601796014 : check e605601796014 [[],[]] .sourceHead = true := by decide
def e605601796026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 2)) (.var 0))))))
theorem wire_e605601796026 : Closed e605601796026 ∧ code e605601796026 = 2804625051578 := by decide
theorem cert_e605601796026 : check e605601796026 [[],[]] .sourceHead = true := by decide
def e605601799022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e605601799022 : Closed e605601799022 ∧ code e605601799022 = 2804625054574 := by decide
theorem cert_e605601799022 : check e605601799022 [[],[]] .chain = true := by decide
def e605601799030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e605601799030 : Closed e605601799030 ∧ code e605601799030 = 2804625054582 := by decide
theorem cert_e605601799030 : check e605601799030 [[],[]] .chain = true := by decide
def e605601799086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e605601799086 : Closed e605601799086 ∧ code e605601799086 = 2804625054638 := by decide
theorem cert_e605601799086 : check e605601799086 [[],[]] .chain = true := by decide
def e605601799098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e605601799098 : Closed e605601799098 ∧ code e605601799098 = 2804625054650 := by decide
theorem cert_e605601799098 : check e605601799098 [[],[]] .chain = true := by decide
end Blc.Floor41
