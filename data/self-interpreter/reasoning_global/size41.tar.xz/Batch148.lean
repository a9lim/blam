import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e701154187682 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701154187682 : Closed e701154187682 ∧ code e701154187682 = 2900177443234 := by decide
theorem cert_e701154187682 : check e701154187682 [[.left],[.left]] .smaller = true := by decide
def e701154187802 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e701154187802 : Closed e701154187802 ∧ code e701154187802 = 2900177443354 := by decide
theorem cert_e701154187802 : check e701154187802 [[.left]] .chain = true := by decide
def e701154244322 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701154244322 : Closed e701154244322 ∧ code e701154244322 = 2900177499874 := by decide
theorem cert_e701154244322 : check e701154244322 [[.left],[.left]] .smaller = true := by decide
def e701154244450 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e701154244450 : Closed e701154244450 ∧ code e701154244450 = 2900177500002 := by decide
theorem cert_e701154244450 : check e701154244450 [[.left],[.left]] .smaller = true := by decide
def e701154245346 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701154245346 : Closed e701154245346 ∧ code e701154245346 = 2900177500898 := by decide
theorem cert_e701154245346 : check e701154245346 [[.left],[.left]] .smaller = true := by decide
def e701154245538 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701154245538 : Closed e701154245538 ∧ code e701154245538 = 2900177501090 := by decide
theorem cert_e701154245538 : check e701154245538 [[.left],[.left]] .smaller = true := by decide
def e701154245986 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e701154245986 : Closed e701154245986 ∧ code e701154245986 = 2900177501538 := by decide
theorem cert_e701154245986 : check e701154245986 [[.left],[.left]] .smaller = true := by decide
def e701154246050 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701154246050 : Closed e701154246050 ∧ code e701154246050 = 2900177501602 := by decide
theorem cert_e701154246050 : check e701154246050 [[.left],[.left]] .smaller = true := by decide
def e701154250466 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.var 0)))
theorem wire_e701154250466 : Closed e701154250466 ∧ code e701154250466 = 2900177506018 := by decide
theorem cert_e701154250466 : check e701154250466 [[.left],[.left]] .smaller = true := by decide
def e701154250594 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e701154250594 : Closed e701154250594 ∧ code e701154250594 = 2900177506146 := by decide
theorem cert_e701154250594 : check e701154250594 [[.left],[.left]] .smaller = true := by decide
def e701154256610 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.var 0)))
theorem wire_e701154256610 : Closed e701154256610 ∧ code e701154256610 = 2900177512162 := by decide
theorem cert_e701154256610 : check e701154256610 [[.left],[.left]] .smaller = true := by decide
def e701154256802 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e701154256802 : Closed e701154256802 ∧ code e701154256802 = 2900177512354 := by decide
theorem cert_e701154256802 : check e701154256802 [[.left],[.left]] .smaller = true := by decide
def e701154258458 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e701154258458 : Closed e701154258458 ∧ code e701154258458 = 2900177514010 := by decide
theorem cert_e701154258458 : check e701154258458 [[.left]] .chain = true := by decide
def e701154259810 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e701154259810 : Closed e701154259810 ∧ code e701154259810 = 2900177515362 := by decide
theorem cert_e701154259810 : check e701154259810 [[.left],[.left]] .smaller = true := by decide
def e701154259874 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e701154259874 : Closed e701154259874 ∧ code e701154259874 = 2900177515426 := by decide
theorem cert_e701154259874 : check e701154259874 [[.left],[.left]] .smaller = true := by decide
def e701154260506 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e701154260506 : Closed e701154260506 ∧ code e701154260506 = 2900177516058 := by decide
theorem cert_e701154260506 : check e701154260506 [[.left]] .chain = true := by decide
def e701154351842 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701154351842 : Closed e701154351842 ∧ code e701154351842 = 2900177607394 := by decide
theorem cert_e701154351842 : check e701154351842 [[.left],[.left]] .smaller = true := by decide
def e701154352034 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701154352034 : Closed e701154352034 ∧ code e701154352034 = 2900177607586 := by decide
theorem cert_e701154352034 : check e701154352034 [[.left],[.left]] .smaller = true := by decide
def e701154352802 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701154352802 : Closed e701154352802 ∧ code e701154352802 = 2900177608354 := by decide
theorem cert_e701154352802 : check e701154352802 [[.left],[.left]] .smaller = true := by decide
def e701154354914 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.var 0)))
theorem wire_e701154354914 : Closed e701154354914 ∧ code e701154354914 = 2900177610466 := by decide
theorem cert_e701154354914 : check e701154354914 [[.left],[.left]] .smaller = true := by decide
def e701154355106 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e701154355106 : Closed e701154355106 ∧ code e701154355106 = 2900177610658 := by decide
theorem cert_e701154355106 : check e701154355106 [[.left],[.left]] .smaller = true := by decide
def e701154356762 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e701154356762 : Closed e701154356762 ∧ code e701154356762 = 2900177612314 := by decide
theorem cert_e701154356762 : check e701154356762 [[.left]] .chain = true := by decide
def e701154359714 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e701154359714 : Closed e701154359714 ∧ code e701154359714 = 2900177615266 := by decide
theorem cert_e701154359714 : check e701154359714 [[.left],[.left]] .smaller = true := by decide
def e701154359834 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e701154359834 : Closed e701154359834 ∧ code e701154359834 = 2900177615386 := by decide
theorem cert_e701154359834 : check e701154359834 [[.left]] .chain = true := by decide
def e701154405730 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e701154405730 : Closed e701154405730 ∧ code e701154405730 = 2900177661282 := by decide
theorem cert_e701154405730 : check e701154405730 [[.left],[.left]] .smaller = true := by decide
def e701154405794 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701154405794 : Closed e701154405794 ∧ code e701154405794 = 2900177661346 := by decide
theorem cert_e701154405794 : check e701154405794 [[.left],[.left]] .smaller = true := by decide
def e701154406050 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701154406050 : Closed e701154406050 ∧ code e701154406050 = 2900177661602 := by decide
theorem cert_e701154406050 : check e701154406050 [[.left],[.left]] .smaller = true := by decide
def e701154407266 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e701154407266 : Closed e701154407266 ∧ code e701154407266 = 2900177662818 := by decide
theorem cert_e701154407266 : check e701154407266 [[.left],[.left]] .smaller = true := by decide
def e701154407330 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e701154407330 : Closed e701154407330 ∧ code e701154407330 = 2900177662882 := by decide
theorem cert_e701154407330 : check e701154407330 [[.left],[.left]] .smaller = true := by decide
def e701154407962 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e701154407962 : Closed e701154407962 ∧ code e701154407962 = 2900177663514 := by decide
theorem cert_e701154407962 : check e701154407962 [[.left]] .chain = true := by decide
def e701154408866 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e701154408866 : Closed e701154408866 ∧ code e701154408866 = 2900177664418 := by decide
theorem cert_e701154408866 : check e701154408866 [[.left],[.left]] .smaller = true := by decide
def e701154408986 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e701154408986 : Closed e701154408986 ∧ code e701154408986 = 2900177664538 := by decide
theorem cert_e701154408986 : check e701154408986 [[.left]] .chain = true := by decide
def e701156252546 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.var 0))))
theorem wire_e701156252546 : Closed e701156252546 ∧ code e701156252546 = 2900179508098 := by decide
theorem cert_e701156252546 : check e701156252546 [[.left],[.left]] .chain = true := by decide
def e701156253058 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e701156253058 : Closed e701156253058 ∧ code e701156253058 = 2900179508610 := by decide
theorem cert_e701156253058 : check e701156253058 [[.left],[.left]] .chain = true := by decide
def e701156256642 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.var 0))))
theorem wire_e701156256642 : Closed e701156256642 ∧ code e701156256642 = 2900179512194 := by decide
theorem cert_e701156256642 : check e701156256642 [[.left],[.left]] .chain = true := by decide
def e701156257410 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e701156257410 : Closed e701156257410 ∧ code e701156257410 = 2900179512962 := by decide
theorem cert_e701156257410 : check e701156257410 [[.left],[.left]] .chain = true := by decide
def e701156257506 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e701156257506 : Closed e701156257506 ∧ code e701156257506 = 2900179513058 := by decide
theorem cert_e701156257506 : check e701156257506 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156259202 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e701156259202 : Closed e701156259202 ∧ code e701156259202 = 2900179514754 := by decide
theorem cert_e701156259202 : check e701156259202 [[.left],[.left]] .chain = true := by decide
def e701156259458 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e701156259458 : Closed e701156259458 ∧ code e701156259458 = 2900179515010 := by decide
theorem cert_e701156259458 : check e701156259458 [[.left],[.left]] .chain = true := by decide
def e701156259554 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e701156259554 : Closed e701156259554 ∧ code e701156259554 = 2900179515106 := by decide
theorem cert_e701156259554 : check e701156259554 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156259682 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e701156259682 : Closed e701156259682 ∧ code e701156259682 = 2900179515234 := by decide
theorem cert_e701156259682 : check e701156259682 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156273026 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.var 0))))
theorem wire_e701156273026 : Closed e701156273026 ∧ code e701156273026 = 2900179528578 := by decide
theorem cert_e701156273026 : check e701156273026 [[.left],[.left]] .chain = true := by decide
def e701156273794 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e701156273794 : Closed e701156273794 ∧ code e701156273794 = 2900179529346 := by decide
theorem cert_e701156273794 : check e701156273794 [[.left],[.left]] .chain = true := by decide
def e701156273890 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e701156273890 : Closed e701156273890 ∧ code e701156273890 = 2900179529442 := by decide
theorem cert_e701156273890 : check e701156273890 [[.left],[.left],[],[.under,.left,.left]] .sourceHead = true := by decide
def e701156276866 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e701156276866 : Closed e701156276866 ∧ code e701156276866 = 2900179532418 := by decide
theorem cert_e701156276866 : check e701156276866 [[.left],[.left]] .chain = true := by decide
def e701156276962 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e701156276962 : Closed e701156276962 ∧ code e701156276962 = 2900179532514 := by decide
theorem cert_e701156276962 : check e701156276962 [[.left],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e701156277154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e701156277154 : Closed e701156277154 ∧ code e701156277154 = 2900179532706 := by decide
theorem cert_e701156277154 : check e701156277154 [[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701156283778 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e701156283778 : Closed e701156283778 ∧ code e701156283778 = 2900179539330 := by decide
theorem cert_e701156283778 : check e701156283778 [[.left],[.left]] .chain = true := by decide
def e701156284034 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e701156284034 : Closed e701156284034 ∧ code e701156284034 = 2900179539586 := by decide
theorem cert_e701156284034 : check e701156284034 [[.left],[.left]] .chain = true := by decide
def e701156284130 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e701156284130 : Closed e701156284130 ∧ code e701156284130 = 2900179539682 := by decide
theorem cert_e701156284130 : check e701156284130 [[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e701156284258 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e701156284258 : Closed e701156284258 ∧ code e701156284258 = 2900179539810 := by decide
theorem cert_e701156284258 : check e701156284258 [[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e701156285058 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e701156285058 : Closed e701156285058 ∧ code e701156285058 = 2900179540610 := by decide
theorem cert_e701156285058 : check e701156285058 [[.left],[.left]] .chain = true := by decide
def e701156285154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.var 0)))
theorem wire_e701156285154 : Closed e701156285154 ∧ code e701156285154 = 2900179540706 := by decide
theorem cert_e701156285154 : check e701156285154 [[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e701156285346 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e701156285346 : Closed e701156285346 ∧ code e701156285346 = 2900179540898 := by decide
theorem cert_e701156285346 : check e701156285346 [[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e701156285794 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.var 0)))
theorem wire_e701156285794 : Closed e701156285794 ∧ code e701156285794 = 2900179541346 := by decide
private def t_e701156285794 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.var 0)))
theorem cert_e701156285794 : ¬ IsSelfInterpreter e701156285794 :=
  wSource (t := t_e701156285794) (replay_sound (ps := []) (t := e701156285794) (by decide)) (by decide)
def e701156285858 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.var 0)))
theorem wire_e701156285858 : Closed e701156285858 ∧ code e701156285858 = 2900179541410 := by decide
private def t_e701156285858 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.var 0)))
theorem cert_e701156285858 : ¬ IsSelfInterpreter e701156285858 :=
  wSource (t := t_e701156285858) (replay_sound (ps := []) (t := e701156285858) (by decide)) (by decide)
def e701156350850 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.var 0))))
theorem wire_e701156350850 : Closed e701156350850 ∧ code e701156350850 = 2900179606402 := by decide
theorem cert_e701156350850 : check e701156350850 [[.left],[.left]] .chain = true := by decide
def e701156351362 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e701156351362 : Closed e701156351362 ∧ code e701156351362 = 2900179606914 := by decide
theorem cert_e701156351362 : check e701156351362 [[.left],[.left]] .chain = true := by decide
def e701156354946 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.var 0))))
theorem wire_e701156354946 : Closed e701156354946 ∧ code e701156354946 = 2900179610498 := by decide
theorem cert_e701156354946 : check e701156354946 [[.left],[.left]] .chain = true := by decide
def e701156355714 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e701156355714 : Closed e701156355714 ∧ code e701156355714 = 2900179611266 := by decide
theorem cert_e701156355714 : check e701156355714 [[.left],[.left]] .chain = true := by decide
def e701156355810 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e701156355810 : Closed e701156355810 ∧ code e701156355810 = 2900179611362 := by decide
theorem cert_e701156355810 : check e701156355810 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156357506 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e701156357506 : Closed e701156357506 ∧ code e701156357506 = 2900179613058 := by decide
theorem cert_e701156357506 : check e701156357506 [[.left],[.left]] .chain = true := by decide
def e701156357762 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e701156357762 : Closed e701156357762 ∧ code e701156357762 = 2900179613314 := by decide
theorem cert_e701156357762 : check e701156357762 [[.left],[.left]] .chain = true := by decide
def e701156357858 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e701156357858 : Closed e701156357858 ∧ code e701156357858 = 2900179613410 := by decide
theorem cert_e701156357858 : check e701156357858 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156357986 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e701156357986 : Closed e701156357986 ∧ code e701156357986 = 2900179613538 := by decide
theorem cert_e701156357986 : check e701156357986 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156375426 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e701156375426 : Closed e701156375426 ∧ code e701156375426 = 2900179630978 := by decide
theorem cert_e701156375426 : check e701156375426 [[.left],[.left]] .chain = true := by decide
def e701156375938 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e701156375938 : Closed e701156375938 ∧ code e701156375938 = 2900179631490 := by decide
theorem cert_e701156375938 : check e701156375938 [[.left],[.left]] .chain = true := by decide
def e701156400002 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e701156400002 : Closed e701156400002 ∧ code e701156400002 = 2900179655554 := by decide
theorem cert_e701156400002 : check e701156400002 [[.left],[.left]] .chain = true := by decide
def e701156400770 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701156400770 : Closed e701156400770 ∧ code e701156400770 = 2900179656322 := by decide
theorem cert_e701156400770 : check e701156400770 [[.left],[.left]] .chain = true := by decide
def e701156400866 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701156400866 : Closed e701156400866 ∧ code e701156400866 = 2900179656418 := by decide
theorem cert_e701156400866 : check e701156400866 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156407322 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e701156407322 : Closed e701156407322 ∧ code e701156407322 = 2900179662874 := by decide
theorem cert_e701156407322 : check e701156407322 [[.left]] .chain = true := by decide
def e701156412802 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e701156412802 : Closed e701156412802 ∧ code e701156412802 = 2900179668354 := by decide
theorem cert_e701156412802 : check e701156412802 [[.left],[.left]] .chain = true := by decide
def e701156413058 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701156413058 : Closed e701156413058 ∧ code e701156413058 = 2900179668610 := by decide
theorem cert_e701156413058 : check e701156413058 [[.left],[.left]] .chain = true := by decide
def e701156413154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701156413154 : Closed e701156413154 ∧ code e701156413154 = 2900179668706 := by decide
theorem cert_e701156413154 : check e701156413154 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156413282 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.var 0)))
theorem wire_e701156413282 : Closed e701156413282 ∧ code e701156413282 = 2900179668834 := by decide
theorem cert_e701156413282 : check e701156413282 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156415514 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e701156415514 : Closed e701156415514 ∧ code e701156415514 = 2900179671066 := by decide
theorem cert_e701156415514 : check e701156415514 [[.left]] .chain = true := by decide
def e701156453250 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.var 0))))
theorem wire_e701156453250 : Closed e701156453250 ∧ code e701156453250 = 2900179708802 := by decide
theorem cert_e701156453250 : check e701156453250 [[.left],[.left]] .chain = true := by decide
def e701156454018 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e701156454018 : Closed e701156454018 ∧ code e701156454018 = 2900179709570 := by decide
theorem cert_e701156454018 : check e701156454018 [[.left],[.left]] .chain = true := by decide
def e701156454114 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e701156454114 : Closed e701156454114 ∧ code e701156454114 = 2900179709666 := by decide
theorem cert_e701156454114 : check e701156454114 [[.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e701156457090 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e701156457090 : Closed e701156457090 ∧ code e701156457090 = 2900179712642 := by decide
theorem cert_e701156457090 : check e701156457090 [[.left],[.left]] .chain = true := by decide
def e701156457186 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e701156457186 : Closed e701156457186 ∧ code e701156457186 = 2900179712738 := by decide
theorem cert_e701156457186 : check e701156457186 [[.left],[.left],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e701156457378 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e701156457378 : Closed e701156457378 ∧ code e701156457378 = 2900179712930 := by decide
theorem cert_e701156457378 : checkPay e701156457378 [[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e701156465538 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e701156465538 : Closed e701156465538 ∧ code e701156465538 = 2900179721090 := by decide
theorem cert_e701156465538 : check e701156465538 [[.left],[.left]] .chain = true := by decide
def e701156466306 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701156466306 : Closed e701156466306 ∧ code e701156466306 = 2900179721858 := by decide
theorem cert_e701156466306 : check e701156466306 [[.left],[.left]] .chain = true := by decide
def e701156466402 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701156466402 : Closed e701156466402 ∧ code e701156466402 = 2900179721954 := by decide
theorem cert_e701156466402 : check e701156466402 [[.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e701156472858 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e701156472858 : Closed e701156472858 ∧ code e701156472858 = 2900179728410 := by decide
theorem cert_e701156472858 : check e701156472858 [[.left]] .chain = true := by decide
def e701156484738 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701156484738 : Closed e701156484738 ∧ code e701156484738 = 2900179740290 := by decide
theorem cert_e701156484738 : check e701156484738 [[.left],[.left]] .chain = true := by decide
def e701156484834 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701156484834 : Closed e701156484834 ∧ code e701156484834 = 2900179740386 := by decide
theorem cert_e701156484834 : check e701156484834 [[.left],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e701156485026 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701156485026 : Closed e701156485026 ∧ code e701156485026 = 2900179740578 := by decide
theorem cert_e701156485026 : check e701156485026 [[.left],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e701156485146 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e701156485146 : Closed e701156485146 ∧ code e701156485146 = 2900179740698 := by decide
theorem cert_e701156485146 : check e701156485146 [[.left]] .chain = true := by decide
def e701156504962 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.var 0))))
theorem wire_e701156504962 : Closed e701156504962 ∧ code e701156504962 = 2900179760514 := by decide
theorem cert_e701156504962 : check e701156504962 [[.left],[.left]] .chain = true := by decide
def e701156505218 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e701156505218 : Closed e701156505218 ∧ code e701156505218 = 2900179760770 := by decide
theorem cert_e701156505218 : check e701156505218 [[.left],[.left]] .chain = true := by decide
def e701156505314 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e701156505314 : Closed e701156505314 ∧ code e701156505314 = 2900179760866 := by decide
theorem cert_e701156505314 : check e701156505314 [[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e701156505442 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e701156505442 : Closed e701156505442 ∧ code e701156505442 = 2900179760994 := by decide
theorem cert_e701156505442 : check e701156505442 [[.left],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e701156506242 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.var 0))))
theorem wire_e701156506242 : Closed e701156506242 ∧ code e701156506242 = 2900179761794 := by decide
theorem cert_e701156506242 : check e701156506242 [[.left],[.left]] .chain = true := by decide
def e701156506338 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.var 0)))
theorem wire_e701156506338 : Closed e701156506338 ∧ code e701156506338 = 2900179761890 := by decide
theorem cert_e701156506338 : check e701156506338 [[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e701156506530 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e701156506530 : Closed e701156506530 ∧ code e701156506530 = 2900179762082 := by decide
theorem cert_e701156506530 : check e701156506530 [[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e701156506978 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e701156506978 : Closed e701156506978 ∧ code e701156506978 = 2900179762530 := by decide
theorem cert_e701156506978 : check e701156506978 [[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e701156507042 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e701156507042 : Closed e701156507042 ∧ code e701156507042 = 2900179762594 := by decide
theorem cert_e701156507042 : check e701156507042 [[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e701156511106 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e701156511106 : Closed e701156511106 ∧ code e701156511106 = 2900179766658 := by decide
theorem cert_e701156511106 : check e701156511106 [[.left],[.left]] .chain = true := by decide
def e701156511362 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701156511362 : Closed e701156511362 ∧ code e701156511362 = 2900179766914 := by decide
theorem cert_e701156511362 : check e701156511362 [[.left],[.left]] .chain = true := by decide
def e701156511458 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701156511458 : Closed e701156511458 ∧ code e701156511458 = 2900179767010 := by decide
theorem cert_e701156511458 : check e701156511458 [[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e701156511586 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.var 0)))
theorem wire_e701156511586 : Closed e701156511586 ∧ code e701156511586 = 2900179767138 := by decide
theorem cert_e701156511586 : check e701156511586 [[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e701156513818 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e701156513818 : Closed e701156513818 ∧ code e701156513818 = 2900179769370 := by decide
theorem cert_e701156513818 : check e701156513818 [[.left]] .chain = true := by decide
def e701156517506 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701156517506 : Closed e701156517506 ∧ code e701156517506 = 2900179773058 := by decide
theorem cert_e701156517506 : check e701156517506 [[.left],[.left]] .chain = true := by decide
def e701156517602 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701156517602 : Closed e701156517602 ∧ code e701156517602 = 2900179773154 := by decide
theorem cert_e701156517602 : check e701156517602 [[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e701156517794 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701156517794 : Closed e701156517794 ∧ code e701156517794 = 2900179773346 := by decide
theorem cert_e701156517794 : check e701156517794 [[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e701156517914 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e701156517914 : Closed e701156517914 ∧ code e701156517914 = 2900179773466 := by decide
theorem cert_e701156517914 : check e701156517914 [[.left]] .chain = true := by decide
def e701156520802 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.var 0)))
theorem wire_e701156520802 : Closed e701156520802 ∧ code e701156520802 = 2900179776354 := by decide
private def t_e701156520802 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.var 0)))
theorem cert_e701156520802 : ¬ IsSelfInterpreter e701156520802 :=
  wSource (t := t_e701156520802) (replay_sound (ps := []) (t := e701156520802) (by decide)) (by decide)
def e701156520866 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701156520866 : Closed e701156520866 ∧ code e701156520866 = 2900179776418 := by decide
private def t_e701156520866 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.var 0)))
theorem cert_e701156520866 : ¬ IsSelfInterpreter e701156520866 :=
  wSource (t := t_e701156520866) (replay_sound (ps := []) (t := e701156520866) (by decide)) (by decide)
def e701156603618 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701156603618 : Closed e701156603618 ∧ code e701156603618 = 2900179859170 := by decide
theorem cert_e701156603618 : check e701156603618 [[.left],[.left]] .smaller = true := by decide
def e701156603746 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e701156603746 : Closed e701156603746 ∧ code e701156603746 = 2900179859298 := by decide
theorem cert_e701156603746 : check e701156603746 [[.left],[.left]] .smaller = true := by decide
def e701156604642 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701156604642 : Closed e701156604642 ∧ code e701156604642 = 2900179860194 := by decide
theorem cert_e701156604642 : check e701156604642 [[.left],[.left]] .smaller = true := by decide
def e701156604834 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701156604834 : Closed e701156604834 ∧ code e701156604834 = 2900179860386 := by decide
theorem cert_e701156604834 : check e701156604834 [[.left],[.left]] .smaller = true := by decide
def e701156605282 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e701156605282 : Closed e701156605282 ∧ code e701156605282 = 2900179860834 := by decide
theorem cert_e701156605282 : check e701156605282 [[.left],[.left]] .smaller = true := by decide
def e701156605346 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701156605346 : Closed e701156605346 ∧ code e701156605346 = 2900179860898 := by decide
theorem cert_e701156605346 : check e701156605346 [[.left],[.left]] .smaller = true := by decide
def e701156609762 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.var 0)))
theorem wire_e701156609762 : Closed e701156609762 ∧ code e701156609762 = 2900179865314 := by decide
theorem cert_e701156609762 : check e701156609762 [[.left],[.left]] .smaller = true := by decide
def e701156609890 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e701156609890 : Closed e701156609890 ∧ code e701156609890 = 2900179865442 := by decide
theorem cert_e701156609890 : check e701156609890 [[.left],[.left]] .smaller = true := by decide
def e701156615906 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.var 0)))
theorem wire_e701156615906 : Closed e701156615906 ∧ code e701156615906 = 2900179871458 := by decide
theorem cert_e701156615906 : check e701156615906 [[.left],[.left]] .smaller = true := by decide
def e701156616098 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e701156616098 : Closed e701156616098 ∧ code e701156616098 = 2900179871650 := by decide
theorem cert_e701156616098 : check e701156616098 [[.left],[.left]] .smaller = true := by decide
def e701156619106 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e701156619106 : Closed e701156619106 ∧ code e701156619106 = 2900179874658 := by decide
theorem cert_e701156619106 : check e701156619106 [[.left],[.left]] .smaller = true := by decide
def e701156619170 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e701156619170 : Closed e701156619170 ∧ code e701156619170 = 2900179874722 := by decide
theorem cert_e701156619170 : check e701156619170 [[.left],[.left]] .smaller = true := by decide
def e701156744066 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e701156744066 : Closed e701156744066 ∧ code e701156744066 = 2900179999618 := by decide
theorem cert_e701156744066 : check e701156744066 [[.left],[.left]] .chain = true := by decide
def e701156744578 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e701156744578 : Closed e701156744578 ∧ code e701156744578 = 2900180000130 := by decide
theorem cert_e701156744578 : check e701156744578 [[.left],[.left]] .chain = true := by decide
def e701156748162 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e701156748162 : Closed e701156748162 ∧ code e701156748162 = 2900180003714 := by decide
theorem cert_e701156748162 : check e701156748162 [[.left],[.left]] .chain = true := by decide
def e701156748930 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701156748930 : Closed e701156748930 ∧ code e701156748930 = 2900180004482 := by decide
theorem cert_e701156748930 : check e701156748930 [[.left],[.left]] .chain = true := by decide
def e701156749026 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701156749026 : Closed e701156749026 ∧ code e701156749026 = 2900180004578 := by decide
theorem cert_e701156749026 : check e701156749026 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156750722 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e701156750722 : Closed e701156750722 ∧ code e701156750722 = 2900180006274 := by decide
theorem cert_e701156750722 : check e701156750722 [[.left],[.left]] .chain = true := by decide
def e701156750978 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701156750978 : Closed e701156750978 ∧ code e701156750978 = 2900180006530 := by decide
theorem cert_e701156750978 : check e701156750978 [[.left],[.left]] .chain = true := by decide
def e701156751074 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701156751074 : Closed e701156751074 ∧ code e701156751074 = 2900180006626 := by decide
theorem cert_e701156751074 : check e701156751074 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156751202 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e701156751202 : Closed e701156751202 ∧ code e701156751202 = 2900180006754 := by decide
theorem cert_e701156751202 : check e701156751202 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156768642 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.var 0))))
theorem wire_e701156768642 : Closed e701156768642 ∧ code e701156768642 = 2900180024194 := by decide
theorem cert_e701156768642 : check e701156768642 [[.left],[.left]] .chain = true := by decide
def e701156769154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e701156769154 : Closed e701156769154 ∧ code e701156769154 = 2900180024706 := by decide
theorem cert_e701156769154 : check e701156769154 [[.left],[.left]] .chain = true := by decide
def e701156793218 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.var 0))))
theorem wire_e701156793218 : Closed e701156793218 ∧ code e701156793218 = 2900180048770 := by decide
theorem cert_e701156793218 : check e701156793218 [[.left],[.left]] .chain = true := by decide
def e701156793986 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e701156793986 : Closed e701156793986 ∧ code e701156793986 = 2900180049538 := by decide
theorem cert_e701156793986 : check e701156793986 [[.left],[.left]] .chain = true := by decide
def e701156794082 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701156794082 : Closed e701156794082 ∧ code e701156794082 = 2900180049634 := by decide
theorem cert_e701156794082 : check e701156794082 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156800538 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e701156800538 : Closed e701156800538 ∧ code e701156800538 = 2900180056090 := by decide
theorem cert_e701156800538 : check e701156800538 [[.left]] .chain = true := by decide
def e701156806018 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e701156806018 : Closed e701156806018 ∧ code e701156806018 = 2900180061570 := by decide
theorem cert_e701156806018 : check e701156806018 [[.left],[.left]] .chain = true := by decide
def e701156806274 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e701156806274 : Closed e701156806274 ∧ code e701156806274 = 2900180061826 := by decide
theorem cert_e701156806274 : check e701156806274 [[.left],[.left]] .chain = true := by decide
def e701156806370 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701156806370 : Closed e701156806370 ∧ code e701156806370 = 2900180061922 := by decide
theorem cert_e701156806370 : check e701156806370 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156806498 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e701156806498 : Closed e701156806498 ∧ code e701156806498 = 2900180062050 := by decide
theorem cert_e701156806498 : check e701156806498 [[.left],[.left],[]] .sourceHead = true := by decide
def e701156808730 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e701156808730 : Closed e701156808730 ∧ code e701156808730 = 2900180064282 := by decide
theorem cert_e701156808730 : check e701156808730 [[.left]] .chain = true := by decide
def e701157174146 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e701157174146 : Closed e701157174146 ∧ code e701157174146 = 2900180429698 := by decide
theorem cert_e701157174146 : check e701157174146 [[.left],[.left]] .chain = true := by decide
def e701157174914 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701157174914 : Closed e701157174914 ∧ code e701157174914 = 2900180430466 := by decide
theorem cert_e701157174914 : check e701157174914 [[.left],[.left]] .chain = true := by decide
def e701157175010 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701157175010 : Closed e701157175010 ∧ code e701157175010 = 2900180430562 := by decide
theorem cert_e701157175010 : check e701157175010 [[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e701157177986 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701157177986 : Closed e701157177986 ∧ code e701157177986 = 2900180433538 := by decide
theorem cert_e701157177986 : check e701157177986 [[.left],[.left]] .chain = true := by decide
def e701157178082 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701157178082 : Closed e701157178082 ∧ code e701157178082 = 2900180433634 := by decide
theorem cert_e701157178082 : check e701157178082 [[.left],[.left],[],[.under],[.under,.left]] .chain = true := by decide
def e701157178274 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701157178274 : Closed e701157178274 ∧ code e701157178274 = 2900180433826 := by decide
theorem cert_e701157178274 : check e701157178274 [[.left],[.left],[],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e701157186434 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.var 0))))
theorem wire_e701157186434 : Closed e701157186434 ∧ code e701157186434 = 2900180441986 := by decide
theorem cert_e701157186434 : check e701157186434 [[.left],[.left]] .chain = true := by decide
def e701157187202 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e701157187202 : Closed e701157187202 ∧ code e701157187202 = 2900180442754 := by decide
theorem cert_e701157187202 : check e701157187202 [[.left],[.left]] .chain = true := by decide
def e701157187298 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701157187298 : Closed e701157187298 ∧ code e701157187298 = 2900180442850 := by decide
theorem cert_e701157187298 : check e701157187298 [[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e701157193754 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e701157193754 : Closed e701157193754 ∧ code e701157193754 = 2900180449306 := by decide
theorem cert_e701157193754 : check e701157193754 [[.left]] .chain = true := by decide
def e701157205634 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e701157205634 : Closed e701157205634 ∧ code e701157205634 = 2900180461186 := by decide
theorem cert_e701157205634 : check e701157205634 [[.left],[.left]] .chain = true := by decide
def e701157205730 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701157205730 : Closed e701157205730 ∧ code e701157205730 = 2900180461282 := by decide
theorem cert_e701157205730 : check e701157205730 [[.left],[.left],[],[.under],[.under]] .three = true := by decide
def e701157205922 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701157205922 : Closed e701157205922 ∧ code e701157205922 = 2900180461474 := by decide
theorem cert_e701157205922 : check e701157205922 [[.left],[.left],[],[.under],[.under]] .three = true := by decide
def e701157206042 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e701157206042 : Closed e701157206042 ∧ code e701157206042 = 2900180461594 := by decide
theorem cert_e701157206042 : check e701157206042 [[.left]] .chain = true := by decide
def e701157389698 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e701157389698 : Closed e701157389698 ∧ code e701157389698 = 2900180645250 := by decide
theorem cert_e701157389698 : check e701157389698 [[.left],[.left]] .chain = true := by decide
def e701157389954 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701157389954 : Closed e701157389954 ∧ code e701157389954 = 2900180645506 := by decide
theorem cert_e701157389954 : check e701157389954 [[.left],[.left]] .chain = true := by decide
def e701157390050 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701157390050 : Closed e701157390050 ∧ code e701157390050 = 2900180645602 := by decide
theorem cert_e701157390050 : check e701157390050 [[.left],[.left],[],[.under]] .three = true := by decide
def e701157390178 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e701157390178 : Closed e701157390178 ∧ code e701157390178 = 2900180645730 := by decide
theorem cert_e701157390178 : check e701157390178 [[.left],[.left],[],[.under]] .three = true := by decide
end Blc.Floor41
