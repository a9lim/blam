import Extra41
import Batch146
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness605795414814
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 3
private def u5 := Term.lam u4
private def u6 := Term.app u0 u5
private def u7 := Term.app u3 u6
private def u8 := Term.lam u7
private def u9 := Term.app u3 u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605795414814 : ¬ IsSelfInterpreter e605795414814 := by
  intro he
  have h : replay [] e605795414814 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605795414814
end Witness605795414814
namespace Witness605795414982
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.lam u3
private def u6 := Term.app u4 u5
private def u7 := Term.app u3 u6
private def u8 := Term.lam u7
private def u9 := Term.app u3 u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605795414982 : ¬ IsSelfInterpreter e605795414982 := by
  intro he
  have h : replay [] e605795414982 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605795414982
end Witness605795414982
namespace Witness605795416462
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.lam u4
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.app u3 u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605795416462 : ¬ IsSelfInterpreter e605795416462 := by
  intro he
  have h : replay [] e605795416462 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605795416462
end Witness605795416462
namespace Witness605795416518
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.lam u3
private def u6 := Term.app u3 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.app u3 u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605795416518 : ¬ IsSelfInterpreter e605795416518 := by
  intro he
  have h : replay [] e605795416518 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605795416518
end Witness605795416518
namespace Witness605803261370
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u0 u3
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605803261370 : ¬ IsSelfInterpreter e605803261370 := by
  intro he
  have h : replay [] e605803261370 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605803261370
end Witness605803261370
namespace Witness605803261626
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u3 u0
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605803261626 : ¬ IsSelfInterpreter e605803261626 := by
  intro he
  have h : replay [] e605803261626 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605803261626
end Witness605803261626
namespace Witness605803262906
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.app u0 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u14 := Term.app u0 u3
private theorem sou3 : SO u3 := SO.var 1
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.app sou3 sou4
private theorem sou6 : SO u6 := SO.app sou0 sou5
private theorem sou14 : SO u14 := SO.app sou0 sou3
private theorem sou7 : SO u7 := SO.lam (r := u14) (g := u14) sou6 sou14 (by decide) (by decide)
private theorem sou8 : SO u8 := SO.lam (r := u0) (g := u7) sou7 sou0 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou10 : SO u10 := SO.app sou9 sou0
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605803262906 : ¬ IsSelfInterpreter e605803262906 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605803262906
end Witness605803262906
namespace Witness605803262938
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u3 u4
private def u6 := Term.app u0 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u14 := Term.app u4 u0
private def u15 := Term.app u0 u4
private theorem sou3 : SO u3 := SO.var 2
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.app sou3 sou4
private theorem sou6 : SO u6 := SO.app sou0 sou5
private theorem sou14 : SO u14 := SO.app sou4 sou0
private theorem sou7 : SO u7 := SO.lam (r := u14) (g := u15) sou6 sou14 (by decide) (by decide)
private theorem sou8 : SO u8 := SO.lam (r := u0) (g := u7) sou7 sou0 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou10 : SO u10 := SO.app sou9 sou0
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605803262938 : ¬ IsSelfInterpreter e605803262938 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605803262938
end Witness605803262938
end Blc.Floor41
