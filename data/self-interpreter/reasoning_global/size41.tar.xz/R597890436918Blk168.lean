import R597890436918Data
namespace Certgen.R597890436918
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl2016 : FloorIndex.rangeOK validState 2016 12 = true := by decide +kernel
theorem bl2028 : FloorIndex.rangeOK validState 2028 12 = true := by decide +kernel
theorem bl2040 : FloorIndex.rangeOK validState 2040 12 = true := by decide +kernel
theorem bl2052 : FloorIndex.rangeOK validState 2052 12 = true := by decide +kernel
theorem bl2064 : FloorIndex.rangeOK validState 2064 12 = true := by decide +kernel
theorem bl2076 : FloorIndex.rangeOK validState 2076 12 = true := by decide +kernel
end Certgen.R597890436918
