import R596279823994V0
import R596279823994K0
import R596279823994st0
import R596279823994st12
import R596279823994hs0
import R596279823994hs12
import CodeBridge
import Batch031
namespace Certgen.R596279823994
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 22,.app 2 21,.app 3 11,.lam 4,.app 5 10,.app 6 9,.app 7 8,.var 0,.var 0,.var 0,.var 0,.lam 12,.app 13 14,.var 0,.lam 15,.lam 16,.app 17 18,.var 1,.app 19 20,.var 2,.var 0,.opaque,.lam 23,.app 24 29,.app 25 26,.var 0,.lam 27,.lam 28,.var 1,.lam 30,.app 31 36,.app 32 33,.var 0,.lam 34,.lam 35,.var 1,.lam 37,.app 38 43,.app 39 40,.var 0,.lam 41,.lam 42,.var 0,.lam 44,.app 45 50,.app 46 47,.var 0,.lam 48,.lam 49,.var 1,.opaque]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (V20[i-20]?.getD []))
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (if i < 40 then (K20[i-20]?.getD []) else (K40[i-40]?.getD [])))
def st (i : Nat) : AState := if i < 264 then (if i < 140 then (if i < 60 then (if i < 20 then (st0[i-0]?.getD entry) else (if i < 40 then (st20[i-20]?.getD entry) else (st40[i-40]?.getD entry))) else (if i < 100 then (if i < 80 then (st60[i-60]?.getD entry) else (st80[i-80]?.getD entry)) else (if i < 120 then (st100[i-100]?.getD entry) else (st120[i-120]?.getD entry)))) else (if i < 200 then (if i < 160 then (st140[i-140]?.getD entry) else (if i < 180 then (st160[i-160]?.getD entry) else (st180[i-180]?.getD entry))) else (if i < 240 then (if i < 220 then (st200[i-200]?.getD entry) else (st220[i-220]?.getD entry)) else (if i < 260 then (st240[i-240]?.getD entry) else (st260[i-260]?.getD entry))))) else entry
def hs (i : Nat) : List Nat := (if i < 140 then (if i < 60 then (if i < 20 then (hs0[i-0]?.getD []) else (if i < 40 then (hs20[i-20]?.getD []) else (hs40[i-40]?.getD []))) else (if i < 100 then (if i < 80 then (hs60[i-60]?.getD []) else (hs80[i-80]?.getD [])) else (if i < 120 then (hs100[i-100]?.getD []) else (hs120[i-120]?.getD [])))) else (if i < 200 then (if i < 160 then (hs140[i-140]?.getD []) else (if i < 180 then (hs160[i-160]?.getD []) else (hs180[i-180]?.getD []))) else (if i < 240 then (if i < 220 then (hs200[i-200]?.getD []) else (hs220[i-220]?.getD [])) else (if i < 260 then (hs240[i-240]?.getD []) else (hs260[i-260]?.getD [])))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R596279823994
