import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e602906407710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e602906407710 : Closed e602906407710 ∧ code e602906407710 = 2801929663262 := by decide
theorem cert_e602906407710 : check e602906407710 [[],[]] .smaller = true := by decide
def e602906407878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e602906407878 : Closed e602906407878 ∧ code e602906407878 = 2801929663430 := by decide
theorem cert_e602906407878 : check e602906407878 [[],[]] .smaller = true := by decide
def e602906409358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e602906409358 : Closed e602906409358 ∧ code e602906409358 = 2801929664910 := by decide
theorem cert_e602906409358 : check e602906409358 [[],[]] .smaller = true := by decide
def e602906409414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e602906409414 : Closed e602906409414 ∧ code e602906409414 = 2801929664966 := by decide
theorem cert_e602906409414 : check e602906409414 [[],[]] .smaller = true := by decide
def e602906412654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e602906412654 : Closed e602906412654 ∧ code e602906412654 = 2801929668206 := by decide
theorem cert_e602906412654 : check e602906412654 [[],[]] .smaller = true := by decide
def e602906412666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e602906412666 : Closed e602906412666 ∧ code e602906412666 = 2801929668218 := by decide
theorem cert_e602906412666 : check e602906412666 [[],[]] .smaller = true := by decide
def e602906412954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e602906412954 : Closed e602906412954 ∧ code e602906412954 = 2801929668506 := by decide
theorem cert_e602906412954 : check e602906412954 [[],[]] .smaller = true := by decide
def e602906414190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e602906414190 : Closed e602906414190 ∧ code e602906414190 = 2801929669742 := by decide
theorem cert_e602906414190 : check e602906414190 [[],[]] .smaller = true := by decide
def e602906414202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e602906414202 : Closed e602906414202 ∧ code e602906414202 = 2801929669754 := by decide
theorem cert_e602906414202 : check e602906414202 [[],[]] .smaller = true := by decide
def e602906414366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e602906414366 : Closed e602906414366 ∧ code e602906414366 = 2801929669918 := by decide
theorem cert_e602906414366 : check e602906414366 [[],[]] .smaller = true := by decide
def e602906414534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e602906414534 : Closed e602906414534 ∧ code e602906414534 = 2801929670086 := by decide
theorem cert_e602906414534 : check e602906414534 [[],[]] .smaller = true := by decide
def e602906414874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e602906414874 : Closed e602906414874 ∧ code e602906414874 = 2801929670426 := by decide
theorem cert_e602906414874 : check e602906414874 [[],[]] .smaller = true := by decide
def e602906414918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e602906414918 : Closed e602906414918 ∧ code e602906414918 = 2801929670470 := by decide
theorem cert_e602906414918 : check e602906414918 [[],[]] .smaller = true := by decide
def e602906415902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e602906415902 : Closed e602906415902 ∧ code e602906415902 = 2801929671454 := by decide
theorem cert_e602906415902 : check e602906415902 [[],[]] .smaller = true := by decide
def e602906416070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e602906416070 : Closed e602906416070 ∧ code e602906416070 = 2801929671622 := by decide
theorem cert_e602906416070 : check e602906416070 [[],[]] .smaller = true := by decide
def e602906418374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e602906418374 : Closed e602906418374 ∧ code e602906418374 = 2801929673926 := by decide
theorem cert_e602906418374 : check e602906418374 [[],[]] .smaller = true := by decide
def e602906420022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e602906420022 : Closed e602906420022 ∧ code e602906420022 = 2801929675574 := by decide
theorem cert_e602906420022 : check e602906420022 [[],[]] .smaller = true := by decide
def e602906420026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e602906420026 : Closed e602906420026 ∧ code e602906420026 = 2801929675578 := by decide
theorem cert_e602906420026 : check e602906420026 [[],[]] .smaller = true := by decide
def e602906420122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e602906420122 : Closed e602906420122 ∧ code e602906420122 = 2801929675674 := by decide
theorem cert_e602906420122 : check e602906420122 [[],[]] .smaller = true := by decide
def e602906420790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e602906420790 : Closed e602906420790 ∧ code e602906420790 = 2801929676342 := by decide
theorem cert_e602906420790 : check e602906420790 [[],[]] .smaller = true := by decide
def e602906420794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e602906420794 : Closed e602906420794 ∧ code e602906420794 = 2801929676346 := by decide
theorem cert_e602906420794 : check e602906420794 [[],[]] .smaller = true := by decide
def e602906420878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e602906420878 : Closed e602906420878 ∧ code e602906420878 = 2801929676430 := by decide
theorem cert_e602906420878 : check e602906420878 [[],[]] .smaller = true := by decide
def e602906420934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e602906420934 : Closed e602906420934 ∧ code e602906420934 = 2801929676486 := by decide
theorem cert_e602906420934 : check e602906420934 [[],[]] .smaller = true := by decide
def e602906421018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e602906421018 : Closed e602906421018 ∧ code e602906421018 = 2801929676570 := by decide
theorem cert_e602906421018 : check e602906421018 [[],[]] .smaller = true := by decide
def e602906421062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e602906421062 : Closed e602906421062 ∧ code e602906421062 = 2801929676614 := by decide
theorem cert_e602906421062 : check e602906421062 [[],[]] .smaller = true := by decide
def e602906421646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e602906421646 : Closed e602906421646 ∧ code e602906421646 = 2801929677198 := by decide
theorem cert_e602906421646 : check e602906421646 [[],[]] .smaller = true := by decide
def e602906421702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e602906421702 : Closed e602906421702 ∧ code e602906421702 = 2801929677254 := by decide
theorem cert_e602906421702 : check e602906421702 [[],[]] .smaller = true := by decide
def e602906422470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e602906422470 : Closed e602906422470 ∧ code e602906422470 = 2801929678022 := by decide
theorem cert_e602906422470 : check e602906422470 [[],[]] .smaller = true := by decide
def e602906433246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e602906433246 : Closed e602906433246 ∧ code e602906433246 = 2801929688798 := by decide
theorem cert_e602906433246 : check e602906433246 [[],[]] .smaller = true := by decide
def e602906433270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e602906433270 : Closed e602906433270 ∧ code e602906433270 = 2801929688822 := by decide
theorem cert_e602906433270 : check e602906433270 [[],[]] .smaller = true := by decide
def e602906433374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e602906433374 : Closed e602906433374 ∧ code e602906433374 = 2801929688926 := by decide
theorem cert_e602906433374 : check e602906433374 [[],[]] .smaller = true := by decide
def e602906433402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e602906433402 : Closed e602906433402 ∧ code e602906433402 = 2801929688954 := by decide
theorem cert_e602906433402 : check e602906433402 [[],[]] .smaller = true := by decide
def e602906433494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e602906433494 : Closed e602906433494 ∧ code e602906433494 = 2801929689046 := by decide
theorem cert_e602906433494 : check e602906433494 [[],[]] .smaller = true := by decide
def e602906433498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e602906433498 : Closed e602906433498 ∧ code e602906433498 = 2801929689050 := by decide
theorem cert_e602906433498 : check e602906433498 [[],[]] .smaller = true := by decide
def e602906434014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e602906434014 : Closed e602906434014 ∧ code e602906434014 = 2801929689566 := by decide
theorem cert_e602906434014 : check e602906434014 [[],[]] .smaller = true := by decide
def e602906434038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e602906434038 : Closed e602906434038 ∧ code e602906434038 = 2801929689590 := by decide
theorem cert_e602906434038 : check e602906434038 [[],[]] .smaller = true := by decide
def e602906434782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e602906434782 : Closed e602906434782 ∧ code e602906434782 = 2801929690334 := by decide
theorem cert_e602906434782 : check e602906434782 [[],[]] .smaller = true := by decide
def e602906434810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e602906434810 : Closed e602906434810 ∧ code e602906434810 = 2801929690362 := by decide
theorem cert_e602906434810 : check e602906434810 [[],[]] .smaller = true := by decide
def e602906435382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e602906435382 : Closed e602906435382 ∧ code e602906435382 = 2801929690934 := by decide
theorem cert_e602906435382 : check e602906435382 [[],[]] .smaller = true := by decide
def e602906435386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e602906435386 : Closed e602906435386 ∧ code e602906435386 = 2801929690938 := by decide
theorem cert_e602906435386 : check e602906435386 [[],[]] .smaller = true := by decide
def e602906450158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e602906450158 : Closed e602906450158 ∧ code e602906450158 = 2801929705710 := by decide
theorem cert_e602906450158 : check e602906450158 [[],[]] .smaller = true := by decide
def e602906450166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e602906450166 : Closed e602906450166 ∧ code e602906450166 = 2801929705718 := by decide
theorem cert_e602906450166 : check e602906450166 [[],[]] .smaller = true := by decide
def e602906450718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e602906450718 : Closed e602906450718 ∧ code e602906450718 = 2801929706270 := by decide
theorem cert_e602906450718 : check e602906450718 [[],[]] .smaller = true := by decide
def e602906450830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e602906450830 : Closed e602906450830 ∧ code e602906450830 = 2801929706382 := by decide
theorem cert_e602906450830 : check e602906450830 [[],[]] .smaller = true := by decide
def e602906451054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e602906451054 : Closed e602906451054 ∧ code e602906451054 = 2801929706606 := by decide
theorem cert_e602906451054 : check e602906451054 [[],[]] .smaller = true := by decide
def e602906451066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e602906451066 : Closed e602906451066 ∧ code e602906451066 = 2801929706618 := by decide
theorem cert_e602906451066 : check e602906451066 [[],[]] .smaller = true := by decide
def e602906451230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e602906451230 : Closed e602906451230 ∧ code e602906451230 = 2801929706782 := by decide
theorem cert_e602906451230 : check e602906451230 [[],[]] .smaller = true := by decide
def e602906451398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e602906451398 : Closed e602906451398 ∧ code e602906451398 = 2801929706950 := by decide
theorem cert_e602906451398 : check e602906451398 [[],[]] .smaller = true := by decide
def e602906451510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e602906451510 : Closed e602906451510 ∧ code e602906451510 = 2801929707062 := by decide
theorem cert_e602906451510 : check e602906451510 [[],[]] .smaller = true := by decide
def e602906451514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e602906451514 : Closed e602906451514 ∧ code e602906451514 = 2801929707066 := by decide
theorem cert_e602906451514 : check e602906451514 [[],[]] .smaller = true := by decide
def e602906451598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e602906451598 : Closed e602906451598 ∧ code e602906451598 = 2801929707150 := by decide
theorem cert_e602906451598 : check e602906451598 [[],[]] .smaller = true := by decide
def e602906451654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e602906451654 : Closed e602906451654 ∧ code e602906451654 = 2801929707206 := by decide
theorem cert_e602906451654 : check e602906451654 [[],[]] .smaller = true := by decide
def e602906453790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e602906453790 : Closed e602906453790 ∧ code e602906453790 = 2801929709342 := by decide
theorem cert_e602906453790 : check e602906453790 [[],[]] .smaller = true := by decide
def e602906453902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e602906453902 : Closed e602906453902 ∧ code e602906453902 = 2801929709454 := by decide
theorem cert_e602906453902 : check e602906453902 [[],[]] .smaller = true := by decide
def e602906456862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e602906456862 : Closed e602906456862 ∧ code e602906456862 = 2801929712414 := by decide
theorem cert_e602906456862 : check e602906456862 [[],[]] .smaller = true := by decide
def e602906457030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e602906457030 : Closed e602906457030 ∧ code e602906457030 = 2801929712582 := by decide
theorem cert_e602906457030 : check e602906457030 [[],[]] .smaller = true := by decide
def e602906458510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e602906458510 : Closed e602906458510 ∧ code e602906458510 = 2801929714062 := by decide
theorem cert_e602906458510 : check e602906458510 [[],[]] .smaller = true := by decide
def e602906458566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e602906458566 : Closed e602906458566 ∧ code e602906458566 = 2801929714118 := by decide
theorem cert_e602906458566 : check e602906458566 [[],[]] .smaller = true := by decide
def e602906495854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e602906495854 : Closed e602906495854 ∧ code e602906495854 = 2801929751406 := by decide
theorem cert_e602906495854 : check e602906495854 [[],[]] .smaller = true := by decide
def e602906495862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e602906495862 : Closed e602906495862 ∧ code e602906495862 = 2801929751414 := by decide
theorem cert_e602906495862 : check e602906495862 [[],[]] .smaller = true := by decide
def e602906495918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e602906495918 : Closed e602906495918 ∧ code e602906495918 = 2801929751470 := by decide
theorem cert_e602906495918 : check e602906495918 [[],[]] .smaller = true := by decide
def e602906495930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e602906495930 : Closed e602906495930 ∧ code e602906495930 = 2801929751482 := by decide
theorem cert_e602906495930 : check e602906495930 [[],[]] .smaller = true := by decide
def e602906495958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e602906495958 : Closed e602906495958 ∧ code e602906495958 = 2801929751510 := by decide
theorem cert_e602906495958 : check e602906495958 [[],[]] .smaller = true := by decide
def e602906495962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e602906495962 : Closed e602906495962 ∧ code e602906495962 = 2801929751514 := by decide
theorem cert_e602906495962 : check e602906495962 [[],[]] .smaller = true := by decide
def e602906496238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e602906496238 : Closed e602906496238 ∧ code e602906496238 = 2801929751790 := by decide
theorem cert_e602906496238 : check e602906496238 [[],[]] .smaller = true := by decide
def e602906496246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e602906496246 : Closed e602906496246 ∧ code e602906496246 = 2801929751798 := by decide
theorem cert_e602906496246 : check e602906496246 [[],[]] .smaller = true := by decide
def e602906496622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e602906496622 : Closed e602906496622 ∧ code e602906496622 = 2801929752174 := by decide
theorem cert_e602906496622 : check e602906496622 [[],[]] .smaller = true := by decide
def e602906496634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e602906496634 : Closed e602906496634 ∧ code e602906496634 = 2801929752186 := by decide
theorem cert_e602906496634 : check e602906496634 [[],[]] .smaller = true := by decide
def e602906496822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e602906496822 : Closed e602906496822 ∧ code e602906496822 = 2801929752374 := by decide
theorem cert_e602906496822 : check e602906496822 [[],[]] .smaller = true := by decide
def e602906496826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e602906496826 : Closed e602906496826 ∧ code e602906496826 = 2801929752378 := by decide
theorem cert_e602906496826 : check e602906496826 [[],[]] .smaller = true := by decide
def e602906504302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e602906504302 : Closed e602906504302 ∧ code e602906504302 = 2801929759854 := by decide
theorem cert_e602906504302 : check e602906504302 [[],[]] .smaller = true := by decide
def e602906504314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e602906504314 : Closed e602906504314 ∧ code e602906504314 = 2801929759866 := by decide
theorem cert_e602906504314 : check e602906504314 [[],[]] .smaller = true := by decide
def e602906504478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e602906504478 : Closed e602906504478 ∧ code e602906504478 = 2801929760030 := by decide
theorem cert_e602906504478 : check e602906504478 [[],[]] .smaller = true := by decide
def e602906504646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e602906504646 : Closed e602906504646 ∧ code e602906504646 = 2801929760198 := by decide
theorem cert_e602906504646 : check e602906504646 [[],[]] .smaller = true := by decide
def e602906504986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e602906504986 : Closed e602906504986 ∧ code e602906504986 = 2801929760538 := by decide
theorem cert_e602906504986 : check e602906504986 [[],[]] .smaller = true := by decide
def e602906505030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e602906505030 : Closed e602906505030 ∧ code e602906505030 = 2801929760582 := by decide
theorem cert_e602906505030 : check e602906505030 [[],[]] .smaller = true := by decide
def e602906506014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e602906506014 : Closed e602906506014 ∧ code e602906506014 = 2801929761566 := by decide
theorem cert_e602906506014 : check e602906506014 [[],[]] .smaller = true := by decide
def e602906506182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e602906506182 : Closed e602906506182 ∧ code e602906506182 = 2801929761734 := by decide
theorem cert_e602906506182 : check e602906506182 [[],[]] .smaller = true := by decide
def e602906508486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e602906508486 : Closed e602906508486 ∧ code e602906508486 = 2801929764038 := by decide
theorem cert_e602906508486 : check e602906508486 [[],[]] .smaller = true := by decide
def e602906531382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e602906531382 : Closed e602906531382 ∧ code e602906531382 = 2801929786934 := by decide
theorem cert_e602906531382 : check e602906531382 [[],[]] .smaller = true := by decide
def e602906531386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e602906531386 : Closed e602906531386 ∧ code e602906531386 = 2801929786938 := by decide
theorem cert_e602906531386 : check e602906531386 [[],[]] .smaller = true := by decide
def e602906531470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e602906531470 : Closed e602906531470 ∧ code e602906531470 = 2801929787022 := by decide
theorem cert_e602906531470 : check e602906531470 [[],[]] .smaller = true := by decide
def e602906531526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e602906531526 : Closed e602906531526 ∧ code e602906531526 = 2801929787078 := by decide
theorem cert_e602906531526 : check e602906531526 [[],[]] .smaller = true := by decide
def e602906531610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e602906531610 : Closed e602906531610 ∧ code e602906531610 = 2801929787162 := by decide
theorem cert_e602906531610 : check e602906531610 [[],[]] .smaller = true := by decide
def e602906531654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e602906531654 : Closed e602906531654 ∧ code e602906531654 = 2801929787206 := by decide
theorem cert_e602906531654 : check e602906531654 [[],[]] .smaller = true := by decide
def e602906532238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e602906532238 : Closed e602906532238 ∧ code e602906532238 = 2801929787790 := by decide
theorem cert_e602906532238 : check e602906532238 [[],[]] .smaller = true := by decide
def e602906532294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e602906532294 : Closed e602906532294 ∧ code e602906532294 = 2801929787846 := by decide
theorem cert_e602906532294 : check e602906532294 [[],[]] .smaller = true := by decide
def e602906533062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e602906533062 : Closed e602906533062 ∧ code e602906533062 = 2801929788614 := by decide
theorem cert_e602906533062 : check e602906533062 [[],[]] .smaller = true := by decide
def e602907437934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e602907437934 : Closed e602907437934 ∧ code e602907437934 = 2801930693486 := by decide
theorem cert_e602907437934 : check e602907437934 [[],[]] .chain = true := by decide
def e602907437942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e602907437942 : Closed e602907437942 ∧ code e602907437942 = 2801930693494 := by decide
theorem cert_e602907437942 : check e602907437942 [[],[]] .chain = true := by decide
def e602907438006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e602907438006 : Closed e602907438006 ∧ code e602907438006 = 2801930693558 := by decide
theorem cert_e602907438006 : check e602907438006 [[],[]] .chain = true := by decide
def e602907438446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e602907438446 : Closed e602907438446 ∧ code e602907438446 = 2801930693998 := by decide
theorem cert_e602907438446 : check e602907438446 [[],[]] .chain = true := by decide
def e602907438454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e602907438454 : Closed e602907438454 ∧ code e602907438454 = 2801930694006 := by decide
theorem cert_e602907438454 : check e602907438454 [[],[]] .chain = true := by decide
def e602907438510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e602907438510 : Closed e602907438510 ∧ code e602907438510 = 2801930694062 := by decide
theorem cert_e602907438510 : check e602907438510 [[],[]] .chain = true := by decide
def e602907438522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e602907438522 : Closed e602907438522 ∧ code e602907438522 = 2801930694074 := by decide
theorem cert_e602907438522 : check e602907438522 [[],[]] .chain = true := by decide
def e602907438550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e602907438550 : Closed e602907438550 ∧ code e602907438550 = 2801930694102 := by decide
theorem cert_e602907438550 : check e602907438550 [[],[]] .chain = true := by decide
def e602907438554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e602907438554 : Closed e602907438554 ∧ code e602907438554 = 2801930694106 := by decide
theorem cert_e602907438554 : check e602907438554 [[],[]] .chain = true := by decide
def e602907438774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e602907438774 : Closed e602907438774 ∧ code e602907438774 = 2801930694326 := by decide
theorem cert_e602907438774 : check e602907438774 [[],[]] .chain = true := by decide
def e602907438806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e602907438806 : Closed e602907438806 ∧ code e602907438806 = 2801930694358 := by decide
theorem cert_e602907438806 : check e602907438806 [[],[]] .chain = true := by decide
def e602907438810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e602907438810 : Closed e602907438810 ∧ code e602907438810 = 2801930694362 := by decide
theorem cert_e602907438810 : check e602907438810 [[],[]] .chain = true := by decide
def e602907440494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e602907440494 : Closed e602907440494 ∧ code e602907440494 = 2801930696046 := by decide
theorem cert_e602907440494 : check e602907440494 [[],[]] .chain = true := by decide
def e602907440502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e602907440502 : Closed e602907440502 ∧ code e602907440502 = 2801930696054 := by decide
theorem cert_e602907440502 : check e602907440502 [[],[]] .chain = true := by decide
def e602907440558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e602907440558 : Closed e602907440558 ∧ code e602907440558 = 2801930696110 := by decide
theorem cert_e602907440558 : check e602907440558 [[],[]] .chain = true := by decide
def e602907440570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e602907440570 : Closed e602907440570 ∧ code e602907440570 = 2801930696122 := by decide
theorem cert_e602907440570 : check e602907440570 [[],[]] .chain = true := by decide
def e602907440598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e602907440598 : Closed e602907440598 ∧ code e602907440598 = 2801930696150 := by decide
theorem cert_e602907440598 : check e602907440598 [[],[]] .chain = true := by decide
def e602907440602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e602907440602 : Closed e602907440602 ∧ code e602907440602 = 2801930696154 := by decide
theorem cert_e602907440602 : check e602907440602 [[],[]] .chain = true := by decide
def e602907440814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e602907440814 : Closed e602907440814 ∧ code e602907440814 = 2801930696366 := by decide
theorem cert_e602907440814 : check e602907440814 [[],[]] .chain = true := by decide
def e602907440826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e602907440826 : Closed e602907440826 ∧ code e602907440826 = 2801930696378 := by decide
theorem cert_e602907440826 : check e602907440826 [[],[]] .chain = true := by decide
def e602907440874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e602907440874 : Closed e602907440874 ∧ code e602907440874 = 2801930696426 := by decide
theorem cert_e602907440874 : check e602907440874 [[],[]] .chain = true := by decide
def e602907440982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e602907440982 : Closed e602907440982 ∧ code e602907440982 = 2801930696534 := by decide
theorem cert_e602907440982 : check e602907440982 [[],[]] .chain = true := by decide
def e602907440986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e602907440986 : Closed e602907440986 ∧ code e602907440986 = 2801930696538 := by decide
theorem cert_e602907440986 : check e602907440986 [[],[]] .chain = true := by decide
def e602907441002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e602907441002 : Closed e602907441002 ∧ code e602907441002 = 2801930696554 := by decide
theorem cert_e602907441002 : check e602907441002 [[],[]] .chain = true := by decide
def e602907441846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e602907441846 : Closed e602907441846 ∧ code e602907441846 = 2801930697398 := by decide
theorem cert_e602907441846 : check e602907441846 [[],[]] .chain = true := by decide
def e602907441878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e602907441878 : Closed e602907441878 ∧ code e602907441878 = 2801930697430 := by decide
theorem cert_e602907441878 : check e602907441878 [[],[]] .chain = true := by decide
def e602907441882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e602907441882 : Closed e602907441882 ∧ code e602907441882 = 2801930697434 := by decide
theorem cert_e602907441882 : check e602907441882 [[],[]] .chain = true := by decide
def e602907442006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e602907442006 : Closed e602907442006 ∧ code e602907442006 = 2801930697558 := by decide
theorem cert_e602907442006 : check e602907442006 [[],[]] .chain = true := by decide
def e602907442010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e602907442010 : Closed e602907442010 ∧ code e602907442010 = 2801930697562 := by decide
theorem cert_e602907442010 : check e602907442010 [[],[]] .chain = true := by decide
def e602907442026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e602907442026 : Closed e602907442026 ∧ code e602907442026 = 2801930697578 := by decide
theorem cert_e602907442026 : check e602907442026 [[],[]] .chain = true := by decide
def e602907447022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2))))))
theorem wire_e602907447022 : Closed e602907447022 ∧ code e602907447022 = 2801930702574 := by decide
theorem cert_e602907447022 : check e602907447022 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e602907447150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2))))))
theorem wire_e602907447150 : Closed e602907447150 ∧ code e602907447150 = 2801930702702 := by decide
theorem cert_e602907447150 : check e602907447150 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602907447158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1))))))
theorem wire_e602907447158 : Closed e602907447158 ∧ code e602907447158 = 2801930702710 := by decide
theorem cert_e602907447158 : check e602907447158 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602907450222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e602907450222 : Closed e602907450222 ∧ code e602907450222 = 2801930705774 := by decide
theorem cert_e602907450222 : check e602907450222 [[],[]] .chain = true := by decide
def e602907450230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e602907450230 : Closed e602907450230 ∧ code e602907450230 = 2801930705782 := by decide
theorem cert_e602907450230 : check e602907450230 [[],[]] .chain = true := by decide
def e602907450294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e602907450294 : Closed e602907450294 ∧ code e602907450294 = 2801930705846 := by decide
theorem cert_e602907450294 : check e602907450294 [[],[]] .chain = true := by decide
def e602907450734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e602907450734 : Closed e602907450734 ∧ code e602907450734 = 2801930706286 := by decide
theorem cert_e602907450734 : check e602907450734 [[],[]] .chain = true := by decide
def e602907450742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e602907450742 : Closed e602907450742 ∧ code e602907450742 = 2801930706294 := by decide
theorem cert_e602907450742 : check e602907450742 [[],[]] .chain = true := by decide
def e602907450798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e602907450798 : Closed e602907450798 ∧ code e602907450798 = 2801930706350 := by decide
theorem cert_e602907450798 : check e602907450798 [[],[]] .chain = true := by decide
def e602907450810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e602907450810 : Closed e602907450810 ∧ code e602907450810 = 2801930706362 := by decide
theorem cert_e602907450810 : check e602907450810 [[],[]] .chain = true := by decide
def e602907450838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e602907450838 : Closed e602907450838 ∧ code e602907450838 = 2801930706390 := by decide
theorem cert_e602907450838 : check e602907450838 [[],[]] .chain = true := by decide
def e602907450842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e602907450842 : Closed e602907450842 ∧ code e602907450842 = 2801930706394 := by decide
theorem cert_e602907450842 : check e602907450842 [[],[]] .chain = true := by decide
def e602907451062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e602907451062 : Closed e602907451062 ∧ code e602907451062 = 2801930706614 := by decide
theorem cert_e602907451062 : check e602907451062 [[],[]] .chain = true := by decide
def e602907451094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e602907451094 : Closed e602907451094 ∧ code e602907451094 = 2801930706646 := by decide
theorem cert_e602907451094 : check e602907451094 [[],[]] .chain = true := by decide
def e602907451098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e602907451098 : Closed e602907451098 ∧ code e602907451098 = 2801930706650 := by decide
theorem cert_e602907451098 : check e602907451098 [[],[]] .chain = true := by decide
def e602907453294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e602907453294 : Closed e602907453294 ∧ code e602907453294 = 2801930708846 := by decide
theorem cert_e602907453294 : check e602907453294 [[],[]] .chain = true := by decide
def e602907453302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e602907453302 : Closed e602907453302 ∧ code e602907453302 = 2801930708854 := by decide
theorem cert_e602907453302 : check e602907453302 [[],[]] .chain = true := by decide
def e602907453366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e602907453366 : Closed e602907453366 ∧ code e602907453366 = 2801930708918 := by decide
theorem cert_e602907453366 : check e602907453366 [[],[]] .chain = true := by decide
def e602907454702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e602907454702 : Closed e602907454702 ∧ code e602907454702 = 2801930710254 := by decide
theorem cert_e602907454702 : check e602907454702 [[],[]] .chain = true := by decide
def e602907454710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e602907454710 : Closed e602907454710 ∧ code e602907454710 = 2801930710262 := by decide
theorem cert_e602907454710 : check e602907454710 [[],[]] .chain = true := by decide
def e602907455094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e602907455094 : Closed e602907455094 ∧ code e602907455094 = 2801930710646 := by decide
theorem cert_e602907455094 : check e602907455094 [[],[]] .chain = true := by decide
def e602907455982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2))))))
theorem wire_e602907455982 : Closed e602907455982 ∧ code e602907455982 = 2801930711534 := by decide
theorem cert_e602907455982 : check e602907455982 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e602907456366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e602907456366 : Closed e602907456366 ∧ code e602907456366 = 2801930711918 := by decide
theorem cert_e602907456366 : check e602907456366 [[],[]] .chain = true := by decide
def e602907456374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e602907456374 : Closed e602907456374 ∧ code e602907456374 = 2801930711926 := by decide
theorem cert_e602907456374 : check e602907456374 [[],[]] .chain = true := by decide
def e602907456430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e602907456430 : Closed e602907456430 ∧ code e602907456430 = 2801930711982 := by decide
theorem cert_e602907456430 : check e602907456430 [[],[]] .chain = true := by decide
def e602907456442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e602907456442 : Closed e602907456442 ∧ code e602907456442 = 2801930711994 := by decide
theorem cert_e602907456442 : check e602907456442 [[],[]] .chain = true := by decide
def e602907456470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e602907456470 : Closed e602907456470 ∧ code e602907456470 = 2801930712022 := by decide
theorem cert_e602907456470 : check e602907456470 [[],[]] .chain = true := by decide
def e602907456474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e602907456474 : Closed e602907456474 ∧ code e602907456474 = 2801930712026 := by decide
theorem cert_e602907456474 : check e602907456474 [[],[]] .chain = true := by decide
def e602907456750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e602907456750 : Closed e602907456750 ∧ code e602907456750 = 2801930712302 := by decide
theorem cert_e602907456750 : check e602907456750 [[],[]] .chain = true := by decide
def e602907456758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e602907456758 : Closed e602907456758 ∧ code e602907456758 = 2801930712310 := by decide
theorem cert_e602907456758 : check e602907456758 [[],[]] .chain = true := by decide
def e602907457134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e602907457134 : Closed e602907457134 ∧ code e602907457134 = 2801930712686 := by decide
theorem cert_e602907457134 : check e602907457134 [[],[]] .chain = true := by decide
def e602907457146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e602907457146 : Closed e602907457146 ∧ code e602907457146 = 2801930712698 := by decide
theorem cert_e602907457146 : check e602907457146 [[],[]] .chain = true := by decide
def e602907457310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e602907457310 : Closed e602907457310 ∧ code e602907457310 = 2801930712862 := by decide
theorem cert_e602907457310 : check e602907457310 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e602907457334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e602907457334 : Closed e602907457334 ∧ code e602907457334 = 2801930712886 := by decide
theorem cert_e602907457334 : check e602907457334 [[],[]] .chain = true := by decide
def e602907457338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e602907457338 : Closed e602907457338 ∧ code e602907457338 = 2801930712890 := by decide
theorem cert_e602907457338 : check e602907457338 [[],[]] .chain = true := by decide
def e602907457774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2))))))
theorem wire_e602907457774 : Closed e602907457774 ∧ code e602907457774 = 2801930713326 := by decide
theorem cert_e602907457774 : check e602907457774 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602907457782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1))))))
theorem wire_e602907457782 : Closed e602907457782 ∧ code e602907457782 = 2801930713334 := by decide
theorem cert_e602907457782 : check e602907457782 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602907457974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e602907457974 : Closed e602907457974 ∧ code e602907457974 = 2801930713526 := by decide
theorem cert_e602907457974 : check e602907457974 [[],[]] .chain = true := by decide
def e602907458006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e602907458006 : Closed e602907458006 ∧ code e602907458006 = 2801930713558 := by decide
theorem cert_e602907458006 : check e602907458006 [[],[]] .chain = true := by decide
def e602907458010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e602907458010 : Closed e602907458010 ∧ code e602907458010 = 2801930713562 := by decide
theorem cert_e602907458010 : check e602907458010 [[],[]] .chain = true := by decide
def e602907458166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e602907458166 : Closed e602907458166 ∧ code e602907458166 = 2801930713718 := by decide
theorem cert_e602907458166 : check e602907458166 [[],[]] .chain = true := by decide
def e602907458334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e602907458334 : Closed e602907458334 ∧ code e602907458334 = 2801930713886 := by decide
theorem cert_e602907458334 : check e602907458334 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
end Blc.Floor41
