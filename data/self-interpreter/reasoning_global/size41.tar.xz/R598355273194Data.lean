import R598355273194V0
import R598355273194K0
import R598355273194st0
import R598355273194hs0
import CodeBridge
import Batch044
namespace Certgen.R598355273194
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 22,.app 2 21,.app 3 9,.lam 4,.app 5 8,.app 6 7,.var 0,.var 0,.var 0,.lam 10,.app 11 12,.var 0,.lam 13,.lam 14,.app 15 16,.var 1,.app 17 20,.app 18 19,.var 2,.var 0,.var 0,.opaque,.lam 23,.app 24 29,.app 25 26,.var 0,.lam 27,.lam 28,.var 1,.lam 30,.app 31 36,.app 32 33,.var 0,.lam 34,.lam 35,.var 1,.lam 37,.app 38 43,.app 39 40,.var 0,.lam 41,.lam 42,.var 0,.lam 44,.app 45 50,.app 46 47,.var 0,.lam 48,.lam 49,.var 1,.opaque]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (V0[i-0]?.getD [])
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD []))
def st (i : Nat) : AState := if i < 154 then (if i < 80 then (if i < 40 then (if i < 20 then (st0[i-0]?.getD entry) else (st20[i-20]?.getD entry)) else (if i < 60 then (st40[i-40]?.getD entry) else (st60[i-60]?.getD entry))) else (if i < 120 then (if i < 100 then (st80[i-80]?.getD entry) else (st100[i-100]?.getD entry)) else (if i < 140 then (st120[i-120]?.getD entry) else (st140[i-140]?.getD entry)))) else entry
def hs (i : Nat) : List Nat := (if i < 80 then (if i < 40 then (if i < 20 then (hs0[i-0]?.getD []) else (hs20[i-20]?.getD [])) else (if i < 60 then (hs40[i-40]?.getD []) else (hs60[i-60]?.getD []))) else (if i < 120 then (if i < 100 then (hs80[i-80]?.getD []) else (hs100[i-100]?.getD [])) else (if i < 140 then (hs120[i-120]?.getD []) else (hs140[i-140]?.getD []))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R598355273194
