import Extra41
import Batch147
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness605804344954
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u0 u3
private def u5 := Term.var 2
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605804344954 : ¬ IsSelfInterpreter e605804344954 := by
  intro he
  have h : replay [] e605804344954 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605804344954
end Witness605804344954
namespace Witness605804345142
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u0 u3
private def u5 := Term.var 1
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605804345142 : ¬ IsSelfInterpreter e605804345142 := by
  intro he
  have h : replay [] e605804345142 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605804345142
end Witness605804345142
namespace Witness605804345146
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u0 u3
private def u5 := Term.var 1
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605804345146 : ¬ IsSelfInterpreter e605804345146 := by
  intro he
  have h : replay [] e605804345146 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605804345146
end Witness605804345146
namespace Witness605804345774
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u3 u1
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u0 u9
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
theorem nege605804345774 : ¬ IsSelfInterpreter e605804345774 := by
  intro he
  have h : replay [] e605804345774 = some u12 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u12) (by decide) (by decide) hj
#print axioms nege605804345774
end Witness605804345774
namespace Witness605804345786
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.app u0 u4
private def u6 := Term.app u3 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605804345786 : ¬ IsSelfInterpreter e605804345786 := by
  intro he
  have h : replay [] e605804345786 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605804345786
end Witness605804345786
namespace Witness605804345834
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.app u4 u0
private def u6 := Term.app u3 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605804345834 : ¬ IsSelfInterpreter e605804345834 := by
  intro he
  have h : replay [] e605804345834 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605804345834
end Witness605804345834
namespace Witness605804345966
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u3 u0
private def u5 := Term.var 2
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605804345966 : ¬ IsSelfInterpreter e605804345966 := by
  intro he
  have h : replay [] e605804345966 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605804345966
end Witness605804345966
namespace Witness605804345978
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u3 u0
private def u5 := Term.var 2
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605804345978 : ¬ IsSelfInterpreter e605804345978 := by
  intro he
  have h : replay [] e605804345978 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605804345978
end Witness605804345978
end Blc.Floor41
