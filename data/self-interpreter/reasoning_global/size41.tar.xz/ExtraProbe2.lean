import Extra41
import Batch030
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness565606878842
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u0 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565606878842 : ¬ IsSelfInterpreter e565606878842 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565606878842 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565606878842 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565606878842
end Witness565606878842
namespace Witness596279078254
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u1 u1
private def u4 := Term.app u3 u0
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u10 u9
private def u12 := Term.app u11 u9
private def u13 := Term.app u12 u0
private def u14 := Term.lam u0
private def u15 := Term.lam u14
private def u16 := Term.app u1 u15
private def u17 := Term.lam u2
private def u18 := Term.app u1 u17
private def u19 := Term.var 4
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u16 u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u26
private def u28 := Term.app u13 u27
private def u29 := Term.app u0 u17
private def u30 := Term.app u29 u1
private def u31 := Term.app u4 u9
private def u32 := Term.lam u31
private def u33 := Term.lam u32
private def u34 := Term.app u33 u9
private def u35 := Term.app u34 u9
private def u36 := Term.app u35 u0
private def u37 := Term.app u36 u27
theorem nege596279078254 : ¬ IsSelfInterpreter e596279078254 := by
  intro he
  have hv : NFt u30 := by decide
  have reach : Betas (Floor40.call e596279078254 u0 u2 u1 []) u30 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left]] (Floor40.call e596279078254 u0 u2 u1 []) = some u28 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u28) (u := u37) [] (by decide) (replay_sound (ps := [[.left,.left,.left],[.left,.left]]) (by decide)) j hj
#print axioms nege596279078254
end Witness596279078254
namespace Witness596279078262
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u1 u1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.app u5 u0
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u10 u9
private def u12 := Term.app u11 u9
private def u13 := Term.app u12 u0
private def u14 := Term.lam u0
private def u15 := Term.lam u14
private def u16 := Term.app u1 u15
private def u17 := Term.lam u2
private def u18 := Term.app u1 u17
private def u19 := Term.var 4
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u16 u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u26
private def u28 := Term.app u13 u27
private def u29 := Term.app u0 u17
private def u30 := Term.app u29 u1
private def u31 := Term.app u3 u9
private def u32 := Term.app u31 u0
private def u33 := Term.lam u32
private def u34 := Term.lam u33
private def u35 := Term.app u34 u9
private def u36 := Term.app u35 u9
private def u37 := Term.app u36 u0
private def u38 := Term.app u37 u27
theorem nege596279078262 : ¬ IsSelfInterpreter e596279078262 := by
  intro he
  have hv : NFt u30 := by decide
  have reach : Betas (Floor40.call e596279078262 u0 u2 u1 []) u30 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left]] (Floor40.call e596279078262 u0 u2 u1 []) = some u28 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u28) (u := u38) [] (by decide) (replay_sound (ps := [[.left,.left,.left],[.left,.left]]) (by decide)) j hj
#print axioms nege596279078262
end Witness596279078262
namespace Witness596279078318
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u1 u0
private def u4 := Term.app u3 u1
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u10 u9
private def u12 := Term.app u11 u9
private def u13 := Term.app u12 u0
private def u14 := Term.lam u0
private def u15 := Term.lam u14
private def u16 := Term.app u1 u15
private def u17 := Term.lam u2
private def u18 := Term.app u1 u17
private def u19 := Term.var 4
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u16 u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u26
private def u28 := Term.app u13 u27
private def u29 := Term.app u0 u17
private def u30 := Term.app u29 u1
private def u31 := Term.app u4 u9
private def u32 := Term.lam u31
private def u33 := Term.lam u32
private def u34 := Term.app u33 u9
private def u35 := Term.app u34 u9
private def u36 := Term.app u35 u0
private def u37 := Term.app u36 u27
theorem nege596279078318 : ¬ IsSelfInterpreter e596279078318 := by
  intro he
  have hv : NFt u30 := by decide
  have reach : Betas (Floor40.call e596279078318 u0 u2 u1 []) u30 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left]] (Floor40.call e596279078318 u0 u2 u1 []) = some u28 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u28) (u := u37) [] (by decide) (replay_sound (ps := [[.left,.left,.left],[.left,.left]]) (by decide)) j hj
#print axioms nege596279078318
end Witness596279078318
namespace Witness596279078330
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u1 u0
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.app u5 u1
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u10 u9
private def u12 := Term.app u11 u9
private def u13 := Term.app u12 u0
private def u14 := Term.lam u0
private def u15 := Term.lam u14
private def u16 := Term.app u1 u15
private def u17 := Term.lam u2
private def u18 := Term.app u1 u17
private def u19 := Term.var 4
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u16 u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u26
private def u28 := Term.app u13 u27
private def u29 := Term.app u0 u17
private def u30 := Term.app u29 u1
private def u31 := Term.app u3 u9
private def u32 := Term.app u31 u1
private def u33 := Term.lam u32
private def u34 := Term.lam u33
private def u35 := Term.app u34 u9
private def u36 := Term.app u35 u9
private def u37 := Term.app u36 u0
private def u38 := Term.app u37 u27
theorem nege596279078330 : ¬ IsSelfInterpreter e596279078330 := by
  intro he
  have hv : NFt u30 := by decide
  have reach : Betas (Floor40.call e596279078330 u0 u2 u1 []) u30 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left]] (Floor40.call e596279078330 u0 u2 u1 []) = some u28 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u28) (u := u38) [] (by decide) (replay_sound (ps := [[.left,.left,.left],[.left,.left]]) (by decide)) j hj
#print axioms nege596279078330
end Witness596279078330
namespace Witness596279078358
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u4 u1
private def u6 := Term.app u5 u0
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u10 u9
private def u12 := Term.app u11 u9
private def u13 := Term.app u12 u0
private def u14 := Term.lam u0
private def u15 := Term.lam u14
private def u16 := Term.app u1 u15
private def u17 := Term.lam u2
private def u18 := Term.app u1 u17
private def u19 := Term.var 4
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u16 u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u26
private def u28 := Term.app u13 u27
private def u29 := Term.app u0 u17
private def u30 := Term.app u29 u1
private def u31 := Term.app u1 u9
private def u32 := Term.app u31 u1
private def u33 := Term.app u32 u0
private def u34 := Term.lam u33
private def u35 := Term.lam u34
private def u36 := Term.app u35 u9
private def u37 := Term.app u36 u9
private def u38 := Term.app u37 u0
private def u39 := Term.app u38 u27
theorem nege596279078358 : ¬ IsSelfInterpreter e596279078358 := by
  intro he
  have hv : NFt u30 := by decide
  have reach : Betas (Floor40.call e596279078358 u0 u2 u1 []) u30 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left]] (Floor40.call e596279078358 u0 u2 u1 []) = some u28 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u28) (u := u39) [] (by decide) (replay_sound (ps := [[.left,.left,.left],[.left,.left]]) (by decide)) j hj
#print axioms nege596279078358
end Witness596279078358
namespace Witness596279078574
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u0 u1
private def u4 := Term.app u3 u1
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u10 u9
private def u12 := Term.app u11 u9
private def u13 := Term.app u12 u0
private def u14 := Term.lam u0
private def u15 := Term.lam u14
private def u16 := Term.app u1 u15
private def u17 := Term.lam u2
private def u18 := Term.app u1 u17
private def u19 := Term.var 4
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u16 u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u26
private def u28 := Term.app u13 u27
private def u29 := Term.app u0 u17
private def u30 := Term.app u29 u1
private def u31 := Term.app u4 u9
private def u32 := Term.lam u31
private def u33 := Term.lam u32
private def u34 := Term.app u33 u9
private def u35 := Term.app u34 u9
private def u36 := Term.app u35 u0
private def u37 := Term.app u36 u27
theorem nege596279078574 : ¬ IsSelfInterpreter e596279078574 := by
  intro he
  have hv : NFt u30 := by decide
  have reach : Betas (Floor40.call e596279078574 u0 u2 u1 []) u30 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left]] (Floor40.call e596279078574 u0 u2 u1 []) = some u28 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u28) (u := u37) [] (by decide) (replay_sound (ps := [[.left,.left,.left],[.left,.left]]) (by decide)) j hj
#print axioms nege596279078574
end Witness596279078574
namespace Witness596279078586
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u0 u1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.app u5 u1
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u10 u9
private def u12 := Term.app u11 u9
private def u13 := Term.app u12 u0
private def u14 := Term.lam u0
private def u15 := Term.lam u14
private def u16 := Term.app u1 u15
private def u17 := Term.lam u2
private def u18 := Term.app u1 u17
private def u19 := Term.var 4
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u16 u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u26
private def u28 := Term.app u13 u27
private def u29 := Term.app u0 u17
private def u30 := Term.app u29 u1
private def u31 := Term.app u3 u9
private def u32 := Term.app u31 u1
private def u33 := Term.lam u32
private def u34 := Term.lam u33
private def u35 := Term.app u34 u9
private def u36 := Term.app u35 u9
private def u37 := Term.app u36 u0
private def u38 := Term.app u37 u27
theorem nege596279078586 : ¬ IsSelfInterpreter e596279078586 := by
  intro he
  have hv : NFt u30 := by decide
  have reach : Betas (Floor40.call e596279078586 u0 u2 u1 []) u30 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left]] (Floor40.call e596279078586 u0 u2 u1 []) = some u28 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u28) (u := u38) [] (by decide) (replay_sound (ps := [[.left,.left,.left],[.left,.left]]) (by decide)) j hj
#print axioms nege596279078586
end Witness596279078586
end Blc.Floor41
