import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605794873182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605794873182 : Closed e605794873182 ∧ code e605794873182 = 2804818128734 := by decide
theorem cert_e605794873182 : check e605794873182 [[],[],[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605794873210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605794873210 : Closed e605794873210 ∧ code e605794873210 = 2804818128762 := by decide
private def t_e605794873210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem cert_e605794873210 : ¬ IsSelfInterpreter e605794873210 :=
  wSource (t := t_e605794873210) (replay_sound (ps := []) (t := e605794873210) (by decide)) (by decide)
def e605794873262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605794873262 : Closed e605794873262 ∧ code e605794873262 = 2804818128814 := by decide
theorem cert_e605794873262 : check e605794873262 [[],[],[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605794873274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605794873274 : Closed e605794873274 ∧ code e605794873274 = 2804818128826 := by decide
private def t_e605794873274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem cert_e605794873274 : ¬ IsSelfInterpreter e605794873274 :=
  wSource (t := t_e605794873274) (replay_sound (ps := []) (t := e605794873274) (by decide)) (by decide)
def e605794874334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605794874334 : Closed e605794874334 ∧ code e605794874334 = 2804818129886 := by decide
theorem cert_e605794874334 : check e605794874334 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e605794874350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605794874350 : Closed e605794874350 ∧ code e605794874350 = 2804818129902 := by decide
theorem cert_e605794874350 : check e605794874350 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e605794876638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605794876638 : Closed e605794876638 ∧ code e605794876638 = 2804818132190 := by decide
theorem cert_e605794876638 : check e605794876638 [[],[],[],[],[],[],[.under]] .sourceHead = true := by decide
def e605794876666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605794876666 : Closed e605794876666 ∧ code e605794876666 = 2804818132218 := by decide
theorem cert_e605794876666 : check e605794876666 [[],[],[],[],[],[],[.under],[.under,.left]] .sourceHead = true := by decide
def e605794877038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605794877038 : Closed e605794877038 ∧ code e605794877038 = 2804818132590 := by decide
theorem cert_e605794877038 : check e605794877038 [[],[],[],[],[],[],[.under]] .sourceHead = true := by decide
def e605794877050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605794877050 : Closed e605794877050 ∧ code e605794877050 = 2804818132602 := by decide
theorem cert_e605794877050 : check e605794877050 [[],[],[],[],[],[],[.under],[.under,.left]] .sourceHead = true := by decide
def e605794905454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605794905454 : Closed e605794905454 ∧ code e605794905454 = 2804818161006 := by decide
private def t_e605794905454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem cert_e605794905454 : ¬ IsSelfInterpreter e605794905454 :=
  wSource (t := t_e605794905454) (replay_sound (ps := []) (t := e605794905454) (by decide)) (by decide)
def e605794905462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605794905462 : Closed e605794905462 ∧ code e605794905462 = 2804818161014 := by decide
private def t_e605794905462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem cert_e605794905462 : ¬ IsSelfInterpreter e605794905462 :=
  wSource (t := t_e605794905462) (replay_sound (ps := []) (t := e605794905462) (by decide)) (by decide)
def e605794905518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605794905518 : Closed e605794905518 ∧ code e605794905518 = 2804818161070 := by decide
private def t_e605794905518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem cert_e605794905518 : ¬ IsSelfInterpreter e605794905518 :=
  wSource (t := t_e605794905518) (replay_sound (ps := []) (t := e605794905518) (by decide)) (by decide)
def e605794905530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605794905530 : Closed e605794905530 ∧ code e605794905530 = 2804818161082 := by decide
private def t_e605794905530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem cert_e605794905530 : ¬ IsSelfInterpreter e605794905530 :=
  wSource (t := t_e605794905530) (replay_sound (ps := []) (t := e605794905530) (by decide)) (by decide)
def e605794905558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605794905558 : Closed e605794905558 ∧ code e605794905558 = 2804818161110 := by decide
private def t_e605794905558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem cert_e605794905558 : ¬ IsSelfInterpreter e605794905558 :=
  wSource (t := t_e605794905558) (replay_sound (ps := []) (t := e605794905558) (by decide)) (by decide)
def e605794905562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605794905562 : Closed e605794905562 ∧ code e605794905562 = 2804818161114 := by decide
private def t_e605794905562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem cert_e605794905562 : ¬ IsSelfInterpreter e605794905562 :=
  wSource (t := t_e605794905562) (replay_sound (ps := []) (t := e605794905562) (by decide)) (by decide)
def e605794905774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605794905774 : Closed e605794905774 ∧ code e605794905774 = 2804818161326 := by decide
private def t_e605794905774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem cert_e605794905774 : ¬ IsSelfInterpreter e605794905774 :=
  wSource (t := t_e605794905774) (replay_sound (ps := []) (t := e605794905774) (by decide)) (by decide)
def e605794905786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605794905786 : Closed e605794905786 ∧ code e605794905786 = 2804818161338 := by decide
private def t_e605794905786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem cert_e605794905786 : ¬ IsSelfInterpreter e605794905786 :=
  wSource (t := t_e605794905786) (replay_sound (ps := []) (t := e605794905786) (by decide)) (by decide)
def e605794905834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605794905834 : Closed e605794905834 ∧ code e605794905834 = 2804818161386 := by decide
private def t_e605794905834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem cert_e605794905834 : ¬ IsSelfInterpreter e605794905834 :=
  wSource (t := t_e605794905834) (replay_sound (ps := []) (t := e605794905834) (by decide)) (by decide)
def e605794905942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605794905942 : Closed e605794905942 ∧ code e605794905942 = 2804818161494 := by decide
private def t_e605794905942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem cert_e605794905942 : ¬ IsSelfInterpreter e605794905942 :=
  wSource (t := t_e605794905942) (replay_sound (ps := []) (t := e605794905942) (by decide)) (by decide)
def e605794905946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605794905946 : Closed e605794905946 ∧ code e605794905946 = 2804818161498 := by decide
private def t_e605794905946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem cert_e605794905946 : ¬ IsSelfInterpreter e605794905946 :=
  wSource (t := t_e605794905946) (replay_sound (ps := []) (t := e605794905946) (by decide)) (by decide)
def e605794905962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605794905962 : Closed e605794905962 ∧ code e605794905962 = 2804818161514 := by decide
private def t_e605794905962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem cert_e605794905962 : ¬ IsSelfInterpreter e605794905962 :=
  wSource (t := t_e605794905962) (replay_sound (ps := []) (t := e605794905962) (by decide)) (by decide)
def e605794906990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605794906990 : Closed e605794906990 ∧ code e605794906990 = 2804818162542 := by decide
private def t_e605794906990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem cert_e605794906990 : ¬ IsSelfInterpreter e605794906990 :=
  wSource (t := t_e605794906990) (replay_sound (ps := []) (t := e605794906990) (by decide)) (by decide)
def e605794906998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605794906998 : Closed e605794906998 ∧ code e605794906998 = 2804818162550 := by decide
private def t_e605794906998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem cert_e605794906998 : ¬ IsSelfInterpreter e605794906998 :=
  wSource (t := t_e605794906998) (replay_sound (ps := []) (t := e605794906998) (by decide)) (by decide)
def e605794907054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605794907054 : Closed e605794907054 ∧ code e605794907054 = 2804818162606 := by decide
private def t_e605794907054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem cert_e605794907054 : ¬ IsSelfInterpreter e605794907054 :=
  wSource (t := t_e605794907054) (replay_sound (ps := []) (t := e605794907054) (by decide)) (by decide)
def e605794907066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605794907066 : Closed e605794907066 ∧ code e605794907066 = 2804818162618 := by decide
private def t_e605794907066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem cert_e605794907066 : ¬ IsSelfInterpreter e605794907066 :=
  wSource (t := t_e605794907066) (replay_sound (ps := []) (t := e605794907066) (by decide)) (by decide)
def e605794907094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605794907094 : Closed e605794907094 ∧ code e605794907094 = 2804818162646 := by decide
private def t_e605794907094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem cert_e605794907094 : ¬ IsSelfInterpreter e605794907094 :=
  wSource (t := t_e605794907094) (replay_sound (ps := []) (t := e605794907094) (by decide)) (by decide)
def e605794907098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605794907098 : Closed e605794907098 ∧ code e605794907098 = 2804818162650 := by decide
private def t_e605794907098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem cert_e605794907098 : ¬ IsSelfInterpreter e605794907098 :=
  wSource (t := t_e605794907098) (replay_sound (ps := []) (t := e605794907098) (by decide)) (by decide)
def e605794907374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605794907374 : Closed e605794907374 ∧ code e605794907374 = 2804818162926 := by decide
private def t_e605794907374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem cert_e605794907374 : ¬ IsSelfInterpreter e605794907374 :=
  wSource (t := t_e605794907374) (replay_sound (ps := []) (t := e605794907374) (by decide)) (by decide)
def e605794907382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605794907382 : Closed e605794907382 ∧ code e605794907382 = 2804818162934 := by decide
private def t_e605794907382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem cert_e605794907382 : ¬ IsSelfInterpreter e605794907382 :=
  wSource (t := t_e605794907382) (replay_sound (ps := []) (t := e605794907382) (by decide)) (by decide)
def e605794907758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605794907758 : Closed e605794907758 ∧ code e605794907758 = 2804818163310 := by decide
private def t_e605794907758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem cert_e605794907758 : ¬ IsSelfInterpreter e605794907758 :=
  wSource (t := t_e605794907758) (replay_sound (ps := []) (t := e605794907758) (by decide)) (by decide)
def e605794907770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605794907770 : Closed e605794907770 ∧ code e605794907770 = 2804818163322 := by decide
private def t_e605794907770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem cert_e605794907770 : ¬ IsSelfInterpreter e605794907770 :=
  wSource (t := t_e605794907770) (replay_sound (ps := []) (t := e605794907770) (by decide)) (by decide)
def e605794907958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605794907958 : Closed e605794907958 ∧ code e605794907958 = 2804818163510 := by decide
private def t_e605794907958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem cert_e605794907958 : ¬ IsSelfInterpreter e605794907958 :=
  wSource (t := t_e605794907958) (replay_sound (ps := []) (t := e605794907958) (by decide)) (by decide)
def e605794907962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605794907962 : Closed e605794907962 ∧ code e605794907962 = 2804818163514 := by decide
private def t_e605794907962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem cert_e605794907962 : ¬ IsSelfInterpreter e605794907962 :=
  wSource (t := t_e605794907962) (replay_sound (ps := []) (t := e605794907962) (by decide)) (by decide)
def e605794908590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605794908590 : Closed e605794908590 ∧ code e605794908590 = 2804818164142 := by decide
private def t_e605794908590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem cert_e605794908590 : ¬ IsSelfInterpreter e605794908590 :=
  wSource (t := t_e605794908590) (replay_sound (ps := []) (t := e605794908590) (by decide)) (by decide)
def e605794908602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605794908602 : Closed e605794908602 ∧ code e605794908602 = 2804818164154 := by decide
private def t_e605794908602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem cert_e605794908602 : ¬ IsSelfInterpreter e605794908602 :=
  wSource (t := t_e605794908602) (replay_sound (ps := []) (t := e605794908602) (by decide)) (by decide)
def e605794908650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605794908650 : Closed e605794908650 ∧ code e605794908650 = 2804818164202 := by decide
private def t_e605794908650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem cert_e605794908650 : ¬ IsSelfInterpreter e605794908650 :=
  wSource (t := t_e605794908650) (replay_sound (ps := []) (t := e605794908650) (by decide)) (by decide)
def e605794908782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605794908782 : Closed e605794908782 ∧ code e605794908782 = 2804818164334 := by decide
private def t_e605794908782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem cert_e605794908782 : ¬ IsSelfInterpreter e605794908782 :=
  wSource (t := t_e605794908782) (replay_sound (ps := []) (t := e605794908782) (by decide)) (by decide)
def e605794908794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605794908794 : Closed e605794908794 ∧ code e605794908794 = 2804818164346 := by decide
private def t_e605794908794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem cert_e605794908794 : ¬ IsSelfInterpreter e605794908794 :=
  wSource (t := t_e605794908794) (replay_sound (ps := []) (t := e605794908794) (by decide)) (by decide)
def e605794909082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605794909082 : Closed e605794909082 ∧ code e605794909082 = 2804818164634 := by decide
private def t_e605794909082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem cert_e605794909082 : ¬ IsSelfInterpreter e605794909082 :=
  wSource (t := t_e605794909082) (replay_sound (ps := []) (t := e605794909082) (by decide)) (by decide)
def e605794909398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605794909398 : Closed e605794909398 ∧ code e605794909398 = 2804818164950 := by decide
private def t_e605794909398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem cert_e605794909398 : ¬ IsSelfInterpreter e605794909398 :=
  wSource (t := t_e605794909398) (replay_sound (ps := []) (t := e605794909398) (by decide)) (by decide)
def e605794909402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605794909402 : Closed e605794909402 ∧ code e605794909402 = 2804818164954 := by decide
private def t_e605794909402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem cert_e605794909402 : ¬ IsSelfInterpreter e605794909402 :=
  wSource (t := t_e605794909402) (replay_sound (ps := []) (t := e605794909402) (by decide)) (by decide)
def e605794909418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605794909418 : Closed e605794909418 ∧ code e605794909418 = 2804818164970 := by decide
private def t_e605794909418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem cert_e605794909418 : ¬ IsSelfInterpreter e605794909418 :=
  wSource (t := t_e605794909418) (replay_sound (ps := []) (t := e605794909418) (by decide)) (by decide)
def e605794909494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605794909494 : Closed e605794909494 ∧ code e605794909494 = 2804818165046 := by decide
private def t_e605794909494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem cert_e605794909494 : ¬ IsSelfInterpreter e605794909494 :=
  wSource (t := t_e605794909494) (replay_sound (ps := []) (t := e605794909494) (by decide)) (by decide)
def e605794909498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605794909498 : Closed e605794909498 ∧ code e605794909498 = 2804818165050 := by decide
private def t_e605794909498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem cert_e605794909498 : ¬ IsSelfInterpreter e605794909498 :=
  wSource (t := t_e605794909498) (replay_sound (ps := []) (t := e605794909498) (by decide)) (by decide)
def e605794909594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605794909594 : Closed e605794909594 ∧ code e605794909594 = 2804818165146 := by decide
private def t_e605794909594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem cert_e605794909594 : ¬ IsSelfInterpreter e605794909594 :=
  wSource (t := t_e605794909594) (replay_sound (ps := []) (t := e605794909594) (by decide)) (by decide)
def e605794911198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e605794911198 : Closed e605794911198 ∧ code e605794911198 = 2804818166750 := by decide
private def t_e605794911198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem cert_e605794911198 : ¬ IsSelfInterpreter e605794911198 :=
  wSource (t := t_e605794911198) (replay_sound (ps := []) (t := e605794911198) (by decide)) (by decide)
def e605794911214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e605794911214 : Closed e605794911214 ∧ code e605794911214 = 2804818166766 := by decide
private def t_e605794911214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem cert_e605794911214 : ¬ IsSelfInterpreter e605794911214 :=
  wSource (t := t_e605794911214) (replay_sound (ps := []) (t := e605794911214) (by decide)) (by decide)
def e605794913134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605794913134 : Closed e605794913134 ∧ code e605794913134 = 2804818168686 := by decide
private def t_e605794913134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem cert_e605794913134 : ¬ IsSelfInterpreter e605794913134 :=
  wSource (t := t_e605794913134) (replay_sound (ps := []) (t := e605794913134) (by decide)) (by decide)
def e605794913142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605794913142 : Closed e605794913142 ∧ code e605794913142 = 2804818168694 := by decide
private def t_e605794913142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem cert_e605794913142 : ¬ IsSelfInterpreter e605794913142 :=
  wSource (t := t_e605794913142) (replay_sound (ps := []) (t := e605794913142) (by decide)) (by decide)
def e605794913198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605794913198 : Closed e605794913198 ∧ code e605794913198 = 2804818168750 := by decide
private def t_e605794913198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem cert_e605794913198 : ¬ IsSelfInterpreter e605794913198 :=
  wSource (t := t_e605794913198) (replay_sound (ps := []) (t := e605794913198) (by decide)) (by decide)
def e605794913210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605794913210 : Closed e605794913210 ∧ code e605794913210 = 2804818168762 := by decide
private def t_e605794913210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e605794913210 : ¬ IsSelfInterpreter e605794913210 :=
  wSource (t := t_e605794913210) (replay_sound (ps := []) (t := e605794913210) (by decide)) (by decide)
def e605794913238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605794913238 : Closed e605794913238 ∧ code e605794913238 = 2804818168790 := by decide
private def t_e605794913238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem cert_e605794913238 : ¬ IsSelfInterpreter e605794913238 :=
  wSource (t := t_e605794913238) (replay_sound (ps := []) (t := e605794913238) (by decide)) (by decide)
def e605794913242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605794913242 : Closed e605794913242 ∧ code e605794913242 = 2804818168794 := by decide
private def t_e605794913242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e605794913242 : ¬ IsSelfInterpreter e605794913242 :=
  wSource (t := t_e605794913242) (replay_sound (ps := []) (t := e605794913242) (by decide)) (by decide)
def e605794913518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605794913518 : Closed e605794913518 ∧ code e605794913518 = 2804818169070 := by decide
private def t_e605794913518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem cert_e605794913518 : ¬ IsSelfInterpreter e605794913518 :=
  wSource (t := t_e605794913518) (replay_sound (ps := []) (t := e605794913518) (by decide)) (by decide)
def e605794913526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605794913526 : Closed e605794913526 ∧ code e605794913526 = 2804818169078 := by decide
private def t_e605794913526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem cert_e605794913526 : ¬ IsSelfInterpreter e605794913526 :=
  wSource (t := t_e605794913526) (replay_sound (ps := []) (t := e605794913526) (by decide)) (by decide)
def e605794913902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605794913902 : Closed e605794913902 ∧ code e605794913902 = 2804818169454 := by decide
private def t_e605794913902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem cert_e605794913902 : ¬ IsSelfInterpreter e605794913902 :=
  wSource (t := t_e605794913902) (replay_sound (ps := []) (t := e605794913902) (by decide)) (by decide)
def e605794913914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605794913914 : Closed e605794913914 ∧ code e605794913914 = 2804818169466 := by decide
private def t_e605794913914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem cert_e605794913914 : ¬ IsSelfInterpreter e605794913914 :=
  wSource (t := t_e605794913914) (replay_sound (ps := []) (t := e605794913914) (by decide)) (by decide)
def e605794914102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605794914102 : Closed e605794914102 ∧ code e605794914102 = 2804818169654 := by decide
private def t_e605794914102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem cert_e605794914102 : ¬ IsSelfInterpreter e605794914102 :=
  wSource (t := t_e605794914102) (replay_sound (ps := []) (t := e605794914102) (by decide)) (by decide)
def e605794914106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605794914106 : Closed e605794914106 ∧ code e605794914106 = 2804818169658 := by decide
private def t_e605794914106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem cert_e605794914106 : ¬ IsSelfInterpreter e605794914106 :=
  wSource (t := t_e605794914106) (replay_sound (ps := []) (t := e605794914106) (by decide)) (by decide)
def e605794918878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605794918878 : Closed e605794918878 ∧ code e605794918878 = 2804818174430 := by decide
private def t_e605794918878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem cert_e605794918878 : ¬ IsSelfInterpreter e605794918878 :=
  wSource (t := t_e605794918878) (replay_sound (ps := []) (t := e605794918878) (by decide)) (by decide)
def e605794918902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605794918902 : Closed e605794918902 ∧ code e605794918902 = 2804818174454 := by decide
private def t_e605794918902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem cert_e605794918902 : ¬ IsSelfInterpreter e605794918902 :=
  wSource (t := t_e605794918902) (replay_sound (ps := []) (t := e605794918902) (by decide)) (by decide)
def e605794919854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605794919854 : Closed e605794919854 ∧ code e605794919854 = 2804818175406 := by decide
private def t_e605794919854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem cert_e605794919854 : ¬ IsSelfInterpreter e605794919854 :=
  wSource (t := t_e605794919854) (replay_sound (ps := []) (t := e605794919854) (by decide)) (by decide)
def e605794919866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605794919866 : Closed e605794919866 ∧ code e605794919866 = 2804818175418 := by decide
private def t_e605794919866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem cert_e605794919866 : ¬ IsSelfInterpreter e605794919866 :=
  wSource (t := t_e605794919866) (replay_sound (ps := []) (t := e605794919866) (by decide)) (by decide)
def e605794919914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605794919914 : Closed e605794919914 ∧ code e605794919914 = 2804818175466 := by decide
private def t_e605794919914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem cert_e605794919914 : ¬ IsSelfInterpreter e605794919914 :=
  wSource (t := t_e605794919914) (replay_sound (ps := []) (t := e605794919914) (by decide)) (by decide)
def e605794920046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605794920046 : Closed e605794920046 ∧ code e605794920046 = 2804818175598 := by decide
private def t_e605794920046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem cert_e605794920046 : ¬ IsSelfInterpreter e605794920046 :=
  wSource (t := t_e605794920046) (replay_sound (ps := []) (t := e605794920046) (by decide)) (by decide)
def e605794920058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605794920058 : Closed e605794920058 ∧ code e605794920058 = 2804818175610 := by decide
private def t_e605794920058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem cert_e605794920058 : ¬ IsSelfInterpreter e605794920058 :=
  wSource (t := t_e605794920058) (replay_sound (ps := []) (t := e605794920058) (by decide)) (by decide)
def e605794920346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605794920346 : Closed e605794920346 ∧ code e605794920346 = 2804818175898 := by decide
private def t_e605794920346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem cert_e605794920346 : ¬ IsSelfInterpreter e605794920346 :=
  wSource (t := t_e605794920346) (replay_sound (ps := []) (t := e605794920346) (by decide)) (by decide)
def e605794922734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605794922734 : Closed e605794922734 ∧ code e605794922734 = 2804818178286 := by decide
private def t_e605794922734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem cert_e605794922734 : ¬ IsSelfInterpreter e605794922734 :=
  wSource (t := t_e605794922734) (replay_sound (ps := []) (t := e605794922734) (by decide)) (by decide)
def e605794922742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605794922742 : Closed e605794922742 ∧ code e605794922742 = 2804818178294 := by decide
private def t_e605794922742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem cert_e605794922742 : ¬ IsSelfInterpreter e605794922742 :=
  wSource (t := t_e605794922742) (replay_sound (ps := []) (t := e605794922742) (by decide)) (by decide)
def e605794923222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605794923222 : Closed e605794923222 ∧ code e605794923222 = 2804818178774 := by decide
private def t_e605794923222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem cert_e605794923222 : ¬ IsSelfInterpreter e605794923222 :=
  wSource (t := t_e605794923222) (replay_sound (ps := []) (t := e605794923222) (by decide)) (by decide)
def e605794923226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605794923226 : Closed e605794923226 ∧ code e605794923226 = 2804818178778 := by decide
private def t_e605794923226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem cert_e605794923226 : ¬ IsSelfInterpreter e605794923226 :=
  wSource (t := t_e605794923226) (replay_sound (ps := []) (t := e605794923226) (by decide)) (by decide)
def e605794923242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605794923242 : Closed e605794923242 ∧ code e605794923242 = 2804818178794 := by decide
private def t_e605794923242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem cert_e605794923242 : ¬ IsSelfInterpreter e605794923242 :=
  wSource (t := t_e605794923242) (replay_sound (ps := []) (t := e605794923242) (by decide)) (by decide)
def e605794923318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605794923318 : Closed e605794923318 ∧ code e605794923318 = 2804818178870 := by decide
private def t_e605794923318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem cert_e605794923318 : ¬ IsSelfInterpreter e605794923318 :=
  wSource (t := t_e605794923318) (replay_sound (ps := []) (t := e605794923318) (by decide)) (by decide)
def e605794923322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605794923322 : Closed e605794923322 ∧ code e605794923322 = 2804818178874 := by decide
private def t_e605794923322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem cert_e605794923322 : ¬ IsSelfInterpreter e605794923322 :=
  wSource (t := t_e605794923322) (replay_sound (ps := []) (t := e605794923322) (by decide)) (by decide)
def e605794923418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605794923418 : Closed e605794923418 ∧ code e605794923418 = 2804818178970 := by decide
private def t_e605794923418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem cert_e605794923418 : ¬ IsSelfInterpreter e605794923418 :=
  wSource (t := t_e605794923418) (replay_sound (ps := []) (t := e605794923418) (by decide)) (by decide)
def e605795060590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605795060590 : Closed e605795060590 ∧ code e605795060590 = 2804818316142 := by decide
private def t_e605795060590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem cert_e605795060590 : ¬ IsSelfInterpreter e605795060590 :=
  wSource (t := t_e605795060590) (replay_sound (ps := []) (t := e605795060590) (by decide)) (by decide)
def e605795060598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605795060598 : Closed e605795060598 ∧ code e605795060598 = 2804818316150 := by decide
private def t_e605795060598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem cert_e605795060598 : ¬ IsSelfInterpreter e605795060598 :=
  wSource (t := t_e605795060598) (replay_sound (ps := []) (t := e605795060598) (by decide)) (by decide)
def e605795060654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605795060654 : Closed e605795060654 ∧ code e605795060654 = 2804818316206 := by decide
private def t_e605795060654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem cert_e605795060654 : ¬ IsSelfInterpreter e605795060654 :=
  wSource (t := t_e605795060654) (replay_sound (ps := []) (t := e605795060654) (by decide)) (by decide)
def e605795060666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605795060666 : Closed e605795060666 ∧ code e605795060666 = 2804818316218 := by decide
private def t_e605795060666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e605795060666 : ¬ IsSelfInterpreter e605795060666 :=
  wSource (t := t_e605795060666) (replay_sound (ps := []) (t := e605795060666) (by decide)) (by decide)
def e605795060694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605795060694 : Closed e605795060694 ∧ code e605795060694 = 2804818316246 := by decide
private def t_e605795060694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem cert_e605795060694 : ¬ IsSelfInterpreter e605795060694 :=
  wSource (t := t_e605795060694) (replay_sound (ps := []) (t := e605795060694) (by decide)) (by decide)
def e605795060698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605795060698 : Closed e605795060698 ∧ code e605795060698 = 2804818316250 := by decide
private def t_e605795060698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e605795060698 : ¬ IsSelfInterpreter e605795060698 :=
  wSource (t := t_e605795060698) (replay_sound (ps := []) (t := e605795060698) (by decide)) (by decide)
def e605795060974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605795060974 : Closed e605795060974 ∧ code e605795060974 = 2804818316526 := by decide
private def t_e605795060974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem cert_e605795060974 : ¬ IsSelfInterpreter e605795060974 :=
  wSource (t := t_e605795060974) (replay_sound (ps := []) (t := e605795060974) (by decide)) (by decide)
def e605795060982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605795060982 : Closed e605795060982 ∧ code e605795060982 = 2804818316534 := by decide
private def t_e605795060982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem cert_e605795060982 : ¬ IsSelfInterpreter e605795060982 :=
  wSource (t := t_e605795060982) (replay_sound (ps := []) (t := e605795060982) (by decide)) (by decide)
def e605795061358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605795061358 : Closed e605795061358 ∧ code e605795061358 = 2804818316910 := by decide
private def t_e605795061358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem cert_e605795061358 : ¬ IsSelfInterpreter e605795061358 :=
  wSource (t := t_e605795061358) (replay_sound (ps := []) (t := e605795061358) (by decide)) (by decide)
def e605795061370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605795061370 : Closed e605795061370 ∧ code e605795061370 = 2804818316922 := by decide
private def t_e605795061370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem cert_e605795061370 : ¬ IsSelfInterpreter e605795061370 :=
  wSource (t := t_e605795061370) (replay_sound (ps := []) (t := e605795061370) (by decide)) (by decide)
def e605795061558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605795061558 : Closed e605795061558 ∧ code e605795061558 = 2804818317110 := by decide
private def t_e605795061558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem cert_e605795061558 : ¬ IsSelfInterpreter e605795061558 :=
  wSource (t := t_e605795061558) (replay_sound (ps := []) (t := e605795061558) (by decide)) (by decide)
def e605795061562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605795061562 : Closed e605795061562 ∧ code e605795061562 = 2804818317114 := by decide
private def t_e605795061562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem cert_e605795061562 : ¬ IsSelfInterpreter e605795061562 :=
  wSource (t := t_e605795061562) (replay_sound (ps := []) (t := e605795061562) (by decide)) (by decide)
def e605795391198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605795391198 : Closed e605795391198 ∧ code e605795391198 = 2804818646750 := by decide
theorem cert_e605795391198 : check e605795391198 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e605795391222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605795391222 : Closed e605795391222 ∧ code e605795391222 = 2804818646774 := by decide
theorem cert_e605795391222 : check e605795391222 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e605795391326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605795391326 : Closed e605795391326 ∧ code e605795391326 = 2804818646878 := by decide
def e605795391354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605795391354 : Closed e605795391354 ∧ code e605795391354 = 2804818646906 := by decide
private def t_e605795391354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem cert_e605795391354 : ¬ IsSelfInterpreter e605795391354 :=
  wSource (t := t_e605795391354) (replay_sound (ps := []) (t := e605795391354) (by decide)) (by decide)
def e605795391446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605795391446 : Closed e605795391446 ∧ code e605795391446 = 2804818646998 := by decide
theorem cert_e605795391446 : check e605795391446 [[],[],[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605795391450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605795391450 : Closed e605795391450 ∧ code e605795391450 = 2804818647002 := by decide
private def t_e605795391450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem cert_e605795391450 : ¬ IsSelfInterpreter e605795391450 :=
  wSource (t := t_e605795391450) (replay_sound (ps := []) (t := e605795391450) (by decide)) (by decide)
def e605795391966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605795391966 : Closed e605795391966 ∧ code e605795391966 = 2804818647518 := by decide
theorem cert_e605795391966 : check e605795391966 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e605795391990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605795391990 : Closed e605795391990 ∧ code e605795391990 = 2804818647542 := by decide
theorem cert_e605795391990 : check e605795391990 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e605795392734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605795392734 : Closed e605795392734 ∧ code e605795392734 = 2804818648286 := by decide
theorem cert_e605795392734 : check e605795392734 [[],[],[],[],[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e605795392762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605795392762 : Closed e605795392762 ∧ code e605795392762 = 2804818648314 := by decide
theorem cert_e605795392762 : check e605795392762 [[],[],[],[],[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e605795393334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605795393334 : Closed e605795393334 ∧ code e605795393334 = 2804818648886 := by decide
theorem cert_e605795393334 : check e605795393334 [[],[],[],[],[],[],[.under]] .sourceHead = true := by decide
def e605795393338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605795393338 : Closed e605795393338 ∧ code e605795393338 = 2804818648890 := by decide
def e605795408110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605795408110 : Closed e605795408110 ∧ code e605795408110 = 2804818663662 := by decide
def e605795408118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605795408118 : Closed e605795408118 ∧ code e605795408118 = 2804818663670 := by decide
def e605795408670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605795408670 : Closed e605795408670 ∧ code e605795408670 = 2804818664222 := by decide
private def t_e605795408670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem cert_e605795408670 : ¬ IsSelfInterpreter e605795408670 :=
  wSource (t := t_e605795408670) (replay_sound (ps := []) (t := e605795408670) (by decide)) (by decide)
def e605795408782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605795408782 : Closed e605795408782 ∧ code e605795408782 = 2804818664334 := by decide
private def t_e605795408782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem cert_e605795408782 : ¬ IsSelfInterpreter e605795408782 :=
  wSource (t := t_e605795408782) (replay_sound (ps := []) (t := e605795408782) (by decide)) (by decide)
def e605795409006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605795409006 : Closed e605795409006 ∧ code e605795409006 = 2804818664558 := by decide
def e605795409018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605795409018 : Closed e605795409018 ∧ code e605795409018 = 2804818664570 := by decide
def e605795409182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605795409182 : Closed e605795409182 ∧ code e605795409182 = 2804818664734 := by decide
private def t_e605795409182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem cert_e605795409182 : ¬ IsSelfInterpreter e605795409182 :=
  wSource (t := t_e605795409182) (replay_sound (ps := []) (t := e605795409182) (by decide)) (by decide)
def e605795409350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605795409350 : Closed e605795409350 ∧ code e605795409350 = 2804818664902 := by decide
private def t_e605795409350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem cert_e605795409350 : ¬ IsSelfInterpreter e605795409350 :=
  wSource (t := t_e605795409350) (replay_sound (ps := []) (t := e605795409350) (by decide)) (by decide)
def e605795409462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605795409462 : Closed e605795409462 ∧ code e605795409462 = 2804818665014 := by decide
def e605795409466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605795409466 : Closed e605795409466 ∧ code e605795409466 = 2804818665018 := by decide
def e605795409550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605795409550 : Closed e605795409550 ∧ code e605795409550 = 2804818665102 := by decide
private def t_e605795409550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem cert_e605795409550 : ¬ IsSelfInterpreter e605795409550 :=
  wSource (t := t_e605795409550) (replay_sound (ps := []) (t := e605795409550) (by decide)) (by decide)
def e605795409606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605795409606 : Closed e605795409606 ∧ code e605795409606 = 2804818665158 := by decide
private def t_e605795409606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem cert_e605795409606 : ¬ IsSelfInterpreter e605795409606 :=
  wSource (t := t_e605795409606) (replay_sound (ps := []) (t := e605795409606) (by decide)) (by decide)
def e605795411742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605795411742 : Closed e605795411742 ∧ code e605795411742 = 2804818667294 := by decide
def e605795411854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605795411854 : Closed e605795411854 ∧ code e605795411854 = 2804818667406 := by decide
def e605795414814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605795414814 : Closed e605795414814 ∧ code e605795414814 = 2804818670366 := by decide
def e605795414982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605795414982 : Closed e605795414982 ∧ code e605795414982 = 2804818670534 := by decide
def e605795416462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605795416462 : Closed e605795416462 ∧ code e605795416462 = 2804818672014 := by decide
def e605795416518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605795416518 : Closed e605795416518 ∧ code e605795416518 = 2804818672070 := by decide
def e605803261370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e605803261370 : Closed e605803261370 ∧ code e605803261370 = 2804826516922 := by decide
def e605803261402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e605803261402 : Closed e605803261402 ∧ code e605803261402 = 2804826516954 := by decide
def e605803261626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e605803261626 : Closed e605803261626 ∧ code e605803261626 = 2804826517178 := by decide
def e605803261674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e605803261674 : Closed e605803261674 ∧ code e605803261674 = 2804826517226 := by decide
private def t_e605803261674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem cert_e605803261674 : ¬ IsSelfInterpreter e605803261674 :=
  wSource (t := t_e605803261674) (replay_sound (ps := []) (t := e605803261674) (by decide)) (by decide)
def e605803261786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e605803261786 : Closed e605803261786 ∧ code e605803261786 = 2804826517338 := by decide
def e605803261802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e605803261802 : Closed e605803261802 ∧ code e605803261802 = 2804826517354 := by decide
private def t_e605803261802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem cert_e605803261802 : ¬ IsSelfInterpreter e605803261802 :=
  wSource (t := t_e605803261802) (replay_sound (ps := []) (t := e605803261802) (by decide)) (by decide)
def e605803262906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e605803262906 : Closed e605803262906 ∧ code e605803262906 = 2804826518458 := by decide
def e605803262938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e605803262938 : Closed e605803262938 ∧ code e605803262938 = 2804826518490 := by decide
def e605803264442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e605803264442 : Closed e605803264442 ∧ code e605803264442 = 2804826519994 := by decide
def e605803264490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e605803264490 : Closed e605803264490 ∧ code e605803264490 = 2804826520042 := by decide
def e605803265242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e605803265242 : Closed e605803265242 ∧ code e605803265242 = 2804826520794 := by decide
def e605803265258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e605803265258 : Closed e605803265258 ∧ code e605803265258 = 2804826520810 := by decide
def e605803514734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605803514734 : Closed e605803514734 ∧ code e605803514734 = 2804826770286 := by decide
private def t_e605803514734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e605803514734 : ¬ IsSelfInterpreter e605803514734 :=
  wSource (t := t_e605803514734) (replay_sound (ps := []) (t := e605803514734) (by decide)) (by decide)
def e605803514742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605803514742 : Closed e605803514742 ∧ code e605803514742 = 2804826770294 := by decide
private def t_e605803514742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e605803514742 : ¬ IsSelfInterpreter e605803514742 :=
  wSource (t := t_e605803514742) (replay_sound (ps := []) (t := e605803514742) (by decide)) (by decide)
def e605803514798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605803514798 : Closed e605803514798 ∧ code e605803514798 = 2804826770350 := by decide
private def t_e605803514798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e605803514798 : ¬ IsSelfInterpreter e605803514798 :=
  wSource (t := t_e605803514798) (replay_sound (ps := []) (t := e605803514798) (by decide)) (by decide)
def e605803514810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605803514810 : Closed e605803514810 ∧ code e605803514810 = 2804826770362 := by decide
private def t_e605803514810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e605803514810 : ¬ IsSelfInterpreter e605803514810 :=
  wSource (t := t_e605803514810) (replay_sound (ps := []) (t := e605803514810) (by decide)) (by decide)
def e605803514838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605803514838 : Closed e605803514838 ∧ code e605803514838 = 2804826770390 := by decide
private def t_e605803514838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e605803514838 : ¬ IsSelfInterpreter e605803514838 :=
  wSource (t := t_e605803514838) (replay_sound (ps := []) (t := e605803514838) (by decide)) (by decide)
def e605803514842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605803514842 : Closed e605803514842 ∧ code e605803514842 = 2804826770394 := by decide
private def t_e605803514842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e605803514842 : ¬ IsSelfInterpreter e605803514842 :=
  wSource (t := t_e605803514842) (replay_sound (ps := []) (t := e605803514842) (by decide)) (by decide)
def e605803515118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605803515118 : Closed e605803515118 ∧ code e605803515118 = 2804826770670 := by decide
private def t_e605803515118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e605803515118 : ¬ IsSelfInterpreter e605803515118 :=
  wSource (t := t_e605803515118) (replay_sound (ps := []) (t := e605803515118) (by decide)) (by decide)
def e605803515126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605803515126 : Closed e605803515126 ∧ code e605803515126 = 2804826770678 := by decide
private def t_e605803515126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e605803515126 : ¬ IsSelfInterpreter e605803515126 :=
  wSource (t := t_e605803515126) (replay_sound (ps := []) (t := e605803515126) (by decide)) (by decide)
def e605803515502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605803515502 : Closed e605803515502 ∧ code e605803515502 = 2804826771054 := by decide
private def t_e605803515502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e605803515502 : ¬ IsSelfInterpreter e605803515502 :=
  wSource (t := t_e605803515502) (replay_sound (ps := []) (t := e605803515502) (by decide)) (by decide)
def e605803515514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605803515514 : Closed e605803515514 ∧ code e605803515514 = 2804826771066 := by decide
private def t_e605803515514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e605803515514 : ¬ IsSelfInterpreter e605803515514 :=
  wSource (t := t_e605803515514) (replay_sound (ps := []) (t := e605803515514) (by decide)) (by decide)
def e605803515702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605803515702 : Closed e605803515702 ∧ code e605803515702 = 2804826771254 := by decide
private def t_e605803515702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e605803515702 : ¬ IsSelfInterpreter e605803515702 :=
  wSource (t := t_e605803515702) (replay_sound (ps := []) (t := e605803515702) (by decide)) (by decide)
def e605803515706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605803515706 : Closed e605803515706 ∧ code e605803515706 = 2804826771258 := by decide
private def t_e605803515706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e605803515706 : ¬ IsSelfInterpreter e605803515706 :=
  wSource (t := t_e605803515706) (replay_sound (ps := []) (t := e605803515706) (by decide)) (by decide)
def e605804301166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605804301166 : Closed e605804301166 ∧ code e605804301166 = 2804827556718 := by decide
theorem cert_e605804301166 : check e605804301166 [[],[],[],[.left]] .chain = true := by decide
def e605804301174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605804301174 : Closed e605804301174 ∧ code e605804301174 = 2804827556726 := by decide
theorem cert_e605804301174 : check e605804301174 [[],[],[],[.left]] .chain = true := by decide
def e605804301230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605804301230 : Closed e605804301230 ∧ code e605804301230 = 2804827556782 := by decide
theorem cert_e605804301230 : check e605804301230 [[],[],[],[.left]] .chain = true := by decide
def e605804301242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605804301242 : Closed e605804301242 ∧ code e605804301242 = 2804827556794 := by decide
theorem cert_e605804301242 : check e605804301242 [[],[],[],[.left]] .chain = true := by decide
def e605804301270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605804301270 : Closed e605804301270 ∧ code e605804301270 = 2804827556822 := by decide
theorem cert_e605804301270 : check e605804301270 [[],[],[],[.left]] .chain = true := by decide
def e605804301274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605804301274 : Closed e605804301274 ∧ code e605804301274 = 2804827556826 := by decide
theorem cert_e605804301274 : check e605804301274 [[],[],[],[.left]] .chain = true := by decide
def e605804301550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605804301550 : Closed e605804301550 ∧ code e605804301550 = 2804827557102 := by decide
theorem cert_e605804301550 : check e605804301550 [[],[],[],[.left]] .chain = true := by decide
def e605804301558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605804301558 : Closed e605804301558 ∧ code e605804301558 = 2804827557110 := by decide
theorem cert_e605804301558 : check e605804301558 [[],[],[],[.left]] .chain = true := by decide
def e605804301934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605804301934 : Closed e605804301934 ∧ code e605804301934 = 2804827557486 := by decide
theorem cert_e605804301934 : check e605804301934 [[],[],[],[.left]] .chain = true := by decide
def e605804301946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605804301946 : Closed e605804301946 ∧ code e605804301946 = 2804827557498 := by decide
theorem cert_e605804301946 : check e605804301946 [[],[],[],[.left]] .chain = true := by decide
def e605804302134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605804302134 : Closed e605804302134 ∧ code e605804302134 = 2804827557686 := by decide
theorem cert_e605804302134 : check e605804302134 [[],[],[],[.left]] .chain = true := by decide
def e605804302138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605804302138 : Closed e605804302138 ∧ code e605804302138 = 2804827557690 := by decide
theorem cert_e605804302138 : check e605804302138 [[],[],[],[.left]] .chain = true := by decide
def e605804309982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605804309982 : Closed e605804309982 ∧ code e605804309982 = 2804827565534 := by decide
theorem cert_e605804309982 : check e605804309982 [[],[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e605804309998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605804309998 : Closed e605804309998 ∧ code e605804309998 = 2804827565550 := by decide
theorem cert_e605804309998 : check e605804309998 [[],[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e605804310366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605804310366 : Closed e605804310366 ∧ code e605804310366 = 2804827565918 := by decide
theorem cert_e605804310366 : check e605804310366 [[],[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e605804310394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605804310394 : Closed e605804310394 ∧ code e605804310394 = 2804827565946 := by decide
private def t_e605804310394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem cert_e605804310394 : ¬ IsSelfInterpreter e605804310394 :=
  wSource (t := t_e605804310394) (replay_sound (ps := []) (t := e605804310394) (by decide)) (by decide)
def e605804310446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605804310446 : Closed e605804310446 ∧ code e605804310446 = 2804827565998 := by decide
theorem cert_e605804310446 : check e605804310446 [[],[],[],[.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e605804310458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605804310458 : Closed e605804310458 ∧ code e605804310458 = 2804827566010 := by decide
private def t_e605804310458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem cert_e605804310458 : ¬ IsSelfInterpreter e605804310458 :=
  wSource (t := t_e605804310458) (replay_sound (ps := []) (t := e605804310458) (by decide)) (by decide)
end Blc.Floor41
