import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605627354734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605627354734 : Closed e605627354734 ∧ code e605627354734 = 2804650610286 := by decide
theorem cert_e605627354734 : check e605627354734 [[],[]] .smaller = true := by decide
def e605627354746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605627354746 : Closed e605627354746 ∧ code e605627354746 = 2804650610298 := by decide
theorem cert_e605627354746 : check e605627354746 [[],[]] .smaller = true := by decide
def e605627354934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605627354934 : Closed e605627354934 ∧ code e605627354934 = 2804650610486 := by decide
theorem cert_e605627354934 : check e605627354934 [[],[]] .smaller = true := by decide
def e605627354938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605627354938 : Closed e605627354938 ∧ code e605627354938 = 2804650610490 := by decide
theorem cert_e605627354938 : check e605627354938 [[],[]] .smaller = true := by decide
def e605635524330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)) (.var 0)))))
theorem wire_e605635524330 : Closed e605635524330 ∧ code e605635524330 = 2804658779882 := by decide
theorem cert_e605635524330 : check e605635524330 [[],[]] .chain = true := by decide
def e605635524458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)) (.var 0)))))
theorem wire_e605635524458 : Closed e605635524458 ∧ code e605635524458 = 2804658780010 := by decide
theorem cert_e605635524458 : check e605635524458 [[],[]] .chain = true := by decide
def e605635525354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)) (.var 0)))))
theorem wire_e605635525354 : Closed e605635525354 ∧ code e605635525354 = 2804658780906 := by decide
theorem cert_e605635525354 : check e605635525354 [[],[]] .chain = true := by decide
def e605635525546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)) (.var 0)))))
theorem wire_e605635525546 : Closed e605635525546 ∧ code e605635525546 = 2804658781098 := by decide
theorem cert_e605635525546 : check e605635525546 [[],[]] .chain = true := by decide
def e605635525994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)) (.var 0)))))
theorem wire_e605635525994 : Closed e605635525994 ∧ code e605635525994 = 2804658781546 := by decide
theorem cert_e605635525994 : check e605635525994 [[],[]] .chain = true := by decide
def e605635526058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)) (.var 0)))))
theorem wire_e605635526058 : Closed e605635526058 ∧ code e605635526058 = 2804658781610 := by decide
theorem cert_e605635526058 : check e605635526058 [[],[]] .chain = true := by decide
def e605635530474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)) (.var 0)))))
theorem wire_e605635530474 : Closed e605635530474 ∧ code e605635530474 = 2804658786026 := by decide
theorem cert_e605635530474 : check e605635530474 [[],[]] .chain = true := by decide
def e605635530602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)) (.var 0)))))
theorem wire_e605635530602 : Closed e605635530602 ∧ code e605635530602 = 2804658786154 := by decide
theorem cert_e605635530602 : check e605635530602 [[],[]] .chain = true := by decide
def e605635536618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)) (.var 0)))))
theorem wire_e605635536618 : Closed e605635536618 ∧ code e605635536618 = 2804658792170 := by decide
theorem cert_e605635536618 : check e605635536618 [[],[]] .chain = true := by decide
def e605635536810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)) (.var 0)))))
theorem wire_e605635536810 : Closed e605635536810 ∧ code e605635536810 = 2804658792362 := by decide
theorem cert_e605635536810 : check e605635536810 [[],[]] .chain = true := by decide
def e605635539818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)) (.var 0)))))
theorem wire_e605635539818 : Closed e605635539818 ∧ code e605635539818 = 2804658795370 := by decide
theorem cert_e605635539818 : check e605635539818 [[],[]] .chain = true := by decide
def e605635539882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)) (.var 0)))))
theorem wire_e605635539882 : Closed e605635539882 ∧ code e605635539882 = 2804658795434 := by decide
theorem cert_e605635539882 : check e605635539882 [[],[]] .chain = true := by decide
def e605635751354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e605635751354 : Closed e605635751354 ∧ code e605635751354 = 2804659006906 := by decide
theorem cert_e605635751354 : check e605635751354 [[],[]] .chain = true := by decide
def e605635751386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e605635751386 : Closed e605635751386 ∧ code e605635751386 = 2804659006938 := by decide
theorem cert_e605635751386 : check e605635751386 [[],[]] .chain = true := by decide
def e605635751610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e605635751610 : Closed e605635751610 ∧ code e605635751610 = 2804659007162 := by decide
theorem cert_e605635751610 : check e605635751610 [[],[]] .chain = true := by decide
def e605635751658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e605635751658 : Closed e605635751658 ∧ code e605635751658 = 2804659007210 := by decide
theorem cert_e605635751658 : check e605635751658 [[],[]] .chain = true := by decide
def e605635751770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e605635751770 : Closed e605635751770 ∧ code e605635751770 = 2804659007322 := by decide
theorem cert_e605635751770 : check e605635751770 [[],[]] .chain = true := by decide
def e605635751786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e605635751786 : Closed e605635751786 ∧ code e605635751786 = 2804659007338 := by decide
theorem cert_e605635751786 : check e605635751786 [[],[]] .chain = true := by decide
def e605635752890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e605635752890 : Closed e605635752890 ∧ code e605635752890 = 2804659008442 := by decide
theorem cert_e605635752890 : check e605635752890 [[],[]] .chain = true := by decide
def e605635752922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e605635752922 : Closed e605635752922 ∧ code e605635752922 = 2804659008474 := by decide
theorem cert_e605635752922 : check e605635752922 [[],[]] .chain = true := by decide
def e605635754426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e605635754426 : Closed e605635754426 ∧ code e605635754426 = 2804659009978 := by decide
theorem cert_e605635754426 : check e605635754426 [[],[]] .chain = true := by decide
def e605635754474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e605635754474 : Closed e605635754474 ∧ code e605635754474 = 2804659010026 := by decide
theorem cert_e605635754474 : check e605635754474 [[],[]] .chain = true := by decide
def e605635755226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e605635755226 : Closed e605635755226 ∧ code e605635755226 = 2804659010778 := by decide
theorem cert_e605635755226 : check e605635755226 [[],[]] .chain = true := by decide
def e605635755242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e605635755242 : Closed e605635755242 ∧ code e605635755242 = 2804659010794 := by decide
theorem cert_e605635755242 : check e605635755242 [[],[]] .chain = true := by decide
def e605635808110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605635808110 : Closed e605635808110 ∧ code e605635808110 = 2804659063662 := by decide
theorem cert_e605635808110 : check e605635808110 [[],[]] .chain = true := by decide
def e605635808118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605635808118 : Closed e605635808118 ∧ code e605635808118 = 2804659063670 := by decide
theorem cert_e605635808118 : check e605635808118 [[],[]] .chain = true := by decide
def e605635808174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605635808174 : Closed e605635808174 ∧ code e605635808174 = 2804659063726 := by decide
theorem cert_e605635808174 : check e605635808174 [[],[]] .chain = true := by decide
def e605635808186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605635808186 : Closed e605635808186 ∧ code e605635808186 = 2804659063738 := by decide
theorem cert_e605635808186 : check e605635808186 [[],[]] .chain = true := by decide
def e605635808214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605635808214 : Closed e605635808214 ∧ code e605635808214 = 2804659063766 := by decide
theorem cert_e605635808214 : check e605635808214 [[],[]] .chain = true := by decide
def e605635808218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605635808218 : Closed e605635808218 ∧ code e605635808218 = 2804659063770 := by decide
theorem cert_e605635808218 : check e605635808218 [[],[]] .chain = true := by decide
def e605635808494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605635808494 : Closed e605635808494 ∧ code e605635808494 = 2804659064046 := by decide
theorem cert_e605635808494 : check e605635808494 [[],[]] .chain = true := by decide
def e605635808502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605635808502 : Closed e605635808502 ∧ code e605635808502 = 2804659064054 := by decide
theorem cert_e605635808502 : check e605635808502 [[],[]] .chain = true := by decide
def e605635808878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605635808878 : Closed e605635808878 ∧ code e605635808878 = 2804659064430 := by decide
theorem cert_e605635808878 : check e605635808878 [[],[]] .chain = true := by decide
def e605635808890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605635808890 : Closed e605635808890 ∧ code e605635808890 = 2804659064442 := by decide
theorem cert_e605635808890 : check e605635808890 [[],[]] .chain = true := by decide
def e605635809078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605635809078 : Closed e605635809078 ∧ code e605635809078 = 2804659064630 := by decide
theorem cert_e605635809078 : check e605635809078 [[],[]] .chain = true := by decide
def e605635809082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605635809082 : Closed e605635809082 ∧ code e605635809082 = 2804659064634 := by decide
theorem cert_e605635809082 : check e605635809082 [[],[]] .chain = true := by decide
def e605636537786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0)))))
theorem wire_e605636537786 : Closed e605636537786 ∧ code e605636537786 = 2804659793338 := by decide
theorem cert_e605636537786 : check e605636537786 [[],[]] .smaller = true := by decide
def e605636537818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0)))))
theorem wire_e605636537818 : Closed e605636537818 ∧ code e605636537818 = 2804659793370 := by decide
theorem cert_e605636537818 : check e605636537818 [[],[]] .smaller = true := by decide
def e605636538042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0)))))
theorem wire_e605636538042 : Closed e605636538042 ∧ code e605636538042 = 2804659793594 := by decide
theorem cert_e605636538042 : check e605636538042 [[],[]] .smaller = true := by decide
def e605636538090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0)))))
theorem wire_e605636538090 : Closed e605636538090 ∧ code e605636538090 = 2804659793642 := by decide
theorem cert_e605636538090 : check e605636538090 [[],[]] .smaller = true := by decide
def e605636538202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0)))))
theorem wire_e605636538202 : Closed e605636538202 ∧ code e605636538202 = 2804659793754 := by decide
theorem cert_e605636538202 : check e605636538202 [[],[]] .smaller = true := by decide
def e605636538218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0)))))
theorem wire_e605636538218 : Closed e605636538218 ∧ code e605636538218 = 2804659793770 := by decide
theorem cert_e605636538218 : check e605636538218 [[],[]] .smaller = true := by decide
def e605636539322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0)))))
theorem wire_e605636539322 : Closed e605636539322 ∧ code e605636539322 = 2804659794874 := by decide
theorem cert_e605636539322 : check e605636539322 [[],[]] .smaller = true := by decide
def e605636539354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0)))))
theorem wire_e605636539354 : Closed e605636539354 ∧ code e605636539354 = 2804659794906 := by decide
theorem cert_e605636539354 : check e605636539354 [[],[]] .smaller = true := by decide
def e605636540858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0)))))
theorem wire_e605636540858 : Closed e605636540858 ∧ code e605636540858 = 2804659796410 := by decide
theorem cert_e605636540858 : check e605636540858 [[],[]] .smaller = true := by decide
def e605636540906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0)))))
theorem wire_e605636540906 : Closed e605636540906 ∧ code e605636540906 = 2804659796458 := by decide
theorem cert_e605636540906 : check e605636540906 [[],[]] .smaller = true := by decide
def e605636541658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0)))))
theorem wire_e605636541658 : Closed e605636541658 ∧ code e605636541658 = 2804659797210 := by decide
theorem cert_e605636541658 : check e605636541658 [[],[]] .smaller = true := by decide
def e605636541674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0)))))
theorem wire_e605636541674 : Closed e605636541674 ∧ code e605636541674 = 2804659797226 := by decide
theorem cert_e605636541674 : check e605636541674 [[],[]] .smaller = true := by decide
def e605636572898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0))))))
theorem wire_e605636572898 : Closed e605636572898 ∧ code e605636572898 = 2804659828450 := by decide
theorem cert_e605636572898 : check e605636572898 [[],[]] .smaller = true := by decide
def e605636572918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))) (.var 1)))))
theorem wire_e605636572918 : Closed e605636572918 ∧ code e605636572918 = 2804659828470 := by decide
theorem cert_e605636572918 : check e605636572918 [[],[]] .sourceHead = true := by decide
def e605636573026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0))))))
theorem wire_e605636573026 : Closed e605636573026 ∧ code e605636573026 = 2804659828578 := by decide
theorem cert_e605636573026 : check e605636573026 [[],[]] .smaller = true := by decide
def e605636573050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))) (.var 0)))))
theorem wire_e605636573050 : Closed e605636573050 ∧ code e605636573050 = 2804659828602 := by decide
theorem cert_e605636573050 : check e605636573050 [[],[]] .chain = true := by decide
def e605636573110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))) (.var 1)))))
theorem wire_e605636573110 : Closed e605636573110 ∧ code e605636573110 = 2804659828662 := by decide
theorem cert_e605636573110 : check e605636573110 [[],[]] .sourceHead = true := by decide
def e605636573114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))) (.var 0)))))
theorem wire_e605636573114 : Closed e605636573114 ∧ code e605636573114 = 2804659828666 := by decide
theorem cert_e605636573114 : check e605636573114 [[],[]] .chain = true := by decide
def e605636573922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0))))))
theorem wire_e605636573922 : Closed e605636573922 ∧ code e605636573922 = 2804659829474 := by decide
theorem cert_e605636573922 : check e605636573922 [[],[]] .smaller = true := by decide
def e605636573942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))) (.var 1)))))
theorem wire_e605636573942 : Closed e605636573942 ∧ code e605636573942 = 2804659829494 := by decide
theorem cert_e605636573942 : check e605636573942 [[],[]] .sourceHead = true := by decide
def e605636574114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0))))))
theorem wire_e605636574114 : Closed e605636574114 ∧ code e605636574114 = 2804659829666 := by decide
theorem cert_e605636574114 : check e605636574114 [[],[]] .smaller = true := by decide
def e605636574166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))) (.var 1)))))
theorem wire_e605636574166 : Closed e605636574166 ∧ code e605636574166 = 2804659829718 := by decide
theorem cert_e605636574166 : check e605636574166 [[],[]] .sourceHead = true := by decide
def e605636574562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0))))))
theorem wire_e605636574562 : Closed e605636574562 ∧ code e605636574562 = 2804659830114 := by decide
theorem cert_e605636574562 : check e605636574562 [[],[]] .smaller = true := by decide
def e605636574586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))) (.var 0)))))
theorem wire_e605636574586 : Closed e605636574586 ∧ code e605636574586 = 2804659830138 := by decide
theorem cert_e605636574586 : check e605636574586 [[],[]] .chain = true := by decide
def e605636574626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0))))))
theorem wire_e605636574626 : Closed e605636574626 ∧ code e605636574626 = 2804659830178 := by decide
theorem cert_e605636574626 : check e605636574626 [[],[]] .smaller = true := by decide
def e605636574698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))) (.var 0)))))
theorem wire_e605636574698 : Closed e605636574698 ∧ code e605636574698 = 2804659830250 := by decide
theorem cert_e605636574698 : check e605636574698 [[],[]] .chain = true := by decide
def e605636574902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))) (.var 1)))))
theorem wire_e605636574902 : Closed e605636574902 ∧ code e605636574902 = 2804659830454 := by decide
theorem cert_e605636574902 : check e605636574902 [[],[]] .sourceHead = true := by decide
def e605636574906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e605636574906 : Closed e605636574906 ∧ code e605636574906 = 2804659830458 := by decide
theorem cert_e605636574906 : check e605636574906 [[],[]] .chain = true := by decide
def e605636574934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))) (.var 1)))))
theorem wire_e605636574934 : Closed e605636574934 ∧ code e605636574934 = 2804659830486 := by decide
theorem cert_e605636574934 : check e605636574934 [[],[]] .sourceHead = true := by decide
def e605636574954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e605636574954 : Closed e605636574954 ∧ code e605636574954 = 2804659830506 := by decide
theorem cert_e605636574954 : check e605636574954 [[],[]] .chain = true := by decide
def e605636579042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0))))))
theorem wire_e605636579042 : Closed e605636579042 ∧ code e605636579042 = 2804659834594 := by decide
theorem cert_e605636579042 : check e605636579042 [[],[]] .smaller = true := by decide
def e605636579062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))) (.var 1)))))
theorem wire_e605636579062 : Closed e605636579062 ∧ code e605636579062 = 2804659834614 := by decide
theorem cert_e605636579062 : check e605636579062 [[],[]] .sourceHead = true := by decide
def e605636579170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0))))))
theorem wire_e605636579170 : Closed e605636579170 ∧ code e605636579170 = 2804659834722 := by decide
theorem cert_e605636579170 : check e605636579170 [[],[]] .smaller = true := by decide
def e605636579194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))) (.var 0)))))
theorem wire_e605636579194 : Closed e605636579194 ∧ code e605636579194 = 2804659834746 := by decide
theorem cert_e605636579194 : check e605636579194 [[],[]] .chain = true := by decide
def e605636579254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))) (.var 1)))))
theorem wire_e605636579254 : Closed e605636579254 ∧ code e605636579254 = 2804659834806 := by decide
theorem cert_e605636579254 : check e605636579254 [[],[]] .sourceHead = true := by decide
def e605636579258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))) (.var 0)))))
theorem wire_e605636579258 : Closed e605636579258 ∧ code e605636579258 = 2804659834810 := by decide
theorem cert_e605636579258 : check e605636579258 [[],[]] .chain = true := by decide
def e605636585186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0))))))
theorem wire_e605636585186 : Closed e605636585186 ∧ code e605636585186 = 2804659840738 := by decide
theorem cert_e605636585186 : check e605636585186 [[],[]] .smaller = true := by decide
def e605636585206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))) (.var 1)))))
theorem wire_e605636585206 : Closed e605636585206 ∧ code e605636585206 = 2804659840758 := by decide
theorem cert_e605636585206 : check e605636585206 [[],[]] .sourceHead = true := by decide
def e605636585378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0))))))
theorem wire_e605636585378 : Closed e605636585378 ∧ code e605636585378 = 2804659840930 := by decide
theorem cert_e605636585378 : check e605636585378 [[],[]] .smaller = true := by decide
def e605636585430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))) (.var 1)))))
theorem wire_e605636585430 : Closed e605636585430 ∧ code e605636585430 = 2804659840982 := by decide
theorem cert_e605636585430 : check e605636585430 [[],[]] .sourceHead = true := by decide
def e605636588386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0))))))
theorem wire_e605636588386 : Closed e605636588386 ∧ code e605636588386 = 2804659843938 := by decide
theorem cert_e605636588386 : check e605636588386 [[],[]] .smaller = true := by decide
def e605636588410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))) (.var 0)))))
theorem wire_e605636588410 : Closed e605636588410 ∧ code e605636588410 = 2804659843962 := by decide
theorem cert_e605636588410 : check e605636588410 [[],[]] .chain = true := by decide
def e605636588450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0))))))
theorem wire_e605636588450 : Closed e605636588450 ∧ code e605636588450 = 2804659844002 := by decide
theorem cert_e605636588450 : check e605636588450 [[],[]] .smaller = true := by decide
def e605636588522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))) (.var 0)))))
theorem wire_e605636588522 : Closed e605636588522 ∧ code e605636588522 = 2804659844074 := by decide
theorem cert_e605636588522 : check e605636588522 [[],[]] .chain = true := by decide
def e605636590006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 1)))))
theorem wire_e605636590006 : Closed e605636590006 ∧ code e605636590006 = 2804659845558 := by decide
theorem cert_e605636590006 : check e605636590006 [[],[]] .sourceHead = true := by decide
def e605636590010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e605636590010 : Closed e605636590010 ∧ code e605636590010 = 2804659845562 := by decide
theorem cert_e605636590010 : check e605636590010 [[],[]] .chain = true := by decide
def e605636590038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 1)))))
theorem wire_e605636590038 : Closed e605636590038 ∧ code e605636590038 = 2804659845590 := by decide
theorem cert_e605636590038 : check e605636590038 [[],[]] .sourceHead = true := by decide
def e605636590058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e605636590058 : Closed e605636590058 ∧ code e605636590058 = 2804659845610 := by decide
theorem cert_e605636590058 : check e605636590058 [[],[]] .chain = true := by decide
def e605636594542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605636594542 : Closed e605636594542 ∧ code e605636594542 = 2804659850094 := by decide
theorem cert_e605636594542 : check e605636594542 [[],[]] .chain = true := by decide
def e605636594550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605636594550 : Closed e605636594550 ∧ code e605636594550 = 2804659850102 := by decide
theorem cert_e605636594550 : check e605636594550 [[],[]] .chain = true := by decide
def e605636594606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605636594606 : Closed e605636594606 ∧ code e605636594606 = 2804659850158 := by decide
theorem cert_e605636594606 : check e605636594606 [[],[]] .chain = true := by decide
def e605636594618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605636594618 : Closed e605636594618 ∧ code e605636594618 = 2804659850170 := by decide
theorem cert_e605636594618 : check e605636594618 [[],[]] .chain = true := by decide
def e605636594646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605636594646 : Closed e605636594646 ∧ code e605636594646 = 2804659850198 := by decide
theorem cert_e605636594646 : check e605636594646 [[],[]] .chain = true := by decide
def e605636594650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605636594650 : Closed e605636594650 ∧ code e605636594650 = 2804659850202 := by decide
theorem cert_e605636594650 : check e605636594650 [[],[]] .chain = true := by decide
def e605636594926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605636594926 : Closed e605636594926 ∧ code e605636594926 = 2804659850478 := by decide
theorem cert_e605636594926 : check e605636594926 [[],[]] .chain = true := by decide
def e605636594934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605636594934 : Closed e605636594934 ∧ code e605636594934 = 2804659850486 := by decide
theorem cert_e605636594934 : check e605636594934 [[],[]] .chain = true := by decide
def e605636595310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605636595310 : Closed e605636595310 ∧ code e605636595310 = 2804659850862 := by decide
theorem cert_e605636595310 : check e605636595310 [[],[]] .chain = true := by decide
def e605636595322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605636595322 : Closed e605636595322 ∧ code e605636595322 = 2804659850874 := by decide
theorem cert_e605636595322 : check e605636595322 [[],[]] .chain = true := by decide
def e605636595510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605636595510 : Closed e605636595510 ∧ code e605636595510 = 2804659851062 := by decide
theorem cert_e605636595510 : check e605636595510 [[],[]] .chain = true := by decide
def e605636595514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605636595514 : Closed e605636595514 ∧ code e605636595514 = 2804659851066 := by decide
theorem cert_e605636595514 : check e605636595514 [[],[]] .chain = true := by decide
def e605636703674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e605636703674 : Closed e605636703674 ∧ code e605636703674 = 2804659959226 := by decide
theorem cert_e605636703674 : check e605636703674 [[],[]] .chain = true := by decide
def e605636703706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e605636703706 : Closed e605636703706 ∧ code e605636703706 = 2804659959258 := by decide
theorem cert_e605636703706 : check e605636703706 [[],[]] .chain = true := by decide
def e605636703930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e605636703930 : Closed e605636703930 ∧ code e605636703930 = 2804659959482 := by decide
theorem cert_e605636703930 : check e605636703930 [[],[]] .chain = true := by decide
def e605636703978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e605636703978 : Closed e605636703978 ∧ code e605636703978 = 2804659959530 := by decide
theorem cert_e605636703978 : check e605636703978 [[],[]] .chain = true := by decide
def e605636704090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e605636704090 : Closed e605636704090 ∧ code e605636704090 = 2804659959642 := by decide
theorem cert_e605636704090 : check e605636704090 [[],[]] .chain = true := by decide
def e605636704106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e605636704106 : Closed e605636704106 ∧ code e605636704106 = 2804659959658 := by decide
theorem cert_e605636704106 : check e605636704106 [[],[]] .chain = true := by decide
def e605636704954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e605636704954 : Closed e605636704954 ∧ code e605636704954 = 2804659960506 := by decide
theorem cert_e605636704954 : check e605636704954 [[],[]] .chain = true := by decide
def e605636705002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e605636705002 : Closed e605636705002 ∧ code e605636705002 = 2804659960554 := by decide
theorem cert_e605636705002 : check e605636705002 [[],[]] .chain = true := by decide
def e605636705194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))) (.var 0)))))
theorem wire_e605636705194 : Closed e605636705194 ∧ code e605636705194 = 2804659960746 := by decide
theorem cert_e605636705194 : check e605636705194 [[],[]] .chain = true := by decide
def e605636705626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e605636705626 : Closed e605636705626 ∧ code e605636705626 = 2804659961178 := by decide
theorem cert_e605636705626 : check e605636705626 [[],[]] .chain = true := by decide
def e605636705642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e605636705642 : Closed e605636705642 ∧ code e605636705642 = 2804659961194 := by decide
theorem cert_e605636705642 : check e605636705642 [[],[]] .chain = true := by decide
def e605636705706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))) (.var 0)))))
theorem wire_e605636705706 : Closed e605636705706 ∧ code e605636705706 = 2804659961258 := by decide
theorem cert_e605636705706 : check e605636705706 [[],[]] .chain = true := by decide
def e605636708214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))) (.var 1)))))
theorem wire_e605636708214 : Closed e605636708214 ∧ code e605636708214 = 2804659963766 := by decide
theorem cert_e605636708214 : check e605636708214 [[],[]] .sourceHead = true := by decide
def e605636708278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))) (.var 1)))))
theorem wire_e605636708278 : Closed e605636708278 ∧ code e605636708278 = 2804659963830 := by decide
theorem cert_e605636708278 : check e605636708278 [[],[]] .sourceHead = true := by decide
def e605636709818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))) (.var 0)))))
theorem wire_e605636709818 : Closed e605636709818 ∧ code e605636709818 = 2804659965370 := by decide
theorem cert_e605636709818 : check e605636709818 [[],[]] .chain = true := by decide
def e605636709850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))) (.var 0)))))
theorem wire_e605636709850 : Closed e605636709850 ∧ code e605636709850 = 2804659965402 := by decide
theorem cert_e605636709850 : check e605636709850 [[],[]] .chain = true := by decide
def e605636710074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))) (.var 0)))))
theorem wire_e605636710074 : Closed e605636710074 ∧ code e605636710074 = 2804659965626 := by decide
theorem cert_e605636710074 : check e605636710074 [[],[]] .chain = true := by decide
def e605636710122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))) (.var 0)))))
theorem wire_e605636710122 : Closed e605636710122 ∧ code e605636710122 = 2804659965674 := by decide
theorem cert_e605636710122 : check e605636710122 [[],[]] .chain = true := by decide
def e605636710234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))) (.var 0)))))
theorem wire_e605636710234 : Closed e605636710234 ∧ code e605636710234 = 2804659965786 := by decide
theorem cert_e605636710234 : check e605636710234 [[],[]] .chain = true := by decide
def e605636710250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))) (.var 0)))))
theorem wire_e605636710250 : Closed e605636710250 ∧ code e605636710250 = 2804659965802 := by decide
theorem cert_e605636710250 : check e605636710250 [[],[]] .chain = true := by decide
def e605636711354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e605636711354 : Closed e605636711354 ∧ code e605636711354 = 2804659966906 := by decide
theorem cert_e605636711354 : check e605636711354 [[],[]] .chain = true := by decide
def e605636711386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e605636711386 : Closed e605636711386 ∧ code e605636711386 = 2804659966938 := by decide
theorem cert_e605636711386 : check e605636711386 [[],[]] .chain = true := by decide
def e605636712694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))) (.var 1)))))
theorem wire_e605636712694 : Closed e605636712694 ∧ code e605636712694 = 2804659968246 := by decide
theorem cert_e605636712694 : check e605636712694 [[],[]] .sourceHead = true := by decide
def e605636712890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e605636712890 : Closed e605636712890 ∧ code e605636712890 = 2804659968442 := by decide
theorem cert_e605636712890 : check e605636712890 [[],[]] .chain = true := by decide
def e605636712938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e605636712938 : Closed e605636712938 ∧ code e605636712938 = 2804659968490 := by decide
theorem cert_e605636712938 : check e605636712938 [[],[]] .chain = true := by decide
def e605636713346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.lam (.var 0)))))))
theorem wire_e605636713346 : Closed e605636713346 ∧ code e605636713346 = 2804659968898 := by decide
theorem cert_e605636713346 : check e605636713346 [[],[]] .chain = true := by decide
def e605636713358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 2))))))
theorem wire_e605636713358 : Closed e605636713358 ∧ code e605636713358 = 2804659968910 := by decide
theorem cert_e605636713358 : check e605636713358 [[],[]] .sourceHead = true := by decide
def e605636713370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.app (.var 0) (.var 0))))))
theorem wire_e605636713370 : Closed e605636713370 ∧ code e605636713370 = 2804659968922 := by decide
theorem cert_e605636713370 : check e605636713370 [[],[]] .chain = true := by decide
def e605636713590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))) (.var 1)))))
theorem wire_e605636713590 : Closed e605636713590 ∧ code e605636713590 = 2804659969142 := by decide
theorem cert_e605636713590 : check e605636713590 [[],[]] .sourceHead = true := by decide
def e605636713690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e605636713690 : Closed e605636713690 ∧ code e605636713690 = 2804659969242 := by decide
theorem cert_e605636713690 : check e605636713690 [[],[]] .chain = true := by decide
def e605636713706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e605636713706 : Closed e605636713706 ∧ code e605636713706 = 2804659969258 := by decide
theorem cert_e605636713706 : check e605636713706 [[],[]] .chain = true := by decide
def e605636713858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.lam (.var 0)))))))
theorem wire_e605636713858 : Closed e605636713858 ∧ code e605636713858 = 2804659969410 := by decide
theorem cert_e605636713858 : check e605636713858 [[],[]] .chain = true := by decide
def e605636713870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 2))))))
theorem wire_e605636713870 : Closed e605636713870 ∧ code e605636713870 = 2804659969422 := by decide
theorem cert_e605636713870 : check e605636713870 [[],[]] .sourceHead = true := by decide
def e605636713882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.app (.var 0) (.var 0))))))
theorem wire_e605636713882 : Closed e605636713882 ∧ code e605636713882 = 2804659969434 := by decide
theorem cert_e605636713882 : check e605636713882 [[],[]] .chain = true := by decide
def e605636715382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))) (.var 1)))))
theorem wire_e605636715382 : Closed e605636715382 ∧ code e605636715382 = 2804659970934 := by decide
theorem cert_e605636715382 : check e605636715382 [[],[]] .sourceHead = true := by decide
def e605636715478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))) (.var 1)))))
theorem wire_e605636715478 : Closed e605636715478 ∧ code e605636715478 = 2804659971030 := by decide
theorem cert_e605636715478 : check e605636715478 [[],[]] .sourceHead = true := by decide
def e605636716218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))) (.var 0)))))
theorem wire_e605636716218 : Closed e605636716218 ∧ code e605636716218 = 2804659971770 := by decide
theorem cert_e605636716218 : check e605636716218 [[],[]] .chain = true := by decide
def e605636716266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))) (.var 0)))))
theorem wire_e605636716266 : Closed e605636716266 ∧ code e605636716266 = 2804659971818 := by decide
theorem cert_e605636716266 : check e605636716266 [[],[]] .chain = true := by decide
def e605636716458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))) (.var 0)))))
theorem wire_e605636716458 : Closed e605636716458 ∧ code e605636716458 = 2804659972010 := by decide
theorem cert_e605636716458 : check e605636716458 [[],[]] .chain = true := by decide
def e605636716790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))) (.var 1)))))
theorem wire_e605636716790 : Closed e605636716790 ∧ code e605636716790 = 2804659972342 := by decide
theorem cert_e605636716790 : check e605636716790 [[],[]] .sourceHead = true := by decide
def e605636716986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e605636716986 : Closed e605636716986 ∧ code e605636716986 = 2804659972538 := by decide
theorem cert_e605636716986 : check e605636716986 [[],[]] .chain = true := by decide
def e605636717034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e605636717034 : Closed e605636717034 ∧ code e605636717034 = 2804659972586 := by decide
theorem cert_e605636717034 : check e605636717034 [[],[]] .chain = true := by decide
def e605636717442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.lam (.var 0)))))))
theorem wire_e605636717442 : Closed e605636717442 ∧ code e605636717442 = 2804659972994 := by decide
theorem cert_e605636717442 : check e605636717442 [[],[]] .chain = true := by decide
def e605636717454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 2))))))
theorem wire_e605636717454 : Closed e605636717454 ∧ code e605636717454 = 2804659973006 := by decide
theorem cert_e605636717454 : check e605636717454 [[],[]] .sourceHead = true := by decide
def e605636717466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.app (.var 0) (.var 0))))))
theorem wire_e605636717466 : Closed e605636717466 ∧ code e605636717466 = 2804659973018 := by decide
theorem cert_e605636717466 : check e605636717466 [[],[]] .chain = true := by decide
def e605636718134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))) (.var 1)))))
theorem wire_e605636718134 : Closed e605636718134 ∧ code e605636718134 = 2804659973686 := by decide
theorem cert_e605636718134 : check e605636718134 [[],[]] .sourceHead = true := by decide
def e605636718186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))) (.var 0)))))
theorem wire_e605636718186 : Closed e605636718186 ∧ code e605636718186 = 2804659973738 := by decide
theorem cert_e605636718186 : check e605636718186 [[],[]] .chain = true := by decide
def e605636718210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.lam (.var 0)))))))
theorem wire_e605636718210 : Closed e605636718210 ∧ code e605636718210 = 2804659973762 := by decide
theorem cert_e605636718210 : check e605636718210 [[],[]] .chain = true := by decide
def e605636718222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 2))))))
theorem wire_e605636718222 : Closed e605636718222 ∧ code e605636718222 = 2804659973774 := by decide
theorem cert_e605636718222 : check e605636718222 [[],[]] .sourceHead = true := by decide
def e605636718234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.app (.var 0) (.var 0))))))
theorem wire_e605636718234 : Closed e605636718234 ∧ code e605636718234 = 2804659973786 := by decide
theorem cert_e605636718234 : check e605636718234 [[],[]] .chain = true := by decide
def e605636719030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))) (.var 1)))))
theorem wire_e605636719030 : Closed e605636719030 ∧ code e605636719030 = 2804659974582 := by decide
theorem cert_e605636719030 : check e605636719030 [[],[]] .sourceHead = true := by decide
def e605636719062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))) (.var 1)))))
theorem wire_e605636719062 : Closed e605636719062 ∧ code e605636719062 = 2804659974614 := by decide
theorem cert_e605636719062 : check e605636719062 [[],[]] .sourceHead = true := by decide
def e605636719450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))) (.var 0)))))
theorem wire_e605636719450 : Closed e605636719450 ∧ code e605636719450 = 2804659975002 := by decide
theorem cert_e605636719450 : check e605636719450 [[],[]] .chain = true := by decide
def e605636719466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))) (.var 0)))))
theorem wire_e605636719466 : Closed e605636719466 ∧ code e605636719466 = 2804659975018 := by decide
theorem cert_e605636719466 : check e605636719466 [[],[]] .chain = true := by decide
def e605636719530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))) (.var 0)))))
theorem wire_e605636719530 : Closed e605636719530 ∧ code e605636719530 = 2804659975082 := by decide
theorem cert_e605636719530 : check e605636719530 [[],[]] .chain = true := by decide
def e605636719734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))) (.var 1)))))
theorem wire_e605636719734 : Closed e605636719734 ∧ code e605636719734 = 2804659975286 := by decide
theorem cert_e605636719734 : check e605636719734 [[],[]] .sourceHead = true := by decide
def e605636719834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e605636719834 : Closed e605636719834 ∧ code e605636719834 = 2804659975386 := by decide
theorem cert_e605636719834 : check e605636719834 [[],[]] .chain = true := by decide
def e605636719850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e605636719850 : Closed e605636719850 ∧ code e605636719850 = 2804659975402 := by decide
theorem cert_e605636719850 : check e605636719850 [[],[]] .chain = true := by decide
def e605636720002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.lam (.var 0)))))))
theorem wire_e605636720002 : Closed e605636720002 ∧ code e605636720002 = 2804659975554 := by decide
theorem cert_e605636720002 : check e605636720002 [[],[]] .chain = true := by decide
def e605636720014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 2))))))
theorem wire_e605636720014 : Closed e605636720014 ∧ code e605636720014 = 2804659975566 := by decide
theorem cert_e605636720014 : check e605636720014 [[],[]] .sourceHead = true := by decide
end Blc.Floor41
