import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e565023176302 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e565023176302 : Closed e565023176302 ∧ code e565023176302 = 2764046431854 := by decide
theorem cert_e565023176302 : check e565023176302 [[],[.under]] .three = true := by decide
def e565023176314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e565023176314 : Closed e565023176314 ∧ code e565023176314 = 2764046431866 := by decide
theorem cert_e565023176314 : check e565023176314 [[],[.under]] .three = true := by decide
def e565023176502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e565023176502 : Closed e565023176502 ∧ code e565023176502 = 2764046432054 := by decide
theorem cert_e565023176502 : check e565023176502 [[],[.under]] .three = true := by decide
def e565023176506 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e565023176506 : Closed e565023176506 ∧ code e565023176506 = 2764046432058 := by decide
theorem cert_e565023176506 : check e565023176506 [[],[.under]] .three = true := by decide
def e565023177142 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e565023177142 : Closed e565023177142 ∧ code e565023177142 = 2764046432694 := by decide
theorem cert_e565023177142 : check e565023177142 [[],[.under]] .three = true := by decide
def e565023177174 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e565023177174 : Closed e565023177174 ∧ code e565023177174 = 2764046432726 := by decide
theorem cert_e565023177174 : check e565023177174 [[],[.under]] .three = true := by decide
def e565023177178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e565023177178 : Closed e565023177178 ∧ code e565023177178 = 2764046432730 := by decide
theorem cert_e565023177178 : check e565023177178 [[],[.under]] .three = true := by decide
def e565023177334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e565023177334 : Closed e565023177334 ∧ code e565023177334 = 2764046432886 := by decide
theorem cert_e565023177334 : check e565023177334 [[],[.under]] .three = true := by decide
def e565023177526 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e565023177526 : Closed e565023177526 ∧ code e565023177526 = 2764046433078 := by decide
theorem cert_e565023177526 : check e565023177526 [[],[.under]] .three = true := by decide
def e565023177530 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e565023177530 : Closed e565023177530 ∧ code e565023177530 = 2764046433082 := by decide
theorem cert_e565023177530 : check e565023177530 [[],[.under]] .three = true := by decide
def e565023184750 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e565023184750 : Closed e565023184750 ∧ code e565023184750 = 2764046440302 := by decide
theorem cert_e565023184750 : check e565023184750 [[],[.under]] .three = true := by decide
def e565023184758 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e565023184758 : Closed e565023184758 ∧ code e565023184758 = 2764046440310 := by decide
theorem cert_e565023184758 : check e565023184758 [[],[.under]] .three = true := by decide
def e565023184822 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e565023184822 : Closed e565023184822 ∧ code e565023184822 = 2764046440374 := by decide
theorem cert_e565023184822 : check e565023184822 [[],[.under]] .three = true := by decide
def e565023186158 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e565023186158 : Closed e565023186158 ∧ code e565023186158 = 2764046441710 := by decide
theorem cert_e565023186158 : check e565023186158 [[],[.under]] .three = true := by decide
def e565023186166 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e565023186166 : Closed e565023186166 ∧ code e565023186166 = 2764046441718 := by decide
theorem cert_e565023186166 : check e565023186166 [[],[.under]] .three = true := by decide
def e565023186550 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e565023186550 : Closed e565023186550 ∧ code e565023186550 = 2764046442102 := by decide
theorem cert_e565023186550 : check e565023186550 [[],[.under]] .three = true := by decide
def e565023198062 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e565023198062 : Closed e565023198062 ∧ code e565023198062 = 2764046453614 := by decide
theorem cert_e565023198062 : check e565023198062 [[],[.under]] .three = true := by decide
def e565023198070 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e565023198070 : Closed e565023198070 ∧ code e565023198070 = 2764046453622 := by decide
theorem cert_e565023198070 : check e565023198070 [[],[.under]] .three = true := by decide
def e565023198126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e565023198126 : Closed e565023198126 ∧ code e565023198126 = 2764046453678 := by decide
theorem cert_e565023198126 : check e565023198126 [[],[.under]] .three = true := by decide
def e565023198138 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e565023198138 : Closed e565023198138 ∧ code e565023198138 = 2764046453690 := by decide
theorem cert_e565023198138 : check e565023198138 [[],[.under]] .three = true := by decide
def e565023198166 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e565023198166 : Closed e565023198166 ∧ code e565023198166 = 2764046453718 := by decide
theorem cert_e565023198166 : check e565023198166 [[],[.under]] .three = true := by decide
def e565023198170 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e565023198170 : Closed e565023198170 ∧ code e565023198170 = 2764046453722 := by decide
theorem cert_e565023198170 : check e565023198170 [[],[.under]] .three = true := by decide
def e565023198446 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e565023198446 : Closed e565023198446 ∧ code e565023198446 = 2764046453998 := by decide
theorem cert_e565023198446 : check e565023198446 [[],[.under]] .three = true := by decide
def e565023198454 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e565023198454 : Closed e565023198454 ∧ code e565023198454 = 2764046454006 := by decide
theorem cert_e565023198454 : check e565023198454 [[],[.under]] .three = true := by decide
def e565023198830 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e565023198830 : Closed e565023198830 ∧ code e565023198830 = 2764046454382 := by decide
theorem cert_e565023198830 : check e565023198830 [[],[.under]] .three = true := by decide
def e565023198842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e565023198842 : Closed e565023198842 ∧ code e565023198842 = 2764046454394 := by decide
theorem cert_e565023198842 : check e565023198842 [[],[.under]] .three = true := by decide
def e565023199030 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e565023199030 : Closed e565023199030 ∧ code e565023199030 = 2764046454582 := by decide
theorem cert_e565023199030 : check e565023199030 [[],[.under]] .three = true := by decide
def e565023199034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e565023199034 : Closed e565023199034 ∧ code e565023199034 = 2764046454586 := by decide
theorem cert_e565023199034 : check e565023199034 [[],[.under]] .three = true := by decide
def e565023204790 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e565023204790 : Closed e565023204790 ∧ code e565023204790 = 2764046460342 := by decide
theorem cert_e565023204790 : check e565023204790 [[],[.under]] .three = true := by decide
def e565023204822 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e565023204822 : Closed e565023204822 ∧ code e565023204822 = 2764046460374 := by decide
theorem cert_e565023204822 : check e565023204822 [[],[.under]] .three = true := by decide
def e565023204826 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e565023204826 : Closed e565023204826 ∧ code e565023204826 = 2764046460378 := by decide
theorem cert_e565023204826 : check e565023204826 [[],[.under]] .three = true := by decide
def e565023204982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e565023204982 : Closed e565023204982 ∧ code e565023204982 = 2764046460534 := by decide
theorem cert_e565023204982 : check e565023204982 [[],[.under]] .three = true := by decide
def e565023205174 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e565023205174 : Closed e565023205174 ∧ code e565023205174 = 2764046460726 := by decide
theorem cert_e565023205174 : check e565023205174 [[],[.under]] .three = true := by decide
def e565023205178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e565023205178 : Closed e565023205178 ∧ code e565023205178 = 2764046460730 := by decide
theorem cert_e565023205178 : check e565023205178 [[],[.under]] .three = true := by decide
def e565023542126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e565023542126 : Closed e565023542126 ∧ code e565023542126 = 2764046797678 := by decide
theorem cert_e565023542126 : check e565023542126 [[],[.under],[.under,.under]] .smaller = true := by decide
def e565023542134 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e565023542134 : Closed e565023542134 ∧ code e565023542134 = 2764046797686 := by decide
theorem cert_e565023542134 : check e565023542134 [[],[.under],[.under,.under]] .smaller = true := by decide
def e565023542190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e565023542190 : Closed e565023542190 ∧ code e565023542190 = 2764046797742 := by decide
theorem cert_e565023542190 : check e565023542190 [[],[.under],[.under,.under]] .smaller = true := by decide
def e565023542202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e565023542202 : Closed e565023542202 ∧ code e565023542202 = 2764046797754 := by decide
theorem cert_e565023542202 : check e565023542202 [[],[.under],[.under,.under]] .smaller = true := by decide
def e565023542230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e565023542230 : Closed e565023542230 ∧ code e565023542230 = 2764046797782 := by decide
theorem cert_e565023542230 : check e565023542230 [[],[.under],[.under,.under]] .smaller = true := by decide
def e565023542234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e565023542234 : Closed e565023542234 ∧ code e565023542234 = 2764046797786 := by decide
theorem cert_e565023542234 : check e565023542234 [[],[.under],[.under,.under]] .smaller = true := by decide
def e565023542510 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e565023542510 : Closed e565023542510 ∧ code e565023542510 = 2764046798062 := by decide
theorem cert_e565023542510 : check e565023542510 [[],[.under],[.under,.under]] .smaller = true := by decide
def e565023542518 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e565023542518 : Closed e565023542518 ∧ code e565023542518 = 2764046798070 := by decide
theorem cert_e565023542518 : check e565023542518 [[],[.under],[.under,.under]] .smaller = true := by decide
def e565023542894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e565023542894 : Closed e565023542894 ∧ code e565023542894 = 2764046798446 := by decide
theorem cert_e565023542894 : check e565023542894 [[],[.under],[.under,.under]] .smaller = true := by decide
def e565023542906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e565023542906 : Closed e565023542906 ∧ code e565023542906 = 2764046798458 := by decide
theorem cert_e565023542906 : check e565023542906 [[],[.under],[.under,.under]] .smaller = true := by decide
def e565023543094 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e565023543094 : Closed e565023543094 ∧ code e565023543094 = 2764046798646 := by decide
theorem cert_e565023543094 : check e565023543094 [[],[.under],[.under,.under]] .smaller = true := by decide
def e565023543098 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e565023543098 : Closed e565023543098 ∧ code e565023543098 = 2764046798650 := by decide
theorem cert_e565023543098 : check e565023543098 [[],[.under],[.under,.under]] .smaller = true := by decide
def e565196845254 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e565196845254 : Closed e565196845254 ∧ code e565196845254 = 2764220100806 := by decide
theorem cert_e565196845254 : check e565196845254 [[]] .width = true := by decide
def e565196861638 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e565196861638 : Closed e565196861638 ∧ code e565196861638 = 2764220117190 := by decide
theorem cert_e565196861638 : check e565196861638 [[]] .width = true := by decide
def e565196976326 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e565196976326 : Closed e565196976326 ∧ code e565196976326 = 2764220231878 := by decide
theorem cert_e565196976326 : check e565196976326 [[]] .width = true := by decide
def e565197000902 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e565197000902 : Closed e565197000902 ∧ code e565197000902 = 2764220256454 := by decide
theorem cert_e565197000902 : check e565197000902 [[]] .width = true := by decide
def e565197058246 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e565197058246 : Closed e565197058246 ∧ code e565197058246 = 2764220313798 := by decide
theorem cert_e565197058246 : check e565197058246 [[]] .width = true := by decide
def e565197066438 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e565197066438 : Closed e565197066438 ∧ code e565197066438 = 2764220321990 := by decide
theorem cert_e565197066438 : check e565197066438 [[]] .width = true := by decide
def e565197631686 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e565197631686 : Closed e565197631686 ∧ code e565197631686 = 2764220887238 := by decide
theorem cert_e565197631686 : check e565197631686 [[]] .width = true := by decide
def e565197648070 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e565197648070 : Closed e565197648070 ∧ code e565197648070 = 2764220903622 := by decide
theorem cert_e565197648070 : check e565197648070 [[]] .width = true := by decide
def e565198418118 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e565198418118 : Closed e565198418118 ∧ code e565198418118 = 2764221673670 := by decide
theorem cert_e565198418118 : check e565198418118 [[]] .width = true := by decide
def e565198442694 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e565198442694 : Closed e565198442694 ∧ code e565198442694 = 2764221698246 := by decide
theorem cert_e565198442694 : check e565198442694 [[]] .width = true := by decide
def e565198827718 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e565198827718 : Closed e565198827718 ∧ code e565198827718 = 2764222083270 := by decide
theorem cert_e565198827718 : check e565198827718 [[]] .width = true := by decide
def e565198835910 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e565198835910 : Closed e565198835910 ∧ code e565198835910 = 2764222091462 := by decide
theorem cert_e565198835910 : check e565198835910 [[]] .width = true := by decide
def e565241228654 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e565241228654 : Closed e565241228654 ∧ code e565241228654 = 2764264484206 := by decide
theorem cert_e565241228654 : check e565241228654 [[],[.under]] .three = true := by decide
def e565241228662 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e565241228662 : Closed e565241228662 ∧ code e565241228662 = 2764264484214 := by decide
theorem cert_e565241228662 : check e565241228662 [[],[.under]] .three = true := by decide
def e565241228718 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e565241228718 : Closed e565241228718 ∧ code e565241228718 = 2764264484270 := by decide
theorem cert_e565241228718 : check e565241228718 [[],[.under]] .three = true := by decide
def e565241228730 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e565241228730 : Closed e565241228730 ∧ code e565241228730 = 2764264484282 := by decide
theorem cert_e565241228730 : check e565241228730 [[],[.under]] .three = true := by decide
def e565241228758 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e565241228758 : Closed e565241228758 ∧ code e565241228758 = 2764264484310 := by decide
theorem cert_e565241228758 : check e565241228758 [[],[.under]] .three = true := by decide
def e565241228762 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e565241228762 : Closed e565241228762 ∧ code e565241228762 = 2764264484314 := by decide
theorem cert_e565241228762 : check e565241228762 [[],[.under]] .three = true := by decide
def e565241228974 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e565241228974 : Closed e565241228974 ∧ code e565241228974 = 2764264484526 := by decide
theorem cert_e565241228974 : check e565241228974 [[],[.under]] .three = true := by decide
def e565241228986 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e565241228986 : Closed e565241228986 ∧ code e565241228986 = 2764264484538 := by decide
theorem cert_e565241228986 : check e565241228986 [[],[.under]] .three = true := by decide
def e565241229034 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e565241229034 : Closed e565241229034 ∧ code e565241229034 = 2764264484586 := by decide
theorem cert_e565241229034 : check e565241229034 [[],[.under]] .three = true := by decide
def e565241229142 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e565241229142 : Closed e565241229142 ∧ code e565241229142 = 2764264484694 := by decide
theorem cert_e565241229142 : check e565241229142 [[],[.under]] .three = true := by decide
def e565241229146 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e565241229146 : Closed e565241229146 ∧ code e565241229146 = 2764264484698 := by decide
theorem cert_e565241229146 : check e565241229146 [[],[.under]] .three = true := by decide
def e565241229162 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e565241229162 : Closed e565241229162 ∧ code e565241229162 = 2764264484714 := by decide
theorem cert_e565241229162 : check e565241229162 [[],[.under]] .three = true := by decide
def e565241230190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e565241230190 : Closed e565241230190 ∧ code e565241230190 = 2764264485742 := by decide
theorem cert_e565241230190 : check e565241230190 [[],[.under]] .three = true := by decide
def e565241230198 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e565241230198 : Closed e565241230198 ∧ code e565241230198 = 2764264485750 := by decide
theorem cert_e565241230198 : check e565241230198 [[],[.under]] .three = true := by decide
def e565241230254 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e565241230254 : Closed e565241230254 ∧ code e565241230254 = 2764264485806 := by decide
theorem cert_e565241230254 : check e565241230254 [[],[.under]] .three = true := by decide
def e565241230266 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e565241230266 : Closed e565241230266 ∧ code e565241230266 = 2764264485818 := by decide
theorem cert_e565241230266 : check e565241230266 [[],[.under]] .three = true := by decide
def e565241230294 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e565241230294 : Closed e565241230294 ∧ code e565241230294 = 2764264485846 := by decide
theorem cert_e565241230294 : check e565241230294 [[],[.under]] .three = true := by decide
def e565241230298 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e565241230298 : Closed e565241230298 ∧ code e565241230298 = 2764264485850 := by decide
theorem cert_e565241230298 : check e565241230298 [[],[.under]] .three = true := by decide
def e565241230574 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e565241230574 : Closed e565241230574 ∧ code e565241230574 = 2764264486126 := by decide
theorem cert_e565241230574 : check e565241230574 [[],[.under]] .three = true := by decide
def e565241230582 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e565241230582 : Closed e565241230582 ∧ code e565241230582 = 2764264486134 := by decide
theorem cert_e565241230582 : check e565241230582 [[],[.under]] .three = true := by decide
def e565241230958 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e565241230958 : Closed e565241230958 ∧ code e565241230958 = 2764264486510 := by decide
theorem cert_e565241230958 : check e565241230958 [[],[.under]] .three = true := by decide
def e565241230970 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e565241230970 : Closed e565241230970 ∧ code e565241230970 = 2764264486522 := by decide
theorem cert_e565241230970 : check e565241230970 [[],[.under]] .three = true := by decide
def e565241231158 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e565241231158 : Closed e565241231158 ∧ code e565241231158 = 2764264486710 := by decide
theorem cert_e565241231158 : check e565241231158 [[],[.under]] .three = true := by decide
def e565241231162 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e565241231162 : Closed e565241231162 ∧ code e565241231162 = 2764264486714 := by decide
theorem cert_e565241231162 : check e565241231162 [[],[.under]] .three = true := by decide
def e565241231790 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e565241231790 : Closed e565241231790 ∧ code e565241231790 = 2764264487342 := by decide
theorem cert_e565241231790 : check e565241231790 [[],[.under]] .three = true := by decide
def e565241231802 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e565241231802 : Closed e565241231802 ∧ code e565241231802 = 2764264487354 := by decide
theorem cert_e565241231802 : check e565241231802 [[],[.under]] .three = true := by decide
def e565241231850 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e565241231850 : Closed e565241231850 ∧ code e565241231850 = 2764264487402 := by decide
theorem cert_e565241231850 : check e565241231850 [[],[.under]] .three = true := by decide
def e565241231982 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e565241231982 : Closed e565241231982 ∧ code e565241231982 = 2764264487534 := by decide
theorem cert_e565241231982 : check e565241231982 [[],[.under]] .three = true := by decide
def e565241231994 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e565241231994 : Closed e565241231994 ∧ code e565241231994 = 2764264487546 := by decide
theorem cert_e565241231994 : check e565241231994 [[],[.under]] .three = true := by decide
def e565241232282 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e565241232282 : Closed e565241232282 ∧ code e565241232282 = 2764264487834 := by decide
theorem cert_e565241232282 : check e565241232282 [[],[.under]] .three = true := by decide
def e565241232598 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e565241232598 : Closed e565241232598 ∧ code e565241232598 = 2764264488150 := by decide
theorem cert_e565241232598 : check e565241232598 [[],[.under]] .three = true := by decide
def e565241232602 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e565241232602 : Closed e565241232602 ∧ code e565241232602 = 2764264488154 := by decide
theorem cert_e565241232602 : check e565241232602 [[],[.under]] .three = true := by decide
def e565241232618 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e565241232618 : Closed e565241232618 ∧ code e565241232618 = 2764264488170 := by decide
theorem cert_e565241232618 : check e565241232618 [[],[.under]] .three = true := by decide
def e565241232694 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e565241232694 : Closed e565241232694 ∧ code e565241232694 = 2764264488246 := by decide
theorem cert_e565241232694 : check e565241232694 [[],[.under]] .three = true := by decide
def e565241232698 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e565241232698 : Closed e565241232698 ∧ code e565241232698 = 2764264488250 := by decide
theorem cert_e565241232698 : check e565241232698 [[],[.under]] .three = true := by decide
def e565241232794 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e565241232794 : Closed e565241232794 ∧ code e565241232794 = 2764264488346 := by decide
theorem cert_e565241232794 : check e565241232794 [[],[.under]] .three = true := by decide
def e565241236334 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e565241236334 : Closed e565241236334 ∧ code e565241236334 = 2764264491886 := by decide
theorem cert_e565241236334 : check e565241236334 [[],[.under]] .three = true := by decide
def e565241236342 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e565241236342 : Closed e565241236342 ∧ code e565241236342 = 2764264491894 := by decide
theorem cert_e565241236342 : check e565241236342 [[],[.under]] .three = true := by decide
def e565241236398 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e565241236398 : Closed e565241236398 ∧ code e565241236398 = 2764264491950 := by decide
theorem cert_e565241236398 : check e565241236398 [[],[.under]] .three = true := by decide
def e565241236410 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e565241236410 : Closed e565241236410 ∧ code e565241236410 = 2764264491962 := by decide
theorem cert_e565241236410 : check e565241236410 [[],[.under]] .three = true := by decide
def e565241236438 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e565241236438 : Closed e565241236438 ∧ code e565241236438 = 2764264491990 := by decide
theorem cert_e565241236438 : check e565241236438 [[],[.under]] .three = true := by decide
def e565241236442 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e565241236442 : Closed e565241236442 ∧ code e565241236442 = 2764264491994 := by decide
theorem cert_e565241236442 : check e565241236442 [[],[.under]] .three = true := by decide
def e565241236718 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e565241236718 : Closed e565241236718 ∧ code e565241236718 = 2764264492270 := by decide
theorem cert_e565241236718 : check e565241236718 [[],[.under]] .three = true := by decide
def e565241236726 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e565241236726 : Closed e565241236726 ∧ code e565241236726 = 2764264492278 := by decide
theorem cert_e565241236726 : check e565241236726 [[],[.under]] .three = true := by decide
def e565241237102 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e565241237102 : Closed e565241237102 ∧ code e565241237102 = 2764264492654 := by decide
theorem cert_e565241237102 : check e565241237102 [[],[.under]] .three = true := by decide
def e565241237114 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e565241237114 : Closed e565241237114 ∧ code e565241237114 = 2764264492666 := by decide
theorem cert_e565241237114 : check e565241237114 [[],[.under]] .three = true := by decide
def e565241237302 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e565241237302 : Closed e565241237302 ∧ code e565241237302 = 2764264492854 := by decide
theorem cert_e565241237302 : check e565241237302 [[],[.under]] .three = true := by decide
def e565241237306 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e565241237306 : Closed e565241237306 ∧ code e565241237306 = 2764264492858 := by decide
theorem cert_e565241237306 : check e565241237306 [[],[.under]] .three = true := by decide
def e565241243054 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e565241243054 : Closed e565241243054 ∧ code e565241243054 = 2764264498606 := by decide
theorem cert_e565241243054 : check e565241243054 [[],[.under]] .three = true := by decide
def e565241243066 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e565241243066 : Closed e565241243066 ∧ code e565241243066 = 2764264498618 := by decide
theorem cert_e565241243066 : check e565241243066 [[],[.under]] .three = true := by decide
def e565241243114 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e565241243114 : Closed e565241243114 ∧ code e565241243114 = 2764264498666 := by decide
theorem cert_e565241243114 : check e565241243114 [[],[.under]] .three = true := by decide
def e565241243246 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e565241243246 : Closed e565241243246 ∧ code e565241243246 = 2764264498798 := by decide
theorem cert_e565241243246 : check e565241243246 [[],[.under]] .three = true := by decide
def e565241243258 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e565241243258 : Closed e565241243258 ∧ code e565241243258 = 2764264498810 := by decide
theorem cert_e565241243258 : check e565241243258 [[],[.under]] .three = true := by decide
def e565241243546 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e565241243546 : Closed e565241243546 ∧ code e565241243546 = 2764264499098 := by decide
theorem cert_e565241243546 : check e565241243546 [[],[.under]] .three = true := by decide
def e565241246422 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e565241246422 : Closed e565241246422 ∧ code e565241246422 = 2764264501974 := by decide
theorem cert_e565241246422 : check e565241246422 [[],[.under]] .three = true := by decide
def e565241246426 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e565241246426 : Closed e565241246426 ∧ code e565241246426 = 2764264501978 := by decide
theorem cert_e565241246426 : check e565241246426 [[],[.under]] .three = true := by decide
def e565241246442 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e565241246442 : Closed e565241246442 ∧ code e565241246442 = 2764264501994 := by decide
theorem cert_e565241246442 : check e565241246442 [[],[.under]] .three = true := by decide
def e565241246518 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e565241246518 : Closed e565241246518 ∧ code e565241246518 = 2764264502070 := by decide
theorem cert_e565241246518 : check e565241246518 [[],[.under]] .three = true := by decide
def e565241246522 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e565241246522 : Closed e565241246522 ∧ code e565241246522 = 2764264502074 := by decide
theorem cert_e565241246522 : check e565241246522 [[],[.under]] .three = true := by decide
def e565241246618 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e565241246618 : Closed e565241246618 ∧ code e565241246618 = 2764264502170 := by decide
theorem cert_e565241246618 : check e565241246618 [[],[.under]] .three = true := by decide
def e565241383790 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e565241383790 : Closed e565241383790 ∧ code e565241383790 = 2764264639342 := by decide
theorem cert_e565241383790 : check e565241383790 [[],[.under]] .chain = true := by decide
def e565241383798 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e565241383798 : Closed e565241383798 ∧ code e565241383798 = 2764264639350 := by decide
theorem cert_e565241383798 : check e565241383798 [[],[.under]] .chain = true := by decide
def e565241383854 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e565241383854 : Closed e565241383854 ∧ code e565241383854 = 2764264639406 := by decide
theorem cert_e565241383854 : check e565241383854 [[],[.under]] .chain = true := by decide
def e565241383866 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e565241383866 : Closed e565241383866 ∧ code e565241383866 = 2764264639418 := by decide
theorem cert_e565241383866 : check e565241383866 [[],[.under]] .chain = true := by decide
def e565241383894 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e565241383894 : Closed e565241383894 ∧ code e565241383894 = 2764264639446 := by decide
theorem cert_e565241383894 : check e565241383894 [[],[.under]] .chain = true := by decide
def e565241383898 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e565241383898 : Closed e565241383898 ∧ code e565241383898 = 2764264639450 := by decide
theorem cert_e565241383898 : check e565241383898 [[],[.under]] .chain = true := by decide
def e565241384174 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e565241384174 : Closed e565241384174 ∧ code e565241384174 = 2764264639726 := by decide
theorem cert_e565241384174 : check e565241384174 [[],[.under]] .chain = true := by decide
def e565241384182 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e565241384182 : Closed e565241384182 ∧ code e565241384182 = 2764264639734 := by decide
theorem cert_e565241384182 : check e565241384182 [[],[.under]] .chain = true := by decide
def e565241384558 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e565241384558 : Closed e565241384558 ∧ code e565241384558 = 2764264640110 := by decide
theorem cert_e565241384558 : check e565241384558 [[],[.under]] .chain = true := by decide
def e565241384570 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e565241384570 : Closed e565241384570 ∧ code e565241384570 = 2764264640122 := by decide
theorem cert_e565241384570 : check e565241384570 [[],[.under]] .chain = true := by decide
def e565241384758 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e565241384758 : Closed e565241384758 ∧ code e565241384758 = 2764264640310 := by decide
theorem cert_e565241384758 : check e565241384758 [[],[.under]] .chain = true := by decide
def e565241384762 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e565241384762 : Closed e565241384762 ∧ code e565241384762 = 2764264640314 := by decide
theorem cert_e565241384762 : check e565241384762 [[],[.under]] .chain = true := by decide
def e565241973614 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e565241973614 : Closed e565241973614 ∧ code e565241973614 = 2764265229166 := by decide
theorem cert_e565241973614 : check e565241973614 [[],[.under]] .sourceHead = true := by decide
def e565241973622 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e565241973622 : Closed e565241973622 ∧ code e565241973622 = 2764265229174 := by decide
theorem cert_e565241973622 : check e565241973622 [[],[.under]] .sourceHead = true := by decide
def e565241973678 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e565241973678 : Closed e565241973678 ∧ code e565241973678 = 2764265229230 := by decide
theorem cert_e565241973678 : check e565241973678 [[],[.under]] .sourceHead = true := by decide
def e565241973690 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e565241973690 : Closed e565241973690 ∧ code e565241973690 = 2764265229242 := by decide
theorem cert_e565241973690 : check e565241973690 [[],[.under]] .sourceHead = true := by decide
def e565241973718 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e565241973718 : Closed e565241973718 ∧ code e565241973718 = 2764265229270 := by decide
theorem cert_e565241973718 : check e565241973718 [[],[.under]] .sourceHead = true := by decide
def e565241973722 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e565241973722 : Closed e565241973722 ∧ code e565241973722 = 2764265229274 := by decide
theorem cert_e565241973722 : check e565241973722 [[],[.under]] .sourceHead = true := by decide
def e565241973998 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e565241973998 : Closed e565241973998 ∧ code e565241973998 = 2764265229550 := by decide
theorem cert_e565241973998 : check e565241973998 [[],[.under]] .sourceHead = true := by decide
def e565241974006 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e565241974006 : Closed e565241974006 ∧ code e565241974006 = 2764265229558 := by decide
theorem cert_e565241974006 : check e565241974006 [[],[.under]] .sourceHead = true := by decide
def e565241974382 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e565241974382 : Closed e565241974382 ∧ code e565241974382 = 2764265229934 := by decide
theorem cert_e565241974382 : check e565241974382 [[],[.under]] .sourceHead = true := by decide
def e565241974394 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e565241974394 : Closed e565241974394 ∧ code e565241974394 = 2764265229946 := by decide
theorem cert_e565241974394 : check e565241974394 [[],[.under]] .sourceHead = true := by decide
def e565241974582 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e565241974582 : Closed e565241974582 ∧ code e565241974582 = 2764265230134 := by decide
theorem cert_e565241974582 : check e565241974582 [[],[.under]] .sourceHead = true := by decide
def e565241974586 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e565241974586 : Closed e565241974586 ∧ code e565241974586 = 2764265230138 := by decide
theorem cert_e565241974586 : check e565241974586 [[],[.under]] .sourceHead = true := by decide
def e565260957722 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e565260957722 : Closed e565260957722 ∧ code e565260957722 = 2764284213274 := by decide
theorem cert_e565260957722 : check e565260957722 [[]] .width = true := by decide
def e565260965914 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e565260965914 : Closed e565260965914 ∧ code e565260965914 = 2764284221466 := by decide
theorem cert_e565260965914 : check e565260965914 [[]] .width = true := by decide
def e565261023258 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e565261023258 : Closed e565261023258 ∧ code e565261023258 = 2764284278810 := by decide
theorem cert_e565261023258 : check e565261023258 [[]] .width = true := by decide
def e565261035546 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e565261035546 : Closed e565261035546 ∧ code e565261035546 = 2764284291098 := by decide
theorem cert_e565261035546 : check e565261035546 [[]] .width = true := by decide
def e565261064218 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e565261064218 : Closed e565261064218 ∧ code e565261064218 = 2764284319770 := by decide
theorem cert_e565261064218 : check e565261064218 [[]] .width = true := by decide
def e565261068314 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e565261068314 : Closed e565261068314 ∧ code e565261068314 = 2764284323866 := by decide
theorem cert_e565261068314 : check e565261068314 [[]] .width = true := by decide
def e565261350938 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e565261350938 : Closed e565261350938 ∧ code e565261350938 = 2764284606490 := by decide
theorem cert_e565261350938 : check e565261350938 [[]] .width = true := by decide
def e565261359130 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e565261359130 : Closed e565261359130 ∧ code e565261359130 = 2764284614682 := by decide
theorem cert_e565261359130 : check e565261359130 [[]] .width = true := by decide
def e565261744154 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e565261744154 : Closed e565261744154 ∧ code e565261744154 = 2764284999706 := by decide
theorem cert_e565261744154 : check e565261744154 [[]] .width = true := by decide
def e565261756442 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e565261756442 : Closed e565261756442 ∧ code e565261756442 = 2764285011994 := by decide
theorem cert_e565261756442 : check e565261756442 [[]] .width = true := by decide
def e565261948954 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e565261948954 : Closed e565261948954 ∧ code e565261948954 = 2764285204506 := by decide
theorem cert_e565261948954 : check e565261948954 [[]] .width = true := by decide
def e565261953050 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e565261953050 : Closed e565261953050 ∧ code e565261953050 = 2764285208602 := by decide
theorem cert_e565261953050 : check e565261953050 [[]] .width = true := by decide
def e565274783086 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e565274783086 : Closed e565274783086 ∧ code e565274783086 = 2764298038638 := by decide
theorem cert_e565274783086 : check e565274783086 [[],[.under]] .three = true := by decide
def e565274783094 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e565274783094 : Closed e565274783094 ∧ code e565274783094 = 2764298038646 := by decide
theorem cert_e565274783094 : check e565274783094 [[],[.under]] .three = true := by decide
def e565274783150 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e565274783150 : Closed e565274783150 ∧ code e565274783150 = 2764298038702 := by decide
theorem cert_e565274783150 : check e565274783150 [[],[.under]] .three = true := by decide
def e565274783162 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e565274783162 : Closed e565274783162 ∧ code e565274783162 = 2764298038714 := by decide
theorem cert_e565274783162 : check e565274783162 [[],[.under]] .three = true := by decide
def e565274783190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e565274783190 : Closed e565274783190 ∧ code e565274783190 = 2764298038742 := by decide
theorem cert_e565274783190 : check e565274783190 [[],[.under]] .three = true := by decide
def e565274783194 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e565274783194 : Closed e565274783194 ∧ code e565274783194 = 2764298038746 := by decide
theorem cert_e565274783194 : check e565274783194 [[],[.under]] .three = true := by decide
end Blc.Floor41
