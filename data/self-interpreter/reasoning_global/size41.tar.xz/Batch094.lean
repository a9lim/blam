import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605601609558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e605601609558 : Closed e605601609558 ∧ code e605601609558 = 2804624865110 := by decide
theorem cert_e605601609558 : check e605601609558 [[],[]] .chain = true := by decide
def e605601609562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e605601609562 : Closed e605601609562 ∧ code e605601609562 = 2804624865114 := by decide
theorem cert_e605601609562 : check e605601609562 [[],[]] .chain = true := by decide
def e605601609578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e605601609578 : Closed e605601609578 ∧ code e605601609578 = 2804624865130 := by decide
theorem cert_e605601609578 : check e605601609578 [[],[]] .chain = true := by decide
def e605601610414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e605601610414 : Closed e605601610414 ∧ code e605601610414 = 2804624865966 := by decide
theorem cert_e605601610414 : check e605601610414 [[],[]] .chain = true := by decide
def e605601610426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e605601610426 : Closed e605601610426 ∧ code e605601610426 = 2804624865978 := by decide
theorem cert_e605601610426 : check e605601610426 [[],[]] .chain = true := by decide
def e605601610474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e605601610474 : Closed e605601610474 ∧ code e605601610474 = 2804624866026 := by decide
theorem cert_e605601610474 : check e605601610474 [[],[]] .chain = true := by decide
def e605601610666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e605601610666 : Closed e605601610666 ∧ code e605601610666 = 2804624866218 := by decide
theorem cert_e605601610666 : check e605601610666 [[],[]] .chain = true := by decide
def e605601611094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e605601611094 : Closed e605601611094 ∧ code e605601611094 = 2804624866646 := by decide
theorem cert_e605601611094 : check e605601611094 [[],[]] .chain = true := by decide
def e605601611098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e605601611098 : Closed e605601611098 ∧ code e605601611098 = 2804624866650 := by decide
theorem cert_e605601611098 : check e605601611098 [[],[]] .chain = true := by decide
def e605601611114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e605601611114 : Closed e605601611114 ∧ code e605601611114 = 2804624866666 := by decide
theorem cert_e605601611114 : check e605601611114 [[],[]] .chain = true := by decide
def e605601611178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e605601611178 : Closed e605601611178 ∧ code e605601611178 = 2804624866730 := by decide
theorem cert_e605601611178 : check e605601611178 [[],[]] .chain = true := by decide
def e605601612142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e605601612142 : Closed e605601612142 ∧ code e605601612142 = 2804624867694 := by decide
theorem cert_e605601612142 : check e605601612142 [[],[]] .chain = true := by decide
def e605601612150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e605601612150 : Closed e605601612150 ∧ code e605601612150 = 2804624867702 := by decide
theorem cert_e605601612150 : check e605601612150 [[],[]] .chain = true := by decide
def e605601613678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e605601613678 : Closed e605601613678 ∧ code e605601613678 = 2804624869230 := by decide
theorem cert_e605601613678 : check e605601613678 [[],[]] .chain = true := by decide
def e605601613686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e605601613686 : Closed e605601613686 ∧ code e605601613686 = 2804624869238 := by decide
theorem cert_e605601613686 : check e605601613686 [[],[]] .chain = true := by decide
def e605601613750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e605601613750 : Closed e605601613750 ∧ code e605601613750 = 2804624869302 := by decide
theorem cert_e605601613750 : check e605601613750 [[],[]] .chain = true := by decide
def e605601615214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e605601615214 : Closed e605601615214 ∧ code e605601615214 = 2804624870766 := by decide
theorem cert_e605601615214 : check e605601615214 [[],[]] .chain = true := by decide
def e605601615222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e605601615222 : Closed e605601615222 ∧ code e605601615222 = 2804624870774 := by decide
theorem cert_e605601615222 : check e605601615222 [[],[]] .chain = true := by decide
def e605601615278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e605601615278 : Closed e605601615278 ∧ code e605601615278 = 2804624870830 := by decide
theorem cert_e605601615278 : check e605601615278 [[],[]] .chain = true := by decide
def e605601615290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e605601615290 : Closed e605601615290 ∧ code e605601615290 = 2804624870842 := by decide
theorem cert_e605601615290 : check e605601615290 [[],[]] .chain = true := by decide
def e605601615318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e605601615318 : Closed e605601615318 ∧ code e605601615318 = 2804624870870 := by decide
theorem cert_e605601615318 : check e605601615318 [[],[]] .chain = true := by decide
def e605601615322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e605601615322 : Closed e605601615322 ∧ code e605601615322 = 2804624870874 := by decide
theorem cert_e605601615322 : check e605601615322 [[],[]] .chain = true := by decide
def e605601615534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e605601615534 : Closed e605601615534 ∧ code e605601615534 = 2804624871086 := by decide
theorem cert_e605601615534 : check e605601615534 [[],[]] .chain = true := by decide
def e605601615546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e605601615546 : Closed e605601615546 ∧ code e605601615546 = 2804624871098 := by decide
theorem cert_e605601615546 : check e605601615546 [[],[]] .chain = true := by decide
def e605601615594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e605601615594 : Closed e605601615594 ∧ code e605601615594 = 2804624871146 := by decide
theorem cert_e605601615594 : check e605601615594 [[],[]] .chain = true := by decide
def e605601615702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e605601615702 : Closed e605601615702 ∧ code e605601615702 = 2804624871254 := by decide
theorem cert_e605601615702 : check e605601615702 [[],[]] .chain = true := by decide
def e605601615706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e605601615706 : Closed e605601615706 ∧ code e605601615706 = 2804624871258 := by decide
theorem cert_e605601615706 : check e605601615706 [[],[]] .chain = true := by decide
def e605601615722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e605601615722 : Closed e605601615722 ∧ code e605601615722 = 2804624871274 := by decide
theorem cert_e605601615722 : check e605601615722 [[],[]] .chain = true := by decide
def e605601616750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e605601616750 : Closed e605601616750 ∧ code e605601616750 = 2804624872302 := by decide
theorem cert_e605601616750 : check e605601616750 [[],[]] .chain = true := by decide
def e605601616758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e605601616758 : Closed e605601616758 ∧ code e605601616758 = 2804624872310 := by decide
theorem cert_e605601616758 : check e605601616758 [[],[]] .chain = true := by decide
def e605601616814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e605601616814 : Closed e605601616814 ∧ code e605601616814 = 2804624872366 := by decide
theorem cert_e605601616814 : check e605601616814 [[],[]] .chain = true := by decide
def e605601616826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e605601616826 : Closed e605601616826 ∧ code e605601616826 = 2804624872378 := by decide
theorem cert_e605601616826 : check e605601616826 [[],[]] .chain = true := by decide
def e605601616854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e605601616854 : Closed e605601616854 ∧ code e605601616854 = 2804624872406 := by decide
theorem cert_e605601616854 : check e605601616854 [[],[]] .chain = true := by decide
def e605601616858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e605601616858 : Closed e605601616858 ∧ code e605601616858 = 2804624872410 := by decide
theorem cert_e605601616858 : check e605601616858 [[],[]] .chain = true := by decide
def e605601617134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e605601617134 : Closed e605601617134 ∧ code e605601617134 = 2804624872686 := by decide
theorem cert_e605601617134 : check e605601617134 [[],[]] .chain = true := by decide
def e605601617142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e605601617142 : Closed e605601617142 ∧ code e605601617142 = 2804624872694 := by decide
theorem cert_e605601617142 : check e605601617142 [[],[]] .chain = true := by decide
def e605601617518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601617518 : Closed e605601617518 ∧ code e605601617518 = 2804624873070 := by decide
theorem cert_e605601617518 : check e605601617518 [[],[]] .chain = true := by decide
def e605601617530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601617530 : Closed e605601617530 ∧ code e605601617530 = 2804624873082 := by decide
theorem cert_e605601617530 : check e605601617530 [[],[]] .chain = true := by decide
def e605601617718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601617718 : Closed e605601617718 ∧ code e605601617718 = 2804624873270 := by decide
theorem cert_e605601617718 : check e605601617718 [[],[]] .chain = true := by decide
def e605601617722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601617722 : Closed e605601617722 ∧ code e605601617722 = 2804624873274 := by decide
theorem cert_e605601617722 : check e605601617722 [[],[]] .chain = true := by decide
def e605601617966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e605601617966 : Closed e605601617966 ∧ code e605601617966 = 2804624873518 := by decide
theorem cert_e605601617966 : check e605601617966 [[],[]] .chain = true := by decide
def e605601618158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e605601618158 : Closed e605601618158 ∧ code e605601618158 = 2804624873710 := by decide
theorem cert_e605601618158 : check e605601618158 [[],[]] .chain = true := by decide
def e605601618166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e605601618166 : Closed e605601618166 ∧ code e605601618166 = 2804624873718 := by decide
theorem cert_e605601618166 : check e605601618166 [[],[]] .chain = true := by decide
def e605601618350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e605601618350 : Closed e605601618350 ∧ code e605601618350 = 2804624873902 := by decide
theorem cert_e605601618350 : check e605601618350 [[],[]] .chain = true := by decide
def e605601618362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e605601618362 : Closed e605601618362 ∧ code e605601618362 = 2804624873914 := by decide
theorem cert_e605601618362 : check e605601618362 [[],[]] .chain = true := by decide
def e605601618410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e605601618410 : Closed e605601618410 ∧ code e605601618410 = 2804624873962 := by decide
theorem cert_e605601618410 : check e605601618410 [[],[]] .chain = true := by decide
def e605601618542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601618542 : Closed e605601618542 ∧ code e605601618542 = 2804624874094 := by decide
theorem cert_e605601618542 : check e605601618542 [[],[]] .chain = true := by decide
def e605601618554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601618554 : Closed e605601618554 ∧ code e605601618554 = 2804624874106 := by decide
theorem cert_e605601618554 : check e605601618554 [[],[]] .chain = true := by decide
def e605601618718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e605601618718 : Closed e605601618718 ∧ code e605601618718 = 2804624874270 := by decide
theorem cert_e605601618718 : check e605601618718 [[],[]] .chain = true := by decide
def e605601618818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e605601618818 : Closed e605601618818 ∧ code e605601618818 = 2804624874370 := by decide
theorem cert_e605601618818 : check e605601618818 [[],[]] .chain = true := by decide
def e605601618830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e605601618830 : Closed e605601618830 ∧ code e605601618830 = 2804624874382 := by decide
theorem cert_e605601618830 : check e605601618830 [[],[]] .chain = true := by decide
def e605601618842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601618842 : Closed e605601618842 ∧ code e605601618842 = 2804624874394 := by decide
theorem cert_e605601618842 : check e605601618842 [[],[]] .chain = true := by decide
def e605601618966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e605601618966 : Closed e605601618966 ∧ code e605601618966 = 2804624874518 := by decide
theorem cert_e605601618966 : check e605601618966 [[],[]] .chain = true := by decide
def e605601619062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e605601619062 : Closed e605601619062 ∧ code e605601619062 = 2804624874614 := by decide
theorem cert_e605601619062 : check e605601619062 [[],[]] .chain = true := by decide
def e605601619158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e605601619158 : Closed e605601619158 ∧ code e605601619158 = 2804624874710 := by decide
theorem cert_e605601619158 : check e605601619158 [[],[]] .chain = true := by decide
def e605601619162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e605601619162 : Closed e605601619162 ∧ code e605601619162 = 2804624874714 := by decide
theorem cert_e605601619162 : check e605601619162 [[],[]] .chain = true := by decide
def e605601619178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e605601619178 : Closed e605601619178 ∧ code e605601619178 = 2804624874730 := by decide
theorem cert_e605601619178 : check e605601619178 [[],[]] .chain = true := by decide
def e605601619254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601619254 : Closed e605601619254 ∧ code e605601619254 = 2804624874806 := by decide
theorem cert_e605601619254 : check e605601619254 [[],[]] .chain = true := by decide
def e605601619258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601619258 : Closed e605601619258 ∧ code e605601619258 = 2804624874810 := by decide
theorem cert_e605601619258 : check e605601619258 [[],[]] .chain = true := by decide
def e605601619330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e605601619330 : Closed e605601619330 ∧ code e605601619330 = 2804624874882 := by decide
theorem cert_e605601619330 : check e605601619330 [[],[]] .chain = true := by decide
def e605601619342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e605601619342 : Closed e605601619342 ∧ code e605601619342 = 2804624874894 := by decide
theorem cert_e605601619342 : check e605601619342 [[],[]] .chain = true := by decide
def e605601619354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601619354 : Closed e605601619354 ∧ code e605601619354 = 2804624874906 := by decide
theorem cert_e605601619354 : check e605601619354 [[],[]] .chain = true := by decide
def e605601620142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e605601620142 : Closed e605601620142 ∧ code e605601620142 = 2804624875694 := by decide
theorem cert_e605601620142 : check e605601620142 [[],[]] .chain = true := by decide
def e605601620154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e605601620154 : Closed e605601620154 ∧ code e605601620154 = 2804624875706 := by decide
theorem cert_e605601620154 : check e605601620154 [[],[]] .chain = true := by decide
def e605601620718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e605601620718 : Closed e605601620718 ∧ code e605601620718 = 2804624876270 := by decide
theorem cert_e605601620718 : check e605601620718 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e605601620846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e605601620846 : Closed e605601620846 ∧ code e605601620846 = 2804624876398 := by decide
theorem cert_e605601620846 : check e605601620846 [[],[]] .chain = true := by decide
def e605601620854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e605601620854 : Closed e605601620854 ∧ code e605601620854 = 2804624876406 := by decide
theorem cert_e605601620854 : check e605601620854 [[],[]] .chain = true := by decide
def e605601620910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e605601620910 : Closed e605601620910 ∧ code e605601620910 = 2804624876462 := by decide
theorem cert_e605601620910 : check e605601620910 [[],[]] .chain = true := by decide
def e605601620922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e605601620922 : Closed e605601620922 ∧ code e605601620922 = 2804624876474 := by decide
theorem cert_e605601620922 : check e605601620922 [[],[]] .chain = true := by decide
def e605601620950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e605601620950 : Closed e605601620950 ∧ code e605601620950 = 2804624876502 := by decide
theorem cert_e605601620950 : check e605601620950 [[],[]] .chain = true := by decide
def e605601620954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e605601620954 : Closed e605601620954 ∧ code e605601620954 = 2804624876506 := by decide
theorem cert_e605601620954 : check e605601620954 [[],[]] .chain = true := by decide
def e605601621678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e605601621678 : Closed e605601621678 ∧ code e605601621678 = 2804624877230 := by decide
theorem cert_e605601621678 : check e605601621678 [[],[]] .chain = true := by decide
def e605601621690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e605601621690 : Closed e605601621690 ∧ code e605601621690 = 2804624877242 := by decide
theorem cert_e605601621690 : check e605601621690 [[],[]] .chain = true := by decide
def e605601621738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e605601621738 : Closed e605601621738 ∧ code e605601621738 = 2804624877290 := by decide
theorem cert_e605601621738 : check e605601621738 [[],[]] .chain = true := by decide
def e605601621930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e605601621930 : Closed e605601621930 ∧ code e605601621930 = 2804624877482 := by decide
theorem cert_e605601621930 : check e605601621930 [[],[]] .chain = true := by decide
def e605601622062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e605601622062 : Closed e605601622062 ∧ code e605601622062 = 2804624877614 := by decide
theorem cert_e605601622062 : check e605601622062 [[],[]] .chain = true := by decide
def e605601622254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e605601622254 : Closed e605601622254 ∧ code e605601622254 = 2804624877806 := by decide
theorem cert_e605601622254 : check e605601622254 [[],[]] .chain = true := by decide
def e605601622262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e605601622262 : Closed e605601622262 ∧ code e605601622262 = 2804624877814 := by decide
theorem cert_e605601622262 : check e605601622262 [[],[]] .chain = true := by decide
def e605601622446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e605601622446 : Closed e605601622446 ∧ code e605601622446 = 2804624877998 := by decide
theorem cert_e605601622446 : check e605601622446 [[],[]] .chain = true := by decide
def e605601622458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e605601622458 : Closed e605601622458 ∧ code e605601622458 = 2804624878010 := by decide
theorem cert_e605601622458 : check e605601622458 [[],[]] .chain = true := by decide
def e605601622506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e605601622506 : Closed e605601622506 ∧ code e605601622506 = 2804624878058 := by decide
theorem cert_e605601622506 : check e605601622506 [[],[]] .chain = true := by decide
def e605601622638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601622638 : Closed e605601622638 ∧ code e605601622638 = 2804624878190 := by decide
theorem cert_e605601622638 : check e605601622638 [[],[]] .chain = true := by decide
def e605601622650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601622650 : Closed e605601622650 ∧ code e605601622650 = 2804624878202 := by decide
theorem cert_e605601622650 : check e605601622650 [[],[]] .chain = true := by decide
def e605601622814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e605601622814 : Closed e605601622814 ∧ code e605601622814 = 2804624878366 := by decide
theorem cert_e605601622814 : check e605601622814 [[],[]] .chain = true := by decide
def e605601622914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e605601622914 : Closed e605601622914 ∧ code e605601622914 = 2804624878466 := by decide
theorem cert_e605601622914 : check e605601622914 [[],[]] .chain = true := by decide
def e605601622926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e605601622926 : Closed e605601622926 ∧ code e605601622926 = 2804624878478 := by decide
theorem cert_e605601622926 : check e605601622926 [[],[]] .chain = true := by decide
def e605601622938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601622938 : Closed e605601622938 ∧ code e605601622938 = 2804624878490 := by decide
theorem cert_e605601622938 : check e605601622938 [[],[]] .chain = true := by decide
def e605601623150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e605601623150 : Closed e605601623150 ∧ code e605601623150 = 2804624878702 := by decide
theorem cert_e605601623150 : check e605601623150 [[],[]] .chain = true := by decide
def e605601623162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e605601623162 : Closed e605601623162 ∧ code e605601623162 = 2804624878714 := by decide
theorem cert_e605601623162 : check e605601623162 [[],[]] .chain = true := by decide
def e605601623326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e605601623326 : Closed e605601623326 ∧ code e605601623326 = 2804624878878 := by decide
theorem cert_e605601623326 : check e605601623326 [[],[]] .chain = true := by decide
def e605601623494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e605601623494 : Closed e605601623494 ∧ code e605601623494 = 2804624879046 := by decide
theorem cert_e605601623494 : check e605601623494 [[],[]] .chain = true := by decide
def e605601623562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601623562 : Closed e605601623562 ∧ code e605601623562 = 2804624879114 := by decide
theorem cert_e605601623562 : check e605601623562 [[],[]] .chain = true := by decide
def e605601623598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 2))))))
theorem wire_e605601623598 : Closed e605601623598 ∧ code e605601623598 = 2804624879150 := by decide
theorem cert_e605601623598 : check e605601623598 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e605601623606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e605601623606 : Closed e605601623606 ∧ code e605601623606 = 2804624879158 := by decide
theorem cert_e605601623606 : check e605601623606 [[],[]] .chain = true := by decide
def e605601623610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e605601623610 : Closed e605601623610 ∧ code e605601623610 = 2804624879162 := by decide
theorem cert_e605601623610 : check e605601623610 [[],[]] .chain = true := by decide
def e605601623658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e605601623658 : Closed e605601623658 ∧ code e605601623658 = 2804624879210 := by decide
theorem cert_e605601623658 : check e605601623658 [[],[]] .chain = true := by decide
def e605601623682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e605601623682 : Closed e605601623682 ∧ code e605601623682 = 2804624879234 := by decide
theorem cert_e605601623682 : check e605601623682 [[],[]] .chain = true := by decide
def e605601623694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e605601623694 : Closed e605601623694 ∧ code e605601623694 = 2804624879246 := by decide
theorem cert_e605601623694 : check e605601623694 [[],[]] .chain = true := by decide
def e605601623706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601623706 : Closed e605601623706 ∧ code e605601623706 = 2804624879258 := by decide
theorem cert_e605601623706 : check e605601623706 [[],[]] .chain = true := by decide
def e605601623750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e605601623750 : Closed e605601623750 ∧ code e605601623750 = 2804624879302 := by decide
theorem cert_e605601623750 : check e605601623750 [[],[]] .chain = true := by decide
def e605601623778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e605601623778 : Closed e605601623778 ∧ code e605601623778 = 2804624879330 := by decide
theorem cert_e605601623778 : check e605601623778 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e605601623790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 2))))))
theorem wire_e605601623790 : Closed e605601623790 ∧ code e605601623790 = 2804624879342 := by decide
theorem cert_e605601623790 : check e605601623790 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e605601624150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e605601624150 : Closed e605601624150 ∧ code e605601624150 = 2804624879702 := by decide
theorem cert_e605601624150 : check e605601624150 [[],[]] .chain = true := by decide
def e605601624154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e605601624154 : Closed e605601624154 ∧ code e605601624154 = 2804624879706 := by decide
theorem cert_e605601624154 : check e605601624154 [[],[]] .chain = true := by decide
def e605601624430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e605601624430 : Closed e605601624430 ∧ code e605601624430 = 2804624879982 := by decide
theorem cert_e605601624430 : check e605601624430 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601624438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e605601624438 : Closed e605601624438 ∧ code e605601624438 = 2804624879990 := by decide
theorem cert_e605601624438 : check e605601624438 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601624502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e605601624502 : Closed e605601624502 ∧ code e605601624502 = 2804624880054 := by decide
theorem cert_e605601624502 : check e605601624502 [[],[]] .chain = true := by decide
def e605601624534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e605601624534 : Closed e605601624534 ∧ code e605601624534 = 2804624880086 := by decide
theorem cert_e605601624534 : check e605601624534 [[],[]] .chain = true := by decide
def e605601624538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e605601624538 : Closed e605601624538 ∧ code e605601624538 = 2804624880090 := by decide
theorem cert_e605601624538 : check e605601624538 [[],[]] .chain = true := by decide
def e605601624918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e605601624918 : Closed e605601624918 ∧ code e605601624918 = 2804624880470 := by decide
theorem cert_e605601624918 : check e605601624918 [[],[]] .chain = true := by decide
def e605601624922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e605601624922 : Closed e605601624922 ∧ code e605601624922 = 2804624880474 := by decide
theorem cert_e605601624922 : check e605601624922 [[],[]] .chain = true := by decide
def e605601624938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e605601624938 : Closed e605601624938 ∧ code e605601624938 = 2804624880490 := by decide
theorem cert_e605601624938 : check e605601624938 [[],[]] .chain = true := by decide
def e605601625002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e605601625002 : Closed e605601625002 ∧ code e605601625002 = 2804624880554 := by decide
theorem cert_e605601625002 : check e605601625002 [[],[]] .chain = true := by decide
def e605601625110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e605601625110 : Closed e605601625110 ∧ code e605601625110 = 2804624880662 := by decide
theorem cert_e605601625110 : check e605601625110 [[],[]] .chain = true := by decide
def e605601625206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e605601625206 : Closed e605601625206 ∧ code e605601625206 = 2804624880758 := by decide
theorem cert_e605601625206 : check e605601625206 [[],[]] .chain = true := by decide
def e605601625302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e605601625302 : Closed e605601625302 ∧ code e605601625302 = 2804624880854 := by decide
theorem cert_e605601625302 : check e605601625302 [[],[]] .chain = true := by decide
def e605601625306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e605601625306 : Closed e605601625306 ∧ code e605601625306 = 2804624880858 := by decide
theorem cert_e605601625306 : check e605601625306 [[],[]] .chain = true := by decide
def e605601625322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e605601625322 : Closed e605601625322 ∧ code e605601625322 = 2804624880874 := by decide
theorem cert_e605601625322 : check e605601625322 [[],[]] .chain = true := by decide
def e605601625398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601625398 : Closed e605601625398 ∧ code e605601625398 = 2804624880950 := by decide
theorem cert_e605601625398 : check e605601625398 [[],[]] .chain = true := by decide
def e605601625402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601625402 : Closed e605601625402 ∧ code e605601625402 = 2804624880954 := by decide
theorem cert_e605601625402 : check e605601625402 [[],[]] .chain = true := by decide
def e605601625474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e605601625474 : Closed e605601625474 ∧ code e605601625474 = 2804624881026 := by decide
theorem cert_e605601625474 : check e605601625474 [[],[]] .chain = true := by decide
def e605601625486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e605601625486 : Closed e605601625486 ∧ code e605601625486 = 2804624881038 := by decide
theorem cert_e605601625486 : check e605601625486 [[],[]] .chain = true := by decide
def e605601625498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601625498 : Closed e605601625498 ∧ code e605601625498 = 2804624881050 := by decide
theorem cert_e605601625498 : check e605601625498 [[],[]] .chain = true := by decide
def e605601625610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601625610 : Closed e605601625610 ∧ code e605601625610 = 2804624881162 := by decide
theorem cert_e605601625610 : check e605601625610 [[],[]] .chain = true := by decide
def e605601625646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e605601625646 : Closed e605601625646 ∧ code e605601625646 = 2804624881198 := by decide
theorem cert_e605601625646 : check e605601625646 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e605601625654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e605601625654 : Closed e605601625654 ∧ code e605601625654 = 2804624881206 := by decide
theorem cert_e605601625654 : check e605601625654 [[],[]] .chain = true := by decide
def e605601625658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e605601625658 : Closed e605601625658 ∧ code e605601625658 = 2804624881210 := by decide
theorem cert_e605601625658 : check e605601625658 [[],[]] .chain = true := by decide
def e605601625706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e605601625706 : Closed e605601625706 ∧ code e605601625706 = 2804624881258 := by decide
theorem cert_e605601625706 : check e605601625706 [[],[]] .chain = true := by decide
def e605601625730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e605601625730 : Closed e605601625730 ∧ code e605601625730 = 2804624881282 := by decide
theorem cert_e605601625730 : check e605601625730 [[],[]] .chain = true := by decide
def e605601625742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e605601625742 : Closed e605601625742 ∧ code e605601625742 = 2804624881294 := by decide
theorem cert_e605601625742 : check e605601625742 [[],[]] .chain = true := by decide
def e605601625754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601625754 : Closed e605601625754 ∧ code e605601625754 = 2804624881306 := by decide
theorem cert_e605601625754 : check e605601625754 [[],[]] .chain = true := by decide
def e605601625798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e605601625798 : Closed e605601625798 ∧ code e605601625798 = 2804624881350 := by decide
theorem cert_e605601625798 : check e605601625798 [[],[]] .chain = true := by decide
def e605601625826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e605601625826 : Closed e605601625826 ∧ code e605601625826 = 2804624881378 := by decide
theorem cert_e605601625826 : check e605601625826 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e605601625838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e605601625838 : Closed e605601625838 ∧ code e605601625838 = 2804624881390 := by decide
theorem cert_e605601625838 : check e605601625838 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e605601625878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e605601625878 : Closed e605601625878 ∧ code e605601625878 = 2804624881430 := by decide
theorem cert_e605601625878 : check e605601625878 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601625954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e605601625954 : Closed e605601625954 ∧ code e605601625954 = 2804624881506 := by decide
theorem cert_e605601625954 : check e605601625954 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605601625966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e605601625966 : Closed e605601625966 ∧ code e605601625966 = 2804624881518 := by decide
theorem cert_e605601625966 : check e605601625966 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601625974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e605601625974 : Closed e605601625974 ∧ code e605601625974 = 2804624881526 := by decide
theorem cert_e605601625974 : checkPay e605601625974 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605601628846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e605601628846 : Closed e605601628846 ∧ code e605601628846 = 2804624884398 := by decide
theorem cert_e605601628846 : check e605601628846 [[],[]] .chain = true := by decide
def e605601628858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e605601628858 : Closed e605601628858 ∧ code e605601628858 = 2804624884410 := by decide
theorem cert_e605601628858 : check e605601628858 [[],[]] .chain = true := by decide
def e605601628906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e605601628906 : Closed e605601628906 ∧ code e605601628906 = 2804624884458 := by decide
theorem cert_e605601628906 : check e605601628906 [[],[]] .chain = true := by decide
def e605601630958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e605601630958 : Closed e605601630958 ∧ code e605601630958 = 2804624886510 := by decide
theorem cert_e605601630958 : check e605601630958 [[],[]] .sourceHead = true := by decide
def e605601631150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e605601631150 : Closed e605601631150 ∧ code e605601631150 = 2804624886702 := by decide
theorem cert_e605601631150 : check e605601631150 [[],[]] .sourceHead = true := by decide
def e605601631162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e605601631162 : Closed e605601631162 ∧ code e605601631162 = 2804624886714 := by decide
theorem cert_e605601631162 : check e605601631162 [[],[]] .sourceHead = true := by decide
def e605601631598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e605601631598 : Closed e605601631598 ∧ code e605601631598 = 2804624887150 := by decide
theorem cert_e605601631598 : check e605601631598 [[],[]] .chain = true := by decide
def e605601631606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e605601631606 : Closed e605601631606 ∧ code e605601631606 = 2804624887158 := by decide
theorem cert_e605601631606 : check e605601631606 [[],[]] .chain = true := by decide
def e605601631662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e605601631662 : Closed e605601631662 ∧ code e605601631662 = 2804624887214 := by decide
theorem cert_e605601631662 : check e605601631662 [[],[]] .chain = true := by decide
def e605601631674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e605601631674 : Closed e605601631674 ∧ code e605601631674 = 2804624887226 := by decide
theorem cert_e605601631674 : check e605601631674 [[],[]] .chain = true := by decide
def e605601631702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e605601631702 : Closed e605601631702 ∧ code e605601631702 = 2804624887254 := by decide
theorem cert_e605601631702 : check e605601631702 [[],[]] .chain = true := by decide
def e605601631706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e605601631706 : Closed e605601631706 ∧ code e605601631706 = 2804624887258 := by decide
theorem cert_e605601631706 : check e605601631706 [[],[]] .chain = true := by decide
def e605601631918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e605601631918 : Closed e605601631918 ∧ code e605601631918 = 2804624887470 := by decide
theorem cert_e605601631918 : check e605601631918 [[],[]] .chain = true := by decide
def e605601631930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e605601631930 : Closed e605601631930 ∧ code e605601631930 = 2804624887482 := by decide
theorem cert_e605601631930 : check e605601631930 [[],[]] .chain = true := by decide
def e605601631978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e605601631978 : Closed e605601631978 ∧ code e605601631978 = 2804624887530 := by decide
theorem cert_e605601631978 : check e605601631978 [[],[]] .chain = true := by decide
def e605601632086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e605601632086 : Closed e605601632086 ∧ code e605601632086 = 2804624887638 := by decide
theorem cert_e605601632086 : check e605601632086 [[],[]] .chain = true := by decide
def e605601632090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e605601632090 : Closed e605601632090 ∧ code e605601632090 = 2804624887642 := by decide
theorem cert_e605601632090 : check e605601632090 [[],[]] .chain = true := by decide
def e605601632106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e605601632106 : Closed e605601632106 ∧ code e605601632106 = 2804624887658 := by decide
theorem cert_e605601632106 : check e605601632106 [[],[]] .chain = true := by decide
def e605601634990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e605601634990 : Closed e605601634990 ∧ code e605601634990 = 2804624890542 := by decide
theorem cert_e605601634990 : check e605601634990 [[],[]] .chain = true := by decide
def e605601635002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e605601635002 : Closed e605601635002 ∧ code e605601635002 = 2804624890554 := by decide
theorem cert_e605601635002 : check e605601635002 [[],[]] .chain = true := by decide
def e605601635050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e605601635050 : Closed e605601635050 ∧ code e605601635050 = 2804624890602 := by decide
theorem cert_e605601635050 : check e605601635050 [[],[]] .chain = true := by decide
def e605601635242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e605601635242 : Closed e605601635242 ∧ code e605601635242 = 2804624890794 := by decide
theorem cert_e605601635242 : check e605601635242 [[],[]] .chain = true := by decide
end Blc.Floor41
