import R598354180538V0
import R598354180538K0
import R598354180538st0
import R598354180538hs0
import CodeBridge
import Batch043
namespace Certgen.R598354180538
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 7,.lam 2,.app 3 6,.app 4 5,.var 0,.var 0,.var 0,.lam 8,.app 9 18,.app 10 11,.var 0,.lam 12,.lam 13,.app 14 15,.var 1,.app 16 17,.var 0,.var 2,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (V0[i-0]?.getD [])
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD []))
def st (i : Nat) : AState := if i < 93 then (if i < 40 then (if i < 20 then (st0[i-0]?.getD entry) else (st20[i-20]?.getD entry)) else (if i < 60 then (st40[i-40]?.getD entry) else (if i < 80 then (st60[i-60]?.getD entry) else (st80[i-80]?.getD entry)))) else entry
def hs (i : Nat) : List Nat := (if i < 40 then (if i < 20 then (hs0[i-0]?.getD []) else (hs20[i-20]?.getD [])) else (if i < 60 then (hs40[i-40]?.getD []) else (if i < 80 then (hs60[i-60]?.getD []) else (hs80[i-80]?.getD []))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R598354180538
