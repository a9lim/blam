import Extra41
import Batch147
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness605804356086
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 3
private def u4 := Term.app u3 u0
private def u5 := Term.lam u4
private def u6 := Term.app u0 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.app u1 u9
private def u11 := Term.lam u10
private def u12 := Term.app u11 u0
private def u13 := Term.lam u12
private def u14 := Term.app u0 u13
private def u15 := Term.lam u14
private def u16 := Term.lam u15
private def u17 := Term.app u11 u16
private def u18 := Term.app u17 u0
private def u19 := Term.lam u18
private def u20 := Term.app u0 u19
private def u21 := Term.lam u20
private def u22 := Term.lam u21
private def u23 := Term.app u17 u22
private def u24 := Term.app u11 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.lam u0
private def u28 := Term.lam u27
private def u29 := Term.app u1 u28
private def u30 := Term.lam u2
private def u31 := Term.app u1 u30
private def u32 := Term.var 4
private def u33 := Term.app u29 u32
private def u34 := Term.lam u33
private def u35 := Term.app u31 u34
private def u36 := Term.lam u35
private def u37 := Term.app u29 u36
private def u38 := Term.lam u37
private def u39 := Term.app u29 u38
private def u40 := Term.lam u39
private def u41 := Term.app u26 u40
private def u42 := Term.app u0 u30
private def u43 := Term.app u42 u1
theorem nege605804356086 : ¬ IsSelfInterpreter e605804356086 := by
  intro he
  have hv : NFt u43 := by decide
  have reach : Betas (Floor40.call e605804356086 u0 u2 u1 []) u43 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left]] (Floor40.call e605804356086 u0 u2 u1 []) = some u41 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege605804356086
end Witness605804356086
namespace Witness605804359918
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u0 u3
private def u5 := Term.lam u4
private def u6 := Term.app u3 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.app u1 u9
private def u11 := Term.lam u10
private def u12 := Term.app u11 u5
private def u13 := Term.lam u12
private def u14 := Term.lam u13
private def u15 := Term.app u14 u5
private def u16 := Term.lam u15
private def u17 := Term.lam u16
private def u18 := Term.app u0 u17
private def u19 := Term.lam u0
private def u20 := Term.lam u19
private def u21 := Term.app u1 u20
private def u22 := Term.lam u2
private def u23 := Term.app u1 u22
private def u24 := Term.var 3
private def u25 := Term.app u21 u24
private def u26 := Term.lam u25
private def u27 := Term.app u23 u26
private def u28 := Term.lam u27
private def u29 := Term.app u21 u28
private def u30 := Term.lam u29
private def u31 := Term.app u18 u30
private def u32 := Term.app u0 u22
private def u33 := Term.app u32 u1
theorem nege605804359918 : ¬ IsSelfInterpreter e605804359918 := by
  intro he
  have hv : NFt u33 := by decide
  have reach : Betas (Floor40.call e605804359918 u0 u2 u1 []) u33 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[],[],[.left]] (Floor40.call e605804359918 u0 u2 u1 []) = some u31 := by decide
  exact mismatches hv reach hr 2 (by decide)
#print axioms nege605804359918
end Witness605804359918
namespace Witness605804359926
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u0
private def u5 := Term.lam u4
private def u6 := Term.app u3 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.app u1 u9
private def u11 := Term.lam u10
private def u12 := Term.app u11 u5
private def u13 := Term.lam u12
private def u14 := Term.lam u13
private def u15 := Term.app u11 u14
private def u16 := Term.app u15 u5
private def u17 := Term.lam u16
private def u18 := Term.lam u17
private def u19 := Term.var 4
private def u20 := Term.app u18 u19
private def u21 := Term.lam u20
private def u22 := Term.app u21 u0
private def u23 := Term.lam u22
private def u24 := Term.app u11 u23
private def u25 := Term.lam u24
private def u26 := Term.lam u2
private def u27 := Term.app u0 u26
private def u28 := Term.app u27 u1
theorem nege605804359926 : ¬ IsSelfInterpreter e605804359926 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e605804359926 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[],[],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left],[.left],[.left],[.left],[],[]] (Floor40.call e605804359926 u0 u2 u1 []) = some u25 := by decide
  exact mismatches hv reach hr 1 (by decide)
#print axioms nege605804359926
end Witness605804359926
end Blc.Floor41
