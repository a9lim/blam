import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605593495518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 3))))))))
theorem wire_e605593495518 : Closed e605593495518 ∧ code e605593495518 = 2804616751070 := by decide
theorem cert_e605593495518 : check e605593495518 [[],[]] .three = true := by decide
def e605593497838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605593497838 : Closed e605593497838 ∧ code e605593497838 = 2804616753390 := by decide
theorem cert_e605593497838 : check e605593497838 [[],[]] .smaller = true := by decide
def e605593497846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605593497846 : Closed e605593497846 ∧ code e605593497846 = 2804616753398 := by decide
theorem cert_e605593497846 : check e605593497846 [[],[]] .smaller = true := by decide
def e605593498326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605593498326 : Closed e605593498326 ∧ code e605593498326 = 2804616753878 := by decide
theorem cert_e605593498326 : check e605593498326 [[],[]] .smaller = true := by decide
def e605593498330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605593498330 : Closed e605593498330 ∧ code e605593498330 = 2804616753882 := by decide
theorem cert_e605593498330 : check e605593498330 [[],[]] .smaller = true := by decide
def e605593498346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605593498346 : Closed e605593498346 ∧ code e605593498346 = 2804616753898 := by decide
theorem cert_e605593498346 : check e605593498346 [[],[]] .smaller = true := by decide
def e605593498422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593498422 : Closed e605593498422 ∧ code e605593498422 = 2804616753974 := by decide
theorem cert_e605593498422 : check e605593498422 [[],[]] .smaller = true := by decide
def e605593498426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593498426 : Closed e605593498426 ∧ code e605593498426 = 2804616753978 := by decide
theorem cert_e605593498426 : check e605593498426 [[],[]] .smaller = true := by decide
def e605593498522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593498522 : Closed e605593498522 ∧ code e605593498522 = 2804616754074 := by decide
theorem cert_e605593498522 : check e605593498522 [[],[]] .smaller = true := by decide
def e605593499766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605593499766 : Closed e605593499766 ∧ code e605593499766 = 2804616755318 := by decide
theorem cert_e605593499766 : check e605593499766 [[],[]] .three = true := by decide
def e605593500010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605593500010 : Closed e605593500010 ∧ code e605593500010 = 2804616755562 := by decide
theorem cert_e605593500010 : check e605593500010 [[],[]] .three = true := by decide
def e605593500058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593500058 : Closed e605593500058 ∧ code e605593500058 = 2804616755610 := by decide
theorem cert_e605593500058 : check e605593500058 [[],[]] .three = true := by decide
def e605593500126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 3))))))))
theorem wire_e605593500126 : Closed e605593500126 ∧ code e605593500126 = 2804616755678 := by decide
theorem cert_e605593500126 : check e605593500126 [[],[]] .three = true := by decide
def e605593500150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 3) (.var 1))))))))
theorem wire_e605593500150 : Closed e605593500150 ∧ code e605593500150 = 2804616755702 := by decide
theorem cert_e605593500150 : check e605593500150 [[],[]] .three = true := by decide
def e605593503598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e605593503598 : Closed e605593503598 ∧ code e605593503598 = 2804616759150 := by decide
theorem cert_e605593503598 : check e605593503598 [[],[]] .three = true := by decide
def e605593503606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e605593503606 : Closed e605593503606 ∧ code e605593503606 = 2804616759158 := by decide
theorem cert_e605593503606 : check e605593503606 [[],[]] .three = true := by decide
def e605593503610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e605593503610 : Closed e605593503610 ∧ code e605593503610 = 2804616759162 := by decide
theorem cert_e605593503610 : check e605593503610 [[],[]] .three = true := by decide
def e605593503670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e605593503670 : Closed e605593503670 ∧ code e605593503670 = 2804616759222 := by decide
theorem cert_e605593503670 : check e605593503670 [[],[]] .three = true := by decide
def e605593503674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e605593503674 : Closed e605593503674 ∧ code e605593503674 = 2804616759226 := by decide
theorem cert_e605593503674 : check e605593503674 [[],[]] .three = true := by decide
def e605593503706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e605593503706 : Closed e605593503706 ∧ code e605593503706 = 2804616759258 := by decide
theorem cert_e605593503706 : check e605593503706 [[],[]] .three = true := by decide
def e605593507502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e605593507502 : Closed e605593507502 ∧ code e605593507502 = 2804616763054 := by decide
theorem cert_e605593507502 : check e605593507502 [[],[]] .three = true := by decide
def e605593507510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e605593507510 : Closed e605593507510 ∧ code e605593507510 = 2804616763062 := by decide
theorem cert_e605593507510 : check e605593507510 [[],[]] .three = true := by decide
def e605593507514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e605593507514 : Closed e605593507514 ∧ code e605593507514 = 2804616763066 := by decide
theorem cert_e605593507514 : check e605593507514 [[],[]] .three = true := by decide
def e605593507542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e605593507542 : Closed e605593507542 ∧ code e605593507542 = 2804616763094 := by decide
theorem cert_e605593507542 : check e605593507542 [[],[]] .three = true := by decide
def e605593507546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e605593507546 : Closed e605593507546 ∧ code e605593507546 = 2804616763098 := by decide
theorem cert_e605593507546 : check e605593507546 [[],[]] .three = true := by decide
def e605593507562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e605593507562 : Closed e605593507562 ∧ code e605593507562 = 2804616763114 := by decide
theorem cert_e605593507562 : check e605593507562 [[],[]] .three = true := by decide
def e605593507670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e605593507670 : Closed e605593507670 ∧ code e605593507670 = 2804616763222 := by decide
theorem cert_e605593507670 : check e605593507670 [[],[]] .three = true := by decide
def e605593507674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e605593507674 : Closed e605593507674 ∧ code e605593507674 = 2804616763226 := by decide
theorem cert_e605593507674 : check e605593507674 [[],[]] .three = true := by decide
def e605593507690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e605593507690 : Closed e605593507690 ∧ code e605593507690 = 2804616763242 := by decide
theorem cert_e605593507690 : check e605593507690 [[],[]] .three = true := by decide
def e605593507754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e605593507754 : Closed e605593507754 ∧ code e605593507754 = 2804616763306 := by decide
theorem cert_e605593507754 : check e605593507754 [[],[]] .three = true := by decide
def e605593508270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e605593508270 : Closed e605593508270 ∧ code e605593508270 = 2804616763822 := by decide
theorem cert_e605593508270 : check e605593508270 [[],[]] .three = true := by decide
def e605593508278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e605593508278 : Closed e605593508278 ∧ code e605593508278 = 2804616763830 := by decide
theorem cert_e605593508278 : check e605593508278 [[],[]] .three = true := by decide
def e605593508282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605593508282 : Closed e605593508282 ∧ code e605593508282 = 2804616763834 := by decide
theorem cert_e605593508282 : check e605593508282 [[],[]] .three = true := by decide
def e605593508310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e605593508310 : Closed e605593508310 ∧ code e605593508310 = 2804616763862 := by decide
theorem cert_e605593508310 : check e605593508310 [[],[]] .three = true := by decide
def e605593508314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e605593508314 : Closed e605593508314 ∧ code e605593508314 = 2804616763866 := by decide
theorem cert_e605593508314 : check e605593508314 [[],[]] .three = true := by decide
def e605593508330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605593508330 : Closed e605593508330 ∧ code e605593508330 = 2804616763882 := by decide
theorem cert_e605593508330 : check e605593508330 [[],[]] .three = true := by decide
def e605593508462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593508462 : Closed e605593508462 ∧ code e605593508462 = 2804616764014 := by decide
theorem cert_e605593508462 : check e605593508462 [[],[]] .three = true := by decide
def e605593508470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e605593508470 : Closed e605593508470 ∧ code e605593508470 = 2804616764022 := by decide
theorem cert_e605593508470 : check e605593508470 [[],[]] .three = true := by decide
def e605593508474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593508474 : Closed e605593508474 ∧ code e605593508474 = 2804616764026 := by decide
theorem cert_e605593508474 : check e605593508474 [[],[]] .three = true := by decide
def e605593508662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593508662 : Closed e605593508662 ∧ code e605593508662 = 2804616764214 := by decide
theorem cert_e605593508662 : check e605593508662 [[],[]] .three = true := by decide
def e605593508666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593508666 : Closed e605593508666 ∧ code e605593508666 = 2804616764218 := by decide
theorem cert_e605593508666 : check e605593508666 [[],[]] .three = true := by decide
def e605593508762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593508762 : Closed e605593508762 ∧ code e605593508762 = 2804616764314 := by decide
theorem cert_e605593508762 : check e605593508762 [[],[]] .three = true := by decide
def e605593509078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e605593509078 : Closed e605593509078 ∧ code e605593509078 = 2804616764630 := by decide
theorem cert_e605593509078 : check e605593509078 [[],[]] .three = true := by decide
def e605593509082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e605593509082 : Closed e605593509082 ∧ code e605593509082 = 2804616764634 := by decide
theorem cert_e605593509082 : check e605593509082 [[],[]] .three = true := by decide
def e605593509098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e605593509098 : Closed e605593509098 ∧ code e605593509098 = 2804616764650 := by decide
theorem cert_e605593509098 : check e605593509098 [[],[]] .three = true := by decide
def e605593509174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593509174 : Closed e605593509174 ∧ code e605593509174 = 2804616764726 := by decide
theorem cert_e605593509174 : check e605593509174 [[],[]] .three = true := by decide
def e605593509178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593509178 : Closed e605593509178 ∧ code e605593509178 = 2804616764730 := by decide
theorem cert_e605593509178 : check e605593509178 [[],[]] .three = true := by decide
def e605593509274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593509274 : Closed e605593509274 ∧ code e605593509274 = 2804616764826 := by decide
theorem cert_e605593509274 : check e605593509274 [[],[]] .three = true := by decide
def e605593509342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 3)))))))
theorem wire_e605593509342 : Closed e605593509342 ∧ code e605593509342 = 2804616764894 := by decide
theorem cert_e605593509342 : check e605593509342 [[],[]] .three = true := by decide
def e605593509358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 3))) (.var 2)))))))
theorem wire_e605593509358 : Closed e605593509358 ∧ code e605593509358 = 2804616764910 := by decide
theorem cert_e605593509358 : check e605593509358 [[],[]] .three = true := by decide
def e605593509482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605593509482 : Closed e605593509482 ∧ code e605593509482 = 2804616765034 := by decide
theorem cert_e605593509482 : check e605593509482 [[],[]] .three = true := by decide
def e605593509530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593509530 : Closed e605593509530 ∧ code e605593509530 = 2804616765082 := by decide
theorem cert_e605593509530 : check e605593509530 [[],[]] .three = true := by decide
def e605593509598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 3)))))))
theorem wire_e605593509598 : Closed e605593509598 ∧ code e605593509598 = 2804616765150 := by decide
theorem cert_e605593509598 : check e605593509598 [[],[]] .three = true := by decide
def e605593509622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 3))) (.var 1)))))))
theorem wire_e605593509622 : Closed e605593509622 ∧ code e605593509622 = 2804616765174 := by decide
theorem cert_e605593509622 : check e605593509622 [[],[]] .three = true := by decide
def e605593509742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 1))) (.var 2)))))))
theorem wire_e605593509742 : Closed e605593509742 ∧ code e605593509742 = 2804616765294 := by decide
theorem cert_e605593509742 : check e605593509742 [[],[]] .three = true := by decide
def e605593509750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 2))) (.var 1)))))))
theorem wire_e605593509750 : Closed e605593509750 ∧ code e605593509750 = 2804616765302 := by decide
theorem cert_e605593509750 : check e605593509750 [[],[]] .three = true := by decide
def e605593510366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605593510366 : Closed e605593510366 ∧ code e605593510366 = 2804616765918 := by decide
theorem cert_e605593510366 : check e605593510366 [[],[]] .three = true := by decide
def e605593510382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e605593510382 : Closed e605593510382 ∧ code e605593510382 = 2804616765934 := by decide
theorem cert_e605593510382 : check e605593510382 [[],[]] .three = true := by decide
def e605593510390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605593510390 : Closed e605593510390 ∧ code e605593510390 = 2804616765942 := by decide
theorem cert_e605593510390 : check e605593510390 [[],[]] .three = true := by decide
def e605593511342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605593511342 : Closed e605593511342 ∧ code e605593511342 = 2804616766894 := by decide
theorem cert_e605593511342 : check e605593511342 [[],[]] .three = true := by decide
def e605593511350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e605593511350 : Closed e605593511350 ∧ code e605593511350 = 2804616766902 := by decide
theorem cert_e605593511350 : check e605593511350 [[],[]] .three = true := by decide
def e605593511354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605593511354 : Closed e605593511354 ∧ code e605593511354 = 2804616766906 := by decide
theorem cert_e605593511354 : check e605593511354 [[],[]] .three = true := by decide
def e605593511382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e605593511382 : Closed e605593511382 ∧ code e605593511382 = 2804616766934 := by decide
theorem cert_e605593511382 : check e605593511382 [[],[]] .three = true := by decide
def e605593511386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e605593511386 : Closed e605593511386 ∧ code e605593511386 = 2804616766938 := by decide
theorem cert_e605593511386 : check e605593511386 [[],[]] .three = true := by decide
def e605593511402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605593511402 : Closed e605593511402 ∧ code e605593511402 = 2804616766954 := by decide
theorem cert_e605593511402 : check e605593511402 [[],[]] .three = true := by decide
def e605593511534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593511534 : Closed e605593511534 ∧ code e605593511534 = 2804616767086 := by decide
theorem cert_e605593511534 : check e605593511534 [[],[]] .three = true := by decide
def e605593511542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e605593511542 : Closed e605593511542 ∧ code e605593511542 = 2804616767094 := by decide
theorem cert_e605593511542 : check e605593511542 [[],[]] .three = true := by decide
def e605593511546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593511546 : Closed e605593511546 ∧ code e605593511546 = 2804616767098 := by decide
theorem cert_e605593511546 : check e605593511546 [[],[]] .three = true := by decide
def e605593511734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593511734 : Closed e605593511734 ∧ code e605593511734 = 2804616767286 := by decide
theorem cert_e605593511734 : check e605593511734 [[],[]] .three = true := by decide
def e605593511738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593511738 : Closed e605593511738 ∧ code e605593511738 = 2804616767290 := by decide
theorem cert_e605593511738 : check e605593511738 [[],[]] .three = true := by decide
def e605593511834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593511834 : Closed e605593511834 ∧ code e605593511834 = 2804616767386 := by decide
theorem cert_e605593511834 : check e605593511834 [[],[]] .three = true := by decide
def e605593514222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605593514222 : Closed e605593514222 ∧ code e605593514222 = 2804616769774 := by decide
theorem cert_e605593514222 : check e605593514222 [[],[]] .three = true := by decide
def e605593514230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605593514230 : Closed e605593514230 ∧ code e605593514230 = 2804616769782 := by decide
theorem cert_e605593514230 : check e605593514230 [[],[]] .three = true := by decide
def e605593514710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605593514710 : Closed e605593514710 ∧ code e605593514710 = 2804616770262 := by decide
theorem cert_e605593514710 : check e605593514710 [[],[]] .three = true := by decide
def e605593514714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605593514714 : Closed e605593514714 ∧ code e605593514714 = 2804616770266 := by decide
theorem cert_e605593514714 : check e605593514714 [[],[]] .three = true := by decide
def e605593514730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605593514730 : Closed e605593514730 ∧ code e605593514730 = 2804616770282 := by decide
theorem cert_e605593514730 : check e605593514730 [[],[]] .three = true := by decide
def e605593514806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593514806 : Closed e605593514806 ∧ code e605593514806 = 2804616770358 := by decide
theorem cert_e605593514806 : check e605593514806 [[],[]] .three = true := by decide
def e605593514810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593514810 : Closed e605593514810 ∧ code e605593514810 = 2804616770362 := by decide
theorem cert_e605593514810 : check e605593514810 [[],[]] .three = true := by decide
def e605593514906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593514906 : Closed e605593514906 ∧ code e605593514906 = 2804616770458 := by decide
theorem cert_e605593514906 : check e605593514906 [[],[]] .three = true := by decide
def e605593514974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 3))))))))
theorem wire_e605593514974 : Closed e605593514974 ∧ code e605593514974 = 2804616770526 := by decide
theorem cert_e605593514974 : check e605593514974 [[],[]] .three = true := by decide
def e605593514990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 3) (.var 2))))))))
theorem wire_e605593514990 : Closed e605593514990 ∧ code e605593514990 = 2804616770542 := by decide
theorem cert_e605593514990 : check e605593514990 [[],[]] .three = true := by decide
def e605593516150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605593516150 : Closed e605593516150 ∧ code e605593516150 = 2804616771702 := by decide
theorem cert_e605593516150 : check e605593516150 [[],[]] .three = true := by decide
def e605593516394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605593516394 : Closed e605593516394 ∧ code e605593516394 = 2804616771946 := by decide
theorem cert_e605593516394 : check e605593516394 [[],[]] .three = true := by decide
def e605593516442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593516442 : Closed e605593516442 ∧ code e605593516442 = 2804616771994 := by decide
theorem cert_e605593516442 : check e605593516442 [[],[]] .three = true := by decide
def e605593516510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 3))))))))
theorem wire_e605593516510 : Closed e605593516510 ∧ code e605593516510 = 2804616772062 := by decide
theorem cert_e605593516510 : check e605593516510 [[],[]] .three = true := by decide
def e605593516534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 3) (.var 1))))))))
theorem wire_e605593516534 : Closed e605593516534 ∧ code e605593516534 = 2804616772086 := by decide
theorem cert_e605593516534 : check e605593516534 [[],[]] .three = true := by decide
def e605593517294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem wire_e605593517294 : Closed e605593517294 ∧ code e605593517294 = 2804616772846 := by decide
private def t_e605593517294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem cert_e605593517294 : ¬ IsSelfInterpreter e605593517294 :=
  wSource (t := t_e605593517294) (replay_sound (ps := []) (t := e605593517294) (by decide)) (by decide)
def e605593517302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem wire_e605593517302 : Closed e605593517302 ∧ code e605593517302 = 2804616772854 := by decide
private def t_e605593517302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem cert_e605593517302 : ¬ IsSelfInterpreter e605593517302 :=
  wSource (t := t_e605593517302) (replay_sound (ps := []) (t := e605593517302) (by decide)) (by decide)
def e605593546206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e605593546206 : Closed e605593546206 ∧ code e605593546206 = 2804616801758 := by decide
theorem cert_e605593546206 : check e605593546206 [[],[]] .smaller = true := by decide
def e605593546222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e605593546222 : Closed e605593546222 ∧ code e605593546222 = 2804616801774 := by decide
theorem cert_e605593546222 : check e605593546222 [[],[]] .smaller = true := by decide
def e605593546590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e605593546590 : Closed e605593546590 ∧ code e605593546590 = 2804616802142 := by decide
theorem cert_e605593546590 : check e605593546590 [[],[]] .smaller = true := by decide
def e605593546618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e605593546618 : Closed e605593546618 ∧ code e605593546618 = 2804616802170 := by decide
theorem cert_e605593546618 : check e605593546618 [[],[]] .smaller = true := by decide
def e605593546670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e605593546670 : Closed e605593546670 ∧ code e605593546670 = 2804616802222 := by decide
theorem cert_e605593546670 : check e605593546670 [[],[]] .smaller = true := by decide
def e605593546682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e605593546682 : Closed e605593546682 ∧ code e605593546682 = 2804616802234 := by decide
theorem cert_e605593546682 : check e605593546682 [[],[]] .smaller = true := by decide
def e605593547742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e605593547742 : Closed e605593547742 ∧ code e605593547742 = 2804616803294 := by decide
theorem cert_e605593547742 : check e605593547742 [[],[]] .smaller = true := by decide
def e605593547758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e605593547758 : Closed e605593547758 ∧ code e605593547758 = 2804616803310 := by decide
theorem cert_e605593547758 : check e605593547758 [[],[]] .smaller = true := by decide
def e605593550046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e605593550046 : Closed e605593550046 ∧ code e605593550046 = 2804616805598 := by decide
theorem cert_e605593550046 : check e605593550046 [[],[]] .smaller = true := by decide
def e605593550074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e605593550074 : Closed e605593550074 ∧ code e605593550074 = 2804616805626 := by decide
theorem cert_e605593550074 : check e605593550074 [[],[]] .smaller = true := by decide
def e605593550446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605593550446 : Closed e605593550446 ∧ code e605593550446 = 2804616805998 := by decide
theorem cert_e605593550446 : check e605593550446 [[],[]] .smaller = true := by decide
def e605593550458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605593550458 : Closed e605593550458 ∧ code e605593550458 = 2804616806010 := by decide
theorem cert_e605593550458 : check e605593550458 [[],[]] .smaller = true := by decide
def e605593578862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e605593578862 : Closed e605593578862 ∧ code e605593578862 = 2804616834414 := by decide
theorem cert_e605593578862 : check e605593578862 [[],[]] .smaller = true := by decide
def e605593578870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e605593578870 : Closed e605593578870 ∧ code e605593578870 = 2804616834422 := by decide
theorem cert_e605593578870 : check e605593578870 [[],[]] .smaller = true := by decide
def e605593578926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e605593578926 : Closed e605593578926 ∧ code e605593578926 = 2804616834478 := by decide
theorem cert_e605593578926 : check e605593578926 [[],[]] .smaller = true := by decide
def e605593578938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e605593578938 : Closed e605593578938 ∧ code e605593578938 = 2804616834490 := by decide
theorem cert_e605593578938 : check e605593578938 [[],[]] .smaller = true := by decide
def e605593578966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e605593578966 : Closed e605593578966 ∧ code e605593578966 = 2804616834518 := by decide
theorem cert_e605593578966 : check e605593578966 [[],[]] .smaller = true := by decide
def e605593578970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e605593578970 : Closed e605593578970 ∧ code e605593578970 = 2804616834522 := by decide
theorem cert_e605593578970 : check e605593578970 [[],[]] .smaller = true := by decide
def e605593579182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e605593579182 : Closed e605593579182 ∧ code e605593579182 = 2804616834734 := by decide
theorem cert_e605593579182 : check e605593579182 [[],[]] .smaller = true := by decide
def e605593579194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e605593579194 : Closed e605593579194 ∧ code e605593579194 = 2804616834746 := by decide
theorem cert_e605593579194 : check e605593579194 [[],[]] .smaller = true := by decide
def e605593579242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e605593579242 : Closed e605593579242 ∧ code e605593579242 = 2804616834794 := by decide
theorem cert_e605593579242 : check e605593579242 [[],[]] .smaller = true := by decide
def e605593579350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e605593579350 : Closed e605593579350 ∧ code e605593579350 = 2804616834902 := by decide
theorem cert_e605593579350 : check e605593579350 [[],[]] .smaller = true := by decide
def e605593579354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e605593579354 : Closed e605593579354 ∧ code e605593579354 = 2804616834906 := by decide
theorem cert_e605593579354 : check e605593579354 [[],[]] .smaller = true := by decide
def e605593579370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e605593579370 : Closed e605593579370 ∧ code e605593579370 = 2804616834922 := by decide
theorem cert_e605593579370 : check e605593579370 [[],[]] .smaller = true := by decide
def e605593579998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3)))))))))
theorem wire_e605593579998 : Closed e605593579998 ∧ code e605593579998 = 2804616835550 := by decide
theorem cert_e605593579998 : check e605593579998 [[],[]] .smaller = true := by decide
def e605593580022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1)))))))))
theorem wire_e605593580022 : Closed e605593580022 ∧ code e605593580022 = 2804616835574 := by decide
theorem cert_e605593580022 : check e605593580022 [[],[]] .smaller = true := by decide
def e605593580398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e605593580398 : Closed e605593580398 ∧ code e605593580398 = 2804616835950 := by decide
theorem cert_e605593580398 : check e605593580398 [[],[]] .smaller = true := by decide
def e605593580406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e605593580406 : Closed e605593580406 ∧ code e605593580406 = 2804616835958 := by decide
theorem cert_e605593580406 : check e605593580406 [[],[]] .smaller = true := by decide
def e605593580462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e605593580462 : Closed e605593580462 ∧ code e605593580462 = 2804616836014 := by decide
theorem cert_e605593580462 : check e605593580462 [[],[]] .smaller = true := by decide
def e605593580474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e605593580474 : Closed e605593580474 ∧ code e605593580474 = 2804616836026 := by decide
theorem cert_e605593580474 : check e605593580474 [[],[]] .smaller = true := by decide
def e605593580502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e605593580502 : Closed e605593580502 ∧ code e605593580502 = 2804616836054 := by decide
theorem cert_e605593580502 : check e605593580502 [[],[]] .smaller = true := by decide
def e605593580506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e605593580506 : Closed e605593580506 ∧ code e605593580506 = 2804616836058 := by decide
theorem cert_e605593580506 : check e605593580506 [[],[]] .smaller = true := by decide
def e605593580782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e605593580782 : Closed e605593580782 ∧ code e605593580782 = 2804616836334 := by decide
theorem cert_e605593580782 : check e605593580782 [[],[]] .smaller = true := by decide
def e605593580790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e605593580790 : Closed e605593580790 ∧ code e605593580790 = 2804616836342 := by decide
theorem cert_e605593580790 : check e605593580790 [[],[]] .smaller = true := by decide
def e605593581118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4))))))))))
theorem wire_e605593581118 : Closed e605593581118 ∧ code e605593581118 = 2804616836670 := by decide
theorem cert_e605593581118 : check e605593581118 [[],[]] .smaller = true := by decide
def e605593581166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605593581166 : Closed e605593581166 ∧ code e605593581166 = 2804616836718 := by decide
theorem cert_e605593581166 : check e605593581166 [[],[]] .smaller = true := by decide
def e605593581178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605593581178 : Closed e605593581178 ∧ code e605593581178 = 2804616836730 := by decide
theorem cert_e605593581178 : check e605593581178 [[],[]] .smaller = true := by decide
def e605593581366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605593581366 : Closed e605593581366 ∧ code e605593581366 = 2804616836918 := by decide
theorem cert_e605593581366 : check e605593581366 [[],[]] .smaller = true := by decide
def e605593581370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605593581370 : Closed e605593581370 ∧ code e605593581370 = 2804616836922 := by decide
theorem cert_e605593581370 : check e605593581370 [[],[]] .smaller = true := by decide
def e605593581454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2))))))))))
theorem wire_e605593581454 : Closed e605593581454 ∧ code e605593581454 = 2804616837006 := by decide
theorem cert_e605593581454 : check e605593581454 [[],[]] .smaller = true := by decide
def e605593581790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e605593581790 : Closed e605593581790 ∧ code e605593581790 = 2804616837342 := by decide
theorem cert_e605593581790 : check e605593581790 [[],[]] .smaller = true := by decide
def e605593581818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e605593581818 : Closed e605593581818 ∧ code e605593581818 = 2804616837370 := by decide
theorem cert_e605593581818 : check e605593581818 [[],[]] .smaller = true := by decide
def e605593581998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e605593581998 : Closed e605593581998 ∧ code e605593581998 = 2804616837550 := by decide
theorem cert_e605593581998 : check e605593581998 [[],[]] .smaller = true := by decide
def e605593582010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e605593582010 : Closed e605593582010 ∧ code e605593582010 = 2804616837562 := by decide
theorem cert_e605593582010 : check e605593582010 [[],[]] .smaller = true := by decide
def e605593582058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e605593582058 : Closed e605593582058 ∧ code e605593582058 = 2804616837610 := by decide
theorem cert_e605593582058 : check e605593582058 [[],[]] .smaller = true := by decide
def e605593582142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e605593582142 : Closed e605593582142 ∧ code e605593582142 = 2804616837694 := by decide
theorem cert_e605593582142 : check e605593582142 [[],[]] .smaller = true := by decide
def e605593582190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605593582190 : Closed e605593582190 ∧ code e605593582190 = 2804616837742 := by decide
theorem cert_e605593582190 : check e605593582190 [[],[]] .smaller = true := by decide
def e605593582202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605593582202 : Closed e605593582202 ∧ code e605593582202 = 2804616837754 := by decide
theorem cert_e605593582202 : check e605593582202 [[],[]] .smaller = true := by decide
def e605593582490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605593582490 : Closed e605593582490 ∧ code e605593582490 = 2804616838042 := by decide
theorem cert_e605593582490 : check e605593582490 [[],[]] .smaller = true := by decide
def e605593582526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 4)))))))))
theorem wire_e605593582526 : Closed e605593582526 ∧ code e605593582526 = 2804616838078 := by decide
theorem cert_e605593582526 : check e605593582526 [[],[]] .three = true := by decide
def e605593582534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e605593582534 : Closed e605593582534 ∧ code e605593582534 = 2804616838086 := by decide
theorem cert_e605593582534 : check e605593582534 [[],[]] .smaller = true := by decide
def e605593582574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 4)) (.var 2)))))))))
theorem wire_e605593582574 : Closed e605593582574 ∧ code e605593582574 = 2804616838126 := by decide
theorem cert_e605593582574 : check e605593582574 [[],[]] .three = true := by decide
def e605593582806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e605593582806 : Closed e605593582806 ∧ code e605593582806 = 2804616838358 := by decide
theorem cert_e605593582806 : check e605593582806 [[],[]] .smaller = true := by decide
def e605593582810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e605593582810 : Closed e605593582810 ∧ code e605593582810 = 2804616838362 := by decide
theorem cert_e605593582810 : check e605593582810 [[],[]] .smaller = true := by decide
def e605593582826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e605593582826 : Closed e605593582826 ∧ code e605593582826 = 2804616838378 := by decide
theorem cert_e605593582826 : check e605593582826 [[],[]] .smaller = true := by decide
def e605593582902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605593582902 : Closed e605593582902 ∧ code e605593582902 = 2804616838454 := by decide
theorem cert_e605593582902 : check e605593582902 [[],[]] .smaller = true := by decide
def e605593582906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605593582906 : Closed e605593582906 ∧ code e605593582906 = 2804616838458 := by decide
theorem cert_e605593582906 : check e605593582906 [[],[]] .smaller = true := by decide
def e605593583002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605593583002 : Closed e605593583002 ∧ code e605593583002 = 2804616838554 := by decide
theorem cert_e605593583002 : check e605593583002 [[],[]] .smaller = true := by decide
def e605593583038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 4)))))))))
theorem wire_e605593583038 : Closed e605593583038 ∧ code e605593583038 = 2804616838590 := by decide
theorem cert_e605593583038 : check e605593583038 [[],[]] .three = true := by decide
def e605593583070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.var 3)))))))))
theorem wire_e605593583070 : Closed e605593583070 ∧ code e605593583070 = 2804616838622 := by decide
theorem cert_e605593583070 : check e605593583070 [[],[]] .smaller = true := by decide
def e605593583086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 2)))))))))
theorem wire_e605593583086 : Closed e605593583086 ∧ code e605593583086 = 2804616838638 := by decide
theorem cert_e605593583086 : check e605593583086 [[],[]] .smaller = true := by decide
def e605593583094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 4)) (.var 1)))))))))
theorem wire_e605593583094 : Closed e605593583094 ∧ code e605593583094 = 2804616838646 := by decide
theorem cert_e605593583094 : check e605593583094 [[],[]] .three = true := by decide
def e605593583158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e605593583158 : Closed e605593583158 ∧ code e605593583158 = 2804616838710 := by decide
theorem cert_e605593583158 : check e605593583158 [[],[]] .smaller = true := by decide
def e605593583162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e605593583162 : Closed e605593583162 ∧ code e605593583162 = 2804616838714 := by decide
theorem cert_e605593583162 : check e605593583162 [[],[]] .smaller = true := by decide
def e605593583246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e605593583246 : Closed e605593583246 ∧ code e605593583246 = 2804616838798 := by decide
theorem cert_e605593583246 : check e605593583246 [[],[]] .smaller = true := by decide
def e605593583302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e605593583302 : Closed e605593583302 ∧ code e605593583302 = 2804616838854 := by decide
theorem cert_e605593583302 : check e605593583302 [[],[]] .smaller = true := by decide
def e605593583342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 2)))))))))
theorem wire_e605593583342 : Closed e605593583342 ∧ code e605593583342 = 2804616838894 := by decide
theorem cert_e605593583342 : check e605593583342 [[],[]] .smaller = true := by decide
def e605593583470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 1)) (.var 2)))))))))
theorem wire_e605593583470 : Closed e605593583470 ∧ code e605593583470 = 2804616839022 := by decide
theorem cert_e605593583470 : check e605593583470 [[],[]] .three = true := by decide
def e605593583478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 2)) (.var 1)))))))))
theorem wire_e605593583478 : Closed e605593583478 ∧ code e605593583478 = 2804616839030 := by decide
theorem cert_e605593583478 : check e605593583478 [[],[]] .three = true := by decide
def e605593584606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e605593584606 : Closed e605593584606 ∧ code e605593584606 = 2804616840158 := by decide
theorem cert_e605593584606 : check e605593584606 [[],[]] .smaller = true := by decide
def e605593584622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e605593584622 : Closed e605593584622 ∧ code e605593584622 = 2804616840174 := by decide
theorem cert_e605593584622 : check e605593584622 [[],[]] .smaller = true := by decide
def e605593586542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605593586542 : Closed e605593586542 ∧ code e605593586542 = 2804616842094 := by decide
theorem cert_e605593586542 : check e605593586542 [[],[]] .smaller = true := by decide
end Blc.Floor41
