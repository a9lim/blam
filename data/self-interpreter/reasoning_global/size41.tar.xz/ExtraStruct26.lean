import Extra41
import Batch146
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness605795408110
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.lam u4
private def u6 := Term.app u0 u5
private def u7 := Term.app u6 u4
private def u8 := Term.lam u7
private def u9 := Term.app u3 u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605795408110 : ¬ IsSelfInterpreter e605795408110 := by
  intro he
  have h : replay [] e605795408110 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605795408110
end Witness605795408110
namespace Witness605795408118
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 3
private def u5 := Term.lam u4
private def u6 := Term.app u0 u5
private def u7 := Term.app u6 u3
private def u8 := Term.lam u7
private def u9 := Term.app u3 u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605795408118 : ¬ IsSelfInterpreter e605795408118 := by
  intro he
  have h : replay [] e605795408118 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605795408118
end Witness605795408118
namespace Witness605795409006
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.lam u3
private def u5 := Term.app u3 u4
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.lam u7
private def u9 := Term.app u3 u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605795409006 : ¬ IsSelfInterpreter e605795409006 := by
  intro he
  have h : replay [] e605795409006 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605795409006
end Witness605795409006
namespace Witness605795409018
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 3
private def u5 := Term.lam u4
private def u6 := Term.app u3 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.app u3 u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private theorem sou3 : SO u3 := SO.var 1
private def u14 := Term.var 2
private def u15 := Term.lam u14
private def u16 := Term.app u0 u15
private def u17 := Term.app u3 u0
private theorem sou4 : SO u4 := SO.var 3
private theorem sou5 : SO u5 := so_dead (by decide) sou4
private theorem sou6 : SO u6 := SO.app sou3 sou5
private theorem sou7 : SO u7 := SO.app sou6 sou0
private theorem sou14 : SO u14 := SO.var 2
private theorem sou15 : SO u15 := so_dead (by decide) sou14
private theorem sou16 : SO u16 := SO.app sou0 sou15
private theorem sou8 : SO u8 := SO.lam (r := u16) (g := u17) sou7 sou16 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou3 sou8
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605795409018 : ¬ IsSelfInterpreter e605795409018 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605795409018
end Witness605795409018
namespace Witness605795409462
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.lam u3
private def u6 := Term.app u4 u5
private def u7 := Term.app u6 u3
private def u8 := Term.lam u7
private def u9 := Term.app u3 u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605795409462 : ¬ IsSelfInterpreter e605795409462 := by
  intro he
  have h : replay [] e605795409462 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605795409462
end Witness605795409462
namespace Witness605795409466
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.lam u4
private def u6 := Term.app u4 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.app u3 u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private theorem sou3 : SO u3 := SO.var 1
private def u14 := Term.lam u3
private def u15 := Term.app u3 u14
private def u16 := Term.app u3 u0
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := so_dead (by decide) sou4
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou6 sou0
private theorem sou14 : SO u14 := so_dead (by decide) sou3
private theorem sou15 : SO u15 := SO.app sou3 sou14
private theorem sou8 : SO u8 := SO.lam (r := u15) (g := u16) sou7 sou15 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou3 sou8
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605795409466 : ¬ IsSelfInterpreter e605795409466 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605795409466
end Witness605795409466
namespace Witness605795411742
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 3
private def u5 := Term.lam u4
private def u6 := Term.app u3 u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.app u3 u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private theorem sou3 : SO u3 := SO.var 1
private def u14 := Term.var 2
private def u15 := Term.lam u14
private def u16 := Term.app u0 u15
private def u17 := Term.app u0 u3
private theorem sou4 : SO u4 := SO.var 3
private theorem sou5 : SO u5 := so_dead (by decide) sou4
private theorem sou6 : SO u6 := SO.app sou3 sou5
private theorem sou7 : SO u7 := SO.app sou0 sou6
private theorem sou14 : SO u14 := SO.var 2
private theorem sou15 : SO u15 := so_dead (by decide) sou14
private theorem sou16 : SO u16 := SO.app sou0 sou15
private theorem sou8 : SO u8 := SO.lam (r := u16) (g := u17) sou7 sou16 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou3 sou8
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605795411742 : ¬ IsSelfInterpreter e605795411742 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605795411742
end Witness605795411742
namespace Witness605795411854
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.lam u4
private def u6 := Term.app u4 u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.app u3 u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private theorem sou3 : SO u3 := SO.var 1
private def u14 := Term.lam u3
private def u15 := Term.app u3 u14
private def u16 := Term.app u0 u3
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := so_dead (by decide) sou4
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou0 sou6
private theorem sou14 : SO u14 := so_dead (by decide) sou3
private theorem sou15 : SO u15 := SO.app sou3 sou14
private theorem sou8 : SO u8 := SO.lam (r := u15) (g := u16) sou7 sou15 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou3 sou8
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605795411854 : ¬ IsSelfInterpreter e605795411854 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605795411854
end Witness605795411854
end Blc.Floor41
