import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e564887618458 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e564887618458 : Closed e564887618458 ∧ code e564887618458 = 2763910874010 := by decide
theorem cert_e564887618458 : check e564887618458 [[]] .width = true := by decide
def e564887620378 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e564887620378 : Closed e564887620378 ∧ code e564887620378 = 2763910875930 := by decide
theorem cert_e564887620378 : check e564887620378 [[]] .width = true := by decide
def e564887620422 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e564887620422 : Closed e564887620422 ∧ code e564887620422 = 2763910875974 := by decide
theorem cert_e564887620422 : check e564887620422 [[]] .width = true := by decide
def e564887620662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e564887620662 : Closed e564887620662 ∧ code e564887620662 = 2763910876214 := by decide
theorem cert_e564887620662 : check e564887620662 [[]] .width = true := by decide
def e564887620666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e564887620666 : Closed e564887620666 ∧ code e564887620666 = 2763910876218 := by decide
theorem cert_e564887620666 : check e564887620666 [[]] .width = true := by decide
def e564887620806 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e564887620806 : Closed e564887620806 ∧ code e564887620806 = 2763910876358 := by decide
theorem cert_e564887620806 : check e564887620806 [[]] .width = true := by decide
def e564894855366 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564894855366 : Closed e564894855366 ∧ code e564894855366 = 2763918110918 := by decide
theorem cert_e564894855366 : check e564894855366 [[]] .width = true := by decide
def e564894871750 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564894871750 : Closed e564894871750 ∧ code e564894871750 = 2763918127302 := by decide
theorem cert_e564894871750 : check e564894871750 [[]] .width = true := by decide
def e564894986438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564894986438 : Closed e564894986438 ∧ code e564894986438 = 2763918241990 := by decide
theorem cert_e564894986438 : check e564894986438 [[]] .width = true := by decide
def e564895011014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564895011014 : Closed e564895011014 ∧ code e564895011014 = 2763918266566 := by decide
theorem cert_e564895011014 : check e564895011014 [[]] .width = true := by decide
def e564895068358 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564895068358 : Closed e564895068358 ∧ code e564895068358 = 2763918323910 := by decide
theorem cert_e564895068358 : check e564895068358 [[]] .width = true := by decide
def e564895076550 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564895076550 : Closed e564895076550 ∧ code e564895076550 = 2763918332102 := by decide
theorem cert_e564895076550 : check e564895076550 [[]] .width = true := by decide
def e564895641798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564895641798 : Closed e564895641798 ∧ code e564895641798 = 2763918897350 := by decide
theorem cert_e564895641798 : check e564895641798 [[]] .width = true := by decide
def e564895658182 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564895658182 : Closed e564895658182 ∧ code e564895658182 = 2763918913734 := by decide
theorem cert_e564895658182 : check e564895658182 [[]] .width = true := by decide
def e564896325658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564896325658 : Closed e564896325658 ∧ code e564896325658 = 2763919581210 := by decide
theorem cert_e564896325658 : check e564896325658 [[]] .width = true := by decide
def e564896325750 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564896325750 : Closed e564896325750 ∧ code e564896325750 = 2763919581302 := by decide
theorem cert_e564896325750 : check e564896325750 [[]] .width = true := by decide
def e564896325994 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564896325994 : Closed e564896325994 ∧ code e564896325994 = 2763919581546 := by decide
theorem cert_e564896325994 : check e564896325994 [[]] .width = true := by decide
def e564896326042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564896326042 : Closed e564896326042 ∧ code e564896326042 = 2763919581594 := by decide
theorem cert_e564896326042 : check e564896326042 [[]] .width = true := by decide
def e564896428230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564896428230 : Closed e564896428230 ∧ code e564896428230 = 2763919683782 := by decide
theorem cert_e564896428230 : check e564896428230 [[]] .width = true := by decide
def e564896452806 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564896452806 : Closed e564896452806 ∧ code e564896452806 = 2763919708358 := by decide
theorem cert_e564896452806 : check e564896452806 [[]] .width = true := by decide
def e564896661702 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564896661702 : Closed e564896661702 ∧ code e564896661702 = 2763919917254 := by decide
theorem cert_e564896661702 : check e564896661702 [[]] .width = true := by decide
def e564896662230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e564896662230 : Closed e564896662230 ∧ code e564896662230 = 2763919917782 := by decide
theorem cert_e564896662230 : check e564896662230 [[]] .width = true := by decide
def e564896662234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e564896662234 : Closed e564896662234 ∧ code e564896662234 = 2763919917786 := by decide
theorem cert_e564896662234 : check e564896662234 [[]] .width = true := by decide
def e564896662250 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e564896662250 : Closed e564896662250 ∧ code e564896662250 = 2763919917802 := by decide
theorem cert_e564896662250 : check e564896662250 [[]] .width = true := by decide
def e564896662326 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e564896662326 : Closed e564896662326 ∧ code e564896662326 = 2763919917878 := by decide
theorem cert_e564896662326 : check e564896662326 [[]] .width = true := by decide
def e564896662330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e564896662330 : Closed e564896662330 ∧ code e564896662330 = 2763919917882 := by decide
theorem cert_e564896662330 : check e564896662330 [[]] .width = true := by decide
def e564896662414 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e564896662414 : Closed e564896662414 ∧ code e564896662414 = 2763919917966 := by decide
theorem cert_e564896662414 : check e564896662414 [[]] .width = true := by decide
def e564896662426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e564896662426 : Closed e564896662426 ∧ code e564896662426 = 2763919917978 := by decide
theorem cert_e564896662426 : check e564896662426 [[]] .width = true := by decide
def e564896664346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e564896664346 : Closed e564896664346 ∧ code e564896664346 = 2763919919898 := by decide
theorem cert_e564896664346 : check e564896664346 [[]] .width = true := by decide
def e564896664390 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e564896664390 : Closed e564896664390 ∧ code e564896664390 = 2763919919942 := by decide
theorem cert_e564896664390 : check e564896664390 [[]] .width = true := by decide
def e564896664630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e564896664630 : Closed e564896664630 ∧ code e564896664630 = 2763919920182 := by decide
theorem cert_e564896664630 : check e564896664630 [[]] .width = true := by decide
def e564896664634 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e564896664634 : Closed e564896664634 ∧ code e564896664634 = 2763919920186 := by decide
theorem cert_e564896664634 : check e564896664634 [[]] .width = true := by decide
def e564896664774 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e564896664774 : Closed e564896664774 ∧ code e564896664774 = 2763919920326 := by decide
theorem cert_e564896664774 : check e564896664774 [[]] .width = true := by decide
def e564896784410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564896784410 : Closed e564896784410 ∧ code e564896784410 = 2763920039962 := by decide
theorem cert_e564896784410 : check e564896784410 [[]] .width = true := by decide
def e564896784502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564896784502 : Closed e564896784502 ∧ code e564896784502 = 2763920040054 := by decide
theorem cert_e564896784502 : check e564896784502 [[]] .width = true := by decide
def e564896784746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564896784746 : Closed e564896784746 ∧ code e564896784746 = 2763920040298 := by decide
theorem cert_e564896784746 : check e564896784746 [[]] .width = true := by decide
def e564896784794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564896784794 : Closed e564896784794 ∧ code e564896784794 = 2763920040346 := by decide
theorem cert_e564896784794 : check e564896784794 [[]] .width = true := by decide
def e564896837830 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564896837830 : Closed e564896837830 ∧ code e564896837830 = 2763920093382 := by decide
theorem cert_e564896837830 : check e564896837830 [[]] .width = true := by decide
def e564896846022 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564896846022 : Closed e564896846022 ∧ code e564896846022 = 2763920101574 := by decide
theorem cert_e564896846022 : check e564896846022 [[]] .width = true := by decide
def e564896923846 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564896923846 : Closed e564896923846 ∧ code e564896923846 = 2763920179398 := by decide
theorem cert_e564896923846 : check e564896923846 [[]] .width = true := by decide
def e564896924374 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e564896924374 : Closed e564896924374 ∧ code e564896924374 = 2763920179926 := by decide
theorem cert_e564896924374 : check e564896924374 [[]] .width = true := by decide
def e564896924378 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e564896924378 : Closed e564896924378 ∧ code e564896924378 = 2763920179930 := by decide
theorem cert_e564896924378 : check e564896924378 [[]] .width = true := by decide
def e564896924394 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e564896924394 : Closed e564896924394 ∧ code e564896924394 = 2763920179946 := by decide
theorem cert_e564896924394 : check e564896924394 [[]] .width = true := by decide
def e564896924470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e564896924470 : Closed e564896924470 ∧ code e564896924470 = 2763920180022 := by decide
theorem cert_e564896924470 : check e564896924470 [[]] .width = true := by decide
def e564896924474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e564896924474 : Closed e564896924474 ∧ code e564896924474 = 2763920180026 := by decide
theorem cert_e564896924474 : check e564896924474 [[]] .width = true := by decide
def e564896924558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e564896924558 : Closed e564896924558 ∧ code e564896924558 = 2763920180110 := by decide
theorem cert_e564896924558 : check e564896924558 [[]] .width = true := by decide
def e564896924570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e564896924570 : Closed e564896924570 ∧ code e564896924570 = 2763920180122 := by decide
theorem cert_e564896924570 : check e564896924570 [[]] .width = true := by decide
def e564896926490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e564896926490 : Closed e564896926490 ∧ code e564896926490 = 2763920182042 := by decide
theorem cert_e564896926490 : check e564896926490 [[]] .width = true := by decide
def e564896926534 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e564896926534 : Closed e564896926534 ∧ code e564896926534 = 2763920182086 := by decide
theorem cert_e564896926534 : check e564896926534 [[]] .width = true := by decide
def e564896926774 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e564896926774 : Closed e564896926774 ∧ code e564896926774 = 2763920182326 := by decide
theorem cert_e564896926774 : check e564896926774 [[]] .width = true := by decide
def e564896926778 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e564896926778 : Closed e564896926778 ∧ code e564896926778 = 2763920182330 := by decide
theorem cert_e564896926778 : check e564896926778 [[]] .width = true := by decide
def e564896926918 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e564896926918 : Closed e564896926918 ∧ code e564896926918 = 2763920182470 := by decide
theorem cert_e564896926918 : check e564896926918 [[]] .width = true := by decide
def e564908617926 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564908617926 : Closed e564908617926 ∧ code e564908617926 = 2763931873478 := by decide
theorem cert_e564908617926 : check e564908617926 [[]] .width = true := by decide
def e564908642502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564908642502 : Closed e564908642502 ∧ code e564908642502 = 2763931898054 := by decide
theorem cert_e564908642502 : check e564908642502 [[]] .width = true := by decide
def e564908740806 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564908740806 : Closed e564908740806 ∧ code e564908740806 = 2763931996358 := by decide
theorem cert_e564908740806 : check e564908740806 [[]] .width = true := by decide
def e564908908570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564908908570 : Closed e564908908570 ∧ code e564908908570 = 2763932164122 := by decide
theorem cert_e564908908570 : check e564908908570 [[]] .width = true := by decide
def e564908908662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564908908662 : Closed e564908908662 ∧ code e564908908662 = 2763932164214 := by decide
theorem cert_e564908908662 : check e564908908662 [[]] .width = true := by decide
def e564908908906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564908908906 : Closed e564908908906 ∧ code e564908908906 = 2763932164458 := by decide
theorem cert_e564908908906 : check e564908908906 [[]] .width = true := by decide
def e564908908954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564908908954 : Closed e564908908954 ∧ code e564908908954 = 2763932164506 := by decide
theorem cert_e564908908954 : check e564908908954 [[]] .width = true := by decide
def e564909011142 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564909011142 : Closed e564909011142 ∧ code e564909011142 = 2763932266694 := by decide
theorem cert_e564909011142 : check e564909011142 [[]] .width = true := by decide
def e564909035718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564909035718 : Closed e564909035718 ∧ code e564909035718 = 2763932291270 := by decide
theorem cert_e564909035718 : check e564909035718 [[]] .width = true := by decide
def e564909244614 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564909244614 : Closed e564909244614 ∧ code e564909244614 = 2763932500166 := by decide
theorem cert_e564909244614 : check e564909244614 [[]] .width = true := by decide
def e564909245142 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e564909245142 : Closed e564909245142 ∧ code e564909245142 = 2763932500694 := by decide
theorem cert_e564909245142 : check e564909245142 [[]] .width = true := by decide
def e564909245146 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e564909245146 : Closed e564909245146 ∧ code e564909245146 = 2763932500698 := by decide
theorem cert_e564909245146 : check e564909245146 [[]] .width = true := by decide
def e564909245162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e564909245162 : Closed e564909245162 ∧ code e564909245162 = 2763932500714 := by decide
theorem cert_e564909245162 : check e564909245162 [[]] .width = true := by decide
def e564909245238 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e564909245238 : Closed e564909245238 ∧ code e564909245238 = 2763932500790 := by decide
theorem cert_e564909245238 : check e564909245238 [[]] .width = true := by decide
def e564909245242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e564909245242 : Closed e564909245242 ∧ code e564909245242 = 2763932500794 := by decide
theorem cert_e564909245242 : check e564909245242 [[]] .width = true := by decide
def e564909245326 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e564909245326 : Closed e564909245326 ∧ code e564909245326 = 2763932500878 := by decide
theorem cert_e564909245326 : check e564909245326 [[]] .width = true := by decide
def e564909245338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e564909245338 : Closed e564909245338 ∧ code e564909245338 = 2763932500890 := by decide
theorem cert_e564909245338 : check e564909245338 [[]] .width = true := by decide
def e564909247258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e564909247258 : Closed e564909247258 ∧ code e564909247258 = 2763932502810 := by decide
theorem cert_e564909247258 : check e564909247258 [[]] .width = true := by decide
def e564909247302 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e564909247302 : Closed e564909247302 ∧ code e564909247302 = 2763932502854 := by decide
theorem cert_e564909247302 : check e564909247302 [[]] .width = true := by decide
def e564909247542 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e564909247542 : Closed e564909247542 ∧ code e564909247542 = 2763932503094 := by decide
theorem cert_e564909247542 : check e564909247542 [[]] .width = true := by decide
def e564909247546 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e564909247546 : Closed e564909247546 ∧ code e564909247546 = 2763932503098 := by decide
theorem cert_e564909247546 : check e564909247546 [[]] .width = true := by decide
def e564909247686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e564909247686 : Closed e564909247686 ∧ code e564909247686 = 2763932503238 := by decide
theorem cert_e564909247686 : check e564909247686 [[]] .width = true := by decide
def e564909596698 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564909596698 : Closed e564909596698 ∧ code e564909596698 = 2763932852250 := by decide
theorem cert_e564909596698 : check e564909596698 [[]] .width = true := by decide
def e564909596790 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564909596790 : Closed e564909596790 ∧ code e564909596790 = 2763932852342 := by decide
theorem cert_e564909596790 : check e564909596790 [[]] .width = true := by decide
def e564909597034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564909597034 : Closed e564909597034 ∧ code e564909597034 = 2763932852586 := by decide
theorem cert_e564909597034 : check e564909597034 [[]] .width = true := by decide
def e564909597082 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564909597082 : Closed e564909597082 ∧ code e564909597082 = 2763932852634 := by decide
theorem cert_e564909597082 : check e564909597082 [[]] .width = true := by decide
def e564909625542 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564909625542 : Closed e564909625542 ∧ code e564909625542 = 2763932881094 := by decide
theorem cert_e564909625542 : check e564909625542 [[]] .width = true := by decide
def e564909637830 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564909637830 : Closed e564909637830 ∧ code e564909637830 = 2763932893382 := by decide
theorem cert_e564909637830 : check e564909637830 [[]] .width = true := by decide
def e564909638358 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e564909638358 : Closed e564909638358 ∧ code e564909638358 = 2763932893910 := by decide
theorem cert_e564909638358 : check e564909638358 [[]] .width = true := by decide
def e564909638362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e564909638362 : Closed e564909638362 ∧ code e564909638362 = 2763932893914 := by decide
theorem cert_e564909638362 : check e564909638362 [[]] .width = true := by decide
def e564909638378 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e564909638378 : Closed e564909638378 ∧ code e564909638378 = 2763932893930 := by decide
theorem cert_e564909638378 : check e564909638378 [[]] .width = true := by decide
def e564909638454 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e564909638454 : Closed e564909638454 ∧ code e564909638454 = 2763932894006 := by decide
theorem cert_e564909638454 : check e564909638454 [[]] .width = true := by decide
def e564909638458 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e564909638458 : Closed e564909638458 ∧ code e564909638458 = 2763932894010 := by decide
theorem cert_e564909638458 : check e564909638458 [[]] .width = true := by decide
def e564909638542 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e564909638542 : Closed e564909638542 ∧ code e564909638542 = 2763932894094 := by decide
theorem cert_e564909638542 : check e564909638542 [[]] .width = true := by decide
def e564909638554 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e564909638554 : Closed e564909638554 ∧ code e564909638554 = 2763932894106 := by decide
theorem cert_e564909638554 : check e564909638554 [[]] .width = true := by decide
def e564909640474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e564909640474 : Closed e564909640474 ∧ code e564909640474 = 2763932896026 := by decide
theorem cert_e564909640474 : check e564909640474 [[]] .width = true := by decide
def e564909640518 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e564909640518 : Closed e564909640518 ∧ code e564909640518 = 2763932896070 := by decide
theorem cert_e564909640518 : check e564909640518 [[]] .width = true := by decide
def e564909640758 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e564909640758 : Closed e564909640758 ∧ code e564909640758 = 2763932896310 := by decide
theorem cert_e564909640758 : check e564909640758 [[]] .width = true := by decide
def e564909640762 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e564909640762 : Closed e564909640762 ∧ code e564909640762 = 2763932896314 := by decide
theorem cert_e564909640762 : check e564909640762 [[]] .width = true := by decide
def e564909640902 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e564909640902 : Closed e564909640902 ∧ code e564909640902 = 2763932896454 := by decide
theorem cert_e564909640902 : check e564909640902 [[]] .width = true := by decide
def e564914516166 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564914516166 : Closed e564914516166 ∧ code e564914516166 = 2763937771718 := by decide
theorem cert_e564914516166 : check e564914516166 [[]] .width = true := by decide
def e564914532550 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564914532550 : Closed e564914532550 ∧ code e564914532550 = 2763937788102 := by decide
theorem cert_e564914532550 : check e564914532550 [[]] .width = true := by decide
def e564915515590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564915515590 : Closed e564915515590 ∧ code e564915515590 = 2763938771142 := by decide
theorem cert_e564915515590 : check e564915515590 [[]] .width = true := by decide
def e564915523782 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564915523782 : Closed e564915523782 ∧ code e564915523782 = 2763938779334 := by decide
theorem cert_e564915523782 : check e564915523782 [[]] .width = true := by decide
def e564915556550 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564915556550 : Closed e564915556550 ∧ code e564915556550 = 2763938812102 := by decide
theorem cert_e564915556550 : check e564915556550 [[]] .width = true := by decide
def e564915658778 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564915658778 : Closed e564915658778 ∧ code e564915658778 = 2763938914330 := by decide
theorem cert_e564915658778 : check e564915658778 [[]] .width = true := by decide
def e564915658870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564915658870 : Closed e564915658870 ∧ code e564915658870 = 2763938914422 := by decide
theorem cert_e564915658870 : check e564915658870 [[]] .width = true := by decide
def e564915659114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564915659114 : Closed e564915659114 ∧ code e564915659114 = 2763938914666 := by decide
theorem cert_e564915659114 : check e564915659114 [[]] .width = true := by decide
def e564915659162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564915659162 : Closed e564915659162 ∧ code e564915659162 = 2763938914714 := by decide
theorem cert_e564915659162 : check e564915659162 [[]] .width = true := by decide
def e564915712198 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564915712198 : Closed e564915712198 ∧ code e564915712198 = 2763938967750 := by decide
theorem cert_e564915712198 : check e564915712198 [[]] .width = true := by decide
def e564915720390 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564915720390 : Closed e564915720390 ∧ code e564915720390 = 2763938975942 := by decide
theorem cert_e564915720390 : check e564915720390 [[]] .width = true := by decide
def e564915798214 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564915798214 : Closed e564915798214 ∧ code e564915798214 = 2763939053766 := by decide
theorem cert_e564915798214 : check e564915798214 [[]] .width = true := by decide
def e564915798742 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e564915798742 : Closed e564915798742 ∧ code e564915798742 = 2763939054294 := by decide
theorem cert_e564915798742 : check e564915798742 [[]] .width = true := by decide
def e564915798746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e564915798746 : Closed e564915798746 ∧ code e564915798746 = 2763939054298 := by decide
theorem cert_e564915798746 : check e564915798746 [[]] .width = true := by decide
def e564915798762 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e564915798762 : Closed e564915798762 ∧ code e564915798762 = 2763939054314 := by decide
theorem cert_e564915798762 : check e564915798762 [[]] .width = true := by decide
def e564915798838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e564915798838 : Closed e564915798838 ∧ code e564915798838 = 2763939054390 := by decide
theorem cert_e564915798838 : check e564915798838 [[]] .width = true := by decide
def e564915798842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e564915798842 : Closed e564915798842 ∧ code e564915798842 = 2763939054394 := by decide
theorem cert_e564915798842 : check e564915798842 [[]] .width = true := by decide
def e564915798926 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e564915798926 : Closed e564915798926 ∧ code e564915798926 = 2763939054478 := by decide
theorem cert_e564915798926 : check e564915798926 [[]] .width = true := by decide
def e564915798938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e564915798938 : Closed e564915798938 ∧ code e564915798938 = 2763939054490 := by decide
theorem cert_e564915798938 : check e564915798938 [[]] .width = true := by decide
def e564915800858 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e564915800858 : Closed e564915800858 ∧ code e564915800858 = 2763939056410 := by decide
theorem cert_e564915800858 : check e564915800858 [[]] .width = true := by decide
def e564915800902 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e564915800902 : Closed e564915800902 ∧ code e564915800902 = 2763939056454 := by decide
theorem cert_e564915800902 : check e564915800902 [[]] .width = true := by decide
def e564915801142 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e564915801142 : Closed e564915801142 ∧ code e564915801142 = 2763939056694 := by decide
theorem cert_e564915801142 : check e564915801142 [[]] .width = true := by decide
def e564915801146 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e564915801146 : Closed e564915801146 ∧ code e564915801146 = 2763939056698 := by decide
theorem cert_e564915801146 : check e564915801146 [[]] .width = true := by decide
def e564915801286 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e564915801286 : Closed e564915801286 ∧ code e564915801286 = 2763939056838 := by decide
theorem cert_e564915801286 : check e564915801286 [[]] .width = true := by decide
def e564915888154 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564915888154 : Closed e564915888154 ∧ code e564915888154 = 2763939143706 := by decide
theorem cert_e564915888154 : check e564915888154 [[]] .width = true := by decide
def e564915888246 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564915888246 : Closed e564915888246 ∧ code e564915888246 = 2763939143798 := by decide
theorem cert_e564915888246 : check e564915888246 [[]] .width = true := by decide
def e564915888490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564915888490 : Closed e564915888490 ∧ code e564915888490 = 2763939144042 := by decide
theorem cert_e564915888490 : check e564915888490 [[]] .width = true := by decide
def e564915888538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564915888538 : Closed e564915888538 ∧ code e564915888538 = 2763939144090 := by decide
theorem cert_e564915888538 : check e564915888538 [[]] .width = true := by decide
def e564915916998 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e564915916998 : Closed e564915916998 ∧ code e564915916998 = 2763939172550 := by decide
theorem cert_e564915916998 : check e564915916998 [[]] .width = true := by decide
def e564915929286 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e564915929286 : Closed e564915929286 ∧ code e564915929286 = 2763939184838 := by decide
theorem cert_e564915929286 : check e564915929286 [[]] .width = true := by decide
def e564915929814 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e564915929814 : Closed e564915929814 ∧ code e564915929814 = 2763939185366 := by decide
theorem cert_e564915929814 : check e564915929814 [[]] .width = true := by decide
def e564915929818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e564915929818 : Closed e564915929818 ∧ code e564915929818 = 2763939185370 := by decide
theorem cert_e564915929818 : check e564915929818 [[]] .width = true := by decide
def e564915929834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e564915929834 : Closed e564915929834 ∧ code e564915929834 = 2763939185386 := by decide
theorem cert_e564915929834 : check e564915929834 [[]] .width = true := by decide
def e564915929910 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e564915929910 : Closed e564915929910 ∧ code e564915929910 = 2763939185462 := by decide
theorem cert_e564915929910 : check e564915929910 [[]] .width = true := by decide
def e564915929914 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e564915929914 : Closed e564915929914 ∧ code e564915929914 = 2763939185466 := by decide
theorem cert_e564915929914 : check e564915929914 [[]] .width = true := by decide
def e564915929998 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e564915929998 : Closed e564915929998 ∧ code e564915929998 = 2763939185550 := by decide
theorem cert_e564915929998 : check e564915929998 [[]] .width = true := by decide
def e564915930010 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e564915930010 : Closed e564915930010 ∧ code e564915930010 = 2763939185562 := by decide
theorem cert_e564915930010 : check e564915930010 [[]] .width = true := by decide
def e564915931930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e564915931930 : Closed e564915931930 ∧ code e564915931930 = 2763939187482 := by decide
theorem cert_e564915931930 : check e564915931930 [[]] .width = true := by decide
def e564915931974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e564915931974 : Closed e564915931974 ∧ code e564915931974 = 2763939187526 := by decide
theorem cert_e564915931974 : check e564915931974 [[]] .width = true := by decide
def e564915932214 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e564915932214 : Closed e564915932214 ∧ code e564915932214 = 2763939187766 := by decide
theorem cert_e564915932214 : check e564915932214 [[]] .width = true := by decide
def e564915932218 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e564915932218 : Closed e564915932218 ∧ code e564915932218 = 2763939187770 := by decide
theorem cert_e564915932218 : check e564915932218 [[]] .width = true := by decide
def e564915932358 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e564915932358 : Closed e564915932358 ∧ code e564915932358 = 2763939187910 := by decide
theorem cert_e564915932358 : check e564915932358 [[]] .width = true := by decide
def e565023169390 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e565023169390 : Closed e565023169390 ∧ code e565023169390 = 2764046424942 := by decide
theorem cert_e565023169390 : check e565023169390 [[],[.under]] .three = true := by decide
def e565023169398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e565023169398 : Closed e565023169398 ∧ code e565023169398 = 2764046424950 := by decide
theorem cert_e565023169398 : check e565023169398 [[],[.under]] .three = true := by decide
def e565023169462 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e565023169462 : Closed e565023169462 ∧ code e565023169462 = 2764046425014 := by decide
theorem cert_e565023169462 : check e565023169462 [[],[.under]] .three = true := by decide
def e565023169902 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e565023169902 : Closed e565023169902 ∧ code e565023169902 = 2764046425454 := by decide
theorem cert_e565023169902 : check e565023169902 [[],[.under]] .three = true := by decide
def e565023169910 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e565023169910 : Closed e565023169910 ∧ code e565023169910 = 2764046425462 := by decide
theorem cert_e565023169910 : check e565023169910 [[],[.under]] .three = true := by decide
def e565023169966 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e565023169966 : Closed e565023169966 ∧ code e565023169966 = 2764046425518 := by decide
theorem cert_e565023169966 : check e565023169966 [[],[.under]] .three = true := by decide
def e565023169978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e565023169978 : Closed e565023169978 ∧ code e565023169978 = 2764046425530 := by decide
theorem cert_e565023169978 : check e565023169978 [[],[.under]] .three = true := by decide
def e565023170006 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e565023170006 : Closed e565023170006 ∧ code e565023170006 = 2764046425558 := by decide
theorem cert_e565023170006 : check e565023170006 [[],[.under]] .three = true := by decide
def e565023170010 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e565023170010 : Closed e565023170010 ∧ code e565023170010 = 2764046425562 := by decide
theorem cert_e565023170010 : check e565023170010 [[],[.under]] .three = true := by decide
def e565023170230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e565023170230 : Closed e565023170230 ∧ code e565023170230 = 2764046425782 := by decide
theorem cert_e565023170230 : check e565023170230 [[],[.under]] .three = true := by decide
def e565023170262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e565023170262 : Closed e565023170262 ∧ code e565023170262 = 2764046425814 := by decide
theorem cert_e565023170262 : check e565023170262 [[],[.under]] .three = true := by decide
def e565023170266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e565023170266 : Closed e565023170266 ∧ code e565023170266 = 2764046425818 := by decide
theorem cert_e565023170266 : check e565023170266 [[],[.under]] .three = true := by decide
def e565023172462 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e565023172462 : Closed e565023172462 ∧ code e565023172462 = 2764046428014 := by decide
theorem cert_e565023172462 : check e565023172462 [[],[.under]] .three = true := by decide
def e565023172470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e565023172470 : Closed e565023172470 ∧ code e565023172470 = 2764046428022 := by decide
theorem cert_e565023172470 : check e565023172470 [[],[.under]] .three = true := by decide
def e565023172534 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e565023172534 : Closed e565023172534 ∧ code e565023172534 = 2764046428086 := by decide
theorem cert_e565023172534 : check e565023172534 [[],[.under]] .three = true := by decide
def e565023173870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e565023173870 : Closed e565023173870 ∧ code e565023173870 = 2764046429422 := by decide
theorem cert_e565023173870 : check e565023173870 [[],[.under]] .three = true := by decide
def e565023173878 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e565023173878 : Closed e565023173878 ∧ code e565023173878 = 2764046429430 := by decide
theorem cert_e565023173878 : check e565023173878 [[],[.under]] .three = true := by decide
def e565023174262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e565023174262 : Closed e565023174262 ∧ code e565023174262 = 2764046429814 := by decide
theorem cert_e565023174262 : check e565023174262 [[],[.under]] .three = true := by decide
def e565023175534 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e565023175534 : Closed e565023175534 ∧ code e565023175534 = 2764046431086 := by decide
theorem cert_e565023175534 : check e565023175534 [[],[.under]] .three = true := by decide
def e565023175542 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e565023175542 : Closed e565023175542 ∧ code e565023175542 = 2764046431094 := by decide
theorem cert_e565023175542 : check e565023175542 [[],[.under]] .three = true := by decide
def e565023175598 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e565023175598 : Closed e565023175598 ∧ code e565023175598 = 2764046431150 := by decide
theorem cert_e565023175598 : check e565023175598 [[],[.under]] .three = true := by decide
def e565023175610 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e565023175610 : Closed e565023175610 ∧ code e565023175610 = 2764046431162 := by decide
theorem cert_e565023175610 : check e565023175610 [[],[.under]] .three = true := by decide
def e565023175638 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e565023175638 : Closed e565023175638 ∧ code e565023175638 = 2764046431190 := by decide
theorem cert_e565023175638 : check e565023175638 [[],[.under]] .three = true := by decide
def e565023175642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e565023175642 : Closed e565023175642 ∧ code e565023175642 = 2764046431194 := by decide
theorem cert_e565023175642 : check e565023175642 [[],[.under]] .three = true := by decide
def e565023175918 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e565023175918 : Closed e565023175918 ∧ code e565023175918 = 2764046431470 := by decide
theorem cert_e565023175918 : check e565023175918 [[],[.under]] .three = true := by decide
def e565023175926 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e565023175926 : Closed e565023175926 ∧ code e565023175926 = 2764046431478 := by decide
theorem cert_e565023175926 : check e565023175926 [[],[.under]] .three = true := by decide
end Blc.Floor41
