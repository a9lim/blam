import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598343421550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e598343421550 : Closed e598343421550 ∧ code e598343421550 = 2797366677102 := by decide
theorem cert_e598343421550 : check e598343421550 [[],[.left],[]] .smaller = true := by decide
def e598343421562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e598343421562 : Closed e598343421562 ∧ code e598343421562 = 2797366677114 := by decide
theorem cert_e598343421562 : check e598343421562 [[],[.left],[]] .smaller = true := by decide
def e598343421750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e598343421750 : Closed e598343421750 ∧ code e598343421750 = 2797366677302 := by decide
theorem cert_e598343421750 : check e598343421750 [[],[.left],[]] .smaller = true := by decide
def e598343421754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e598343421754 : Closed e598343421754 ∧ code e598343421754 = 2797366677306 := by decide
theorem cert_e598343421754 : check e598343421754 [[],[.left],[]] .smaller = true := by decide
def e598343462254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e598343462254 : Closed e598343462254 ∧ code e598343462254 = 2797366717806 := by decide
theorem cert_e598343462254 : check e598343462254 [[],[.left],[]] .sourceHead = true := by decide
def e598343462262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e598343462262 : Closed e598343462262 ∧ code e598343462262 = 2797366717814 := by decide
theorem cert_e598343462262 : check e598343462262 [[],[.left],[]] .sourceHead = true := by decide
def e598343462318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e598343462318 : Closed e598343462318 ∧ code e598343462318 = 2797366717870 := by decide
theorem cert_e598343462318 : check e598343462318 [[],[.left],[]] .sourceHead = true := by decide
def e598343462330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e598343462330 : Closed e598343462330 ∧ code e598343462330 = 2797366717882 := by decide
theorem cert_e598343462330 : check e598343462330 [[],[.left],[]] .sourceHead = true := by decide
def e598343462358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e598343462358 : Closed e598343462358 ∧ code e598343462358 = 2797366717910 := by decide
theorem cert_e598343462358 : check e598343462358 [[],[.left],[]] .sourceHead = true := by decide
def e598343462362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e598343462362 : Closed e598343462362 ∧ code e598343462362 = 2797366717914 := by decide
theorem cert_e598343462362 : check e598343462362 [[],[.left],[]] .sourceHead = true := by decide
def e598343462574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e598343462574 : Closed e598343462574 ∧ code e598343462574 = 2797366718126 := by decide
theorem cert_e598343462574 : check e598343462574 [[],[.left],[]] .sourceHead = true := by decide
def e598343462586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e598343462586 : Closed e598343462586 ∧ code e598343462586 = 2797366718138 := by decide
theorem cert_e598343462586 : check e598343462586 [[],[.left],[]] .sourceHead = true := by decide
def e598343462634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e598343462634 : Closed e598343462634 ∧ code e598343462634 = 2797366718186 := by decide
theorem cert_e598343462634 : check e598343462634 [[],[.left],[]] .sourceHead = true := by decide
def e598343462742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e598343462742 : Closed e598343462742 ∧ code e598343462742 = 2797366718294 := by decide
theorem cert_e598343462742 : check e598343462742 [[],[.left],[]] .sourceHead = true := by decide
def e598343462746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e598343462746 : Closed e598343462746 ∧ code e598343462746 = 2797366718298 := by decide
theorem cert_e598343462746 : check e598343462746 [[],[.left],[]] .sourceHead = true := by decide
def e598343462762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e598343462762 : Closed e598343462762 ∧ code e598343462762 = 2797366718314 := by decide
theorem cert_e598343462762 : check e598343462762 [[],[.left],[]] .sourceHead = true := by decide
def e598343463790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e598343463790 : Closed e598343463790 ∧ code e598343463790 = 2797366719342 := by decide
theorem cert_e598343463790 : check e598343463790 [[],[.left],[]] .sourceHead = true := by decide
def e598343463798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e598343463798 : Closed e598343463798 ∧ code e598343463798 = 2797366719350 := by decide
theorem cert_e598343463798 : check e598343463798 [[],[.left],[]] .sourceHead = true := by decide
def e598343463854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e598343463854 : Closed e598343463854 ∧ code e598343463854 = 2797366719406 := by decide
theorem cert_e598343463854 : check e598343463854 [[],[.left],[]] .sourceHead = true := by decide
def e598343463866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e598343463866 : Closed e598343463866 ∧ code e598343463866 = 2797366719418 := by decide
theorem cert_e598343463866 : check e598343463866 [[],[.left],[]] .sourceHead = true := by decide
def e598343463894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e598343463894 : Closed e598343463894 ∧ code e598343463894 = 2797366719446 := by decide
theorem cert_e598343463894 : check e598343463894 [[],[.left],[]] .sourceHead = true := by decide
def e598343463898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e598343463898 : Closed e598343463898 ∧ code e598343463898 = 2797366719450 := by decide
theorem cert_e598343463898 : check e598343463898 [[],[.left],[]] .sourceHead = true := by decide
def e598343464174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e598343464174 : Closed e598343464174 ∧ code e598343464174 = 2797366719726 := by decide
theorem cert_e598343464174 : check e598343464174 [[],[.left],[]] .sourceHead = true := by decide
def e598343464182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e598343464182 : Closed e598343464182 ∧ code e598343464182 = 2797366719734 := by decide
theorem cert_e598343464182 : check e598343464182 [[],[.left],[]] .sourceHead = true := by decide
def e598343464558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e598343464558 : Closed e598343464558 ∧ code e598343464558 = 2797366720110 := by decide
theorem cert_e598343464558 : check e598343464558 [[],[.left],[]] .sourceHead = true := by decide
def e598343464570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e598343464570 : Closed e598343464570 ∧ code e598343464570 = 2797366720122 := by decide
theorem cert_e598343464570 : check e598343464570 [[],[.left],[]] .sourceHead = true := by decide
def e598343464758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e598343464758 : Closed e598343464758 ∧ code e598343464758 = 2797366720310 := by decide
theorem cert_e598343464758 : check e598343464758 [[],[.left],[]] .sourceHead = true := by decide
def e598343464762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e598343464762 : Closed e598343464762 ∧ code e598343464762 = 2797366720314 := by decide
theorem cert_e598343464762 : check e598343464762 [[],[.left],[]] .sourceHead = true := by decide
def e598343465198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))
theorem wire_e598343465198 : Closed e598343465198 ∧ code e598343465198 = 2797366720750 := by decide
theorem cert_e598343465198 : check e598343465198 [[],[.left],[]] .sourceHead = true := by decide
def e598343465206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))
theorem wire_e598343465206 : Closed e598343465206 ∧ code e598343465206 = 2797366720758 := by decide
theorem cert_e598343465206 : check e598343465206 [[],[.left],[]] .sourceHead = true := by decide
def e598343465390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e598343465390 : Closed e598343465390 ∧ code e598343465390 = 2797366720942 := by decide
theorem cert_e598343465390 : check e598343465390 [[],[.left],[]] .sourceHead = true := by decide
def e598343465402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e598343465402 : Closed e598343465402 ∧ code e598343465402 = 2797366720954 := by decide
theorem cert_e598343465402 : check e598343465402 [[],[.left],[]] .sourceHead = true := by decide
def e598343465450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e598343465450 : Closed e598343465450 ∧ code e598343465450 = 2797366721002 := by decide
theorem cert_e598343465450 : check e598343465450 [[],[.left],[]] .sourceHead = true := by decide
def e598343465582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e598343465582 : Closed e598343465582 ∧ code e598343465582 = 2797366721134 := by decide
theorem cert_e598343465582 : check e598343465582 [[],[.left],[]] .sourceHead = true := by decide
def e598343465594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e598343465594 : Closed e598343465594 ∧ code e598343465594 = 2797366721146 := by decide
theorem cert_e598343465594 : check e598343465594 [[],[.left],[]] .sourceHead = true := by decide
def e598343465758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))
theorem wire_e598343465758 : Closed e598343465758 ∧ code e598343465758 = 2797366721310 := by decide
theorem cert_e598343465758 : check e598343465758 [[],[.left],[]] .sourceHead = true := by decide
def e598343465870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))
theorem wire_e598343465870 : Closed e598343465870 ∧ code e598343465870 = 2797366721422 := by decide
theorem cert_e598343465870 : check e598343465870 [[],[.left],[]] .sourceHead = true := by decide
def e598343465882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e598343465882 : Closed e598343465882 ∧ code e598343465882 = 2797366721434 := by decide
theorem cert_e598343465882 : check e598343465882 [[],[.left],[]] .sourceHead = true := by decide
def e598343466102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))
theorem wire_e598343466102 : Closed e598343466102 ∧ code e598343466102 = 2797366721654 := by decide
theorem cert_e598343466102 : check e598343466102 [[],[.left],[]] .sourceHead = true := by decide
def e598343466198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e598343466198 : Closed e598343466198 ∧ code e598343466198 = 2797366721750 := by decide
theorem cert_e598343466198 : check e598343466198 [[],[.left],[]] .sourceHead = true := by decide
def e598343466202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e598343466202 : Closed e598343466202 ∧ code e598343466202 = 2797366721754 := by decide
theorem cert_e598343466202 : check e598343466202 [[],[.left],[]] .sourceHead = true := by decide
def e598343466218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e598343466218 : Closed e598343466218 ∧ code e598343466218 = 2797366721770 := by decide
theorem cert_e598343466218 : check e598343466218 [[],[.left],[]] .sourceHead = true := by decide
def e598343466294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e598343466294 : Closed e598343466294 ∧ code e598343466294 = 2797366721846 := by decide
theorem cert_e598343466294 : check e598343466294 [[],[.left],[]] .sourceHead = true := by decide
def e598343466298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e598343466298 : Closed e598343466298 ∧ code e598343466298 = 2797366721850 := by decide
theorem cert_e598343466298 : check e598343466298 [[],[.left],[]] .sourceHead = true := by decide
def e598343466382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))
theorem wire_e598343466382 : Closed e598343466382 ∧ code e598343466382 = 2797366721934 := by decide
theorem cert_e598343466382 : check e598343466382 [[],[.left],[]] .sourceHead = true := by decide
def e598343466394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e598343466394 : Closed e598343466394 ∧ code e598343466394 = 2797366721946 := by decide
theorem cert_e598343466394 : check e598343466394 [[],[.left],[]] .sourceHead = true := by decide
def e598343467998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e598343467998 : Closed e598343467998 ∧ code e598343467998 = 2797366723550 := by decide
theorem cert_e598343467998 : check e598343467998 [[],[.left],[]] .sourceHead = true := by decide
def e598343468014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e598343468014 : Closed e598343468014 ∧ code e598343468014 = 2797366723566 := by decide
theorem cert_e598343468014 : check e598343468014 [[],[.left],[]] .sourceHead = true := by decide
def e598343469934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598343469934 : Closed e598343469934 ∧ code e598343469934 = 2797366725486 := by decide
theorem cert_e598343469934 : check e598343469934 [[],[.left],[]] .sourceHead = true := by decide
def e598343469942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598343469942 : Closed e598343469942 ∧ code e598343469942 = 2797366725494 := by decide
theorem cert_e598343469942 : check e598343469942 [[],[.left],[]] .sourceHead = true := by decide
def e598343469998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598343469998 : Closed e598343469998 ∧ code e598343469998 = 2797366725550 := by decide
theorem cert_e598343469998 : check e598343469998 [[],[.left],[]] .sourceHead = true := by decide
def e598343470010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598343470010 : Closed e598343470010 ∧ code e598343470010 = 2797366725562 := by decide
theorem cert_e598343470010 : check e598343470010 [[],[.left],[]] .sourceHead = true := by decide
def e598343470038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598343470038 : Closed e598343470038 ∧ code e598343470038 = 2797366725590 := by decide
theorem cert_e598343470038 : check e598343470038 [[],[.left],[]] .sourceHead = true := by decide
def e598343470042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598343470042 : Closed e598343470042 ∧ code e598343470042 = 2797366725594 := by decide
theorem cert_e598343470042 : check e598343470042 [[],[.left],[]] .sourceHead = true := by decide
def e598343470318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598343470318 : Closed e598343470318 ∧ code e598343470318 = 2797366725870 := by decide
theorem cert_e598343470318 : check e598343470318 [[],[.left],[]] .sourceHead = true := by decide
def e598343470326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598343470326 : Closed e598343470326 ∧ code e598343470326 = 2797366725878 := by decide
theorem cert_e598343470326 : check e598343470326 [[],[.left],[]] .sourceHead = true := by decide
def e598343470702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598343470702 : Closed e598343470702 ∧ code e598343470702 = 2797366726254 := by decide
theorem cert_e598343470702 : check e598343470702 [[],[.left],[]] .sourceHead = true := by decide
def e598343470714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598343470714 : Closed e598343470714 ∧ code e598343470714 = 2797366726266 := by decide
theorem cert_e598343470714 : check e598343470714 [[],[.left],[]] .sourceHead = true := by decide
def e598343470902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598343470902 : Closed e598343470902 ∧ code e598343470902 = 2797366726454 := by decide
theorem cert_e598343470902 : check e598343470902 [[],[.left],[]] .sourceHead = true := by decide
def e598343470906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598343470906 : Closed e598343470906 ∧ code e598343470906 = 2797366726458 := by decide
theorem cert_e598343470906 : check e598343470906 [[],[.left],[]] .sourceHead = true := by decide
def e598343475678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e598343475678 : Closed e598343475678 ∧ code e598343475678 = 2797366731230 := by decide
theorem cert_e598343475678 : check e598343475678 [[],[.left],[]] .sourceHead = true := by decide
def e598343475702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e598343475702 : Closed e598343475702 ∧ code e598343475702 = 2797366731254 := by decide
theorem cert_e598343475702 : check e598343475702 [[],[.left],[]] .sourceHead = true := by decide
def e598343476654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e598343476654 : Closed e598343476654 ∧ code e598343476654 = 2797366732206 := by decide
theorem cert_e598343476654 : check e598343476654 [[],[.left],[]] .sourceHead = true := by decide
def e598343476666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e598343476666 : Closed e598343476666 ∧ code e598343476666 = 2797366732218 := by decide
theorem cert_e598343476666 : check e598343476666 [[],[.left],[]] .sourceHead = true := by decide
def e598343476714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e598343476714 : Closed e598343476714 ∧ code e598343476714 = 2797366732266 := by decide
theorem cert_e598343476714 : check e598343476714 [[],[.left],[]] .sourceHead = true := by decide
def e598343476846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e598343476846 : Closed e598343476846 ∧ code e598343476846 = 2797366732398 := by decide
theorem cert_e598343476846 : check e598343476846 [[],[.left],[]] .sourceHead = true := by decide
def e598343476858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e598343476858 : Closed e598343476858 ∧ code e598343476858 = 2797366732410 := by decide
theorem cert_e598343476858 : check e598343476858 [[],[.left],[]] .sourceHead = true := by decide
def e598343477022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e598343477022 : Closed e598343477022 ∧ code e598343477022 = 2797366732574 := by decide
theorem cert_e598343477022 : check e598343477022 [[],[.left],[]] .sourceHead = true := by decide
def e598343477134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e598343477134 : Closed e598343477134 ∧ code e598343477134 = 2797366732686 := by decide
theorem cert_e598343477134 : check e598343477134 [[],[.left],[]] .sourceHead = true := by decide
def e598343477146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e598343477146 : Closed e598343477146 ∧ code e598343477146 = 2797366732698 := by decide
theorem cert_e598343477146 : check e598343477146 [[],[.left],[]] .sourceHead = true := by decide
def e598343479534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e598343479534 : Closed e598343479534 ∧ code e598343479534 = 2797366735086 := by decide
theorem cert_e598343479534 : check e598343479534 [[],[.left],[]] .sourceHead = true := by decide
def e598343479542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e598343479542 : Closed e598343479542 ∧ code e598343479542 = 2797366735094 := by decide
theorem cert_e598343479542 : check e598343479542 [[],[.left],[]] .sourceHead = true := by decide
def e598343480022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e598343480022 : Closed e598343480022 ∧ code e598343480022 = 2797366735574 := by decide
theorem cert_e598343480022 : check e598343480022 [[],[.left],[]] .sourceHead = true := by decide
def e598343480026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e598343480026 : Closed e598343480026 ∧ code e598343480026 = 2797366735578 := by decide
theorem cert_e598343480026 : check e598343480026 [[],[.left],[]] .sourceHead = true := by decide
def e598343480042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e598343480042 : Closed e598343480042 ∧ code e598343480042 = 2797366735594 := by decide
theorem cert_e598343480042 : check e598343480042 [[],[.left],[]] .sourceHead = true := by decide
def e598343480118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e598343480118 : Closed e598343480118 ∧ code e598343480118 = 2797366735670 := by decide
theorem cert_e598343480118 : check e598343480118 [[],[.left],[]] .sourceHead = true := by decide
def e598343480122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e598343480122 : Closed e598343480122 ∧ code e598343480122 = 2797366735674 := by decide
theorem cert_e598343480122 : check e598343480122 [[],[.left],[]] .sourceHead = true := by decide
def e598343480206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e598343480206 : Closed e598343480206 ∧ code e598343480206 = 2797366735758 := by decide
theorem cert_e598343480206 : check e598343480206 [[],[.left],[]] .sourceHead = true := by decide
def e598343480218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e598343480218 : Closed e598343480218 ∧ code e598343480218 = 2797366735770 := by decide
theorem cert_e598343480218 : check e598343480218 [[],[.left],[]] .sourceHead = true := by decide
def e598343571118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e598343571118 : Closed e598343571118 ∧ code e598343571118 = 2797366826670 := by decide
theorem cert_e598343571118 : check e598343571118 [[],[.left],[],[.under]] .three = true := by decide
def e598343571130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e598343571130 : Closed e598343571130 ∧ code e598343571130 = 2797366826682 := by decide
theorem cert_e598343571130 : check e598343571130 [[],[.left],[],[.under]] .three = true := by decide
def e598343571178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e598343571178 : Closed e598343571178 ∧ code e598343571178 = 2797366826730 := by decide
theorem cert_e598343571178 : check e598343571178 [[],[.left],[],[.under]] .three = true := by decide
def e598343571370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e598343571370 : Closed e598343571370 ∧ code e598343571370 = 2797366826922 := by decide
theorem cert_e598343571370 : check e598343571370 [[],[.left],[],[.under]] .three = true := by decide
def e598343571694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e598343571694 : Closed e598343571694 ∧ code e598343571694 = 2797366827246 := by decide
theorem cert_e598343571694 : check e598343571694 [[],[.left],[],[.under]] .three = true := by decide
def e598343571702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e598343571702 : Closed e598343571702 ∧ code e598343571702 = 2797366827254 := by decide
theorem cert_e598343571702 : check e598343571702 [[],[.left],[],[.under]] .three = true := by decide
def e598343571886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e598343571886 : Closed e598343571886 ∧ code e598343571886 = 2797366827438 := by decide
theorem cert_e598343571886 : check e598343571886 [[],[.left],[],[.under]] .three = true := by decide
def e598343571898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e598343571898 : Closed e598343571898 ∧ code e598343571898 = 2797366827450 := by decide
theorem cert_e598343571898 : check e598343571898 [[],[.left],[],[.under]] .three = true := by decide
def e598343571946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e598343571946 : Closed e598343571946 ∧ code e598343571946 = 2797366827498 := by decide
theorem cert_e598343571946 : check e598343571946 [[],[.left],[],[.under]] .three = true := by decide
def e598343572078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e598343572078 : Closed e598343572078 ∧ code e598343572078 = 2797366827630 := by decide
theorem cert_e598343572078 : check e598343572078 [[],[.left],[],[.under]] .three = true := by decide
def e598343572090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e598343572090 : Closed e598343572090 ∧ code e598343572090 = 2797366827642 := by decide
theorem cert_e598343572090 : check e598343572090 [[],[.left],[],[.under]] .three = true := by decide
def e598343572254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e598343572254 : Closed e598343572254 ∧ code e598343572254 = 2797366827806 := by decide
theorem cert_e598343572254 : check e598343572254 [[],[.left],[],[.under]] .three = true := by decide
def e598343572366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e598343572366 : Closed e598343572366 ∧ code e598343572366 = 2797366827918 := by decide
theorem cert_e598343572366 : check e598343572366 [[],[.left],[],[.under]] .three = true := by decide
def e598343572378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e598343572378 : Closed e598343572378 ∧ code e598343572378 = 2797366827930 := by decide
theorem cert_e598343572378 : check e598343572378 [[],[.left],[],[.under]] .three = true := by decide
def e598343572590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e598343572590 : Closed e598343572590 ∧ code e598343572590 = 2797366828142 := by decide
theorem cert_e598343572590 : check e598343572590 [[],[.left],[],[.under]] .three = true := by decide
def e598343572602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e598343572602 : Closed e598343572602 ∧ code e598343572602 = 2797366828154 := by decide
theorem cert_e598343572602 : check e598343572602 [[],[.left],[],[.under]] .three = true := by decide
def e598343572766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e598343572766 : Closed e598343572766 ∧ code e598343572766 = 2797366828318 := by decide
theorem cert_e598343572766 : check e598343572766 [[],[.left],[],[.under]] .three = true := by decide
def e598343572934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e598343572934 : Closed e598343572934 ∧ code e598343572934 = 2797366828486 := by decide
theorem cert_e598343572934 : check e598343572934 [[],[.left],[],[.under]] .three = true := by decide
def e598343573046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e598343573046 : Closed e598343573046 ∧ code e598343573046 = 2797366828598 := by decide
theorem cert_e598343573046 : check e598343573046 [[],[.left],[],[.under]] .three = true := by decide
def e598343573050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e598343573050 : Closed e598343573050 ∧ code e598343573050 = 2797366828602 := by decide
theorem cert_e598343573050 : check e598343573050 [[],[.left],[],[.under]] .three = true := by decide
def e598343573098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e598343573098 : Closed e598343573098 ∧ code e598343573098 = 2797366828650 := by decide
theorem cert_e598343573098 : check e598343573098 [[],[.left],[],[.under]] .three = true := by decide
def e598343573134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e598343573134 : Closed e598343573134 ∧ code e598343573134 = 2797366828686 := by decide
theorem cert_e598343573134 : check e598343573134 [[],[.left],[],[.under]] .three = true := by decide
def e598343573146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e598343573146 : Closed e598343573146 ∧ code e598343573146 = 2797366828698 := by decide
theorem cert_e598343573146 : check e598343573146 [[],[.left],[],[.under]] .three = true := by decide
def e598343573190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e598343573190 : Closed e598343573190 ∧ code e598343573190 = 2797366828742 := by decide
theorem cert_e598343573190 : check e598343573190 [[],[.left],[],[.under]] .three = true := by decide
def e598343573982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e598343573982 : Closed e598343573982 ∧ code e598343573982 = 2797366829534 := by decide
theorem cert_e598343573982 : check e598343573982 [[],[.left],[],[.under]] .three = true := by decide
def e598343574006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e598343574006 : Closed e598343574006 ∧ code e598343574006 = 2797366829558 := by decide
theorem cert_e598343574006 : check e598343574006 [[],[.left],[],[.under]] .three = true := by decide
def e598343574958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e598343574958 : Closed e598343574958 ∧ code e598343574958 = 2797366830510 := by decide
theorem cert_e598343574958 : check e598343574958 [[],[.left],[],[.under]] .three = true := by decide
def e598343574970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e598343574970 : Closed e598343574970 ∧ code e598343574970 = 2797366830522 := by decide
theorem cert_e598343574970 : check e598343574970 [[],[.left],[],[.under]] .three = true := by decide
def e598343575018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e598343575018 : Closed e598343575018 ∧ code e598343575018 = 2797366830570 := by decide
theorem cert_e598343575018 : check e598343575018 [[],[.left],[],[.under]] .three = true := by decide
def e598343575150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e598343575150 : Closed e598343575150 ∧ code e598343575150 = 2797366830702 := by decide
theorem cert_e598343575150 : check e598343575150 [[],[.left],[],[.under]] .three = true := by decide
def e598343575162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e598343575162 : Closed e598343575162 ∧ code e598343575162 = 2797366830714 := by decide
theorem cert_e598343575162 : check e598343575162 [[],[.left],[],[.under]] .three = true := by decide
def e598343575326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e598343575326 : Closed e598343575326 ∧ code e598343575326 = 2797366830878 := by decide
theorem cert_e598343575326 : check e598343575326 [[],[.left],[],[.under]] .three = true := by decide
def e598343575438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e598343575438 : Closed e598343575438 ∧ code e598343575438 = 2797366830990 := by decide
theorem cert_e598343575438 : check e598343575438 [[],[.left],[],[.under]] .three = true := by decide
def e598343575450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e598343575450 : Closed e598343575450 ∧ code e598343575450 = 2797366831002 := by decide
theorem cert_e598343575450 : check e598343575450 [[],[.left],[],[.under]] .three = true := by decide
def e598343578398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e598343578398 : Closed e598343578398 ∧ code e598343578398 = 2797366833950 := by decide
theorem cert_e598343578398 : check e598343578398 [[],[.left],[],[.under]] .three = true := by decide
def e598343578566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e598343578566 : Closed e598343578566 ∧ code e598343578566 = 2797366834118 := by decide
theorem cert_e598343578566 : check e598343578566 [[],[.left],[],[.under]] .three = true := by decide
def e598343579766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e598343579766 : Closed e598343579766 ∧ code e598343579766 = 2797366835318 := by decide
theorem cert_e598343579766 : check e598343579766 [[],[.left],[],[.under]] .three = true := by decide
def e598343580010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e598343580010 : Closed e598343580010 ∧ code e598343580010 = 2797366835562 := by decide
theorem cert_e598343580010 : check e598343580010 [[],[.left],[],[.under]] .three = true := by decide
def e598343580046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e598343580046 : Closed e598343580046 ∧ code e598343580046 = 2797366835598 := by decide
theorem cert_e598343580046 : check e598343580046 [[],[.left],[],[.under]] .three = true := by decide
def e598343580058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e598343580058 : Closed e598343580058 ∧ code e598343580058 = 2797366835610 := by decide
theorem cert_e598343580058 : check e598343580058 [[],[.left],[],[.under]] .three = true := by decide
def e598343580102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e598343580102 : Closed e598343580102 ∧ code e598343580102 = 2797366835654 := by decide
theorem cert_e598343580102 : check e598343580102 [[],[.left],[],[.under]] .three = true := by decide
def e598343625558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e598343625558 : Closed e598343625558 ∧ code e598343625558 = 2797366881110 := by decide
theorem cert_e598343625558 : check e598343625558 [[],[.left],[],[.under]] .three = true := by decide
def e598343625562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e598343625562 : Closed e598343625562 ∧ code e598343625562 = 2797366881114 := by decide
theorem cert_e598343625562 : check e598343625562 [[],[.left],[],[.under]] .three = true := by decide
def e598343625578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e598343625578 : Closed e598343625578 ∧ code e598343625578 = 2797366881130 := by decide
theorem cert_e598343625578 : check e598343625578 [[],[.left],[],[.under]] .three = true := by decide
def e598343625642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e598343625642 : Closed e598343625642 ∧ code e598343625642 = 2797366881194 := by decide
theorem cert_e598343625642 : check e598343625642 [[],[.left],[],[.under]] .three = true := by decide
def e598343625846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))
theorem wire_e598343625846 : Closed e598343625846 ∧ code e598343625846 = 2797366881398 := by decide
theorem cert_e598343625846 : check e598343625846 [[],[.left],[],[.under]] .three = true := by decide
def e598343625942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e598343625942 : Closed e598343625942 ∧ code e598343625942 = 2797366881494 := by decide
theorem cert_e598343625942 : check e598343625942 [[],[.left],[],[.under]] .three = true := by decide
def e598343625946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e598343625946 : Closed e598343625946 ∧ code e598343625946 = 2797366881498 := by decide
theorem cert_e598343625946 : check e598343625946 [[],[.left],[],[.under]] .three = true := by decide
def e598343625962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e598343625962 : Closed e598343625962 ∧ code e598343625962 = 2797366881514 := by decide
theorem cert_e598343625962 : check e598343625962 [[],[.left],[],[.under]] .three = true := by decide
def e598343626038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e598343626038 : Closed e598343626038 ∧ code e598343626038 = 2797366881590 := by decide
theorem cert_e598343626038 : check e598343626038 [[],[.left],[],[.under]] .three = true := by decide
def e598343626042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e598343626042 : Closed e598343626042 ∧ code e598343626042 = 2797366881594 := by decide
theorem cert_e598343626042 : check e598343626042 [[],[.left],[],[.under]] .three = true := by decide
def e598343626126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))
theorem wire_e598343626126 : Closed e598343626126 ∧ code e598343626126 = 2797366881678 := by decide
theorem cert_e598343626126 : check e598343626126 [[],[.left],[],[.under]] .three = true := by decide
def e598343626138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e598343626138 : Closed e598343626138 ∧ code e598343626138 = 2797366881690 := by decide
theorem cert_e598343626138 : check e598343626138 [[],[.left],[],[.under]] .three = true := by decide
def e598343626294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))
theorem wire_e598343626294 : Closed e598343626294 ∧ code e598343626294 = 2797366881846 := by decide
theorem cert_e598343626294 : check e598343626294 [[],[.left],[],[.under]] .three = true := by decide
def e598343626298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))
theorem wire_e598343626298 : Closed e598343626298 ∧ code e598343626298 = 2797366881850 := by decide
theorem cert_e598343626298 : check e598343626298 [[],[.left],[],[.under]] .three = true := by decide
def e598343626346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e598343626346 : Closed e598343626346 ∧ code e598343626346 = 2797366881898 := by decide
theorem cert_e598343626346 : check e598343626346 [[],[.left],[],[.under]] .three = true := by decide
def e598343626382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))
theorem wire_e598343626382 : Closed e598343626382 ∧ code e598343626382 = 2797366881934 := by decide
theorem cert_e598343626382 : check e598343626382 [[],[.left],[],[.under]] .three = true := by decide
def e598343626394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e598343626394 : Closed e598343626394 ∧ code e598343626394 = 2797366881946 := by decide
theorem cert_e598343626394 : check e598343626394 [[],[.left],[],[.under]] .three = true := by decide
def e598343626438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))
theorem wire_e598343626438 : Closed e598343626438 ∧ code e598343626438 = 2797366881990 := by decide
theorem cert_e598343626438 : check e598343626438 [[],[.left],[],[.under]] .three = true := by decide
def e598343626990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e598343626990 : Closed e598343626990 ∧ code e598343626990 = 2797366882542 := by decide
theorem cert_e598343626990 : check e598343626990 [[],[.left],[],[.under]] .three = true := by decide
def e598343626998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e598343626998 : Closed e598343626998 ∧ code e598343626998 = 2797366882550 := by decide
theorem cert_e598343626998 : check e598343626998 [[],[.left],[],[.under]] .three = true := by decide
def e598343627478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e598343627478 : Closed e598343627478 ∧ code e598343627478 = 2797366883030 := by decide
theorem cert_e598343627478 : check e598343627478 [[],[.left],[],[.under]] .three = true := by decide
def e598343627482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e598343627482 : Closed e598343627482 ∧ code e598343627482 = 2797366883034 := by decide
theorem cert_e598343627482 : check e598343627482 [[],[.left],[],[.under]] .three = true := by decide
def e598343627498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e598343627498 : Closed e598343627498 ∧ code e598343627498 = 2797366883050 := by decide
theorem cert_e598343627498 : check e598343627498 [[],[.left],[],[.under]] .three = true := by decide
def e598343627574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e598343627574 : Closed e598343627574 ∧ code e598343627574 = 2797366883126 := by decide
theorem cert_e598343627574 : check e598343627574 [[],[.left],[],[.under]] .three = true := by decide
def e598343627578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e598343627578 : Closed e598343627578 ∧ code e598343627578 = 2797366883130 := by decide
theorem cert_e598343627578 : check e598343627578 [[],[.left],[],[.under]] .three = true := by decide
def e598343627662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e598343627662 : Closed e598343627662 ∧ code e598343627662 = 2797366883214 := by decide
theorem cert_e598343627662 : check e598343627662 [[],[.left],[],[.under]] .three = true := by decide
def e598343627674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e598343627674 : Closed e598343627674 ∧ code e598343627674 = 2797366883226 := by decide
theorem cert_e598343627674 : check e598343627674 [[],[.left],[],[.under]] .three = true := by decide
def e598343628918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e598343628918 : Closed e598343628918 ∧ code e598343628918 = 2797366884470 := by decide
theorem cert_e598343628918 : check e598343628918 [[],[.left],[],[.under]] .three = true := by decide
def e598343629162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e598343629162 : Closed e598343629162 ∧ code e598343629162 = 2797366884714 := by decide
theorem cert_e598343629162 : check e598343629162 [[],[.left],[],[.under]] .three = true := by decide
def e598343629198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e598343629198 : Closed e598343629198 ∧ code e598343629198 = 2797366884750 := by decide
theorem cert_e598343629198 : check e598343629198 [[],[.left],[],[.under]] .three = true := by decide
def e598343629210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e598343629210 : Closed e598343629210 ∧ code e598343629210 = 2797366884762 := by decide
theorem cert_e598343629210 : check e598343629210 [[],[.left],[],[.under]] .three = true := by decide
def e598343629254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e598343629254 : Closed e598343629254 ∧ code e598343629254 = 2797366884806 := by decide
theorem cert_e598343629254 : check e598343629254 [[],[.left],[],[.under]] .three = true := by decide
def e598345526714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e598345526714 : Closed e598345526714 ∧ code e598345526714 = 2797368782266 := by decide
def e598345526746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e598345526746 : Closed e598345526746 ∧ code e598345526746 = 2797368782298 := by decide
def e598345526970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e598345526970 : Closed e598345526970 ∧ code e598345526970 = 2797368782522 := by decide
def e598345527018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e598345527018 : Closed e598345527018 ∧ code e598345527018 = 2797368782570 := by decide
def e598345527130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e598345527130 : Closed e598345527130 ∧ code e598345527130 = 2797368782682 := by decide
def e598345527146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e598345527146 : Closed e598345527146 ∧ code e598345527146 = 2797368782698 := by decide
def e598345528250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e598345528250 : Closed e598345528250 ∧ code e598345528250 = 2797368783802 := by decide
def e598345528282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e598345528282 : Closed e598345528282 ∧ code e598345528282 = 2797368783834 := by decide
end Blc.Floor41
