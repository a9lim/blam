import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e601551067162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601551067162 : Closed e601551067162 ∧ code e601551067162 = 2800574322714 := by decide
theorem cert_e601551067162 : check e601551067162 [[]] .width = true := by decide
def e601551071258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601551071258 : Closed e601551071258 ∧ code e601551071258 = 2800574326810 := by decide
theorem cert_e601551071258 : check e601551071258 [[]] .width = true := by decide
def e601765227886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e601765227886 : Closed e601765227886 ∧ code e601765227886 = 2800788483438 := by decide
theorem cert_e601765227886 : check e601765227886 [[],[]] .smaller = true := by decide
def e601765227894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e601765227894 : Closed e601765227894 ∧ code e601765227894 = 2800788483446 := by decide
theorem cert_e601765227894 : check e601765227894 [[],[]] .smaller = true := by decide
def e601765227950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e601765227950 : Closed e601765227950 ∧ code e601765227950 = 2800788483502 := by decide
theorem cert_e601765227950 : check e601765227950 [[],[]] .smaller = true := by decide
def e601765227962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e601765227962 : Closed e601765227962 ∧ code e601765227962 = 2800788483514 := by decide
theorem cert_e601765227962 : check e601765227962 [[],[]] .smaller = true := by decide
def e601765227990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e601765227990 : Closed e601765227990 ∧ code e601765227990 = 2800788483542 := by decide
theorem cert_e601765227990 : check e601765227990 [[],[]] .smaller = true := by decide
def e601765227994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e601765227994 : Closed e601765227994 ∧ code e601765227994 = 2800788483546 := by decide
theorem cert_e601765227994 : check e601765227994 [[],[]] .smaller = true := by decide
def e601765228206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e601765228206 : Closed e601765228206 ∧ code e601765228206 = 2800788483758 := by decide
theorem cert_e601765228206 : check e601765228206 [[],[]] .smaller = true := by decide
def e601765228218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e601765228218 : Closed e601765228218 ∧ code e601765228218 = 2800788483770 := by decide
theorem cert_e601765228218 : check e601765228218 [[],[]] .smaller = true := by decide
def e601765228266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e601765228266 : Closed e601765228266 ∧ code e601765228266 = 2800788483818 := by decide
theorem cert_e601765228266 : check e601765228266 [[],[]] .smaller = true := by decide
def e601765228374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e601765228374 : Closed e601765228374 ∧ code e601765228374 = 2800788483926 := by decide
theorem cert_e601765228374 : check e601765228374 [[],[]] .smaller = true := by decide
def e601765228378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e601765228378 : Closed e601765228378 ∧ code e601765228378 = 2800788483930 := by decide
theorem cert_e601765228378 : check e601765228378 [[],[]] .smaller = true := by decide
def e601765228394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e601765228394 : Closed e601765228394 ∧ code e601765228394 = 2800788483946 := by decide
theorem cert_e601765228394 : check e601765228394 [[],[]] .smaller = true := by decide
def e601765229422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e601765229422 : Closed e601765229422 ∧ code e601765229422 = 2800788484974 := by decide
theorem cert_e601765229422 : check e601765229422 [[],[]] .smaller = true := by decide
def e601765229430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e601765229430 : Closed e601765229430 ∧ code e601765229430 = 2800788484982 := by decide
theorem cert_e601765229430 : check e601765229430 [[],[]] .smaller = true := by decide
def e601765229486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e601765229486 : Closed e601765229486 ∧ code e601765229486 = 2800788485038 := by decide
theorem cert_e601765229486 : check e601765229486 [[],[]] .smaller = true := by decide
def e601765229498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e601765229498 : Closed e601765229498 ∧ code e601765229498 = 2800788485050 := by decide
theorem cert_e601765229498 : check e601765229498 [[],[]] .smaller = true := by decide
def e601765229526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e601765229526 : Closed e601765229526 ∧ code e601765229526 = 2800788485078 := by decide
theorem cert_e601765229526 : check e601765229526 [[],[]] .smaller = true := by decide
def e601765229530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e601765229530 : Closed e601765229530 ∧ code e601765229530 = 2800788485082 := by decide
theorem cert_e601765229530 : check e601765229530 [[],[]] .smaller = true := by decide
def e601765229806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e601765229806 : Closed e601765229806 ∧ code e601765229806 = 2800788485358 := by decide
theorem cert_e601765229806 : check e601765229806 [[],[]] .smaller = true := by decide
def e601765229814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e601765229814 : Closed e601765229814 ∧ code e601765229814 = 2800788485366 := by decide
theorem cert_e601765229814 : check e601765229814 [[],[]] .smaller = true := by decide
def e601765230190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e601765230190 : Closed e601765230190 ∧ code e601765230190 = 2800788485742 := by decide
theorem cert_e601765230190 : check e601765230190 [[],[]] .smaller = true := by decide
def e601765230202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e601765230202 : Closed e601765230202 ∧ code e601765230202 = 2800788485754 := by decide
theorem cert_e601765230202 : check e601765230202 [[],[]] .smaller = true := by decide
def e601765230390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e601765230390 : Closed e601765230390 ∧ code e601765230390 = 2800788485942 := by decide
theorem cert_e601765230390 : check e601765230390 [[],[]] .smaller = true := by decide
def e601765230394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e601765230394 : Closed e601765230394 ∧ code e601765230394 = 2800788485946 := by decide
theorem cert_e601765230394 : check e601765230394 [[],[]] .smaller = true := by decide
def e601765231022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e601765231022 : Closed e601765231022 ∧ code e601765231022 = 2800788486574 := by decide
theorem cert_e601765231022 : check e601765231022 [[],[]] .smaller = true := by decide
def e601765231034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e601765231034 : Closed e601765231034 ∧ code e601765231034 = 2800788486586 := by decide
theorem cert_e601765231034 : check e601765231034 [[],[]] .smaller = true := by decide
def e601765231082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e601765231082 : Closed e601765231082 ∧ code e601765231082 = 2800788486634 := by decide
theorem cert_e601765231082 : check e601765231082 [[],[]] .smaller = true := by decide
def e601765231214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e601765231214 : Closed e601765231214 ∧ code e601765231214 = 2800788486766 := by decide
theorem cert_e601765231214 : check e601765231214 [[],[]] .smaller = true := by decide
def e601765231226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e601765231226 : Closed e601765231226 ∧ code e601765231226 = 2800788486778 := by decide
theorem cert_e601765231226 : check e601765231226 [[],[]] .smaller = true := by decide
def e601765231514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e601765231514 : Closed e601765231514 ∧ code e601765231514 = 2800788487066 := by decide
theorem cert_e601765231514 : check e601765231514 [[],[]] .smaller = true := by decide
def e601765231830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e601765231830 : Closed e601765231830 ∧ code e601765231830 = 2800788487382 := by decide
theorem cert_e601765231830 : check e601765231830 [[],[]] .smaller = true := by decide
def e601765231834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e601765231834 : Closed e601765231834 ∧ code e601765231834 = 2800788487386 := by decide
theorem cert_e601765231834 : check e601765231834 [[],[]] .smaller = true := by decide
def e601765231850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e601765231850 : Closed e601765231850 ∧ code e601765231850 = 2800788487402 := by decide
theorem cert_e601765231850 : check e601765231850 [[],[]] .smaller = true := by decide
def e601765231926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e601765231926 : Closed e601765231926 ∧ code e601765231926 = 2800788487478 := by decide
theorem cert_e601765231926 : check e601765231926 [[],[]] .smaller = true := by decide
def e601765231930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e601765231930 : Closed e601765231930 ∧ code e601765231930 = 2800788487482 := by decide
theorem cert_e601765231930 : check e601765231930 [[],[]] .smaller = true := by decide
def e601765232026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e601765232026 : Closed e601765232026 ∧ code e601765232026 = 2800788487578 := by decide
theorem cert_e601765232026 : check e601765232026 [[],[]] .smaller = true := by decide
def e601765235566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e601765235566 : Closed e601765235566 ∧ code e601765235566 = 2800788491118 := by decide
theorem cert_e601765235566 : check e601765235566 [[],[]] .smaller = true := by decide
def e601765235574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e601765235574 : Closed e601765235574 ∧ code e601765235574 = 2800788491126 := by decide
theorem cert_e601765235574 : check e601765235574 [[],[]] .smaller = true := by decide
def e601765235630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e601765235630 : Closed e601765235630 ∧ code e601765235630 = 2800788491182 := by decide
theorem cert_e601765235630 : check e601765235630 [[],[]] .smaller = true := by decide
def e601765235642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e601765235642 : Closed e601765235642 ∧ code e601765235642 = 2800788491194 := by decide
theorem cert_e601765235642 : check e601765235642 [[],[]] .smaller = true := by decide
def e601765235670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e601765235670 : Closed e601765235670 ∧ code e601765235670 = 2800788491222 := by decide
theorem cert_e601765235670 : check e601765235670 [[],[]] .smaller = true := by decide
def e601765235674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e601765235674 : Closed e601765235674 ∧ code e601765235674 = 2800788491226 := by decide
theorem cert_e601765235674 : check e601765235674 [[],[]] .smaller = true := by decide
def e601765235950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e601765235950 : Closed e601765235950 ∧ code e601765235950 = 2800788491502 := by decide
theorem cert_e601765235950 : check e601765235950 [[],[]] .smaller = true := by decide
def e601765235958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e601765235958 : Closed e601765235958 ∧ code e601765235958 = 2800788491510 := by decide
theorem cert_e601765235958 : check e601765235958 [[],[]] .smaller = true := by decide
def e601765236334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e601765236334 : Closed e601765236334 ∧ code e601765236334 = 2800788491886 := by decide
theorem cert_e601765236334 : check e601765236334 [[],[]] .smaller = true := by decide
def e601765236346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e601765236346 : Closed e601765236346 ∧ code e601765236346 = 2800788491898 := by decide
theorem cert_e601765236346 : check e601765236346 [[],[]] .smaller = true := by decide
def e601765236534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e601765236534 : Closed e601765236534 ∧ code e601765236534 = 2800788492086 := by decide
theorem cert_e601765236534 : check e601765236534 [[],[]] .smaller = true := by decide
def e601765236538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e601765236538 : Closed e601765236538 ∧ code e601765236538 = 2800788492090 := by decide
theorem cert_e601765236538 : check e601765236538 [[],[]] .smaller = true := by decide
def e601765242286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e601765242286 : Closed e601765242286 ∧ code e601765242286 = 2800788497838 := by decide
theorem cert_e601765242286 : check e601765242286 [[],[]] .smaller = true := by decide
def e601765242298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e601765242298 : Closed e601765242298 ∧ code e601765242298 = 2800788497850 := by decide
theorem cert_e601765242298 : check e601765242298 [[],[]] .smaller = true := by decide
def e601765242346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e601765242346 : Closed e601765242346 ∧ code e601765242346 = 2800788497898 := by decide
theorem cert_e601765242346 : check e601765242346 [[],[]] .smaller = true := by decide
def e601765242478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e601765242478 : Closed e601765242478 ∧ code e601765242478 = 2800788498030 := by decide
theorem cert_e601765242478 : check e601765242478 [[],[]] .smaller = true := by decide
def e601765242490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e601765242490 : Closed e601765242490 ∧ code e601765242490 = 2800788498042 := by decide
theorem cert_e601765242490 : check e601765242490 [[],[]] .smaller = true := by decide
def e601765242778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e601765242778 : Closed e601765242778 ∧ code e601765242778 = 2800788498330 := by decide
theorem cert_e601765242778 : check e601765242778 [[],[]] .smaller = true := by decide
def e601765245654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e601765245654 : Closed e601765245654 ∧ code e601765245654 = 2800788501206 := by decide
theorem cert_e601765245654 : check e601765245654 [[],[]] .smaller = true := by decide
def e601765245658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e601765245658 : Closed e601765245658 ∧ code e601765245658 = 2800788501210 := by decide
theorem cert_e601765245658 : check e601765245658 [[],[]] .smaller = true := by decide
def e601765245674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e601765245674 : Closed e601765245674 ∧ code e601765245674 = 2800788501226 := by decide
theorem cert_e601765245674 : check e601765245674 [[],[]] .smaller = true := by decide
def e601765245750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e601765245750 : Closed e601765245750 ∧ code e601765245750 = 2800788501302 := by decide
theorem cert_e601765245750 : check e601765245750 [[],[]] .smaller = true := by decide
def e601765245754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e601765245754 : Closed e601765245754 ∧ code e601765245754 = 2800788501306 := by decide
theorem cert_e601765245754 : check e601765245754 [[],[]] .smaller = true := by decide
def e601765245850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e601765245850 : Closed e601765245850 ∧ code e601765245850 = 2800788501402 := by decide
theorem cert_e601765245850 : check e601765245850 [[],[]] .smaller = true := by decide
def e601765361390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e601765361390 : Closed e601765361390 ∧ code e601765361390 = 2800788616942 := by decide
theorem cert_e601765361390 : check e601765361390 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e601765361518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e601765361518 : Closed e601765361518 ∧ code e601765361518 = 2800788617070 := by decide
theorem cert_e601765361518 : check e601765361518 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e601765361526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e601765361526 : Closed e601765361526 ∧ code e601765361526 = 2800788617078 := by decide
theorem cert_e601765361526 : check e601765361526 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e601765362414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e601765362414 : Closed e601765362414 ∧ code e601765362414 = 2800788617966 := by decide
theorem cert_e601765362414 : check e601765362414 [[],[]] .sourceHead = true := by decide
def e601765362606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e601765362606 : Closed e601765362606 ∧ code e601765362606 = 2800788618158 := by decide
theorem cert_e601765362606 : check e601765362606 [[],[]] .sourceHead = true := by decide
def e601765362618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e601765362618 : Closed e601765362618 ∧ code e601765362618 = 2800788618170 := by decide
theorem cert_e601765362618 : check e601765362618 [[],[]] .sourceHead = true := by decide
def e601765363054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e601765363054 : Closed e601765363054 ∧ code e601765363054 = 2800788618606 := by decide
theorem cert_e601765363054 : check e601765363054 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e601765363062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e601765363062 : Closed e601765363062 ∧ code e601765363062 = 2800788618614 := by decide
theorem cert_e601765363062 : check e601765363062 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .smaller = true := by decide
def e601765363118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e601765363118 : Closed e601765363118 ∧ code e601765363118 = 2800788618670 := by decide
theorem cert_e601765363118 : check e601765363118 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e601765363130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e601765363130 : Closed e601765363130 ∧ code e601765363130 = 2800788618682 := by decide
theorem cert_e601765363130 : check e601765363130 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .smaller = true := by decide
def e601765363158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e601765363158 : Closed e601765363158 ∧ code e601765363158 = 2800788618710 := by decide
theorem cert_e601765363158 : check e601765363158 [[],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e601765363162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e601765363162 : Closed e601765363162 ∧ code e601765363162 = 2800788618714 := by decide
theorem cert_e601765363162 : check e601765363162 [[],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e601765367534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e601765367534 : Closed e601765367534 ∧ code e601765367534 = 2800788623086 := by decide
theorem cert_e601765367534 : check e601765367534 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e601765367662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e601765367662 : Closed e601765367662 ∧ code e601765367662 = 2800788623214 := by decide
theorem cert_e601765367662 : check e601765367662 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e601765367670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e601765367670 : Closed e601765367670 ∧ code e601765367670 = 2800788623222 := by decide
theorem cert_e601765367670 : check e601765367670 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e601765370350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e601765370350 : Closed e601765370350 ∧ code e601765370350 = 2800788625902 := by decide
theorem cert_e601765370350 : check e601765370350 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e601765371118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e601765371118 : Closed e601765371118 ∧ code e601765371118 = 2800788626670 := by decide
theorem cert_e601765371118 : check e601765371118 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e601765371126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e601765371126 : Closed e601765371126 ∧ code e601765371126 = 2800788626678 := by decide
theorem cert_e601765371126 : check e601765371126 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e601765373678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e601765373678 : Closed e601765373678 ∧ code e601765373678 = 2800788629230 := by decide
theorem cert_e601765373678 : checkPay e601765373678 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e601765373870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e601765373870 : Closed e601765373870 ∧ code e601765373870 = 2800788629422 := by decide
theorem cert_e601765373870 : checkPay e601765373870 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e601765373882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e601765373882 : Closed e601765373882 ∧ code e601765373882 = 2800788629434 := by decide
theorem cert_e601765373882 : checkPay e601765373882 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e601765374446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e601765374446 : Closed e601765374446 ∧ code e601765374446 = 2800788629998 := by decide
theorem cert_e601765374446 : checkPay e601765374446 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e601765375598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e601765375598 : Closed e601765375598 ∧ code e601765375598 = 2800788631150 := by decide
theorem cert_e601765375598 : checkPay e601765375598 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e601765375610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e601765375610 : Closed e601765375610 ∧ code e601765375610 = 2800788631162 := by decide
theorem cert_e601765375610 : checkPay e601765375610 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e601765376878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e601765376878 : Closed e601765376878 ∧ code e601765376878 = 2800788632430 := by decide
theorem cert_e601765376878 : check e601765376878 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e601765376886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e601765376886 : Closed e601765376886 ∧ code e601765376886 = 2800788632438 := by decide
theorem cert_e601765376886 : check e601765376886 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e601765376942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e601765376942 : Closed e601765376942 ∧ code e601765376942 = 2800788632494 := by decide
theorem cert_e601765376942 : check e601765376942 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e601765376954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e601765376954 : Closed e601765376954 ∧ code e601765376954 = 2800788632506 := by decide
theorem cert_e601765376954 : check e601765376954 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e601765376982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e601765376982 : Closed e601765376982 ∧ code e601765376982 = 2800788632534 := by decide
theorem cert_e601765376982 : check e601765376982 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e601765376986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e601765376986 : Closed e601765376986 ∧ code e601765376986 = 2800788632538 := by decide
theorem cert_e601765376986 : check e601765376986 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e601765377262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e601765377262 : Closed e601765377262 ∧ code e601765377262 = 2800788632814 := by decide
theorem cert_e601765377262 : check e601765377262 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e601765377270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e601765377270 : Closed e601765377270 ∧ code e601765377270 = 2800788632822 := by decide
theorem cert_e601765377270 : check e601765377270 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e601765377646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e601765377646 : Closed e601765377646 ∧ code e601765377646 = 2800788633198 := by decide
theorem cert_e601765377646 : check e601765377646 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e601765377658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e601765377658 : Closed e601765377658 ∧ code e601765377658 = 2800788633210 := by decide
theorem cert_e601765377658 : check e601765377658 [[],[],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e601765377846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e601765377846 : Closed e601765377846 ∧ code e601765377846 = 2800788633398 := by decide
theorem cert_e601765377846 : check e601765377846 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e601765377850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e601765377850 : Closed e601765377850 ∧ code e601765377850 = 2800788633402 := by decide
theorem cert_e601765377850 : check e601765377850 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e601765383022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e601765383022 : Closed e601765383022 ∧ code e601765383022 = 2800788638574 := by decide
theorem cert_e601765383022 : check e601765383022 [[],[]] .smaller = true := by decide
def e601765383030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e601765383030 : Closed e601765383030 ∧ code e601765383030 = 2800788638582 := by decide
theorem cert_e601765383030 : check e601765383030 [[],[]] .smaller = true := by decide
def e601765383086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e601765383086 : Closed e601765383086 ∧ code e601765383086 = 2800788638638 := by decide
theorem cert_e601765383086 : check e601765383086 [[],[]] .smaller = true := by decide
def e601765383098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e601765383098 : Closed e601765383098 ∧ code e601765383098 = 2800788638650 := by decide
theorem cert_e601765383098 : check e601765383098 [[],[]] .smaller = true := by decide
def e601765383126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e601765383126 : Closed e601765383126 ∧ code e601765383126 = 2800788638678 := by decide
theorem cert_e601765383126 : check e601765383126 [[],[]] .smaller = true := by decide
def e601765383130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e601765383130 : Closed e601765383130 ∧ code e601765383130 = 2800788638682 := by decide
theorem cert_e601765383130 : check e601765383130 [[],[]] .smaller = true := by decide
def e601765383406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e601765383406 : Closed e601765383406 ∧ code e601765383406 = 2800788638958 := by decide
theorem cert_e601765383406 : check e601765383406 [[],[]] .smaller = true := by decide
def e601765383414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e601765383414 : Closed e601765383414 ∧ code e601765383414 = 2800788638966 := by decide
theorem cert_e601765383414 : check e601765383414 [[],[]] .smaller = true := by decide
def e601765383790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e601765383790 : Closed e601765383790 ∧ code e601765383790 = 2800788639342 := by decide
theorem cert_e601765383790 : check e601765383790 [[],[]] .smaller = true := by decide
def e601765383802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e601765383802 : Closed e601765383802 ∧ code e601765383802 = 2800788639354 := by decide
theorem cert_e601765383802 : check e601765383802 [[],[]] .smaller = true := by decide
def e601765383990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e601765383990 : Closed e601765383990 ∧ code e601765383990 = 2800788639542 := by decide
theorem cert_e601765383990 : check e601765383990 [[],[]] .smaller = true := by decide
def e601765383994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e601765383994 : Closed e601765383994 ∧ code e601765383994 = 2800788639546 := by decide
theorem cert_e601765383994 : check e601765383994 [[],[]] .smaller = true := by decide
def e601765392110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e601765392110 : Closed e601765392110 ∧ code e601765392110 = 2800788647662 := by decide
theorem cert_e601765392110 : check e601765392110 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e601765392238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e601765392238 : Closed e601765392238 ∧ code e601765392238 = 2800788647790 := by decide
theorem cert_e601765392238 : check e601765392238 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e601765392246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e601765392246 : Closed e601765392246 ∧ code e601765392246 = 2800788647798 := by decide
theorem cert_e601765392246 : check e601765392246 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e601765394926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e601765394926 : Closed e601765394926 ∧ code e601765394926 = 2800788650478 := by decide
theorem cert_e601765394926 : check e601765394926 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e601765395694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e601765395694 : Closed e601765395694 ∧ code e601765395694 = 2800788651246 := by decide
theorem cert_e601765395694 : check e601765395694 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e601765395702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e601765395702 : Closed e601765395702 ∧ code e601765395702 = 2800788651254 := by decide
theorem cert_e601765395702 : check e601765395702 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e601765418734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e601765418734 : Closed e601765418734 ∧ code e601765418734 = 2800788674286 := by decide
theorem cert_e601765418734 : check e601765418734 [[],[]] .sourceHead = true := by decide
def e601765418926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e601765418926 : Closed e601765418926 ∧ code e601765418926 = 2800788674478 := by decide
theorem cert_e601765418926 : check e601765418926 [[],[]] .sourceHead = true := by decide
def e601765418938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e601765418938 : Closed e601765418938 ∧ code e601765418938 = 2800788674490 := by decide
theorem cert_e601765418938 : check e601765418938 [[],[]] .sourceHead = true := by decide
def e601765419502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e601765419502 : Closed e601765419502 ∧ code e601765419502 = 2800788675054 := by decide
theorem cert_e601765419502 : check e601765419502 [[],[]] .sourceHead = true := by decide
def e601765420654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e601765420654 : Closed e601765420654 ∧ code e601765420654 = 2800788676206 := by decide
theorem cert_e601765420654 : check e601765420654 [[],[]] .sourceHead = true := by decide
def e601765420666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e601765420666 : Closed e601765420666 ∧ code e601765420666 = 2800788676218 := by decide
theorem cert_e601765420666 : check e601765420666 [[],[]] .sourceHead = true := by decide
def e601765432174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e601765432174 : Closed e601765432174 ∧ code e601765432174 = 2800788687726 := by decide
theorem cert_e601765432174 : check e601765432174 [[],[],[.under,.under]] .smaller = true := by decide
def e601765432182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e601765432182 : Closed e601765432182 ∧ code e601765432182 = 2800788687734 := by decide
theorem cert_e601765432182 : check e601765432182 [[],[],[.under,.under]] .smaller = true := by decide
def e601765432238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e601765432238 : Closed e601765432238 ∧ code e601765432238 = 2800788687790 := by decide
theorem cert_e601765432238 : check e601765432238 [[],[],[.under,.under]] .smaller = true := by decide
def e601765432250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e601765432250 : Closed e601765432250 ∧ code e601765432250 = 2800788687802 := by decide
theorem cert_e601765432250 : check e601765432250 [[],[],[.under,.under]] .smaller = true := by decide
def e601765432278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e601765432278 : Closed e601765432278 ∧ code e601765432278 = 2800788687830 := by decide
theorem cert_e601765432278 : check e601765432278 [[],[],[.under,.under]] .smaller = true := by decide
def e601765432282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e601765432282 : Closed e601765432282 ∧ code e601765432282 = 2800788687834 := by decide
theorem cert_e601765432282 : check e601765432282 [[],[],[.under,.under]] .smaller = true := by decide
def e601765432558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e601765432558 : Closed e601765432558 ∧ code e601765432558 = 2800788688110 := by decide
theorem cert_e601765432558 : check e601765432558 [[],[],[.under,.under]] .smaller = true := by decide
def e601765432566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e601765432566 : Closed e601765432566 ∧ code e601765432566 = 2800788688118 := by decide
theorem cert_e601765432566 : check e601765432566 [[],[],[.under,.under]] .smaller = true := by decide
def e601765432942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e601765432942 : Closed e601765432942 ∧ code e601765432942 = 2800788688494 := by decide
theorem cert_e601765432942 : check e601765432942 [[],[],[.under,.under]] .smaller = true := by decide
def e601765432954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e601765432954 : Closed e601765432954 ∧ code e601765432954 = 2800788688506 := by decide
theorem cert_e601765432954 : check e601765432954 [[],[],[.under,.under]] .smaller = true := by decide
def e601765433142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e601765433142 : Closed e601765433142 ∧ code e601765433142 = 2800788688694 := by decide
theorem cert_e601765433142 : check e601765433142 [[],[],[.under,.under]] .smaller = true := by decide
def e601765433146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e601765433146 : Closed e601765433146 ∧ code e601765433146 = 2800788688698 := by decide
theorem cert_e601765433146 : check e601765433146 [[],[],[.under,.under]] .smaller = true := by decide
def e601765972846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e601765972846 : Closed e601765972846 ∧ code e601765972846 = 2800789228398 := by decide
theorem cert_e601765972846 : check e601765972846 [[],[]] .smaller = true := by decide
def e601765972854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e601765972854 : Closed e601765972854 ∧ code e601765972854 = 2800789228406 := by decide
theorem cert_e601765972854 : check e601765972854 [[],[]] .smaller = true := by decide
def e601765972910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e601765972910 : Closed e601765972910 ∧ code e601765972910 = 2800789228462 := by decide
theorem cert_e601765972910 : check e601765972910 [[],[]] .smaller = true := by decide
def e601765972922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e601765972922 : Closed e601765972922 ∧ code e601765972922 = 2800789228474 := by decide
theorem cert_e601765972922 : check e601765972922 [[],[]] .smaller = true := by decide
def e601765972950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e601765972950 : Closed e601765972950 ∧ code e601765972950 = 2800789228502 := by decide
theorem cert_e601765972950 : check e601765972950 [[],[]] .smaller = true := by decide
def e601765972954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e601765972954 : Closed e601765972954 ∧ code e601765972954 = 2800789228506 := by decide
theorem cert_e601765972954 : check e601765972954 [[],[]] .smaller = true := by decide
def e601765973230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e601765973230 : Closed e601765973230 ∧ code e601765973230 = 2800789228782 := by decide
theorem cert_e601765973230 : check e601765973230 [[],[]] .smaller = true := by decide
def e601765973238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e601765973238 : Closed e601765973238 ∧ code e601765973238 = 2800789228790 := by decide
theorem cert_e601765973238 : check e601765973238 [[],[]] .smaller = true := by decide
def e601765973614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e601765973614 : Closed e601765973614 ∧ code e601765973614 = 2800789229166 := by decide
theorem cert_e601765973614 : check e601765973614 [[],[]] .smaller = true := by decide
def e601765973626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e601765973626 : Closed e601765973626 ∧ code e601765973626 = 2800789229178 := by decide
theorem cert_e601765973626 : check e601765973626 [[],[]] .smaller = true := by decide
def e601765973814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e601765973814 : Closed e601765973814 ∧ code e601765973814 = 2800789229366 := by decide
theorem cert_e601765973814 : check e601765973814 [[],[]] .smaller = true := by decide
def e601765973818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e601765973818 : Closed e601765973818 ∧ code e601765973818 = 2800789229370 := by decide
theorem cert_e601765973818 : check e601765973818 [[],[]] .smaller = true := by decide
def e602112712730 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602112712730 : Closed e602112712730 ∧ code e602112712730 = 2801135968282 := by decide
theorem cert_e602112712730 : check e602112712730 [[]] .width = true := by decide
def e602112712822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e602112712822 : Closed e602112712822 ∧ code e602112712822 = 2801135968374 := by decide
private def t_e602112712822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e602112712822 : ¬ IsSelfInterpreter e602112712822 :=
  wSource (t := t_e602112712822) (replay_sound (ps := []) (t := e602112712822) (by decide)) (by decide)
def e602112713066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e602112713066 : Closed e602112713066 ∧ code e602112713066 = 2801135968618 := by decide
private def t_e602112713066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e602112713066 : ¬ IsSelfInterpreter e602112713066 :=
  wSource (t := t_e602112713066) (replay_sound (ps := []) (t := e602112713066) (by decide)) (by decide)
def e602112713114 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e602112713114 : Closed e602112713114 ∧ code e602112713114 = 2801135968666 := by decide
private def t_e602112713114 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e602112713114 : ¬ IsSelfInterpreter e602112713114 :=
  wSource (t := t_e602112713114) (replay_sound (ps := []) (t := e602112713114) (by decide)) (by decide)
def e602112745498 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602112745498 : Closed e602112745498 ∧ code e602112745498 = 2801136001050 := by decide
theorem cert_e602112745498 : check e602112745498 [[]] .width = true := by decide
def e602112745590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e602112745590 : Closed e602112745590 ∧ code e602112745590 = 2801136001142 := by decide
private def t_e602112745590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e602112745590 : ¬ IsSelfInterpreter e602112745590 :=
  wSource (t := t_e602112745590) (replay_sound (ps := []) (t := e602112745590) (by decide)) (by decide)
def e602112745834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e602112745834 : Closed e602112745834 ∧ code e602112745834 = 2801136001386 := by decide
private def t_e602112745834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e602112745834 : ¬ IsSelfInterpreter e602112745834 :=
  wSource (t := t_e602112745834) (replay_sound (ps := []) (t := e602112745834) (by decide)) (by decide)
def e602112745882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e602112745882 : Closed e602112745882 ∧ code e602112745882 = 2801136001434 := by decide
private def t_e602112745882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e602112745882 : ¬ IsSelfInterpreter e602112745882 :=
  wSource (t := t_e602112745882) (replay_sound (ps := []) (t := e602112745882) (by decide)) (by decide)
def e602112974874 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602112974874 : Closed e602112974874 ∧ code e602112974874 = 2801136230426 := by decide
theorem cert_e602112974874 : check e602112974874 [[]] .width = true := by decide
def e602112974966 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e602112974966 : Closed e602112974966 ∧ code e602112974966 = 2801136230518 := by decide
private def t_e602112974966 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e602112974966 : ¬ IsSelfInterpreter e602112974966 :=
  wSource (t := t_e602112974966) (replay_sound (ps := []) (t := e602112974966) (by decide)) (by decide)
def e602112975210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e602112975210 : Closed e602112975210 ∧ code e602112975210 = 2801136230762 := by decide
private def t_e602112975210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e602112975210 : ¬ IsSelfInterpreter e602112975210 :=
  wSource (t := t_e602112975210) (replay_sound (ps := []) (t := e602112975210) (by decide)) (by decide)
def e602112975258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e602112975258 : Closed e602112975258 ∧ code e602112975258 = 2801136230810 := by decide
private def t_e602112975258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e602112975258 : ¬ IsSelfInterpreter e602112975258 :=
  wSource (t := t_e602112975258) (replay_sound (ps := []) (t := e602112975258) (by decide)) (by decide)
def e602113024026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602113024026 : Closed e602113024026 ∧ code e602113024026 = 2801136279578 := by decide
theorem cert_e602113024026 : check e602113024026 [[]] .width = true := by decide
def e602113024118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e602113024118 : Closed e602113024118 ∧ code e602113024118 = 2801136279670 := by decide
private def t_e602113024118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e602113024118 : ¬ IsSelfInterpreter e602113024118 :=
  wSource (t := t_e602113024118) (replay_sound (ps := []) (t := e602113024118) (by decide)) (by decide)
end Blc.Floor41
