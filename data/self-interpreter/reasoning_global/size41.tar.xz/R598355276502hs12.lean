import Indexed
namespace Certgen.R598355276502
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def hs240 : Array (List Nat) := #[[61,67],[62,68],[63,69],[60,66],[61,67],[62,68],[63,69],[64,70],[65,71],[148,153],[149,154],[150,155],[151,156],[152,157],[148,153],[149,154],[150,155],[151,156],[152,157]]
end Certgen.R598355276502
