import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e602907535162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e602907535162 : Closed e602907535162 ∧ code e602907535162 = 2801930790714 := by decide
theorem cert_e602907535162 : check e602907535162 [[],[]] .chain = true := by decide
def e602907535246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e602907535246 : Closed e602907535246 ∧ code e602907535246 = 2801930790798 := by decide
theorem cert_e602907535246 : check e602907535246 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602907545326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e602907545326 : Closed e602907545326 ∧ code e602907545326 = 2801930800878 := by decide
theorem cert_e602907545326 : check e602907545326 [[],[]] .chain = true := by decide
def e602907545334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e602907545334 : Closed e602907545334 ∧ code e602907545334 = 2801930800886 := by decide
theorem cert_e602907545334 : check e602907545334 [[],[]] .chain = true := by decide
def e602907545454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e602907545454 : Closed e602907545454 ∧ code e602907545454 = 2801930801006 := by decide
theorem cert_e602907545454 : check e602907545454 [[],[]] .chain = true := by decide
def e602907545466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e602907545466 : Closed e602907545466 ∧ code e602907545466 = 2801930801018 := by decide
theorem cert_e602907545466 : check e602907545466 [[],[]] .chain = true := by decide
def e602907545526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e602907545526 : Closed e602907545526 ∧ code e602907545526 = 2801930801078 := by decide
theorem cert_e602907545526 : check e602907545526 [[],[]] .chain = true := by decide
def e602907545530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e602907545530 : Closed e602907545530 ∧ code e602907545530 = 2801930801082 := by decide
theorem cert_e602907545530 : check e602907545530 [[],[]] .chain = true := by decide
def e602907548142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e602907548142 : Closed e602907548142 ∧ code e602907548142 = 2801930803694 := by decide
theorem cert_e602907548142 : checkPay e602907548142 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e602907549294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2)))))))
theorem wire_e602907549294 : Closed e602907549294 ∧ code e602907549294 = 2801930804846 := by decide
theorem cert_e602907549294 : checkPay e602907549294 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e602907549306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0)))))))
theorem wire_e602907549306 : Closed e602907549306 ∧ code e602907549306 = 2801930804858 := by decide
theorem cert_e602907549306 : checkPay e602907549306 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e602907553134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e602907553134 : Closed e602907553134 ∧ code e602907553134 = 2801930808686 := by decide
theorem cert_e602907553134 : check e602907553134 [[],[]] .chain = true := by decide
def e602907553142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e602907553142 : Closed e602907553142 ∧ code e602907553142 = 2801930808694 := by decide
theorem cert_e602907553142 : check e602907553142 [[],[]] .chain = true := by decide
def e602907553198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e602907553198 : Closed e602907553198 ∧ code e602907553198 = 2801930808750 := by decide
theorem cert_e602907553198 : check e602907553198 [[],[]] .chain = true := by decide
def e602907553210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e602907553210 : Closed e602907553210 ∧ code e602907553210 = 2801930808762 := by decide
theorem cert_e602907553210 : check e602907553210 [[],[]] .chain = true := by decide
def e602907553238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e602907553238 : Closed e602907553238 ∧ code e602907553238 = 2801930808790 := by decide
theorem cert_e602907553238 : check e602907553238 [[],[]] .chain = true := by decide
def e602907553242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e602907553242 : Closed e602907553242 ∧ code e602907553242 = 2801930808794 := by decide
theorem cert_e602907553242 : check e602907553242 [[],[]] .chain = true := by decide
def e602907553454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e602907553454 : Closed e602907553454 ∧ code e602907553454 = 2801930809006 := by decide
theorem cert_e602907553454 : check e602907553454 [[],[]] .chain = true := by decide
def e602907553466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e602907553466 : Closed e602907553466 ∧ code e602907553466 = 2801930809018 := by decide
theorem cert_e602907553466 : check e602907553466 [[],[]] .chain = true := by decide
def e602907553514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e602907553514 : Closed e602907553514 ∧ code e602907553514 = 2801930809066 := by decide
theorem cert_e602907553514 : check e602907553514 [[],[]] .chain = true := by decide
def e602907553622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e602907553622 : Closed e602907553622 ∧ code e602907553622 = 2801930809174 := by decide
theorem cert_e602907553622 : check e602907553622 [[],[]] .chain = true := by decide
def e602907553626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e602907553626 : Closed e602907553626 ∧ code e602907553626 = 2801930809178 := by decide
theorem cert_e602907553626 : check e602907553626 [[],[]] .chain = true := by decide
def e602907553642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e602907553642 : Closed e602907553642 ∧ code e602907553642 = 2801930809194 := by decide
theorem cert_e602907553642 : check e602907553642 [[],[]] .chain = true := by decide
def e602907554286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2))))))
theorem wire_e602907554286 : Closed e602907554286 ∧ code e602907554286 = 2801930809838 := by decide
theorem cert_e602907554286 : checkPay e602907554286 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e602907554670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e602907554670 : Closed e602907554670 ∧ code e602907554670 = 2801930810222 := by decide
theorem cert_e602907554670 : check e602907554670 [[],[]] .chain = true := by decide
def e602907554678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e602907554678 : Closed e602907554678 ∧ code e602907554678 = 2801930810230 := by decide
theorem cert_e602907554678 : check e602907554678 [[],[]] .chain = true := by decide
def e602907554734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e602907554734 : Closed e602907554734 ∧ code e602907554734 = 2801930810286 := by decide
theorem cert_e602907554734 : check e602907554734 [[],[]] .chain = true := by decide
def e602907554746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e602907554746 : Closed e602907554746 ∧ code e602907554746 = 2801930810298 := by decide
theorem cert_e602907554746 : check e602907554746 [[],[]] .chain = true := by decide
def e602907554774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e602907554774 : Closed e602907554774 ∧ code e602907554774 = 2801930810326 := by decide
theorem cert_e602907554774 : check e602907554774 [[],[]] .chain = true := by decide
def e602907554778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e602907554778 : Closed e602907554778 ∧ code e602907554778 = 2801930810330 := by decide
theorem cert_e602907554778 : check e602907554778 [[],[]] .chain = true := by decide
def e602907555054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e602907555054 : Closed e602907555054 ∧ code e602907555054 = 2801930810606 := by decide
theorem cert_e602907555054 : check e602907555054 [[],[]] .chain = true := by decide
def e602907555062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e602907555062 : Closed e602907555062 ∧ code e602907555062 = 2801930810614 := by decide
theorem cert_e602907555062 : check e602907555062 [[],[]] .chain = true := by decide
def e602907555438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e602907555438 : Closed e602907555438 ∧ code e602907555438 = 2801930810990 := by decide
theorem cert_e602907555438 : check e602907555438 [[],[]] .chain = true := by decide
def e602907555450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e602907555450 : Closed e602907555450 ∧ code e602907555450 = 2801930811002 := by decide
theorem cert_e602907555450 : check e602907555450 [[],[]] .chain = true := by decide
def e602907555614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3)))))))
theorem wire_e602907555614 : Closed e602907555614 ∧ code e602907555614 = 2801930811166 := by decide
theorem cert_e602907555614 : checkPay e602907555614 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e602907555638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e602907555638 : Closed e602907555638 ∧ code e602907555638 = 2801930811190 := by decide
theorem cert_e602907555638 : check e602907555638 [[],[]] .chain = true := by decide
def e602907555642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e602907555642 : Closed e602907555642 ∧ code e602907555642 = 2801930811194 := by decide
theorem cert_e602907555642 : check e602907555642 [[],[]] .chain = true := by decide
def e602907556270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e602907556270 : Closed e602907556270 ∧ code e602907556270 = 2801930811822 := by decide
theorem cert_e602907556270 : check e602907556270 [[],[]] .chain = true := by decide
def e602907556282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e602907556282 : Closed e602907556282 ∧ code e602907556282 = 2801930811834 := by decide
theorem cert_e602907556282 : check e602907556282 [[],[]] .chain = true := by decide
def e602907556330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e602907556330 : Closed e602907556330 ∧ code e602907556330 = 2801930811882 := by decide
theorem cert_e602907556330 : check e602907556330 [[],[]] .chain = true := by decide
def e602907556462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e602907556462 : Closed e602907556462 ∧ code e602907556462 = 2801930812014 := by decide
theorem cert_e602907556462 : check e602907556462 [[],[]] .chain = true := by decide
def e602907556474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e602907556474 : Closed e602907556474 ∧ code e602907556474 = 2801930812026 := by decide
theorem cert_e602907556474 : check e602907556474 [[],[]] .chain = true := by decide
def e602907556762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e602907556762 : Closed e602907556762 ∧ code e602907556762 = 2801930812314 := by decide
theorem cert_e602907556762 : check e602907556762 [[],[]] .chain = true := by decide
def e602907556974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2))))))
theorem wire_e602907556974 : Closed e602907556974 ∧ code e602907556974 = 2801930812526 := by decide
theorem cert_e602907556974 : checkPay e602907556974 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e602907556986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0))))))
theorem wire_e602907556986 : Closed e602907556986 ∧ code e602907556986 = 2801930812538 := by decide
theorem cert_e602907556986 : checkPay e602907556986 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e602907557078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e602907557078 : Closed e602907557078 ∧ code e602907557078 = 2801930812630 := by decide
theorem cert_e602907557078 : check e602907557078 [[],[]] .chain = true := by decide
def e602907557082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e602907557082 : Closed e602907557082 ∧ code e602907557082 = 2801930812634 := by decide
theorem cert_e602907557082 : check e602907557082 [[],[]] .chain = true := by decide
def e602907557098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e602907557098 : Closed e602907557098 ∧ code e602907557098 = 2801930812650 := by decide
theorem cert_e602907557098 : check e602907557098 [[],[]] .chain = true := by decide
def e602907557150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3)))))))
theorem wire_e602907557150 : Closed e602907557150 ∧ code e602907557150 = 2801930812702 := by decide
theorem cert_e602907557150 : checkPay e602907557150 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e602907557174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e602907557174 : Closed e602907557174 ∧ code e602907557174 = 2801930812726 := by decide
theorem cert_e602907557174 : check e602907557174 [[],[]] .chain = true := by decide
def e602907557178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e602907557178 : Closed e602907557178 ∧ code e602907557178 = 2801930812730 := by decide
theorem cert_e602907557178 : check e602907557178 [[],[]] .chain = true := by decide
def e602907557274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e602907557274 : Closed e602907557274 ∧ code e602907557274 = 2801930812826 := by decide
theorem cert_e602907557274 : check e602907557274 [[],[]] .chain = true := by decide
def e602907557318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1)))))))
theorem wire_e602907557318 : Closed e602907557318 ∧ code e602907557318 = 2801930812870 := by decide
theorem cert_e602907557318 : checkPay e602907557318 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e602907558878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e602907558878 : Closed e602907558878 ∧ code e602907558878 = 2801930814430 := by decide
theorem cert_e602907558878 : check e602907558878 [[],[]] .chain = true := by decide
def e602907558894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e602907558894 : Closed e602907558894 ∧ code e602907558894 = 2801930814446 := by decide
theorem cert_e602907558894 : check e602907558894 [[],[]] .chain = true := by decide
def e602907560814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e602907560814 : Closed e602907560814 ∧ code e602907560814 = 2801930816366 := by decide
theorem cert_e602907560814 : check e602907560814 [[],[]] .chain = true := by decide
def e602907560822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e602907560822 : Closed e602907560822 ∧ code e602907560822 = 2801930816374 := by decide
theorem cert_e602907560822 : check e602907560822 [[],[]] .chain = true := by decide
def e602907560878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e602907560878 : Closed e602907560878 ∧ code e602907560878 = 2801930816430 := by decide
theorem cert_e602907560878 : check e602907560878 [[],[]] .chain = true := by decide
def e602907560890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e602907560890 : Closed e602907560890 ∧ code e602907560890 = 2801930816442 := by decide
theorem cert_e602907560890 : check e602907560890 [[],[]] .chain = true := by decide
def e602907560918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e602907560918 : Closed e602907560918 ∧ code e602907560918 = 2801930816470 := by decide
theorem cert_e602907560918 : check e602907560918 [[],[]] .chain = true := by decide
def e602907560922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e602907560922 : Closed e602907560922 ∧ code e602907560922 = 2801930816474 := by decide
theorem cert_e602907560922 : check e602907560922 [[],[]] .chain = true := by decide
def e602907561198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e602907561198 : Closed e602907561198 ∧ code e602907561198 = 2801930816750 := by decide
theorem cert_e602907561198 : check e602907561198 [[],[]] .chain = true := by decide
def e602907561206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e602907561206 : Closed e602907561206 ∧ code e602907561206 = 2801930816758 := by decide
theorem cert_e602907561206 : check e602907561206 [[],[]] .chain = true := by decide
def e602907561582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e602907561582 : Closed e602907561582 ∧ code e602907561582 = 2801930817134 := by decide
theorem cert_e602907561582 : check e602907561582 [[],[]] .chain = true := by decide
def e602907561594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e602907561594 : Closed e602907561594 ∧ code e602907561594 = 2801930817146 := by decide
theorem cert_e602907561594 : check e602907561594 [[],[]] .chain = true := by decide
def e602907561758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e602907561758 : Closed e602907561758 ∧ code e602907561758 = 2801930817310 := by decide
theorem cert_e602907561758 : checkPay e602907561758 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e602907561782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e602907561782 : Closed e602907561782 ∧ code e602907561782 = 2801930817334 := by decide
theorem cert_e602907561782 : check e602907561782 [[],[]] .chain = true := by decide
def e602907561786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e602907561786 : Closed e602907561786 ∧ code e602907561786 = 2801930817338 := by decide
theorem cert_e602907561786 : check e602907561786 [[],[]] .chain = true := by decide
def e602907566558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e602907566558 : Closed e602907566558 ∧ code e602907566558 = 2801930822110 := by decide
theorem cert_e602907566558 : check e602907566558 [[],[]] .chain = true := by decide
def e602907566582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e602907566582 : Closed e602907566582 ∧ code e602907566582 = 2801930822134 := by decide
theorem cert_e602907566582 : check e602907566582 [[],[]] .chain = true := by decide
def e602907567534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e602907567534 : Closed e602907567534 ∧ code e602907567534 = 2801930823086 := by decide
theorem cert_e602907567534 : check e602907567534 [[],[]] .chain = true := by decide
def e602907567546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e602907567546 : Closed e602907567546 ∧ code e602907567546 = 2801930823098 := by decide
theorem cert_e602907567546 : check e602907567546 [[],[]] .chain = true := by decide
def e602907567594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e602907567594 : Closed e602907567594 ∧ code e602907567594 = 2801930823146 := by decide
theorem cert_e602907567594 : check e602907567594 [[],[]] .chain = true := by decide
def e602907567726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e602907567726 : Closed e602907567726 ∧ code e602907567726 = 2801930823278 := by decide
theorem cert_e602907567726 : check e602907567726 [[],[]] .chain = true := by decide
def e602907567738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e602907567738 : Closed e602907567738 ∧ code e602907567738 = 2801930823290 := by decide
theorem cert_e602907567738 : check e602907567738 [[],[]] .chain = true := by decide
def e602907568026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e602907568026 : Closed e602907568026 ∧ code e602907568026 = 2801930823578 := by decide
theorem cert_e602907568026 : check e602907568026 [[],[]] .chain = true := by decide
def e602907570414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e602907570414 : Closed e602907570414 ∧ code e602907570414 = 2801930825966 := by decide
theorem cert_e602907570414 : check e602907570414 [[],[]] .chain = true := by decide
def e602907570422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e602907570422 : Closed e602907570422 ∧ code e602907570422 = 2801930825974 := by decide
theorem cert_e602907570422 : check e602907570422 [[],[]] .chain = true := by decide
def e602907570902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e602907570902 : Closed e602907570902 ∧ code e602907570902 = 2801930826454 := by decide
theorem cert_e602907570902 : check e602907570902 [[],[]] .chain = true := by decide
def e602907570906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e602907570906 : Closed e602907570906 ∧ code e602907570906 = 2801930826458 := by decide
theorem cert_e602907570906 : check e602907570906 [[],[]] .chain = true := by decide
def e602907570922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e602907570922 : Closed e602907570922 ∧ code e602907570922 = 2801930826474 := by decide
theorem cert_e602907570922 : check e602907570922 [[],[]] .chain = true := by decide
def e602907570974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e602907570974 : Closed e602907570974 ∧ code e602907570974 = 2801930826526 := by decide
theorem cert_e602907570974 : checkPay e602907570974 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e602907570998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e602907570998 : Closed e602907570998 ∧ code e602907570998 = 2801930826550 := by decide
theorem cert_e602907570998 : check e602907570998 [[],[]] .chain = true := by decide
def e602907571002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e602907571002 : Closed e602907571002 ∧ code e602907571002 = 2801930826554 := by decide
theorem cert_e602907571002 : check e602907571002 [[],[]] .chain = true := by decide
def e602907571098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e602907571098 : Closed e602907571098 ∧ code e602907571098 = 2801930826650 := by decide
theorem cert_e602907571098 : check e602907571098 [[],[]] .chain = true := by decide
def e602907571142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e602907571142 : Closed e602907571142 ∧ code e602907571142 = 2801930826694 := by decide
theorem cert_e602907571142 : checkPay e602907571142 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e602907576182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e602907576182 : Closed e602907576182 ∧ code e602907576182 = 2801930831734 := by decide
theorem cert_e602907576182 : check e602907576182 [[],[]] .chain = true := by decide
def e602907576246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e602907576246 : Closed e602907576246 ∧ code e602907576246 = 2801930831798 := by decide
theorem cert_e602907576246 : check e602907576246 [[],[]] .chain = true := by decide
def e602907576250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e602907576250 : Closed e602907576250 ∧ code e602907576250 = 2801930831802 := by decide
theorem cert_e602907576250 : check e602907576250 [[],[]] .chain = true := by decide
def e602907577582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e602907577582 : Closed e602907577582 ∧ code e602907577582 = 2801930833134 := by decide
theorem cert_e602907577582 : check e602907577582 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907577590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e602907577590 : Closed e602907577590 ∧ code e602907577590 = 2801930833142 := by decide
theorem cert_e602907577590 : check e602907577590 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907577966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e602907577966 : Closed e602907577966 ∧ code e602907577966 = 2801930833518 := by decide
theorem cert_e602907577966 : check e602907577966 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907577978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e602907577978 : Closed e602907577978 ∧ code e602907577978 = 2801930833530 := by decide
theorem cert_e602907577978 : check e602907577978 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907578166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e602907578166 : Closed e602907578166 ∧ code e602907578166 = 2801930833718 := by decide
theorem cert_e602907578166 : check e602907578166 [[],[],[.under,.under,.left]] .chain = true := by decide
def e602907578170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e602907578170 : Closed e602907578170 ∧ code e602907578170 = 2801930833722 := by decide
theorem cert_e602907578170 : check e602907578170 [[],[],[.under,.under,.left]] .chain = true := by decide
def e602907580086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e602907580086 : Closed e602907580086 ∧ code e602907580086 = 2801930835638 := by decide
theorem cert_e602907580086 : check e602907580086 [[],[]] .chain = true := by decide
def e602907580118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e602907580118 : Closed e602907580118 ∧ code e602907580118 = 2801930835670 := by decide
theorem cert_e602907580118 : check e602907580118 [[],[]] .chain = true := by decide
def e602907580122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e602907580122 : Closed e602907580122 ∧ code e602907580122 = 2801930835674 := by decide
theorem cert_e602907580122 : check e602907580122 [[],[]] .chain = true := by decide
def e602907580246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e602907580246 : Closed e602907580246 ∧ code e602907580246 = 2801930835798 := by decide
theorem cert_e602907580246 : check e602907580246 [[],[]] .chain = true := by decide
def e602907580250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e602907580250 : Closed e602907580250 ∧ code e602907580250 = 2801930835802 := by decide
theorem cert_e602907580250 : check e602907580250 [[],[]] .chain = true := by decide
def e602907580266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e602907580266 : Closed e602907580266 ∧ code e602907580266 = 2801930835818 := by decide
theorem cert_e602907580266 : check e602907580266 [[],[]] .chain = true := by decide
def e602907580654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e602907580654 : Closed e602907580654 ∧ code e602907580654 = 2801930836206 := by decide
theorem cert_e602907580654 : check e602907580654 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907580662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e602907580662 : Closed e602907580662 ∧ code e602907580662 = 2801930836214 := by decide
theorem cert_e602907580662 : check e602907580662 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e602907580854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e602907580854 : Closed e602907580854 ∧ code e602907580854 = 2801930836406 := by decide
theorem cert_e602907580854 : check e602907580854 [[],[]] .chain = true := by decide
def e602907580886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e602907580886 : Closed e602907580886 ∧ code e602907580886 = 2801930836438 := by decide
theorem cert_e602907580886 : check e602907580886 [[],[]] .chain = true := by decide
def e602907580890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e602907580890 : Closed e602907580890 ∧ code e602907580890 = 2801930836442 := by decide
theorem cert_e602907580890 : check e602907580890 [[],[]] .chain = true := by decide
def e602907581046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e602907581046 : Closed e602907581046 ∧ code e602907581046 = 2801930836598 := by decide
theorem cert_e602907581046 : check e602907581046 [[],[]] .chain = true := by decide
def e602907581214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e602907581214 : Closed e602907581214 ∧ code e602907581214 = 2801930836766 := by decide
theorem cert_e602907581214 : check e602907581214 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907581238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e602907581238 : Closed e602907581238 ∧ code e602907581238 = 2801930836790 := by decide
theorem cert_e602907581238 : check e602907581238 [[],[]] .chain = true := by decide
def e602907581242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e602907581242 : Closed e602907581242 ∧ code e602907581242 = 2801930836794 := by decide
theorem cert_e602907581242 : check e602907581242 [[],[]] .chain = true := by decide
def e602907581326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e602907581326 : Closed e602907581326 ∧ code e602907581326 = 2801930836878 := by decide
theorem cert_e602907581326 : check e602907581326 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e602907581550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e602907581550 : Closed e602907581550 ∧ code e602907581550 = 2801930837102 := by decide
theorem cert_e602907581550 : check e602907581550 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907581562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e602907581562 : Closed e602907581562 ∧ code e602907581562 = 2801930837114 := by decide
theorem cert_e602907581562 : check e602907581562 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e602907581654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e602907581654 : Closed e602907581654 ∧ code e602907581654 = 2801930837206 := by decide
theorem cert_e602907581654 : check e602907581654 [[],[]] .chain = true := by decide
def e602907581658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e602907581658 : Closed e602907581658 ∧ code e602907581658 = 2801930837210 := by decide
theorem cert_e602907581658 : check e602907581658 [[],[]] .chain = true := by decide
def e602907581674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e602907581674 : Closed e602907581674 ∧ code e602907581674 = 2801930837226 := by decide
theorem cert_e602907581674 : check e602907581674 [[],[]] .chain = true := by decide
def e602907581726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e602907581726 : Closed e602907581726 ∧ code e602907581726 = 2801930837278 := by decide
theorem cert_e602907581726 : check e602907581726 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907581750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e602907581750 : Closed e602907581750 ∧ code e602907581750 = 2801930837302 := by decide
theorem cert_e602907581750 : check e602907581750 [[],[]] .chain = true := by decide
def e602907581754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e602907581754 : Closed e602907581754 ∧ code e602907581754 = 2801930837306 := by decide
theorem cert_e602907581754 : check e602907581754 [[],[]] .chain = true := by decide
def e602907581850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e602907581850 : Closed e602907581850 ∧ code e602907581850 = 2801930837402 := by decide
theorem cert_e602907581850 : check e602907581850 [[],[]] .chain = true := by decide
def e602907581894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e602907581894 : Closed e602907581894 ∧ code e602907581894 = 2801930837446 := by decide
theorem cert_e602907581894 : check e602907581894 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e602907582006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e602907582006 : Closed e602907582006 ∧ code e602907582006 = 2801930837558 := by decide
theorem cert_e602907582006 : check e602907582006 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e602907582010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e602907582010 : Closed e602907582010 ∧ code e602907582010 = 2801930837562 := by decide
theorem cert_e602907582010 : check e602907582010 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e602907582094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e602907582094 : Closed e602907582094 ∧ code e602907582094 = 2801930837646 := by decide
theorem cert_e602907582094 : check e602907582094 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e602907582150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e602907582150 : Closed e602907582150 ∧ code e602907582150 = 2801930837702 := by decide
theorem cert_e602907582150 : check e602907582150 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e602907582958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e602907582958 : Closed e602907582958 ∧ code e602907582958 = 2801930838510 := by decide
theorem cert_e602907582958 : check e602907582958 [[],[]] .chain = true := by decide
def e602907583926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e602907583926 : Closed e602907583926 ∧ code e602907583926 = 2801930839478 := by decide
theorem cert_e602907583926 : check e602907583926 [[],[]] .chain = true := by decide
def e602907583958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e602907583958 : Closed e602907583958 ∧ code e602907583958 = 2801930839510 := by decide
theorem cert_e602907583958 : check e602907583958 [[],[]] .chain = true := by decide
def e602907583962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e602907583962 : Closed e602907583962 ∧ code e602907583962 = 2801930839514 := by decide
theorem cert_e602907583962 : check e602907583962 [[],[]] .chain = true := by decide
def e602907584118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e602907584118 : Closed e602907584118 ∧ code e602907584118 = 2801930839670 := by decide
theorem cert_e602907584118 : check e602907584118 [[],[]] .chain = true := by decide
def e602907584286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e602907584286 : Closed e602907584286 ∧ code e602907584286 = 2801930839838 := by decide
theorem cert_e602907584286 : check e602907584286 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907584310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e602907584310 : Closed e602907584310 ∧ code e602907584310 = 2801930839862 := by decide
theorem cert_e602907584310 : check e602907584310 [[],[]] .chain = true := by decide
def e602907584314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e602907584314 : Closed e602907584314 ∧ code e602907584314 = 2801930839866 := by decide
theorem cert_e602907584314 : check e602907584314 [[],[]] .chain = true := by decide
def e602907584398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e602907584398 : Closed e602907584398 ∧ code e602907584398 = 2801930839950 := by decide
theorem cert_e602907584398 : check e602907584398 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907586798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e602907586798 : Closed e602907586798 ∧ code e602907586798 = 2801930842350 := by decide
theorem cert_e602907586798 : check e602907586798 [[],[]] .chain = true := by decide
def e602907586806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e602907586806 : Closed e602907586806 ∧ code e602907586806 = 2801930842358 := by decide
theorem cert_e602907586806 : check e602907586806 [[],[]] .chain = true := by decide
def e602907587286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e602907587286 : Closed e602907587286 ∧ code e602907587286 = 2801930842838 := by decide
theorem cert_e602907587286 : check e602907587286 [[],[]] .chain = true := by decide
def e602907587290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e602907587290 : Closed e602907587290 ∧ code e602907587290 = 2801930842842 := by decide
theorem cert_e602907587290 : check e602907587290 [[],[]] .chain = true := by decide
def e602907587306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e602907587306 : Closed e602907587306 ∧ code e602907587306 = 2801930842858 := by decide
theorem cert_e602907587306 : check e602907587306 [[],[]] .chain = true := by decide
def e602907587358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e602907587358 : Closed e602907587358 ∧ code e602907587358 = 2801930842910 := by decide
theorem cert_e602907587358 : check e602907587358 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907587382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e602907587382 : Closed e602907587382 ∧ code e602907587382 = 2801930842934 := by decide
theorem cert_e602907587382 : check e602907587382 [[],[]] .chain = true := by decide
def e602907587386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e602907587386 : Closed e602907587386 ∧ code e602907587386 = 2801930842938 := by decide
theorem cert_e602907587386 : check e602907587386 [[],[]] .chain = true := by decide
def e602907587482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e602907587482 : Closed e602907587482 ∧ code e602907587482 = 2801930843034 := by decide
theorem cert_e602907587482 : check e602907587482 [[],[]] .chain = true := by decide
def e602907587526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e602907587526 : Closed e602907587526 ∧ code e602907587526 = 2801930843078 := by decide
theorem cert_e602907587526 : check e602907587526 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907589006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e602907589006 : Closed e602907589006 ∧ code e602907589006 = 2801930844558 := by decide
theorem cert_e602907589006 : check e602907589006 [[],[],[.under,.under,.left]] .chain = true := by decide
def e602907589062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e602907589062 : Closed e602907589062 ∧ code e602907589062 = 2801930844614 := by decide
theorem cert_e602907589062 : check e602907589062 [[],[],[.under,.under,.left]] .chain = true := by decide
def e602907629806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e602907629806 : Closed e602907629806 ∧ code e602907629806 = 2801930885358 := by decide
theorem cert_e602907629806 : check e602907629806 [[],[]] .smaller = true := by decide
def e602907629814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e602907629814 : Closed e602907629814 ∧ code e602907629814 = 2801930885366 := by decide
theorem cert_e602907629814 : check e602907629814 [[],[]] .smaller = true := by decide
def e602907630366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e602907630366 : Closed e602907630366 ∧ code e602907630366 = 2801930885918 := by decide
theorem cert_e602907630366 : check e602907630366 [[],[]] .smaller = true := by decide
def e602907630478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e602907630478 : Closed e602907630478 ∧ code e602907630478 = 2801930886030 := by decide
theorem cert_e602907630478 : check e602907630478 [[],[]] .smaller = true := by decide
def e602907630702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e602907630702 : Closed e602907630702 ∧ code e602907630702 = 2801930886254 := by decide
theorem cert_e602907630702 : check e602907630702 [[],[]] .smaller = true := by decide
def e602907630714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e602907630714 : Closed e602907630714 ∧ code e602907630714 = 2801930886266 := by decide
theorem cert_e602907630714 : check e602907630714 [[],[]] .smaller = true := by decide
def e602907630878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e602907630878 : Closed e602907630878 ∧ code e602907630878 = 2801930886430 := by decide
theorem cert_e602907630878 : check e602907630878 [[],[]] .smaller = true := by decide
def e602907631046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e602907631046 : Closed e602907631046 ∧ code e602907631046 = 2801930886598 := by decide
theorem cert_e602907631046 : check e602907631046 [[],[]] .smaller = true := by decide
def e602907631070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e602907631070 : Closed e602907631070 ∧ code e602907631070 = 2801930886622 := by decide
theorem cert_e602907631070 : check e602907631070 [[],[]] .chain = true := by decide
def e602907631086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e602907631086 : Closed e602907631086 ∧ code e602907631086 = 2801930886638 := by decide
theorem cert_e602907631086 : check e602907631086 [[],[]] .chain = true := by decide
def e602907631158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e602907631158 : Closed e602907631158 ∧ code e602907631158 = 2801930886710 := by decide
theorem cert_e602907631158 : check e602907631158 [[],[]] .smaller = true := by decide
def e602907631162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e602907631162 : Closed e602907631162 ∧ code e602907631162 = 2801930886714 := by decide
theorem cert_e602907631162 : check e602907631162 [[],[]] .smaller = true := by decide
def e602907631246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e602907631246 : Closed e602907631246 ∧ code e602907631246 = 2801930886798 := by decide
theorem cert_e602907631246 : check e602907631246 [[],[]] .smaller = true := by decide
def e602907631302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e602907631302 : Closed e602907631302 ∧ code e602907631302 = 2801930886854 := by decide
theorem cert_e602907631302 : check e602907631302 [[],[]] .smaller = true := by decide
end Blc.Floor41
