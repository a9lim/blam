import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e602913433210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e602913433210 : Closed e602913433210 ∧ code e602913433210 = 2801936688762 := by decide
theorem cert_e602913433210 : check e602913433210 [[],[],[.under]] .smaller = true := by decide
def e602913433498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e602913433498 : Closed e602913433498 ∧ code e602913433498 = 2801936689050 := by decide
theorem cert_e602913433498 : check e602913433498 [[],[],[.under]] .smaller = true := by decide
def e602913435886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e602913435886 : Closed e602913435886 ∧ code e602913435886 = 2801936691438 := by decide
theorem cert_e602913435886 : check e602913435886 [[],[],[.under]] .smaller = true := by decide
def e602913435894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e602913435894 : Closed e602913435894 ∧ code e602913435894 = 2801936691446 := by decide
theorem cert_e602913435894 : check e602913435894 [[],[],[.under]] .smaller = true := by decide
def e602913436374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e602913436374 : Closed e602913436374 ∧ code e602913436374 = 2801936691926 := by decide
theorem cert_e602913436374 : check e602913436374 [[],[],[.under]] .smaller = true := by decide
def e602913436378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e602913436378 : Closed e602913436378 ∧ code e602913436378 = 2801936691930 := by decide
theorem cert_e602913436378 : check e602913436378 [[],[],[.under]] .smaller = true := by decide
def e602913436394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e602913436394 : Closed e602913436394 ∧ code e602913436394 = 2801936691946 := by decide
theorem cert_e602913436394 : check e602913436394 [[],[],[.under]] .smaller = true := by decide
def e602913436470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e602913436470 : Closed e602913436470 ∧ code e602913436470 = 2801936692022 := by decide
theorem cert_e602913436470 : check e602913436470 [[],[],[.under]] .smaller = true := by decide
def e602913436474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e602913436474 : Closed e602913436474 ∧ code e602913436474 = 2801936692026 := by decide
theorem cert_e602913436474 : check e602913436474 [[],[],[.under]] .smaller = true := by decide
def e602913436570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e602913436570 : Closed e602913436570 ∧ code e602913436570 = 2801936692122 := by decide
theorem cert_e602913436570 : check e602913436570 [[],[],[.under]] .smaller = true := by decide
def e602913573742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e602913573742 : Closed e602913573742 ∧ code e602913573742 = 2801936829294 := by decide
theorem cert_e602913573742 : check e602913573742 [[],[],[.under]] .smaller = true := by decide
def e602913573750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e602913573750 : Closed e602913573750 ∧ code e602913573750 = 2801936829302 := by decide
theorem cert_e602913573750 : check e602913573750 [[],[],[.under]] .smaller = true := by decide
def e602913573806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e602913573806 : Closed e602913573806 ∧ code e602913573806 = 2801936829358 := by decide
theorem cert_e602913573806 : check e602913573806 [[],[],[.under]] .smaller = true := by decide
def e602913573818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e602913573818 : Closed e602913573818 ∧ code e602913573818 = 2801936829370 := by decide
theorem cert_e602913573818 : check e602913573818 [[],[],[.under]] .smaller = true := by decide
def e602913573846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e602913573846 : Closed e602913573846 ∧ code e602913573846 = 2801936829398 := by decide
theorem cert_e602913573846 : check e602913573846 [[],[],[.under]] .smaller = true := by decide
def e602913573850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e602913573850 : Closed e602913573850 ∧ code e602913573850 = 2801936829402 := by decide
theorem cert_e602913573850 : check e602913573850 [[],[],[.under]] .smaller = true := by decide
def e602913574126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e602913574126 : Closed e602913574126 ∧ code e602913574126 = 2801936829678 := by decide
theorem cert_e602913574126 : check e602913574126 [[],[],[.under]] .smaller = true := by decide
def e602913574134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e602913574134 : Closed e602913574134 ∧ code e602913574134 = 2801936829686 := by decide
theorem cert_e602913574134 : check e602913574134 [[],[],[.under]] .smaller = true := by decide
def e602913574510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e602913574510 : Closed e602913574510 ∧ code e602913574510 = 2801936830062 := by decide
theorem cert_e602913574510 : check e602913574510 [[],[],[.under]] .smaller = true := by decide
def e602913574522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e602913574522 : Closed e602913574522 ∧ code e602913574522 = 2801936830074 := by decide
theorem cert_e602913574522 : check e602913574522 [[],[],[.under]] .smaller = true := by decide
def e602913574710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e602913574710 : Closed e602913574710 ∧ code e602913574710 = 2801936830262 := by decide
theorem cert_e602913574710 : check e602913574710 [[],[],[.under]] .smaller = true := by decide
def e602913574714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e602913574714 : Closed e602913574714 ∧ code e602913574714 = 2801936830266 := by decide
theorem cert_e602913574714 : check e602913574714 [[],[],[.under]] .smaller = true := by decide
def e602931224030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e602931224030 : Closed e602931224030 ∧ code e602931224030 = 2801954479582 := by decide
theorem cert_e602931224030 : check e602931224030 [[],[],[]] .smaller = true := by decide
def e602931224046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e602931224046 : Closed e602931224046 ∧ code e602931224046 = 2801954479598 := by decide
theorem cert_e602931224046 : check e602931224046 [[],[],[]] .smaller = true := by decide
def e602931224286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e602931224286 : Closed e602931224286 ∧ code e602931224286 = 2801954479838 := by decide
theorem cert_e602931224286 : check e602931224286 [[],[],[]] .smaller = true := by decide
def e602931224310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e602931224310 : Closed e602931224310 ∧ code e602931224310 = 2801954479862 := by decide
theorem cert_e602931224310 : check e602931224310 [[],[],[]] .smaller = true := by decide
def e602931224430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e602931224430 : Closed e602931224430 ∧ code e602931224430 = 2801954479982 := by decide
theorem cert_e602931224430 : check e602931224430 [[],[],[]] .smaller = true := by decide
def e602931224438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e602931224438 : Closed e602931224438 ∧ code e602931224438 = 2801954479990 := by decide
theorem cert_e602931224438 : check e602931224438 [[],[],[]] .smaller = true := by decide
def e602931229662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e602931229662 : Closed e602931229662 ∧ code e602931229662 = 2801954485214 := by decide
theorem cert_e602931229662 : check e602931229662 [[],[],[]] .smaller = true := by decide
def e602931229678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e602931229678 : Closed e602931229678 ∧ code e602931229678 = 2801954485230 := by decide
theorem cert_e602931229678 : check e602931229678 [[],[],[]] .smaller = true := by decide
def e602931231198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e602931231198 : Closed e602931231198 ∧ code e602931231198 = 2801954486750 := by decide
theorem cert_e602931231198 : check e602931231198 [[],[],[]] .smaller = true := by decide
def e602931231222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e602931231222 : Closed e602931231222 ∧ code e602931231222 = 2801954486774 := by decide
theorem cert_e602931231222 : check e602931231222 [[],[],[]] .smaller = true := by decide
def e602931231982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e602931231982 : Closed e602931231982 ∧ code e602931231982 = 2801954487534 := by decide
theorem cert_e602931231982 : check e602931231982 [[],[],[]] .smaller = true := by decide
def e602931231990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e602931231990 : Closed e602931231990 ∧ code e602931231990 = 2801954487542 := by decide
theorem cert_e602931231990 : check e602931231990 [[],[],[]] .smaller = true := by decide
def e602931288942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e602931288942 : Closed e602931288942 ∧ code e602931288942 = 2801954544494 := by decide
theorem cert_e602931288942 : check e602931288942 [[],[],[]] .smaller = true := by decide
def e602931288950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e602931288950 : Closed e602931288950 ∧ code e602931288950 = 2801954544502 := by decide
theorem cert_e602931288950 : check e602931288950 [[],[],[]] .smaller = true := by decide
def e602931289014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e602931289014 : Closed e602931289014 ∧ code e602931289014 = 2801954544566 := by decide
theorem cert_e602931289014 : check e602931289014 [[],[],[]] .smaller = true := by decide
def e602931289454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e602931289454 : Closed e602931289454 ∧ code e602931289454 = 2801954545006 := by decide
theorem cert_e602931289454 : check e602931289454 [[],[],[]] .smaller = true := by decide
def e602931289462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e602931289462 : Closed e602931289462 ∧ code e602931289462 = 2801954545014 := by decide
theorem cert_e602931289462 : check e602931289462 [[],[],[]] .smaller = true := by decide
def e602931289518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e602931289518 : Closed e602931289518 ∧ code e602931289518 = 2801954545070 := by decide
theorem cert_e602931289518 : check e602931289518 [[],[],[]] .smaller = true := by decide
def e602931289530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e602931289530 : Closed e602931289530 ∧ code e602931289530 = 2801954545082 := by decide
theorem cert_e602931289530 : check e602931289530 [[],[],[]] .smaller = true := by decide
def e602931289558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e602931289558 : Closed e602931289558 ∧ code e602931289558 = 2801954545110 := by decide
theorem cert_e602931289558 : check e602931289558 [[],[],[]] .smaller = true := by decide
def e602931289562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e602931289562 : Closed e602931289562 ∧ code e602931289562 = 2801954545114 := by decide
theorem cert_e602931289562 : check e602931289562 [[],[],[]] .smaller = true := by decide
def e602931289782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e602931289782 : Closed e602931289782 ∧ code e602931289782 = 2801954545334 := by decide
theorem cert_e602931289782 : check e602931289782 [[],[],[]] .smaller = true := by decide
def e602931289814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e602931289814 : Closed e602931289814 ∧ code e602931289814 = 2801954545366 := by decide
theorem cert_e602931289814 : check e602931289814 [[],[],[]] .smaller = true := by decide
def e602931289818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e602931289818 : Closed e602931289818 ∧ code e602931289818 = 2801954545370 := by decide
theorem cert_e602931289818 : check e602931289818 [[],[],[]] .smaller = true := by decide
def e602931292014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e602931292014 : Closed e602931292014 ∧ code e602931292014 = 2801954547566 := by decide
theorem cert_e602931292014 : check e602931292014 [[],[],[]] .smaller = true := by decide
def e602931292022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e602931292022 : Closed e602931292022 ∧ code e602931292022 = 2801954547574 := by decide
theorem cert_e602931292022 : check e602931292022 [[],[],[]] .smaller = true := by decide
def e602931292086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e602931292086 : Closed e602931292086 ∧ code e602931292086 = 2801954547638 := by decide
theorem cert_e602931292086 : check e602931292086 [[],[],[]] .smaller = true := by decide
def e602931293422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e602931293422 : Closed e602931293422 ∧ code e602931293422 = 2801954548974 := by decide
theorem cert_e602931293422 : check e602931293422 [[],[],[]] .smaller = true := by decide
def e602931293430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e602931293430 : Closed e602931293430 ∧ code e602931293430 = 2801954548982 := by decide
theorem cert_e602931293430 : check e602931293430 [[],[],[]] .smaller = true := by decide
def e602931293814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e602931293814 : Closed e602931293814 ∧ code e602931293814 = 2801954549366 := by decide
theorem cert_e602931293814 : check e602931293814 [[],[],[]] .smaller = true := by decide
def e602931295086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e602931295086 : Closed e602931295086 ∧ code e602931295086 = 2801954550638 := by decide
theorem cert_e602931295086 : check e602931295086 [[],[],[]] .smaller = true := by decide
def e602931295094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e602931295094 : Closed e602931295094 ∧ code e602931295094 = 2801954550646 := by decide
theorem cert_e602931295094 : check e602931295094 [[],[],[]] .smaller = true := by decide
def e602931295150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e602931295150 : Closed e602931295150 ∧ code e602931295150 = 2801954550702 := by decide
theorem cert_e602931295150 : check e602931295150 [[],[],[]] .smaller = true := by decide
def e602931295162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e602931295162 : Closed e602931295162 ∧ code e602931295162 = 2801954550714 := by decide
theorem cert_e602931295162 : check e602931295162 [[],[],[]] .smaller = true := by decide
def e602931295190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e602931295190 : Closed e602931295190 ∧ code e602931295190 = 2801954550742 := by decide
theorem cert_e602931295190 : check e602931295190 [[],[],[]] .smaller = true := by decide
def e602931295194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e602931295194 : Closed e602931295194 ∧ code e602931295194 = 2801954550746 := by decide
theorem cert_e602931295194 : check e602931295194 [[],[],[]] .smaller = true := by decide
def e602931295470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e602931295470 : Closed e602931295470 ∧ code e602931295470 = 2801954551022 := by decide
theorem cert_e602931295470 : check e602931295470 [[],[],[]] .smaller = true := by decide
def e602931295478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e602931295478 : Closed e602931295478 ∧ code e602931295478 = 2801954551030 := by decide
theorem cert_e602931295478 : check e602931295478 [[],[],[]] .smaller = true := by decide
def e602931295854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e602931295854 : Closed e602931295854 ∧ code e602931295854 = 2801954551406 := by decide
theorem cert_e602931295854 : check e602931295854 [[],[],[]] .smaller = true := by decide
def e602931295866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e602931295866 : Closed e602931295866 ∧ code e602931295866 = 2801954551418 := by decide
theorem cert_e602931295866 : check e602931295866 [[],[],[]] .smaller = true := by decide
def e602931296054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e602931296054 : Closed e602931296054 ∧ code e602931296054 = 2801954551606 := by decide
theorem cert_e602931296054 : check e602931296054 [[],[],[]] .smaller = true := by decide
def e602931296058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e602931296058 : Closed e602931296058 ∧ code e602931296058 = 2801954551610 := by decide
theorem cert_e602931296058 : check e602931296058 [[],[],[]] .smaller = true := by decide
def e602931296694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e602931296694 : Closed e602931296694 ∧ code e602931296694 = 2801954552246 := by decide
theorem cert_e602931296694 : check e602931296694 [[],[],[]] .smaller = true := by decide
def e602931296726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e602931296726 : Closed e602931296726 ∧ code e602931296726 = 2801954552278 := by decide
theorem cert_e602931296726 : check e602931296726 [[],[],[]] .smaller = true := by decide
def e602931296730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e602931296730 : Closed e602931296730 ∧ code e602931296730 = 2801954552282 := by decide
theorem cert_e602931296730 : check e602931296730 [[],[],[]] .smaller = true := by decide
def e602931296886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e602931296886 : Closed e602931296886 ∧ code e602931296886 = 2801954552438 := by decide
theorem cert_e602931296886 : check e602931296886 [[],[],[]] .smaller = true := by decide
def e602931297078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e602931297078 : Closed e602931297078 ∧ code e602931297078 = 2801954552630 := by decide
theorem cert_e602931297078 : check e602931297078 [[],[],[]] .smaller = true := by decide
def e602931297082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e602931297082 : Closed e602931297082 ∧ code e602931297082 = 2801954552634 := by decide
theorem cert_e602931297082 : check e602931297082 [[],[],[]] .smaller = true := by decide
def e602931304302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e602931304302 : Closed e602931304302 ∧ code e602931304302 = 2801954559854 := by decide
theorem cert_e602931304302 : check e602931304302 [[],[],[]] .smaller = true := by decide
def e602931304310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e602931304310 : Closed e602931304310 ∧ code e602931304310 = 2801954559862 := by decide
theorem cert_e602931304310 : check e602931304310 [[],[],[]] .smaller = true := by decide
def e602931304374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e602931304374 : Closed e602931304374 ∧ code e602931304374 = 2801954559926 := by decide
theorem cert_e602931304374 : check e602931304374 [[],[],[]] .smaller = true := by decide
def e602931305710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e602931305710 : Closed e602931305710 ∧ code e602931305710 = 2801954561262 := by decide
theorem cert_e602931305710 : check e602931305710 [[],[],[]] .smaller = true := by decide
def e602931305718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e602931305718 : Closed e602931305718 ∧ code e602931305718 = 2801954561270 := by decide
theorem cert_e602931305718 : check e602931305718 [[],[],[]] .smaller = true := by decide
def e602931306102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e602931306102 : Closed e602931306102 ∧ code e602931306102 = 2801954561654 := by decide
theorem cert_e602931306102 : check e602931306102 [[],[],[]] .smaller = true := by decide
def e602931317614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e602931317614 : Closed e602931317614 ∧ code e602931317614 = 2801954573166 := by decide
theorem cert_e602931317614 : check e602931317614 [[],[],[]] .smaller = true := by decide
def e602931317622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e602931317622 : Closed e602931317622 ∧ code e602931317622 = 2801954573174 := by decide
theorem cert_e602931317622 : check e602931317622 [[],[],[]] .smaller = true := by decide
def e602931317678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e602931317678 : Closed e602931317678 ∧ code e602931317678 = 2801954573230 := by decide
theorem cert_e602931317678 : check e602931317678 [[],[],[]] .smaller = true := by decide
def e602931317690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e602931317690 : Closed e602931317690 ∧ code e602931317690 = 2801954573242 := by decide
theorem cert_e602931317690 : check e602931317690 [[],[],[]] .smaller = true := by decide
def e602931317718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e602931317718 : Closed e602931317718 ∧ code e602931317718 = 2801954573270 := by decide
theorem cert_e602931317718 : check e602931317718 [[],[],[]] .smaller = true := by decide
def e602931317722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e602931317722 : Closed e602931317722 ∧ code e602931317722 = 2801954573274 := by decide
theorem cert_e602931317722 : check e602931317722 [[],[],[]] .smaller = true := by decide
def e602931317998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e602931317998 : Closed e602931317998 ∧ code e602931317998 = 2801954573550 := by decide
theorem cert_e602931317998 : check e602931317998 [[],[],[]] .smaller = true := by decide
def e602931318006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e602931318006 : Closed e602931318006 ∧ code e602931318006 = 2801954573558 := by decide
theorem cert_e602931318006 : check e602931318006 [[],[],[]] .smaller = true := by decide
def e602931318382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e602931318382 : Closed e602931318382 ∧ code e602931318382 = 2801954573934 := by decide
theorem cert_e602931318382 : check e602931318382 [[],[],[]] .smaller = true := by decide
def e602931318394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e602931318394 : Closed e602931318394 ∧ code e602931318394 = 2801954573946 := by decide
theorem cert_e602931318394 : check e602931318394 [[],[],[]] .smaller = true := by decide
def e602931318582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e602931318582 : Closed e602931318582 ∧ code e602931318582 = 2801954574134 := by decide
theorem cert_e602931318582 : check e602931318582 [[],[],[]] .smaller = true := by decide
def e602931318586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e602931318586 : Closed e602931318586 ∧ code e602931318586 = 2801954574138 := by decide
theorem cert_e602931318586 : check e602931318586 [[],[],[]] .smaller = true := by decide
def e602931324342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e602931324342 : Closed e602931324342 ∧ code e602931324342 = 2801954579894 := by decide
theorem cert_e602931324342 : check e602931324342 [[],[],[]] .smaller = true := by decide
def e602931324374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e602931324374 : Closed e602931324374 ∧ code e602931324374 = 2801954579926 := by decide
theorem cert_e602931324374 : check e602931324374 [[],[],[]] .smaller = true := by decide
def e602931324378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e602931324378 : Closed e602931324378 ∧ code e602931324378 = 2801954579930 := by decide
theorem cert_e602931324378 : check e602931324378 [[],[],[]] .smaller = true := by decide
def e602931324534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e602931324534 : Closed e602931324534 ∧ code e602931324534 = 2801954580086 := by decide
theorem cert_e602931324534 : check e602931324534 [[],[],[]] .smaller = true := by decide
def e602931324726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e602931324726 : Closed e602931324726 ∧ code e602931324726 = 2801954580278 := by decide
theorem cert_e602931324726 : check e602931324726 [[],[],[]] .smaller = true := by decide
def e602931324730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e602931324730 : Closed e602931324730 ∧ code e602931324730 = 2801954580282 := by decide
theorem cert_e602931324730 : check e602931324730 [[],[],[]] .smaller = true := by decide
def e602931661678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e602931661678 : Closed e602931661678 ∧ code e602931661678 = 2801954917230 := by decide
theorem cert_e602931661678 : check e602931661678 [[],[],[]] .smaller = true := by decide
def e602931661686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e602931661686 : Closed e602931661686 ∧ code e602931661686 = 2801954917238 := by decide
theorem cert_e602931661686 : check e602931661686 [[],[],[]] .smaller = true := by decide
def e602931661742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e602931661742 : Closed e602931661742 ∧ code e602931661742 = 2801954917294 := by decide
theorem cert_e602931661742 : check e602931661742 [[],[],[]] .smaller = true := by decide
def e602931661754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e602931661754 : Closed e602931661754 ∧ code e602931661754 = 2801954917306 := by decide
theorem cert_e602931661754 : check e602931661754 [[],[],[]] .smaller = true := by decide
def e602931661782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e602931661782 : Closed e602931661782 ∧ code e602931661782 = 2801954917334 := by decide
theorem cert_e602931661782 : check e602931661782 [[],[],[]] .smaller = true := by decide
def e602931661786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e602931661786 : Closed e602931661786 ∧ code e602931661786 = 2801954917338 := by decide
theorem cert_e602931661786 : check e602931661786 [[],[],[]] .smaller = true := by decide
def e602931662062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e602931662062 : Closed e602931662062 ∧ code e602931662062 = 2801954917614 := by decide
theorem cert_e602931662062 : check e602931662062 [[],[],[]] .smaller = true := by decide
def e602931662070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e602931662070 : Closed e602931662070 ∧ code e602931662070 = 2801954917622 := by decide
theorem cert_e602931662070 : check e602931662070 [[],[],[]] .smaller = true := by decide
def e602931662446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e602931662446 : Closed e602931662446 ∧ code e602931662446 = 2801954917998 := by decide
theorem cert_e602931662446 : check e602931662446 [[],[],[]] .smaller = true := by decide
def e602931662458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e602931662458 : Closed e602931662458 ∧ code e602931662458 = 2801954918010 := by decide
theorem cert_e602931662458 : check e602931662458 [[],[],[]] .smaller = true := by decide
def e602931662646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e602931662646 : Closed e602931662646 ∧ code e602931662646 = 2801954918198 := by decide
theorem cert_e602931662646 : check e602931662646 [[],[],[]] .smaller = true := by decide
def e602931662650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e602931662650 : Closed e602931662650 ∧ code e602931662650 = 2801954918202 := by decide
theorem cert_e602931662650 : check e602931662650 [[],[],[]] .smaller = true := by decide
def e604251208218 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604251208218 : Closed e604251208218 ∧ code e604251208218 = 2803274463770 := by decide
theorem cert_e604251208218 : check e604251208218 [[]] .width = true := by decide
def e604251216410 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604251216410 : Closed e604251216410 ∧ code e604251216410 = 2803274471962 := by decide
theorem cert_e604251216410 : check e604251216410 [[]] .width = true := by decide
def e604251273754 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604251273754 : Closed e604251273754 ∧ code e604251273754 = 2803274529306 := by decide
theorem cert_e604251273754 : check e604251273754 [[]] .width = true := by decide
def e604251286042 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604251286042 : Closed e604251286042 ∧ code e604251286042 = 2803274541594 := by decide
private def t_e604251286042 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604251286042 : ¬ IsSelfInterpreter e604251286042 :=
  wSource (t := t_e604251286042) (replay_sound (ps := []) (t := e604251286042) (by decide)) (by decide)
def e604251314714 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604251314714 : Closed e604251314714 ∧ code e604251314714 = 2803274570266 := by decide
theorem cert_e604251314714 : check e604251314714 [[]] .width = true := by decide
def e604251318810 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604251318810 : Closed e604251318810 ∧ code e604251318810 = 2803274574362 := by decide
private def t_e604251318810 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604251318810 : ¬ IsSelfInterpreter e604251318810 :=
  wSource (t := t_e604251318810) (replay_sound (ps := []) (t := e604251318810) (by decide)) (by decide)
def e604251601434 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604251601434 : Closed e604251601434 ∧ code e604251601434 = 2803274856986 := by decide
theorem cert_e604251601434 : check e604251601434 [[]] .width = true := by decide
def e604251609626 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604251609626 : Closed e604251609626 ∧ code e604251609626 = 2803274865178 := by decide
theorem cert_e604251609626 : check e604251609626 [[]] .width = true := by decide
def e604251994650 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604251994650 : Closed e604251994650 ∧ code e604251994650 = 2803275250202 := by decide
theorem cert_e604251994650 : check e604251994650 [[]] .width = true := by decide
def e604252006938 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604252006938 : Closed e604252006938 ∧ code e604252006938 = 2803275262490 := by decide
theorem cert_e604252006938 : check e604252006938 [[]] .width = true := by decide
def e604252199450 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604252199450 : Closed e604252199450 ∧ code e604252199450 = 2803275455002 := by decide
theorem cert_e604252199450 : check e604252199450 [[]] .width = true := by decide
def e604252203546 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604252203546 : Closed e604252203546 ∧ code e604252203546 = 2803275459098 := by decide
theorem cert_e604252203546 : check e604252203546 [[]] .width = true := by decide
def e604316069402 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604316069402 : Closed e604316069402 ∧ code e604316069402 = 2803339324954 := by decide
private def t_e604316069402 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604316069402 : ¬ IsSelfInterpreter e604316069402 :=
  wSource (t := t_e604316069402) (replay_sound (ps := []) (t := e604316069402) (by decide)) (by decide)
def e604316071450 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604316071450 : Closed e604316071450 ∧ code e604316071450 = 2803339327002 := by decide
private def t_e604316071450 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604316071450 : ¬ IsSelfInterpreter e604316071450 :=
  wSource (t := t_e604316071450) (replay_sound (ps := []) (t := e604316071450) (by decide)) (by decide)
def e604316085786 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604316085786 : Closed e604316085786 ∧ code e604316085786 = 2803339341338 := by decide
private def t_e604316085786 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604316085786 : ¬ IsSelfInterpreter e604316085786 :=
  wSource (t := t_e604316085786) (replay_sound (ps := []) (t := e604316085786) (by decide)) (by decide)
def e604316088858 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604316088858 : Closed e604316088858 ∧ code e604316088858 = 2803339344410 := by decide
private def t_e604316088858 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604316088858 : ¬ IsSelfInterpreter e604316088858 :=
  wSource (t := t_e604316088858) (replay_sound (ps := []) (t := e604316088858) (by decide)) (by decide)
def e604316096026 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604316096026 : Closed e604316096026 ∧ code e604316096026 = 2803339351578 := by decide
private def t_e604316096026 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604316096026 : ¬ IsSelfInterpreter e604316096026 :=
  wSource (t := t_e604316096026) (replay_sound (ps := []) (t := e604316096026) (by decide)) (by decide)
def e604316097050 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604316097050 : Closed e604316097050 ∧ code e604316097050 = 2803339352602 := by decide
private def t_e604316097050 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604316097050 : ¬ IsSelfInterpreter e604316097050 :=
  wSource (t := t_e604316097050) (replay_sound (ps := []) (t := e604316097050) (by decide)) (by decide)
def e604316167706 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604316167706 : Closed e604316167706 ∧ code e604316167706 = 2803339423258 := by decide
private def t_e604316167706 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604316167706 : ¬ IsSelfInterpreter e604316167706 :=
  wSource (t := t_e604316167706) (replay_sound (ps := []) (t := e604316167706) (by decide)) (by decide)
def e604316169754 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604316169754 : Closed e604316169754 ∧ code e604316169754 = 2803339425306 := by decide
private def t_e604316169754 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604316169754 : ¬ IsSelfInterpreter e604316169754 :=
  wSource (t := t_e604316169754) (replay_sound (ps := []) (t := e604316169754) (by decide)) (by decide)
def e604316266010 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604316266010 : Closed e604316266010 ∧ code e604316266010 = 2803339521562 := by decide
private def t_e604316266010 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604316266010 : ¬ IsSelfInterpreter e604316266010 :=
  wSource (t := t_e604316266010) (replay_sound (ps := []) (t := e604316266010) (by decide)) (by decide)
def e604316269082 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604316269082 : Closed e604316269082 ∧ code e604316269082 = 2803339524634 := by decide
private def t_e604316269082 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604316269082 : ¬ IsSelfInterpreter e604316269082 :=
  wSource (t := t_e604316269082) (replay_sound (ps := []) (t := e604316269082) (by decide)) (by decide)
def e604316317210 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604316317210 : Closed e604316317210 ∧ code e604316317210 = 2803339572762 := by decide
private def t_e604316317210 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604316317210 : ¬ IsSelfInterpreter e604316317210 :=
  wSource (t := t_e604316317210) (replay_sound (ps := []) (t := e604316317210) (by decide)) (by decide)
def e604316318234 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604316318234 : Closed e604316318234 ∧ code e604316318234 = 2803339573786 := by decide
private def t_e604316318234 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604316318234 : ¬ IsSelfInterpreter e604316318234 :=
  wSource (t := t_e604316318234) (replay_sound (ps := []) (t := e604316318234) (by decide)) (by decide)
def e604332141934 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e604332141934 : Closed e604332141934 ∧ code e604332141934 = 2803355397486 := by decide
theorem cert_e604332141934 : check e604332141934 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604332141942 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e604332141942 : Closed e604332141942 ∧ code e604332141942 = 2803355397494 := by decide
theorem cert_e604332141942 : checkPay e604332141942 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604332141998 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e604332141998 : Closed e604332141998 ∧ code e604332141998 = 2803355397550 := by decide
theorem cert_e604332141998 : check e604332141998 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604332142010 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e604332142010 : Closed e604332142010 ∧ code e604332142010 = 2803355397562 := by decide
theorem cert_e604332142010 : check e604332142010 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604332142038 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e604332142038 : Closed e604332142038 ∧ code e604332142038 = 2803355397590 := by decide
theorem cert_e604332142038 : check e604332142038 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604332142042 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e604332142042 : Closed e604332142042 ∧ code e604332142042 = 2803355397594 := by decide
theorem cert_e604332142042 : check e604332142042 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e604332142254 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e604332142254 : Closed e604332142254 ∧ code e604332142254 = 2803355397806 := by decide
theorem cert_e604332142254 : check e604332142254 [[],[]] .sourceHead = true := by decide
def e604332142266 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e604332142266 : Closed e604332142266 ∧ code e604332142266 = 2803355397818 := by decide
theorem cert_e604332142266 : check e604332142266 [[],[]] .sourceHead = true := by decide
def e604332142314 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e604332142314 : Closed e604332142314 ∧ code e604332142314 = 2803355397866 := by decide
theorem cert_e604332142314 : check e604332142314 [[],[]] .sourceHead = true := by decide
def e604332142422 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e604332142422 : Closed e604332142422 ∧ code e604332142422 = 2803355397974 := by decide
theorem cert_e604332142422 : check e604332142422 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604332142426 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e604332142426 : Closed e604332142426 ∧ code e604332142426 = 2803355397978 := by decide
theorem cert_e604332142426 : check e604332142426 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e604332142442 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e604332142442 : Closed e604332142442 ∧ code e604332142442 = 2803355397994 := by decide
theorem cert_e604332142442 : check e604332142442 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e604332143470 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e604332143470 : Closed e604332143470 ∧ code e604332143470 = 2803355399022 := by decide
theorem cert_e604332143470 : check e604332143470 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e604332143478 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e604332143478 : Closed e604332143478 ∧ code e604332143478 = 2803355399030 := by decide
theorem cert_e604332143478 : checkPay e604332143478 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604332143534 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e604332143534 : Closed e604332143534 ∧ code e604332143534 = 2803355399086 := by decide
theorem cert_e604332143534 : check e604332143534 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604332143546 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e604332143546 : Closed e604332143546 ∧ code e604332143546 = 2803355399098 := by decide
theorem cert_e604332143546 : check e604332143546 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604332143574 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e604332143574 : Closed e604332143574 ∧ code e604332143574 = 2803355399126 := by decide
theorem cert_e604332143574 : check e604332143574 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604332143578 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e604332143578 : Closed e604332143578 ∧ code e604332143578 = 2803355399130 := by decide
theorem cert_e604332143578 : check e604332143578 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604332143854 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e604332143854 : Closed e604332143854 ∧ code e604332143854 = 2803355399406 := by decide
theorem cert_e604332143854 : check e604332143854 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604332143862 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e604332143862 : Closed e604332143862 ∧ code e604332143862 = 2803355399414 := by decide
theorem cert_e604332143862 : check e604332143862 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604332144238 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e604332144238 : Closed e604332144238 ∧ code e604332144238 = 2803355399790 := by decide
theorem cert_e604332144238 : check e604332144238 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604332144250 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e604332144250 : Closed e604332144250 ∧ code e604332144250 = 2803355399802 := by decide
theorem cert_e604332144250 : check e604332144250 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604332144438 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e604332144438 : Closed e604332144438 ∧ code e604332144438 = 2803355399990 := by decide
theorem cert_e604332144438 : check e604332144438 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604332144442 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e604332144442 : Closed e604332144442 ∧ code e604332144442 = 2803355399994 := by decide
theorem cert_e604332144442 : check e604332144442 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604332145070 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e604332145070 : Closed e604332145070 ∧ code e604332145070 = 2803355400622 := by decide
theorem cert_e604332145070 : checkPay e604332145070 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e604332145082 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e604332145082 : Closed e604332145082 ∧ code e604332145082 = 2803355400634 := by decide
theorem cert_e604332145082 : checkPay e604332145082 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[]] = true := by decide
def e604332145130 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e604332145130 : Closed e604332145130 ∧ code e604332145130 = 2803355400682 := by decide
theorem cert_e604332145130 : checkPay e604332145130 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left,.right],[.under,.left,.left,.left,.right,.left],[.under,.left,.left,.left,.right]] = true := by decide
def e604332145262 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e604332145262 : Closed e604332145262 ∧ code e604332145262 = 2803355400814 := by decide
theorem cert_e604332145262 : checkPay e604332145262 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604332145274 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e604332145274 : Closed e604332145274 ∧ code e604332145274 = 2803355400826 := by decide
theorem cert_e604332145274 : checkPay e604332145274 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604332145562 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e604332145562 : Closed e604332145562 ∧ code e604332145562 = 2803355401114 := by decide
theorem cert_e604332145562 : checkPay e604332145562 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under]] = true := by decide
end Blc.Floor41
