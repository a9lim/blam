import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e188990781978 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990781978 : Closed e188990781978 ∧ code e188990781978 = 2388014037530 := by decide
theorem cert_e188990781978 : check e188990781978 [] .sourceHead = true := by decide
def e188990855706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990855706 : Closed e188990855706 ∧ code e188990855706 = 2388014111258 := by decide
theorem cert_e188990855706 : check e188990855706 [] .sourceHead = true := by decide
def e188990936602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990936602 : Closed e188990936602 ∧ code e188990936602 = 2388014192154 := by decide
theorem cert_e188990936602 : check e188990936602 [] .sourceHead = true := by decide
def e188990937626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990937626 : Closed e188990937626 ∧ code e188990937626 = 2388014193178 := by decide
theorem cert_e188990937626 : check e188990937626 [] .sourceHead = true := by decide
def e188990941722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990941722 : Closed e188990941722 ∧ code e188990941722 = 2388014197274 := by decide
theorem cert_e188990941722 : check e188990941722 [] .sourceHead = true := by decide
def e188990961178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990961178 : Closed e188990961178 ∧ code e188990961178 = 2388014216730 := by decide
theorem cert_e188990961178 : check e188990961178 [] .sourceHead = true := by decide
def e188990962202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990962202 : Closed e188990962202 ∧ code e188990962202 = 2388014217754 := by decide
theorem cert_e188990962202 : check e188990962202 [] .sourceHead = true := by decide
def e188990986778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188990986778 : Closed e188990986778 ∧ code e188990986778 = 2388014242330 := by decide
theorem cert_e188990986778 : check e188990986778 [] .sourceHead = true := by decide
def e188991893018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188991893018 : Closed e188991893018 ∧ code e188991893018 = 2388015148570 := by decide
theorem cert_e188991893018 : check e188991893018 [] .sourceHead = true := by decide
def e188991895066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188991895066 : Closed e188991895066 ∧ code e188991895066 = 2388015150618 := by decide
theorem cert_e188991895066 : check e188991895066 [] .sourceHead = true := by decide
def e188991909402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188991909402 : Closed e188991909402 ∧ code e188991909402 = 2388015164954 := by decide
theorem cert_e188991909402 : check e188991909402 [] .sourceHead = true := by decide
def e188991912474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188991912474 : Closed e188991912474 ∧ code e188991912474 = 2388015168026 := by decide
theorem cert_e188991912474 : check e188991912474 [] .sourceHead = true := by decide
def e188991919642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188991919642 : Closed e188991919642 ∧ code e188991919642 = 2388015175194 := by decide
theorem cert_e188991919642 : check e188991919642 [] .sourceHead = true := by decide
def e188991920666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188991920666 : Closed e188991920666 ∧ code e188991920666 = 2388015176218 := by decide
theorem cert_e188991920666 : check e188991920666 [] .sourceHead = true := by decide
def e188991991322 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188991991322 : Closed e188991991322 ∧ code e188991991322 = 2388015246874 := by decide
theorem cert_e188991991322 : check e188991991322 [] .sourceHead = true := by decide
def e188991993370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188991993370 : Closed e188991993370 ∧ code e188991993370 = 2388015248922 := by decide
theorem cert_e188991993370 : check e188991993370 [] .sourceHead = true := by decide
def e188992089626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188992089626 : Closed e188992089626 ∧ code e188992089626 = 2388015345178 := by decide
theorem cert_e188992089626 : check e188992089626 [] .sourceHead = true := by decide
def e188992092698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188992092698 : Closed e188992092698 ∧ code e188992092698 = 2388015348250 := by decide
theorem cert_e188992092698 : check e188992092698 [] .sourceHead = true := by decide
def e188992140826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188992140826 : Closed e188992140826 ∧ code e188992140826 = 2388015396378 := by decide
theorem cert_e188992140826 : check e188992140826 [] .sourceHead = true := by decide
def e188992141850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188992141850 : Closed e188992141850 ∧ code e188992141850 = 2388015397402 := by decide
theorem cert_e188992141850 : check e188992141850 [] .sourceHead = true := by decide
def e188993613338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188993613338 : Closed e188993613338 ∧ code e188993613338 = 2388016868890 := by decide
theorem cert_e188993613338 : check e188993613338 [] .sourceHead = true := by decide
def e188993616410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188993616410 : Closed e188993616410 ∧ code e188993616410 = 2388016871962 := by decide
theorem cert_e188993616410 : check e188993616410 [] .sourceHead = true := by decide
def e188993628698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188993628698 : Closed e188993628698 ∧ code e188993628698 = 2388016884250 := by decide
theorem cert_e188993628698 : check e188993628698 [] .sourceHead = true := by decide
def e188993662490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188993662490 : Closed e188993662490 ∧ code e188993662490 = 2388016918042 := by decide
theorem cert_e188993662490 : check e188993662490 [] .sourceHead = true := by decide
def e188993665562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188993665562 : Closed e188993665562 ∧ code e188993665562 = 2388016921114 := by decide
theorem cert_e188993665562 : check e188993665562 [] .sourceHead = true := by decide
def e188993739290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188993739290 : Closed e188993739290 ∧ code e188993739290 = 2388016994842 := by decide
theorem cert_e188993739290 : check e188993739290 [] .sourceHead = true := by decide
def e188994475546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188994475546 : Closed e188994475546 ∧ code e188994475546 = 2388017731098 := by decide
theorem cert_e188994475546 : check e188994475546 [] .sourceHead = true := by decide
def e188994476570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188994476570 : Closed e188994476570 ∧ code e188994476570 = 2388017732122 := by decide
theorem cert_e188994476570 : check e188994476570 [] .sourceHead = true := by decide
def e188994480666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188994480666 : Closed e188994480666 ∧ code e188994480666 = 2388017736218 := by decide
theorem cert_e188994480666 : check e188994480666 [] .sourceHead = true := by decide
def e188994500122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188994500122 : Closed e188994500122 ∧ code e188994500122 = 2388017755674 := by decide
theorem cert_e188994500122 : check e188994500122 [] .sourceHead = true := by decide
def e188994501146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188994501146 : Closed e188994501146 ∧ code e188994501146 = 2388017756698 := by decide
theorem cert_e188994501146 : check e188994501146 [] .sourceHead = true := by decide
def e188994525722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e188994525722 : Closed e188994525722 ∧ code e188994525722 = 2388017781274 := by decide
theorem cert_e188994525722 : check e188994525722 [] .sourceHead = true := by decide
def e189024024602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189024024602 : Closed e189024024602 ∧ code e189024024602 = 2388047280154 := by decide
theorem cert_e189024024602 : check e189024024602 [] .sourceHead = true := by decide
def e189024032794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189024032794 : Closed e189024032794 ∧ code e189024032794 = 2388047288346 := by decide
theorem cert_e189024032794 : check e189024032794 [] .sourceHead = true := by decide
def e189024090138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189024090138 : Closed e189024090138 ∧ code e189024090138 = 2388047345690 := by decide
theorem cert_e189024090138 : check e189024090138 [] .sourceHead = true := by decide
def e189024102426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189024102426 : Closed e189024102426 ∧ code e189024102426 = 2388047357978 := by decide
theorem cert_e189024102426 : check e189024102426 [] .sourceHead = true := by decide
def e189024103962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189024103962 : Closed e189024103962 ∧ code e189024103962 = 2388047359514 := by decide
theorem cert_e189024103962 : check e189024103962 [] .sourceHead = true := by decide
def e189024131098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189024131098 : Closed e189024131098 ∧ code e189024131098 = 2388047386650 := by decide
theorem cert_e189024131098 : check e189024131098 [] .sourceHead = true := by decide
def e189024135194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189024135194 : Closed e189024135194 ∧ code e189024135194 = 2388047390746 := by decide
theorem cert_e189024135194 : check e189024135194 [] .sourceHead = true := by decide
def e189024136730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189024136730 : Closed e189024136730 ∧ code e189024136730 = 2388047392282 := by decide
theorem cert_e189024136730 : check e189024136730 [] .sourceHead = true := by decide
def e189024138778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189024138778 : Closed e189024138778 ∧ code e189024138778 = 2388047394330 := by decide
theorem cert_e189024138778 : check e189024138778 [] .sourceHead = true := by decide
def e189024352282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189024352282 : Closed e189024352282 ∧ code e189024352282 = 2388047607834 := by decide
theorem cert_e189024352282 : check e189024352282 [] .sourceHead = true := by decide
def e189024364570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189024364570 : Closed e189024364570 ∧ code e189024364570 = 2388047620122 := by decide
theorem cert_e189024364570 : check e189024364570 [] .sourceHead = true := by decide
def e189024366106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189024366106 : Closed e189024366106 ∧ code e189024366106 = 2388047621658 := by decide
theorem cert_e189024366106 : check e189024366106 [] .sourceHead = true := by decide
def e189024413722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189024413722 : Closed e189024413722 ∧ code e189024413722 = 2388047669274 := by decide
theorem cert_e189024413722 : check e189024413722 [] .sourceHead = true := by decide
def e189024415258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189024415258 : Closed e189024415258 ∧ code e189024415258 = 2388047670810 := by decide
theorem cert_e189024415258 : check e189024415258 [] .sourceHead = true := by decide
def e189024418330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189024418330 : Closed e189024418330 ∧ code e189024418330 = 2388047673882 := by decide
theorem cert_e189024418330 : check e189024418330 [] .sourceHead = true := by decide
def e189024524314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189024524314 : Closed e189024524314 ∧ code e189024524314 = 2388047779866 := by decide
theorem cert_e189024524314 : check e189024524314 [] .sourceHead = true := by decide
def e189024528410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189024528410 : Closed e189024528410 ∧ code e189024528410 = 2388047783962 := by decide
theorem cert_e189024528410 : check e189024528410 [] .sourceHead = true := by decide
def e189024529946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189024529946 : Closed e189024529946 ∧ code e189024529946 = 2388047785498 := by decide
theorem cert_e189024529946 : check e189024529946 [] .sourceHead = true := by decide
def e189024531994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189024531994 : Closed e189024531994 ∧ code e189024531994 = 2388047787546 := by decide
theorem cert_e189024531994 : check e189024531994 [] .sourceHead = true := by decide
def e189024544794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189024544794 : Closed e189024544794 ∧ code e189024544794 = 2388047800346 := by decide
theorem cert_e189024544794 : check e189024544794 [] .sourceHead = true := by decide
def e189024546330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189024546330 : Closed e189024546330 ∧ code e189024546330 = 2388047801882 := by decide
theorem cert_e189024546330 : check e189024546330 [] .sourceHead = true := by decide
def e189024549402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189024549402 : Closed e189024549402 ∧ code e189024549402 = 2388047804954 := by decide
theorem cert_e189024549402 : check e189024549402 [] .sourceHead = true := by decide
def e189024556570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189024556570 : Closed e189024556570 ∧ code e189024556570 = 2388047812122 := by decide
theorem cert_e189024556570 : check e189024556570 [] .sourceHead = true := by decide
def e189024557594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189024557594 : Closed e189024557594 ∧ code e189024557594 = 2388047813146 := by decide
theorem cert_e189024557594 : check e189024557594 [] .sourceHead = true := by decide
def e189025597466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189025597466 : Closed e189025597466 ∧ code e189025597466 = 2388048853018 := by decide
theorem cert_e189025597466 : check e189025597466 [] .sourceHead = true := by decide
def e189025605658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189025605658 : Closed e189025605658 ∧ code e189025605658 = 2388048861210 := by decide
theorem cert_e189025605658 : check e189025605658 [] .sourceHead = true := by decide
def e189025663002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189025663002 : Closed e189025663002 ∧ code e189025663002 = 2388048918554 := by decide
theorem cert_e189025663002 : check e189025663002 [] .sourceHead = true := by decide
def e189025675290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189025675290 : Closed e189025675290 ∧ code e189025675290 = 2388048930842 := by decide
theorem cert_e189025675290 : check e189025675290 [] .sourceHead = true := by decide
def e189025676826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189025676826 : Closed e189025676826 ∧ code e189025676826 = 2388048932378 := by decide
theorem cert_e189025676826 : check e189025676826 [] .sourceHead = true := by decide
def e189025703962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189025703962 : Closed e189025703962 ∧ code e189025703962 = 2388048959514 := by decide
theorem cert_e189025703962 : check e189025703962 [] .sourceHead = true := by decide
def e189025708058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189025708058 : Closed e189025708058 ∧ code e189025708058 = 2388048963610 := by decide
theorem cert_e189025708058 : check e189025708058 [] .sourceHead = true := by decide
def e189025709594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189025709594 : Closed e189025709594 ∧ code e189025709594 = 2388048965146 := by decide
theorem cert_e189025709594 : check e189025709594 [] .sourceHead = true := by decide
def e189025711642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189025711642 : Closed e189025711642 ∧ code e189025711642 = 2388048967194 := by decide
theorem cert_e189025711642 : check e189025711642 [] .sourceHead = true := by decide
def e189025990682 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189025990682 : Closed e189025990682 ∧ code e189025990682 = 2388049246234 := by decide
theorem cert_e189025990682 : check e189025990682 [] .sourceHead = true := by decide
def e189025998874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189025998874 : Closed e189025998874 ∧ code e189025998874 = 2388049254426 := by decide
theorem cert_e189025998874 : check e189025998874 [] .sourceHead = true := by decide
def e189026383898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189026383898 : Closed e189026383898 ∧ code e189026383898 = 2388049639450 := by decide
theorem cert_e189026383898 : check e189026383898 [] .sourceHead = true := by decide
def e189026396186 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189026396186 : Closed e189026396186 ∧ code e189026396186 = 2388049651738 := by decide
theorem cert_e189026396186 : check e189026396186 [] .sourceHead = true := by decide
def e189026397722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189026397722 : Closed e189026397722 ∧ code e189026397722 = 2388049653274 := by decide
theorem cert_e189026397722 : check e189026397722 [] .sourceHead = true := by decide
def e189026588698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189026588698 : Closed e189026588698 ∧ code e189026588698 = 2388049844250 := by decide
theorem cert_e189026588698 : check e189026588698 [] .sourceHead = true := by decide
def e189026592794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189026592794 : Closed e189026592794 ∧ code e189026592794 = 2388049848346 := by decide
theorem cert_e189026592794 : check e189026592794 [] .sourceHead = true := by decide
def e189026594330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189026594330 : Closed e189026594330 ∧ code e189026594330 = 2388049849882 := by decide
theorem cert_e189026594330 : check e189026594330 [] .sourceHead = true := by decide
def e189026596378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189026596378 : Closed e189026596378 ∧ code e189026596378 = 2388049851930 := by decide
theorem cert_e189026596378 : check e189026596378 [] .sourceHead = true := by decide
def e189027235866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189027235866 : Closed e189027235866 ∧ code e189027235866 = 2388050491418 := by decide
theorem cert_e189027235866 : check e189027235866 [] .sourceHead = true := by decide
def e189027248154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189027248154 : Closed e189027248154 ∧ code e189027248154 = 2388050503706 := by decide
theorem cert_e189027248154 : check e189027248154 [] .sourceHead = true := by decide
def e189027249690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189027249690 : Closed e189027249690 ∧ code e189027249690 = 2388050505242 := by decide
theorem cert_e189027249690 : check e189027249690 [] .sourceHead = true := by decide
def e189027297306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189027297306 : Closed e189027297306 ∧ code e189027297306 = 2388050552858 := by decide
theorem cert_e189027297306 : check e189027297306 [] .sourceHead = true := by decide
def e189027298842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189027298842 : Closed e189027298842 ∧ code e189027298842 = 2388050554394 := by decide
theorem cert_e189027298842 : check e189027298842 [] .sourceHead = true := by decide
def e189027301914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189027301914 : Closed e189027301914 ∧ code e189027301914 = 2388050557466 := by decide
theorem cert_e189027301914 : check e189027301914 [] .sourceHead = true := by decide
def e189027432474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189027432474 : Closed e189027432474 ∧ code e189027432474 = 2388050688026 := by decide
theorem cert_e189027432474 : check e189027432474 [] .sourceHead = true := by decide
def e189027444762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189027444762 : Closed e189027444762 ∧ code e189027444762 = 2388050700314 := by decide
theorem cert_e189027444762 : check e189027444762 [] .sourceHead = true := by decide
def e189027446298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189027446298 : Closed e189027446298 ∧ code e189027446298 = 2388050701850 := by decide
theorem cert_e189027446298 : check e189027446298 [] .sourceHead = true := by decide
def e189027739674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189027739674 : Closed e189027739674 ∧ code e189027739674 = 2388050995226 := by decide
theorem cert_e189027739674 : check e189027739674 [] .sourceHead = true := by decide
def e189027741210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189027741210 : Closed e189027741210 ∧ code e189027741210 = 2388050996762 := by decide
theorem cert_e189027741210 : check e189027741210 [] .sourceHead = true := by decide
def e189027744282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189027744282 : Closed e189027744282 ∧ code e189027744282 = 2388050999834 := by decide
theorem cert_e189027744282 : check e189027744282 [] .sourceHead = true := by decide
def e189028063258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189028063258 : Closed e189028063258 ∧ code e189028063258 = 2388051318810 := by decide
theorem cert_e189028063258 : check e189028063258 [] .sourceHead = true := by decide
def e189028067354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189028067354 : Closed e189028067354 ∧ code e189028067354 = 2388051322906 := by decide
theorem cert_e189028067354 : check e189028067354 [] .sourceHead = true := by decide
def e189028068890 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189028068890 : Closed e189028068890 ∧ code e189028068890 = 2388051324442 := by decide
theorem cert_e189028068890 : check e189028068890 [] .sourceHead = true := by decide
def e189028070938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189028070938 : Closed e189028070938 ∧ code e189028070938 = 2388051326490 := by decide
theorem cert_e189028070938 : check e189028070938 [] .sourceHead = true := by decide
def e189028083738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189028083738 : Closed e189028083738 ∧ code e189028083738 = 2388051339290 := by decide
theorem cert_e189028083738 : check e189028083738 [] .sourceHead = true := by decide
def e189028085274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189028085274 : Closed e189028085274 ∧ code e189028085274 = 2388051340826 := by decide
theorem cert_e189028085274 : check e189028085274 [] .sourceHead = true := by decide
def e189028088346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189028088346 : Closed e189028088346 ∧ code e189028088346 = 2388051343898 := by decide
theorem cert_e189028088346 : check e189028088346 [] .sourceHead = true := by decide
def e189028095514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189028095514 : Closed e189028095514 ∧ code e189028095514 = 2388051351066 := by decide
theorem cert_e189028095514 : check e189028095514 [] .sourceHead = true := by decide
def e189028096538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189028096538 : Closed e189028096538 ∧ code e189028096538 = 2388051352090 := by decide
theorem cert_e189028096538 : check e189028096538 [] .sourceHead = true := by decide
def e189028161562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189028161562 : Closed e189028161562 ∧ code e189028161562 = 2388051417114 := by decide
theorem cert_e189028161562 : check e189028161562 [] .sourceHead = true := by decide
def e189028165658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189028165658 : Closed e189028165658 ∧ code e189028165658 = 2388051421210 := by decide
theorem cert_e189028165658 : check e189028165658 [] .sourceHead = true := by decide
def e189028167194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189028167194 : Closed e189028167194 ∧ code e189028167194 = 2388051422746 := by decide
theorem cert_e189028167194 : check e189028167194 [] .sourceHead = true := by decide
def e189028169242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189028169242 : Closed e189028169242 ∧ code e189028169242 = 2388051424794 := by decide
theorem cert_e189028169242 : check e189028169242 [] .sourceHead = true := by decide
def e189028263962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189028263962 : Closed e189028263962 ∧ code e189028263962 = 2388051519514 := by decide
theorem cert_e189028263962 : check e189028263962 [] .sourceHead = true := by decide
def e189028265498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189028265498 : Closed e189028265498 ∧ code e189028265498 = 2388051521050 := by decide
theorem cert_e189028265498 : check e189028265498 [] .sourceHead = true := by decide
def e189028268570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189028268570 : Closed e189028268570 ∧ code e189028268570 = 2388051524122 := by decide
theorem cert_e189028268570 : check e189028268570 [] .sourceHead = true := by decide
def e189028316698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189028316698 : Closed e189028316698 ∧ code e189028316698 = 2388051572250 := by decide
theorem cert_e189028316698 : check e189028316698 [] .sourceHead = true := by decide
def e189028317722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189028317722 : Closed e189028317722 ∧ code e189028317722 = 2388051573274 := by decide
theorem cert_e189028317722 : check e189028317722 [] .sourceHead = true := by decide
def e189029641754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189029641754 : Closed e189029641754 ∧ code e189029641754 = 2388052897306 := by decide
theorem cert_e189029641754 : check e189029641754 [] .sourceHead = true := by decide
def e189029643802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189029643802 : Closed e189029643802 ∧ code e189029643802 = 2388052899354 := by decide
theorem cert_e189029643802 : check e189029643802 [] .sourceHead = true := by decide
def e189029658138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189029658138 : Closed e189029658138 ∧ code e189029658138 = 2388052913690 := by decide
theorem cert_e189029658138 : check e189029658138 [] .sourceHead = true := by decide
def e189029661210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189029661210 : Closed e189029661210 ∧ code e189029661210 = 2388052916762 := by decide
theorem cert_e189029661210 : check e189029661210 [] .sourceHead = true := by decide
def e189029668378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189029668378 : Closed e189029668378 ∧ code e189029668378 = 2388052923930 := by decide
theorem cert_e189029668378 : check e189029668378 [] .sourceHead = true := by decide
def e189029669402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189029669402 : Closed e189029669402 ∧ code e189029669402 = 2388052924954 := by decide
theorem cert_e189029669402 : check e189029669402 [] .sourceHead = true := by decide
def e189029740058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189029740058 : Closed e189029740058 ∧ code e189029740058 = 2388052995610 := by decide
theorem cert_e189029740058 : check e189029740058 [] .sourceHead = true := by decide
def e189029742106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189029742106 : Closed e189029742106 ∧ code e189029742106 = 2388052997658 := by decide
theorem cert_e189029742106 : check e189029742106 [] .sourceHead = true := by decide
def e189029838362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189029838362 : Closed e189029838362 ∧ code e189029838362 = 2388053093914 := by decide
theorem cert_e189029838362 : check e189029838362 [] .sourceHead = true := by decide
def e189029841434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189029841434 : Closed e189029841434 ∧ code e189029841434 = 2388053096986 := by decide
theorem cert_e189029841434 : check e189029841434 [] .sourceHead = true := by decide
def e189029889562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189029889562 : Closed e189029889562 ∧ code e189029889562 = 2388053145114 := by decide
theorem cert_e189029889562 : check e189029889562 [] .sourceHead = true := by decide
def e189029890586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189029890586 : Closed e189029890586 ∧ code e189029890586 = 2388053146138 := by decide
theorem cert_e189029890586 : check e189029890586 [] .sourceHead = true := by decide
def e189031888922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189031888922 : Closed e189031888922 ∧ code e189031888922 = 2388055144474 := by decide
theorem cert_e189031888922 : check e189031888922 [] .sourceHead = true := by decide
def e189031897114 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189031897114 : Closed e189031897114 ∧ code e189031897114 = 2388055152666 := by decide
theorem cert_e189031897114 : check e189031897114 [] .sourceHead = true := by decide
def e189031954458 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189031954458 : Closed e189031954458 ∧ code e189031954458 = 2388055210010 := by decide
theorem cert_e189031954458 : check e189031954458 [] .sourceHead = true := by decide
def e189031966746 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189031966746 : Closed e189031966746 ∧ code e189031966746 = 2388055222298 := by decide
theorem cert_e189031966746 : check e189031966746 [] .sourceHead = true := by decide
def e189031968282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189031968282 : Closed e189031968282 ∧ code e189031968282 = 2388055223834 := by decide
theorem cert_e189031968282 : check e189031968282 [] .sourceHead = true := by decide
def e189031995418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189031995418 : Closed e189031995418 ∧ code e189031995418 = 2388055250970 := by decide
theorem cert_e189031995418 : check e189031995418 [] .sourceHead = true := by decide
def e189031999514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189031999514 : Closed e189031999514 ∧ code e189031999514 = 2388055255066 := by decide
theorem cert_e189031999514 : check e189031999514 [] .sourceHead = true := by decide
def e189032001050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189032001050 : Closed e189032001050 ∧ code e189032001050 = 2388055256602 := by decide
theorem cert_e189032001050 : check e189032001050 [] .sourceHead = true := by decide
def e189032003098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189032003098 : Closed e189032003098 ∧ code e189032003098 = 2388055258650 := by decide
theorem cert_e189032003098 : check e189032003098 [] .sourceHead = true := by decide
def e189032282138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189032282138 : Closed e189032282138 ∧ code e189032282138 = 2388055537690 := by decide
theorem cert_e189032282138 : check e189032282138 [] .sourceHead = true := by decide
def e189032290330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189032290330 : Closed e189032290330 ∧ code e189032290330 = 2388055545882 := by decide
theorem cert_e189032290330 : check e189032290330 [] .sourceHead = true := by decide
def e189032675354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189032675354 : Closed e189032675354 ∧ code e189032675354 = 2388055930906 := by decide
theorem cert_e189032675354 : check e189032675354 [] .sourceHead = true := by decide
def e189032687642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189032687642 : Closed e189032687642 ∧ code e189032687642 = 2388055943194 := by decide
theorem cert_e189032687642 : check e189032687642 [] .sourceHead = true := by decide
def e189032689178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189032689178 : Closed e189032689178 ∧ code e189032689178 = 2388055944730 := by decide
theorem cert_e189032689178 : check e189032689178 [] .sourceHead = true := by decide
def e189032880154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189032880154 : Closed e189032880154 ∧ code e189032880154 = 2388056135706 := by decide
theorem cert_e189032880154 : check e189032880154 [] .sourceHead = true := by decide
def e189032884250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189032884250 : Closed e189032884250 ∧ code e189032884250 = 2388056139802 := by decide
theorem cert_e189032884250 : check e189032884250 [] .sourceHead = true := by decide
def e189032885786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189032885786 : Closed e189032885786 ∧ code e189032885786 = 2388056141338 := by decide
theorem cert_e189032885786 : check e189032885786 [] .sourceHead = true := by decide
def e189032887834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189032887834 : Closed e189032887834 ∧ code e189032887834 = 2388056143386 := by decide
theorem cert_e189032887834 : check e189032887834 [] .sourceHead = true := by decide
def e189038770202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189038770202 : Closed e189038770202 ∧ code e189038770202 = 2388062025754 := by decide
theorem cert_e189038770202 : check e189038770202 [] .sourceHead = true := by decide
def e189038782490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189038782490 : Closed e189038782490 ∧ code e189038782490 = 2388062038042 := by decide
theorem cert_e189038782490 : check e189038782490 [] .sourceHead = true := by decide
def e189038784026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189038784026 : Closed e189038784026 ∧ code e189038784026 = 2388062039578 := by decide
theorem cert_e189038784026 : check e189038784026 [] .sourceHead = true := by decide
def e189038831642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189038831642 : Closed e189038831642 ∧ code e189038831642 = 2388062087194 := by decide
theorem cert_e189038831642 : check e189038831642 [] .sourceHead = true := by decide
def e189038833178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189038833178 : Closed e189038833178 ∧ code e189038833178 = 2388062088730 := by decide
theorem cert_e189038833178 : check e189038833178 [] .sourceHead = true := by decide
def e189038836250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189038836250 : Closed e189038836250 ∧ code e189038836250 = 2388062091802 := by decide
theorem cert_e189038836250 : check e189038836250 [] .sourceHead = true := by decide
def e189038966810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189038966810 : Closed e189038966810 ∧ code e189038966810 = 2388062222362 := by decide
theorem cert_e189038966810 : check e189038966810 [] .sourceHead = true := by decide
def e189038979098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189038979098 : Closed e189038979098 ∧ code e189038979098 = 2388062234650 := by decide
theorem cert_e189038979098 : check e189038979098 [] .sourceHead = true := by decide
def e189038980634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189038980634 : Closed e189038980634 ∧ code e189038980634 = 2388062236186 := by decide
theorem cert_e189038980634 : check e189038980634 [] .sourceHead = true := by decide
def e189039274010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189039274010 : Closed e189039274010 ∧ code e189039274010 = 2388062529562 := by decide
theorem cert_e189039274010 : check e189039274010 [] .sourceHead = true := by decide
def e189039275546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189039275546 : Closed e189039275546 ∧ code e189039275546 = 2388062531098 := by decide
theorem cert_e189039275546 : check e189039275546 [] .sourceHead = true := by decide
def e189039278618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189039278618 : Closed e189039278618 ∧ code e189039278618 = 2388062534170 := by decide
theorem cert_e189039278618 : check e189039278618 [] .sourceHead = true := by decide
def e189042219034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189042219034 : Closed e189042219034 ∧ code e189042219034 = 2388065474586 := by decide
theorem cert_e189042219034 : check e189042219034 [] .sourceHead = true := by decide
def e189042223130 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189042223130 : Closed e189042223130 ∧ code e189042223130 = 2388065478682 := by decide
theorem cert_e189042223130 : check e189042223130 [] .sourceHead = true := by decide
def e189042224666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189042224666 : Closed e189042224666 ∧ code e189042224666 = 2388065480218 := by decide
theorem cert_e189042224666 : check e189042224666 [] .sourceHead = true := by decide
def e189042226714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189042226714 : Closed e189042226714 ∧ code e189042226714 = 2388065482266 := by decide
theorem cert_e189042226714 : check e189042226714 [] .sourceHead = true := by decide
def e189042239514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189042239514 : Closed e189042239514 ∧ code e189042239514 = 2388065495066 := by decide
theorem cert_e189042239514 : check e189042239514 [] .sourceHead = true := by decide
def e189042241050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189042241050 : Closed e189042241050 ∧ code e189042241050 = 2388065496602 := by decide
theorem cert_e189042241050 : check e189042241050 [] .sourceHead = true := by decide
def e189042244122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189042244122 : Closed e189042244122 ∧ code e189042244122 = 2388065499674 := by decide
theorem cert_e189042244122 : check e189042244122 [] .sourceHead = true := by decide
def e189042251290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189042251290 : Closed e189042251290 ∧ code e189042251290 = 2388065506842 := by decide
theorem cert_e189042251290 : check e189042251290 [] .sourceHead = true := by decide
def e189042252314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189042252314 : Closed e189042252314 ∧ code e189042252314 = 2388065507866 := by decide
theorem cert_e189042252314 : check e189042252314 [] .sourceHead = true := by decide
def e189042317338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189042317338 : Closed e189042317338 ∧ code e189042317338 = 2388065572890 := by decide
theorem cert_e189042317338 : check e189042317338 [] .sourceHead = true := by decide
def e189042321434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189042321434 : Closed e189042321434 ∧ code e189042321434 = 2388065576986 := by decide
theorem cert_e189042321434 : check e189042321434 [] .sourceHead = true := by decide
def e189042322970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189042322970 : Closed e189042322970 ∧ code e189042322970 = 2388065578522 := by decide
theorem cert_e189042322970 : check e189042322970 [] .sourceHead = true := by decide
def e189042325018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e189042325018 : Closed e189042325018 ∧ code e189042325018 = 2388065580570 := by decide
theorem cert_e189042325018 : check e189042325018 [] .sourceHead = true := by decide
def e189042419738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e189042419738 : Closed e189042419738 ∧ code e189042419738 = 2388065675290 := by decide
theorem cert_e189042419738 : check e189042419738 [] .sourceHead = true := by decide
end Blc.Floor41
