import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605593327678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 4)))))))))
theorem wire_e605593327678 : Closed e605593327678 ∧ code e605593327678 = 2804616583230 := by decide
theorem cert_e605593327678 : check e605593327678 [[],[]] .smaller = true := by decide
def e605593328094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e605593328094 : Closed e605593328094 ∧ code e605593328094 = 2804616583646 := by decide
theorem cert_e605593328094 : check e605593328094 [[],[]] .three = true := by decide
def e605593328098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605593328098 : Closed e605593328098 ∧ code e605593328098 = 2804616583650 := by decide
theorem cert_e605593328098 : check e605593328098 [[],[]] .smaller = true := by decide
def e605593328110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2))))))))
theorem wire_e605593328110 : Closed e605593328110 ∧ code e605593328110 = 2804616583662 := by decide
theorem cert_e605593328110 : check e605593328110 [[],[]] .smaller = true := by decide
def e605593328118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e605593328118 : Closed e605593328118 ∧ code e605593328118 = 2804616583670 := by decide
theorem cert_e605593328118 : check e605593328118 [[],[]] .three = true := by decide
def e605593328670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 3)))))))))
theorem wire_e605593328670 : Closed e605593328670 ∧ code e605593328670 = 2804616584222 := by decide
theorem cert_e605593328670 : check e605593328670 [[],[]] .smaller = true := by decide
def e605593328862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e605593328862 : Closed e605593328862 ∧ code e605593328862 = 2804616584414 := by decide
theorem cert_e605593328862 : check e605593328862 [[],[]] .three = true := by decide
def e605593328866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e605593328866 : Closed e605593328866 ∧ code e605593328866 = 2804616584418 := by decide
theorem cert_e605593328866 : check e605593328866 [[],[]] .smaller = true := by decide
def e605593328878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e605593328878 : Closed e605593328878 ∧ code e605593328878 = 2804616584430 := by decide
theorem cert_e605593328878 : check e605593328878 [[],[]] .smaller = true := by decide
def e605593328886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e605593328886 : Closed e605593328886 ∧ code e605593328886 = 2804616584438 := by decide
theorem cert_e605593328886 : check e605593328886 [[],[]] .smaller = true := by decide
def e605593328890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e605593328890 : Closed e605593328890 ∧ code e605593328890 = 2804616584442 := by decide
theorem cert_e605593328890 : check e605593328890 [[],[]] .three = true := by decide
def e605593329262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593329262 : Closed e605593329262 ∧ code e605593329262 = 2804616584814 := by decide
theorem cert_e605593329262 : check e605593329262 [[],[]] .three = true := by decide
def e605593329270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e605593329270 : Closed e605593329270 ∧ code e605593329270 = 2804616584822 := by decide
theorem cert_e605593329270 : check e605593329270 [[],[]] .three = true := by decide
def e605593329274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593329274 : Closed e605593329274 ∧ code e605593329274 = 2804616584826 := by decide
theorem cert_e605593329274 : check e605593329274 [[],[]] .three = true := by decide
def e605593329902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 2)))))))
theorem wire_e605593329902 : Closed e605593329902 ∧ code e605593329902 = 2804616585454 := by decide
theorem cert_e605593329902 : check e605593329902 [[],[]] .smaller = true := by decide
def e605593329914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0)))))))
theorem wire_e605593329914 : Closed e605593329914 ∧ code e605593329914 = 2804616585466 := by decide
theorem cert_e605593329914 : check e605593329914 [[],[]] .smaller = true := by decide
def e605593330094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 2)))))))
theorem wire_e605593330094 : Closed e605593330094 ∧ code e605593330094 = 2804616585646 := by decide
theorem cert_e605593330094 : check e605593330094 [[],[]] .smaller = true := by decide
def e605593330286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593330286 : Closed e605593330286 ∧ code e605593330286 = 2804616585838 := by decide
theorem cert_e605593330286 : check e605593330286 [[],[]] .smaller = true := by decide
def e605593330298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593330298 : Closed e605593330298 ∧ code e605593330298 = 2804616585850 := by decide
theorem cert_e605593330298 : check e605593330298 [[],[]] .smaller = true := by decide
def e605593330462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 3))))))))
theorem wire_e605593330462 : Closed e605593330462 ∧ code e605593330462 = 2804616586014 := by decide
theorem cert_e605593330462 : check e605593330462 [[],[]] .smaller = true := by decide
def e605593330630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 1))))))))
theorem wire_e605593330630 : Closed e605593330630 ∧ code e605593330630 = 2804616586182 := by decide
theorem cert_e605593330630 : check e605593330630 [[],[]] .smaller = true := by decide
def e605593331246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e605593331246 : Closed e605593331246 ∧ code e605593331246 = 2804616586798 := by decide
theorem cert_e605593331246 : check e605593331246 [[],[]] .smaller = true := by decide
def e605593331422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e605593331422 : Closed e605593331422 ∧ code e605593331422 = 2804616586974 := by decide
theorem cert_e605593331422 : check e605593331422 [[],[]] .three = true := by decide
def e605593331426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e605593331426 : Closed e605593331426 ∧ code e605593331426 = 2804616586978 := by decide
theorem cert_e605593331426 : check e605593331426 [[],[]] .smaller = true := by decide
def e605593331438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e605593331438 : Closed e605593331438 ∧ code e605593331438 = 2804616586990 := by decide
theorem cert_e605593331438 : check e605593331438 [[],[]] .smaller = true := by decide
def e605593331446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e605593331446 : Closed e605593331446 ∧ code e605593331446 = 2804616586998 := by decide
theorem cert_e605593331446 : check e605593331446 [[],[]] .three = true := by decide
def e605593331550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e605593331550 : Closed e605593331550 ∧ code e605593331550 = 2804616587102 := by decide
theorem cert_e605593331550 : check e605593331550 [[],[]] .three = true := by decide
def e605593331566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e605593331566 : Closed e605593331566 ∧ code e605593331566 = 2804616587118 := by decide
theorem cert_e605593331566 : check e605593331566 [[],[]] .smaller = true := by decide
def e605593331574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e605593331574 : Closed e605593331574 ∧ code e605593331574 = 2804616587126 := by decide
theorem cert_e605593331574 : check e605593331574 [[],[]] .smaller = true := by decide
def e605593331578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e605593331578 : Closed e605593331578 ∧ code e605593331578 = 2804616587130 := by decide
theorem cert_e605593331578 : check e605593331578 [[],[]] .three = true := by decide
def e605593331594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605593331594 : Closed e605593331594 ∧ code e605593331594 = 2804616587146 := by decide
theorem cert_e605593331594 : check e605593331594 [[],[]] .smaller = true := by decide
def e605593331618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e605593331618 : Closed e605593331618 ∧ code e605593331618 = 2804616587170 := by decide
theorem cert_e605593331618 : check e605593331618 [[],[]] .smaller = true := by decide
def e605593331630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e605593331630 : Closed e605593331630 ∧ code e605593331630 = 2804616587182 := by decide
theorem cert_e605593331630 : check e605593331630 [[],[]] .smaller = true := by decide
def e605593331638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e605593331638 : Closed e605593331638 ∧ code e605593331638 = 2804616587190 := by decide
theorem cert_e605593331638 : check e605593331638 [[],[]] .smaller = true := by decide
def e605593331642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e605593331642 : Closed e605593331642 ∧ code e605593331642 = 2804616587194 := by decide
theorem cert_e605593331642 : check e605593331642 [[],[]] .smaller = true := by decide
def e605593331670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e605593331670 : Closed e605593331670 ∧ code e605593331670 = 2804616587222 := by decide
theorem cert_e605593331670 : check e605593331670 [[],[]] .three = true := by decide
def e605593331674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e605593331674 : Closed e605593331674 ∧ code e605593331674 = 2804616587226 := by decide
theorem cert_e605593331674 : check e605593331674 [[],[]] .three = true := by decide
def e605593331774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 4)))))))))
theorem wire_e605593331774 : Closed e605593331774 ∧ code e605593331774 = 2804616587326 := by decide
theorem cert_e605593331774 : check e605593331774 [[],[]] .smaller = true := by decide
def e605593332190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e605593332190 : Closed e605593332190 ∧ code e605593332190 = 2804616587742 := by decide
theorem cert_e605593332190 : check e605593332190 [[],[]] .three = true := by decide
def e605593332194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605593332194 : Closed e605593332194 ∧ code e605593332194 = 2804616587746 := by decide
theorem cert_e605593332194 : check e605593332194 [[],[]] .smaller = true := by decide
def e605593332206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2))))))))
theorem wire_e605593332206 : Closed e605593332206 ∧ code e605593332206 = 2804616587758 := by decide
theorem cert_e605593332206 : check e605593332206 [[],[]] .smaller = true := by decide
def e605593332214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e605593332214 : Closed e605593332214 ∧ code e605593332214 = 2804616587766 := by decide
theorem cert_e605593332214 : check e605593332214 [[],[]] .three = true := by decide
def e605593332958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e605593332958 : Closed e605593332958 ∧ code e605593332958 = 2804616588510 := by decide
theorem cert_e605593332958 : check e605593332958 [[],[]] .three = true := by decide
def e605593332974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e605593332974 : Closed e605593332974 ∧ code e605593332974 = 2804616588526 := by decide
theorem cert_e605593332974 : check e605593332974 [[],[]] .smaller = true := by decide
def e605593332982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e605593332982 : Closed e605593332982 ∧ code e605593332982 = 2804616588534 := by decide
theorem cert_e605593332982 : check e605593332982 [[],[]] .smaller = true := by decide
def e605593332986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e605593332986 : Closed e605593332986 ∧ code e605593332986 = 2804616588538 := by decide
theorem cert_e605593332986 : check e605593332986 [[],[]] .three = true := by decide
def e605593333262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 2)))))))))
theorem wire_e605593333262 : Closed e605593333262 ∧ code e605593333262 = 2804616588814 := by decide
theorem cert_e605593333262 : check e605593333262 [[],[]] .smaller = true := by decide
def e605593333274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605593333274 : Closed e605593333274 ∧ code e605593333274 = 2804616588826 := by decide
theorem cert_e605593333274 : check e605593333274 [[],[]] .smaller = true := by decide
def e605593333346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605593333346 : Closed e605593333346 ∧ code e605593333346 = 2804616588898 := by decide
theorem cert_e605593333346 : check e605593333346 [[],[]] .smaller = true := by decide
def e605593333358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593333358 : Closed e605593333358 ∧ code e605593333358 = 2804616588910 := by decide
theorem cert_e605593333358 : check e605593333358 [[],[]] .smaller = true := by decide
def e605593333366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e605593333366 : Closed e605593333366 ∧ code e605593333366 = 2804616588918 := by decide
theorem cert_e605593333366 : check e605593333366 [[],[]] .smaller = true := by decide
def e605593333370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593333370 : Closed e605593333370 ∧ code e605593333370 = 2804616588922 := by decide
theorem cert_e605593333370 : check e605593333370 [[],[]] .smaller = true := by decide
def e605593333558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593333558 : Closed e605593333558 ∧ code e605593333558 = 2804616589110 := by decide
theorem cert_e605593333558 : check e605593333558 [[],[]] .three = true := by decide
def e605593333562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593333562 : Closed e605593333562 ∧ code e605593333562 = 2804616589114 := by decide
theorem cert_e605593333562 : check e605593333562 [[],[]] .three = true := by decide
def e605593333878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 1)))))))
theorem wire_e605593333878 : Closed e605593333878 ∧ code e605593333878 = 2804616589430 := by decide
theorem cert_e605593333878 : check e605593333878 [[],[]] .smaller = true := by decide
def e605593333882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0)))))))
theorem wire_e605593333882 : Closed e605593333882 ∧ code e605593333882 = 2804616589434 := by decide
theorem cert_e605593333882 : check e605593333882 [[],[]] .smaller = true := by decide
def e605593333974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e605593333974 : Closed e605593333974 ∧ code e605593333974 = 2804616589526 := by decide
theorem cert_e605593333974 : check e605593333974 [[],[]] .smaller = true := by decide
def e605593334070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593334070 : Closed e605593334070 ∧ code e605593334070 = 2804616589622 := by decide
theorem cert_e605593334070 : check e605593334070 [[],[]] .smaller = true := by decide
def e605593334074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593334074 : Closed e605593334074 ∧ code e605593334074 = 2804616589626 := by decide
theorem cert_e605593334074 : check e605593334074 [[],[]] .smaller = true := by decide
def e605593334158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 2))))))))
theorem wire_e605593334158 : Closed e605593334158 ∧ code e605593334158 = 2804616589710 := by decide
theorem cert_e605593334158 : check e605593334158 [[],[]] .smaller = true := by decide
def e605593334214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 1))))))))
theorem wire_e605593334214 : Closed e605593334214 ∧ code e605593334214 = 2804616589766 := by decide
theorem cert_e605593334214 : check e605593334214 [[],[]] .smaller = true := by decide
def e605593334550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e605593334550 : Closed e605593334550 ∧ code e605593334550 = 2804616590102 := by decide
theorem cert_e605593334550 : check e605593334550 [[],[]] .smaller = true := by decide
def e605593334622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e605593334622 : Closed e605593334622 ∧ code e605593334622 = 2804616590174 := by decide
theorem cert_e605593334622 : check e605593334622 [[],[]] .three = true := by decide
def e605593334626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e605593334626 : Closed e605593334626 ∧ code e605593334626 = 2804616590178 := by decide
theorem cert_e605593334626 : check e605593334626 [[],[]] .smaller = true := by decide
def e605593334638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e605593334638 : Closed e605593334638 ∧ code e605593334638 = 2804616590190 := by decide
theorem cert_e605593334638 : check e605593334638 [[],[]] .smaller = true := by decide
def e605593334646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e605593334646 : Closed e605593334646 ∧ code e605593334646 = 2804616590198 := by decide
theorem cert_e605593334646 : check e605593334646 [[],[]] .smaller = true := by decide
def e605593334650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e605593334650 : Closed e605593334650 ∧ code e605593334650 = 2804616590202 := by decide
theorem cert_e605593334650 : check e605593334650 [[],[]] .three = true := by decide
def e605593334666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605593334666 : Closed e605593334666 ∧ code e605593334666 = 2804616590218 := by decide
theorem cert_e605593334666 : check e605593334666 [[],[]] .smaller = true := by decide
def e605593334690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e605593334690 : Closed e605593334690 ∧ code e605593334690 = 2804616590242 := by decide
theorem cert_e605593334690 : check e605593334690 [[],[]] .smaller = true := by decide
def e605593334702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e605593334702 : Closed e605593334702 ∧ code e605593334702 = 2804616590254 := by decide
theorem cert_e605593334702 : check e605593334702 [[],[]] .smaller = true := by decide
def e605593334710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e605593334710 : Closed e605593334710 ∧ code e605593334710 = 2804616590262 := by decide
theorem cert_e605593334710 : check e605593334710 [[],[]] .smaller = true := by decide
def e605593334714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e605593334714 : Closed e605593334714 ∧ code e605593334714 = 2804616590266 := by decide
theorem cert_e605593334714 : check e605593334714 [[],[]] .smaller = true := by decide
def e605593334742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e605593334742 : Closed e605593334742 ∧ code e605593334742 = 2804616590294 := by decide
theorem cert_e605593334742 : check e605593334742 [[],[]] .smaller = true := by decide
def e605593334746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e605593334746 : Closed e605593334746 ∧ code e605593334746 = 2804616590298 := by decide
theorem cert_e605593334746 : check e605593334746 [[],[]] .smaller = true := by decide
def e605593334762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e605593334762 : Closed e605593334762 ∧ code e605593334762 = 2804616590314 := by decide
theorem cert_e605593334762 : check e605593334762 [[],[]] .three = true := by decide
def e605593334814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 3)))))))))
theorem wire_e605593334814 : Closed e605593334814 ∧ code e605593334814 = 2804616590366 := by decide
theorem cert_e605593334814 : check e605593334814 [[],[]] .smaller = true := by decide
def e605593335006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e605593335006 : Closed e605593335006 ∧ code e605593335006 = 2804616590558 := by decide
theorem cert_e605593335006 : check e605593335006 [[],[]] .three = true := by decide
def e605593335010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e605593335010 : Closed e605593335010 ∧ code e605593335010 = 2804616590562 := by decide
theorem cert_e605593335010 : check e605593335010 [[],[]] .smaller = true := by decide
def e605593335022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e605593335022 : Closed e605593335022 ∧ code e605593335022 = 2804616590574 := by decide
theorem cert_e605593335022 : check e605593335022 [[],[]] .smaller = true := by decide
def e605593335030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e605593335030 : Closed e605593335030 ∧ code e605593335030 = 2804616590582 := by decide
theorem cert_e605593335030 : check e605593335030 [[],[]] .smaller = true := by decide
def e605593335034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e605593335034 : Closed e605593335034 ∧ code e605593335034 = 2804616590586 := by decide
theorem cert_e605593335034 : check e605593335034 [[],[]] .three = true := by decide
def e605593335310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 2)))))))))
theorem wire_e605593335310 : Closed e605593335310 ∧ code e605593335310 = 2804616590862 := by decide
theorem cert_e605593335310 : check e605593335310 [[],[]] .smaller = true := by decide
def e605593335322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605593335322 : Closed e605593335322 ∧ code e605593335322 = 2804616590874 := by decide
theorem cert_e605593335322 : check e605593335322 [[],[]] .smaller = true := by decide
def e605593335394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605593335394 : Closed e605593335394 ∧ code e605593335394 = 2804616590946 := by decide
theorem cert_e605593335394 : check e605593335394 [[],[]] .smaller = true := by decide
def e605593335406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593335406 : Closed e605593335406 ∧ code e605593335406 = 2804616590958 := by decide
theorem cert_e605593335406 : check e605593335406 [[],[]] .smaller = true := by decide
def e605593335414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e605593335414 : Closed e605593335414 ∧ code e605593335414 = 2804616590966 := by decide
theorem cert_e605593335414 : check e605593335414 [[],[]] .smaller = true := by decide
def e605593335418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593335418 : Closed e605593335418 ∧ code e605593335418 = 2804616590970 := by decide
theorem cert_e605593335418 : check e605593335418 [[],[]] .smaller = true := by decide
def e605593335606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593335606 : Closed e605593335606 ∧ code e605593335606 = 2804616591158 := by decide
theorem cert_e605593335606 : check e605593335606 [[],[]] .smaller = true := by decide
def e605593335610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593335610 : Closed e605593335610 ∧ code e605593335610 = 2804616591162 := by decide
theorem cert_e605593335610 : check e605593335610 [[],[]] .smaller = true := by decide
def e605593335706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593335706 : Closed e605593335706 ∧ code e605593335706 = 2804616591258 := by decide
theorem cert_e605593335706 : check e605593335706 [[],[]] .three = true := by decide
def e605593336238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e605593336238 : Closed e605593336238 ∧ code e605593336238 = 2804616591790 := by decide
theorem cert_e605593336238 : check e605593336238 [[],[]] .three = true := by decide
def e605593336246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e605593336246 : Closed e605593336246 ∧ code e605593336246 = 2804616591798 := by decide
theorem cert_e605593336246 : check e605593336246 [[],[]] .three = true := by decide
def e605593336250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605593336250 : Closed e605593336250 ∧ code e605593336250 = 2804616591802 := by decide
theorem cert_e605593336250 : check e605593336250 [[],[]] .three = true := by decide
def e605593336278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e605593336278 : Closed e605593336278 ∧ code e605593336278 = 2804616591830 := by decide
theorem cert_e605593336278 : check e605593336278 [[],[]] .three = true := by decide
def e605593336282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e605593336282 : Closed e605593336282 ∧ code e605593336282 = 2804616591834 := by decide
theorem cert_e605593336282 : check e605593336282 [[],[]] .three = true := by decide
def e605593336298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605593336298 : Closed e605593336298 ∧ code e605593336298 = 2804616591850 := by decide
theorem cert_e605593336298 : check e605593336298 [[],[]] .three = true := by decide
def e605593336430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593336430 : Closed e605593336430 ∧ code e605593336430 = 2804616591982 := by decide
theorem cert_e605593336430 : check e605593336430 [[],[]] .three = true := by decide
def e605593336438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e605593336438 : Closed e605593336438 ∧ code e605593336438 = 2804616591990 := by decide
theorem cert_e605593336438 : check e605593336438 [[],[]] .three = true := by decide
def e605593336442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593336442 : Closed e605593336442 ∧ code e605593336442 = 2804616591994 := by decide
theorem cert_e605593336442 : check e605593336442 [[],[]] .three = true := by decide
def e605593336630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593336630 : Closed e605593336630 ∧ code e605593336630 = 2804616592182 := by decide
theorem cert_e605593336630 : check e605593336630 [[],[]] .three = true := by decide
def e605593336634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593336634 : Closed e605593336634 ∧ code e605593336634 = 2804616592186 := by decide
theorem cert_e605593336634 : check e605593336634 [[],[]] .three = true := by decide
def e605593336730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593336730 : Closed e605593336730 ∧ code e605593336730 = 2804616592282 := by decide
theorem cert_e605593336730 : check e605593336730 [[],[]] .three = true := by decide
def e605593340782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605593340782 : Closed e605593340782 ∧ code e605593340782 = 2804616596334 := by decide
theorem cert_e605593340782 : check e605593340782 [[],[]] .smaller = true := by decide
def e605593340790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605593340790 : Closed e605593340790 ∧ code e605593340790 = 2804616596342 := by decide
theorem cert_e605593340790 : check e605593340790 [[],[]] .smaller = true := by decide
def e605593340846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605593340846 : Closed e605593340846 ∧ code e605593340846 = 2804616596398 := by decide
theorem cert_e605593340846 : check e605593340846 [[],[]] .smaller = true := by decide
def e605593340858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605593340858 : Closed e605593340858 ∧ code e605593340858 = 2804616596410 := by decide
theorem cert_e605593340858 : check e605593340858 [[],[]] .smaller = true := by decide
def e605593340886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605593340886 : Closed e605593340886 ∧ code e605593340886 = 2804616596438 := by decide
theorem cert_e605593340886 : check e605593340886 [[],[]] .smaller = true := by decide
def e605593340890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605593340890 : Closed e605593340890 ∧ code e605593340890 = 2804616596442 := by decide
theorem cert_e605593340890 : check e605593340890 [[],[]] .smaller = true := by decide
def e605593341166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605593341166 : Closed e605593341166 ∧ code e605593341166 = 2804616596718 := by decide
theorem cert_e605593341166 : check e605593341166 [[],[]] .smaller = true := by decide
def e605593341174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605593341174 : Closed e605593341174 ∧ code e605593341174 = 2804616596726 := by decide
theorem cert_e605593341174 : check e605593341174 [[],[]] .smaller = true := by decide
def e605593341550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605593341550 : Closed e605593341550 ∧ code e605593341550 = 2804616597102 := by decide
theorem cert_e605593341550 : check e605593341550 [[],[]] .smaller = true := by decide
def e605593341562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605593341562 : Closed e605593341562 ∧ code e605593341562 = 2804616597114 := by decide
theorem cert_e605593341562 : check e605593341562 [[],[]] .smaller = true := by decide
def e605593341750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605593341750 : Closed e605593341750 ∧ code e605593341750 = 2804616597302 := by decide
theorem cert_e605593341750 : check e605593341750 [[],[]] .smaller = true := by decide
def e605593341754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605593341754 : Closed e605593341754 ∧ code e605593341754 = 2804616597306 := by decide
theorem cert_e605593341754 : check e605593341754 [[],[]] .smaller = true := by decide
def e605593341886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 4)))))))))
theorem wire_e605593341886 : Closed e605593341886 ∧ code e605593341886 = 2804616597438 := by decide
theorem cert_e605593341886 : check e605593341886 [[],[]] .three = true := by decide
def e605593341918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 4) (.var 3)))))))))
theorem wire_e605593341918 : Closed e605593341918 ∧ code e605593341918 = 2804616597470 := by decide
theorem cert_e605593341918 : check e605593341918 [[],[]] .three = true := by decide
def e605593349598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e605593349598 : Closed e605593349598 ∧ code e605593349598 = 2804616605150 := by decide
theorem cert_e605593349598 : check e605593349598 [[],[]] .three = true := by decide
def e605593349614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e605593349614 : Closed e605593349614 ∧ code e605593349614 = 2804616605166 := by decide
theorem cert_e605593349614 : check e605593349614 [[],[]] .three = true := by decide
def e605593349678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605593349678 : Closed e605593349678 ∧ code e605593349678 = 2804616605230 := by decide
theorem cert_e605593349678 : check e605593349678 [[],[]] .smaller = true := by decide
def e605593349854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e605593349854 : Closed e605593349854 ∧ code e605593349854 = 2804616605406 := by decide
theorem cert_e605593349854 : check e605593349854 [[],[]] .three = true := by decide
def e605593349858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605593349858 : Closed e605593349858 ∧ code e605593349858 = 2804616605410 := by decide
theorem cert_e605593349858 : check e605593349858 [[],[]] .smaller = true := by decide
def e605593349870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e605593349870 : Closed e605593349870 ∧ code e605593349870 = 2804616605422 := by decide
theorem cert_e605593349870 : check e605593349870 [[],[]] .smaller = true := by decide
def e605593349878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e605593349878 : Closed e605593349878 ∧ code e605593349878 = 2804616605430 := by decide
theorem cert_e605593349878 : check e605593349878 [[],[]] .three = true := by decide
def e605593349910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e605593349910 : Closed e605593349910 ∧ code e605593349910 = 2804616605462 := by decide
theorem cert_e605593349910 : check e605593349910 [[],[]] .smaller = true := by decide
def e605593349982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e605593349982 : Closed e605593349982 ∧ code e605593349982 = 2804616605534 := by decide
theorem cert_e605593349982 : check e605593349982 [[],[]] .three = true := by decide
def e605593349986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e605593349986 : Closed e605593349986 ∧ code e605593349986 = 2804616605538 := by decide
theorem cert_e605593349986 : check e605593349986 [[],[]] .smaller = true := by decide
def e605593349998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e605593349998 : Closed e605593349998 ∧ code e605593349998 = 2804616605550 := by decide
theorem cert_e605593349998 : check e605593349998 [[],[]] .smaller = true := by decide
def e605593350006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e605593350006 : Closed e605593350006 ∧ code e605593350006 = 2804616605558 := by decide
theorem cert_e605593350006 : check e605593350006 [[],[]] .smaller = true := by decide
def e605593350010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e605593350010 : Closed e605593350010 ∧ code e605593350010 = 2804616605562 := by decide
theorem cert_e605593350010 : check e605593350010 [[],[]] .three = true := by decide
def e605593350062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e605593350062 : Closed e605593350062 ∧ code e605593350062 = 2804616605614 := by decide
theorem cert_e605593350062 : check e605593350062 [[],[]] .three = true := by decide
def e605593350070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e605593350070 : Closed e605593350070 ∧ code e605593350070 = 2804616605622 := by decide
theorem cert_e605593350070 : check e605593350070 [[],[]] .three = true := by decide
def e605593350074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e605593350074 : Closed e605593350074 ∧ code e605593350074 = 2804616605626 := by decide
theorem cert_e605593350074 : check e605593350074 [[],[]] .three = true := by decide
def e605593351134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e605593351134 : Closed e605593351134 ∧ code e605593351134 = 2804616606686 := by decide
theorem cert_e605593351134 : check e605593351134 [[],[]] .three = true := by decide
def e605593351150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e605593351150 : Closed e605593351150 ∧ code e605593351150 = 2804616606702 := by decide
theorem cert_e605593351150 : check e605593351150 [[],[]] .three = true := by decide
def e605593352254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e605593352254 : Closed e605593352254 ∧ code e605593352254 = 2804616607806 := by decide
theorem cert_e605593352254 : check e605593352254 [[],[]] .smaller = true := by decide
def e605593352670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e605593352670 : Closed e605593352670 ∧ code e605593352670 = 2804616608222 := by decide
theorem cert_e605593352670 : check e605593352670 [[],[]] .three = true := by decide
def e605593352674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605593352674 : Closed e605593352674 ∧ code e605593352674 = 2804616608226 := by decide
theorem cert_e605593352674 : check e605593352674 [[],[]] .smaller = true := by decide
def e605593352686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e605593352686 : Closed e605593352686 ∧ code e605593352686 = 2804616608238 := by decide
theorem cert_e605593352686 : check e605593352686 [[],[]] .smaller = true := by decide
def e605593352694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e605593352694 : Closed e605593352694 ∧ code e605593352694 = 2804616608246 := by decide
theorem cert_e605593352694 : check e605593352694 [[],[]] .three = true := by decide
def e605593353246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e605593353246 : Closed e605593353246 ∧ code e605593353246 = 2804616608798 := by decide
theorem cert_e605593353246 : check e605593353246 [[],[]] .smaller = true := by decide
def e605593353438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e605593353438 : Closed e605593353438 ∧ code e605593353438 = 2804616608990 := by decide
theorem cert_e605593353438 : check e605593353438 [[],[]] .three = true := by decide
def e605593353442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e605593353442 : Closed e605593353442 ∧ code e605593353442 = 2804616608994 := by decide
theorem cert_e605593353442 : check e605593353442 [[],[]] .smaller = true := by decide
def e605593353454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e605593353454 : Closed e605593353454 ∧ code e605593353454 = 2804616609006 := by decide
theorem cert_e605593353454 : check e605593353454 [[],[]] .smaller = true := by decide
def e605593353462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e605593353462 : Closed e605593353462 ∧ code e605593353462 = 2804616609014 := by decide
theorem cert_e605593353462 : check e605593353462 [[],[]] .smaller = true := by decide
def e605593353466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e605593353466 : Closed e605593353466 ∧ code e605593353466 = 2804616609018 := by decide
theorem cert_e605593353466 : check e605593353466 [[],[]] .three = true := by decide
def e605593353838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593353838 : Closed e605593353838 ∧ code e605593353838 = 2804616609390 := by decide
theorem cert_e605593353838 : check e605593353838 [[],[]] .three = true := by decide
def e605593353846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e605593353846 : Closed e605593353846 ∧ code e605593353846 = 2804616609398 := by decide
theorem cert_e605593353846 : check e605593353846 [[],[]] .three = true := by decide
def e605593353850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593353850 : Closed e605593353850 ∧ code e605593353850 = 2804616609402 := by decide
theorem cert_e605593353850 : check e605593353850 [[],[]] .three = true := by decide
def e605593372606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 4)))))))))
theorem wire_e605593372606 : Closed e605593372606 ∧ code e605593372606 = 2804616628158 := by decide
theorem cert_e605593372606 : check e605593372606 [[],[]] .three = true := by decide
def e605593372638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e605593372638 : Closed e605593372638 ∧ code e605593372638 = 2804616628190 := by decide
theorem cert_e605593372638 : check e605593372638 [[],[]] .smaller = true := by decide
def e605593372654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 4) (.var 2)))))))))
theorem wire_e605593372654 : Closed e605593372654 ∧ code e605593372654 = 2804616628206 := by decide
theorem cert_e605593372654 : check e605593372654 [[],[]] .three = true := by decide
def e605593376302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605593376302 : Closed e605593376302 ∧ code e605593376302 = 2804616631854 := by decide
theorem cert_e605593376302 : check e605593376302 [[],[]] .smaller = true := by decide
def e605593376478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e605593376478 : Closed e605593376478 ∧ code e605593376478 = 2804616632030 := by decide
theorem cert_e605593376478 : check e605593376478 [[],[]] .three = true := by decide
def e605593376482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605593376482 : Closed e605593376482 ∧ code e605593376482 = 2804616632034 := by decide
theorem cert_e605593376482 : check e605593376482 [[],[]] .smaller = true := by decide
def e605593376494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e605593376494 : Closed e605593376494 ∧ code e605593376494 = 2804616632046 := by decide
theorem cert_e605593376494 : check e605593376494 [[],[]] .smaller = true := by decide
def e605593376502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e605593376502 : Closed e605593376502 ∧ code e605593376502 = 2804616632054 := by decide
theorem cert_e605593376502 : check e605593376502 [[],[]] .three = true := by decide
def e605593376606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e605593376606 : Closed e605593376606 ∧ code e605593376606 = 2804616632158 := by decide
theorem cert_e605593376606 : check e605593376606 [[],[]] .three = true := by decide
def e605593376622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e605593376622 : Closed e605593376622 ∧ code e605593376622 = 2804616632174 := by decide
theorem cert_e605593376622 : check e605593376622 [[],[]] .smaller = true := by decide
def e605593376630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e605593376630 : Closed e605593376630 ∧ code e605593376630 = 2804616632182 := by decide
theorem cert_e605593376630 : check e605593376630 [[],[]] .smaller = true := by decide
def e605593376634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e605593376634 : Closed e605593376634 ∧ code e605593376634 = 2804616632186 := by decide
theorem cert_e605593376634 : check e605593376634 [[],[]] .three = true := by decide
end Blc.Floor41
