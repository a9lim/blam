import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605593724858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e605593724858 : Closed e605593724858 ∧ code e605593724858 = 2804616980410 := by decide
theorem cert_e605593724858 : check e605593724858 [[],[]] .smaller = true := by decide
def e605593724886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e605593724886 : Closed e605593724886 ∧ code e605593724886 = 2804616980438 := by decide
theorem cert_e605593724886 : check e605593724886 [[],[]] .three = true := by decide
def e605593724890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e605593724890 : Closed e605593724890 ∧ code e605593724890 = 2804616980442 := by decide
theorem cert_e605593724890 : check e605593724890 [[],[]] .three = true := by decide
def e605593724990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4))))))))))
theorem wire_e605593724990 : Closed e605593724990 ∧ code e605593724990 = 2804616980542 := by decide
theorem cert_e605593724990 : check e605593724990 [[],[]] .smaller = true := by decide
def e605593725406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605593725406 : Closed e605593725406 ∧ code e605593725406 = 2804616980958 := by decide
theorem cert_e605593725406 : check e605593725406 [[],[]] .three = true := by decide
def e605593725410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605593725410 : Closed e605593725410 ∧ code e605593725410 = 2804616980962 := by decide
theorem cert_e605593725410 : check e605593725410 [[],[]] .smaller = true := by decide
def e605593725422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e605593725422 : Closed e605593725422 ∧ code e605593725422 = 2804616980974 := by decide
theorem cert_e605593725422 : check e605593725422 [[],[]] .smaller = true := by decide
def e605593725430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605593725430 : Closed e605593725430 ∧ code e605593725430 = 2804616980982 := by decide
theorem cert_e605593725430 : check e605593725430 [[],[]] .three = true := by decide
def e605593726174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605593726174 : Closed e605593726174 ∧ code e605593726174 = 2804616981726 := by decide
theorem cert_e605593726174 : check e605593726174 [[],[]] .three = true := by decide
def e605593726190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605593726190 : Closed e605593726190 ∧ code e605593726190 = 2804616981742 := by decide
theorem cert_e605593726190 : check e605593726190 [[],[]] .smaller = true := by decide
def e605593726198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605593726198 : Closed e605593726198 ∧ code e605593726198 = 2804616981750 := by decide
theorem cert_e605593726198 : check e605593726198 [[],[]] .smaller = true := by decide
def e605593726202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605593726202 : Closed e605593726202 ∧ code e605593726202 = 2804616981754 := by decide
theorem cert_e605593726202 : check e605593726202 [[],[]] .three = true := by decide
def e605593726478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2))))))))))
theorem wire_e605593726478 : Closed e605593726478 ∧ code e605593726478 = 2804616982030 := by decide
theorem cert_e605593726478 : check e605593726478 [[],[]] .smaller = true := by decide
def e605593726490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605593726490 : Closed e605593726490 ∧ code e605593726490 = 2804616982042 := by decide
theorem cert_e605593726490 : check e605593726490 [[],[]] .smaller = true := by decide
def e605593726562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605593726562 : Closed e605593726562 ∧ code e605593726562 = 2804616982114 := by decide
theorem cert_e605593726562 : check e605593726562 [[],[]] .smaller = true := by decide
def e605593726574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593726574 : Closed e605593726574 ∧ code e605593726574 = 2804616982126 := by decide
theorem cert_e605593726574 : check e605593726574 [[],[]] .smaller = true := by decide
def e605593726582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605593726582 : Closed e605593726582 ∧ code e605593726582 = 2804616982134 := by decide
theorem cert_e605593726582 : check e605593726582 [[],[]] .smaller = true := by decide
def e605593726586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593726586 : Closed e605593726586 ∧ code e605593726586 = 2804616982138 := by decide
theorem cert_e605593726586 : check e605593726586 [[],[]] .smaller = true := by decide
def e605593726774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593726774 : Closed e605593726774 ∧ code e605593726774 = 2804616982326 := by decide
theorem cert_e605593726774 : check e605593726774 [[],[]] .three = true := by decide
def e605593726778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593726778 : Closed e605593726778 ∧ code e605593726778 = 2804616982330 := by decide
theorem cert_e605593726778 : check e605593726778 [[],[]] .three = true := by decide
def e605593727094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e605593727094 : Closed e605593727094 ∧ code e605593727094 = 2804616982646 := by decide
theorem cert_e605593727094 : check e605593727094 [[],[]] .smaller = true := by decide
def e605593727098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e605593727098 : Closed e605593727098 ∧ code e605593727098 = 2804616982650 := by decide
theorem cert_e605593727098 : check e605593727098 [[],[]] .smaller = true := by decide
def e605593727190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e605593727190 : Closed e605593727190 ∧ code e605593727190 = 2804616982742 := by decide
theorem cert_e605593727190 : check e605593727190 [[],[]] .smaller = true := by decide
def e605593727286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593727286 : Closed e605593727286 ∧ code e605593727286 = 2804616982838 := by decide
theorem cert_e605593727286 : check e605593727286 [[],[]] .smaller = true := by decide
def e605593727290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593727290 : Closed e605593727290 ∧ code e605593727290 = 2804616982842 := by decide
theorem cert_e605593727290 : check e605593727290 [[],[]] .smaller = true := by decide
def e605593727374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e605593727374 : Closed e605593727374 ∧ code e605593727374 = 2804616982926 := by decide
theorem cert_e605593727374 : check e605593727374 [[],[]] .smaller = true := by decide
def e605593727430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e605593727430 : Closed e605593727430 ∧ code e605593727430 = 2804616982982 := by decide
theorem cert_e605593727430 : check e605593727430 [[],[]] .smaller = true := by decide
def e605593727766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605593727766 : Closed e605593727766 ∧ code e605593727766 = 2804616983318 := by decide
theorem cert_e605593727766 : check e605593727766 [[],[]] .smaller = true := by decide
def e605593727838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e605593727838 : Closed e605593727838 ∧ code e605593727838 = 2804616983390 := by decide
theorem cert_e605593727838 : check e605593727838 [[],[]] .three = true := by decide
def e605593727842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e605593727842 : Closed e605593727842 ∧ code e605593727842 = 2804616983394 := by decide
theorem cert_e605593727842 : check e605593727842 [[],[]] .smaller = true := by decide
def e605593727854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605593727854 : Closed e605593727854 ∧ code e605593727854 = 2804616983406 := by decide
theorem cert_e605593727854 : check e605593727854 [[],[]] .smaller = true := by decide
def e605593727862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605593727862 : Closed e605593727862 ∧ code e605593727862 = 2804616983414 := by decide
theorem cert_e605593727862 : check e605593727862 [[],[]] .smaller = true := by decide
def e605593727866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e605593727866 : Closed e605593727866 ∧ code e605593727866 = 2804616983418 := by decide
theorem cert_e605593727866 : check e605593727866 [[],[]] .three = true := by decide
def e605593727882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605593727882 : Closed e605593727882 ∧ code e605593727882 = 2804616983434 := by decide
theorem cert_e605593727882 : check e605593727882 [[],[]] .smaller = true := by decide
def e605593727906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e605593727906 : Closed e605593727906 ∧ code e605593727906 = 2804616983458 := by decide
theorem cert_e605593727906 : check e605593727906 [[],[]] .smaller = true := by decide
def e605593727918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605593727918 : Closed e605593727918 ∧ code e605593727918 = 2804616983470 := by decide
theorem cert_e605593727918 : check e605593727918 [[],[]] .smaller = true := by decide
def e605593727926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1))))))))
theorem wire_e605593727926 : Closed e605593727926 ∧ code e605593727926 = 2804616983478 := by decide
theorem cert_e605593727926 : check e605593727926 [[],[]] .smaller = true := by decide
def e605593727930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605593727930 : Closed e605593727930 ∧ code e605593727930 = 2804616983482 := by decide
theorem cert_e605593727930 : check e605593727930 [[],[]] .smaller = true := by decide
def e605593727958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605593727958 : Closed e605593727958 ∧ code e605593727958 = 2804616983510 := by decide
theorem cert_e605593727958 : check e605593727958 [[],[]] .smaller = true := by decide
def e605593727962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605593727962 : Closed e605593727962 ∧ code e605593727962 = 2804616983514 := by decide
theorem cert_e605593727962 : check e605593727962 [[],[]] .smaller = true := by decide
def e605593727978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e605593727978 : Closed e605593727978 ∧ code e605593727978 = 2804616983530 := by decide
theorem cert_e605593727978 : check e605593727978 [[],[]] .three = true := by decide
def e605593728030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e605593728030 : Closed e605593728030 ∧ code e605593728030 = 2804616983582 := by decide
theorem cert_e605593728030 : check e605593728030 [[],[]] .smaller = true := by decide
def e605593728222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605593728222 : Closed e605593728222 ∧ code e605593728222 = 2804616983774 := by decide
theorem cert_e605593728222 : check e605593728222 [[],[]] .three = true := by decide
def e605593728226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e605593728226 : Closed e605593728226 ∧ code e605593728226 = 2804616983778 := by decide
theorem cert_e605593728226 : check e605593728226 [[],[]] .smaller = true := by decide
def e605593728238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605593728238 : Closed e605593728238 ∧ code e605593728238 = 2804616983790 := by decide
theorem cert_e605593728238 : check e605593728238 [[],[]] .smaller = true := by decide
def e605593728246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605593728246 : Closed e605593728246 ∧ code e605593728246 = 2804616983798 := by decide
theorem cert_e605593728246 : check e605593728246 [[],[]] .smaller = true := by decide
def e605593728250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605593728250 : Closed e605593728250 ∧ code e605593728250 = 2804616983802 := by decide
theorem cert_e605593728250 : check e605593728250 [[],[]] .three = true := by decide
def e605593728526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e605593728526 : Closed e605593728526 ∧ code e605593728526 = 2804616984078 := by decide
theorem cert_e605593728526 : check e605593728526 [[],[]] .smaller = true := by decide
def e605593728538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605593728538 : Closed e605593728538 ∧ code e605593728538 = 2804616984090 := by decide
theorem cert_e605593728538 : check e605593728538 [[],[]] .smaller = true := by decide
def e605593728610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605593728610 : Closed e605593728610 ∧ code e605593728610 = 2804616984162 := by decide
theorem cert_e605593728610 : check e605593728610 [[],[]] .smaller = true := by decide
def e605593728622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593728622 : Closed e605593728622 ∧ code e605593728622 = 2804616984174 := by decide
theorem cert_e605593728622 : check e605593728622 [[],[]] .smaller = true := by decide
def e605593728630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605593728630 : Closed e605593728630 ∧ code e605593728630 = 2804616984182 := by decide
theorem cert_e605593728630 : check e605593728630 [[],[]] .smaller = true := by decide
def e605593728634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593728634 : Closed e605593728634 ∧ code e605593728634 = 2804616984186 := by decide
theorem cert_e605593728634 : check e605593728634 [[],[]] .smaller = true := by decide
def e605593728822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593728822 : Closed e605593728822 ∧ code e605593728822 = 2804616984374 := by decide
theorem cert_e605593728822 : check e605593728822 [[],[]] .smaller = true := by decide
def e605593728826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593728826 : Closed e605593728826 ∧ code e605593728826 = 2804616984378 := by decide
theorem cert_e605593728826 : check e605593728826 [[],[]] .smaller = true := by decide
def e605593728922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593728922 : Closed e605593728922 ∧ code e605593728922 = 2804616984474 := by decide
theorem cert_e605593728922 : check e605593728922 [[],[]] .three = true := by decide
def e605593729454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605593729454 : Closed e605593729454 ∧ code e605593729454 = 2804616985006 := by decide
theorem cert_e605593729454 : check e605593729454 [[],[]] .three = true := by decide
def e605593729462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e605593729462 : Closed e605593729462 ∧ code e605593729462 = 2804616985014 := by decide
theorem cert_e605593729462 : check e605593729462 [[],[]] .three = true := by decide
def e605593729466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605593729466 : Closed e605593729466 ∧ code e605593729466 = 2804616985018 := by decide
theorem cert_e605593729466 : check e605593729466 [[],[]] .three = true := by decide
def e605593729494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e605593729494 : Closed e605593729494 ∧ code e605593729494 = 2804616985046 := by decide
theorem cert_e605593729494 : check e605593729494 [[],[]] .three = true := by decide
def e605593729498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e605593729498 : Closed e605593729498 ∧ code e605593729498 = 2804616985050 := by decide
theorem cert_e605593729498 : check e605593729498 [[],[]] .three = true := by decide
def e605593729514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605593729514 : Closed e605593729514 ∧ code e605593729514 = 2804616985066 := by decide
theorem cert_e605593729514 : check e605593729514 [[],[]] .three = true := by decide
def e605593729646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593729646 : Closed e605593729646 ∧ code e605593729646 = 2804616985198 := by decide
theorem cert_e605593729646 : check e605593729646 [[],[]] .three = true := by decide
def e605593729654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605593729654 : Closed e605593729654 ∧ code e605593729654 = 2804616985206 := by decide
theorem cert_e605593729654 : check e605593729654 [[],[]] .three = true := by decide
def e605593729658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593729658 : Closed e605593729658 ∧ code e605593729658 = 2804616985210 := by decide
theorem cert_e605593729658 : check e605593729658 [[],[]] .three = true := by decide
def e605593729846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593729846 : Closed e605593729846 ∧ code e605593729846 = 2804616985398 := by decide
theorem cert_e605593729846 : check e605593729846 [[],[]] .three = true := by decide
def e605593729850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593729850 : Closed e605593729850 ∧ code e605593729850 = 2804616985402 := by decide
theorem cert_e605593729850 : check e605593729850 [[],[]] .three = true := by decide
def e605593729946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593729946 : Closed e605593729946 ∧ code e605593729946 = 2804616985498 := by decide
theorem cert_e605593729946 : check e605593729946 [[],[]] .three = true := by decide
def e605593733998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605593733998 : Closed e605593733998 ∧ code e605593733998 = 2804616989550 := by decide
theorem cert_e605593733998 : check e605593733998 [[],[]] .smaller = true := by decide
def e605593734006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605593734006 : Closed e605593734006 ∧ code e605593734006 = 2804616989558 := by decide
theorem cert_e605593734006 : check e605593734006 [[],[]] .smaller = true := by decide
def e605593734062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605593734062 : Closed e605593734062 ∧ code e605593734062 = 2804616989614 := by decide
theorem cert_e605593734062 : check e605593734062 [[],[]] .smaller = true := by decide
def e605593734074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605593734074 : Closed e605593734074 ∧ code e605593734074 = 2804616989626 := by decide
theorem cert_e605593734074 : check e605593734074 [[],[]] .smaller = true := by decide
def e605593734102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605593734102 : Closed e605593734102 ∧ code e605593734102 = 2804616989654 := by decide
theorem cert_e605593734102 : check e605593734102 [[],[]] .smaller = true := by decide
def e605593734106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605593734106 : Closed e605593734106 ∧ code e605593734106 = 2804616989658 := by decide
theorem cert_e605593734106 : check e605593734106 [[],[]] .smaller = true := by decide
def e605593734382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605593734382 : Closed e605593734382 ∧ code e605593734382 = 2804616989934 := by decide
theorem cert_e605593734382 : check e605593734382 [[],[]] .smaller = true := by decide
def e605593734390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605593734390 : Closed e605593734390 ∧ code e605593734390 = 2804616989942 := by decide
theorem cert_e605593734390 : check e605593734390 [[],[]] .smaller = true := by decide
def e605593734766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605593734766 : Closed e605593734766 ∧ code e605593734766 = 2804616990318 := by decide
theorem cert_e605593734766 : check e605593734766 [[],[]] .smaller = true := by decide
def e605593734778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605593734778 : Closed e605593734778 ∧ code e605593734778 = 2804616990330 := by decide
theorem cert_e605593734778 : check e605593734778 [[],[]] .smaller = true := by decide
def e605593734966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605593734966 : Closed e605593734966 ∧ code e605593734966 = 2804616990518 := by decide
theorem cert_e605593734966 : check e605593734966 [[],[]] .smaller = true := by decide
def e605593734970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605593734970 : Closed e605593734970 ∧ code e605593734970 = 2804616990522 := by decide
theorem cert_e605593734970 : check e605593734970 [[],[]] .smaller = true := by decide
def e605593735102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e605593735102 : Closed e605593735102 ∧ code e605593735102 = 2804616990654 := by decide
theorem cert_e605593735102 : check e605593735102 [[],[]] .three = true := by decide
def e605593735134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e605593735134 : Closed e605593735134 ∧ code e605593735134 = 2804616990686 := by decide
theorem cert_e605593735134 : check e605593735134 [[],[]] .three = true := by decide
def e605593742814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605593742814 : Closed e605593742814 ∧ code e605593742814 = 2804616998366 := by decide
theorem cert_e605593742814 : check e605593742814 [[],[]] .three = true := by decide
def e605593742830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605593742830 : Closed e605593742830 ∧ code e605593742830 = 2804616998382 := by decide
theorem cert_e605593742830 : check e605593742830 [[],[]] .three = true := by decide
def e605593742894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e605593742894 : Closed e605593742894 ∧ code e605593742894 = 2804616998446 := by decide
theorem cert_e605593742894 : check e605593742894 [[],[]] .smaller = true := by decide
def e605593743070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e605593743070 : Closed e605593743070 ∧ code e605593743070 = 2804616998622 := by decide
theorem cert_e605593743070 : check e605593743070 [[],[]] .three = true := by decide
def e605593743074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e605593743074 : Closed e605593743074 ∧ code e605593743074 = 2804616998626 := by decide
theorem cert_e605593743074 : check e605593743074 [[],[]] .smaller = true := by decide
def e605593743086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e605593743086 : Closed e605593743086 ∧ code e605593743086 = 2804616998638 := by decide
theorem cert_e605593743086 : check e605593743086 [[],[]] .smaller = true := by decide
def e605593743094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e605593743094 : Closed e605593743094 ∧ code e605593743094 = 2804616998646 := by decide
theorem cert_e605593743094 : check e605593743094 [[],[]] .three = true := by decide
def e605593743126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e605593743126 : Closed e605593743126 ∧ code e605593743126 = 2804616998678 := by decide
theorem cert_e605593743126 : check e605593743126 [[],[]] .smaller = true := by decide
def e605593743198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605593743198 : Closed e605593743198 ∧ code e605593743198 = 2804616998750 := by decide
theorem cert_e605593743198 : check e605593743198 [[],[]] .three = true := by decide
def e605593743202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e605593743202 : Closed e605593743202 ∧ code e605593743202 = 2804616998754 := by decide
theorem cert_e605593743202 : check e605593743202 [[],[]] .smaller = true := by decide
def e605593743214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e605593743214 : Closed e605593743214 ∧ code e605593743214 = 2804616998766 := by decide
theorem cert_e605593743214 : check e605593743214 [[],[]] .smaller = true := by decide
def e605593743222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e605593743222 : Closed e605593743222 ∧ code e605593743222 = 2804616998774 := by decide
theorem cert_e605593743222 : check e605593743222 [[],[]] .smaller = true := by decide
def e605593743226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605593743226 : Closed e605593743226 ∧ code e605593743226 = 2804616998778 := by decide
theorem cert_e605593743226 : check e605593743226 [[],[]] .three = true := by decide
def e605593743278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605593743278 : Closed e605593743278 ∧ code e605593743278 = 2804616998830 := by decide
theorem cert_e605593743278 : check e605593743278 [[],[]] .three = true := by decide
def e605593743286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e605593743286 : Closed e605593743286 ∧ code e605593743286 = 2804616998838 := by decide
theorem cert_e605593743286 : check e605593743286 [[],[]] .three = true := by decide
def e605593743290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605593743290 : Closed e605593743290 ∧ code e605593743290 = 2804616998842 := by decide
theorem cert_e605593743290 : check e605593743290 [[],[]] .three = true := by decide
def e605593744350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605593744350 : Closed e605593744350 ∧ code e605593744350 = 2804616999902 := by decide
theorem cert_e605593744350 : check e605593744350 [[],[]] .three = true := by decide
def e605593744366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605593744366 : Closed e605593744366 ∧ code e605593744366 = 2804616999918 := by decide
theorem cert_e605593744366 : check e605593744366 [[],[]] .three = true := by decide
def e605593745470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4)))))))))))
theorem wire_e605593745470 : Closed e605593745470 ∧ code e605593745470 = 2804617001022 := by decide
theorem cert_e605593745470 : check e605593745470 [[],[]] .smaller = true := by decide
def e605593745886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e605593745886 : Closed e605593745886 ∧ code e605593745886 = 2804617001438 := by decide
theorem cert_e605593745886 : check e605593745886 [[],[]] .three = true := by decide
def e605593745890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e605593745890 : Closed e605593745890 ∧ code e605593745890 = 2804617001442 := by decide
theorem cert_e605593745890 : check e605593745890 [[],[]] .smaller = true := by decide
def e605593745902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e605593745902 : Closed e605593745902 ∧ code e605593745902 = 2804617001454 := by decide
theorem cert_e605593745902 : check e605593745902 [[],[]] .smaller = true := by decide
def e605593745910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e605593745910 : Closed e605593745910 ∧ code e605593745910 = 2804617001462 := by decide
theorem cert_e605593745910 : check e605593745910 [[],[]] .three = true := by decide
def e605593746462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3)))))))))))
theorem wire_e605593746462 : Closed e605593746462 ∧ code e605593746462 = 2804617002014 := by decide
theorem cert_e605593746462 : check e605593746462 [[],[]] .smaller = true := by decide
def e605593746654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605593746654 : Closed e605593746654 ∧ code e605593746654 = 2804617002206 := by decide
theorem cert_e605593746654 : check e605593746654 [[],[]] .three = true := by decide
def e605593746658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e605593746658 : Closed e605593746658 ∧ code e605593746658 = 2804617002210 := by decide
theorem cert_e605593746658 : check e605593746658 [[],[]] .smaller = true := by decide
def e605593746670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e605593746670 : Closed e605593746670 ∧ code e605593746670 = 2804617002222 := by decide
theorem cert_e605593746670 : check e605593746670 [[],[]] .smaller = true := by decide
def e605593746678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e605593746678 : Closed e605593746678 ∧ code e605593746678 = 2804617002230 := by decide
theorem cert_e605593746678 : check e605593746678 [[],[]] .smaller = true := by decide
def e605593746682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605593746682 : Closed e605593746682 ∧ code e605593746682 = 2804617002234 := by decide
theorem cert_e605593746682 : check e605593746682 [[],[]] .three = true := by decide
def e605593747054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605593747054 : Closed e605593747054 ∧ code e605593747054 = 2804617002606 := by decide
theorem cert_e605593747054 : check e605593747054 [[],[]] .three = true := by decide
def e605593747062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e605593747062 : Closed e605593747062 ∧ code e605593747062 = 2804617002614 := by decide
theorem cert_e605593747062 : check e605593747062 [[],[]] .three = true := by decide
def e605593747066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605593747066 : Closed e605593747066 ∧ code e605593747066 = 2804617002618 := by decide
theorem cert_e605593747066 : check e605593747066 [[],[]] .three = true := by decide
def e605593765822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e605593765822 : Closed e605593765822 ∧ code e605593765822 = 2804617021374 := by decide
theorem cert_e605593765822 : check e605593765822 [[],[]] .three = true := by decide
def e605593765854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 3))))))))))
theorem wire_e605593765854 : Closed e605593765854 ∧ code e605593765854 = 2804617021406 := by decide
theorem cert_e605593765854 : check e605593765854 [[],[]] .smaller = true := by decide
def e605593765870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e605593765870 : Closed e605593765870 ∧ code e605593765870 = 2804617021422 := by decide
theorem cert_e605593765870 : check e605593765870 [[],[]] .three = true := by decide
def e605593769518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e605593769518 : Closed e605593769518 ∧ code e605593769518 = 2804617025070 := by decide
theorem cert_e605593769518 : check e605593769518 [[],[]] .smaller = true := by decide
def e605593769694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605593769694 : Closed e605593769694 ∧ code e605593769694 = 2804617025246 := by decide
theorem cert_e605593769694 : check e605593769694 [[],[]] .three = true := by decide
def e605593769698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e605593769698 : Closed e605593769698 ∧ code e605593769698 = 2804617025250 := by decide
theorem cert_e605593769698 : check e605593769698 [[],[]] .smaller = true := by decide
def e605593769710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e605593769710 : Closed e605593769710 ∧ code e605593769710 = 2804617025262 := by decide
theorem cert_e605593769710 : check e605593769710 [[],[]] .smaller = true := by decide
def e605593769718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605593769718 : Closed e605593769718 ∧ code e605593769718 = 2804617025270 := by decide
theorem cert_e605593769718 : check e605593769718 [[],[]] .three = true := by decide
def e605593769822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605593769822 : Closed e605593769822 ∧ code e605593769822 = 2804617025374 := by decide
theorem cert_e605593769822 : check e605593769822 [[],[]] .three = true := by decide
def e605593769838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e605593769838 : Closed e605593769838 ∧ code e605593769838 = 2804617025390 := by decide
theorem cert_e605593769838 : check e605593769838 [[],[]] .smaller = true := by decide
def e605593769846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e605593769846 : Closed e605593769846 ∧ code e605593769846 = 2804617025398 := by decide
theorem cert_e605593769846 : check e605593769846 [[],[]] .smaller = true := by decide
def e605593769850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605593769850 : Closed e605593769850 ∧ code e605593769850 = 2804617025402 := by decide
theorem cert_e605593769850 : check e605593769850 [[],[]] .three = true := by decide
def e605593769866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e605593769866 : Closed e605593769866 ∧ code e605593769866 = 2804617025418 := by decide
theorem cert_e605593769866 : check e605593769866 [[],[]] .smaller = true := by decide
def e605593769890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e605593769890 : Closed e605593769890 ∧ code e605593769890 = 2804617025442 := by decide
theorem cert_e605593769890 : check e605593769890 [[],[]] .smaller = true := by decide
def e605593769902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e605593769902 : Closed e605593769902 ∧ code e605593769902 = 2804617025454 := by decide
theorem cert_e605593769902 : check e605593769902 [[],[]] .smaller = true := by decide
def e605593769910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e605593769910 : Closed e605593769910 ∧ code e605593769910 = 2804617025462 := by decide
theorem cert_e605593769910 : check e605593769910 [[],[]] .smaller = true := by decide
def e605593769914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e605593769914 : Closed e605593769914 ∧ code e605593769914 = 2804617025466 := by decide
theorem cert_e605593769914 : check e605593769914 [[],[]] .smaller = true := by decide
def e605593769942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605593769942 : Closed e605593769942 ∧ code e605593769942 = 2804617025494 := by decide
theorem cert_e605593769942 : check e605593769942 [[],[]] .three = true := by decide
def e605593769946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605593769946 : Closed e605593769946 ∧ code e605593769946 = 2804617025498 := by decide
theorem cert_e605593769946 : check e605593769946 [[],[]] .three = true := by decide
def e605593770046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4)))))))))))
theorem wire_e605593770046 : Closed e605593770046 ∧ code e605593770046 = 2804617025598 := by decide
theorem cert_e605593770046 : check e605593770046 [[],[]] .smaller = true := by decide
def e605593770462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605593770462 : Closed e605593770462 ∧ code e605593770462 = 2804617026014 := by decide
theorem cert_e605593770462 : check e605593770462 [[],[]] .three = true := by decide
def e605593770466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e605593770466 : Closed e605593770466 ∧ code e605593770466 = 2804617026018 := by decide
theorem cert_e605593770466 : check e605593770466 [[],[]] .smaller = true := by decide
def e605593770478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e605593770478 : Closed e605593770478 ∧ code e605593770478 = 2804617026030 := by decide
theorem cert_e605593770478 : check e605593770478 [[],[]] .smaller = true := by decide
def e605593770486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605593770486 : Closed e605593770486 ∧ code e605593770486 = 2804617026038 := by decide
theorem cert_e605593770486 : check e605593770486 [[],[]] .three = true := by decide
def e605593771230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605593771230 : Closed e605593771230 ∧ code e605593771230 = 2804617026782 := by decide
theorem cert_e605593771230 : check e605593771230 [[],[]] .three = true := by decide
def e605593771246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e605593771246 : Closed e605593771246 ∧ code e605593771246 = 2804617026798 := by decide
theorem cert_e605593771246 : check e605593771246 [[],[]] .smaller = true := by decide
def e605593771254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e605593771254 : Closed e605593771254 ∧ code e605593771254 = 2804617026806 := by decide
theorem cert_e605593771254 : check e605593771254 [[],[]] .smaller = true := by decide
def e605593771258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605593771258 : Closed e605593771258 ∧ code e605593771258 = 2804617026810 := by decide
theorem cert_e605593771258 : check e605593771258 [[],[]] .three = true := by decide
def e605593771534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2)))))))))))
theorem wire_e605593771534 : Closed e605593771534 ∧ code e605593771534 = 2804617027086 := by decide
theorem cert_e605593771534 : check e605593771534 [[],[]] .smaller = true := by decide
def e605593771546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e605593771546 : Closed e605593771546 ∧ code e605593771546 = 2804617027098 := by decide
theorem cert_e605593771546 : check e605593771546 [[],[]] .smaller = true := by decide
def e605593771618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e605593771618 : Closed e605593771618 ∧ code e605593771618 = 2804617027170 := by decide
theorem cert_e605593771618 : check e605593771618 [[],[]] .smaller = true := by decide
def e605593771630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e605593771630 : Closed e605593771630 ∧ code e605593771630 = 2804617027182 := by decide
theorem cert_e605593771630 : check e605593771630 [[],[]] .smaller = true := by decide
def e605593771638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e605593771638 : Closed e605593771638 ∧ code e605593771638 = 2804617027190 := by decide
theorem cert_e605593771638 : check e605593771638 [[],[]] .smaller = true := by decide
def e605593771642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e605593771642 : Closed e605593771642 ∧ code e605593771642 = 2804617027194 := by decide
theorem cert_e605593771642 : check e605593771642 [[],[]] .smaller = true := by decide
def e605593771830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605593771830 : Closed e605593771830 ∧ code e605593771830 = 2804617027382 := by decide
theorem cert_e605593771830 : check e605593771830 [[],[]] .three = true := by decide
def e605593771834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605593771834 : Closed e605593771834 ∧ code e605593771834 = 2804617027386 := by decide
theorem cert_e605593771834 : check e605593771834 [[],[]] .three = true := by decide
def e605593781182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e605593781182 : Closed e605593781182 ∧ code e605593781182 = 2804617036734 := by decide
theorem cert_e605593781182 : check e605593781182 [[],[]] .three = true := by decide
def e605593781214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e605593781214 : Closed e605593781214 ∧ code e605593781214 = 2804617036766 := by decide
theorem cert_e605593781214 : check e605593781214 [[],[]] .smaller = true := by decide
def e605593781230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e605593781230 : Closed e605593781230 ∧ code e605593781230 = 2804617036782 := by decide
theorem cert_e605593781230 : check e605593781230 [[],[]] .smaller = true := by decide
def e605593781238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e605593781238 : Closed e605593781238 ∧ code e605593781238 = 2804617036790 := by decide
theorem cert_e605593781238 : check e605593781238 [[],[]] .three = true := by decide
def e605593783062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e605593783062 : Closed e605593783062 ∧ code e605593783062 = 2804617038614 := by decide
theorem cert_e605593783062 : check e605593783062 [[],[]] .smaller = true := by decide
def e605593783134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e605593783134 : Closed e605593783134 ∧ code e605593783134 = 2804617038686 := by decide
theorem cert_e605593783134 : check e605593783134 [[],[]] .three = true := by decide
def e605593783138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e605593783138 : Closed e605593783138 ∧ code e605593783138 = 2804617038690 := by decide
theorem cert_e605593783138 : check e605593783138 [[],[]] .smaller = true := by decide
def e605593783150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605593783150 : Closed e605593783150 ∧ code e605593783150 = 2804617038702 := by decide
theorem cert_e605593783150 : check e605593783150 [[],[]] .smaller = true := by decide
def e605593783158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605593783158 : Closed e605593783158 ∧ code e605593783158 = 2804617038710 := by decide
theorem cert_e605593783158 : check e605593783158 [[],[]] .smaller = true := by decide
def e605593783162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e605593783162 : Closed e605593783162 ∧ code e605593783162 = 2804617038714 := by decide
theorem cert_e605593783162 : check e605593783162 [[],[]] .three = true := by decide
end Blc.Floor41
