import CodeBridge
import Batch044
namespace Certgen.R598355258734
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 7,.lam 2,.app 3 6,.app 4 5,.var 0,.var 0,.var 0,.lam 8,.app 9 10,.var 0,.lam 11,.lam 12,.app 13 18,.app 14 17,.app 15 16,.var 0,.var 0,.var 1,.var 2]
def values : Array (List AClo) := #[[⟨7,[]⟩],[⟨10,[3]⟩,⟨16,[2,1,3]⟩],[⟨6,[0]⟩,⟨17,[2,1,3]⟩],[⟨5,[0]⟩,⟨10,[3]⟩,⟨16,[2,1,3]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨7,[]⟩,0⟩],[⟨⟨18,[2,1,3]⟩,0⟩,⟨⟨18,[2,1,3]⟩,2⟩],[⟨⟨17,[2,1,3]⟩,2⟩],[⟨⟨16,[2,1,3]⟩,3⟩],[⟨⟨6,[0]⟩,0⟩],[⟨⟨5,[0]⟩,5⟩],[⟨⟨10,[3]⟩,3⟩,⟨⟨10,[3]⟩,5⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[0]⟩,0⟩,⟨⟨3,[0]⟩,5⟩,⟨⟨4,[0]⟩,6⟩,⟨⟨5,[0]⟩,7⟩,⟨⟨6,[0]⟩,4⟩,⟨⟨6,[0]⟩,7⟩,⟨⟨7,[]⟩,4⟩,⟨⟨7,[]⟩,6⟩,⟨⟨7,[]⟩,7⟩,⟨⟨8,[3]⟩,3⟩,⟨⟨8,[3]⟩,5⟩,⟨⟨9,[3]⟩,7⟩,⟨⟨10,[3]⟩,4⟩,⟨⟨10,[3]⟩,7⟩,⟨⟨11,[1,3]⟩,3⟩,⟨⟨11,[1,3]⟩,5⟩,⟨⟨12,[2,1,3]⟩,0⟩,⟨⟨12,[2,1,3]⟩,2⟩,⟨⟨13,[2,1,3]⟩,2⟩,⟨⟨14,[2,1,3]⟩,3⟩,⟨⟨15,[2,1,3]⟩,4⟩,⟨⟨16,[2,1,3]⟩,4⟩,⟨⟨16,[2,1,3]⟩,7⟩,⟨⟨17,[2,1,3]⟩,4⟩,⟨⟨17,[2,1,3]⟩,7⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[4],[9],[10],[8],[10],[11],[12],[11,12],[13],[13],[5,15,24],[16],[16,17],[19],[18],[20],[20],[21],[22],[6,25],[6,25],[7,26],[14,23],[15,24]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem block24 : checkRange P V K states hints 24 3=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<27 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 by_cases h12 : i<24
 · exact range_sound block12 i (by omega) h12 hi
 exact range_sound block24 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Floor41 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit16 : Term := .var 0
def lit17 : Term := .var 1
def lit18 : Term := .var 2
def lit14 : Term := .app lit16 lit16
def lit2 : Term := .app lit14 lit16
def lit13 : Term := .app lit14 lit17
def lit1 : Term := .lam lit2
def lit12 : Term := .app lit13 lit18
def lit11 : Term := .lam lit12
def lit10 : Term := .lam lit11
def lit8 : Term := .app lit16 lit10
def lit7 : Term := .lam lit8
def lit0 : Term := .app lit1 lit7
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub18 : model.term 18 = lit18 := model.var_eq 18 2 (by rfl)
theorem sub17 : model.term 17 = lit17 := model.var_eq 17 1 (by rfl)
theorem sub16 : model.term 16 = lit16 := model.var_eq 16 0 (by rfl)
theorem sub15 : model.term 15 = lit16 := model.var_eq 15 0 (by rfl)
theorem sub14 : model.term 14 = lit14 := by rw [model.app_eq 14 15 16 (by rfl), sub15, sub16]; rfl
theorem sub13 : model.term 13 = lit13 := by rw [model.app_eq 13 14 17 (by rfl), sub14, sub17]; rfl
theorem sub12 : model.term 12 = lit12 := by rw [model.app_eq 12 13 18 (by rfl), sub13, sub18]; rfl
theorem sub11 : model.term 11 = lit11 := by rw [model.lam_eq 11 12 (by rfl), sub12]; rfl
theorem sub10 : model.term 10 = lit10 := by rw [model.lam_eq 10 11 (by rfl), sub11]; rfl
theorem sub9 : model.term 9 = lit16 := model.var_eq 9 0 (by rfl)
theorem sub8 : model.term 8 = lit8 := by rw [model.app_eq 8 9 10 (by rfl), sub9, sub10]; rfl
theorem sub7 : model.term 7 = lit7 := by rw [model.lam_eq 7 8 (by rfl), sub8]; rfl
theorem sub6 : model.term 6 = lit16 := model.var_eq 6 0 (by rfl)
theorem sub5 : model.term 5 = lit16 := model.var_eq 5 0 (by rfl)
theorem sub4 : model.term 4 = lit16 := model.var_eq 4 0 (by rfl)
theorem sub3 : model.term 3 = lit14 := by rw [model.app_eq 3 4 5 (by rfl), sub4, sub5]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 6 (by rfl), sub3, sub6]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.lam_eq 1 2 (by rfl), sub2]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 7 (by rfl), sub1, sub7]; rfl
theorem excluded : ¬ IsSelfInterpreter e598355258734 := by
 intro he
 have hp : replay [] e598355258734 = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (rawCount he) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R598355258734
