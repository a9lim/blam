import R598356004462Data
namespace Certgen.R598356004462
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl72 : FloorIndex.rangeOK validState 72 12 = true := by decide +kernel
theorem bl84 : FloorIndex.rangeOK validState 84 12 = true := by decide +kernel
theorem bl96 : FloorIndex.rangeOK validState 96 12 = true := by decide +kernel
theorem bl108 : FloorIndex.rangeOK validState 108 12 = true := by decide +kernel
theorem bl120 : FloorIndex.rangeOK validState 120 12 = true := by decide +kernel
theorem bl132 : FloorIndex.rangeOK validState 132 12 = true := by decide +kernel
end Certgen.R598356004462
