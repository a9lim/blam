import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605792559582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605792559582 : Closed e605792559582 ∧ code e605792559582 = 2804815815134 := by decide
theorem cert_e605792559582 : check e605792559582 [[],[],[],[]] .sourceHead = true := by decide
def e605792559606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605792559606 : Closed e605792559606 ∧ code e605792559606 = 2804815815158 := by decide
theorem cert_e605792559606 : check e605792559606 [[],[],[],[]] .sourceHead = true := by decide
def e605792560558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605792560558 : Closed e605792560558 ∧ code e605792560558 = 2804815816110 := by decide
theorem cert_e605792560558 : check e605792560558 [[],[],[],[]] .sourceHead = true := by decide
def e605792560570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605792560570 : Closed e605792560570 ∧ code e605792560570 = 2804815816122 := by decide
theorem cert_e605792560570 : check e605792560570 [[],[],[],[]] .sourceHead = true := by decide
def e605792560618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605792560618 : Closed e605792560618 ∧ code e605792560618 = 2804815816170 := by decide
theorem cert_e605792560618 : check e605792560618 [[],[],[],[]] .sourceHead = true := by decide
def e605792560750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605792560750 : Closed e605792560750 ∧ code e605792560750 = 2804815816302 := by decide
theorem cert_e605792560750 : check e605792560750 [[],[],[],[]] .sourceHead = true := by decide
def e605792560762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605792560762 : Closed e605792560762 ∧ code e605792560762 = 2804815816314 := by decide
theorem cert_e605792560762 : check e605792560762 [[],[],[],[]] .sourceHead = true := by decide
def e605792560926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605792560926 : Closed e605792560926 ∧ code e605792560926 = 2804815816478 := by decide
theorem cert_e605792560926 : check e605792560926 [[],[],[],[]] .sourceHead = true := by decide
def e605792561026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e605792561026 : Closed e605792561026 ∧ code e605792561026 = 2804815816578 := by decide
theorem cert_e605792561026 : check e605792561026 [[],[],[],[]] .sourceHead = true := by decide
def e605792561038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605792561038 : Closed e605792561038 ∧ code e605792561038 = 2804815816590 := by decide
theorem cert_e605792561038 : check e605792561038 [[],[],[],[]] .sourceHead = true := by decide
def e605792561050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605792561050 : Closed e605792561050 ∧ code e605792561050 = 2804815816602 := by decide
theorem cert_e605792561050 : check e605792561050 [[],[],[],[]] .sourceHead = true := by decide
def e605792563438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605792563438 : Closed e605792563438 ∧ code e605792563438 = 2804815818990 := by decide
theorem cert_e605792563438 : check e605792563438 [[],[],[],[]] .sourceHead = true := by decide
def e605792563446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605792563446 : Closed e605792563446 ∧ code e605792563446 = 2804815818998 := by decide
theorem cert_e605792563446 : check e605792563446 [[],[],[],[]] .sourceHead = true := by decide
def e605792563926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605792563926 : Closed e605792563926 ∧ code e605792563926 = 2804815819478 := by decide
theorem cert_e605792563926 : check e605792563926 [[],[],[],[]] .sourceHead = true := by decide
def e605792563930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605792563930 : Closed e605792563930 ∧ code e605792563930 = 2804815819482 := by decide
theorem cert_e605792563930 : check e605792563930 [[],[],[],[]] .sourceHead = true := by decide
def e605792563946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605792563946 : Closed e605792563946 ∧ code e605792563946 = 2804815819498 := by decide
theorem cert_e605792563946 : check e605792563946 [[],[],[],[]] .sourceHead = true := by decide
def e605792564022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605792564022 : Closed e605792564022 ∧ code e605792564022 = 2804815819574 := by decide
theorem cert_e605792564022 : check e605792564022 [[],[],[],[]] .sourceHead = true := by decide
def e605792564026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605792564026 : Closed e605792564026 ∧ code e605792564026 = 2804815819578 := by decide
theorem cert_e605792564026 : check e605792564026 [[],[],[],[]] .sourceHead = true := by decide
def e605792564098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e605792564098 : Closed e605792564098 ∧ code e605792564098 = 2804815819650 := by decide
theorem cert_e605792564098 : check e605792564098 [[],[],[],[]] .sourceHead = true := by decide
def e605792564110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e605792564110 : Closed e605792564110 ∧ code e605792564110 = 2804815819662 := by decide
theorem cert_e605792564110 : check e605792564110 [[],[],[],[]] .sourceHead = true := by decide
def e605792564122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605792564122 : Closed e605792564122 ∧ code e605792564122 = 2804815819674 := by decide
theorem cert_e605792564122 : check e605792564122 [[],[],[],[]] .sourceHead = true := by decide
def e605792634814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e605792634814 : Closed e605792634814 ∧ code e605792634814 = 2804815890366 := by decide
theorem cert_e605792634814 : check e605792634814 [[],[],[],[],[.under],[.under,.under]] .three = true := by decide
def e605792634862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e605792634862 : Closed e605792634862 ∧ code e605792634862 = 2804815890414 := by decide
theorem cert_e605792634862 : check e605792634862 [[],[],[],[],[.under],[.under,.under]] .three = true := by decide
def e605792638686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605792638686 : Closed e605792638686 ∧ code e605792638686 = 2804815894238 := by decide
theorem cert_e605792638686 : check e605792638686 [[],[],[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605792638710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605792638710 : Closed e605792638710 ∧ code e605792638710 = 2804815894262 := by decide
private def t_e605792638710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem cert_e605792638710 : ¬ IsSelfInterpreter e605792638710 :=
  wSource (t := t_e605792638710) (replay_sound (ps := []) (t := e605792638710) (by decide)) (by decide)
def e605792638814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605792638814 : Closed e605792638814 ∧ code e605792638814 = 2804815894366 := by decide
theorem cert_e605792638814 : checkPay e605792638814 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left]] = true := by decide
def e605792638842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605792638842 : Closed e605792638842 ∧ code e605792638842 = 2804815894394 := by decide
theorem cert_e605792638842 : checkPay e605792638842 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e605792638934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605792638934 : Closed e605792638934 ∧ code e605792638934 = 2804815894486 := by decide
private def t_e605792638934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem cert_e605792638934 : ¬ IsSelfInterpreter e605792638934 :=
  wSource (t := t_e605792638934) (replay_sound (ps := []) (t := e605792638934) (by decide)) (by decide)
def e605792638938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605792638938 : Closed e605792638938 ∧ code e605792638938 = 2804815894490 := by decide
theorem cert_e605792638938 : check e605792638938 [[],[],[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e605792639454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605792639454 : Closed e605792639454 ∧ code e605792639454 = 2804815895006 := by decide
theorem cert_e605792639454 : checkPay e605792639454 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 0 [] = true := by decide
def e605792639478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605792639478 : Closed e605792639478 ∧ code e605792639478 = 2804815895030 := by decide
theorem cert_e605792639478 : check e605792639478 [[],[],[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e605792640222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605792640222 : Closed e605792640222 ∧ code e605792640222 = 2804815895774 := by decide
theorem cert_e605792640222 : check e605792640222 [[],[],[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605792640250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605792640250 : Closed e605792640250 ∧ code e605792640250 = 2804815895802 := by decide
theorem cert_e605792640250 : check e605792640250 [[],[],[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605792640822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605792640822 : Closed e605792640822 ∧ code e605792640822 = 2804815896374 := by decide
theorem cert_e605792640822 : checkPay e605792640822 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[],[.left],[.left],[]] 0 [] = true := by decide
def e605792640826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605792640826 : Closed e605792640826 ∧ code e605792640826 = 2804815896378 := by decide
theorem cert_e605792640826 : checkPay e605792640826 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 0 [[.under],[.under,.under,.left],[.under,.under,.right,.under]] = true := by decide
def e605792655022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605792655022 : Closed e605792655022 ∧ code e605792655022 = 2804815910574 := by decide
theorem cert_e605792655022 : check e605792655022 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792655034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605792655034 : Closed e605792655034 ∧ code e605792655034 = 2804815910586 := by decide
theorem cert_e605792655034 : check e605792655034 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792655082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605792655082 : Closed e605792655082 ∧ code e605792655082 = 2804815910634 := by decide
theorem cert_e605792655082 : check e605792655082 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792655274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605792655274 : Closed e605792655274 ∧ code e605792655274 = 2804815910826 := by decide
theorem cert_e605792655274 : check e605792655274 [[],[],[],[],[.under],[.under,.under,.left,.left,.left]] .sourceHead = true := by decide
def e605792655406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605792655406 : Closed e605792655406 ∧ code e605792655406 = 2804815910958 := by decide
theorem cert_e605792655406 : check e605792655406 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792655598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605792655598 : Closed e605792655598 ∧ code e605792655598 = 2804815911150 := by decide
theorem cert_e605792655598 : check e605792655598 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792655606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605792655606 : Closed e605792655606 ∧ code e605792655606 = 2804815911158 := by decide
theorem cert_e605792655606 : check e605792655606 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792655790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605792655790 : Closed e605792655790 ∧ code e605792655790 = 2804815911342 := by decide
theorem cert_e605792655790 : check e605792655790 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792655802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605792655802 : Closed e605792655802 ∧ code e605792655802 = 2804815911354 := by decide
theorem cert_e605792655802 : check e605792655802 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792655850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605792655850 : Closed e605792655850 ∧ code e605792655850 = 2804815911402 := by decide
theorem cert_e605792655850 : check e605792655850 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792655982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605792655982 : Closed e605792655982 ∧ code e605792655982 = 2804815911534 := by decide
theorem cert_e605792655982 : check e605792655982 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792655994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605792655994 : Closed e605792655994 ∧ code e605792655994 = 2804815911546 := by decide
theorem cert_e605792655994 : check e605792655994 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792656158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605792656158 : Closed e605792656158 ∧ code e605792656158 = 2804815911710 := by decide
theorem cert_e605792656158 : check e605792656158 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792656258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e605792656258 : Closed e605792656258 ∧ code e605792656258 = 2804815911810 := by decide
theorem cert_e605792656258 : check e605792656258 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792656270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605792656270 : Closed e605792656270 ∧ code e605792656270 = 2804815911822 := by decide
theorem cert_e605792656270 : check e605792656270 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792656282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605792656282 : Closed e605792656282 ∧ code e605792656282 = 2804815911834 := by decide
theorem cert_e605792656282 : check e605792656282 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792656494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605792656494 : Closed e605792656494 ∧ code e605792656494 = 2804815912046 := by decide
theorem cert_e605792656494 : check e605792656494 [[],[],[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e605792656506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605792656506 : Closed e605792656506 ∧ code e605792656506 = 2804815912058 := by decide
theorem cert_e605792656506 : check e605792656506 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605792656670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605792656670 : Closed e605792656670 ∧ code e605792656670 = 2804815912222 := by decide
theorem cert_e605792656670 : checkPay e605792656670 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left]] 0 [] = true := by decide
def e605792656838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605792656838 : Closed e605792656838 ∧ code e605792656838 = 2804815912390 := by decide
private def t_e605792656838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem cert_e605792656838 : ¬ IsSelfInterpreter e605792656838 :=
  wSource (t := t_e605792656838) (replay_sound (ps := []) (t := e605792656838) (by decide)) (by decide)
def e605792656906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605792656906 : Closed e605792656906 ∧ code e605792656906 = 2804815912458 := by decide
theorem cert_e605792656906 : check e605792656906 [[],[],[],[],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e605792656950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605792656950 : Closed e605792656950 ∧ code e605792656950 = 2804815912502 := by decide
theorem cert_e605792656950 : checkPay e605792656950 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left]] 0 [[.under,.under,.right,.left],[.under,.under,.right],[.under,.under,.right]] = true := by decide
def e605792656954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605792656954 : Closed e605792656954 ∧ code e605792656954 = 2804815912506 := by decide
theorem cert_e605792656954 : check e605792656954 [[],[],[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605792657002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605792657002 : Closed e605792657002 ∧ code e605792657002 = 2804815912554 := by decide
theorem cert_e605792657002 : check e605792657002 [[],[],[],[],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e605792657026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e605792657026 : Closed e605792657026 ∧ code e605792657026 = 2804815912578 := by decide
theorem cert_e605792657026 : check e605792657026 [[],[],[],[],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e605792657038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605792657038 : Closed e605792657038 ∧ code e605792657038 = 2804815912590 := by decide
theorem cert_e605792657038 : check e605792657038 [[],[],[],[],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e605792657050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605792657050 : Closed e605792657050 ∧ code e605792657050 = 2804815912602 := by decide
theorem cert_e605792657050 : check e605792657050 [[],[],[],[],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e605792657094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605792657094 : Closed e605792657094 ∧ code e605792657094 = 2804815912646 := by decide
private def t_e605792657094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem cert_e605792657094 : ¬ IsSelfInterpreter e605792657094 :=
  wSource (t := t_e605792657094) (replay_sound (ps := []) (t := e605792657094) (by decide)) (by decide)
def e605792657886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605792657886 : Closed e605792657886 ∧ code e605792657886 = 2804815913438 := by decide
theorem cert_e605792657886 : checkPay e605792657886 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605792657910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605792657910 : Closed e605792657910 ∧ code e605792657910 = 2804815913462 := by decide
theorem cert_e605792657910 : checkPay e605792657910 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e605792658862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605792658862 : Closed e605792658862 ∧ code e605792658862 = 2804815914414 := by decide
theorem cert_e605792658862 : checkPay e605792658862 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605792658874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605792658874 : Closed e605792658874 ∧ code e605792658874 = 2804815914426 := by decide
theorem cert_e605792658874 : checkPay e605792658874 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605792658922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605792658922 : Closed e605792658922 ∧ code e605792658922 = 2804815914474 := by decide
theorem cert_e605792658922 : checkPay e605792658922 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.left]] = true := by decide
def e605792659054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605792659054 : Closed e605792659054 ∧ code e605792659054 = 2804815914606 := by decide
theorem cert_e605792659054 : checkPay e605792659054 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605792659066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605792659066 : Closed e605792659066 ∧ code e605792659066 = 2804815914618 := by decide
theorem cert_e605792659066 : checkPay e605792659066 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.right]] = true := by decide
def e605792659230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605792659230 : Closed e605792659230 ∧ code e605792659230 = 2804815914782 := by decide
theorem cert_e605792659230 : checkPay e605792659230 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[],[.under]] = true := by decide
def e605792659330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e605792659330 : Closed e605792659330 ∧ code e605792659330 = 2804815914882 := by decide
theorem cert_e605792659330 : checkPay e605792659330 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[],[]] = true := by decide
def e605792659342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605792659342 : Closed e605792659342 ∧ code e605792659342 = 2804815914894 := by decide
theorem cert_e605792659342 : checkPay e605792659342 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[],[],[.under,.under,.right,.right],[.under,.under,.right,.right,.under]] = true := by decide
def e605792659354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605792659354 : Closed e605792659354 ∧ code e605792659354 = 2804815914906 := by decide
theorem cert_e605792659354 : checkPay e605792659354 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[]] = true := by decide
def e605792662302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605792662302 : Closed e605792662302 ∧ code e605792662302 = 2804815917854 := by decide
theorem cert_e605792662302 : checkPay e605792662302 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] 0 [] = true := by decide
def e605792662470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605792662470 : Closed e605792662470 ∧ code e605792662470 = 2804815918022 := by decide
theorem cert_e605792662470 : check e605792662470 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e605792663670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605792663670 : Closed e605792663670 ∧ code e605792663670 = 2804815919222 := by decide
theorem cert_e605792663670 : check e605792663670 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e605792663914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605792663914 : Closed e605792663914 ∧ code e605792663914 = 2804815919466 := by decide
theorem cert_e605792663914 : check e605792663914 [[],[],[],[],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605792663938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e605792663938 : Closed e605792663938 ∧ code e605792663938 = 2804815919490 := by decide
theorem cert_e605792663938 : check e605792663938 [[],[],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e605792663950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605792663950 : Closed e605792663950 ∧ code e605792663950 = 2804815919502 := by decide
theorem cert_e605792663950 : check e605792663950 [[],[],[],[],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605792663962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605792663962 : Closed e605792663962 ∧ code e605792663962 = 2804815919514 := by decide
theorem cert_e605792663962 : check e605792663962 [[],[],[],[],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605792664006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605792664006 : Closed e605792664006 ∧ code e605792664006 = 2804815919558 := by decide
theorem cert_e605792664006 : check e605792664006 [[],[],[],[],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e605792699358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e605792699358 : Closed e605792699358 ∧ code e605792699358 = 2804815954910 := by decide
theorem cert_e605792699358 : check e605792699358 [[],[],[],[],[.under],[.under]] .chain = true := by decide
def e605792699374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e605792699374 : Closed e605792699374 ∧ code e605792699374 = 2804815954926 := by decide
theorem cert_e605792699374 : check e605792699374 [[],[],[],[],[.under],[.under]] .chain = true := by decide
def e605792701294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605792701294 : Closed e605792701294 ∧ code e605792701294 = 2804815956846 := by decide
theorem cert_e605792701294 : check e605792701294 [[],[],[],[],[.under],[.under],[.under,.left],[.under],[.under],[.under,.left]] .sourceHead = true := by decide
def e605792701302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605792701302 : Closed e605792701302 ∧ code e605792701302 = 2804815956854 := by decide
private def t_e605792701302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem cert_e605792701302 : ¬ IsSelfInterpreter e605792701302 :=
  wSource (t := t_e605792701302) (replay_sound (ps := []) (t := e605792701302) (by decide)) (by decide)
def e605792701358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605792701358 : Closed e605792701358 ∧ code e605792701358 = 2804815956910 := by decide
theorem cert_e605792701358 : check e605792701358 [[],[],[],[],[.under],[.under]] .sourceHead = true := by decide
def e605792701370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605792701370 : Closed e605792701370 ∧ code e605792701370 = 2804815956922 := by decide
theorem cert_e605792701370 : check e605792701370 [[],[],[],[],[.under],[.under]] .sourceHead = true := by decide
def e605792701398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605792701398 : Closed e605792701398 ∧ code e605792701398 = 2804815956950 := by decide
private def t_e605792701398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem cert_e605792701398 : ¬ IsSelfInterpreter e605792701398 :=
  wSource (t := t_e605792701398) (replay_sound (ps := []) (t := e605792701398) (by decide)) (by decide)
def e605792701402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605792701402 : Closed e605792701402 ∧ code e605792701402 = 2804815956954 := by decide
theorem cert_e605792701402 : check e605792701402 [[],[],[],[],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e605792701678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605792701678 : Closed e605792701678 ∧ code e605792701678 = 2804815957230 := by decide
theorem cert_e605792701678 : checkPay e605792701678 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[],[],[]] 0 [[.under,.under],[.under,.under,.under],[.under,.under,.under],[.under,.under,.under],[.under,.under,.under,.under],[.under,.under,.under,.under]] = true := by decide
def e605792701686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605792701686 : Closed e605792701686 ∧ code e605792701686 = 2804815957238 := by decide
theorem cert_e605792701686 : check e605792701686 [[],[],[],[],[.under],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e605792702062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605792702062 : Closed e605792702062 ∧ code e605792702062 = 2804815957614 := by decide
theorem cert_e605792702062 : check e605792702062 [[],[],[],[],[.under],[.under]] .sourceHead = true := by decide
def e605792702074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605792702074 : Closed e605792702074 ∧ code e605792702074 = 2804815957626 := by decide
theorem cert_e605792702074 : check e605792702074 [[],[],[],[],[.under],[.under]] .sourceHead = true := by decide
def e605792702262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605792702262 : Closed e605792702262 ∧ code e605792702262 = 2804815957814 := by decide
theorem cert_e605792702262 : check e605792702262 [[],[],[],[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e605792702266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605792702266 : Closed e605792702266 ∧ code e605792702266 = 2804815957818 := by decide
theorem cert_e605792702266 : check e605792702266 [[],[],[],[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e605792709462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605792709462 : Closed e605792709462 ∧ code e605792709462 = 2804815965014 := by decide
theorem cert_e605792709462 : check e605792709462 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792709466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605792709466 : Closed e605792709466 ∧ code e605792709466 = 2804815965018 := by decide
theorem cert_e605792709466 : check e605792709466 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792709482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605792709482 : Closed e605792709482 ∧ code e605792709482 = 2804815965034 := by decide
theorem cert_e605792709482 : check e605792709482 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792709546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605792709546 : Closed e605792709546 ∧ code e605792709546 = 2804815965098 := by decide
theorem cert_e605792709546 : check e605792709546 [[],[],[],[],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e605792709654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605792709654 : Closed e605792709654 ∧ code e605792709654 = 2804815965206 := by decide
theorem cert_e605792709654 : check e605792709654 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792709750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e605792709750 : Closed e605792709750 ∧ code e605792709750 = 2804815965302 := by decide
theorem cert_e605792709750 : check e605792709750 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792709846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605792709846 : Closed e605792709846 ∧ code e605792709846 = 2804815965398 := by decide
theorem cert_e605792709846 : check e605792709846 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792709850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605792709850 : Closed e605792709850 ∧ code e605792709850 = 2804815965402 := by decide
theorem cert_e605792709850 : check e605792709850 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792709866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605792709866 : Closed e605792709866 ∧ code e605792709866 = 2804815965418 := by decide
theorem cert_e605792709866 : check e605792709866 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792709942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605792709942 : Closed e605792709942 ∧ code e605792709942 = 2804815965494 := by decide
theorem cert_e605792709942 : check e605792709942 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792709946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605792709946 : Closed e605792709946 ∧ code e605792709946 = 2804815965498 := by decide
theorem cert_e605792709946 : check e605792709946 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792710018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e605792710018 : Closed e605792710018 ∧ code e605792710018 = 2804815965570 := by decide
theorem cert_e605792710018 : check e605792710018 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792710030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e605792710030 : Closed e605792710030 ∧ code e605792710030 = 2804815965582 := by decide
theorem cert_e605792710030 : check e605792710030 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792710042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605792710042 : Closed e605792710042 ∧ code e605792710042 = 2804815965594 := by decide
theorem cert_e605792710042 : check e605792710042 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792710154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605792710154 : Closed e605792710154 ∧ code e605792710154 = 2804815965706 := by decide
theorem cert_e605792710154 : check e605792710154 [[],[],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e605792710198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605792710198 : Closed e605792710198 ∧ code e605792710198 = 2804815965750 := by decide
def e605792710202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605792710202 : Closed e605792710202 ∧ code e605792710202 = 2804815965754 := by decide
def e605792710250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605792710250 : Closed e605792710250 ∧ code e605792710250 = 2804815965802 := by decide
def e605792710274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e605792710274 : Closed e605792710274 ∧ code e605792710274 = 2804815965826 := by decide
theorem cert_e605792710274 : check e605792710274 [[],[],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e605792710286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605792710286 : Closed e605792710286 ∧ code e605792710286 = 2804815965838 := by decide
def e605792710298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605792710298 : Closed e605792710298 ∧ code e605792710298 = 2804815965850 := by decide
def e605792710342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605792710342 : Closed e605792710342 ∧ code e605792710342 = 2804815965894 := by decide
private def t_e605792710342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem cert_e605792710342 : ¬ IsSelfInterpreter e605792710342 :=
  wSource (t := t_e605792710342) (replay_sound (ps := []) (t := e605792710342) (by decide)) (by decide)
def e605792710894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605792710894 : Closed e605792710894 ∧ code e605792710894 = 2804815966446 := by decide
theorem cert_e605792710894 : check e605792710894 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792710902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605792710902 : Closed e605792710902 ∧ code e605792710902 = 2804815966454 := by decide
theorem cert_e605792710902 : check e605792710902 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792711382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605792711382 : Closed e605792711382 ∧ code e605792711382 = 2804815966934 := by decide
theorem cert_e605792711382 : check e605792711382 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792711386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605792711386 : Closed e605792711386 ∧ code e605792711386 = 2804815966938 := by decide
theorem cert_e605792711386 : check e605792711386 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792711402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605792711402 : Closed e605792711402 ∧ code e605792711402 = 2804815966954 := by decide
theorem cert_e605792711402 : check e605792711402 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792711478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605792711478 : Closed e605792711478 ∧ code e605792711478 = 2804815967030 := by decide
theorem cert_e605792711478 : check e605792711478 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792711482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605792711482 : Closed e605792711482 ∧ code e605792711482 = 2804815967034 := by decide
theorem cert_e605792711482 : check e605792711482 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792711554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e605792711554 : Closed e605792711554 ∧ code e605792711554 = 2804815967106 := by decide
theorem cert_e605792711554 : check e605792711554 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792711566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e605792711566 : Closed e605792711566 ∧ code e605792711566 = 2804815967118 := by decide
theorem cert_e605792711566 : check e605792711566 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792711578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605792711578 : Closed e605792711578 ∧ code e605792711578 = 2804815967130 := by decide
theorem cert_e605792711578 : check e605792711578 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e605792712822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605792712822 : Closed e605792712822 ∧ code e605792712822 = 2804815968374 := by decide
theorem cert_e605792712822 : check e605792712822 [[],[],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e605792713066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605792713066 : Closed e605792713066 ∧ code e605792713066 = 2804815968618 := by decide
def e605792713090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e605792713090 : Closed e605792713090 ∧ code e605792713090 = 2804815968642 := by decide
theorem cert_e605792713090 : check e605792713090 [[],[],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e605792713102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605792713102 : Closed e605792713102 ∧ code e605792713102 = 2804815968654 := by decide
def e605792713114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605792713114 : Closed e605792713114 ∧ code e605792713114 = 2804815968666 := by decide
def e605792713158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605792713158 : Closed e605792713158 ∧ code e605792713158 = 2804815968710 := by decide
def e605794610618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e605794610618 : Closed e605794610618 ∧ code e605794610618 = 2804817866170 := by decide
private def t_e605794610618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem cert_e605794610618 : ¬ IsSelfInterpreter e605794610618 :=
  wSource (t := t_e605794610618) (replay_sound (ps := []) (t := e605794610618) (by decide)) (by decide)
def e605794610650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e605794610650 : Closed e605794610650 ∧ code e605794610650 = 2804817866202 := by decide
private def t_e605794610650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem cert_e605794610650 : ¬ IsSelfInterpreter e605794610650 :=
  wSource (t := t_e605794610650) (replay_sound (ps := []) (t := e605794610650) (by decide)) (by decide)
def e605794610874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e605794610874 : Closed e605794610874 ∧ code e605794610874 = 2804817866426 := by decide
private def t_e605794610874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem cert_e605794610874 : ¬ IsSelfInterpreter e605794610874 :=
  wSource (t := t_e605794610874) (replay_sound (ps := []) (t := e605794610874) (by decide)) (by decide)
def e605794610922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e605794610922 : Closed e605794610922 ∧ code e605794610922 = 2804817866474 := by decide
private def t_e605794610922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem cert_e605794610922 : ¬ IsSelfInterpreter e605794610922 :=
  wSource (t := t_e605794610922) (replay_sound (ps := []) (t := e605794610922) (by decide)) (by decide)
def e605794611034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e605794611034 : Closed e605794611034 ∧ code e605794611034 = 2804817866586 := by decide
private def t_e605794611034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem cert_e605794611034 : ¬ IsSelfInterpreter e605794611034 :=
  wSource (t := t_e605794611034) (replay_sound (ps := []) (t := e605794611034) (by decide)) (by decide)
def e605794611050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e605794611050 : Closed e605794611050 ∧ code e605794611050 = 2804817866602 := by decide
private def t_e605794611050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem cert_e605794611050 : ¬ IsSelfInterpreter e605794611050 :=
  wSource (t := t_e605794611050) (replay_sound (ps := []) (t := e605794611050) (by decide)) (by decide)
def e605794612154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e605794612154 : Closed e605794612154 ∧ code e605794612154 = 2804817867706 := by decide
private def t_e605794612154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem cert_e605794612154 : ¬ IsSelfInterpreter e605794612154 :=
  wSource (t := t_e605794612154) (replay_sound (ps := []) (t := e605794612154) (by decide)) (by decide)
def e605794612186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e605794612186 : Closed e605794612186 ∧ code e605794612186 = 2804817867738 := by decide
private def t_e605794612186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem cert_e605794612186 : ¬ IsSelfInterpreter e605794612186 :=
  wSource (t := t_e605794612186) (replay_sound (ps := []) (t := e605794612186) (by decide)) (by decide)
def e605794613690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e605794613690 : Closed e605794613690 ∧ code e605794613690 = 2804817869242 := by decide
private def t_e605794613690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem cert_e605794613690 : ¬ IsSelfInterpreter e605794613690 :=
  wSource (t := t_e605794613690) (replay_sound (ps := []) (t := e605794613690) (by decide)) (by decide)
def e605794613738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e605794613738 : Closed e605794613738 ∧ code e605794613738 = 2804817869290 := by decide
private def t_e605794613738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem cert_e605794613738 : ¬ IsSelfInterpreter e605794613738 :=
  wSource (t := t_e605794613738) (replay_sound (ps := []) (t := e605794613738) (by decide)) (by decide)
def e605794614490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e605794614490 : Closed e605794614490 ∧ code e605794614490 = 2804817870042 := by decide
private def t_e605794614490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem cert_e605794614490 : ¬ IsSelfInterpreter e605794614490 :=
  wSource (t := t_e605794614490) (replay_sound (ps := []) (t := e605794614490) (by decide)) (by decide)
def e605794614506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e605794614506 : Closed e605794614506 ∧ code e605794614506 = 2804817870058 := by decide
private def t_e605794614506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem cert_e605794614506 : ¬ IsSelfInterpreter e605794614506 :=
  wSource (t := t_e605794614506) (replay_sound (ps := []) (t := e605794614506) (by decide)) (by decide)
def e605794667374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605794667374 : Closed e605794667374 ∧ code e605794667374 = 2804817922926 := by decide
private def t_e605794667374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e605794667374 : ¬ IsSelfInterpreter e605794667374 :=
  wSource (t := t_e605794667374) (replay_sound (ps := []) (t := e605794667374) (by decide)) (by decide)
def e605794667382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605794667382 : Closed e605794667382 ∧ code e605794667382 = 2804817922934 := by decide
private def t_e605794667382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e605794667382 : ¬ IsSelfInterpreter e605794667382 :=
  wSource (t := t_e605794667382) (replay_sound (ps := []) (t := e605794667382) (by decide)) (by decide)
def e605794667438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605794667438 : Closed e605794667438 ∧ code e605794667438 = 2804817922990 := by decide
private def t_e605794667438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e605794667438 : ¬ IsSelfInterpreter e605794667438 :=
  wSource (t := t_e605794667438) (replay_sound (ps := []) (t := e605794667438) (by decide)) (by decide)
def e605794667450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605794667450 : Closed e605794667450 ∧ code e605794667450 = 2804817923002 := by decide
private def t_e605794667450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e605794667450 : ¬ IsSelfInterpreter e605794667450 :=
  wSource (t := t_e605794667450) (replay_sound (ps := []) (t := e605794667450) (by decide)) (by decide)
def e605794667478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605794667478 : Closed e605794667478 ∧ code e605794667478 = 2804817923030 := by decide
private def t_e605794667478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e605794667478 : ¬ IsSelfInterpreter e605794667478 :=
  wSource (t := t_e605794667478) (replay_sound (ps := []) (t := e605794667478) (by decide)) (by decide)
def e605794667482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605794667482 : Closed e605794667482 ∧ code e605794667482 = 2804817923034 := by decide
private def t_e605794667482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e605794667482 : ¬ IsSelfInterpreter e605794667482 :=
  wSource (t := t_e605794667482) (replay_sound (ps := []) (t := e605794667482) (by decide)) (by decide)
def e605794667758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605794667758 : Closed e605794667758 ∧ code e605794667758 = 2804817923310 := by decide
private def t_e605794667758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e605794667758 : ¬ IsSelfInterpreter e605794667758 :=
  wSource (t := t_e605794667758) (replay_sound (ps := []) (t := e605794667758) (by decide)) (by decide)
def e605794667766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605794667766 : Closed e605794667766 ∧ code e605794667766 = 2804817923318 := by decide
private def t_e605794667766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e605794667766 : ¬ IsSelfInterpreter e605794667766 :=
  wSource (t := t_e605794667766) (replay_sound (ps := []) (t := e605794667766) (by decide)) (by decide)
def e605794668142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605794668142 : Closed e605794668142 ∧ code e605794668142 = 2804817923694 := by decide
private def t_e605794668142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e605794668142 : ¬ IsSelfInterpreter e605794668142 :=
  wSource (t := t_e605794668142) (replay_sound (ps := []) (t := e605794668142) (by decide)) (by decide)
def e605794668154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605794668154 : Closed e605794668154 ∧ code e605794668154 = 2804817923706 := by decide
private def t_e605794668154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e605794668154 : ¬ IsSelfInterpreter e605794668154 :=
  wSource (t := t_e605794668154) (replay_sound (ps := []) (t := e605794668154) (by decide)) (by decide)
def e605794668342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605794668342 : Closed e605794668342 ∧ code e605794668342 = 2804817923894 := by decide
private def t_e605794668342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e605794668342 : ¬ IsSelfInterpreter e605794668342 :=
  wSource (t := t_e605794668342) (replay_sound (ps := []) (t := e605794668342) (by decide)) (by decide)
def e605794668346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605794668346 : Closed e605794668346 ∧ code e605794668346 = 2804817923898 := by decide
private def t_e605794668346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e605794668346 : ¬ IsSelfInterpreter e605794668346 :=
  wSource (t := t_e605794668346) (replay_sound (ps := []) (t := e605794668346) (by decide)) (by decide)
def e605794872798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605794872798 : Closed e605794872798 ∧ code e605794872798 = 2804818128350 := by decide
theorem cert_e605794872798 : check e605794872798 [[],[],[],[],[],[]] .sourceHead = true := by decide
def e605794872814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605794872814 : Closed e605794872814 ∧ code e605794872814 = 2804818128366 := by decide
theorem cert_e605794872814 : check e605794872814 [[],[],[],[],[],[]] .sourceHead = true := by decide
end Blc.Floor41
