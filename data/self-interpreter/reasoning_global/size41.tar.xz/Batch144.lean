import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605792476614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e605792476614 : Closed e605792476614 ∧ code e605792476614 = 2804815732166 := by decide
private def t_e605792476614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem cert_e605792476614 : ¬ IsSelfInterpreter e605792476614 :=
  wSource (t := t_e605792476614) (replay_sound (ps := []) (t := e605792476614) (by decide)) (by decide)
def e605792476682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605792476682 : Closed e605792476682 ∧ code e605792476682 = 2804815732234 := by decide
theorem cert_e605792476682 : check e605792476682 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e605792476726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605792476726 : Closed e605792476726 ∧ code e605792476726 = 2804815732278 := by decide
theorem cert_e605792476726 : check e605792476726 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e605792476730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605792476730 : Closed e605792476730 ∧ code e605792476730 = 2804815732282 := by decide
def e605792476778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605792476778 : Closed e605792476778 ∧ code e605792476778 = 2804815732330 := by decide
theorem cert_e605792476778 : check e605792476778 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e605792476802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e605792476802 : Closed e605792476802 ∧ code e605792476802 = 2804815732354 := by decide
theorem cert_e605792476802 : check e605792476802 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e605792476814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605792476814 : Closed e605792476814 ∧ code e605792476814 = 2804815732366 := by decide
theorem cert_e605792476814 : check e605792476814 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e605792476826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605792476826 : Closed e605792476826 ∧ code e605792476826 = 2804815732378 := by decide
theorem cert_e605792476826 : check e605792476826 [[],[],[],[],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e605792476870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605792476870 : Closed e605792476870 ∧ code e605792476870 = 2804815732422 := by decide
private def t_e605792476870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem cert_e605792476870 : ¬ IsSelfInterpreter e605792476870 :=
  wSource (t := t_e605792476870) (replay_sound (ps := []) (t := e605792476870) (by decide)) (by decide)
def e605792477662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605792477662 : Closed e605792477662 ∧ code e605792477662 = 2804815733214 := by decide
theorem cert_e605792477662 : check e605792477662 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792477686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605792477686 : Closed e605792477686 ∧ code e605792477686 = 2804815733238 := by decide
theorem cert_e605792477686 : check e605792477686 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792478638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605792478638 : Closed e605792478638 ∧ code e605792478638 = 2804815734190 := by decide
theorem cert_e605792478638 : check e605792478638 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792478650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605792478650 : Closed e605792478650 ∧ code e605792478650 = 2804815734202 := by decide
theorem cert_e605792478650 : check e605792478650 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792478698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605792478698 : Closed e605792478698 ∧ code e605792478698 = 2804815734250 := by decide
theorem cert_e605792478698 : check e605792478698 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792478830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605792478830 : Closed e605792478830 ∧ code e605792478830 = 2804815734382 := by decide
theorem cert_e605792478830 : check e605792478830 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792478842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605792478842 : Closed e605792478842 ∧ code e605792478842 = 2804815734394 := by decide
theorem cert_e605792478842 : check e605792478842 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792479006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605792479006 : Closed e605792479006 ∧ code e605792479006 = 2804815734558 := by decide
theorem cert_e605792479006 : check e605792479006 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792479106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e605792479106 : Closed e605792479106 ∧ code e605792479106 = 2804815734658 := by decide
theorem cert_e605792479106 : check e605792479106 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792479118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605792479118 : Closed e605792479118 ∧ code e605792479118 = 2804815734670 := by decide
theorem cert_e605792479118 : check e605792479118 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792479130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605792479130 : Closed e605792479130 ∧ code e605792479130 = 2804815734682 := by decide
theorem cert_e605792479130 : check e605792479130 [[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605792482078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605792482078 : Closed e605792482078 ∧ code e605792482078 = 2804815737630 := by decide
private def t_e605792482078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem cert_e605792482078 : ¬ IsSelfInterpreter e605792482078 :=
  wSource (t := t_e605792482078) (replay_sound (ps := []) (t := e605792482078) (by decide)) (by decide)
def e605792482246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605792482246 : Closed e605792482246 ∧ code e605792482246 = 2804815737798 := by decide
private def t_e605792482246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem cert_e605792482246 : ¬ IsSelfInterpreter e605792482246 :=
  wSource (t := t_e605792482246) (replay_sound (ps := []) (t := e605792482246) (by decide)) (by decide)
def e605792483446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605792483446 : Closed e605792483446 ∧ code e605792483446 = 2804815738998 := by decide
private def t_e605792483446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem cert_e605792483446 : ¬ IsSelfInterpreter e605792483446 :=
  wSource (t := t_e605792483446) (replay_sound (ps := []) (t := e605792483446) (by decide)) (by decide)
def e605792483690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605792483690 : Closed e605792483690 ∧ code e605792483690 = 2804815739242 := by decide
private def t_e605792483690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem cert_e605792483690 : ¬ IsSelfInterpreter e605792483690 :=
  wSource (t := t_e605792483690) (replay_sound (ps := []) (t := e605792483690) (by decide)) (by decide)
def e605792483714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605792483714 : Closed e605792483714 ∧ code e605792483714 = 2804815739266 := by decide
private def t_e605792483714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem cert_e605792483714 : ¬ IsSelfInterpreter e605792483714 :=
  wSource (t := t_e605792483714) (replay_sound (ps := []) (t := e605792483714) (by decide)) (by decide)
def e605792483726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605792483726 : Closed e605792483726 ∧ code e605792483726 = 2804815739278 := by decide
private def t_e605792483726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem cert_e605792483726 : ¬ IsSelfInterpreter e605792483726 :=
  wSource (t := t_e605792483726) (replay_sound (ps := []) (t := e605792483726) (by decide)) (by decide)
def e605792483738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605792483738 : Closed e605792483738 ∧ code e605792483738 = 2804815739290 := by decide
private def t_e605792483738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem cert_e605792483738 : ¬ IsSelfInterpreter e605792483738 :=
  wSource (t := t_e605792483738) (replay_sound (ps := []) (t := e605792483738) (by decide)) (by decide)
def e605792483782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605792483782 : Closed e605792483782 ∧ code e605792483782 = 2804815739334 := by decide
private def t_e605792483782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem cert_e605792483782 : ¬ IsSelfInterpreter e605792483782 :=
  wSource (t := t_e605792483782) (replay_sound (ps := []) (t := e605792483782) (by decide)) (by decide)
def e605792485686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e605792485686 : Closed e605792485686 ∧ code e605792485686 = 2804815741238 := by decide
theorem cert_e605792485686 : check e605792485686 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e605792485690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e605792485690 : Closed e605792485690 ∧ code e605792485690 = 2804815741242 := by decide
theorem cert_e605792485690 : check e605792485690 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e605792486326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e605792486326 : Closed e605792486326 ∧ code e605792486326 = 2804815741878 := by decide
theorem cert_e605792486326 : check e605792486326 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e605792486330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e605792486330 : Closed e605792486330 ∧ code e605792486330 = 2804815741882 := by decide
theorem cert_e605792486330 : check e605792486330 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e605792486362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e605792486362 : Closed e605792486362 ∧ code e605792486362 = 2804815741914 := by decide
theorem cert_e605792486362 : check e605792486362 [[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e605792487030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e605792487030 : Closed e605792487030 ∧ code e605792487030 = 2804815742582 := by decide
theorem cert_e605792487030 : check e605792487030 [[],[],[],[],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e605792487222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e605792487222 : Closed e605792487222 ∧ code e605792487222 = 2804815742774 := by decide
theorem cert_e605792487222 : check e605792487222 [[],[],[],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .chain = true := by decide
def e605792487226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e605792487226 : Closed e605792487226 ∧ code e605792487226 = 2804815742778 := by decide
theorem cert_e605792487226 : check e605792487226 [[],[],[],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .chain = true := by decide
def e605792488278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e605792488278 : Closed e605792488278 ∧ code e605792488278 = 2804815743830 := by decide
theorem cert_e605792488278 : check e605792488278 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792488282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e605792488282 : Closed e605792488282 ∧ code e605792488282 = 2804815743834 := by decide
theorem cert_e605792488282 : check e605792488282 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792488298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e605792488298 : Closed e605792488298 ∧ code e605792488298 = 2804815743850 := by decide
theorem cert_e605792488298 : check e605792488298 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792488362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e605792488362 : Closed e605792488362 ∧ code e605792488362 = 2804815743914 := by decide
theorem cert_e605792488362 : check e605792488362 [[],[],[],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e605792488470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e605792488470 : Closed e605792488470 ∧ code e605792488470 = 2804815744022 := by decide
theorem cert_e605792488470 : check e605792488470 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e605792488566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e605792488566 : Closed e605792488566 ∧ code e605792488566 = 2804815744118 := by decide
theorem cert_e605792488566 : check e605792488566 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792488662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e605792488662 : Closed e605792488662 ∧ code e605792488662 = 2804815744214 := by decide
theorem cert_e605792488662 : check e605792488662 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792488666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e605792488666 : Closed e605792488666 ∧ code e605792488666 = 2804815744218 := by decide
theorem cert_e605792488666 : check e605792488666 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792488682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e605792488682 : Closed e605792488682 ∧ code e605792488682 = 2804815744234 := by decide
theorem cert_e605792488682 : check e605792488682 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792488758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e605792488758 : Closed e605792488758 ∧ code e605792488758 = 2804815744310 := by decide
theorem cert_e605792488758 : check e605792488758 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792488762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e605792488762 : Closed e605792488762 ∧ code e605792488762 = 2804815744314 := by decide
theorem cert_e605792488762 : check e605792488762 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792488834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e605792488834 : Closed e605792488834 ∧ code e605792488834 = 2804815744386 := by decide
theorem cert_e605792488834 : check e605792488834 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792488846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e605792488846 : Closed e605792488846 ∧ code e605792488846 = 2804815744398 := by decide
theorem cert_e605792488846 : check e605792488846 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792488858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e605792488858 : Closed e605792488858 ∧ code e605792488858 = 2804815744410 := by decide
theorem cert_e605792488858 : check e605792488858 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792488970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605792488970 : Closed e605792488970 ∧ code e605792488970 = 2804815744522 := by decide
theorem cert_e605792488970 : check e605792488970 [[],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605792489014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605792489014 : Closed e605792489014 ∧ code e605792489014 = 2804815744566 := by decide
theorem cert_e605792489014 : check e605792489014 [[],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e605792489018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605792489018 : Closed e605792489018 ∧ code e605792489018 = 2804815744570 := by decide
def e605792489066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605792489066 : Closed e605792489066 ∧ code e605792489066 = 2804815744618 := by decide
def e605792489090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e605792489090 : Closed e605792489090 ∧ code e605792489090 = 2804815744642 := by decide
theorem cert_e605792489090 : check e605792489090 [[],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e605792489102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605792489102 : Closed e605792489102 ∧ code e605792489102 = 2804815744654 := by decide
theorem cert_e605792489102 : check e605792489102 [[],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e605792489114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605792489114 : Closed e605792489114 ∧ code e605792489114 = 2804815744666 := by decide
def e605792489158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605792489158 : Closed e605792489158 ∧ code e605792489158 = 2804815744710 := by decide
private def t_e605792489158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem cert_e605792489158 : ¬ IsSelfInterpreter e605792489158 :=
  wSource (t := t_e605792489158) (replay_sound (ps := []) (t := e605792489158) (by decide)) (by decide)
def e605792489710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605792489710 : Closed e605792489710 ∧ code e605792489710 = 2804815745262 := by decide
theorem cert_e605792489710 : check e605792489710 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792489718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605792489718 : Closed e605792489718 ∧ code e605792489718 = 2804815745270 := by decide
theorem cert_e605792489718 : check e605792489718 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792490198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605792490198 : Closed e605792490198 ∧ code e605792490198 = 2804815745750 := by decide
theorem cert_e605792490198 : check e605792490198 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792490202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605792490202 : Closed e605792490202 ∧ code e605792490202 = 2804815745754 := by decide
theorem cert_e605792490202 : check e605792490202 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792490218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605792490218 : Closed e605792490218 ∧ code e605792490218 = 2804815745770 := by decide
theorem cert_e605792490218 : check e605792490218 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792490294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605792490294 : Closed e605792490294 ∧ code e605792490294 = 2804815745846 := by decide
theorem cert_e605792490294 : check e605792490294 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792490298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605792490298 : Closed e605792490298 ∧ code e605792490298 = 2804815745850 := by decide
theorem cert_e605792490298 : check e605792490298 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792490370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e605792490370 : Closed e605792490370 ∧ code e605792490370 = 2804815745922 := by decide
theorem cert_e605792490370 : check e605792490370 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e605792490382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e605792490382 : Closed e605792490382 ∧ code e605792490382 = 2804815745934 := by decide
theorem cert_e605792490382 : check e605792490382 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792490394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605792490394 : Closed e605792490394 ∧ code e605792490394 = 2804815745946 := by decide
theorem cert_e605792490394 : check e605792490394 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e605792491638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605792491638 : Closed e605792491638 ∧ code e605792491638 = 2804815747190 := by decide
private def t_e605792491638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem cert_e605792491638 : ¬ IsSelfInterpreter e605792491638 :=
  wSource (t := t_e605792491638) (replay_sound (ps := []) (t := e605792491638) (by decide)) (by decide)
def e605792491882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605792491882 : Closed e605792491882 ∧ code e605792491882 = 2804815747434 := by decide
private def t_e605792491882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem cert_e605792491882 : ¬ IsSelfInterpreter e605792491882 :=
  wSource (t := t_e605792491882) (replay_sound (ps := []) (t := e605792491882) (by decide)) (by decide)
def e605792491906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605792491906 : Closed e605792491906 ∧ code e605792491906 = 2804815747458 := by decide
private def t_e605792491906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem cert_e605792491906 : ¬ IsSelfInterpreter e605792491906 :=
  wSource (t := t_e605792491906) (replay_sound (ps := []) (t := e605792491906) (by decide)) (by decide)
def e605792491918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605792491918 : Closed e605792491918 ∧ code e605792491918 = 2804815747470 := by decide
private def t_e605792491918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem cert_e605792491918 : ¬ IsSelfInterpreter e605792491918 :=
  wSource (t := t_e605792491918) (replay_sound (ps := []) (t := e605792491918) (by decide)) (by decide)
def e605792491930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605792491930 : Closed e605792491930 ∧ code e605792491930 = 2804815747482 := by decide
private def t_e605792491930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem cert_e605792491930 : ¬ IsSelfInterpreter e605792491930 :=
  wSource (t := t_e605792491930) (replay_sound (ps := []) (t := e605792491930) (by decide)) (by decide)
def e605792491974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605792491974 : Closed e605792491974 ∧ code e605792491974 = 2804815747526 := by decide
private def t_e605792491974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem cert_e605792491974 : ¬ IsSelfInterpreter e605792491974 :=
  wSource (t := t_e605792491974) (replay_sound (ps := []) (t := e605792491974) (by decide)) (by decide)
def e605792504686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605792504686 : Closed e605792504686 ∧ code e605792504686 = 2804815760238 := by decide
theorem cert_e605792504686 : check e605792504686 [[],[],[],[]] .smaller = true := by decide
def e605792504694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605792504694 : Closed e605792504694 ∧ code e605792504694 = 2804815760246 := by decide
theorem cert_e605792504694 : check e605792504694 [[],[],[],[]] .smaller = true := by decide
def e605792504750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605792504750 : Closed e605792504750 ∧ code e605792504750 = 2804815760302 := by decide
theorem cert_e605792504750 : check e605792504750 [[],[],[],[]] .smaller = true := by decide
def e605792504762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605792504762 : Closed e605792504762 ∧ code e605792504762 = 2804815760314 := by decide
theorem cert_e605792504762 : check e605792504762 [[],[],[],[]] .smaller = true := by decide
def e605792504790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605792504790 : Closed e605792504790 ∧ code e605792504790 = 2804815760342 := by decide
theorem cert_e605792504790 : check e605792504790 [[],[],[],[]] .smaller = true := by decide
def e605792504794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605792504794 : Closed e605792504794 ∧ code e605792504794 = 2804815760346 := by decide
theorem cert_e605792504794 : check e605792504794 [[],[],[],[]] .smaller = true := by decide
def e605792505070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605792505070 : Closed e605792505070 ∧ code e605792505070 = 2804815760622 := by decide
theorem cert_e605792505070 : check e605792505070 [[],[],[],[]] .smaller = true := by decide
def e605792505078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605792505078 : Closed e605792505078 ∧ code e605792505078 = 2804815760630 := by decide
theorem cert_e605792505078 : check e605792505078 [[],[],[],[]] .smaller = true := by decide
def e605792505454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605792505454 : Closed e605792505454 ∧ code e605792505454 = 2804815761006 := by decide
theorem cert_e605792505454 : check e605792505454 [[],[],[],[]] .smaller = true := by decide
def e605792505466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605792505466 : Closed e605792505466 ∧ code e605792505466 = 2804815761018 := by decide
theorem cert_e605792505466 : check e605792505466 [[],[],[],[]] .smaller = true := by decide
def e605792505654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605792505654 : Closed e605792505654 ∧ code e605792505654 = 2804815761206 := by decide
theorem cert_e605792505654 : check e605792505654 [[],[],[],[]] .smaller = true := by decide
def e605792505658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605792505658 : Closed e605792505658 ∧ code e605792505658 = 2804815761210 := by decide
theorem cert_e605792505658 : check e605792505658 [[],[],[],[]] .smaller = true := by decide
def e605792505790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e605792505790 : Closed e605792505790 ∧ code e605792505790 = 2804815761342 := by decide
theorem cert_e605792505790 : check e605792505790 [[],[],[],[]] .sourceHead = true := by decide
def e605792505822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e605792505822 : Closed e605792505822 ∧ code e605792505822 = 2804815761374 := by decide
theorem cert_e605792505822 : check e605792505822 [[],[],[],[]] .sourceHead = true := by decide
def e605792513502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605792513502 : Closed e605792513502 ∧ code e605792513502 = 2804815769054 := by decide
theorem cert_e605792513502 : check e605792513502 [[],[],[],[]] .sourceHead = true := by decide
def e605792513518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605792513518 : Closed e605792513518 ∧ code e605792513518 = 2804815769070 := by decide
theorem cert_e605792513518 : check e605792513518 [[],[],[],[]] .sourceHead = true := by decide
def e605792513886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605792513886 : Closed e605792513886 ∧ code e605792513886 = 2804815769438 := by decide
theorem cert_e605792513886 : check e605792513886 [[],[],[],[]] .sourceHead = true := by decide
def e605792513914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605792513914 : Closed e605792513914 ∧ code e605792513914 = 2804815769466 := by decide
theorem cert_e605792513914 : check e605792513914 [[],[],[],[]] .sourceHead = true := by decide
def e605792513966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605792513966 : Closed e605792513966 ∧ code e605792513966 = 2804815769518 := by decide
theorem cert_e605792513966 : check e605792513966 [[],[],[],[]] .sourceHead = true := by decide
def e605792513978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605792513978 : Closed e605792513978 ∧ code e605792513978 = 2804815769530 := by decide
theorem cert_e605792513978 : check e605792513978 [[],[],[],[]] .sourceHead = true := by decide
def e605792515038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605792515038 : Closed e605792515038 ∧ code e605792515038 = 2804815770590 := by decide
theorem cert_e605792515038 : check e605792515038 [[],[],[],[]] .sourceHead = true := by decide
def e605792515054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605792515054 : Closed e605792515054 ∧ code e605792515054 = 2804815770606 := by decide
theorem cert_e605792515054 : check e605792515054 [[],[],[],[]] .sourceHead = true := by decide
def e605792517342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605792517342 : Closed e605792517342 ∧ code e605792517342 = 2804815772894 := by decide
theorem cert_e605792517342 : check e605792517342 [[],[],[],[]] .sourceHead = true := by decide
def e605792517370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605792517370 : Closed e605792517370 ∧ code e605792517370 = 2804815772922 := by decide
theorem cert_e605792517370 : check e605792517370 [[],[],[],[]] .sourceHead = true := by decide
def e605792517742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605792517742 : Closed e605792517742 ∧ code e605792517742 = 2804815773294 := by decide
theorem cert_e605792517742 : check e605792517742 [[],[],[],[]] .sourceHead = true := by decide
def e605792517754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605792517754 : Closed e605792517754 ∧ code e605792517754 = 2804815773306 := by decide
theorem cert_e605792517754 : check e605792517754 [[],[],[],[]] .sourceHead = true := by decide
def e605792546158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605792546158 : Closed e605792546158 ∧ code e605792546158 = 2804815801710 := by decide
theorem cert_e605792546158 : check e605792546158 [[],[],[],[]] .sourceHead = true := by decide
def e605792546166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605792546166 : Closed e605792546166 ∧ code e605792546166 = 2804815801718 := by decide
theorem cert_e605792546166 : check e605792546166 [[],[],[],[]] .sourceHead = true := by decide
def e605792546222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605792546222 : Closed e605792546222 ∧ code e605792546222 = 2804815801774 := by decide
theorem cert_e605792546222 : check e605792546222 [[],[],[],[]] .sourceHead = true := by decide
def e605792546234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605792546234 : Closed e605792546234 ∧ code e605792546234 = 2804815801786 := by decide
theorem cert_e605792546234 : check e605792546234 [[],[],[],[]] .sourceHead = true := by decide
def e605792546262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605792546262 : Closed e605792546262 ∧ code e605792546262 = 2804815801814 := by decide
theorem cert_e605792546262 : check e605792546262 [[],[],[],[]] .sourceHead = true := by decide
def e605792546266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605792546266 : Closed e605792546266 ∧ code e605792546266 = 2804815801818 := by decide
theorem cert_e605792546266 : check e605792546266 [[],[],[],[]] .sourceHead = true := by decide
def e605792546478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605792546478 : Closed e605792546478 ∧ code e605792546478 = 2804815802030 := by decide
theorem cert_e605792546478 : check e605792546478 [[],[],[],[]] .sourceHead = true := by decide
def e605792546490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605792546490 : Closed e605792546490 ∧ code e605792546490 = 2804815802042 := by decide
theorem cert_e605792546490 : check e605792546490 [[],[],[],[]] .sourceHead = true := by decide
def e605792546538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605792546538 : Closed e605792546538 ∧ code e605792546538 = 2804815802090 := by decide
theorem cert_e605792546538 : check e605792546538 [[],[],[],[]] .sourceHead = true := by decide
def e605792546646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605792546646 : Closed e605792546646 ∧ code e605792546646 = 2804815802198 := by decide
theorem cert_e605792546646 : check e605792546646 [[],[],[],[]] .sourceHead = true := by decide
def e605792546650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605792546650 : Closed e605792546650 ∧ code e605792546650 = 2804815802202 := by decide
theorem cert_e605792546650 : check e605792546650 [[],[],[],[]] .sourceHead = true := by decide
def e605792546666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605792546666 : Closed e605792546666 ∧ code e605792546666 = 2804815802218 := by decide
theorem cert_e605792546666 : check e605792546666 [[],[],[],[]] .sourceHead = true := by decide
def e605792547694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605792547694 : Closed e605792547694 ∧ code e605792547694 = 2804815803246 := by decide
theorem cert_e605792547694 : check e605792547694 [[],[],[],[]] .sourceHead = true := by decide
def e605792547702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605792547702 : Closed e605792547702 ∧ code e605792547702 = 2804815803254 := by decide
theorem cert_e605792547702 : check e605792547702 [[],[],[],[]] .sourceHead = true := by decide
def e605792547758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605792547758 : Closed e605792547758 ∧ code e605792547758 = 2804815803310 := by decide
theorem cert_e605792547758 : check e605792547758 [[],[],[],[]] .sourceHead = true := by decide
def e605792547770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605792547770 : Closed e605792547770 ∧ code e605792547770 = 2804815803322 := by decide
theorem cert_e605792547770 : check e605792547770 [[],[],[],[]] .sourceHead = true := by decide
def e605792547798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605792547798 : Closed e605792547798 ∧ code e605792547798 = 2804815803350 := by decide
theorem cert_e605792547798 : check e605792547798 [[],[],[],[]] .sourceHead = true := by decide
def e605792547802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605792547802 : Closed e605792547802 ∧ code e605792547802 = 2804815803354 := by decide
theorem cert_e605792547802 : check e605792547802 [[],[],[],[]] .sourceHead = true := by decide
def e605792548078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605792548078 : Closed e605792548078 ∧ code e605792548078 = 2804815803630 := by decide
theorem cert_e605792548078 : check e605792548078 [[],[],[],[]] .sourceHead = true := by decide
def e605792548086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605792548086 : Closed e605792548086 ∧ code e605792548086 = 2804815803638 := by decide
theorem cert_e605792548086 : check e605792548086 [[],[],[],[]] .sourceHead = true := by decide
def e605792548462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605792548462 : Closed e605792548462 ∧ code e605792548462 = 2804815804014 := by decide
theorem cert_e605792548462 : check e605792548462 [[],[],[],[]] .sourceHead = true := by decide
def e605792548474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605792548474 : Closed e605792548474 ∧ code e605792548474 = 2804815804026 := by decide
theorem cert_e605792548474 : check e605792548474 [[],[],[],[]] .sourceHead = true := by decide
def e605792548662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605792548662 : Closed e605792548662 ∧ code e605792548662 = 2804815804214 := by decide
theorem cert_e605792548662 : check e605792548662 [[],[],[],[]] .sourceHead = true := by decide
def e605792548666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605792548666 : Closed e605792548666 ∧ code e605792548666 = 2804815804218 := by decide
theorem cert_e605792548666 : check e605792548666 [[],[],[],[]] .sourceHead = true := by decide
def e605792548910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605792548910 : Closed e605792548910 ∧ code e605792548910 = 2804815804462 := by decide
theorem cert_e605792548910 : check e605792548910 [[],[],[],[]] .sourceHead = true := by decide
def e605792549102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605792549102 : Closed e605792549102 ∧ code e605792549102 = 2804815804654 := by decide
theorem cert_e605792549102 : check e605792549102 [[],[],[],[]] .sourceHead = true := by decide
def e605792549110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605792549110 : Closed e605792549110 ∧ code e605792549110 = 2804815804662 := by decide
theorem cert_e605792549110 : check e605792549110 [[],[],[],[]] .sourceHead = true := by decide
def e605792549294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605792549294 : Closed e605792549294 ∧ code e605792549294 = 2804815804846 := by decide
theorem cert_e605792549294 : check e605792549294 [[],[],[],[]] .sourceHead = true := by decide
def e605792549306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605792549306 : Closed e605792549306 ∧ code e605792549306 = 2804815804858 := by decide
theorem cert_e605792549306 : check e605792549306 [[],[],[],[]] .sourceHead = true := by decide
def e605792549354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605792549354 : Closed e605792549354 ∧ code e605792549354 = 2804815804906 := by decide
theorem cert_e605792549354 : check e605792549354 [[],[],[],[]] .sourceHead = true := by decide
def e605792549486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605792549486 : Closed e605792549486 ∧ code e605792549486 = 2804815805038 := by decide
theorem cert_e605792549486 : check e605792549486 [[],[],[],[]] .sourceHead = true := by decide
def e605792549498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605792549498 : Closed e605792549498 ∧ code e605792549498 = 2804815805050 := by decide
theorem cert_e605792549498 : check e605792549498 [[],[],[],[]] .sourceHead = true := by decide
def e605792549662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605792549662 : Closed e605792549662 ∧ code e605792549662 = 2804815805214 := by decide
theorem cert_e605792549662 : check e605792549662 [[],[],[],[]] .sourceHead = true := by decide
def e605792549762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e605792549762 : Closed e605792549762 ∧ code e605792549762 = 2804815805314 := by decide
theorem cert_e605792549762 : check e605792549762 [[],[],[],[]] .sourceHead = true := by decide
def e605792549774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605792549774 : Closed e605792549774 ∧ code e605792549774 = 2804815805326 := by decide
theorem cert_e605792549774 : check e605792549774 [[],[],[],[]] .sourceHead = true := by decide
def e605792549786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605792549786 : Closed e605792549786 ∧ code e605792549786 = 2804815805338 := by decide
theorem cert_e605792549786 : check e605792549786 [[],[],[],[]] .sourceHead = true := by decide
def e605792549910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605792549910 : Closed e605792549910 ∧ code e605792549910 = 2804815805462 := by decide
theorem cert_e605792549910 : check e605792549910 [[],[],[],[]] .sourceHead = true := by decide
def e605792550006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e605792550006 : Closed e605792550006 ∧ code e605792550006 = 2804815805558 := by decide
theorem cert_e605792550006 : check e605792550006 [[],[],[],[]] .sourceHead = true := by decide
def e605792550102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605792550102 : Closed e605792550102 ∧ code e605792550102 = 2804815805654 := by decide
theorem cert_e605792550102 : check e605792550102 [[],[],[],[]] .sourceHead = true := by decide
def e605792550106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605792550106 : Closed e605792550106 ∧ code e605792550106 = 2804815805658 := by decide
theorem cert_e605792550106 : check e605792550106 [[],[],[],[]] .sourceHead = true := by decide
def e605792550122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605792550122 : Closed e605792550122 ∧ code e605792550122 = 2804815805674 := by decide
theorem cert_e605792550122 : check e605792550122 [[],[],[],[]] .sourceHead = true := by decide
def e605792550198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605792550198 : Closed e605792550198 ∧ code e605792550198 = 2804815805750 := by decide
theorem cert_e605792550198 : check e605792550198 [[],[],[],[]] .sourceHead = true := by decide
def e605792550202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605792550202 : Closed e605792550202 ∧ code e605792550202 = 2804815805754 := by decide
theorem cert_e605792550202 : check e605792550202 [[],[],[],[]] .sourceHead = true := by decide
def e605792550274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e605792550274 : Closed e605792550274 ∧ code e605792550274 = 2804815805826 := by decide
theorem cert_e605792550274 : check e605792550274 [[],[],[],[]] .sourceHead = true := by decide
def e605792550286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e605792550286 : Closed e605792550286 ∧ code e605792550286 = 2804815805838 := by decide
theorem cert_e605792550286 : check e605792550286 [[],[],[],[]] .sourceHead = true := by decide
def e605792550298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605792550298 : Closed e605792550298 ∧ code e605792550298 = 2804815805850 := by decide
theorem cert_e605792550298 : check e605792550298 [[],[],[],[]] .sourceHead = true := by decide
def e605792551902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e605792551902 : Closed e605792551902 ∧ code e605792551902 = 2804815807454 := by decide
theorem cert_e605792551902 : check e605792551902 [[],[],[],[]] .sourceHead = true := by decide
def e605792551918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e605792551918 : Closed e605792551918 ∧ code e605792551918 = 2804815807470 := by decide
theorem cert_e605792551918 : check e605792551918 [[],[],[],[]] .sourceHead = true := by decide
def e605792553838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605792553838 : Closed e605792553838 ∧ code e605792553838 = 2804815809390 := by decide
theorem cert_e605792553838 : check e605792553838 [[],[],[],[]] .sourceHead = true := by decide
def e605792553846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605792553846 : Closed e605792553846 ∧ code e605792553846 = 2804815809398 := by decide
theorem cert_e605792553846 : check e605792553846 [[],[],[],[]] .sourceHead = true := by decide
def e605792553902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605792553902 : Closed e605792553902 ∧ code e605792553902 = 2804815809454 := by decide
theorem cert_e605792553902 : check e605792553902 [[],[],[],[]] .sourceHead = true := by decide
def e605792553914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605792553914 : Closed e605792553914 ∧ code e605792553914 = 2804815809466 := by decide
theorem cert_e605792553914 : check e605792553914 [[],[],[],[]] .sourceHead = true := by decide
def e605792553942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605792553942 : Closed e605792553942 ∧ code e605792553942 = 2804815809494 := by decide
theorem cert_e605792553942 : check e605792553942 [[],[],[],[]] .sourceHead = true := by decide
def e605792553946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605792553946 : Closed e605792553946 ∧ code e605792553946 = 2804815809498 := by decide
theorem cert_e605792553946 : check e605792553946 [[],[],[],[]] .sourceHead = true := by decide
def e605792554222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605792554222 : Closed e605792554222 ∧ code e605792554222 = 2804815809774 := by decide
theorem cert_e605792554222 : check e605792554222 [[],[],[],[]] .sourceHead = true := by decide
def e605792554230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605792554230 : Closed e605792554230 ∧ code e605792554230 = 2804815809782 := by decide
theorem cert_e605792554230 : check e605792554230 [[],[],[],[]] .sourceHead = true := by decide
def e605792554606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605792554606 : Closed e605792554606 ∧ code e605792554606 = 2804815810158 := by decide
theorem cert_e605792554606 : check e605792554606 [[],[],[],[]] .sourceHead = true := by decide
def e605792554618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605792554618 : Closed e605792554618 ∧ code e605792554618 = 2804815810170 := by decide
theorem cert_e605792554618 : check e605792554618 [[],[],[],[]] .sourceHead = true := by decide
def e605792554806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605792554806 : Closed e605792554806 ∧ code e605792554806 = 2804815810358 := by decide
theorem cert_e605792554806 : check e605792554806 [[],[],[],[]] .sourceHead = true := by decide
def e605792554810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605792554810 : Closed e605792554810 ∧ code e605792554810 = 2804815810362 := by decide
theorem cert_e605792554810 : check e605792554810 [[],[],[],[]] .sourceHead = true := by decide
end Blc.Floor41
