import CodeBridge
import Batch031
namespace Certgen.R596279823214
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 9,.lam 2,.app 3 8,.app 4 7,.app 5 6,.var 0,.var 0,.var 0,.var 0,.lam 10,.app 11 12,.var 0,.lam 13,.lam 14,.app 15 18,.app 16 17,.var 0,.var 1,.var 2]
def values : Array (List AClo) := #[[⟨9,[]⟩],[⟨12,[3]⟩,⟨17,[2,1,3]⟩],[⟨7,[0]⟩,⟨18,[2,1,3]⟩],[⟨6,[0]⟩,⟨12,[3]⟩,⟨17,[2,1,3]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨9,[]⟩,0⟩],[⟨⟨12,[3]⟩,3⟩,⟨⟨12,[3]⟩,6⟩],[⟨⟨18,[2,1,3]⟩,5⟩],[⟨⟨17,[2,1,3]⟩,3⟩],[⟨⟨8,[0]⟩,0⟩],[⟨⟨7,[0]⟩,5⟩],[⟨⟨6,[0]⟩,6⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[0]⟩,0⟩,⟨⟨3,[0]⟩,5⟩,⟨⟨4,[0]⟩,6⟩,⟨⟨5,[0]⟩,7⟩,⟨⟨6,[0]⟩,2⟩,⟨⟨6,[0]⟩,4⟩,⟨⟨7,[0]⟩,4⟩,⟨⟨9,[]⟩,2⟩,⟨⟨9,[]⟩,4⟩,⟨⟨9,[]⟩,7⟩,⟨⟨10,[3]⟩,3⟩,⟨⟨10,[3]⟩,6⟩,⟨⟨11,[3]⟩,2⟩,⟨⟨12,[3]⟩,2⟩,⟨⟨12,[3]⟩,4⟩,⟨⟨13,[1,3]⟩,3⟩,⟨⟨13,[1,3]⟩,6⟩,⟨⟨14,[2,1,3]⟩,5⟩,⟨⟨15,[2,1,3]⟩,3⟩,⟨⟨16,[2,1,3]⟩,4⟩,⟨⟨17,[2,1,3]⟩,2⟩,⟨⟨17,[2,1,3]⟩,4⟩,⟨⟨18,[2,1,3]⟩,4⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[4],[5],[11],[9],[10],[10],[12,13],[12],[13],[14],[14],[6,15,22],[17,18],[17],[19],[19],[20],[21],[8,24],[15,22],[16,23],[7,16,23]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem block24 : checkRange P V K states hints 24 1=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<25 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 by_cases h12 : i<24
 · exact range_sound block12 i (by omega) h12 hi
 exact range_sound block24 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Floor41 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit16 : Term := .var 0
def lit17 : Term := .var 1
def lit18 : Term := .var 2
def lit4 : Term := .app lit16 lit16
def lit15 : Term := .app lit16 lit17
def lit3 : Term := .app lit4 lit16
def lit14 : Term := .app lit15 lit18
def lit2 : Term := .app lit3 lit16
def lit13 : Term := .lam lit14
def lit1 : Term := .lam lit2
def lit12 : Term := .lam lit13
def lit10 : Term := .app lit16 lit12
def lit9 : Term := .lam lit10
def lit0 : Term := .app lit1 lit9
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub18 : model.term 18 = lit18 := model.var_eq 18 2 (by rfl)
theorem sub17 : model.term 17 = lit17 := model.var_eq 17 1 (by rfl)
theorem sub16 : model.term 16 = lit16 := model.var_eq 16 0 (by rfl)
theorem sub15 : model.term 15 = lit15 := by rw [model.app_eq 15 16 17 (by rfl), sub16, sub17]; rfl
theorem sub14 : model.term 14 = lit14 := by rw [model.app_eq 14 15 18 (by rfl), sub15, sub18]; rfl
theorem sub13 : model.term 13 = lit13 := by rw [model.lam_eq 13 14 (by rfl), sub14]; rfl
theorem sub12 : model.term 12 = lit12 := by rw [model.lam_eq 12 13 (by rfl), sub13]; rfl
theorem sub11 : model.term 11 = lit16 := model.var_eq 11 0 (by rfl)
theorem sub10 : model.term 10 = lit10 := by rw [model.app_eq 10 11 12 (by rfl), sub11, sub12]; rfl
theorem sub9 : model.term 9 = lit9 := by rw [model.lam_eq 9 10 (by rfl), sub10]; rfl
theorem sub8 : model.term 8 = lit16 := model.var_eq 8 0 (by rfl)
theorem sub7 : model.term 7 = lit16 := model.var_eq 7 0 (by rfl)
theorem sub6 : model.term 6 = lit16 := model.var_eq 6 0 (by rfl)
theorem sub5 : model.term 5 = lit16 := model.var_eq 5 0 (by rfl)
theorem sub4 : model.term 4 = lit4 := by rw [model.app_eq 4 5 6 (by rfl), sub5, sub6]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 7 (by rfl), sub4, sub7]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 8 (by rfl), sub3, sub8]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.lam_eq 1 2 (by rfl), sub2]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 9 (by rfl), sub1, sub9]; rfl
theorem excluded : ¬ IsSelfInterpreter e596279823214 := by
 intro he
 have hp : replay [] e596279823214 = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (rawCount he) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R596279823214
