import CodeBridge
import Batch044
namespace Certgen.R598356003798
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 7,.lam 2,.app 3 6,.app 4 5,.var 0,.var 0,.var 0,.lam 8,.app 9 10,.var 0,.app 11 12,.var 0,.lam 13,.lam 14,.app 15 18,.app 16 17,.var 2,.var 0,.var 1]
def values : Array (List AClo) := #[[⟨7,[]⟩],[⟨10,[3]⟩,⟨12,[3]⟩,⟨17,[2,1,3]⟩],[⟨6,[0]⟩,⟨10,[3]⟩,⟨12,[3]⟩,⟨17,[2,1,3]⟩,⟨18,[2,1,3]⟩],[⟨5,[0]⟩,⟨10,[3]⟩,⟨12,[3]⟩,⟨17,[2,1,3]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨7,[]⟩,0⟩],[⟨⟨12,[3]⟩,2⟩,⟨⟨12,[3]⟩,4⟩,⟨⟨12,[3]⟩,7⟩],[⟨⟨18,[2,1,3]⟩,0⟩,⟨⟨18,[2,1,3]⟩,2⟩,⟨⟨18,[2,1,3]⟩,3⟩,⟨⟨18,[2,1,3]⟩,4⟩,⟨⟨18,[2,1,3]⟩,5⟩,⟨⟨18,[2,1,3]⟩,7⟩],[⟨⟨17,[2,1,3]⟩,3⟩],[⟨⟨6,[0]⟩,0⟩],[⟨⟨5,[0]⟩,5⟩],[⟨⟨10,[3]⟩,2⟩,⟨⟨10,[3]⟩,3⟩,⟨⟨10,[3]⟩,4⟩,⟨⟨10,[3]⟩,5⟩,⟨⟨10,[3]⟩,7⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[0]⟩,0⟩,⟨⟨3,[0]⟩,5⟩,⟨⟨4,[0]⟩,6⟩,⟨⟨5,[0]⟩,2⟩,⟨⟨5,[0]⟩,4⟩,⟨⟨5,[0]⟩,7⟩,⟨⟨6,[0]⟩,2⟩,⟨⟨6,[0]⟩,4⟩,⟨⟨6,[0]⟩,7⟩,⟨⟨7,[]⟩,2⟩,⟨⟨7,[]⟩,4⟩,⟨⟨7,[]⟩,6⟩,⟨⟨7,[]⟩,7⟩,⟨⟨8,[3]⟩,2⟩,⟨⟨8,[3]⟩,3⟩,⟨⟨8,[3]⟩,4⟩,⟨⟨8,[3]⟩,5⟩,⟨⟨8,[3]⟩,7⟩,⟨⟨9,[3]⟩,7⟩,⟨⟨10,[3]⟩,2⟩,⟨⟨10,[3]⟩,4⟩,⟨⟨10,[3]⟩,7⟩,⟨⟨11,[3]⟩,2⟩,⟨⟨12,[3]⟩,2⟩,⟨⟨12,[3]⟩,4⟩,⟨⟨12,[3]⟩,7⟩,⟨⟨13,[1,3]⟩,2⟩,⟨⟨13,[1,3]⟩,3⟩,⟨⟨13,[1,3]⟩,4⟩,⟨⟨13,[1,3]⟩,5⟩,⟨⟨13,[1,3]⟩,7⟩,⟨⟨14,[2,1,3]⟩,0⟩,⟨⟨14,[2,1,3]⟩,2⟩,⟨⟨14,[2,1,3]⟩,3⟩,⟨⟨14,[2,1,3]⟩,4⟩,⟨⟨14,[2,1,3]⟩,5⟩,⟨⟨14,[2,1,3]⟩,7⟩,⟨⟨15,[2,1,3]⟩,3⟩,⟨⟨16,[2,1,3]⟩,4⟩,⟨⟨17,[2,1,3]⟩,2⟩,⟨⟨17,[2,1,3]⟩,4⟩,⟨⟨17,[2,1,3]⟩,7⟩,⟨⟨18,[2,1,3]⟩,2⟩,⟨⟨18,[2,1,3]⟩,4⟩,⟨⟨18,[2,1,3]⟩,7⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[4],[13],[11],[12],[14],[11],[12],[14],[15,17,19],[16],[18],[15,16,17,18,19],[20],[20],[20],[20],[20],[7,23,27,43],[24],[24],[24],[5,21,25,41],[28,30,32],[29],[28,29,30,31,32],[34,36,38],[33,34,35,36,37,38],[35],[33],[34,35,36,37,38],[39],[39],[39],[39],[39],[39],[40],[6,22,26,42],[8,21,25,41,44],[9,22,26,42,45],[10,23,27,43,46],[21,25,41],[22,26,42],[23,27,43]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem block24 : checkRange P V K states hints 24 12=true := by decide
theorem block36 : checkRange P V K states hints 36 11=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<47 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 by_cases h12 : i<24
 · exact range_sound block12 i (by omega) h12 hi
 by_cases h24 : i<36
 · exact range_sound block24 i (by omega) h24 hi
 exact range_sound block36 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Floor41 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit17 : Term := .var 0
def lit18 : Term := .var 1
def lit16 : Term := .var 2
def lit3 : Term := .app lit17 lit17
def lit15 : Term := .app lit16 lit17
def lit2 : Term := .app lit3 lit17
def lit1 : Term := .lam lit2
def lit14 : Term := .app lit15 lit18
def lit13 : Term := .lam lit14
def lit12 : Term := .lam lit13
def lit10 : Term := .app lit17 lit12
def lit8 : Term := .app lit17 lit10
def lit7 : Term := .lam lit8
def lit0 : Term := .app lit1 lit7
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub18 : model.term 18 = lit18 := model.var_eq 18 1 (by rfl)
theorem sub17 : model.term 17 = lit17 := model.var_eq 17 0 (by rfl)
theorem sub16 : model.term 16 = lit16 := model.var_eq 16 2 (by rfl)
theorem sub15 : model.term 15 = lit15 := by rw [model.app_eq 15 16 17 (by rfl), sub16, sub17]; rfl
theorem sub14 : model.term 14 = lit14 := by rw [model.app_eq 14 15 18 (by rfl), sub15, sub18]; rfl
theorem sub13 : model.term 13 = lit13 := by rw [model.lam_eq 13 14 (by rfl), sub14]; rfl
theorem sub12 : model.term 12 = lit12 := by rw [model.lam_eq 12 13 (by rfl), sub13]; rfl
theorem sub11 : model.term 11 = lit17 := model.var_eq 11 0 (by rfl)
theorem sub10 : model.term 10 = lit10 := by rw [model.app_eq 10 11 12 (by rfl), sub11, sub12]; rfl
theorem sub9 : model.term 9 = lit17 := model.var_eq 9 0 (by rfl)
theorem sub8 : model.term 8 = lit8 := by rw [model.app_eq 8 9 10 (by rfl), sub9, sub10]; rfl
theorem sub7 : model.term 7 = lit7 := by rw [model.lam_eq 7 8 (by rfl), sub8]; rfl
theorem sub6 : model.term 6 = lit17 := model.var_eq 6 0 (by rfl)
theorem sub5 : model.term 5 = lit17 := model.var_eq 5 0 (by rfl)
theorem sub4 : model.term 4 = lit17 := model.var_eq 4 0 (by rfl)
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 5 (by rfl), sub4, sub5]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 6 (by rfl), sub3, sub6]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.lam_eq 1 2 (by rfl), sub2]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 7 (by rfl), sub1, sub7]; rfl
theorem excluded : ¬ IsSelfInterpreter e598356003798 := by
 intro he
 have hp : replay [] e598356003798 = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (rawCount he) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R598356003798
