import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605591170682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605591170682 : Closed e605591170682 ∧ code e605591170682 = 2804614426234 := by decide
theorem cert_e605591170682 : check e605591170682 [[],[]] .smaller = true := by decide
def e605591170870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605591170870 : Closed e605591170870 ∧ code e605591170870 = 2804614426422 := by decide
theorem cert_e605591170870 : check e605591170870 [[],[]] .smaller = true := by decide
def e605591170874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605591170874 : Closed e605591170874 ∧ code e605591170874 = 2804614426426 := by decide
theorem cert_e605591170874 : check e605591170874 [[],[]] .smaller = true := by decide
def e605591170970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 4)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591170970 : Closed e605591170970 ∧ code e605591170970 = 2804614426522 := by decide
theorem cert_e605591170970 : check e605591170970 [[],[]] .three = true := by decide
def e605591171934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e605591171934 : Closed e605591171934 ∧ code e605591171934 = 2804614427486 := by decide
theorem cert_e605591171934 : check e605591171934 [[],[]] .three = true := by decide
def e605591171962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e605591171962 : Closed e605591171962 ∧ code e605591171962 = 2804614427514 := by decide
theorem cert_e605591171962 : check e605591171962 [[],[]] .three = true := by decide
def e605591172074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e605591172074 : Closed e605591172074 ∧ code e605591172074 = 2804614427626 := by decide
theorem cert_e605591172074 : check e605591172074 [[],[]] .three = true := by decide
def e605591172318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605591172318 : Closed e605591172318 ∧ code e605591172318 = 2804614427870 := by decide
theorem cert_e605591172318 : check e605591172318 [[],[]] .three = true := by decide
def e605591172346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605591172346 : Closed e605591172346 ∧ code e605591172346 = 2804614427898 := by decide
theorem cert_e605591172346 : check e605591172346 [[],[]] .three = true := by decide
def e605591173018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591173018 : Closed e605591173018 ∧ code e605591173018 = 2804614428570 := by decide
theorem cert_e605591173018 : check e605591173018 [[],[]] .three = true := by decide
def e605591178094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e605591178094 : Closed e605591178094 ∧ code e605591178094 = 2804614433646 := by decide
theorem cert_e605591178094 : check e605591178094 [[],[]] .smaller = true := by decide
def e605591178102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e605591178102 : Closed e605591178102 ∧ code e605591178102 = 2804614433654 := by decide
theorem cert_e605591178102 : check e605591178102 [[],[]] .smaller = true := by decide
def e605591178158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e605591178158 : Closed e605591178158 ∧ code e605591178158 = 2804614433710 := by decide
theorem cert_e605591178158 : check e605591178158 [[],[]] .smaller = true := by decide
def e605591178170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e605591178170 : Closed e605591178170 ∧ code e605591178170 = 2804614433722 := by decide
theorem cert_e605591178170 : check e605591178170 [[],[]] .smaller = true := by decide
def e605591178198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e605591178198 : Closed e605591178198 ∧ code e605591178198 = 2804614433750 := by decide
theorem cert_e605591178198 : check e605591178198 [[],[]] .smaller = true := by decide
def e605591178202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e605591178202 : Closed e605591178202 ∧ code e605591178202 = 2804614433754 := by decide
theorem cert_e605591178202 : check e605591178202 [[],[]] .smaller = true := by decide
def e605591178478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e605591178478 : Closed e605591178478 ∧ code e605591178478 = 2804614434030 := by decide
theorem cert_e605591178478 : check e605591178478 [[],[]] .smaller = true := by decide
def e605591178486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e605591178486 : Closed e605591178486 ∧ code e605591178486 = 2804614434038 := by decide
theorem cert_e605591178486 : check e605591178486 [[],[]] .smaller = true := by decide
def e605591178862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e605591178862 : Closed e605591178862 ∧ code e605591178862 = 2804614434414 := by decide
theorem cert_e605591178862 : check e605591178862 [[],[]] .smaller = true := by decide
def e605591178874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e605591178874 : Closed e605591178874 ∧ code e605591178874 = 2804614434426 := by decide
theorem cert_e605591178874 : check e605591178874 [[],[]] .smaller = true := by decide
def e605591179062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e605591179062 : Closed e605591179062 ∧ code e605591179062 = 2804614434614 := by decide
theorem cert_e605591179062 : check e605591179062 [[],[]] .smaller = true := by decide
def e605591179066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e605591179066 : Closed e605591179066 ∧ code e605591179066 = 2804614434618 := by decide
theorem cert_e605591179066 : check e605591179066 [[],[]] .smaller = true := by decide
def e605591186878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 4))))))))))
theorem wire_e605591186878 : Closed e605591186878 ∧ code e605591186878 = 2804614442430 := by decide
theorem cert_e605591186878 : check e605591186878 [[],[]] .smaller = true := by decide
def e605591186934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 4)) (.var 1))))))))))
theorem wire_e605591186934 : Closed e605591186934 ∧ code e605591186934 = 2804614442486 := by decide
theorem cert_e605591186934 : check e605591186934 [[],[]] .smaller = true := by decide
def e605591187134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 4))))))))))
theorem wire_e605591187134 : Closed e605591187134 ∧ code e605591187134 = 2804614442686 := by decide
theorem cert_e605591187134 : check e605591187134 [[],[]] .smaller = true := by decide
def e605591187194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 4)) (.var 0))))))))))
theorem wire_e605591187194 : Closed e605591187194 ∧ code e605591187194 = 2804614442746 := by decide
theorem cert_e605591187194 : check e605591187194 [[],[]] .smaller = true := by decide
def e605591187414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 0)) (.var 1))))))))))
theorem wire_e605591187414 : Closed e605591187414 ∧ code e605591187414 = 2804614442966 := by decide
theorem cert_e605591187414 : check e605591187414 [[],[]] .smaller = true := by decide
def e605591187418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 1)) (.var 0))))))))))
theorem wire_e605591187418 : Closed e605591187418 ∧ code e605591187418 = 2804614442970 := by decide
theorem cert_e605591187418 : check e605591187418 [[],[]] .smaller = true := by decide
def e605591188414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 4)))))))))))
theorem wire_e605591188414 : Closed e605591188414 ∧ code e605591188414 = 2804614443966 := by decide
theorem cert_e605591188414 : check e605591188414 [[],[]] .smaller = true := by decide
def e605591188470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 4) (.var 1)))))))))))
theorem wire_e605591188470 : Closed e605591188470 ∧ code e605591188470 = 2804614444022 := by decide
theorem cert_e605591188470 : check e605591188470 [[],[]] .smaller = true := by decide
def e605591189950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 4)))))))))))
theorem wire_e605591189950 : Closed e605591189950 ∧ code e605591189950 = 2804614445502 := by decide
theorem cert_e605591189950 : check e605591189950 [[],[]] .smaller = true := by decide
def e605591190010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 4) (.var 0)))))))))))
theorem wire_e605591190010 : Closed e605591190010 ∧ code e605591190010 = 2804614445562 := by decide
theorem cert_e605591190010 : check e605591190010 [[],[]] .smaller = true := by decide
def e605591191350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605591191350 : Closed e605591191350 ∧ code e605591191350 = 2804614446902 := by decide
theorem cert_e605591191350 : check e605591191350 [[],[]] .smaller = true := by decide
def e605591191354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605591191354 : Closed e605591191354 ∧ code e605591191354 = 2804614446906 := by decide
theorem cert_e605591191354 : check e605591191354 [[],[]] .smaller = true := by decide
def e605591219566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e605591219566 : Closed e605591219566 ∧ code e605591219566 = 2804614475118 := by decide
theorem cert_e605591219566 : check e605591219566 [[],[]] .smaller = true := by decide
def e605591219574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e605591219574 : Closed e605591219574 ∧ code e605591219574 = 2804614475126 := by decide
theorem cert_e605591219574 : check e605591219574 [[],[]] .smaller = true := by decide
def e605591219630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e605591219630 : Closed e605591219630 ∧ code e605591219630 = 2804614475182 := by decide
theorem cert_e605591219630 : check e605591219630 [[],[]] .smaller = true := by decide
def e605591219642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e605591219642 : Closed e605591219642 ∧ code e605591219642 = 2804614475194 := by decide
theorem cert_e605591219642 : check e605591219642 [[],[]] .smaller = true := by decide
def e605591219670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e605591219670 : Closed e605591219670 ∧ code e605591219670 = 2804614475222 := by decide
theorem cert_e605591219670 : check e605591219670 [[],[]] .smaller = true := by decide
def e605591219674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e605591219674 : Closed e605591219674 ∧ code e605591219674 = 2804614475226 := by decide
theorem cert_e605591219674 : check e605591219674 [[],[]] .smaller = true := by decide
def e605591219886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e605591219886 : Closed e605591219886 ∧ code e605591219886 = 2804614475438 := by decide
theorem cert_e605591219886 : check e605591219886 [[],[]] .smaller = true := by decide
def e605591219898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e605591219898 : Closed e605591219898 ∧ code e605591219898 = 2804614475450 := by decide
theorem cert_e605591219898 : check e605591219898 [[],[]] .smaller = true := by decide
def e605591219946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e605591219946 : Closed e605591219946 ∧ code e605591219946 = 2804614475498 := by decide
theorem cert_e605591219946 : check e605591219946 [[],[]] .smaller = true := by decide
def e605591220054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e605591220054 : Closed e605591220054 ∧ code e605591220054 = 2804614475606 := by decide
theorem cert_e605591220054 : check e605591220054 [[],[]] .smaller = true := by decide
def e605591220058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e605591220058 : Closed e605591220058 ∧ code e605591220058 = 2804614475610 := by decide
theorem cert_e605591220058 : check e605591220058 [[],[]] .smaller = true := by decide
def e605591220074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e605591220074 : Closed e605591220074 ∧ code e605591220074 = 2804614475626 := by decide
theorem cert_e605591220074 : check e605591220074 [[],[]] .smaller = true := by decide
def e605591220702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 3)))))))))
theorem wire_e605591220702 : Closed e605591220702 ∧ code e605591220702 = 2804614476254 := by decide
theorem cert_e605591220702 : check e605591220702 [[],[]] .smaller = true := by decide
def e605591220726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.var 1)))))))))
theorem wire_e605591220726 : Closed e605591220726 ∧ code e605591220726 = 2804614476278 := by decide
theorem cert_e605591220726 : check e605591220726 [[],[]] .smaller = true := by decide
def e605591221102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e605591221102 : Closed e605591221102 ∧ code e605591221102 = 2804614476654 := by decide
theorem cert_e605591221102 : check e605591221102 [[],[]] .smaller = true := by decide
def e605591221110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e605591221110 : Closed e605591221110 ∧ code e605591221110 = 2804614476662 := by decide
theorem cert_e605591221110 : check e605591221110 [[],[]] .smaller = true := by decide
def e605591221166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e605591221166 : Closed e605591221166 ∧ code e605591221166 = 2804614476718 := by decide
theorem cert_e605591221166 : check e605591221166 [[],[]] .smaller = true := by decide
def e605591221178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e605591221178 : Closed e605591221178 ∧ code e605591221178 = 2804614476730 := by decide
theorem cert_e605591221178 : check e605591221178 [[],[]] .smaller = true := by decide
def e605591221206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e605591221206 : Closed e605591221206 ∧ code e605591221206 = 2804614476758 := by decide
theorem cert_e605591221206 : check e605591221206 [[],[]] .smaller = true := by decide
def e605591221210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e605591221210 : Closed e605591221210 ∧ code e605591221210 = 2804614476762 := by decide
theorem cert_e605591221210 : check e605591221210 [[],[]] .smaller = true := by decide
def e605591221486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e605591221486 : Closed e605591221486 ∧ code e605591221486 = 2804614477038 := by decide
theorem cert_e605591221486 : check e605591221486 [[],[]] .smaller = true := by decide
def e605591221494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e605591221494 : Closed e605591221494 ∧ code e605591221494 = 2804614477046 := by decide
theorem cert_e605591221494 : check e605591221494 [[],[]] .smaller = true := by decide
def e605591221822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 4))))))))))
theorem wire_e605591221822 : Closed e605591221822 ∧ code e605591221822 = 2804614477374 := by decide
theorem cert_e605591221822 : check e605591221822 [[],[]] .smaller = true := by decide
def e605591221870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605591221870 : Closed e605591221870 ∧ code e605591221870 = 2804614477422 := by decide
theorem cert_e605591221870 : check e605591221870 [[],[]] .smaller = true := by decide
def e605591221882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605591221882 : Closed e605591221882 ∧ code e605591221882 = 2804614477434 := by decide
theorem cert_e605591221882 : check e605591221882 [[],[]] .smaller = true := by decide
def e605591222070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605591222070 : Closed e605591222070 ∧ code e605591222070 = 2804614477622 := by decide
theorem cert_e605591222070 : check e605591222070 [[],[]] .smaller = true := by decide
def e605591222074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605591222074 : Closed e605591222074 ∧ code e605591222074 = 2804614477626 := by decide
theorem cert_e605591222074 : check e605591222074 [[],[]] .smaller = true := by decide
def e605591222158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 2))))))))))
theorem wire_e605591222158 : Closed e605591222158 ∧ code e605591222158 = 2804614477710 := by decide
theorem cert_e605591222158 : check e605591222158 [[],[]] .smaller = true := by decide
def e605591222206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 4)))))))))
theorem wire_e605591222206 : Closed e605591222206 ∧ code e605591222206 = 2804614477758 := by decide
theorem cert_e605591222206 : check e605591222206 [[],[]] .three = true := by decide
def e605591222238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 3)))))))))
theorem wire_e605591222238 : Closed e605591222238 ∧ code e605591222238 = 2804614477790 := by decide
theorem cert_e605591222238 : check e605591222238 [[],[]] .three = true := by decide
def e605591222494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e605591222494 : Closed e605591222494 ∧ code e605591222494 = 2804614478046 := by decide
theorem cert_e605591222494 : check e605591222494 [[],[]] .smaller = true := by decide
def e605591222510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e605591222510 : Closed e605591222510 ∧ code e605591222510 = 2804614478062 := by decide
theorem cert_e605591222510 : check e605591222510 [[],[]] .smaller = true := by decide
def e605591222518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e605591222518 : Closed e605591222518 ∧ code e605591222518 = 2804614478070 := by decide
theorem cert_e605591222518 : check e605591222518 [[],[]] .smaller = true := by decide
def e605591222522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e605591222522 : Closed e605591222522 ∧ code e605591222522 = 2804614478074 := by decide
theorem cert_e605591222522 : check e605591222522 [[],[]] .smaller = true := by decide
def e605591222702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e605591222702 : Closed e605591222702 ∧ code e605591222702 = 2804614478254 := by decide
theorem cert_e605591222702 : check e605591222702 [[],[]] .smaller = true := by decide
def e605591222714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e605591222714 : Closed e605591222714 ∧ code e605591222714 = 2804614478266 := by decide
theorem cert_e605591222714 : check e605591222714 [[],[]] .smaller = true := by decide
def e605591222762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e605591222762 : Closed e605591222762 ∧ code e605591222762 = 2804614478314 := by decide
theorem cert_e605591222762 : check e605591222762 [[],[]] .smaller = true := by decide
def e605591222846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e605591222846 : Closed e605591222846 ∧ code e605591222846 = 2804614478398 := by decide
theorem cert_e605591222846 : check e605591222846 [[],[]] .smaller = true := by decide
def e605591222894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605591222894 : Closed e605591222894 ∧ code e605591222894 = 2804614478446 := by decide
theorem cert_e605591222894 : check e605591222894 [[],[]] .smaller = true := by decide
def e605591222906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605591222906 : Closed e605591222906 ∧ code e605591222906 = 2804614478458 := by decide
theorem cert_e605591222906 : check e605591222906 [[],[]] .smaller = true := by decide
def e605591223070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e605591223070 : Closed e605591223070 ∧ code e605591223070 = 2804614478622 := by decide
theorem cert_e605591223070 : check e605591223070 [[],[]] .smaller = true := by decide
def e605591223182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e605591223182 : Closed e605591223182 ∧ code e605591223182 = 2804614478734 := by decide
theorem cert_e605591223182 : check e605591223182 [[],[]] .smaller = true := by decide
def e605591223194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591223194 : Closed e605591223194 ∧ code e605591223194 = 2804614478746 := by decide
theorem cert_e605591223194 : check e605591223194 [[],[]] .smaller = true := by decide
def e605591223238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e605591223238 : Closed e605591223238 ∧ code e605591223238 = 2804614478790 := by decide
theorem cert_e605591223238 : check e605591223238 [[],[]] .smaller = true := by decide
def e605591223262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 3)))))))))
theorem wire_e605591223262 : Closed e605591223262 ∧ code e605591223262 = 2804614478814 := by decide
theorem cert_e605591223262 : check e605591223262 [[],[]] .smaller = true := by decide
def e605591223414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e605591223414 : Closed e605591223414 ∧ code e605591223414 = 2804614478966 := by decide
theorem cert_e605591223414 : check e605591223414 [[],[]] .smaller = true := by decide
def e605591223510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e605591223510 : Closed e605591223510 ∧ code e605591223510 = 2804614479062 := by decide
theorem cert_e605591223510 : check e605591223510 [[],[]] .smaller = true := by decide
def e605591223514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e605591223514 : Closed e605591223514 ∧ code e605591223514 = 2804614479066 := by decide
theorem cert_e605591223514 : check e605591223514 [[],[]] .smaller = true := by decide
def e605591223530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e605591223530 : Closed e605591223530 ∧ code e605591223530 = 2804614479082 := by decide
theorem cert_e605591223530 : check e605591223530 [[],[]] .smaller = true := by decide
def e605591223606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605591223606 : Closed e605591223606 ∧ code e605591223606 = 2804614479158 := by decide
theorem cert_e605591223606 : check e605591223606 [[],[]] .smaller = true := by decide
def e605591223610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605591223610 : Closed e605591223610 ∧ code e605591223610 = 2804614479162 := by decide
theorem cert_e605591223610 : check e605591223610 [[],[]] .smaller = true := by decide
def e605591223694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e605591223694 : Closed e605591223694 ∧ code e605591223694 = 2804614479246 := by decide
theorem cert_e605591223694 : check e605591223694 [[],[]] .smaller = true := by decide
def e605591223706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591223706 : Closed e605591223706 ∧ code e605591223706 = 2804614479258 := by decide
theorem cert_e605591223706 : check e605591223706 [[],[]] .smaller = true := by decide
def e605591223774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 3)))))))))
theorem wire_e605591223774 : Closed e605591223774 ∧ code e605591223774 = 2804614479326 := by decide
theorem cert_e605591223774 : check e605591223774 [[],[]] .smaller = true := by decide
def e605591223790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 2)))))))))
theorem wire_e605591223790 : Closed e605591223790 ∧ code e605591223790 = 2804614479342 := by decide
theorem cert_e605591223790 : check e605591223790 [[],[]] .smaller = true := by decide
def e605591223862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e605591223862 : Closed e605591223862 ∧ code e605591223862 = 2804614479414 := by decide
theorem cert_e605591223862 : check e605591223862 [[],[]] .smaller = true := by decide
def e605591223866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e605591223866 : Closed e605591223866 ∧ code e605591223866 = 2804614479418 := by decide
theorem cert_e605591223866 : check e605591223866 [[],[]] .smaller = true := by decide
def e605591223950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e605591223950 : Closed e605591223950 ∧ code e605591223950 = 2804614479502 := by decide
theorem cert_e605591223950 : check e605591223950 [[],[]] .smaller = true := by decide
def e605591223998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 4)))))))))
theorem wire_e605591223998 : Closed e605591223998 ∧ code e605591223998 = 2804614479550 := by decide
theorem cert_e605591223998 : check e605591223998 [[],[]] .three = true := by decide
def e605591224006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e605591224006 : Closed e605591224006 ∧ code e605591224006 = 2804614479558 := by decide
theorem cert_e605591224006 : check e605591224006 [[],[]] .smaller = true := by decide
def e605591224030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 3)))))))))
theorem wire_e605591224030 : Closed e605591224030 ∧ code e605591224030 = 2804614479582 := by decide
theorem cert_e605591224030 : check e605591224030 [[],[]] .smaller = true := by decide
def e605591224046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 2)))))))))
theorem wire_e605591224046 : Closed e605591224046 ∧ code e605591224046 = 2804614479598 := by decide
theorem cert_e605591224046 : check e605591224046 [[],[]] .smaller = true := by decide
def e605591224054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 1)))))))))
theorem wire_e605591224054 : Closed e605591224054 ∧ code e605591224054 = 2804614479606 := by decide
theorem cert_e605591224054 : check e605591224054 [[],[]] .smaller = true := by decide
def e605591224058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 4)) (.var 0)))))))))
theorem wire_e605591224058 : Closed e605591224058 ∧ code e605591224058 = 2804614479610 := by decide
theorem cert_e605591224058 : check e605591224058 [[],[]] .three = true := by decide
def e605591224158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 3)))))))))
theorem wire_e605591224158 : Closed e605591224158 ∧ code e605591224158 = 2804614479710 := by decide
theorem cert_e605591224158 : check e605591224158 [[],[]] .three = true := by decide
def e605591224186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 3)) (.var 0)))))))))
theorem wire_e605591224186 : Closed e605591224186 ∧ code e605591224186 = 2804614479738 := by decide
theorem cert_e605591224186 : check e605591224186 [[],[]] .three = true := by decide
def e605591225310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e605591225310 : Closed e605591225310 ∧ code e605591225310 = 2804614480862 := by decide
theorem cert_e605591225310 : check e605591225310 [[],[]] .smaller = true := by decide
def e605591225326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e605591225326 : Closed e605591225326 ∧ code e605591225326 = 2804614480878 := by decide
theorem cert_e605591225326 : check e605591225326 [[],[]] .smaller = true := by decide
def e605591227246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605591227246 : Closed e605591227246 ∧ code e605591227246 = 2804614482798 := by decide
theorem cert_e605591227246 : check e605591227246 [[],[]] .smaller = true := by decide
def e605591227254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605591227254 : Closed e605591227254 ∧ code e605591227254 = 2804614482806 := by decide
theorem cert_e605591227254 : check e605591227254 [[],[]] .smaller = true := by decide
def e605591227310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605591227310 : Closed e605591227310 ∧ code e605591227310 = 2804614482862 := by decide
theorem cert_e605591227310 : check e605591227310 [[],[]] .smaller = true := by decide
def e605591227322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605591227322 : Closed e605591227322 ∧ code e605591227322 = 2804614482874 := by decide
theorem cert_e605591227322 : check e605591227322 [[],[]] .smaller = true := by decide
def e605591227350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605591227350 : Closed e605591227350 ∧ code e605591227350 = 2804614482902 := by decide
theorem cert_e605591227350 : check e605591227350 [[],[]] .smaller = true := by decide
def e605591227354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605591227354 : Closed e605591227354 ∧ code e605591227354 = 2804614482906 := by decide
theorem cert_e605591227354 : check e605591227354 [[],[]] .smaller = true := by decide
def e605591227630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605591227630 : Closed e605591227630 ∧ code e605591227630 = 2804614483182 := by decide
theorem cert_e605591227630 : check e605591227630 [[],[]] .smaller = true := by decide
def e605591227638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605591227638 : Closed e605591227638 ∧ code e605591227638 = 2804614483190 := by decide
theorem cert_e605591227638 : check e605591227638 [[],[]] .smaller = true := by decide
def e605591227966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e605591227966 : Closed e605591227966 ∧ code e605591227966 = 2804614483518 := by decide
theorem cert_e605591227966 : check e605591227966 [[],[]] .smaller = true := by decide
def e605591228014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605591228014 : Closed e605591228014 ∧ code e605591228014 = 2804614483566 := by decide
theorem cert_e605591228014 : check e605591228014 [[],[]] .smaller = true := by decide
def e605591228026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605591228026 : Closed e605591228026 ∧ code e605591228026 = 2804614483578 := by decide
theorem cert_e605591228026 : check e605591228026 [[],[]] .smaller = true := by decide
def e605591228214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605591228214 : Closed e605591228214 ∧ code e605591228214 = 2804614483766 := by decide
theorem cert_e605591228214 : check e605591228214 [[],[]] .smaller = true := by decide
def e605591228218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605591228218 : Closed e605591228218 ∧ code e605591228218 = 2804614483770 := by decide
theorem cert_e605591228218 : check e605591228218 [[],[]] .smaller = true := by decide
def e605591228302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e605591228302 : Closed e605591228302 ∧ code e605591228302 = 2804614483854 := by decide
theorem cert_e605591228302 : check e605591228302 [[],[]] .smaller = true := by decide
def e605591228350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 4))))))))))
theorem wire_e605591228350 : Closed e605591228350 ∧ code e605591228350 = 2804614483902 := by decide
theorem cert_e605591228350 : check e605591228350 [[],[]] .three = true := by decide
def e605591228382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 3))))))))))
theorem wire_e605591228382 : Closed e605591228382 ∧ code e605591228382 = 2804614483934 := by decide
theorem cert_e605591228382 : check e605591228382 [[],[]] .three = true := by decide
def e605591232990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e605591232990 : Closed e605591232990 ∧ code e605591232990 = 2804614488542 := by decide
theorem cert_e605591232990 : check e605591232990 [[],[]] .smaller = true := by decide
def e605591233014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e605591233014 : Closed e605591233014 ∧ code e605591233014 = 2804614488566 := by decide
theorem cert_e605591233014 : check e605591233014 [[],[]] .smaller = true := by decide
def e605591233966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e605591233966 : Closed e605591233966 ∧ code e605591233966 = 2804614489518 := by decide
theorem cert_e605591233966 : check e605591233966 [[],[]] .smaller = true := by decide
def e605591233978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e605591233978 : Closed e605591233978 ∧ code e605591233978 = 2804614489530 := by decide
theorem cert_e605591233978 : check e605591233978 [[],[]] .smaller = true := by decide
def e605591234026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e605591234026 : Closed e605591234026 ∧ code e605591234026 = 2804614489578 := by decide
theorem cert_e605591234026 : check e605591234026 [[],[]] .smaller = true := by decide
def e605591234110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e605591234110 : Closed e605591234110 ∧ code e605591234110 = 2804614489662 := by decide
theorem cert_e605591234110 : check e605591234110 [[],[]] .smaller = true := by decide
def e605591234158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605591234158 : Closed e605591234158 ∧ code e605591234158 = 2804614489710 := by decide
theorem cert_e605591234158 : check e605591234158 [[],[]] .smaller = true := by decide
def e605591234170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605591234170 : Closed e605591234170 ∧ code e605591234170 = 2804614489722 := by decide
theorem cert_e605591234170 : check e605591234170 [[],[]] .smaller = true := by decide
def e605591234334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e605591234334 : Closed e605591234334 ∧ code e605591234334 = 2804614489886 := by decide
theorem cert_e605591234334 : check e605591234334 [[],[]] .smaller = true := by decide
def e605591234446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e605591234446 : Closed e605591234446 ∧ code e605591234446 = 2804614489998 := by decide
theorem cert_e605591234446 : check e605591234446 [[],[]] .smaller = true := by decide
def e605591234458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605591234458 : Closed e605591234458 ∧ code e605591234458 = 2804614490010 := by decide
theorem cert_e605591234458 : check e605591234458 [[],[]] .smaller = true := by decide
def e605591234502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e605591234502 : Closed e605591234502 ∧ code e605591234502 = 2804614490054 := by decide
theorem cert_e605591234502 : check e605591234502 [[],[]] .smaller = true := by decide
def e605591234526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 3))))))))))
theorem wire_e605591234526 : Closed e605591234526 ∧ code e605591234526 = 2804614490078 := by decide
theorem cert_e605591234526 : check e605591234526 [[],[]] .smaller = true := by decide
def e605591236846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e605591236846 : Closed e605591236846 ∧ code e605591236846 = 2804614492398 := by decide
theorem cert_e605591236846 : check e605591236846 [[],[]] .smaller = true := by decide
def e605591236854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e605591236854 : Closed e605591236854 ∧ code e605591236854 = 2804614492406 := by decide
theorem cert_e605591236854 : check e605591236854 [[],[]] .smaller = true := by decide
def e605591237334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e605591237334 : Closed e605591237334 ∧ code e605591237334 = 2804614492886 := by decide
theorem cert_e605591237334 : check e605591237334 [[],[]] .smaller = true := by decide
def e605591237338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e605591237338 : Closed e605591237338 ∧ code e605591237338 = 2804614492890 := by decide
theorem cert_e605591237338 : check e605591237338 [[],[]] .smaller = true := by decide
def e605591237354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e605591237354 : Closed e605591237354 ∧ code e605591237354 = 2804614492906 := by decide
theorem cert_e605591237354 : check e605591237354 [[],[]] .smaller = true := by decide
def e605591237430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605591237430 : Closed e605591237430 ∧ code e605591237430 = 2804614492982 := by decide
theorem cert_e605591237430 : check e605591237430 [[],[]] .smaller = true := by decide
def e605591237434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605591237434 : Closed e605591237434 ∧ code e605591237434 = 2804614492986 := by decide
theorem cert_e605591237434 : check e605591237434 [[],[]] .smaller = true := by decide
def e605591237518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e605591237518 : Closed e605591237518 ∧ code e605591237518 = 2804614493070 := by decide
theorem cert_e605591237518 : check e605591237518 [[],[]] .smaller = true := by decide
def e605591237530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605591237530 : Closed e605591237530 ∧ code e605591237530 = 2804614493082 := by decide
theorem cert_e605591237530 : check e605591237530 [[],[]] .smaller = true := by decide
def e605591237598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 3))))))))))
theorem wire_e605591237598 : Closed e605591237598 ∧ code e605591237598 = 2804614493150 := by decide
theorem cert_e605591237598 : check e605591237598 [[],[]] .smaller = true := by decide
def e605591237614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 2))))))))))
theorem wire_e605591237614 : Closed e605591237614 ∧ code e605591237614 = 2804614493166 := by decide
theorem cert_e605591237614 : check e605591237614 [[],[]] .smaller = true := by decide
def e605591239054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e605591239054 : Closed e605591239054 ∧ code e605591239054 = 2804614494606 := by decide
theorem cert_e605591239054 : check e605591239054 [[],[]] .smaller = true := by decide
def e605591239102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 4))))))))))
theorem wire_e605591239102 : Closed e605591239102 ∧ code e605591239102 = 2804614494654 := by decide
theorem cert_e605591239102 : check e605591239102 [[],[]] .three = true := by decide
def e605591239110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e605591239110 : Closed e605591239110 ∧ code e605591239110 = 2804614494662 := by decide
theorem cert_e605591239110 : check e605591239110 [[],[]] .smaller = true := by decide
def e605591239134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 3))))))))))
theorem wire_e605591239134 : Closed e605591239134 ∧ code e605591239134 = 2804614494686 := by decide
theorem cert_e605591239134 : check e605591239134 [[],[]] .smaller = true := by decide
def e605591239150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 2))))))))))
theorem wire_e605591239150 : Closed e605591239150 ∧ code e605591239150 = 2804614494702 := by decide
theorem cert_e605591239150 : check e605591239150 [[],[]] .smaller = true := by decide
def e605591239158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 1))))))))))
theorem wire_e605591239158 : Closed e605591239158 ∧ code e605591239158 = 2804614494710 := by decide
theorem cert_e605591239158 : check e605591239158 [[],[]] .smaller = true := by decide
def e605591239162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 4) (.var 0))))))))))
theorem wire_e605591239162 : Closed e605591239162 ∧ code e605591239162 = 2804614494714 := by decide
theorem cert_e605591239162 : check e605591239162 [[],[]] .three = true := by decide
def e605591239902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 3))))))))))
theorem wire_e605591239902 : Closed e605591239902 ∧ code e605591239902 = 2804614495454 := by decide
theorem cert_e605591239902 : check e605591239902 [[],[]] .three = true := by decide
def e605591239930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 3) (.var 0))))))))))
theorem wire_e605591239930 : Closed e605591239930 ∧ code e605591239930 = 2804614495482 := by decide
theorem cert_e605591239930 : check e605591239930 [[],[]] .three = true := by decide
def e605591328430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e605591328430 : Closed e605591328430 ∧ code e605591328430 = 2804614583982 := by decide
theorem cert_e605591328430 : check e605591328430 [[],[]] .smaller = true := by decide
def e605591328442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e605591328442 : Closed e605591328442 ∧ code e605591328442 = 2804614583994 := by decide
theorem cert_e605591328442 : check e605591328442 [[],[]] .smaller = true := by decide
def e605591328490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e605591328490 : Closed e605591328490 ∧ code e605591328490 = 2804614584042 := by decide
theorem cert_e605591328490 : check e605591328490 [[],[]] .smaller = true := by decide
def e605591328682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e605591328682 : Closed e605591328682 ∧ code e605591328682 = 2804614584234 := by decide
theorem cert_e605591328682 : check e605591328682 [[],[]] .smaller = true := by decide
def e605591328990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e605591328990 : Closed e605591328990 ∧ code e605591328990 = 2804614584542 := by decide
theorem cert_e605591328990 : check e605591328990 [[],[]] .smaller = true := by decide
def e605591329006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e605591329006 : Closed e605591329006 ∧ code e605591329006 = 2804614584558 := by decide
theorem cert_e605591329006 : check e605591329006 [[],[]] .smaller = true := by decide
def e605591329014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e605591329014 : Closed e605591329014 ∧ code e605591329014 = 2804614584566 := by decide
theorem cert_e605591329014 : check e605591329014 [[],[]] .smaller = true := by decide
def e605591329018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e605591329018 : Closed e605591329018 ∧ code e605591329018 = 2804614584570 := by decide
theorem cert_e605591329018 : check e605591329018 [[],[]] .smaller = true := by decide
def e605591329198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e605591329198 : Closed e605591329198 ∧ code e605591329198 = 2804614584750 := by decide
theorem cert_e605591329198 : check e605591329198 [[],[]] .smaller = true := by decide
end Blc.Floor41
