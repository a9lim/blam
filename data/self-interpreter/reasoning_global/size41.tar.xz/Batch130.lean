import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605640899514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e605640899514 : Closed e605640899514 ∧ code e605640899514 = 2804664155066 := by decide
theorem cert_e605640899514 : check e605640899514 [[],[]] .smaller = true := by decide
def e605640899542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e605640899542 : Closed e605640899542 ∧ code e605640899542 = 2804664155094 := by decide
theorem cert_e605640899542 : check e605640899542 [[],[]] .chain = true := by decide
def e605640899546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e605640899546 : Closed e605640899546 ∧ code e605640899546 = 2804664155098 := by decide
theorem cert_e605640899546 : check e605640899546 [[],[]] .chain = true := by decide
def e605640899670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e605640899670 : Closed e605640899670 ∧ code e605640899670 = 2804664155222 := by decide
theorem cert_e605640899670 : check e605640899670 [[],[]] .smaller = true := by decide
def e605640899674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e605640899674 : Closed e605640899674 ∧ code e605640899674 = 2804664155226 := by decide
theorem cert_e605640899674 : check e605640899674 [[],[]] .smaller = true := by decide
def e605640899862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e605640899862 : Closed e605640899862 ∧ code e605640899862 = 2804664155414 := by decide
theorem cert_e605640899862 : check e605640899862 [[],[]] .smaller = true := by decide
def e605640899934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e605640899934 : Closed e605640899934 ∧ code e605640899934 = 2804664155486 := by decide
theorem cert_e605640899934 : check e605640899934 [[],[]] .chain = true := by decide
def e605640899938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e605640899938 : Closed e605640899938 ∧ code e605640899938 = 2804664155490 := by decide
theorem cert_e605640899938 : check e605640899938 [[],[]] .smaller = true := by decide
def e605640899950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605640899950 : Closed e605640899950 ∧ code e605640899950 = 2804664155502 := by decide
theorem cert_e605640899950 : check e605640899950 [[],[]] .smaller = true := by decide
def e605640899958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605640899958 : Closed e605640899958 ∧ code e605640899958 = 2804664155510 := by decide
theorem cert_e605640899958 : check e605640899958 [[],[]] .smaller = true := by decide
def e605640899962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e605640899962 : Closed e605640899962 ∧ code e605640899962 = 2804664155514 := by decide
theorem cert_e605640899962 : check e605640899962 [[],[]] .chain = true := by decide
def e605640899978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605640899978 : Closed e605640899978 ∧ code e605640899978 = 2804664155530 := by decide
theorem cert_e605640899978 : check e605640899978 [[],[]] .smaller = true := by decide
def e605640900002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605640900002 : Closed e605640900002 ∧ code e605640900002 = 2804664155554 := by decide
theorem cert_e605640900002 : check e605640900002 [[],[]] .smaller = true := by decide
def e605640900014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605640900014 : Closed e605640900014 ∧ code e605640900014 = 2804664155566 := by decide
theorem cert_e605640900014 : check e605640900014 [[],[]] .smaller = true := by decide
def e605640900026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605640900026 : Closed e605640900026 ∧ code e605640900026 = 2804664155578 := by decide
theorem cert_e605640900026 : check e605640900026 [[],[]] .smaller = true := by decide
def e605640900054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605640900054 : Closed e605640900054 ∧ code e605640900054 = 2804664155606 := by decide
theorem cert_e605640900054 : check e605640900054 [[],[]] .smaller = true := by decide
def e605640900058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605640900058 : Closed e605640900058 ∧ code e605640900058 = 2804664155610 := by decide
theorem cert_e605640900058 : check e605640900058 [[],[]] .smaller = true := by decide
def e605640900074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e605640900074 : Closed e605640900074 ∧ code e605640900074 = 2804664155626 := by decide
theorem cert_e605640900074 : check e605640900074 [[],[]] .chain = true := by decide
def e605640900270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605640900270 : Closed e605640900270 ∧ code e605640900270 = 2804664155822 := by decide
theorem cert_e605640900270 : check e605640900270 [[],[]] .chain = true := by decide
def e605640900278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e605640900278 : Closed e605640900278 ∧ code e605640900278 = 2804664155830 := by decide
theorem cert_e605640900278 : check e605640900278 [[],[]] .chain = true := by decide
def e605640900282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605640900282 : Closed e605640900282 ∧ code e605640900282 = 2804664155834 := by decide
theorem cert_e605640900282 : check e605640900282 [[],[]] .chain = true := by decide
def e605640900310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e605640900310 : Closed e605640900310 ∧ code e605640900310 = 2804664155862 := by decide
theorem cert_e605640900310 : check e605640900310 [[],[]] .chain = true := by decide
def e605640900314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e605640900314 : Closed e605640900314 ∧ code e605640900314 = 2804664155866 := by decide
theorem cert_e605640900314 : check e605640900314 [[],[]] .chain = true := by decide
def e605640900330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605640900330 : Closed e605640900330 ∧ code e605640900330 = 2804664155882 := by decide
theorem cert_e605640900330 : check e605640900330 [[],[]] .chain = true := by decide
def e605640901102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2))))))))
theorem wire_e605640901102 : Closed e605640901102 ∧ code e605640901102 = 2804664156654 := by decide
theorem cert_e605640901102 : check e605640901102 [[],[]] .smaller = true := by decide
def e605640901110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1))))))))
theorem wire_e605640901110 : Closed e605640901110 ∧ code e605640901110 = 2804664156662 := by decide
theorem cert_e605640901110 : check e605640901110 [[],[]] .smaller = true := by decide
def e605640901870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e605640901870 : Closed e605640901870 ∧ code e605640901870 = 2804664157422 := by decide
theorem cert_e605640901870 : check e605640901870 [[],[]] .smaller = true := by decide
def e605640901878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e605640901878 : Closed e605640901878 ∧ code e605640901878 = 2804664157430 := by decide
theorem cert_e605640901878 : check e605640901878 [[],[]] .smaller = true := by decide
def e605640902430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3)))))))))
theorem wire_e605640902430 : Closed e605640902430 ∧ code e605640902430 = 2804664157982 := by decide
theorem cert_e605640902430 : check e605640902430 [[],[]] .smaller = true := by decide
def e605640902542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2)))))))))
theorem wire_e605640902542 : Closed e605640902542 ∧ code e605640902542 = 2804664158094 := by decide
theorem cert_e605640902542 : check e605640902542 [[],[]] .smaller = true := by decide
def e605640904158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e605640904158 : Closed e605640904158 ∧ code e605640904158 = 2804664159710 := by decide
theorem cert_e605640904158 : check e605640904158 [[],[]] .chain = true := by decide
def e605640904174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e605640904174 : Closed e605640904174 ∧ code e605640904174 = 2804664159726 := by decide
theorem cert_e605640904174 : check e605640904174 [[],[]] .chain = true := by decide
def e605640904238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605640904238 : Closed e605640904238 ∧ code e605640904238 = 2804664159790 := by decide
theorem cert_e605640904238 : check e605640904238 [[],[]] .smaller = true := by decide
def e605640904414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e605640904414 : Closed e605640904414 ∧ code e605640904414 = 2804664159966 := by decide
theorem cert_e605640904414 : check e605640904414 [[],[]] .chain = true := by decide
def e605640904418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e605640904418 : Closed e605640904418 ∧ code e605640904418 = 2804664159970 := by decide
theorem cert_e605640904418 : check e605640904418 [[],[]] .smaller = true := by decide
def e605640904430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e605640904430 : Closed e605640904430 ∧ code e605640904430 = 2804664159982 := by decide
theorem cert_e605640904430 : check e605640904430 [[],[]] .smaller = true := by decide
def e605640904438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e605640904438 : Closed e605640904438 ∧ code e605640904438 = 2804664159990 := by decide
theorem cert_e605640904438 : check e605640904438 [[],[]] .chain = true := by decide
def e605640904470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605640904470 : Closed e605640904470 ∧ code e605640904470 = 2804664160022 := by decide
theorem cert_e605640904470 : check e605640904470 [[],[]] .smaller = true := by decide
def e605640904542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e605640904542 : Closed e605640904542 ∧ code e605640904542 = 2804664160094 := by decide
theorem cert_e605640904542 : check e605640904542 [[],[]] .chain = true := by decide
def e605640904546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e605640904546 : Closed e605640904546 ∧ code e605640904546 = 2804664160098 := by decide
theorem cert_e605640904546 : check e605640904546 [[],[]] .smaller = true := by decide
def e605640904558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e605640904558 : Closed e605640904558 ∧ code e605640904558 = 2804664160110 := by decide
theorem cert_e605640904558 : check e605640904558 [[],[]] .smaller = true := by decide
def e605640904566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e605640904566 : Closed e605640904566 ∧ code e605640904566 = 2804664160118 := by decide
theorem cert_e605640904566 : check e605640904566 [[],[]] .smaller = true := by decide
def e605640904570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e605640904570 : Closed e605640904570 ∧ code e605640904570 = 2804664160122 := by decide
theorem cert_e605640904570 : check e605640904570 [[],[]] .chain = true := by decide
def e605640904622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e605640904622 : Closed e605640904622 ∧ code e605640904622 = 2804664160174 := by decide
theorem cert_e605640904622 : check e605640904622 [[],[]] .chain = true := by decide
def e605640904630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e605640904630 : Closed e605640904630 ∧ code e605640904630 = 2804664160182 := by decide
theorem cert_e605640904630 : check e605640904630 [[],[]] .chain = true := by decide
def e605640904634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e605640904634 : Closed e605640904634 ∧ code e605640904634 = 2804664160186 := by decide
theorem cert_e605640904634 : check e605640904634 [[],[]] .chain = true := by decide
def e605640905694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e605640905694 : Closed e605640905694 ∧ code e605640905694 = 2804664161246 := by decide
theorem cert_e605640905694 : check e605640905694 [[],[]] .chain = true := by decide
def e605640905710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e605640905710 : Closed e605640905710 ∧ code e605640905710 = 2804664161262 := by decide
theorem cert_e605640905710 : check e605640905710 [[],[]] .chain = true := by decide
def e605640906814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4))))))))))
theorem wire_e605640906814 : Closed e605640906814 ∧ code e605640906814 = 2804664162366 := by decide
theorem cert_e605640906814 : check e605640906814 [[],[]] .smaller = true := by decide
def e605640907230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605640907230 : Closed e605640907230 ∧ code e605640907230 = 2804664162782 := by decide
theorem cert_e605640907230 : check e605640907230 [[],[]] .chain = true := by decide
def e605640907234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605640907234 : Closed e605640907234 ∧ code e605640907234 = 2804664162786 := by decide
theorem cert_e605640907234 : check e605640907234 [[],[]] .smaller = true := by decide
def e605640907246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e605640907246 : Closed e605640907246 ∧ code e605640907246 = 2804664162798 := by decide
theorem cert_e605640907246 : check e605640907246 [[],[]] .smaller = true := by decide
def e605640907254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605640907254 : Closed e605640907254 ∧ code e605640907254 = 2804664162806 := by decide
theorem cert_e605640907254 : check e605640907254 [[],[]] .chain = true := by decide
def e605640907806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3))))))))))
theorem wire_e605640907806 : Closed e605640907806 ∧ code e605640907806 = 2804664163358 := by decide
theorem cert_e605640907806 : check e605640907806 [[],[]] .smaller = true := by decide
def e605640907998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605640907998 : Closed e605640907998 ∧ code e605640907998 = 2804664163550 := by decide
theorem cert_e605640907998 : check e605640907998 [[],[]] .chain = true := by decide
def e605640908002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e605640908002 : Closed e605640908002 ∧ code e605640908002 = 2804664163554 := by decide
theorem cert_e605640908002 : check e605640908002 [[],[]] .smaller = true := by decide
def e605640908014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605640908014 : Closed e605640908014 ∧ code e605640908014 = 2804664163566 := by decide
theorem cert_e605640908014 : check e605640908014 [[],[]] .smaller = true := by decide
def e605640908022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605640908022 : Closed e605640908022 ∧ code e605640908022 = 2804664163574 := by decide
theorem cert_e605640908022 : check e605640908022 [[],[]] .smaller = true := by decide
def e605640908026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605640908026 : Closed e605640908026 ∧ code e605640908026 = 2804664163578 := by decide
theorem cert_e605640908026 : check e605640908026 [[],[]] .chain = true := by decide
def e605640908398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605640908398 : Closed e605640908398 ∧ code e605640908398 = 2804664163950 := by decide
theorem cert_e605640908398 : check e605640908398 [[],[]] .chain = true := by decide
def e605640908406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605640908406 : Closed e605640908406 ∧ code e605640908406 = 2804664163958 := by decide
theorem cert_e605640908406 : check e605640908406 [[],[]] .chain = true := by decide
def e605640908410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605640908410 : Closed e605640908410 ∧ code e605640908410 = 2804664163962 := by decide
theorem cert_e605640908410 : check e605640908410 [[],[]] .chain = true := by decide
def e605640909038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2))))))))
theorem wire_e605640909038 : Closed e605640909038 ∧ code e605640909038 = 2804664164590 := by decide
theorem cert_e605640909038 : check e605640909038 [[],[]] .smaller = true := by decide
def e605640909050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0))))))))
theorem wire_e605640909050 : Closed e605640909050 ∧ code e605640909050 = 2804664164602 := by decide
theorem cert_e605640909050 : check e605640909050 [[],[]] .smaller = true := by decide
def e605640909422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e605640909422 : Closed e605640909422 ∧ code e605640909422 = 2804664164974 := by decide
theorem cert_e605640909422 : check e605640909422 [[],[]] .smaller = true := by decide
def e605640909434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e605640909434 : Closed e605640909434 ∧ code e605640909434 = 2804664164986 := by decide
theorem cert_e605640909434 : check e605640909434 [[],[]] .smaller = true := by decide
def e605640909598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3)))))))))
theorem wire_e605640909598 : Closed e605640909598 ∧ code e605640909598 = 2804664165150 := by decide
theorem cert_e605640909598 : check e605640909598 [[],[]] .smaller = true := by decide
def e605640909766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1)))))))))
theorem wire_e605640909766 : Closed e605640909766 ∧ code e605640909766 = 2804664165318 := by decide
theorem cert_e605640909766 : check e605640909766 [[],[]] .smaller = true := by decide
def e605640909790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 3))))))))
theorem wire_e605640909790 : Closed e605640909790 ∧ code e605640909790 = 2804664165342 := by decide
theorem cert_e605640909790 : check e605640909790 [[],[]] .chain = true := by decide
def e605640909806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 2))))))))
theorem wire_e605640909806 : Closed e605640909806 ∧ code e605640909806 = 2804664165358 := by decide
theorem cert_e605640909806 : check e605640909806 [[],[]] .chain = true := by decide
def e605640910382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605640910382 : Closed e605640910382 ∧ code e605640910382 = 2804664165934 := by decide
theorem cert_e605640910382 : check e605640910382 [[],[]] .smaller = true := by decide
def e605640910558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e605640910558 : Closed e605640910558 ∧ code e605640910558 = 2804664166110 := by decide
theorem cert_e605640910558 : check e605640910558 [[],[]] .chain = true := by decide
def e605640910562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e605640910562 : Closed e605640910562 ∧ code e605640910562 = 2804664166114 := by decide
theorem cert_e605640910562 : check e605640910562 [[],[]] .smaller = true := by decide
def e605640910574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e605640910574 : Closed e605640910574 ∧ code e605640910574 = 2804664166126 := by decide
theorem cert_e605640910574 : check e605640910574 [[],[]] .smaller = true := by decide
def e605640910582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e605640910582 : Closed e605640910582 ∧ code e605640910582 = 2804664166134 := by decide
theorem cert_e605640910582 : check e605640910582 [[],[]] .chain = true := by decide
def e605640910686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e605640910686 : Closed e605640910686 ∧ code e605640910686 = 2804664166238 := by decide
theorem cert_e605640910686 : check e605640910686 [[],[]] .chain = true := by decide
def e605640910714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e605640910714 : Closed e605640910714 ∧ code e605640910714 = 2804664166266 := by decide
theorem cert_e605640910714 : check e605640910714 [[],[]] .chain = true := by decide
def e605640910730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605640910730 : Closed e605640910730 ∧ code e605640910730 = 2804664166282 := by decide
theorem cert_e605640910730 : check e605640910730 [[],[]] .smaller = true := by decide
def e605640910754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e605640910754 : Closed e605640910754 ∧ code e605640910754 = 2804664166306 := by decide
theorem cert_e605640910754 : check e605640910754 [[],[]] .smaller = true := by decide
def e605640910766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e605640910766 : Closed e605640910766 ∧ code e605640910766 = 2804664166318 := by decide
theorem cert_e605640910766 : check e605640910766 [[],[]] .smaller = true := by decide
def e605640910778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e605640910778 : Closed e605640910778 ∧ code e605640910778 = 2804664166330 := by decide
theorem cert_e605640910778 : check e605640910778 [[],[]] .smaller = true := by decide
def e605640910806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e605640910806 : Closed e605640910806 ∧ code e605640910806 = 2804664166358 := by decide
theorem cert_e605640910806 : check e605640910806 [[],[]] .chain = true := by decide
def e605640910810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e605640910810 : Closed e605640910810 ∧ code e605640910810 = 2804664166362 := by decide
theorem cert_e605640910810 : check e605640910810 [[],[]] .chain = true := by decide
def e605640910910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4))))))))))
theorem wire_e605640910910 : Closed e605640910910 ∧ code e605640910910 = 2804664166462 := by decide
theorem cert_e605640910910 : check e605640910910 [[],[]] .smaller = true := by decide
def e605640911326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605640911326 : Closed e605640911326 ∧ code e605640911326 = 2804664166878 := by decide
theorem cert_e605640911326 : check e605640911326 [[],[]] .chain = true := by decide
def e605640911330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605640911330 : Closed e605640911330 ∧ code e605640911330 = 2804664166882 := by decide
theorem cert_e605640911330 : check e605640911330 [[],[]] .smaller = true := by decide
def e605640911342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e605640911342 : Closed e605640911342 ∧ code e605640911342 = 2804664166894 := by decide
theorem cert_e605640911342 : check e605640911342 [[],[]] .smaller = true := by decide
def e605640911350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605640911350 : Closed e605640911350 ∧ code e605640911350 = 2804664166902 := by decide
theorem cert_e605640911350 : check e605640911350 [[],[]] .chain = true := by decide
def e605640912094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605640912094 : Closed e605640912094 ∧ code e605640912094 = 2804664167646 := by decide
theorem cert_e605640912094 : check e605640912094 [[],[]] .chain = true := by decide
def e605640912122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605640912122 : Closed e605640912122 ∧ code e605640912122 = 2804664167674 := by decide
theorem cert_e605640912122 : check e605640912122 [[],[]] .chain = true := by decide
def e605640912398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2))))))))))
theorem wire_e605640912398 : Closed e605640912398 ∧ code e605640912398 = 2804664167950 := by decide
theorem cert_e605640912398 : check e605640912398 [[],[]] .smaller = true := by decide
def e605640912446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e605640912446 : Closed e605640912446 ∧ code e605640912446 = 2804664167998 := by decide
theorem cert_e605640912446 : check e605640912446 [[],[]] .chain = true := by decide
def e605640912482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605640912482 : Closed e605640912482 ∧ code e605640912482 = 2804664168034 := by decide
theorem cert_e605640912482 : check e605640912482 [[],[]] .smaller = true := by decide
def e605640912494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605640912494 : Closed e605640912494 ∧ code e605640912494 = 2804664168046 := by decide
theorem cert_e605640912494 : check e605640912494 [[],[]] .smaller = true := by decide
def e605640912506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605640912506 : Closed e605640912506 ∧ code e605640912506 = 2804664168058 := by decide
theorem cert_e605640912506 : check e605640912506 [[],[]] .smaller = true := by decide
def e605640912670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e605640912670 : Closed e605640912670 ∧ code e605640912670 = 2804664168222 := by decide
theorem cert_e605640912670 : check e605640912670 [[],[]] .chain = true := by decide
def e605640912694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605640912694 : Closed e605640912694 ∧ code e605640912694 = 2804664168246 := by decide
theorem cert_e605640912694 : check e605640912694 [[],[]] .chain = true := by decide
def e605640912698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605640912698 : Closed e605640912698 ∧ code e605640912698 = 2804664168250 := by decide
theorem cert_e605640912698 : check e605640912698 [[],[]] .chain = true := by decide
def e605640913014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e605640913014 : Closed e605640913014 ∧ code e605640913014 = 2804664168566 := by decide
theorem cert_e605640913014 : check e605640913014 [[],[]] .smaller = true := by decide
def e605640913018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e605640913018 : Closed e605640913018 ∧ code e605640913018 = 2804664168570 := by decide
theorem cert_e605640913018 : check e605640913018 [[],[]] .smaller = true := by decide
def e605640913206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e605640913206 : Closed e605640913206 ∧ code e605640913206 = 2804664168758 := by decide
theorem cert_e605640913206 : check e605640913206 [[],[]] .smaller = true := by decide
def e605640913210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e605640913210 : Closed e605640913210 ∧ code e605640913210 = 2804664168762 := by decide
theorem cert_e605640913210 : check e605640913210 [[],[]] .smaller = true := by decide
def e605640913294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e605640913294 : Closed e605640913294 ∧ code e605640913294 = 2804664168846 := by decide
theorem cert_e605640913294 : check e605640913294 [[],[]] .smaller = true := by decide
def e605640913350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e605640913350 : Closed e605640913350 ∧ code e605640913350 = 2804664168902 := by decide
theorem cert_e605640913350 : check e605640913350 [[],[]] .smaller = true := by decide
def e605640913374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 3))))))))
theorem wire_e605640913374 : Closed e605640913374 ∧ code e605640913374 = 2804664168926 := by decide
theorem cert_e605640913374 : check e605640913374 [[],[]] .chain = true := by decide
def e605640913398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 1))))))))
theorem wire_e605640913398 : Closed e605640913398 ∧ code e605640913398 = 2804664168950 := by decide
theorem cert_e605640913398 : check e605640913398 [[],[]] .chain = true := by decide
def e605640913686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605640913686 : Closed e605640913686 ∧ code e605640913686 = 2804664169238 := by decide
theorem cert_e605640913686 : check e605640913686 [[],[]] .smaller = true := by decide
def e605640913758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e605640913758 : Closed e605640913758 ∧ code e605640913758 = 2804664169310 := by decide
theorem cert_e605640913758 : check e605640913758 [[],[]] .chain = true := by decide
def e605640913762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e605640913762 : Closed e605640913762 ∧ code e605640913762 = 2804664169314 := by decide
theorem cert_e605640913762 : check e605640913762 [[],[]] .smaller = true := by decide
def e605640913774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605640913774 : Closed e605640913774 ∧ code e605640913774 = 2804664169326 := by decide
theorem cert_e605640913774 : check e605640913774 [[],[]] .smaller = true := by decide
def e605640913782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605640913782 : Closed e605640913782 ∧ code e605640913782 = 2804664169334 := by decide
theorem cert_e605640913782 : check e605640913782 [[],[]] .smaller = true := by decide
def e605640913786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e605640913786 : Closed e605640913786 ∧ code e605640913786 = 2804664169338 := by decide
theorem cert_e605640913786 : check e605640913786 [[],[]] .chain = true := by decide
def e605640913802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605640913802 : Closed e605640913802 ∧ code e605640913802 = 2804664169354 := by decide
theorem cert_e605640913802 : check e605640913802 [[],[]] .smaller = true := by decide
def e605640913826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e605640913826 : Closed e605640913826 ∧ code e605640913826 = 2804664169378 := by decide
theorem cert_e605640913826 : check e605640913826 [[],[]] .smaller = true := by decide
def e605640913838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605640913838 : Closed e605640913838 ∧ code e605640913838 = 2804664169390 := by decide
theorem cert_e605640913838 : check e605640913838 [[],[]] .smaller = true := by decide
def e605640913850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605640913850 : Closed e605640913850 ∧ code e605640913850 = 2804664169402 := by decide
theorem cert_e605640913850 : check e605640913850 [[],[]] .smaller = true := by decide
def e605640913878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605640913878 : Closed e605640913878 ∧ code e605640913878 = 2804664169430 := by decide
theorem cert_e605640913878 : check e605640913878 [[],[]] .smaller = true := by decide
def e605640913882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605640913882 : Closed e605640913882 ∧ code e605640913882 = 2804664169434 := by decide
theorem cert_e605640913882 : check e605640913882 [[],[]] .smaller = true := by decide
def e605640913898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e605640913898 : Closed e605640913898 ∧ code e605640913898 = 2804664169450 := by decide
theorem cert_e605640913898 : check e605640913898 [[],[]] .chain = true := by decide
def e605640913950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e605640913950 : Closed e605640913950 ∧ code e605640913950 = 2804664169502 := by decide
theorem cert_e605640913950 : check e605640913950 [[],[]] .smaller = true := by decide
def e605640914142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605640914142 : Closed e605640914142 ∧ code e605640914142 = 2804664169694 := by decide
theorem cert_e605640914142 : check e605640914142 [[],[]] .chain = true := by decide
def e605640914146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e605640914146 : Closed e605640914146 ∧ code e605640914146 = 2804664169698 := by decide
theorem cert_e605640914146 : check e605640914146 [[],[]] .smaller = true := by decide
def e605640914158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605640914158 : Closed e605640914158 ∧ code e605640914158 = 2804664169710 := by decide
theorem cert_e605640914158 : check e605640914158 [[],[]] .smaller = true := by decide
def e605640914166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605640914166 : Closed e605640914166 ∧ code e605640914166 = 2804664169718 := by decide
theorem cert_e605640914166 : check e605640914166 [[],[]] .smaller = true := by decide
def e605640914170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605640914170 : Closed e605640914170 ∧ code e605640914170 = 2804664169722 := by decide
theorem cert_e605640914170 : check e605640914170 [[],[]] .chain = true := by decide
def e605640914446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e605640914446 : Closed e605640914446 ∧ code e605640914446 = 2804664169998 := by decide
theorem cert_e605640914446 : check e605640914446 [[],[]] .smaller = true := by decide
def e605640914494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e605640914494 : Closed e605640914494 ∧ code e605640914494 = 2804664170046 := by decide
theorem cert_e605640914494 : check e605640914494 [[],[]] .chain = true := by decide
def e605640914530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605640914530 : Closed e605640914530 ∧ code e605640914530 = 2804664170082 := by decide
theorem cert_e605640914530 : check e605640914530 [[],[]] .smaller = true := by decide
def e605640914542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605640914542 : Closed e605640914542 ∧ code e605640914542 = 2804664170094 := by decide
theorem cert_e605640914542 : check e605640914542 [[],[]] .smaller = true := by decide
def e605640914554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605640914554 : Closed e605640914554 ∧ code e605640914554 = 2804664170106 := by decide
theorem cert_e605640914554 : check e605640914554 [[],[]] .smaller = true := by decide
def e605640914742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605640914742 : Closed e605640914742 ∧ code e605640914742 = 2804664170294 := by decide
theorem cert_e605640914742 : check e605640914742 [[],[]] .smaller = true := by decide
def e605640914746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605640914746 : Closed e605640914746 ∧ code e605640914746 = 2804664170298 := by decide
theorem cert_e605640914746 : check e605640914746 [[],[]] .smaller = true := by decide
def e605640914830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e605640914830 : Closed e605640914830 ∧ code e605640914830 = 2804664170382 := by decide
theorem cert_e605640914830 : check e605640914830 [[],[]] .chain = true := by decide
def e605640914842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605640914842 : Closed e605640914842 ∧ code e605640914842 = 2804664170394 := by decide
theorem cert_e605640914842 : check e605640914842 [[],[]] .chain = true := by decide
def e605640915182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605640915182 : Closed e605640915182 ∧ code e605640915182 = 2804664170734 := by decide
theorem cert_e605640915182 : check e605640915182 [[],[]] .chain = true := by decide
def e605640915190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605640915190 : Closed e605640915190 ∧ code e605640915190 = 2804664170742 := by decide
theorem cert_e605640915190 : check e605640915190 [[],[]] .chain = true := by decide
def e605640915374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605640915374 : Closed e605640915374 ∧ code e605640915374 = 2804664170926 := by decide
theorem cert_e605640915374 : check e605640915374 [[],[]] .chain = true := by decide
def e605640915382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e605640915382 : Closed e605640915382 ∧ code e605640915382 = 2804664170934 := by decide
theorem cert_e605640915382 : check e605640915382 [[],[]] .chain = true := by decide
def e605640915386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605640915386 : Closed e605640915386 ∧ code e605640915386 = 2804664170938 := by decide
theorem cert_e605640915386 : check e605640915386 [[],[]] .chain = true := by decide
def e605640915414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e605640915414 : Closed e605640915414 ∧ code e605640915414 = 2804664170966 := by decide
theorem cert_e605640915414 : check e605640915414 [[],[]] .chain = true := by decide
def e605640915418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e605640915418 : Closed e605640915418 ∧ code e605640915418 = 2804664170970 := by decide
theorem cert_e605640915418 : check e605640915418 [[],[]] .chain = true := by decide
def e605640915434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605640915434 : Closed e605640915434 ∧ code e605640915434 = 2804664170986 := by decide
theorem cert_e605640915434 : check e605640915434 [[],[]] .chain = true := by decide
def e605640915566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605640915566 : Closed e605640915566 ∧ code e605640915566 = 2804664171118 := by decide
theorem cert_e605640915566 : check e605640915566 [[],[]] .chain = true := by decide
def e605640915574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605640915574 : Closed e605640915574 ∧ code e605640915574 = 2804664171126 := by decide
theorem cert_e605640915574 : check e605640915574 [[],[]] .chain = true := by decide
def e605640915578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605640915578 : Closed e605640915578 ∧ code e605640915578 = 2804664171130 := by decide
theorem cert_e605640915578 : check e605640915578 [[],[]] .chain = true := by decide
def e605640915742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605640915742 : Closed e605640915742 ∧ code e605640915742 = 2804664171294 := by decide
theorem cert_e605640915742 : check e605640915742 [[],[]] .chain = true := by decide
def e605640915766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605640915766 : Closed e605640915766 ∧ code e605640915766 = 2804664171318 := by decide
theorem cert_e605640915766 : check e605640915766 [[],[]] .chain = true := by decide
def e605640915770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605640915770 : Closed e605640915770 ∧ code e605640915770 = 2804664171322 := by decide
theorem cert_e605640915770 : check e605640915770 [[],[]] .chain = true := by decide
def e605640915854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605640915854 : Closed e605640915854 ∧ code e605640915854 = 2804664171406 := by decide
theorem cert_e605640915854 : check e605640915854 [[],[]] .chain = true := by decide
def e605640915866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605640915866 : Closed e605640915866 ∧ code e605640915866 = 2804664171418 := by decide
theorem cert_e605640915866 : check e605640915866 [[],[]] .chain = true := by decide
def e605640919918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605640919918 : Closed e605640919918 ∧ code e605640919918 = 2804664175470 := by decide
theorem cert_e605640919918 : check e605640919918 [[],[]] .smaller = true := by decide
def e605640919926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605640919926 : Closed e605640919926 ∧ code e605640919926 = 2804664175478 := by decide
theorem cert_e605640919926 : check e605640919926 [[],[]] .smaller = true := by decide
def e605640919982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605640919982 : Closed e605640919982 ∧ code e605640919982 = 2804664175534 := by decide
theorem cert_e605640919982 : check e605640919982 [[],[]] .smaller = true := by decide
def e605640919994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605640919994 : Closed e605640919994 ∧ code e605640919994 = 2804664175546 := by decide
theorem cert_e605640919994 : check e605640919994 [[],[]] .smaller = true := by decide
def e605640920022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605640920022 : Closed e605640920022 ∧ code e605640920022 = 2804664175574 := by decide
theorem cert_e605640920022 : check e605640920022 [[],[]] .smaller = true := by decide
def e605640920026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605640920026 : Closed e605640920026 ∧ code e605640920026 = 2804664175578 := by decide
theorem cert_e605640920026 : check e605640920026 [[],[]] .smaller = true := by decide
def e605640920302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605640920302 : Closed e605640920302 ∧ code e605640920302 = 2804664175854 := by decide
theorem cert_e605640920302 : check e605640920302 [[],[]] .smaller = true := by decide
def e605640920310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605640920310 : Closed e605640920310 ∧ code e605640920310 = 2804664175862 := by decide
theorem cert_e605640920310 : check e605640920310 [[],[]] .smaller = true := by decide
def e605640920686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605640920686 : Closed e605640920686 ∧ code e605640920686 = 2804664176238 := by decide
theorem cert_e605640920686 : check e605640920686 [[],[]] .smaller = true := by decide
def e605640920698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605640920698 : Closed e605640920698 ∧ code e605640920698 = 2804664176250 := by decide
theorem cert_e605640920698 : check e605640920698 [[],[]] .smaller = true := by decide
end Blc.Floor41
