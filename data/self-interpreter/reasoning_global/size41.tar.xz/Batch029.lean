import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e565596458806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e565596458806 : Closed e565596458806 ∧ code e565596458806 = 2764619714358 := by decide
theorem cert_e565596458806 : check e565596458806 [[],[.under]] .chain = true := by decide
def e565596458810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e565596458810 : Closed e565596458810 ∧ code e565596458810 = 2764619714362 := by decide
theorem cert_e565596458810 : check e565596458810 [[],[.under]] .chain = true := by decide
def e565596663262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e565596663262 : Closed e565596663262 ∧ code e565596663262 = 2764619918814 := by decide
theorem cert_e565596663262 : check e565596663262 [[],[.under]] .chain = true := by decide
def e565596663278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e565596663278 : Closed e565596663278 ∧ code e565596663278 = 2764619918830 := by decide
theorem cert_e565596663278 : check e565596663278 [[],[.under]] .chain = true := by decide
def e565596663646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e565596663646 : Closed e565596663646 ∧ code e565596663646 = 2764619919198 := by decide
theorem cert_e565596663646 : check e565596663646 [[],[.under]] .chain = true := by decide
def e565596663674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e565596663674 : Closed e565596663674 ∧ code e565596663674 = 2764619919226 := by decide
theorem cert_e565596663674 : check e565596663674 [[],[.under]] .chain = true := by decide
def e565596663726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e565596663726 : Closed e565596663726 ∧ code e565596663726 = 2764619919278 := by decide
theorem cert_e565596663726 : check e565596663726 [[],[.under]] .chain = true := by decide
def e565596663738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e565596663738 : Closed e565596663738 ∧ code e565596663738 = 2764619919290 := by decide
theorem cert_e565596663738 : check e565596663738 [[],[.under]] .chain = true := by decide
def e565596664798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e565596664798 : Closed e565596664798 ∧ code e565596664798 = 2764619920350 := by decide
theorem cert_e565596664798 : check e565596664798 [[],[.under]] .chain = true := by decide
def e565596664814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e565596664814 : Closed e565596664814 ∧ code e565596664814 = 2764619920366 := by decide
theorem cert_e565596664814 : check e565596664814 [[],[.under]] .chain = true := by decide
def e565596667102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e565596667102 : Closed e565596667102 ∧ code e565596667102 = 2764619922654 := by decide
theorem cert_e565596667102 : check e565596667102 [[],[.under]] .chain = true := by decide
def e565596667130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e565596667130 : Closed e565596667130 ∧ code e565596667130 = 2764619922682 := by decide
theorem cert_e565596667130 : check e565596667130 [[],[.under]] .chain = true := by decide
def e565596667502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e565596667502 : Closed e565596667502 ∧ code e565596667502 = 2764619923054 := by decide
theorem cert_e565596667502 : check e565596667502 [[],[.under]] .chain = true := by decide
def e565596667514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e565596667514 : Closed e565596667514 ∧ code e565596667514 = 2764619923066 := by decide
theorem cert_e565596667514 : check e565596667514 [[],[.under]] .chain = true := by decide
def e565596695918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e565596695918 : Closed e565596695918 ∧ code e565596695918 = 2764619951470 := by decide
theorem cert_e565596695918 : check e565596695918 [[],[.under]] .chain = true := by decide
def e565596695926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e565596695926 : Closed e565596695926 ∧ code e565596695926 = 2764619951478 := by decide
theorem cert_e565596695926 : check e565596695926 [[],[.under]] .chain = true := by decide
def e565596695982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e565596695982 : Closed e565596695982 ∧ code e565596695982 = 2764619951534 := by decide
theorem cert_e565596695982 : check e565596695982 [[],[.under]] .chain = true := by decide
def e565596695994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e565596695994 : Closed e565596695994 ∧ code e565596695994 = 2764619951546 := by decide
theorem cert_e565596695994 : check e565596695994 [[],[.under]] .chain = true := by decide
def e565596696022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e565596696022 : Closed e565596696022 ∧ code e565596696022 = 2764619951574 := by decide
theorem cert_e565596696022 : check e565596696022 [[],[.under]] .chain = true := by decide
def e565596696026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e565596696026 : Closed e565596696026 ∧ code e565596696026 = 2764619951578 := by decide
theorem cert_e565596696026 : check e565596696026 [[],[.under]] .chain = true := by decide
def e565596696238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e565596696238 : Closed e565596696238 ∧ code e565596696238 = 2764619951790 := by decide
theorem cert_e565596696238 : check e565596696238 [[],[.under]] .chain = true := by decide
def e565596696250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e565596696250 : Closed e565596696250 ∧ code e565596696250 = 2764619951802 := by decide
theorem cert_e565596696250 : check e565596696250 [[],[.under]] .chain = true := by decide
def e565596696298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e565596696298 : Closed e565596696298 ∧ code e565596696298 = 2764619951850 := by decide
theorem cert_e565596696298 : check e565596696298 [[],[.under]] .chain = true := by decide
def e565596696406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e565596696406 : Closed e565596696406 ∧ code e565596696406 = 2764619951958 := by decide
theorem cert_e565596696406 : check e565596696406 [[],[.under]] .chain = true := by decide
def e565596696410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e565596696410 : Closed e565596696410 ∧ code e565596696410 = 2764619951962 := by decide
theorem cert_e565596696410 : check e565596696410 [[],[.under]] .chain = true := by decide
def e565596696426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e565596696426 : Closed e565596696426 ∧ code e565596696426 = 2764619951978 := by decide
theorem cert_e565596696426 : check e565596696426 [[],[.under]] .chain = true := by decide
def e565596697454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e565596697454 : Closed e565596697454 ∧ code e565596697454 = 2764619953006 := by decide
theorem cert_e565596697454 : check e565596697454 [[],[.under]] .chain = true := by decide
def e565596697462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e565596697462 : Closed e565596697462 ∧ code e565596697462 = 2764619953014 := by decide
theorem cert_e565596697462 : check e565596697462 [[],[.under]] .chain = true := by decide
def e565596697518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e565596697518 : Closed e565596697518 ∧ code e565596697518 = 2764619953070 := by decide
theorem cert_e565596697518 : check e565596697518 [[],[.under]] .chain = true := by decide
def e565596697530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e565596697530 : Closed e565596697530 ∧ code e565596697530 = 2764619953082 := by decide
theorem cert_e565596697530 : check e565596697530 [[],[.under]] .chain = true := by decide
def e565596697558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e565596697558 : Closed e565596697558 ∧ code e565596697558 = 2764619953110 := by decide
theorem cert_e565596697558 : check e565596697558 [[],[.under]] .chain = true := by decide
def e565596697562 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e565596697562 : Closed e565596697562 ∧ code e565596697562 = 2764619953114 := by decide
theorem cert_e565596697562 : check e565596697562 [[],[.under]] .chain = true := by decide
def e565596697838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e565596697838 : Closed e565596697838 ∧ code e565596697838 = 2764619953390 := by decide
theorem cert_e565596697838 : check e565596697838 [[],[.under]] .chain = true := by decide
def e565596697846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e565596697846 : Closed e565596697846 ∧ code e565596697846 = 2764619953398 := by decide
theorem cert_e565596697846 : check e565596697846 [[],[.under]] .chain = true := by decide
def e565596698222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e565596698222 : Closed e565596698222 ∧ code e565596698222 = 2764619953774 := by decide
theorem cert_e565596698222 : check e565596698222 [[],[.under]] .chain = true := by decide
def e565596698234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e565596698234 : Closed e565596698234 ∧ code e565596698234 = 2764619953786 := by decide
theorem cert_e565596698234 : check e565596698234 [[],[.under]] .chain = true := by decide
def e565596698422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e565596698422 : Closed e565596698422 ∧ code e565596698422 = 2764619953974 := by decide
theorem cert_e565596698422 : check e565596698422 [[],[.under]] .chain = true := by decide
def e565596698426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e565596698426 : Closed e565596698426 ∧ code e565596698426 = 2764619953978 := by decide
theorem cert_e565596698426 : check e565596698426 [[],[.under]] .chain = true := by decide
def e565596699054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e565596699054 : Closed e565596699054 ∧ code e565596699054 = 2764619954606 := by decide
theorem cert_e565596699054 : check e565596699054 [[],[.under]] .chain = true := by decide
def e565596699066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e565596699066 : Closed e565596699066 ∧ code e565596699066 = 2764619954618 := by decide
theorem cert_e565596699066 : check e565596699066 [[],[.under]] .chain = true := by decide
def e565596699114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e565596699114 : Closed e565596699114 ∧ code e565596699114 = 2764619954666 := by decide
theorem cert_e565596699114 : check e565596699114 [[],[.under]] .chain = true := by decide
def e565596699246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e565596699246 : Closed e565596699246 ∧ code e565596699246 = 2764619954798 := by decide
theorem cert_e565596699246 : check e565596699246 [[],[.under]] .chain = true := by decide
def e565596699258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e565596699258 : Closed e565596699258 ∧ code e565596699258 = 2764619954810 := by decide
theorem cert_e565596699258 : check e565596699258 [[],[.under]] .chain = true := by decide
def e565596699546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e565596699546 : Closed e565596699546 ∧ code e565596699546 = 2764619955098 := by decide
theorem cert_e565596699546 : check e565596699546 [[],[.under]] .chain = true := by decide
def e565596699862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e565596699862 : Closed e565596699862 ∧ code e565596699862 = 2764619955414 := by decide
theorem cert_e565596699862 : check e565596699862 [[],[.under]] .chain = true := by decide
def e565596699866 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e565596699866 : Closed e565596699866 ∧ code e565596699866 = 2764619955418 := by decide
theorem cert_e565596699866 : check e565596699866 [[],[.under]] .chain = true := by decide
def e565596699882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e565596699882 : Closed e565596699882 ∧ code e565596699882 = 2764619955434 := by decide
theorem cert_e565596699882 : check e565596699882 [[],[.under]] .chain = true := by decide
def e565596699958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e565596699958 : Closed e565596699958 ∧ code e565596699958 = 2764619955510 := by decide
theorem cert_e565596699958 : check e565596699958 [[],[.under]] .chain = true := by decide
def e565596699962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e565596699962 : Closed e565596699962 ∧ code e565596699962 = 2764619955514 := by decide
theorem cert_e565596699962 : check e565596699962 [[],[.under]] .chain = true := by decide
def e565596700058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e565596700058 : Closed e565596700058 ∧ code e565596700058 = 2764619955610 := by decide
theorem cert_e565596700058 : check e565596700058 [[],[.under]] .chain = true := by decide
def e565596701662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e565596701662 : Closed e565596701662 ∧ code e565596701662 = 2764619957214 := by decide
theorem cert_e565596701662 : check e565596701662 [[],[.under]] .chain = true := by decide
def e565596701678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e565596701678 : Closed e565596701678 ∧ code e565596701678 = 2764619957230 := by decide
theorem cert_e565596701678 : check e565596701678 [[],[.under]] .chain = true := by decide
def e565596703598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e565596703598 : Closed e565596703598 ∧ code e565596703598 = 2764619959150 := by decide
theorem cert_e565596703598 : check e565596703598 [[],[.under]] .chain = true := by decide
def e565596703606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e565596703606 : Closed e565596703606 ∧ code e565596703606 = 2764619959158 := by decide
theorem cert_e565596703606 : check e565596703606 [[],[.under]] .chain = true := by decide
def e565596703662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e565596703662 : Closed e565596703662 ∧ code e565596703662 = 2764619959214 := by decide
theorem cert_e565596703662 : check e565596703662 [[],[.under]] .chain = true := by decide
def e565596703674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e565596703674 : Closed e565596703674 ∧ code e565596703674 = 2764619959226 := by decide
theorem cert_e565596703674 : check e565596703674 [[],[.under]] .chain = true := by decide
def e565596703702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e565596703702 : Closed e565596703702 ∧ code e565596703702 = 2764619959254 := by decide
theorem cert_e565596703702 : check e565596703702 [[],[.under]] .chain = true := by decide
def e565596703706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e565596703706 : Closed e565596703706 ∧ code e565596703706 = 2764619959258 := by decide
theorem cert_e565596703706 : check e565596703706 [[],[.under]] .chain = true := by decide
def e565596703982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e565596703982 : Closed e565596703982 ∧ code e565596703982 = 2764619959534 := by decide
theorem cert_e565596703982 : check e565596703982 [[],[.under]] .chain = true := by decide
def e565596703990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e565596703990 : Closed e565596703990 ∧ code e565596703990 = 2764619959542 := by decide
theorem cert_e565596703990 : check e565596703990 [[],[.under]] .chain = true := by decide
def e565596704366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e565596704366 : Closed e565596704366 ∧ code e565596704366 = 2764619959918 := by decide
theorem cert_e565596704366 : check e565596704366 [[],[.under]] .chain = true := by decide
def e565596704378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e565596704378 : Closed e565596704378 ∧ code e565596704378 = 2764619959930 := by decide
theorem cert_e565596704378 : check e565596704378 [[],[.under]] .chain = true := by decide
def e565596704566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e565596704566 : Closed e565596704566 ∧ code e565596704566 = 2764619960118 := by decide
theorem cert_e565596704566 : check e565596704566 [[],[.under]] .chain = true := by decide
def e565596704570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e565596704570 : Closed e565596704570 ∧ code e565596704570 = 2764619960122 := by decide
theorem cert_e565596704570 : check e565596704570 [[],[.under]] .chain = true := by decide
def e565596709342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e565596709342 : Closed e565596709342 ∧ code e565596709342 = 2764619964894 := by decide
theorem cert_e565596709342 : check e565596709342 [[],[.under]] .chain = true := by decide
def e565596709366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e565596709366 : Closed e565596709366 ∧ code e565596709366 = 2764619964918 := by decide
theorem cert_e565596709366 : check e565596709366 [[],[.under]] .chain = true := by decide
def e565596710318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e565596710318 : Closed e565596710318 ∧ code e565596710318 = 2764619965870 := by decide
theorem cert_e565596710318 : check e565596710318 [[],[.under]] .chain = true := by decide
def e565596710330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e565596710330 : Closed e565596710330 ∧ code e565596710330 = 2764619965882 := by decide
theorem cert_e565596710330 : check e565596710330 [[],[.under]] .chain = true := by decide
def e565596710378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e565596710378 : Closed e565596710378 ∧ code e565596710378 = 2764619965930 := by decide
theorem cert_e565596710378 : check e565596710378 [[],[.under]] .chain = true := by decide
def e565596710510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e565596710510 : Closed e565596710510 ∧ code e565596710510 = 2764619966062 := by decide
theorem cert_e565596710510 : check e565596710510 [[],[.under]] .chain = true := by decide
def e565596710522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e565596710522 : Closed e565596710522 ∧ code e565596710522 = 2764619966074 := by decide
theorem cert_e565596710522 : check e565596710522 [[],[.under]] .chain = true := by decide
def e565596710810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e565596710810 : Closed e565596710810 ∧ code e565596710810 = 2764619966362 := by decide
theorem cert_e565596710810 : check e565596710810 [[],[.under]] .chain = true := by decide
def e565596713198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e565596713198 : Closed e565596713198 ∧ code e565596713198 = 2764619968750 := by decide
theorem cert_e565596713198 : check e565596713198 [[],[.under]] .chain = true := by decide
def e565596713206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e565596713206 : Closed e565596713206 ∧ code e565596713206 = 2764619968758 := by decide
theorem cert_e565596713206 : check e565596713206 [[],[.under]] .chain = true := by decide
def e565596713686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e565596713686 : Closed e565596713686 ∧ code e565596713686 = 2764619969238 := by decide
theorem cert_e565596713686 : check e565596713686 [[],[.under]] .chain = true := by decide
def e565596713690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e565596713690 : Closed e565596713690 ∧ code e565596713690 = 2764619969242 := by decide
theorem cert_e565596713690 : check e565596713690 [[],[.under]] .chain = true := by decide
def e565596713706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e565596713706 : Closed e565596713706 ∧ code e565596713706 = 2764619969258 := by decide
theorem cert_e565596713706 : check e565596713706 [[],[.under]] .chain = true := by decide
def e565596713782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e565596713782 : Closed e565596713782 ∧ code e565596713782 = 2764619969334 := by decide
theorem cert_e565596713782 : check e565596713782 [[],[.under]] .chain = true := by decide
def e565596713786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e565596713786 : Closed e565596713786 ∧ code e565596713786 = 2764619969338 := by decide
theorem cert_e565596713786 : check e565596713786 [[],[.under]] .chain = true := by decide
def e565596713882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e565596713882 : Closed e565596713882 ∧ code e565596713882 = 2764619969434 := by decide
theorem cert_e565596713882 : check e565596713882 [[],[.under]] .chain = true := by decide
def e565596851054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e565596851054 : Closed e565596851054 ∧ code e565596851054 = 2764620106606 := by decide
theorem cert_e565596851054 : check e565596851054 [[],[.under]] .chain = true := by decide
def e565596851062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e565596851062 : Closed e565596851062 ∧ code e565596851062 = 2764620106614 := by decide
theorem cert_e565596851062 : check e565596851062 [[],[.under]] .chain = true := by decide
def e565596851118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e565596851118 : Closed e565596851118 ∧ code e565596851118 = 2764620106670 := by decide
theorem cert_e565596851118 : check e565596851118 [[],[.under]] .chain = true := by decide
def e565596851130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e565596851130 : Closed e565596851130 ∧ code e565596851130 = 2764620106682 := by decide
theorem cert_e565596851130 : check e565596851130 [[],[.under]] .chain = true := by decide
def e565596851158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e565596851158 : Closed e565596851158 ∧ code e565596851158 = 2764620106710 := by decide
theorem cert_e565596851158 : check e565596851158 [[],[.under]] .chain = true := by decide
def e565596851162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e565596851162 : Closed e565596851162 ∧ code e565596851162 = 2764620106714 := by decide
theorem cert_e565596851162 : check e565596851162 [[],[.under]] .chain = true := by decide
def e565596851438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e565596851438 : Closed e565596851438 ∧ code e565596851438 = 2764620106990 := by decide
theorem cert_e565596851438 : check e565596851438 [[],[.under]] .chain = true := by decide
def e565596851446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e565596851446 : Closed e565596851446 ∧ code e565596851446 = 2764620106998 := by decide
theorem cert_e565596851446 : check e565596851446 [[],[.under]] .chain = true := by decide
def e565596851822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e565596851822 : Closed e565596851822 ∧ code e565596851822 = 2764620107374 := by decide
theorem cert_e565596851822 : check e565596851822 [[],[.under]] .chain = true := by decide
def e565596851834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e565596851834 : Closed e565596851834 ∧ code e565596851834 = 2764620107386 := by decide
theorem cert_e565596851834 : check e565596851834 [[],[.under]] .chain = true := by decide
def e565596852022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e565596852022 : Closed e565596852022 ∧ code e565596852022 = 2764620107574 := by decide
theorem cert_e565596852022 : check e565596852022 [[],[.under]] .chain = true := by decide
def e565596852026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e565596852026 : Closed e565596852026 ∧ code e565596852026 = 2764620107578 := by decide
theorem cert_e565596852026 : check e565596852026 [[],[.under]] .chain = true := by decide
def e565597181662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e565597181662 : Closed e565597181662 ∧ code e565597181662 = 2764620437214 := by decide
theorem cert_e565597181662 : check e565597181662 [[],[.under],[.under,.under]] .three = true := by decide
def e565597181686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e565597181686 : Closed e565597181686 ∧ code e565597181686 = 2764620437238 := by decide
theorem cert_e565597181686 : check e565597181686 [[],[.under],[.under,.under]] .three = true := by decide
def e565597181790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e565597181790 : Closed e565597181790 ∧ code e565597181790 = 2764620437342 := by decide
theorem cert_e565597181790 : check e565597181790 [[],[.under],[.under,.under]] .three = true := by decide
def e565597181818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e565597181818 : Closed e565597181818 ∧ code e565597181818 = 2764620437370 := by decide
private def t_e565597181818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem cert_e565597181818 : ¬ IsSelfInterpreter e565597181818 :=
  wSource (t := t_e565597181818) (replay_sound (ps := []) (t := e565597181818) (by decide)) (by decide)
def e565597181910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e565597181910 : Closed e565597181910 ∧ code e565597181910 = 2764620437462 := by decide
theorem cert_e565597181910 : check e565597181910 [[],[.under],[.under,.under]] .three = true := by decide
def e565597181914 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e565597181914 : Closed e565597181914 ∧ code e565597181914 = 2764620437466 := by decide
private def t_e565597181914 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem cert_e565597181914 : ¬ IsSelfInterpreter e565597181914 :=
  wSource (t := t_e565597181914) (replay_sound (ps := []) (t := e565597181914) (by decide)) (by decide)
def e565597182430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e565597182430 : Closed e565597182430 ∧ code e565597182430 = 2764620437982 := by decide
theorem cert_e565597182430 : check e565597182430 [[],[.under],[.under,.under]] .three = true := by decide
def e565597182454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e565597182454 : Closed e565597182454 ∧ code e565597182454 = 2764620438006 := by decide
theorem cert_e565597182454 : check e565597182454 [[],[.under],[.under,.under]] .three = true := by decide
def e565597183198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e565597183198 : Closed e565597183198 ∧ code e565597183198 = 2764620438750 := by decide
theorem cert_e565597183198 : check e565597183198 [[],[.under],[.under,.under]] .three = true := by decide
def e565597183226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e565597183226 : Closed e565597183226 ∧ code e565597183226 = 2764620438778 := by decide
theorem cert_e565597183226 : check e565597183226 [[],[.under],[.under,.under]] .three = true := by decide
def e565597183798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e565597183798 : Closed e565597183798 ∧ code e565597183798 = 2764620439350 := by decide
theorem cert_e565597183798 : check e565597183798 [[],[.under],[.under,.under]] .three = true := by decide
def e565597183802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e565597183802 : Closed e565597183802 ∧ code e565597183802 = 2764620439354 := by decide
theorem cert_e565597183802 : check e565597183802 [[],[.under],[.under,.under]] .three = true := by decide
def e565597198574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e565597198574 : Closed e565597198574 ∧ code e565597198574 = 2764620454126 := by decide
theorem cert_e565597198574 : check e565597198574 [[],[.under],[.under,.under]] .three = true := by decide
def e565597198582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e565597198582 : Closed e565597198582 ∧ code e565597198582 = 2764620454134 := by decide
theorem cert_e565597198582 : check e565597198582 [[],[.under],[.under,.under]] .three = true := by decide
def e565597199134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e565597199134 : Closed e565597199134 ∧ code e565597199134 = 2764620454686 := by decide
theorem cert_e565597199134 : check e565597199134 [[],[.under],[.under,.under]] .three = true := by decide
def e565597199246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e565597199246 : Closed e565597199246 ∧ code e565597199246 = 2764620454798 := by decide
private def t_e565597199246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem cert_e565597199246 : ¬ IsSelfInterpreter e565597199246 :=
  wSource (t := t_e565597199246) (replay_sound (ps := []) (t := e565597199246) (by decide)) (by decide)
def e565597199470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e565597199470 : Closed e565597199470 ∧ code e565597199470 = 2764620455022 := by decide
theorem cert_e565597199470 : check e565597199470 [[],[.under],[.under,.under]] .three = true := by decide
def e565597199482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e565597199482 : Closed e565597199482 ∧ code e565597199482 = 2764620455034 := by decide
theorem cert_e565597199482 : check e565597199482 [[],[.under],[.under,.under]] .three = true := by decide
def e565597199646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e565597199646 : Closed e565597199646 ∧ code e565597199646 = 2764620455198 := by decide
theorem cert_e565597199646 : check e565597199646 [[],[.under],[.under,.under]] .three = true := by decide
def e565597199814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e565597199814 : Closed e565597199814 ∧ code e565597199814 = 2764620455366 := by decide
theorem cert_e565597199814 : check e565597199814 [[],[.under],[.under,.under]] .three = true := by decide
def e565597199926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e565597199926 : Closed e565597199926 ∧ code e565597199926 = 2764620455478 := by decide
theorem cert_e565597199926 : check e565597199926 [[],[.under],[.under,.under]] .three = true := by decide
def e565597199930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e565597199930 : Closed e565597199930 ∧ code e565597199930 = 2764620455482 := by decide
theorem cert_e565597199930 : check e565597199930 [[],[.under],[.under,.under]] .three = true := by decide
def e565597200014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e565597200014 : Closed e565597200014 ∧ code e565597200014 = 2764620455566 := by decide
private def t_e565597200014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem cert_e565597200014 : ¬ IsSelfInterpreter e565597200014 :=
  wSource (t := t_e565597200014) (replay_sound (ps := []) (t := e565597200014) (by decide)) (by decide)
def e565597200070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e565597200070 : Closed e565597200070 ∧ code e565597200070 = 2764620455622 := by decide
theorem cert_e565597200070 : check e565597200070 [[],[.under],[.under,.under]] .three = true := by decide
def e565597202206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e565597202206 : Closed e565597202206 ∧ code e565597202206 = 2764620457758 := by decide
theorem cert_e565597202206 : check e565597202206 [[],[.under],[.under,.under]] .three = true := by decide
def e565597202318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e565597202318 : Closed e565597202318 ∧ code e565597202318 = 2764620457870 := by decide
theorem cert_e565597202318 : check e565597202318 [[],[.under],[.under,.under]] .three = true := by decide
def e565597205278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e565597205278 : Closed e565597205278 ∧ code e565597205278 = 2764620460830 := by decide
theorem cert_e565597205278 : check e565597205278 [[],[.under],[.under,.under]] .three = true := by decide
def e565597205446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e565597205446 : Closed e565597205446 ∧ code e565597205446 = 2764620460998 := by decide
theorem cert_e565597205446 : check e565597205446 [[],[.under],[.under,.under]] .three = true := by decide
def e565597206926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e565597206926 : Closed e565597206926 ∧ code e565597206926 = 2764620462478 := by decide
theorem cert_e565597206926 : check e565597206926 [[],[.under],[.under,.under]] .three = true := by decide
def e565597206982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e565597206982 : Closed e565597206982 ∧ code e565597206982 = 2764620462534 := by decide
theorem cert_e565597206982 : check e565597206982 [[],[.under],[.under,.under]] .three = true := by decide
def e565605051834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))
theorem wire_e565605051834 : Closed e565605051834 ∧ code e565605051834 = 2764628307386 := by decide
def e565605051866 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))
theorem wire_e565605051866 : Closed e565605051866 ∧ code e565605051866 = 2764628307418 := by decide
def e565605052090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))
theorem wire_e565605052090 : Closed e565605052090 ∧ code e565605052090 = 2764628307642 := by decide
def e565605052138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem wire_e565605052138 : Closed e565605052138 ∧ code e565605052138 = 2764628307690 := by decide
private def t_e565605052138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem cert_e565605052138 : ¬ IsSelfInterpreter e565605052138 :=
  wSource (t := t_e565605052138) (replay_sound (ps := []) (t := e565605052138) (by decide)) (by decide)
def e565605052250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))
theorem wire_e565605052250 : Closed e565605052250 ∧ code e565605052250 = 2764628307802 := by decide
def e565605052266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem wire_e565605052266 : Closed e565605052266 ∧ code e565605052266 = 2764628307818 := by decide
private def t_e565605052266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem cert_e565605052266 : ¬ IsSelfInterpreter e565605052266 :=
  wSource (t := t_e565605052266) (replay_sound (ps := []) (t := e565605052266) (by decide)) (by decide)
def e565605053370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem wire_e565605053370 : Closed e565605053370 ∧ code e565605053370 = 2764628308922 := by decide
def e565605053402 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem wire_e565605053402 : Closed e565605053402 ∧ code e565605053402 = 2764628308954 := by decide
def e565605054906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem wire_e565605054906 : Closed e565605054906 ∧ code e565605054906 = 2764628310458 := by decide
def e565605054954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem wire_e565605054954 : Closed e565605054954 ∧ code e565605054954 = 2764628310506 := by decide
def e565605055706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem wire_e565605055706 : Closed e565605055706 ∧ code e565605055706 = 2764628311258 := by decide
def e565605055722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem wire_e565605055722 : Closed e565605055722 ∧ code e565605055722 = 2764628311274 := by decide
def e565605305198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e565605305198 : Closed e565605305198 ∧ code e565605305198 = 2764628560750 := by decide
private def t_e565605305198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem cert_e565605305198 : ¬ IsSelfInterpreter e565605305198 :=
  wSource (t := t_e565605305198) (replay_sound (ps := []) (t := e565605305198) (by decide)) (by decide)
def e565605305206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e565605305206 : Closed e565605305206 ∧ code e565605305206 = 2764628560758 := by decide
private def t_e565605305206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e565605305206 : ¬ IsSelfInterpreter e565605305206 :=
  wSource (t := t_e565605305206) (replay_sound (ps := []) (t := e565605305206) (by decide)) (by decide)
def e565605305262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e565605305262 : Closed e565605305262 ∧ code e565605305262 = 2764628560814 := by decide
private def t_e565605305262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem cert_e565605305262 : ¬ IsSelfInterpreter e565605305262 :=
  wSource (t := t_e565605305262) (replay_sound (ps := []) (t := e565605305262) (by decide)) (by decide)
def e565605305274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e565605305274 : Closed e565605305274 ∧ code e565605305274 = 2764628560826 := by decide
private def t_e565605305274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e565605305274 : ¬ IsSelfInterpreter e565605305274 :=
  wSource (t := t_e565605305274) (replay_sound (ps := []) (t := e565605305274) (by decide)) (by decide)
def e565605305302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e565605305302 : Closed e565605305302 ∧ code e565605305302 = 2764628560854 := by decide
private def t_e565605305302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e565605305302 : ¬ IsSelfInterpreter e565605305302 :=
  wSource (t := t_e565605305302) (replay_sound (ps := []) (t := e565605305302) (by decide)) (by decide)
def e565605305306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e565605305306 : Closed e565605305306 ∧ code e565605305306 = 2764628560858 := by decide
private def t_e565605305306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e565605305306 : ¬ IsSelfInterpreter e565605305306 :=
  wSource (t := t_e565605305306) (replay_sound (ps := []) (t := e565605305306) (by decide)) (by decide)
def e565605305582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e565605305582 : Closed e565605305582 ∧ code e565605305582 = 2764628561134 := by decide
private def t_e565605305582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem cert_e565605305582 : ¬ IsSelfInterpreter e565605305582 :=
  wSource (t := t_e565605305582) (replay_sound (ps := []) (t := e565605305582) (by decide)) (by decide)
def e565605305590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e565605305590 : Closed e565605305590 ∧ code e565605305590 = 2764628561142 := by decide
private def t_e565605305590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem cert_e565605305590 : ¬ IsSelfInterpreter e565605305590 :=
  wSource (t := t_e565605305590) (replay_sound (ps := []) (t := e565605305590) (by decide)) (by decide)
def e565605305966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e565605305966 : Closed e565605305966 ∧ code e565605305966 = 2764628561518 := by decide
private def t_e565605305966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem cert_e565605305966 : ¬ IsSelfInterpreter e565605305966 :=
  wSource (t := t_e565605305966) (replay_sound (ps := []) (t := e565605305966) (by decide)) (by decide)
def e565605305978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e565605305978 : Closed e565605305978 ∧ code e565605305978 = 2764628561530 := by decide
private def t_e565605305978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem cert_e565605305978 : ¬ IsSelfInterpreter e565605305978 :=
  wSource (t := t_e565605305978) (replay_sound (ps := []) (t := e565605305978) (by decide)) (by decide)
def e565605306166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e565605306166 : Closed e565605306166 ∧ code e565605306166 = 2764628561718 := by decide
private def t_e565605306166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem cert_e565605306166 : ¬ IsSelfInterpreter e565605306166 :=
  wSource (t := t_e565605306166) (replay_sound (ps := []) (t := e565605306166) (by decide)) (by decide)
def e565605306170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e565605306170 : Closed e565605306170 ∧ code e565605306170 = 2764628561722 := by decide
private def t_e565605306170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem cert_e565605306170 : ¬ IsSelfInterpreter e565605306170 :=
  wSource (t := t_e565605306170) (replay_sound (ps := []) (t := e565605306170) (by decide)) (by decide)
def e565606100446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e565606100446 : Closed e565606100446 ∧ code e565606100446 = 2764629355998 := by decide
theorem cert_e565606100446 : check e565606100446 [[],[.under],[.under],[.under]] .three = true := by decide
def e565606100462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e565606100462 : Closed e565606100462 ∧ code e565606100462 = 2764629356014 := by decide
theorem cert_e565606100462 : check e565606100462 [[],[.under],[.under],[.under]] .three = true := by decide
def e565606100830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e565606100830 : Closed e565606100830 ∧ code e565606100830 = 2764629356382 := by decide
theorem cert_e565606100830 : check e565606100830 [[],[.under],[.under],[.under]] .three = true := by decide
def e565606100858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e565606100858 : Closed e565606100858 ∧ code e565606100858 = 2764629356410 := by decide
private def t_e565606100858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem cert_e565606100858 : ¬ IsSelfInterpreter e565606100858 :=
  wSource (t := t_e565606100858) (replay_sound (ps := []) (t := e565606100858) (by decide)) (by decide)
def e565606100910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e565606100910 : Closed e565606100910 ∧ code e565606100910 = 2764629356462 := by decide
theorem cert_e565606100910 : check e565606100910 [[],[.under],[.under],[.under]] .three = true := by decide
def e565606100922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e565606100922 : Closed e565606100922 ∧ code e565606100922 = 2764629356474 := by decide
private def t_e565606100922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem cert_e565606100922 : ¬ IsSelfInterpreter e565606100922 :=
  wSource (t := t_e565606100922) (replay_sound (ps := []) (t := e565606100922) (by decide)) (by decide)
def e565606101982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e565606101982 : Closed e565606101982 ∧ code e565606101982 = 2764629357534 := by decide
theorem cert_e565606101982 : check e565606101982 [[],[.under],[.under],[.under]] .three = true := by decide
def e565606101998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e565606101998 : Closed e565606101998 ∧ code e565606101998 = 2764629357550 := by decide
theorem cert_e565606101998 : check e565606101998 [[],[.under],[.under],[.under]] .three = true := by decide
def e565606104286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e565606104286 : Closed e565606104286 ∧ code e565606104286 = 2764629359838 := by decide
theorem cert_e565606104286 : check e565606104286 [[],[.under],[.under],[.under]] .three = true := by decide
def e565606104314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e565606104314 : Closed e565606104314 ∧ code e565606104314 = 2764629359866 := by decide
theorem cert_e565606104314 : check e565606104314 [[],[.under],[.under],[.under]] .three = true := by decide
def e565606104686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e565606104686 : Closed e565606104686 ∧ code e565606104686 = 2764629360238 := by decide
theorem cert_e565606104686 : check e565606104686 [[],[.under],[.under],[.under]] .three = true := by decide
def e565606104698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e565606104698 : Closed e565606104698 ∧ code e565606104698 = 2764629360250 := by decide
theorem cert_e565606104698 : check e565606104698 [[],[.under],[.under],[.under]] .three = true := by decide
def e565606133102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e565606133102 : Closed e565606133102 ∧ code e565606133102 = 2764629388654 := by decide
theorem cert_e565606133102 : check e565606133102 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e565606133110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e565606133110 : Closed e565606133110 ∧ code e565606133110 = 2764629388662 := by decide
theorem cert_e565606133110 : check e565606133110 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
end Blc.Floor41
