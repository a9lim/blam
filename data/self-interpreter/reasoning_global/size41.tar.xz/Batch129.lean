import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605639170846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605639170846 : Closed e605639170846 ∧ code e605639170846 = 2804662426398 := by decide
theorem cert_e605639170846 : check e605639170846 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639170958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605639170958 : Closed e605639170958 ∧ code e605639170958 = 2804662426510 := by decide
theorem cert_e605639170958 : check e605639170958 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639171182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605639171182 : Closed e605639171182 ∧ code e605639171182 = 2804662426734 := by decide
theorem cert_e605639171182 : check e605639171182 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639171194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605639171194 : Closed e605639171194 ∧ code e605639171194 = 2804662426746 := by decide
theorem cert_e605639171194 : check e605639171194 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639171358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605639171358 : Closed e605639171358 ∧ code e605639171358 = 2804662426910 := by decide
theorem cert_e605639171358 : check e605639171358 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639171526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605639171526 : Closed e605639171526 ∧ code e605639171526 = 2804662427078 := by decide
theorem cert_e605639171526 : check e605639171526 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639171638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605639171638 : Closed e605639171638 ∧ code e605639171638 = 2804662427190 := by decide
theorem cert_e605639171638 : check e605639171638 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639171642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605639171642 : Closed e605639171642 ∧ code e605639171642 = 2804662427194 := by decide
theorem cert_e605639171642 : check e605639171642 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639171726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605639171726 : Closed e605639171726 ∧ code e605639171726 = 2804662427278 := by decide
theorem cert_e605639171726 : check e605639171726 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639171782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605639171782 : Closed e605639171782 ∧ code e605639171782 = 2804662427334 := by decide
theorem cert_e605639171782 : check e605639171782 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639173918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605639173918 : Closed e605639173918 ∧ code e605639173918 = 2804662429470 := by decide
theorem cert_e605639173918 : check e605639173918 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639174030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605639174030 : Closed e605639174030 ∧ code e605639174030 = 2804662429582 := by decide
theorem cert_e605639174030 : check e605639174030 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639176990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605639176990 : Closed e605639176990 ∧ code e605639176990 = 2804662432542 := by decide
theorem cert_e605639176990 : check e605639176990 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639177158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605639177158 : Closed e605639177158 ∧ code e605639177158 = 2804662432710 := by decide
theorem cert_e605639177158 : check e605639177158 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639178638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605639178638 : Closed e605639178638 ∧ code e605639178638 = 2804662434190 := by decide
theorem cert_e605639178638 : check e605639178638 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639178694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605639178694 : Closed e605639178694 ∧ code e605639178694 = 2804662434246 := by decide
theorem cert_e605639178694 : check e605639178694 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639412590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605639412590 : Closed e605639412590 ∧ code e605639412590 = 2804662668142 := by decide
private def t_e605639412590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e605639412590 : ¬ IsSelfInterpreter e605639412590 :=
  wSource (t := t_e605639412590) (replay_sound (ps := []) (t := e605639412590) (by decide)) (by decide)
def e605639412598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605639412598 : Closed e605639412598 ∧ code e605639412598 = 2804662668150 := by decide
private def t_e605639412598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e605639412598 : ¬ IsSelfInterpreter e605639412598 :=
  wSource (t := t_e605639412598) (replay_sound (ps := []) (t := e605639412598) (by decide)) (by decide)
def e605639412654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605639412654 : Closed e605639412654 ∧ code e605639412654 = 2804662668206 := by decide
private def t_e605639412654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e605639412654 : ¬ IsSelfInterpreter e605639412654 :=
  wSource (t := t_e605639412654) (replay_sound (ps := []) (t := e605639412654) (by decide)) (by decide)
def e605639412666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605639412666 : Closed e605639412666 ∧ code e605639412666 = 2804662668218 := by decide
private def t_e605639412666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e605639412666 : ¬ IsSelfInterpreter e605639412666 :=
  wSource (t := t_e605639412666) (replay_sound (ps := []) (t := e605639412666) (by decide)) (by decide)
def e605639412694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605639412694 : Closed e605639412694 ∧ code e605639412694 = 2804662668246 := by decide
private def t_e605639412694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e605639412694 : ¬ IsSelfInterpreter e605639412694 :=
  wSource (t := t_e605639412694) (replay_sound (ps := []) (t := e605639412694) (by decide)) (by decide)
def e605639412698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605639412698 : Closed e605639412698 ∧ code e605639412698 = 2804662668250 := by decide
private def t_e605639412698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e605639412698 : ¬ IsSelfInterpreter e605639412698 :=
  wSource (t := t_e605639412698) (replay_sound (ps := []) (t := e605639412698) (by decide)) (by decide)
def e605639412974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605639412974 : Closed e605639412974 ∧ code e605639412974 = 2804662668526 := by decide
private def t_e605639412974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e605639412974 : ¬ IsSelfInterpreter e605639412974 :=
  wSource (t := t_e605639412974) (replay_sound (ps := []) (t := e605639412974) (by decide)) (by decide)
def e605639412982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605639412982 : Closed e605639412982 ∧ code e605639412982 = 2804662668534 := by decide
private def t_e605639412982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e605639412982 : ¬ IsSelfInterpreter e605639412982 :=
  wSource (t := t_e605639412982) (replay_sound (ps := []) (t := e605639412982) (by decide)) (by decide)
def e605639413358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605639413358 : Closed e605639413358 ∧ code e605639413358 = 2804662668910 := by decide
private def t_e605639413358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e605639413358 : ¬ IsSelfInterpreter e605639413358 :=
  wSource (t := t_e605639413358) (replay_sound (ps := []) (t := e605639413358) (by decide)) (by decide)
def e605639413370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605639413370 : Closed e605639413370 ∧ code e605639413370 = 2804662668922 := by decide
private def t_e605639413370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e605639413370 : ¬ IsSelfInterpreter e605639413370 :=
  wSource (t := t_e605639413370) (replay_sound (ps := []) (t := e605639413370) (by decide)) (by decide)
def e605639413558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605639413558 : Closed e605639413558 ∧ code e605639413558 = 2804662669110 := by decide
private def t_e605639413558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e605639413558 : ¬ IsSelfInterpreter e605639413558 :=
  wSource (t := t_e605639413558) (replay_sound (ps := []) (t := e605639413558) (by decide)) (by decide)
def e605639413562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605639413562 : Closed e605639413562 ∧ code e605639413562 = 2804662669114 := by decide
private def t_e605639413562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e605639413562 : ¬ IsSelfInterpreter e605639413562 :=
  wSource (t := t_e605639413562) (replay_sound (ps := []) (t := e605639413562) (by decide)) (by decide)
def e605640732094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4))))))))))
theorem wire_e605640732094 : Closed e605640732094 ∧ code e605640732094 = 2804663987646 := by decide
theorem cert_e605640732094 : check e605640732094 [[],[]] .smaller = true := by decide
def e605640732150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1))))))))))
theorem wire_e605640732150 : Closed e605640732150 ∧ code e605640732150 = 2804663987702 := by decide
theorem cert_e605640732150 : check e605640732150 [[],[]] .smaller = true := by decide
def e605640732350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4))))))))))
theorem wire_e605640732350 : Closed e605640732350 ∧ code e605640732350 = 2804663987902 := by decide
theorem cert_e605640732350 : check e605640732350 [[],[]] .smaller = true := by decide
def e605640732410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0))))))))))
theorem wire_e605640732410 : Closed e605640732410 ∧ code e605640732410 = 2804663987962 := by decide
theorem cert_e605640732410 : check e605640732410 [[],[]] .smaller = true := by decide
def e605640732630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1))))))))))
theorem wire_e605640732630 : Closed e605640732630 ∧ code e605640732630 = 2804663988182 := by decide
theorem cert_e605640732630 : check e605640732630 [[],[]] .smaller = true := by decide
def e605640732634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0))))))))))
theorem wire_e605640732634 : Closed e605640732634 ∧ code e605640732634 = 2804663988186 := by decide
theorem cert_e605640732634 : check e605640732634 [[],[]] .smaller = true := by decide
def e605640733630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4)))))))))))
theorem wire_e605640733630 : Closed e605640733630 ∧ code e605640733630 = 2804663989182 := by decide
theorem cert_e605640733630 : check e605640733630 [[],[]] .smaller = true := by decide
def e605640733686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1)))))))))))
theorem wire_e605640733686 : Closed e605640733686 ∧ code e605640733686 = 2804663989238 := by decide
theorem cert_e605640733686 : check e605640733686 [[],[]] .smaller = true := by decide
def e605640735166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4)))))))))))
theorem wire_e605640735166 : Closed e605640735166 ∧ code e605640735166 = 2804663990718 := by decide
theorem cert_e605640735166 : check e605640735166 [[],[]] .smaller = true := by decide
def e605640735226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0)))))))))))
theorem wire_e605640735226 : Closed e605640735226 ∧ code e605640735226 = 2804663990778 := by decide
theorem cert_e605640735226 : check e605640735226 [[],[]] .smaller = true := by decide
def e605640736566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605640736566 : Closed e605640736566 ∧ code e605640736566 = 2804663992118 := by decide
theorem cert_e605640736566 : check e605640736566 [[],[]] .smaller = true := by decide
def e605640736570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605640736570 : Closed e605640736570 ∧ code e605640736570 = 2804663992122 := by decide
theorem cert_e605640736570 : check e605640736570 [[],[]] .smaller = true := by decide
def e605640764782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e605640764782 : Closed e605640764782 ∧ code e605640764782 = 2804664020334 := by decide
theorem cert_e605640764782 : check e605640764782 [[],[]] .smaller = true := by decide
def e605640764790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e605640764790 : Closed e605640764790 ∧ code e605640764790 = 2804664020342 := by decide
theorem cert_e605640764790 : check e605640764790 [[],[]] .smaller = true := by decide
def e605640764846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e605640764846 : Closed e605640764846 ∧ code e605640764846 = 2804664020398 := by decide
theorem cert_e605640764846 : check e605640764846 [[],[]] .smaller = true := by decide
def e605640764858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e605640764858 : Closed e605640764858 ∧ code e605640764858 = 2804664020410 := by decide
theorem cert_e605640764858 : check e605640764858 [[],[]] .smaller = true := by decide
def e605640764886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e605640764886 : Closed e605640764886 ∧ code e605640764886 = 2804664020438 := by decide
theorem cert_e605640764886 : check e605640764886 [[],[]] .smaller = true := by decide
def e605640764890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e605640764890 : Closed e605640764890 ∧ code e605640764890 = 2804664020442 := by decide
theorem cert_e605640764890 : check e605640764890 [[],[]] .smaller = true := by decide
def e605640765102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e605640765102 : Closed e605640765102 ∧ code e605640765102 = 2804664020654 := by decide
theorem cert_e605640765102 : check e605640765102 [[],[]] .smaller = true := by decide
def e605640765114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e605640765114 : Closed e605640765114 ∧ code e605640765114 = 2804664020666 := by decide
theorem cert_e605640765114 : check e605640765114 [[],[]] .smaller = true := by decide
def e605640765162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e605640765162 : Closed e605640765162 ∧ code e605640765162 = 2804664020714 := by decide
theorem cert_e605640765162 : check e605640765162 [[],[]] .smaller = true := by decide
def e605640765270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e605640765270 : Closed e605640765270 ∧ code e605640765270 = 2804664020822 := by decide
theorem cert_e605640765270 : check e605640765270 [[],[]] .smaller = true := by decide
def e605640765274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e605640765274 : Closed e605640765274 ∧ code e605640765274 = 2804664020826 := by decide
theorem cert_e605640765274 : check e605640765274 [[],[]] .smaller = true := by decide
def e605640765290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e605640765290 : Closed e605640765290 ∧ code e605640765290 = 2804664020842 := by decide
theorem cert_e605640765290 : check e605640765290 [[],[]] .smaller = true := by decide
def e605640765918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3)))))))))
theorem wire_e605640765918 : Closed e605640765918 ∧ code e605640765918 = 2804664021470 := by decide
theorem cert_e605640765918 : check e605640765918 [[],[]] .smaller = true := by decide
def e605640765942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1)))))))))
theorem wire_e605640765942 : Closed e605640765942 ∧ code e605640765942 = 2804664021494 := by decide
theorem cert_e605640765942 : check e605640765942 [[],[]] .smaller = true := by decide
def e605640766318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e605640766318 : Closed e605640766318 ∧ code e605640766318 = 2804664021870 := by decide
theorem cert_e605640766318 : check e605640766318 [[],[]] .smaller = true := by decide
def e605640766326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e605640766326 : Closed e605640766326 ∧ code e605640766326 = 2804664021878 := by decide
theorem cert_e605640766326 : check e605640766326 [[],[]] .smaller = true := by decide
def e605640766382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e605640766382 : Closed e605640766382 ∧ code e605640766382 = 2804664021934 := by decide
theorem cert_e605640766382 : check e605640766382 [[],[]] .smaller = true := by decide
def e605640766394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e605640766394 : Closed e605640766394 ∧ code e605640766394 = 2804664021946 := by decide
theorem cert_e605640766394 : check e605640766394 [[],[]] .smaller = true := by decide
def e605640766422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e605640766422 : Closed e605640766422 ∧ code e605640766422 = 2804664021974 := by decide
theorem cert_e605640766422 : check e605640766422 [[],[]] .smaller = true := by decide
def e605640766426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e605640766426 : Closed e605640766426 ∧ code e605640766426 = 2804664021978 := by decide
theorem cert_e605640766426 : check e605640766426 [[],[]] .smaller = true := by decide
def e605640766702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e605640766702 : Closed e605640766702 ∧ code e605640766702 = 2804664022254 := by decide
theorem cert_e605640766702 : check e605640766702 [[],[]] .smaller = true := by decide
def e605640766710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e605640766710 : Closed e605640766710 ∧ code e605640766710 = 2804664022262 := by decide
theorem cert_e605640766710 : check e605640766710 [[],[]] .smaller = true := by decide
def e605640767038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4))))))))))
theorem wire_e605640767038 : Closed e605640767038 ∧ code e605640767038 = 2804664022590 := by decide
theorem cert_e605640767038 : check e605640767038 [[],[]] .smaller = true := by decide
def e605640767086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605640767086 : Closed e605640767086 ∧ code e605640767086 = 2804664022638 := by decide
theorem cert_e605640767086 : check e605640767086 [[],[]] .smaller = true := by decide
def e605640767098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605640767098 : Closed e605640767098 ∧ code e605640767098 = 2804664022650 := by decide
theorem cert_e605640767098 : check e605640767098 [[],[]] .smaller = true := by decide
def e605640767286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605640767286 : Closed e605640767286 ∧ code e605640767286 = 2804664022838 := by decide
theorem cert_e605640767286 : check e605640767286 [[],[]] .smaller = true := by decide
def e605640767290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605640767290 : Closed e605640767290 ∧ code e605640767290 = 2804664022842 := by decide
theorem cert_e605640767290 : check e605640767290 [[],[]] .smaller = true := by decide
def e605640767374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2))))))))))
theorem wire_e605640767374 : Closed e605640767374 ∧ code e605640767374 = 2804664022926 := by decide
theorem cert_e605640767374 : check e605640767374 [[],[]] .smaller = true := by decide
def e605640767422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 4)))))))))
theorem wire_e605640767422 : Closed e605640767422 ∧ code e605640767422 = 2804664022974 := by decide
theorem cert_e605640767422 : check e605640767422 [[],[]] .chain = true := by decide
def e605640767454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 3)))))))))
theorem wire_e605640767454 : Closed e605640767454 ∧ code e605640767454 = 2804664023006 := by decide
theorem cert_e605640767454 : check e605640767454 [[],[]] .chain = true := by decide
def e605640767710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e605640767710 : Closed e605640767710 ∧ code e605640767710 = 2804664023262 := by decide
theorem cert_e605640767710 : check e605640767710 [[],[]] .smaller = true := by decide
def e605640767738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e605640767738 : Closed e605640767738 ∧ code e605640767738 = 2804664023290 := by decide
theorem cert_e605640767738 : check e605640767738 [[],[]] .smaller = true := by decide
def e605640767918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e605640767918 : Closed e605640767918 ∧ code e605640767918 = 2804664023470 := by decide
theorem cert_e605640767918 : check e605640767918 [[],[]] .smaller = true := by decide
def e605640767930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e605640767930 : Closed e605640767930 ∧ code e605640767930 = 2804664023482 := by decide
theorem cert_e605640767930 : check e605640767930 [[],[]] .smaller = true := by decide
def e605640767978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e605640767978 : Closed e605640767978 ∧ code e605640767978 = 2804664023530 := by decide
theorem cert_e605640767978 : check e605640767978 [[],[]] .smaller = true := by decide
def e605640768062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e605640768062 : Closed e605640768062 ∧ code e605640768062 = 2804664023614 := by decide
theorem cert_e605640768062 : check e605640768062 [[],[]] .smaller = true := by decide
def e605640768110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605640768110 : Closed e605640768110 ∧ code e605640768110 = 2804664023662 := by decide
theorem cert_e605640768110 : check e605640768110 [[],[]] .smaller = true := by decide
def e605640768122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605640768122 : Closed e605640768122 ∧ code e605640768122 = 2804664023674 := by decide
theorem cert_e605640768122 : check e605640768122 [[],[]] .smaller = true := by decide
def e605640768410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605640768410 : Closed e605640768410 ∧ code e605640768410 = 2804664023962 := by decide
theorem cert_e605640768410 : check e605640768410 [[],[]] .smaller = true := by decide
def e605640768454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e605640768454 : Closed e605640768454 ∧ code e605640768454 = 2804664024006 := by decide
theorem cert_e605640768454 : check e605640768454 [[],[]] .smaller = true := by decide
def e605640768726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e605640768726 : Closed e605640768726 ∧ code e605640768726 = 2804664024278 := by decide
theorem cert_e605640768726 : check e605640768726 [[],[]] .smaller = true := by decide
def e605640768730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e605640768730 : Closed e605640768730 ∧ code e605640768730 = 2804664024282 := by decide
theorem cert_e605640768730 : check e605640768730 [[],[]] .smaller = true := by decide
def e605640768746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e605640768746 : Closed e605640768746 ∧ code e605640768746 = 2804664024298 := by decide
theorem cert_e605640768746 : check e605640768746 [[],[]] .smaller = true := by decide
def e605640768822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605640768822 : Closed e605640768822 ∧ code e605640768822 = 2804664024374 := by decide
theorem cert_e605640768822 : check e605640768822 [[],[]] .smaller = true := by decide
def e605640768826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605640768826 : Closed e605640768826 ∧ code e605640768826 = 2804664024378 := by decide
theorem cert_e605640768826 : check e605640768826 [[],[]] .smaller = true := by decide
def e605640768922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605640768922 : Closed e605640768922 ∧ code e605640768922 = 2804664024474 := by decide
theorem cert_e605640768922 : check e605640768922 [[],[]] .smaller = true := by decide
def e605640769078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e605640769078 : Closed e605640769078 ∧ code e605640769078 = 2804664024630 := by decide
theorem cert_e605640769078 : check e605640769078 [[],[]] .smaller = true := by decide
def e605640769082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e605640769082 : Closed e605640769082 ∧ code e605640769082 = 2804664024634 := by decide
theorem cert_e605640769082 : check e605640769082 [[],[]] .smaller = true := by decide
def e605640769166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e605640769166 : Closed e605640769166 ∧ code e605640769166 = 2804664024718 := by decide
theorem cert_e605640769166 : check e605640769166 [[],[]] .smaller = true := by decide
def e605640769214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 4)))))))))
theorem wire_e605640769214 : Closed e605640769214 ∧ code e605640769214 = 2804664024766 := by decide
theorem cert_e605640769214 : check e605640769214 [[],[]] .chain = true := by decide
def e605640769222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e605640769222 : Closed e605640769222 ∧ code e605640769222 = 2804664024774 := by decide
theorem cert_e605640769222 : check e605640769222 [[],[]] .smaller = true := by decide
def e605640769274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 4)) (.var 0)))))))))
theorem wire_e605640769274 : Closed e605640769274 ∧ code e605640769274 = 2804664024826 := by decide
theorem cert_e605640769274 : check e605640769274 [[],[]] .chain = true := by decide
def e605640769374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 3)))))))))
theorem wire_e605640769374 : Closed e605640769374 ∧ code e605640769374 = 2804664024926 := by decide
theorem cert_e605640769374 : check e605640769374 [[],[]] .chain = true := by decide
def e605640769402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 4) (.var 3)) (.var 0)))))))))
theorem wire_e605640769402 : Closed e605640769402 ∧ code e605640769402 = 2804664024954 := by decide
theorem cert_e605640769402 : check e605640769402 [[],[]] .chain = true := by decide
def e605640772462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605640772462 : Closed e605640772462 ∧ code e605640772462 = 2804664028014 := by decide
theorem cert_e605640772462 : check e605640772462 [[],[]] .smaller = true := by decide
def e605640772470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605640772470 : Closed e605640772470 ∧ code e605640772470 = 2804664028022 := by decide
theorem cert_e605640772470 : check e605640772470 [[],[]] .smaller = true := by decide
def e605640772526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605640772526 : Closed e605640772526 ∧ code e605640772526 = 2804664028078 := by decide
theorem cert_e605640772526 : check e605640772526 [[],[]] .smaller = true := by decide
def e605640772538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605640772538 : Closed e605640772538 ∧ code e605640772538 = 2804664028090 := by decide
theorem cert_e605640772538 : check e605640772538 [[],[]] .smaller = true := by decide
def e605640772566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605640772566 : Closed e605640772566 ∧ code e605640772566 = 2804664028118 := by decide
theorem cert_e605640772566 : check e605640772566 [[],[]] .smaller = true := by decide
def e605640772570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605640772570 : Closed e605640772570 ∧ code e605640772570 = 2804664028122 := by decide
theorem cert_e605640772570 : check e605640772570 [[],[]] .smaller = true := by decide
def e605640772846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605640772846 : Closed e605640772846 ∧ code e605640772846 = 2804664028398 := by decide
theorem cert_e605640772846 : check e605640772846 [[],[]] .smaller = true := by decide
def e605640772854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605640772854 : Closed e605640772854 ∧ code e605640772854 = 2804664028406 := by decide
theorem cert_e605640772854 : check e605640772854 [[],[]] .smaller = true := by decide
def e605640773182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e605640773182 : Closed e605640773182 ∧ code e605640773182 = 2804664028734 := by decide
theorem cert_e605640773182 : check e605640773182 [[],[]] .smaller = true := by decide
def e605640773230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605640773230 : Closed e605640773230 ∧ code e605640773230 = 2804664028782 := by decide
theorem cert_e605640773230 : check e605640773230 [[],[]] .smaller = true := by decide
def e605640773242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605640773242 : Closed e605640773242 ∧ code e605640773242 = 2804664028794 := by decide
theorem cert_e605640773242 : check e605640773242 [[],[]] .smaller = true := by decide
def e605640773430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605640773430 : Closed e605640773430 ∧ code e605640773430 = 2804664028982 := by decide
theorem cert_e605640773430 : check e605640773430 [[],[]] .smaller = true := by decide
def e605640773434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605640773434 : Closed e605640773434 ∧ code e605640773434 = 2804664028986 := by decide
theorem cert_e605640773434 : check e605640773434 [[],[]] .smaller = true := by decide
def e605640773518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e605640773518 : Closed e605640773518 ∧ code e605640773518 = 2804664029070 := by decide
theorem cert_e605640773518 : check e605640773518 [[],[]] .smaller = true := by decide
def e605640773566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 4))))))))))
theorem wire_e605640773566 : Closed e605640773566 ∧ code e605640773566 = 2804664029118 := by decide
theorem cert_e605640773566 : check e605640773566 [[],[]] .chain = true := by decide
def e605640773598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 3))))))))))
theorem wire_e605640773598 : Closed e605640773598 ∧ code e605640773598 = 2804664029150 := by decide
theorem cert_e605640773598 : check e605640773598 [[],[]] .chain = true := by decide
def e605640779182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e605640779182 : Closed e605640779182 ∧ code e605640779182 = 2804664034734 := by decide
theorem cert_e605640779182 : check e605640779182 [[],[]] .smaller = true := by decide
def e605640779194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e605640779194 : Closed e605640779194 ∧ code e605640779194 = 2804664034746 := by decide
theorem cert_e605640779194 : check e605640779194 [[],[]] .smaller = true := by decide
def e605640779242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e605640779242 : Closed e605640779242 ∧ code e605640779242 = 2804664034794 := by decide
theorem cert_e605640779242 : check e605640779242 [[],[]] .smaller = true := by decide
def e605640779326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e605640779326 : Closed e605640779326 ∧ code e605640779326 = 2804664034878 := by decide
theorem cert_e605640779326 : check e605640779326 [[],[]] .smaller = true := by decide
def e605640779374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605640779374 : Closed e605640779374 ∧ code e605640779374 = 2804664034926 := by decide
theorem cert_e605640779374 : check e605640779374 [[],[]] .smaller = true := by decide
def e605640779386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605640779386 : Closed e605640779386 ∧ code e605640779386 = 2804664034938 := by decide
theorem cert_e605640779386 : check e605640779386 [[],[]] .smaller = true := by decide
def e605640779674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605640779674 : Closed e605640779674 ∧ code e605640779674 = 2804664035226 := by decide
theorem cert_e605640779674 : check e605640779674 [[],[]] .smaller = true := by decide
def e605640779718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e605640779718 : Closed e605640779718 ∧ code e605640779718 = 2804664035270 := by decide
theorem cert_e605640779718 : check e605640779718 [[],[]] .smaller = true := by decide
def e605640782550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e605640782550 : Closed e605640782550 ∧ code e605640782550 = 2804664038102 := by decide
theorem cert_e605640782550 : check e605640782550 [[],[]] .smaller = true := by decide
def e605640782554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e605640782554 : Closed e605640782554 ∧ code e605640782554 = 2804664038106 := by decide
theorem cert_e605640782554 : check e605640782554 [[],[]] .smaller = true := by decide
def e605640782570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e605640782570 : Closed e605640782570 ∧ code e605640782570 = 2804664038122 := by decide
theorem cert_e605640782570 : check e605640782570 [[],[]] .smaller = true := by decide
def e605640782646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605640782646 : Closed e605640782646 ∧ code e605640782646 = 2804664038198 := by decide
theorem cert_e605640782646 : check e605640782646 [[],[]] .smaller = true := by decide
def e605640782650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605640782650 : Closed e605640782650 ∧ code e605640782650 = 2804664038202 := by decide
theorem cert_e605640782650 : check e605640782650 [[],[]] .smaller = true := by decide
def e605640782746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605640782746 : Closed e605640782746 ∧ code e605640782746 = 2804664038298 := by decide
theorem cert_e605640782746 : check e605640782746 [[],[]] .smaller = true := by decide
def e605640784270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e605640784270 : Closed e605640784270 ∧ code e605640784270 = 2804664039822 := by decide
theorem cert_e605640784270 : check e605640784270 [[],[]] .smaller = true := by decide
def e605640784318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 4))))))))))
theorem wire_e605640784318 : Closed e605640784318 ∧ code e605640784318 = 2804664039870 := by decide
theorem cert_e605640784318 : check e605640784318 [[],[]] .chain = true := by decide
def e605640784326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e605640784326 : Closed e605640784326 ∧ code e605640784326 = 2804664039878 := by decide
theorem cert_e605640784326 : check e605640784326 [[],[]] .smaller = true := by decide
def e605640784378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 4) (.var 0))))))))))
theorem wire_e605640784378 : Closed e605640784378 ∧ code e605640784378 = 2804664039930 := by decide
theorem cert_e605640784378 : check e605640784378 [[],[]] .chain = true := by decide
def e605640785118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 3))))))))))
theorem wire_e605640785118 : Closed e605640785118 ∧ code e605640785118 = 2804664040670 := by decide
theorem cert_e605640785118 : check e605640785118 [[],[]] .chain = true := by decide
def e605640785146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 4) (.app (.var 3) (.var 0))))))))))
theorem wire_e605640785146 : Closed e605640785146 ∧ code e605640785146 = 2804664040698 := by decide
theorem cert_e605640785146 : check e605640785146 [[],[]] .chain = true := by decide
def e605640896878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e605640896878 : Closed e605640896878 ∧ code e605640896878 = 2804664152430 := by decide
theorem cert_e605640896878 : check e605640896878 [[],[]] .smaller = true := by decide
def e605640896886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e605640896886 : Closed e605640896886 ∧ code e605640896886 = 2804664152438 := by decide
theorem cert_e605640896886 : check e605640896886 [[],[]] .smaller = true := by decide
def e605640898014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e605640898014 : Closed e605640898014 ∧ code e605640898014 = 2804664153566 := by decide
theorem cert_e605640898014 : check e605640898014 [[],[]] .chain = true := by decide
def e605640898030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e605640898030 : Closed e605640898030 ∧ code e605640898030 = 2804664153582 := by decide
theorem cert_e605640898030 : check e605640898030 [[],[]] .chain = true := by decide
def e605640898094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605640898094 : Closed e605640898094 ∧ code e605640898094 = 2804664153646 := by decide
theorem cert_e605640898094 : check e605640898094 [[],[]] .smaller = true := by decide
def e605640898270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e605640898270 : Closed e605640898270 ∧ code e605640898270 = 2804664153822 := by decide
theorem cert_e605640898270 : check e605640898270 [[],[]] .chain = true := by decide
def e605640898274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605640898274 : Closed e605640898274 ∧ code e605640898274 = 2804664153826 := by decide
theorem cert_e605640898274 : check e605640898274 [[],[]] .smaller = true := by decide
def e605640898286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e605640898286 : Closed e605640898286 ∧ code e605640898286 = 2804664153838 := by decide
theorem cert_e605640898286 : check e605640898286 [[],[]] .smaller = true := by decide
def e605640898294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e605640898294 : Closed e605640898294 ∧ code e605640898294 = 2804664153846 := by decide
theorem cert_e605640898294 : check e605640898294 [[],[]] .chain = true := by decide
def e605640898326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e605640898326 : Closed e605640898326 ∧ code e605640898326 = 2804664153878 := by decide
theorem cert_e605640898326 : check e605640898326 [[],[]] .smaller = true := by decide
def e605640898398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e605640898398 : Closed e605640898398 ∧ code e605640898398 = 2804664153950 := by decide
theorem cert_e605640898398 : check e605640898398 [[],[]] .chain = true := by decide
def e605640898402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e605640898402 : Closed e605640898402 ∧ code e605640898402 = 2804664153954 := by decide
theorem cert_e605640898402 : check e605640898402 [[],[]] .smaller = true := by decide
def e605640898414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e605640898414 : Closed e605640898414 ∧ code e605640898414 = 2804664153966 := by decide
theorem cert_e605640898414 : check e605640898414 [[],[]] .smaller = true := by decide
def e605640898422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e605640898422 : Closed e605640898422 ∧ code e605640898422 = 2804664153974 := by decide
theorem cert_e605640898422 : check e605640898422 [[],[]] .smaller = true := by decide
def e605640898426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e605640898426 : Closed e605640898426 ∧ code e605640898426 = 2804664153978 := by decide
theorem cert_e605640898426 : check e605640898426 [[],[]] .chain = true := by decide
def e605640898478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e605640898478 : Closed e605640898478 ∧ code e605640898478 = 2804664154030 := by decide
theorem cert_e605640898478 : check e605640898478 [[],[]] .chain = true := by decide
def e605640898486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e605640898486 : Closed e605640898486 ∧ code e605640898486 = 2804664154038 := by decide
theorem cert_e605640898486 : check e605640898486 [[],[]] .chain = true := by decide
def e605640898490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e605640898490 : Closed e605640898490 ∧ code e605640898490 = 2804664154042 := by decide
theorem cert_e605640898490 : check e605640898490 [[],[]] .chain = true := by decide
def e605640898734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e605640898734 : Closed e605640898734 ∧ code e605640898734 = 2804664154286 := by decide
theorem cert_e605640898734 : check e605640898734 [[],[]] .smaller = true := by decide
def e605640898746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e605640898746 : Closed e605640898746 ∧ code e605640898746 = 2804664154298 := by decide
theorem cert_e605640898746 : check e605640898746 [[],[]] .smaller = true := by decide
def e605640899118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605640899118 : Closed e605640899118 ∧ code e605640899118 = 2804664154670 := by decide
theorem cert_e605640899118 : check e605640899118 [[],[]] .smaller = true := by decide
def e605640899294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e605640899294 : Closed e605640899294 ∧ code e605640899294 = 2804664154846 := by decide
theorem cert_e605640899294 : check e605640899294 [[],[]] .chain = true := by decide
def e605640899298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605640899298 : Closed e605640899298 ∧ code e605640899298 = 2804664154850 := by decide
theorem cert_e605640899298 : check e605640899298 [[],[]] .smaller = true := by decide
def e605640899310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e605640899310 : Closed e605640899310 ∧ code e605640899310 = 2804664154862 := by decide
theorem cert_e605640899310 : check e605640899310 [[],[]] .smaller = true := by decide
def e605640899318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e605640899318 : Closed e605640899318 ∧ code e605640899318 = 2804664154870 := by decide
theorem cert_e605640899318 : check e605640899318 [[],[]] .chain = true := by decide
def e605640899422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e605640899422 : Closed e605640899422 ∧ code e605640899422 = 2804664154974 := by decide
theorem cert_e605640899422 : check e605640899422 [[],[]] .chain = true := by decide
def e605640899450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e605640899450 : Closed e605640899450 ∧ code e605640899450 = 2804664155002 := by decide
theorem cert_e605640899450 : check e605640899450 [[],[]] .chain = true := by decide
def e605640899466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605640899466 : Closed e605640899466 ∧ code e605640899466 = 2804664155018 := by decide
theorem cert_e605640899466 : check e605640899466 [[],[]] .smaller = true := by decide
def e605640899490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605640899490 : Closed e605640899490 ∧ code e605640899490 = 2804664155042 := by decide
theorem cert_e605640899490 : check e605640899490 [[],[]] .smaller = true := by decide
def e605640899502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e605640899502 : Closed e605640899502 ∧ code e605640899502 = 2804664155054 := by decide
theorem cert_e605640899502 : check e605640899502 [[],[]] .smaller = true := by decide
end Blc.Floor41
