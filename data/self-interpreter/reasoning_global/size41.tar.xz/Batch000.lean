import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e138167641626 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138167641626 : Closed e138167641626 ∧ code e138167641626 = 2337190897178 := by decide
theorem cert_e138167641626 : check e138167641626 [[.under]] .three = true := by decide
def e138168165914 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138168165914 : Closed e138168165914 ∧ code e138168165914 = 2337191421466 := by decide
theorem cert_e138168165914 : check e138168165914 [[.under]] .three = true := by decide
def e138168198682 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138168198682 : Closed e138168198682 ∧ code e138168198682 = 2337191454234 := by decide
theorem cert_e138168198682 : check e138168198682 [[.under]] .three = true := by decide
def e138171835930 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138171835930 : Closed e138171835930 ∧ code e138171835930 = 2337195091482 := by decide
theorem cert_e138171835930 : check e138171835930 [[.under]] .three = true := by decide
def e138172622362 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138172622362 : Closed e138172622362 ∧ code e138172622362 = 2337195877914 := by decide
theorem cert_e138172622362 : check e138172622362 [[.under]] .three = true := by decide
def e138172671514 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138172671514 : Closed e138172671514 ∧ code e138172671514 = 2337195927066 := by decide
theorem cert_e138172671514 : check e138172671514 [[.under]] .three = true := by decide
def e138174457370 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138174457370 : Closed e138174457370 ∧ code e138174457370 = 2337197712922 := by decide
theorem cert_e138174457370 : check e138174457370 [[.under]] .three = true := by decide
def e138174490138 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138174490138 : Closed e138174490138 ∧ code e138174490138 = 2337197745690 := by decide
theorem cert_e138174490138 : check e138174490138 [[.under]] .three = true := by decide
def e138174719514 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138174719514 : Closed e138174719514 ∧ code e138174719514 = 2337197975066 := by decide
theorem cert_e138174719514 : check e138174719514 [[.under]] .three = true := by decide
def e138174768666 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138174768666 : Closed e138174768666 ∧ code e138174768666 = 2337198024218 := by decide
theorem cert_e138174768666 : check e138174768666 [[.under]] .three = true := by decide
def e138174883354 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138174883354 : Closed e138174883354 ∧ code e138174883354 = 2337198138906 := by decide
theorem cert_e138174883354 : check e138174883354 [[.under]] .three = true := by decide
def e138174899738 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138174899738 : Closed e138174899738 ∧ code e138174899738 = 2337198155290 := by decide
theorem cert_e138174899738 : check e138174899738 [[.under]] .three = true := by decide
def e138192807450 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138192807450 : Closed e138192807450 ∧ code e138192807450 = 2337216063002 := by decide
theorem cert_e138192807450 : check e138192807450 [[.under]] .three = true := by decide
def e138193331738 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138193331738 : Closed e138193331738 ∧ code e138193331738 = 2337216587290 := by decide
theorem cert_e138193331738 : check e138193331738 [[.under]] .three = true := by decide
def e138193364506 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138193364506 : Closed e138193364506 ∧ code e138193364506 = 2337216620058 := by decide
theorem cert_e138193364506 : check e138193364506 [[.under]] .three = true := by decide
def e138204341786 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138204341786 : Closed e138204341786 ∧ code e138204341786 = 2337227597338 := by decide
theorem cert_e138204341786 : check e138204341786 [[.under]] .three = true := by decide
def e138207487514 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138207487514 : Closed e138207487514 ∧ code e138207487514 = 2337230743066 := by decide
theorem cert_e138207487514 : check e138207487514 [[.under]] .three = true := by decide
def e138207520282 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138207520282 : Closed e138207520282 ∧ code e138207520282 = 2337230775834 := by decide
theorem cert_e138207520282 : check e138207520282 [[.under]] .three = true := by decide
def e138217973274 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138217973274 : Closed e138217973274 ∧ code e138217973274 = 2337241228826 := by decide
theorem cert_e138217973274 : check e138217973274 [[.under]] .three = true := by decide
def e138218759706 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138218759706 : Closed e138218759706 ∧ code e138218759706 = 2337242015258 := by decide
theorem cert_e138218759706 : check e138218759706 [[.under]] .three = true := by decide
def e138218808858 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138218808858 : Closed e138218808858 ∧ code e138218808858 = 2337242064410 := by decide
theorem cert_e138218808858 : check e138218808858 [[.under]] .three = true := by decide
def e138221119002 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138221119002 : Closed e138221119002 ∧ code e138221119002 = 2337244374554 := by decide
theorem cert_e138221119002 : check e138221119002 [[.under]] .three = true := by decide
def e138225837594 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138225837594 : Closed e138225837594 ∧ code e138225837594 = 2337249093146 := by decide
theorem cert_e138225837594 : check e138225837594 [[.under]] .three = true := by decide
def e138225886746 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138225886746 : Closed e138225886746 ∧ code e138225886746 = 2337249142298 := by decide
theorem cert_e138225886746 : check e138225886746 [[.under]] .three = true := by decide
def e138231080474 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138231080474 : Closed e138231080474 ∧ code e138231080474 = 2337254336026 := by decide
theorem cert_e138231080474 : check e138231080474 [[.under]] .three = true := by decide
def e138231113242 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138231113242 : Closed e138231113242 ∧ code e138231113242 = 2337254368794 := by decide
theorem cert_e138231113242 : check e138231113242 [[.under]] .three = true := by decide
def e138231342618 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138231342618 : Closed e138231342618 ∧ code e138231342618 = 2337254598170 := by decide
theorem cert_e138231342618 : check e138231342618 [[.under]] .three = true := by decide
def e138231391770 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138231391770 : Closed e138231391770 ∧ code e138231391770 = 2337254647322 := by decide
theorem cert_e138231391770 : check e138231391770 [[.under]] .three = true := by decide
def e138231506458 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138231506458 : Closed e138231506458 ∧ code e138231506458 = 2337254762010 := by decide
theorem cert_e138231506458 : check e138231506458 [[.under]] .three = true := by decide
def e138231522842 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138231522842 : Closed e138231522842 ∧ code e138231522842 = 2337254778394 := by decide
theorem cert_e138231522842 : check e138231522842 [[.under]] .three = true := by decide
def e138232653338 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138232653338 : Closed e138232653338 ∧ code e138232653338 = 2337255908890 := by decide
theorem cert_e138232653338 : check e138232653338 [[.under]] .three = true := by decide
def e138232686106 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138232686106 : Closed e138232686106 ∧ code e138232686106 = 2337255941658 := by decide
theorem cert_e138232686106 : check e138232686106 [[.under]] .three = true := by decide
def e138234226202 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138234226202 : Closed e138234226202 ∧ code e138234226202 = 2337257481754 := by decide
theorem cert_e138234226202 : check e138234226202 [[.under]] .three = true := by decide
def e138234275354 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138234275354 : Closed e138234275354 ∧ code e138234275354 = 2337257530906 := by decide
theorem cert_e138234275354 : check e138234275354 [[.under]] .three = true := by decide
def e138235045402 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138235045402 : Closed e138235045402 ∧ code e138235045402 = 2337258300954 := by decide
theorem cert_e138235045402 : check e138235045402 [[.under]] .three = true := by decide
def e138235061786 : Term := (.lam (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138235061786 : Closed e138235061786 ∧ code e138235061786 = 2337258317338 := by decide
theorem cert_e138235061786 : check e138235061786 [[.under]] .three = true := by decide
def e138293470746 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138293470746 : Closed e138293470746 ∧ code e138293470746 = 2337316726298 := by decide
theorem cert_e138293470746 : check e138293470746 [[.under]] .three = true := by decide
def e138293995034 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138293995034 : Closed e138293995034 ∧ code e138293995034 = 2337317250586 := by decide
theorem cert_e138293995034 : check e138293995034 [[.under]] .three = true := by decide
def e138294027802 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138294027802 : Closed e138294027802 ∧ code e138294027802 = 2337317283354 := by decide
theorem cert_e138294027802 : check e138294027802 [[.under]] .three = true := by decide
def e138305005082 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138305005082 : Closed e138305005082 ∧ code e138305005082 = 2337328260634 := by decide
theorem cert_e138305005082 : check e138305005082 [[.under]] .three = true := by decide
def e138308150810 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138308150810 : Closed e138308150810 ∧ code e138308150810 = 2337331406362 := by decide
theorem cert_e138308150810 : check e138308150810 [[.under]] .three = true := by decide
def e138308183578 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138308183578 : Closed e138308183578 ∧ code e138308183578 = 2337331439130 := by decide
theorem cert_e138308183578 : check e138308183578 [[.under]] .three = true := by decide
def e138402522650 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138402522650 : Closed e138402522650 ∧ code e138402522650 = 2337425778202 := by decide
theorem cert_e138402522650 : check e138402522650 [[.under]] .three = true := by decide
def e138403309082 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138403309082 : Closed e138403309082 ∧ code e138403309082 = 2337426564634 := by decide
theorem cert_e138403309082 : check e138403309082 [[.under]] .three = true := by decide
def e138403358234 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138403358234 : Closed e138403358234 ∧ code e138403358234 = 2337426613786 := by decide
theorem cert_e138403358234 : check e138403358234 [[.under]] .three = true := by decide
def e138405668378 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138405668378 : Closed e138405668378 ∧ code e138405668378 = 2337428923930 := by decide
theorem cert_e138405668378 : check e138405668378 [[.under]] .three = true := by decide
def e138410386970 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138410386970 : Closed e138410386970 ∧ code e138410386970 = 2337433642522 := by decide
theorem cert_e138410386970 : check e138410386970 [[.under]] .three = true := by decide
def e138410436122 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138410436122 : Closed e138410436122 ∧ code e138410436122 = 2337433691674 := by decide
theorem cert_e138410436122 : check e138410436122 [[.under]] .three = true := by decide
def e138457572890 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138457572890 : Closed e138457572890 ∧ code e138457572890 = 2337480828442 := by decide
theorem cert_e138457572890 : check e138457572890 [[.under]] .three = true := by decide
def e138457605658 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138457605658 : Closed e138457605658 ∧ code e138457605658 = 2337480861210 := by decide
theorem cert_e138457605658 : check e138457605658 [[.under]] .three = true := by decide
def e138457835034 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138457835034 : Closed e138457835034 ∧ code e138457835034 = 2337481090586 := by decide
theorem cert_e138457835034 : check e138457835034 [[.under]] .three = true := by decide
def e138457884186 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138457884186 : Closed e138457884186 ∧ code e138457884186 = 2337481139738 := by decide
theorem cert_e138457884186 : check e138457884186 [[.under]] .three = true := by decide
def e138457998874 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138457998874 : Closed e138457998874 ∧ code e138457998874 = 2337481254426 := by decide
theorem cert_e138457998874 : check e138457998874 [[.under]] .three = true := by decide
def e138458015258 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138458015258 : Closed e138458015258 ∧ code e138458015258 = 2337481270810 := by decide
theorem cert_e138458015258 : check e138458015258 [[.under]] .three = true := by decide
def e138459145754 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138459145754 : Closed e138459145754 ∧ code e138459145754 = 2337482401306 := by decide
theorem cert_e138459145754 : check e138459145754 [[.under]] .three = true := by decide
def e138459178522 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138459178522 : Closed e138459178522 ∧ code e138459178522 = 2337482434074 := by decide
theorem cert_e138459178522 : check e138459178522 [[.under]] .three = true := by decide
def e138460718618 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138460718618 : Closed e138460718618 ∧ code e138460718618 = 2337483974170 := by decide
theorem cert_e138460718618 : check e138460718618 [[.under]] .three = true := by decide
def e138460767770 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138460767770 : Closed e138460767770 ∧ code e138460767770 = 2337484023322 := by decide
theorem cert_e138460767770 : check e138460767770 [[.under]] .three = true := by decide
def e138461537818 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138461537818 : Closed e138461537818 ∧ code e138461537818 = 2337484793370 := by decide
theorem cert_e138461537818 : check e138461537818 [[.under]] .three = true := by decide
def e138461554202 : Term := (.lam (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e138461554202 : Closed e138461554202 ∧ code e138461554202 = 2337484809754 := by decide
theorem cert_e138461554202 : check e138461554202 [[.under]] .three = true := by decide
def e141221020374 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e141221020374 : Closed e141221020374 ∧ code e141221020374 = 2340244275926 := by decide
theorem cert_e141221020374 : check e141221020374 [[.under]] .width = true := by decide
def e141221020378 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e141221020378 : Closed e141221020378 ∧ code e141221020378 = 2340244275930 := by decide
theorem cert_e141221020378 : check e141221020378 [[.under]] .width = true := by decide
def e141221020394 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e141221020394 : Closed e141221020394 ∧ code e141221020394 = 2340244275946 := by decide
theorem cert_e141221020394 : check e141221020394 [[.under]] .width = true := by decide
def e141221020470 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e141221020470 : Closed e141221020470 ∧ code e141221020470 = 2340244276022 := by decide
theorem cert_e141221020470 : check e141221020470 [[.under]] .width = true := by decide
def e141221020474 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e141221020474 : Closed e141221020474 ∧ code e141221020474 = 2340244276026 := by decide
theorem cert_e141221020474 : check e141221020474 [[.under]] .width = true := by decide
def e141221020570 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e141221020570 : Closed e141221020570 ∧ code e141221020570 = 2340244276122 := by decide
theorem cert_e141221020570 : check e141221020570 [[.under]] .width = true := by decide
def e141221085910 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e141221085910 : Closed e141221085910 ∧ code e141221085910 = 2340244341462 := by decide
private def t_e141221085910 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem cert_e141221085910 : ¬ IsSelfInterpreter e141221085910 :=
  wSource (t := t_e141221085910) (replay_sound (ps := []) (t := e141221085910) (by decide)) (by decide)
def e141221085914 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e141221085914 : Closed e141221085914 ∧ code e141221085914 = 2340244341466 := by decide
theorem cert_e141221085914 : check e141221085914 [[.under]] .width = true := by decide
def e141221085930 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e141221085930 : Closed e141221085930 ∧ code e141221085930 = 2340244341482 := by decide
theorem cert_e141221085930 : check e141221085930 [[.under]] .width = true := by decide
def e141221086006 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e141221086006 : Closed e141221086006 ∧ code e141221086006 = 2340244341558 := by decide
theorem cert_e141221086006 : check e141221086006 [[.under]] .width = true := by decide
def e141221086010 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e141221086010 : Closed e141221086010 ∧ code e141221086010 = 2340244341562 := by decide
theorem cert_e141221086010 : check e141221086010 [[.under]] .width = true := by decide
def e141221086106 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e141221086106 : Closed e141221086106 ∧ code e141221086106 = 2340244341658 := by decide
theorem cert_e141221086106 : check e141221086106 [[.under]] .width = true := by decide
def e141221544662 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e141221544662 : Closed e141221544662 ∧ code e141221544662 = 2340244800214 := by decide
theorem cert_e141221544662 : check e141221544662 [[.under]] .width = true := by decide
def e141221544666 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e141221544666 : Closed e141221544666 ∧ code e141221544666 = 2340244800218 := by decide
theorem cert_e141221544666 : check e141221544666 [[.under]] .width = true := by decide
def e141221544682 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e141221544682 : Closed e141221544682 ∧ code e141221544682 = 2340244800234 := by decide
theorem cert_e141221544682 : check e141221544682 [[.under]] .width = true := by decide
def e141221544758 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e141221544758 : Closed e141221544758 ∧ code e141221544758 = 2340244800310 := by decide
theorem cert_e141221544758 : check e141221544758 [[.under]] .width = true := by decide
def e141221544762 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e141221544762 : Closed e141221544762 ∧ code e141221544762 = 2340244800314 := by decide
theorem cert_e141221544762 : check e141221544762 [[.under]] .width = true := by decide
def e141221544858 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e141221544858 : Closed e141221544858 ∧ code e141221544858 = 2340244800410 := by decide
theorem cert_e141221544858 : check e141221544858 [[.under]] .width = true := by decide
def e141221642966 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e141221642966 : Closed e141221642966 ∧ code e141221642966 = 2340244898518 := by decide
theorem cert_e141221642966 : check e141221642966 [[.under]] .width = true := by decide
def e141221642970 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e141221642970 : Closed e141221642970 ∧ code e141221642970 = 2340244898522 := by decide
theorem cert_e141221642970 : check e141221642970 [[.under]] .width = true := by decide
def e141221642986 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e141221642986 : Closed e141221642986 ∧ code e141221642986 = 2340244898538 := by decide
theorem cert_e141221642986 : check e141221642986 [[.under]] .width = true := by decide
def e141221643062 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e141221643062 : Closed e141221643062 ∧ code e141221643062 = 2340244898614 := by decide
theorem cert_e141221643062 : check e141221643062 [[.under]] .width = true := by decide
def e141221643066 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e141221643066 : Closed e141221643066 ∧ code e141221643066 = 2340244898618 := by decide
theorem cert_e141221643066 : check e141221643066 [[.under]] .width = true := by decide
def e141221643162 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e141221643162 : Closed e141221643162 ∧ code e141221643162 = 2340244898714 := by decide
theorem cert_e141221643162 : check e141221643162 [[.under]] .width = true := by decide
def e141221872342 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e141221872342 : Closed e141221872342 ∧ code e141221872342 = 2340245127894 := by decide
private def t_e141221872342 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem cert_e141221872342 : ¬ IsSelfInterpreter e141221872342 :=
  wSource (t := t_e141221872342) (replay_sound (ps := []) (t := e141221872342) (by decide)) (by decide)
def e141221872346 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e141221872346 : Closed e141221872346 ∧ code e141221872346 = 2340245127898 := by decide
theorem cert_e141221872346 : check e141221872346 [[.under]] .width = true := by decide
def e141221872362 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e141221872362 : Closed e141221872362 ∧ code e141221872362 = 2340245127914 := by decide
theorem cert_e141221872362 : check e141221872362 [[.under]] .width = true := by decide
def e141221872438 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e141221872438 : Closed e141221872438 ∧ code e141221872438 = 2340245127990 := by decide
theorem cert_e141221872438 : check e141221872438 [[.under]] .width = true := by decide
def e141221872442 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e141221872442 : Closed e141221872442 ∧ code e141221872442 = 2340245127994 := by decide
theorem cert_e141221872442 : check e141221872442 [[.under]] .width = true := by decide
def e141221872538 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e141221872538 : Closed e141221872538 ∧ code e141221872538 = 2340245128090 := by decide
theorem cert_e141221872538 : check e141221872538 [[.under]] .width = true := by decide
def e141221905110 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e141221905110 : Closed e141221905110 ∧ code e141221905110 = 2340245160662 := by decide
theorem cert_e141221905110 : check e141221905110 [[.under]] .width = true := by decide
def e141221905114 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e141221905114 : Closed e141221905114 ∧ code e141221905114 = 2340245160666 := by decide
theorem cert_e141221905114 : check e141221905114 [[.under]] .width = true := by decide
def e141221905130 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e141221905130 : Closed e141221905130 ∧ code e141221905130 = 2340245160682 := by decide
theorem cert_e141221905130 : check e141221905130 [[.under]] .width = true := by decide
def e141221905206 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e141221905206 : Closed e141221905206 ∧ code e141221905206 = 2340245160758 := by decide
theorem cert_e141221905206 : check e141221905206 [[.under]] .width = true := by decide
def e141221905210 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e141221905210 : Closed e141221905210 ∧ code e141221905210 = 2340245160762 := by decide
theorem cert_e141221905210 : check e141221905210 [[.under]] .width = true := by decide
def e141221905306 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e141221905306 : Closed e141221905306 ∧ code e141221905306 = 2340245160858 := by decide
theorem cert_e141221905306 : check e141221905306 [[.under]] .width = true := by decide
def e141224166102 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e141224166102 : Closed e141224166102 ∧ code e141224166102 = 2340247421654 := by decide
theorem cert_e141224166102 : check e141224166102 [[.under]] .width = true := by decide
def e141224166106 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e141224166106 : Closed e141224166106 ∧ code e141224166106 = 2340247421658 := by decide
theorem cert_e141224166106 : check e141224166106 [[.under]] .width = true := by decide
def e141224166122 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e141224166122 : Closed e141224166122 ∧ code e141224166122 = 2340247421674 := by decide
theorem cert_e141224166122 : check e141224166122 [[.under]] .width = true := by decide
def e141224166198 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e141224166198 : Closed e141224166198 ∧ code e141224166198 = 2340247421750 := by decide
theorem cert_e141224166198 : check e141224166198 [[.under]] .width = true := by decide
def e141224166202 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e141224166202 : Closed e141224166202 ∧ code e141224166202 = 2340247421754 := by decide
theorem cert_e141224166202 : check e141224166202 [[.under]] .width = true := by decide
def e141224166298 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e141224166298 : Closed e141224166298 ∧ code e141224166298 = 2340247421850 := by decide
theorem cert_e141224166298 : check e141224166298 [[.under]] .width = true := by decide
def e141224231638 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e141224231638 : Closed e141224231638 ∧ code e141224231638 = 2340247487190 := by decide
theorem cert_e141224231638 : check e141224231638 [[.under]] .width = true := by decide
def e141224231642 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e141224231642 : Closed e141224231642 ∧ code e141224231642 = 2340247487194 := by decide
theorem cert_e141224231642 : check e141224231642 [[.under]] .width = true := by decide
def e141224231658 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e141224231658 : Closed e141224231658 ∧ code e141224231658 = 2340247487210 := by decide
theorem cert_e141224231658 : check e141224231658 [[.under]] .width = true := by decide
def e141224231734 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e141224231734 : Closed e141224231734 ∧ code e141224231734 = 2340247487286 := by decide
theorem cert_e141224231734 : check e141224231734 [[.under]] .width = true := by decide
def e141224231738 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e141224231738 : Closed e141224231738 ∧ code e141224231738 = 2340247487290 := by decide
theorem cert_e141224231738 : check e141224231738 [[.under]] .width = true := by decide
def e141224231834 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e141224231834 : Closed e141224231834 ∧ code e141224231834 = 2340247487386 := by decide
theorem cert_e141224231834 : check e141224231834 [[.under]] .width = true := by decide
def e141227311830 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e141227311830 : Closed e141227311830 ∧ code e141227311830 = 2340250567382 := by decide
theorem cert_e141227311830 : check e141227311830 [[.under]] .width = true := by decide
def e141227311834 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e141227311834 : Closed e141227311834 ∧ code e141227311834 = 2340250567386 := by decide
theorem cert_e141227311834 : check e141227311834 [[.under]] .width = true := by decide
def e141227311850 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e141227311850 : Closed e141227311850 ∧ code e141227311850 = 2340250567402 := by decide
theorem cert_e141227311850 : check e141227311850 [[.under]] .width = true := by decide
def e141227311926 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e141227311926 : Closed e141227311926 ∧ code e141227311926 = 2340250567478 := by decide
theorem cert_e141227311926 : check e141227311926 [[.under]] .width = true := by decide
def e141227311930 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e141227311930 : Closed e141227311930 ∧ code e141227311930 = 2340250567482 := by decide
theorem cert_e141227311930 : check e141227311930 [[.under]] .width = true := by decide
def e141227312026 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e141227312026 : Closed e141227312026 ∧ code e141227312026 = 2340250567578 := by decide
theorem cert_e141227312026 : check e141227312026 [[.under]] .width = true := by decide
def e141227410134 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e141227410134 : Closed e141227410134 ∧ code e141227410134 = 2340250665686 := by decide
theorem cert_e141227410134 : check e141227410134 [[.under]] .width = true := by decide
def e141227410138 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e141227410138 : Closed e141227410138 ∧ code e141227410138 = 2340250665690 := by decide
theorem cert_e141227410138 : check e141227410138 [[.under]] .width = true := by decide
def e141227410154 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e141227410154 : Closed e141227410154 ∧ code e141227410154 = 2340250665706 := by decide
theorem cert_e141227410154 : check e141227410154 [[.under]] .width = true := by decide
def e141227410230 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e141227410230 : Closed e141227410230 ∧ code e141227410230 = 2340250665782 := by decide
theorem cert_e141227410230 : check e141227410230 [[.under]] .width = true := by decide
def e141227410234 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e141227410234 : Closed e141227410234 ∧ code e141227410234 = 2340250665786 := by decide
theorem cert_e141227410234 : check e141227410234 [[.under]] .width = true := by decide
def e141227410330 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e141227410330 : Closed e141227410330 ∧ code e141227410330 = 2340250665882 := by decide
theorem cert_e141227410330 : check e141227410330 [[.under]] .width = true := by decide
def e141228950230 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e141228950230 : Closed e141228950230 ∧ code e141228950230 = 2340252205782 := by decide
theorem cert_e141228950230 : check e141228950230 [[.under]] .width = true := by decide
def e141228950234 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e141228950234 : Closed e141228950234 ∧ code e141228950234 = 2340252205786 := by decide
theorem cert_e141228950234 : check e141228950234 [[.under]] .width = true := by decide
def e141228950250 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e141228950250 : Closed e141228950250 ∧ code e141228950250 = 2340252205802 := by decide
theorem cert_e141228950250 : check e141228950250 [[.under]] .width = true := by decide
def e141228950326 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e141228950326 : Closed e141228950326 ∧ code e141228950326 = 2340252205878 := by decide
theorem cert_e141228950326 : check e141228950326 [[.under]] .width = true := by decide
def e141228950330 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e141228950330 : Closed e141228950330 ∧ code e141228950330 = 2340252205882 := by decide
theorem cert_e141228950330 : check e141228950330 [[.under]] .width = true := by decide
def e141228950426 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e141228950426 : Closed e141228950426 ∧ code e141228950426 = 2340252205978 := by decide
theorem cert_e141228950426 : check e141228950426 [[.under]] .width = true := by decide
def e141228982998 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e141228982998 : Closed e141228982998 ∧ code e141228982998 = 2340252238550 := by decide
theorem cert_e141228982998 : check e141228982998 [[.under]] .width = true := by decide
def e141228983002 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e141228983002 : Closed e141228983002 ∧ code e141228983002 = 2340252238554 := by decide
theorem cert_e141228983002 : check e141228983002 [[.under]] .width = true := by decide
def e141228983018 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e141228983018 : Closed e141228983018 ∧ code e141228983018 = 2340252238570 := by decide
theorem cert_e141228983018 : check e141228983018 [[.under]] .width = true := by decide
def e141228983094 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e141228983094 : Closed e141228983094 ∧ code e141228983094 = 2340252238646 := by decide
theorem cert_e141228983094 : check e141228983094 [[.under]] .width = true := by decide
def e141228983098 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e141228983098 : Closed e141228983098 ∧ code e141228983098 = 2340252238650 := by decide
theorem cert_e141228983098 : check e141228983098 [[.under]] .width = true := by decide
def e141228983194 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e141228983194 : Closed e141228983194 ∧ code e141228983194 = 2340252238746 := by decide
theorem cert_e141228983194 : check e141228983194 [[.under]] .width = true := by decide
def e149619301230 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e149619301230 : Closed e149619301230 ∧ code e149619301230 = 2348642556782 := by decide
theorem cert_e149619301230 : check e149619301230 [[.under],[.under,.left]] .chain = true := by decide
def e149619301238 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e149619301238 : Closed e149619301238 ∧ code e149619301238 = 2348642556790 := by decide
theorem cert_e149619301238 : check e149619301238 [[.under],[.under,.left]] .chain = true := by decide
def e149619301302 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e149619301302 : Closed e149619301302 ∧ code e149619301302 = 2348642556854 := by decide
theorem cert_e149619301302 : check e149619301302 [[.under],[.under,.left]] .chain = true := by decide
def e149619301742 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e149619301742 : Closed e149619301742 ∧ code e149619301742 = 2348642557294 := by decide
theorem cert_e149619301742 : check e149619301742 [[.under],[.under,.left]] .chain = true := by decide
def e149619301750 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e149619301750 : Closed e149619301750 ∧ code e149619301750 = 2348642557302 := by decide
theorem cert_e149619301750 : check e149619301750 [[.under],[.under,.left]] .chain = true := by decide
def e149619301806 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e149619301806 : Closed e149619301806 ∧ code e149619301806 = 2348642557358 := by decide
theorem cert_e149619301806 : check e149619301806 [[.under],[.under,.left]] .chain = true := by decide
def e149619301818 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e149619301818 : Closed e149619301818 ∧ code e149619301818 = 2348642557370 := by decide
theorem cert_e149619301818 : check e149619301818 [[.under],[.under,.left]] .chain = true := by decide
def e149619301846 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e149619301846 : Closed e149619301846 ∧ code e149619301846 = 2348642557398 := by decide
theorem cert_e149619301846 : check e149619301846 [[.under],[.under,.left]] .chain = true := by decide
def e149619301850 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e149619301850 : Closed e149619301850 ∧ code e149619301850 = 2348642557402 := by decide
theorem cert_e149619301850 : check e149619301850 [[.under],[.under,.left]] .chain = true := by decide
def e149619302070 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e149619302070 : Closed e149619302070 ∧ code e149619302070 = 2348642557622 := by decide
theorem cert_e149619302070 : check e149619302070 [[.under],[.under,.left]] .chain = true := by decide
def e149619302102 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e149619302102 : Closed e149619302102 ∧ code e149619302102 = 2348642557654 := by decide
theorem cert_e149619302102 : check e149619302102 [[.under],[.under,.left]] .chain = true := by decide
def e149619302106 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e149619302106 : Closed e149619302106 ∧ code e149619302106 = 2348642557658 := by decide
theorem cert_e149619302106 : check e149619302106 [[.under],[.under,.left]] .chain = true := by decide
def e149619304302 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e149619304302 : Closed e149619304302 ∧ code e149619304302 = 2348642559854 := by decide
theorem cert_e149619304302 : check e149619304302 [[.under],[.under,.left]] .chain = true := by decide
def e149619304310 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e149619304310 : Closed e149619304310 ∧ code e149619304310 = 2348642559862 := by decide
theorem cert_e149619304310 : check e149619304310 [[.under],[.under,.left]] .chain = true := by decide
def e149619304374 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e149619304374 : Closed e149619304374 ∧ code e149619304374 = 2348642559926 := by decide
theorem cert_e149619304374 : check e149619304374 [[.under],[.under,.left]] .chain = true := by decide
def e149619305710 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e149619305710 : Closed e149619305710 ∧ code e149619305710 = 2348642561262 := by decide
theorem cert_e149619305710 : check e149619305710 [[.under],[.under,.left]] .chain = true := by decide
def e149619305718 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e149619305718 : Closed e149619305718 ∧ code e149619305718 = 2348642561270 := by decide
theorem cert_e149619305718 : check e149619305718 [[.under],[.under,.left]] .chain = true := by decide
def e149619306102 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e149619306102 : Closed e149619306102 ∧ code e149619306102 = 2348642561654 := by decide
theorem cert_e149619306102 : check e149619306102 [[.under],[.under,.left]] .chain = true := by decide
def e149619307374 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e149619307374 : Closed e149619307374 ∧ code e149619307374 = 2348642562926 := by decide
theorem cert_e149619307374 : check e149619307374 [[.under],[.under,.left]] .chain = true := by decide
def e149619307382 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e149619307382 : Closed e149619307382 ∧ code e149619307382 = 2348642562934 := by decide
theorem cert_e149619307382 : check e149619307382 [[.under],[.under,.left]] .chain = true := by decide
def e149619307438 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e149619307438 : Closed e149619307438 ∧ code e149619307438 = 2348642562990 := by decide
theorem cert_e149619307438 : check e149619307438 [[.under],[.under,.left]] .chain = true := by decide
def e149619307450 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e149619307450 : Closed e149619307450 ∧ code e149619307450 = 2348642563002 := by decide
theorem cert_e149619307450 : check e149619307450 [[.under],[.under,.left]] .chain = true := by decide
def e149619307478 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e149619307478 : Closed e149619307478 ∧ code e149619307478 = 2348642563030 := by decide
theorem cert_e149619307478 : check e149619307478 [[.under],[.under,.left]] .chain = true := by decide
def e149619307482 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e149619307482 : Closed e149619307482 ∧ code e149619307482 = 2348642563034 := by decide
theorem cert_e149619307482 : check e149619307482 [[.under],[.under,.left]] .chain = true := by decide
def e149619307758 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e149619307758 : Closed e149619307758 ∧ code e149619307758 = 2348642563310 := by decide
theorem cert_e149619307758 : check e149619307758 [[.under],[.under,.left]] .chain = true := by decide
def e149619307766 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e149619307766 : Closed e149619307766 ∧ code e149619307766 = 2348642563318 := by decide
theorem cert_e149619307766 : check e149619307766 [[.under],[.under,.left]] .chain = true := by decide
def e149619308142 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e149619308142 : Closed e149619308142 ∧ code e149619308142 = 2348642563694 := by decide
theorem cert_e149619308142 : check e149619308142 [[.under],[.under,.left]] .chain = true := by decide
def e149619308154 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e149619308154 : Closed e149619308154 ∧ code e149619308154 = 2348642563706 := by decide
theorem cert_e149619308154 : check e149619308154 [[.under],[.under,.left]] .chain = true := by decide
end Blc.Floor41
