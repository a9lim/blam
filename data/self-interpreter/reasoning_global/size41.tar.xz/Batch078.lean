import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605592702190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605592702190 : Closed e605592702190 ∧ code e605592702190 = 2804615957742 := by decide
theorem cert_e605592702190 : check e605592702190 [[],[]] .smaller = true := by decide
def e605592702198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605592702198 : Closed e605592702198 ∧ code e605592702198 = 2804615957750 := by decide
theorem cert_e605592702198 : check e605592702198 [[],[]] .smaller = true := by decide
def e605592702574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605592702574 : Closed e605592702574 ∧ code e605592702574 = 2804615958126 := by decide
theorem cert_e605592702574 : check e605592702574 [[],[]] .smaller = true := by decide
def e605592702586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605592702586 : Closed e605592702586 ∧ code e605592702586 = 2804615958138 := by decide
theorem cert_e605592702586 : check e605592702586 [[],[]] .smaller = true := by decide
def e605592702774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605592702774 : Closed e605592702774 ∧ code e605592702774 = 2804615958326 := by decide
theorem cert_e605592702774 : check e605592702774 [[],[]] .smaller = true := by decide
def e605592702778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605592702778 : Closed e605592702778 ∧ code e605592702778 = 2804615958330 := by decide
theorem cert_e605592702778 : check e605592702778 [[],[]] .smaller = true := by decide
def e605593064310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605593064310 : Closed e605593064310 ∧ code e605593064310 = 2804616319862 := by decide
theorem cert_e605593064310 : check e605593064310 [[],[]] .smaller = true := by decide
def e605593064378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605593064378 : Closed e605593064378 ∧ code e605593064378 = 2804616319930 := by decide
theorem cert_e605593064378 : check e605593064378 [[],[]] .smaller = true := by decide
def e605593064406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605593064406 : Closed e605593064406 ∧ code e605593064406 = 2804616319958 := by decide
theorem cert_e605593064406 : check e605593064406 [[],[]] .smaller = true := by decide
def e605593064410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605593064410 : Closed e605593064410 ∧ code e605593064410 = 2804616319962 := by decide
theorem cert_e605593064410 : check e605593064410 [[],[]] .smaller = true := by decide
def e605593191790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605593191790 : Closed e605593191790 ∧ code e605593191790 = 2804616447342 := by decide
theorem cert_e605593191790 : check e605593191790 [[],[]] .smaller = true := by decide
def e605593191798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605593191798 : Closed e605593191798 ∧ code e605593191798 = 2804616447350 := by decide
theorem cert_e605593191798 : check e605593191798 [[],[]] .smaller = true := by decide
def e605593191854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605593191854 : Closed e605593191854 ∧ code e605593191854 = 2804616447406 := by decide
theorem cert_e605593191854 : check e605593191854 [[],[]] .smaller = true := by decide
def e605593191866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605593191866 : Closed e605593191866 ∧ code e605593191866 = 2804616447418 := by decide
theorem cert_e605593191866 : check e605593191866 [[],[]] .smaller = true := by decide
def e605593191894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605593191894 : Closed e605593191894 ∧ code e605593191894 = 2804616447446 := by decide
theorem cert_e605593191894 : check e605593191894 [[],[]] .smaller = true := by decide
def e605593191898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605593191898 : Closed e605593191898 ∧ code e605593191898 = 2804616447450 := by decide
theorem cert_e605593191898 : check e605593191898 [[],[]] .smaller = true := by decide
def e605593194862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e605593194862 : Closed e605593194862 ∧ code e605593194862 = 2804616450414 := by decide
theorem cert_e605593194862 : check e605593194862 [[],[]] .smaller = true := by decide
def e605593194870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e605593194870 : Closed e605593194870 ∧ code e605593194870 = 2804616450422 := by decide
theorem cert_e605593194870 : check e605593194870 [[],[]] .smaller = true := by decide
def e605593195998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e605593195998 : Closed e605593195998 ∧ code e605593195998 = 2804616451550 := by decide
theorem cert_e605593195998 : check e605593195998 [[],[]] .three = true := by decide
def e605593196014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e605593196014 : Closed e605593196014 ∧ code e605593196014 = 2804616451566 := by decide
theorem cert_e605593196014 : check e605593196014 [[],[]] .three = true := by decide
def e605593196078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605593196078 : Closed e605593196078 ∧ code e605593196078 = 2804616451630 := by decide
theorem cert_e605593196078 : check e605593196078 [[],[]] .smaller = true := by decide
def e605593196254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e605593196254 : Closed e605593196254 ∧ code e605593196254 = 2804616451806 := by decide
theorem cert_e605593196254 : check e605593196254 [[],[]] .three = true := by decide
def e605593196258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605593196258 : Closed e605593196258 ∧ code e605593196258 = 2804616451810 := by decide
theorem cert_e605593196258 : check e605593196258 [[],[]] .smaller = true := by decide
def e605593196270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e605593196270 : Closed e605593196270 ∧ code e605593196270 = 2804616451822 := by decide
theorem cert_e605593196270 : check e605593196270 [[],[]] .smaller = true := by decide
def e605593196278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e605593196278 : Closed e605593196278 ∧ code e605593196278 = 2804616451830 := by decide
theorem cert_e605593196278 : check e605593196278 [[],[]] .three = true := by decide
def e605593196310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e605593196310 : Closed e605593196310 ∧ code e605593196310 = 2804616451862 := by decide
theorem cert_e605593196310 : check e605593196310 [[],[]] .smaller = true := by decide
def e605593196382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e605593196382 : Closed e605593196382 ∧ code e605593196382 = 2804616451934 := by decide
theorem cert_e605593196382 : check e605593196382 [[],[]] .three = true := by decide
def e605593196386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e605593196386 : Closed e605593196386 ∧ code e605593196386 = 2804616451938 := by decide
theorem cert_e605593196386 : check e605593196386 [[],[]] .smaller = true := by decide
def e605593196398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e605593196398 : Closed e605593196398 ∧ code e605593196398 = 2804616451950 := by decide
theorem cert_e605593196398 : check e605593196398 [[],[]] .smaller = true := by decide
def e605593196406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e605593196406 : Closed e605593196406 ∧ code e605593196406 = 2804616451958 := by decide
theorem cert_e605593196406 : check e605593196406 [[],[]] .smaller = true := by decide
def e605593196410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e605593196410 : Closed e605593196410 ∧ code e605593196410 = 2804616451962 := by decide
theorem cert_e605593196410 : check e605593196410 [[],[]] .three = true := by decide
def e605593196462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e605593196462 : Closed e605593196462 ∧ code e605593196462 = 2804616452014 := by decide
theorem cert_e605593196462 : check e605593196462 [[],[]] .three = true := by decide
def e605593196470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e605593196470 : Closed e605593196470 ∧ code e605593196470 = 2804616452022 := by decide
theorem cert_e605593196470 : check e605593196470 [[],[]] .three = true := by decide
def e605593196474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e605593196474 : Closed e605593196474 ∧ code e605593196474 = 2804616452026 := by decide
theorem cert_e605593196474 : check e605593196474 [[],[]] .three = true := by decide
def e605593196718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605593196718 : Closed e605593196718 ∧ code e605593196718 = 2804616452270 := by decide
theorem cert_e605593196718 : check e605593196718 [[],[]] .smaller = true := by decide
def e605593196730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605593196730 : Closed e605593196730 ∧ code e605593196730 = 2804616452282 := by decide
theorem cert_e605593196730 : check e605593196730 [[],[]] .smaller = true := by decide
def e605593197102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605593197102 : Closed e605593197102 ∧ code e605593197102 = 2804616452654 := by decide
theorem cert_e605593197102 : check e605593197102 [[],[]] .smaller = true := by decide
def e605593197278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e605593197278 : Closed e605593197278 ∧ code e605593197278 = 2804616452830 := by decide
theorem cert_e605593197278 : check e605593197278 [[],[]] .three = true := by decide
def e605593197282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605593197282 : Closed e605593197282 ∧ code e605593197282 = 2804616452834 := by decide
theorem cert_e605593197282 : check e605593197282 [[],[]] .smaller = true := by decide
def e605593197294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e605593197294 : Closed e605593197294 ∧ code e605593197294 = 2804616452846 := by decide
theorem cert_e605593197294 : check e605593197294 [[],[]] .smaller = true := by decide
def e605593197302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e605593197302 : Closed e605593197302 ∧ code e605593197302 = 2804616452854 := by decide
theorem cert_e605593197302 : check e605593197302 [[],[]] .three = true := by decide
def e605593197406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e605593197406 : Closed e605593197406 ∧ code e605593197406 = 2804616452958 := by decide
theorem cert_e605593197406 : check e605593197406 [[],[]] .three = true := by decide
def e605593197422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e605593197422 : Closed e605593197422 ∧ code e605593197422 = 2804616452974 := by decide
theorem cert_e605593197422 : check e605593197422 [[],[]] .smaller = true := by decide
def e605593197430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e605593197430 : Closed e605593197430 ∧ code e605593197430 = 2804616452982 := by decide
theorem cert_e605593197430 : check e605593197430 [[],[]] .smaller = true := by decide
def e605593197434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e605593197434 : Closed e605593197434 ∧ code e605593197434 = 2804616452986 := by decide
theorem cert_e605593197434 : check e605593197434 [[],[]] .three = true := by decide
def e605593197450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605593197450 : Closed e605593197450 ∧ code e605593197450 = 2804616453002 := by decide
theorem cert_e605593197450 : check e605593197450 [[],[]] .smaller = true := by decide
def e605593197474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605593197474 : Closed e605593197474 ∧ code e605593197474 = 2804616453026 := by decide
theorem cert_e605593197474 : check e605593197474 [[],[]] .smaller = true := by decide
def e605593197486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e605593197486 : Closed e605593197486 ∧ code e605593197486 = 2804616453038 := by decide
theorem cert_e605593197486 : check e605593197486 [[],[]] .smaller = true := by decide
def e605593197494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e605593197494 : Closed e605593197494 ∧ code e605593197494 = 2804616453046 := by decide
theorem cert_e605593197494 : check e605593197494 [[],[]] .smaller = true := by decide
def e605593197498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e605593197498 : Closed e605593197498 ∧ code e605593197498 = 2804616453050 := by decide
theorem cert_e605593197498 : check e605593197498 [[],[]] .smaller = true := by decide
def e605593197526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e605593197526 : Closed e605593197526 ∧ code e605593197526 = 2804616453078 := by decide
theorem cert_e605593197526 : check e605593197526 [[],[]] .three = true := by decide
def e605593197530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e605593197530 : Closed e605593197530 ∧ code e605593197530 = 2804616453082 := by decide
theorem cert_e605593197530 : check e605593197530 [[],[]] .three = true := by decide
def e605593197654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e605593197654 : Closed e605593197654 ∧ code e605593197654 = 2804616453206 := by decide
theorem cert_e605593197654 : check e605593197654 [[],[]] .smaller = true := by decide
def e605593197658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e605593197658 : Closed e605593197658 ∧ code e605593197658 = 2804616453210 := by decide
theorem cert_e605593197658 : check e605593197658 [[],[]] .smaller = true := by decide
def e605593197846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e605593197846 : Closed e605593197846 ∧ code e605593197846 = 2804616453398 := by decide
theorem cert_e605593197846 : check e605593197846 [[],[]] .smaller = true := by decide
def e605593197918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e605593197918 : Closed e605593197918 ∧ code e605593197918 = 2804616453470 := by decide
theorem cert_e605593197918 : check e605593197918 [[],[]] .three = true := by decide
def e605593197922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e605593197922 : Closed e605593197922 ∧ code e605593197922 = 2804616453474 := by decide
theorem cert_e605593197922 : check e605593197922 [[],[]] .smaller = true := by decide
def e605593197934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605593197934 : Closed e605593197934 ∧ code e605593197934 = 2804616453486 := by decide
theorem cert_e605593197934 : check e605593197934 [[],[]] .smaller = true := by decide
def e605593197942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605593197942 : Closed e605593197942 ∧ code e605593197942 = 2804616453494 := by decide
theorem cert_e605593197942 : check e605593197942 [[],[]] .smaller = true := by decide
def e605593197946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e605593197946 : Closed e605593197946 ∧ code e605593197946 = 2804616453498 := by decide
theorem cert_e605593197946 : check e605593197946 [[],[]] .three = true := by decide
def e605593197962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605593197962 : Closed e605593197962 ∧ code e605593197962 = 2804616453514 := by decide
theorem cert_e605593197962 : check e605593197962 [[],[]] .smaller = true := by decide
def e605593197986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605593197986 : Closed e605593197986 ∧ code e605593197986 = 2804616453538 := by decide
theorem cert_e605593197986 : check e605593197986 [[],[]] .smaller = true := by decide
def e605593197998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605593197998 : Closed e605593197998 ∧ code e605593197998 = 2804616453550 := by decide
theorem cert_e605593197998 : check e605593197998 [[],[]] .smaller = true := by decide
def e605593198006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 1)))))))
theorem wire_e605593198006 : Closed e605593198006 ∧ code e605593198006 = 2804616453558 := by decide
theorem cert_e605593198006 : check e605593198006 [[],[]] .smaller = true := by decide
def e605593198010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605593198010 : Closed e605593198010 ∧ code e605593198010 = 2804616453562 := by decide
theorem cert_e605593198010 : check e605593198010 [[],[]] .smaller = true := by decide
def e605593198038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605593198038 : Closed e605593198038 ∧ code e605593198038 = 2804616453590 := by decide
theorem cert_e605593198038 : check e605593198038 [[],[]] .smaller = true := by decide
def e605593198042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605593198042 : Closed e605593198042 ∧ code e605593198042 = 2804616453594 := by decide
theorem cert_e605593198042 : check e605593198042 [[],[]] .smaller = true := by decide
def e605593198058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e605593198058 : Closed e605593198058 ∧ code e605593198058 = 2804616453610 := by decide
theorem cert_e605593198058 : check e605593198058 [[],[]] .three = true := by decide
def e605593198254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605593198254 : Closed e605593198254 ∧ code e605593198254 = 2804616453806 := by decide
theorem cert_e605593198254 : check e605593198254 [[],[]] .three = true := by decide
def e605593198262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e605593198262 : Closed e605593198262 ∧ code e605593198262 = 2804616453814 := by decide
theorem cert_e605593198262 : check e605593198262 [[],[]] .three = true := by decide
def e605593198266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605593198266 : Closed e605593198266 ∧ code e605593198266 = 2804616453818 := by decide
theorem cert_e605593198266 : check e605593198266 [[],[]] .three = true := by decide
def e605593198294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e605593198294 : Closed e605593198294 ∧ code e605593198294 = 2804616453846 := by decide
theorem cert_e605593198294 : check e605593198294 [[],[]] .three = true := by decide
def e605593198298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e605593198298 : Closed e605593198298 ∧ code e605593198298 = 2804616453850 := by decide
theorem cert_e605593198298 : check e605593198298 [[],[]] .three = true := by decide
def e605593198314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605593198314 : Closed e605593198314 ∧ code e605593198314 = 2804616453866 := by decide
theorem cert_e605593198314 : check e605593198314 [[],[]] .three = true := by decide
def e605593199278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605593199278 : Closed e605593199278 ∧ code e605593199278 = 2804616454830 := by decide
theorem cert_e605593199278 : check e605593199278 [[],[]] .smaller = true := by decide
def e605593199290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605593199290 : Closed e605593199290 ∧ code e605593199290 = 2804616454842 := by decide
theorem cert_e605593199290 : check e605593199290 [[],[]] .smaller = true := by decide
def e605593199338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605593199338 : Closed e605593199338 ∧ code e605593199338 = 2804616454890 := by decide
theorem cert_e605593199338 : check e605593199338 [[],[]] .smaller = true := by decide
def e605593200814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605593200814 : Closed e605593200814 ∧ code e605593200814 = 2804616456366 := by decide
theorem cert_e605593200814 : check e605593200814 [[],[]] .smaller = true := by decide
def e605593200826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605593200826 : Closed e605593200826 ∧ code e605593200826 = 2804616456378 := by decide
theorem cert_e605593200826 : check e605593200826 [[],[]] .smaller = true := by decide
def e605593201198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605593201198 : Closed e605593201198 ∧ code e605593201198 = 2804616456750 := by decide
theorem cert_e605593201198 : check e605593201198 [[],[]] .smaller = true := by decide
def e605593201374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e605593201374 : Closed e605593201374 ∧ code e605593201374 = 2804616456926 := by decide
theorem cert_e605593201374 : check e605593201374 [[],[]] .three = true := by decide
def e605593201378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605593201378 : Closed e605593201378 ∧ code e605593201378 = 2804616456930 := by decide
theorem cert_e605593201378 : check e605593201378 [[],[]] .smaller = true := by decide
def e605593201390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e605593201390 : Closed e605593201390 ∧ code e605593201390 = 2804616456942 := by decide
theorem cert_e605593201390 : check e605593201390 [[],[]] .smaller = true := by decide
def e605593201398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e605593201398 : Closed e605593201398 ∧ code e605593201398 = 2804616456950 := by decide
theorem cert_e605593201398 : check e605593201398 [[],[]] .three = true := by decide
def e605593201502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e605593201502 : Closed e605593201502 ∧ code e605593201502 = 2804616457054 := by decide
theorem cert_e605593201502 : check e605593201502 [[],[]] .three = true := by decide
def e605593201518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e605593201518 : Closed e605593201518 ∧ code e605593201518 = 2804616457070 := by decide
theorem cert_e605593201518 : check e605593201518 [[],[]] .smaller = true := by decide
def e605593201526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e605593201526 : Closed e605593201526 ∧ code e605593201526 = 2804616457078 := by decide
theorem cert_e605593201526 : check e605593201526 [[],[]] .smaller = true := by decide
def e605593201530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e605593201530 : Closed e605593201530 ∧ code e605593201530 = 2804616457082 := by decide
theorem cert_e605593201530 : check e605593201530 [[],[]] .three = true := by decide
def e605593201546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605593201546 : Closed e605593201546 ∧ code e605593201546 = 2804616457098 := by decide
theorem cert_e605593201546 : check e605593201546 [[],[]] .smaller = true := by decide
def e605593201570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605593201570 : Closed e605593201570 ∧ code e605593201570 = 2804616457122 := by decide
theorem cert_e605593201570 : check e605593201570 [[],[]] .smaller = true := by decide
def e605593201582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e605593201582 : Closed e605593201582 ∧ code e605593201582 = 2804616457134 := by decide
theorem cert_e605593201582 : check e605593201582 [[],[]] .smaller = true := by decide
def e605593201590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e605593201590 : Closed e605593201590 ∧ code e605593201590 = 2804616457142 := by decide
theorem cert_e605593201590 : check e605593201590 [[],[]] .smaller = true := by decide
def e605593201594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e605593201594 : Closed e605593201594 ∧ code e605593201594 = 2804616457146 := by decide
theorem cert_e605593201594 : check e605593201594 [[],[]] .smaller = true := by decide
def e605593201622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e605593201622 : Closed e605593201622 ∧ code e605593201622 = 2804616457174 := by decide
theorem cert_e605593201622 : check e605593201622 [[],[]] .three = true := by decide
def e605593201626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e605593201626 : Closed e605593201626 ∧ code e605593201626 = 2804616457178 := by decide
theorem cert_e605593201626 : check e605593201626 [[],[]] .three = true := by decide
def e605593202014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e605593202014 : Closed e605593202014 ∧ code e605593202014 = 2804616457566 := by decide
theorem cert_e605593202014 : check e605593202014 [[],[]] .three = true := by decide
def e605593202030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605593202030 : Closed e605593202030 ∧ code e605593202030 = 2804616457582 := by decide
theorem cert_e605593202030 : check e605593202030 [[],[]] .smaller = true := by decide
def e605593202038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605593202038 : Closed e605593202038 ∧ code e605593202038 = 2804616457590 := by decide
theorem cert_e605593202038 : check e605593202038 [[],[]] .smaller = true := by decide
def e605593202042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e605593202042 : Closed e605593202042 ∧ code e605593202042 = 2804616457594 := by decide
theorem cert_e605593202042 : check e605593202042 [[],[]] .three = true := by decide
def e605593202094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605593202094 : Closed e605593202094 ∧ code e605593202094 = 2804616457646 := by decide
theorem cert_e605593202094 : check e605593202094 [[],[]] .smaller = true := by decide
def e605593202106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605593202106 : Closed e605593202106 ∧ code e605593202106 = 2804616457658 := by decide
theorem cert_e605593202106 : check e605593202106 [[],[]] .smaller = true := by decide
def e605593202134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605593202134 : Closed e605593202134 ∧ code e605593202134 = 2804616457686 := by decide
theorem cert_e605593202134 : check e605593202134 [[],[]] .smaller = true := by decide
def e605593202138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605593202138 : Closed e605593202138 ∧ code e605593202138 = 2804616457690 := by decide
theorem cert_e605593202138 : check e605593202138 [[],[]] .smaller = true := by decide
def e605593202154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e605593202154 : Closed e605593202154 ∧ code e605593202154 = 2804616457706 := by decide
theorem cert_e605593202154 : check e605593202154 [[],[]] .three = true := by decide
def e605593202218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605593202218 : Closed e605593202218 ∧ code e605593202218 = 2804616457770 := by decide
theorem cert_e605593202218 : check e605593202218 [[],[]] .smaller = true := by decide
def e605593202314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605593202314 : Closed e605593202314 ∧ code e605593202314 = 2804616457866 := by decide
theorem cert_e605593202314 : check e605593202314 [[],[]] .smaller = true := by decide
def e605593202338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605593202338 : Closed e605593202338 ∧ code e605593202338 = 2804616457890 := by decide
theorem cert_e605593202338 : check e605593202338 [[],[]] .smaller = true := by decide
def e605593202350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605593202350 : Closed e605593202350 ∧ code e605593202350 = 2804616457902 := by decide
theorem cert_e605593202350 : check e605593202350 [[],[]] .smaller = true := by decide
def e605593202358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e605593202358 : Closed e605593202358 ∧ code e605593202358 = 2804616457910 := by decide
theorem cert_e605593202358 : check e605593202358 [[],[]] .smaller = true := by decide
def e605593202362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605593202362 : Closed e605593202362 ∧ code e605593202362 = 2804616457914 := by decide
theorem cert_e605593202362 : check e605593202362 [[],[]] .smaller = true := by decide
def e605593202390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e605593202390 : Closed e605593202390 ∧ code e605593202390 = 2804616457942 := by decide
theorem cert_e605593202390 : check e605593202390 [[],[]] .smaller = true := by decide
def e605593202394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e605593202394 : Closed e605593202394 ∧ code e605593202394 = 2804616457946 := by decide
theorem cert_e605593202394 : check e605593202394 [[],[]] .smaller = true := by decide
def e605593202410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605593202410 : Closed e605593202410 ∧ code e605593202410 = 2804616457962 := by decide
theorem cert_e605593202410 : check e605593202410 [[],[]] .smaller = true := by decide
def e605593202518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605593202518 : Closed e605593202518 ∧ code e605593202518 = 2804616458070 := by decide
theorem cert_e605593202518 : check e605593202518 [[],[]] .three = true := by decide
def e605593202522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605593202522 : Closed e605593202522 ∧ code e605593202522 = 2804616458074 := by decide
theorem cert_e605593202522 : check e605593202522 [[],[]] .three = true := by decide
def e605593202538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605593202538 : Closed e605593202538 ∧ code e605593202538 = 2804616458090 := by decide
theorem cert_e605593202538 : check e605593202538 [[],[]] .three = true := by decide
def e605593203030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605593203030 : Closed e605593203030 ∧ code e605593203030 = 2804616458582 := by decide
theorem cert_e605593203030 : check e605593203030 [[],[]] .smaller = true := by decide
def e605593203034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605593203034 : Closed e605593203034 ∧ code e605593203034 = 2804616458586 := by decide
theorem cert_e605593203034 : check e605593203034 [[],[]] .smaller = true := by decide
def e605593203050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605593203050 : Closed e605593203050 ∧ code e605593203050 = 2804616458602 := by decide
theorem cert_e605593203050 : check e605593203050 [[],[]] .smaller = true := by decide
def e605593203798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e605593203798 : Closed e605593203798 ∧ code e605593203798 = 2804616459350 := by decide
theorem cert_e605593203798 : check e605593203798 [[],[]] .smaller = true := by decide
def e605593203802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e605593203802 : Closed e605593203802 ∧ code e605593203802 = 2804616459354 := by decide
theorem cert_e605593203802 : check e605593203802 [[],[]] .smaller = true := by decide
def e605593203990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e605593203990 : Closed e605593203990 ∧ code e605593203990 = 2804616459542 := by decide
theorem cert_e605593203990 : check e605593203990 [[],[]] .smaller = true := by decide
def e605593204062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e605593204062 : Closed e605593204062 ∧ code e605593204062 = 2804616459614 := by decide
theorem cert_e605593204062 : check e605593204062 [[],[]] .three = true := by decide
def e605593204066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e605593204066 : Closed e605593204066 ∧ code e605593204066 = 2804616459618 := by decide
theorem cert_e605593204066 : check e605593204066 [[],[]] .smaller = true := by decide
def e605593204078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605593204078 : Closed e605593204078 ∧ code e605593204078 = 2804616459630 := by decide
theorem cert_e605593204078 : check e605593204078 [[],[]] .smaller = true := by decide
def e605593204086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605593204086 : Closed e605593204086 ∧ code e605593204086 = 2804616459638 := by decide
theorem cert_e605593204086 : check e605593204086 [[],[]] .smaller = true := by decide
def e605593204090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e605593204090 : Closed e605593204090 ∧ code e605593204090 = 2804616459642 := by decide
theorem cert_e605593204090 : check e605593204090 [[],[]] .three = true := by decide
def e605593204106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605593204106 : Closed e605593204106 ∧ code e605593204106 = 2804616459658 := by decide
theorem cert_e605593204106 : check e605593204106 [[],[]] .smaller = true := by decide
def e605593204130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605593204130 : Closed e605593204130 ∧ code e605593204130 = 2804616459682 := by decide
theorem cert_e605593204130 : check e605593204130 [[],[]] .smaller = true := by decide
def e605593204142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605593204142 : Closed e605593204142 ∧ code e605593204142 = 2804616459694 := by decide
theorem cert_e605593204142 : check e605593204142 [[],[]] .smaller = true := by decide
def e605593204150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 1)))))))
theorem wire_e605593204150 : Closed e605593204150 ∧ code e605593204150 = 2804616459702 := by decide
theorem cert_e605593204150 : check e605593204150 [[],[]] .smaller = true := by decide
def e605593204154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605593204154 : Closed e605593204154 ∧ code e605593204154 = 2804616459706 := by decide
theorem cert_e605593204154 : check e605593204154 [[],[]] .smaller = true := by decide
def e605593204182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605593204182 : Closed e605593204182 ∧ code e605593204182 = 2804616459734 := by decide
theorem cert_e605593204182 : check e605593204182 [[],[]] .smaller = true := by decide
def e605593204186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605593204186 : Closed e605593204186 ∧ code e605593204186 = 2804616459738 := by decide
theorem cert_e605593204186 : check e605593204186 [[],[]] .smaller = true := by decide
def e605593204202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e605593204202 : Closed e605593204202 ∧ code e605593204202 = 2804616459754 := by decide
theorem cert_e605593204202 : check e605593204202 [[],[]] .three = true := by decide
def e605593204266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605593204266 : Closed e605593204266 ∧ code e605593204266 = 2804616459818 := by decide
theorem cert_e605593204266 : check e605593204266 [[],[]] .smaller = true := by decide
def e605593204362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605593204362 : Closed e605593204362 ∧ code e605593204362 = 2804616459914 := by decide
theorem cert_e605593204362 : check e605593204362 [[],[]] .smaller = true := by decide
def e605593204386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605593204386 : Closed e605593204386 ∧ code e605593204386 = 2804616459938 := by decide
theorem cert_e605593204386 : check e605593204386 [[],[]] .smaller = true := by decide
def e605593204398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605593204398 : Closed e605593204398 ∧ code e605593204398 = 2804616459950 := by decide
theorem cert_e605593204398 : check e605593204398 [[],[]] .smaller = true := by decide
def e605593204406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e605593204406 : Closed e605593204406 ∧ code e605593204406 = 2804616459958 := by decide
theorem cert_e605593204406 : check e605593204406 [[],[]] .smaller = true := by decide
def e605593204410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605593204410 : Closed e605593204410 ∧ code e605593204410 = 2804616459962 := by decide
theorem cert_e605593204410 : check e605593204410 [[],[]] .smaller = true := by decide
def e605593204438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e605593204438 : Closed e605593204438 ∧ code e605593204438 = 2804616459990 := by decide
theorem cert_e605593204438 : check e605593204438 [[],[]] .smaller = true := by decide
def e605593204442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e605593204442 : Closed e605593204442 ∧ code e605593204442 = 2804616459994 := by decide
theorem cert_e605593204442 : check e605593204442 [[],[]] .smaller = true := by decide
def e605593204458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605593204458 : Closed e605593204458 ∧ code e605593204458 = 2804616460010 := by decide
theorem cert_e605593204458 : check e605593204458 [[],[]] .smaller = true := by decide
def e605593204566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605593204566 : Closed e605593204566 ∧ code e605593204566 = 2804616460118 := by decide
theorem cert_e605593204566 : check e605593204566 [[],[]] .smaller = true := by decide
def e605593204570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605593204570 : Closed e605593204570 ∧ code e605593204570 = 2804616460122 := by decide
theorem cert_e605593204570 : check e605593204570 [[],[]] .smaller = true := by decide
def e605593204586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605593204586 : Closed e605593204586 ∧ code e605593204586 = 2804616460138 := by decide
theorem cert_e605593204586 : check e605593204586 [[],[]] .smaller = true := by decide
def e605593204650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605593204650 : Closed e605593204650 ∧ code e605593204650 = 2804616460202 := by decide
theorem cert_e605593204650 : check e605593204650 [[],[]] .three = true := by decide
def e605593205422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605593205422 : Closed e605593205422 ∧ code e605593205422 = 2804616460974 := by decide
theorem cert_e605593205422 : check e605593205422 [[],[]] .three = true := by decide
def e605593205430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e605593205430 : Closed e605593205430 ∧ code e605593205430 = 2804616460982 := by decide
theorem cert_e605593205430 : check e605593205430 [[],[]] .three = true := by decide
def e605593205434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605593205434 : Closed e605593205434 ∧ code e605593205434 = 2804616460986 := by decide
theorem cert_e605593205434 : check e605593205434 [[],[]] .three = true := by decide
def e605593205462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e605593205462 : Closed e605593205462 ∧ code e605593205462 = 2804616461014 := by decide
theorem cert_e605593205462 : check e605593205462 [[],[]] .three = true := by decide
def e605593205466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e605593205466 : Closed e605593205466 ∧ code e605593205466 = 2804616461018 := by decide
theorem cert_e605593205466 : check e605593205466 [[],[]] .three = true := by decide
def e605593205482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605593205482 : Closed e605593205482 ∧ code e605593205482 = 2804616461034 := by decide
theorem cert_e605593205482 : check e605593205482 [[],[]] .three = true := by decide
def e605593205590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605593205590 : Closed e605593205590 ∧ code e605593205590 = 2804616461142 := by decide
theorem cert_e605593205590 : check e605593205590 [[],[]] .three = true := by decide
def e605593205594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605593205594 : Closed e605593205594 ∧ code e605593205594 = 2804616461146 := by decide
theorem cert_e605593205594 : check e605593205594 [[],[]] .three = true := by decide
def e605593205610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605593205610 : Closed e605593205610 ∧ code e605593205610 = 2804616461162 := by decide
theorem cert_e605593205610 : check e605593205610 [[],[]] .three = true := by decide
def e605593205674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605593205674 : Closed e605593205674 ∧ code e605593205674 = 2804616461226 := by decide
theorem cert_e605593205674 : check e605593205674 [[],[]] .three = true := by decide
def e605593208686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)) (.var 2)))))))
theorem wire_e605593208686 : Closed e605593208686 ∧ code e605593208686 = 2804616464238 := by decide
theorem cert_e605593208686 : check e605593208686 [[],[]] .smaller = true := by decide
def e605593208694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)) (.var 1)))))))
theorem wire_e605593208694 : Closed e605593208694 ∧ code e605593208694 = 2804616464246 := by decide
theorem cert_e605593208694 : check e605593208694 [[],[]] .smaller = true := by decide
end Blc.Floor41
