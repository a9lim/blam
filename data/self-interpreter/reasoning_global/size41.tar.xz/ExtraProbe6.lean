import Extra41
import Batch064
import Batch070
import Batch104
import Batch105
import Batch137
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness604735540182
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.app u8 u0
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u11 u1
private def u13 := Term.app u12 u0
private def u14 := Term.lam u13
private def u15 := Term.lam u14
private def u16 := Term.app u11 u15
private def u17 := Term.var 3
private def u18 := Term.app u17 u1
private def u19 := Term.app u18 u0
private def u20 := Term.lam u19
private def u21 := Term.lam u20
private def u22 := Term.app u0 u21
private def u23 := Term.app u22 u1
private def u24 := Term.lam u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u8
private def u28 := Term.app u27 u27
private def u29 := Term.app u28 u0
private def u30 := Term.app u29 u1
private def u31 := Term.lam u30
private def u32 := Term.lam u31
private def u33 := Term.app u26 u32
private def u34 := Term.app u27 u28
private def u35 := Term.app u34 u1
private def u36 := Term.app u35 u0
private def u37 := Term.lam u36
private def u38 := Term.lam u37
private def u39 := Term.app u33 u38
private def u40 := Term.app u39 u0
private def u41 := Term.lam u0
private def u42 := Term.lam u41
private def u43 := Term.app u1 u42
private def u44 := Term.lam u2
private def u45 := Term.app u1 u44
private def u46 := Term.var 4
private def u47 := Term.app u43 u46
private def u48 := Term.lam u47
private def u49 := Term.app u45 u48
private def u50 := Term.lam u49
private def u51 := Term.app u43 u50
private def u52 := Term.lam u51
private def u53 := Term.app u43 u52
private def u54 := Term.lam u53
private def u55 := Term.app u40 u54
private def u56 := Term.app u0 u44
private def u57 := Term.app u56 u1
private def u58 := Term.app u8 u15
private def u59 := Term.lam u58
private def u60 := Term.app u59 u25
private def u61 := Term.app u60 u32
private def u62 := Term.app u61 u38
private def u63 := Term.app u62 u0
private def u64 := Term.app u63 u54
theorem nege604735540182 : ¬ IsSelfInterpreter e604735540182 := by
  intro he
  have hv : NFt u57 := by decide
  have reach : Betas (Floor40.call e604735540182 u0 u2 u1 []) u57 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.under,.right,.under,.under,.left],[.left,.left,.left,.left,.under,.right,.under,.under],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.right,.under,.under],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left,.left]] (Floor40.call e604735540182 u0 u2 u1 []) = some u55 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u55) (u := u64) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left,.left,.under,.right,.under,.under,.left],[.left,.left,.left,.left,.left,.under,.right,.under,.under],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left,.left,.right,.under,.under],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]]) (by decide)) j hj
#print axioms nege604735540182
end Witness604735540182
namespace Witness604735540858
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u0 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u9 u1
private def u12 := Term.app u0 u11
private def u13 := Term.lam u12
private def u14 := Term.lam u13
private def u15 := Term.app u10 u1
private def u16 := Term.app u0 u15
private def u17 := Term.lam u16
private def u18 := Term.lam u17
private def u19 := Term.var 3
private def u20 := Term.app u18 u19
private def u21 := Term.app u14 u20
private def u22 := Term.app u14 u21
private def u23 := Term.app u22 u1
private def u24 := Term.app u0 u23
private def u25 := Term.lam u24
private def u26 := Term.lam u25
private def u27 := Term.app u9 u26
private def u28 := Term.app u9 u27
private def u29 := Term.app u10 u28
private def u30 := Term.app u0 u29
private def u31 := Term.app u9 u10
private def u32 := Term.app u31 u21
private def u33 := Term.app u32 u1
private def u34 := Term.app u0 u33
private def u35 := Term.lam u34
private def u36 := Term.lam u35
private def u37 := Term.app u18 u36
private def u38 := Term.app u14 u37
private def u39 := Term.app u30 u38
private def u40 := Term.app u31 u1
private def u41 := Term.app u0 u40
private def u42 := Term.lam u41
private def u43 := Term.lam u42
private def u44 := Term.app u14 u43
private def u45 := Term.app u44 u1
private def u46 := Term.app u0 u45
private def u47 := Term.lam u46
private def u48 := Term.lam u47
private def u49 := Term.lam u0
private def u50 := Term.lam u49
private def u51 := Term.app u1 u50
private def u52 := Term.lam u2
private def u53 := Term.app u1 u52
private def u54 := Term.var 4
private def u55 := Term.app u51 u54
private def u56 := Term.lam u55
private def u57 := Term.app u53 u56
private def u58 := Term.lam u57
private def u59 := Term.app u51 u58
private def u60 := Term.lam u59
private def u61 := Term.app u51 u60
private def u62 := Term.lam u61
private def u63 := Term.app u48 u62
private def u64 := Term.app u31 u63
private def u65 := Term.app u39 u64
private def u66 := Term.app u0 u52
private def u67 := Term.app u66 u1
theorem nege604735540858 : ¬ IsSelfInterpreter e604735540858 := by
  intro he
  have hv : NFt u67 := by decide
  have reach : Betas (Floor40.call e604735540858 u0 u2 u1 []) u67 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] (Floor40.call e604735540858 u0 u2 u1 []) = some u65 := by decide
  exact mismatches hv reach hr 3 (by decide)
#print axioms nege604735540858
end Witness604735540858
namespace Witness604797724270
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u1 u4
private def u6 := Term.app u0 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u1 u10
private def u12 := Term.app u1 u11
private def u13 := Term.app u0 u12
private def u14 := Term.lam u13
private def u15 := Term.lam u14
private def u16 := Term.app u0 u15
private def u17 := Term.app u0 u16
private def u18 := Term.app u10 u10
private def u19 := Term.app u17 u18
private def u20 := Term.app u17 u19
private def u21 := Term.app u20 u18
private def u22 := Term.app u20 u21
private def u23 := Term.var 3
private def u24 := Term.app u23 u15
private def u25 := Term.app u23 u24
private def u26 := Term.app u25 u18
private def u27 := Term.app u25 u26
private def u28 := Term.app u27 u18
private def u29 := Term.app u27 u28
private def u30 := Term.app u1 u29
private def u31 := Term.app u1 u30
private def u32 := Term.app u0 u31
private def u33 := Term.lam u32
private def u34 := Term.lam u33
private def u35 := Term.app u22 u34
private def u36 := Term.lam u0
private def u37 := Term.lam u36
private def u38 := Term.app u1 u37
private def u39 := Term.lam u2
private def u40 := Term.app u1 u39
private def u41 := Term.var 4
private def u42 := Term.app u38 u41
private def u43 := Term.lam u42
private def u44 := Term.app u40 u43
private def u45 := Term.lam u44
private def u46 := Term.app u38 u45
private def u47 := Term.lam u46
private def u48 := Term.app u38 u47
private def u49 := Term.lam u48
private def u50 := Term.app u35 u49
private def u51 := Term.app u0 u39
private def u52 := Term.app u51 u1
theorem nege604797724270 : ¬ IsSelfInterpreter e604797724270 := by
  intro he
  have hv : NFt u52 := by decide
  have reach : Betas (Floor40.call e604797724270 u0 u2 u1 []) u52 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left]] (Floor40.call e604797724270 u0 u2 u1 []) = some u50 := by decide
  exact mismatches hv reach hr 2 (by decide)
#print axioms nege604797724270
end Witness604797724270
namespace Witness605602117486
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u3
private def u5 := Term.app u4 u0
private def u6 := Term.app u1 u5
private def u7 := Term.app u6 u3
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u2 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.app u14 u0
private def u16 := Term.lam u15
private def u17 := Term.app u11 u16
private def u18 := Term.app u17 u10
private def u19 := Term.app u18 u10
private def u20 := Term.app u19 u10
private def u21 := Term.lam u2
private def u22 := Term.app u0 u21
private def u23 := Term.app u22 u1
theorem nege605602117486 : ¬ IsSelfInterpreter e605602117486 := by
  intro he
  have hv : NFt u23 := by decide
  have reach : Betas (Floor40.call e605602117486 u0 u2 u1 []) u23 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left]] (Floor40.call e605602117486 u0 u2 u1 []) = some u20 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege605602117486
end Witness605602117486
namespace Witness605602172790
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u3
private def u5 := Term.app u3 u4
private def u6 := Term.app u1 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.app u11 u11
private def u13 := Term.app u11 u12
private def u14 := Term.app u1 u13
private def u15 := Term.app u14 u0
private def u16 := Term.lam u15
private def u17 := Term.lam u16
private def u18 := Term.app u0 u17
private def u19 := Term.app u18 u12
private def u20 := Term.lam u2
private def u21 := Term.app u0 u20
private def u22 := Term.app u21 u1
theorem nege605602172790 : ¬ IsSelfInterpreter e605602172790 := by
  intro he
  have hv : NFt u22 := by decide
  have reach : Betas (Floor40.call e605602172790 u0 u2 u1 []) u22 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.right]] (Floor40.call e605602172790 u0 u2 u1 []) = some u19 := by decide
  exact mismatches hv reach hr 5 (by decide)
#print axioms nege605602172790
end Witness605602172790
namespace Witness605649495606
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.lam u0
private def u5 := Term.app u1 u4
private def u6 := Term.app u3 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u11 u5
private def u13 := Term.app u12 u3
private def u14 := Term.lam u13
private def u15 := Term.var 3
private def u16 := Term.app u12 u15
private def u17 := Term.lam u16
private def u18 := Term.app u17 u5
private def u19 := Term.lam u4
private def u20 := Term.app u1 u19
private def u21 := Term.lam u2
private def u22 := Term.app u1 u21
private def u23 := Term.var 5
private def u24 := Term.app u20 u23
private def u25 := Term.lam u24
private def u26 := Term.app u22 u25
private def u27 := Term.lam u26
private def u28 := Term.app u20 u27
private def u29 := Term.lam u28
private def u30 := Term.app u20 u29
private def u31 := Term.lam u30
private def u32 := Term.app u18 u31
private def u33 := Term.lam u32
private def u34 := Term.app u14 u33
private def u35 := Term.app u0 u21
private def u36 := Term.app u35 u1
private def u37 := Term.var 4
private def u38 := Term.app u20 u37
private def u39 := Term.lam u38
private def u40 := Term.app u22 u39
private def u41 := Term.lam u40
private def u42 := Term.app u20 u41
private def u43 := Term.lam u42
private def u44 := Term.app u20 u43
private def u45 := Term.lam u44
private def u46 := Term.app u12 u37
private def u47 := Term.lam u46
private def u48 := Term.app u47 u5
private def u49 := Term.var 6
private def u50 := Term.app u20 u49
private def u51 := Term.lam u50
private def u52 := Term.app u22 u51
private def u53 := Term.lam u52
private def u54 := Term.app u20 u53
private def u55 := Term.lam u54
private def u56 := Term.app u20 u55
private def u57 := Term.lam u56
private def u58 := Term.app u48 u57
private def u59 := Term.lam u58
private def u60 := Term.app u12 u23
private def u61 := Term.lam u60
private def u62 := Term.app u61 u5
private def u63 := Term.var 7
private def u64 := Term.app u20 u63
private def u65 := Term.lam u64
private def u66 := Term.app u22 u65
private def u67 := Term.lam u66
private def u68 := Term.app u20 u67
private def u69 := Term.lam u68
private def u70 := Term.app u20 u69
private def u71 := Term.lam u70
private def u72 := Term.app u62 u71
private def u73 := Term.lam u72
private def u74 := Term.lam u73
private def u75 := Term.app u59 u74
private def u76 := Term.app u75 u5
private def u77 := Term.app u76 u3
private def u78 := Term.lam u77
private def u79 := Term.lam u59
private def u80 := Term.app u33 u79
private def u81 := Term.app u11 u80
private def u82 := Term.app u81 u0
theorem nege605649495606 : ¬ IsSelfInterpreter e605649495606 := by
  intro he
  have hv : NFt u36 := by decide
  have reach : Betas (Floor40.call e605649495606 u0 u2 u1 []) u36 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left],[.left],[]] (Floor40.call e605649495606 u0 u2 u1 []) = some u34 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u34) (u := u82) [u45,u78] (by decide) (replay_sound (ps := [[.left],[],[.left],[.left,.left,.right]]) (by decide)) j hj
#print axioms nege605649495606
end Witness605649495606
namespace Witness605649526326
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.lam u2
private def u4 := Term.app u1 u3
private def u5 := Term.lam u0
private def u6 := Term.lam u5
private def u7 := Term.app u1 u6
private def u8 := Term.var 2
private def u9 := Term.app u7 u8
private def u10 := Term.lam u9
private def u11 := Term.app u4 u10
private def u12 := Term.lam u11
private def u13 := Term.app u0 u3
private def u14 := Term.app u13 u1
theorem nege605649526326 : ¬ IsSelfInterpreter e605649526326 := by
  intro he
  have hv : NFt u14 := by decide
  have reach : Betas (Floor40.call e605649526326 u0 u2 u1 []) u14 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left],[.left],[],[],[],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] (Floor40.call e605649526326 u0 u2 u1 []) = some u12 := by decide
  exact mismatches hv reach hr 1 (by decide)
#print axioms nege605649526326
end Witness605649526326
namespace Witness605649533382
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.lam u0
private def u5 := Term.app u0 u4
private def u6 := Term.app u3 u5
private def u7 := Term.app u1 u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.var 4
private def u13 := Term.app u12 u4
private def u14 := Term.app u11 u13
private def u15 := Term.app u1 u14
private def u16 := Term.lam u15
private def u17 := Term.lam u4
private def u18 := Term.app u1 u17
private def u19 := Term.lam u2
private def u20 := Term.app u1 u19
private def u21 := Term.var 6
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u20 u23
private def u25 := Term.lam u24
private def u26 := Term.app u18 u25
private def u27 := Term.lam u26
private def u28 := Term.app u18 u27
private def u29 := Term.lam u28
private def u30 := Term.app u29 u4
private def u31 := Term.app u16 u30
private def u32 := Term.app u1 u31
private def u33 := Term.lam u32
private def u34 := Term.lam u33
private def u35 := Term.app u0 u34
private def u36 := Term.var 5
private def u37 := Term.app u36 u4
private def u38 := Term.app u11 u37
private def u39 := Term.app u1 u38
private def u40 := Term.lam u39
private def u41 := Term.var 7
private def u42 := Term.app u18 u41
private def u43 := Term.lam u42
private def u44 := Term.app u20 u43
private def u45 := Term.lam u44
private def u46 := Term.app u18 u45
private def u47 := Term.lam u46
private def u48 := Term.app u18 u47
private def u49 := Term.lam u48
private def u50 := Term.app u49 u4
private def u51 := Term.app u40 u50
private def u52 := Term.app u1 u51
private def u53 := Term.lam u52
private def u54 := Term.lam u53
private def u55 := Term.app u3 u54
private def u56 := Term.var 3
private def u57 := Term.app u56 u4
private def u58 := Term.app u11 u57
private def u59 := Term.app u1 u58
private def u60 := Term.lam u59
private def u61 := Term.app u18 u36
private def u62 := Term.lam u61
private def u63 := Term.app u20 u62
private def u64 := Term.lam u63
private def u65 := Term.app u18 u64
private def u66 := Term.lam u65
private def u67 := Term.app u18 u66
private def u68 := Term.lam u67
private def u69 := Term.app u21 u4
private def u70 := Term.app u11 u69
private def u71 := Term.app u1 u70
private def u72 := Term.lam u71
private def u73 := Term.var 8
private def u74 := Term.app u18 u73
private def u75 := Term.lam u74
private def u76 := Term.app u20 u75
private def u77 := Term.lam u76
private def u78 := Term.app u18 u77
private def u79 := Term.lam u78
private def u80 := Term.app u18 u79
private def u81 := Term.lam u80
private def u82 := Term.app u81 u4
private def u83 := Term.app u72 u82
private def u84 := Term.app u1 u83
private def u85 := Term.lam u84
private def u86 := Term.lam u85
private def u87 := Term.app u56 u86
private def u88 := Term.app u11 u87
private def u89 := Term.lam u88
private def u90 := Term.app u68 u89
private def u91 := Term.app u60 u90
private def u92 := Term.app u91 u4
private def u93 := Term.app u55 u92
private def u94 := Term.app u1 u93
private def u95 := Term.lam u94
private def u96 := Term.app u35 u95
private def u97 := Term.app u0 u19
private def u98 := Term.app u97 u1
theorem nege605649533382 : ¬ IsSelfInterpreter e605649533382 := by
  intro he
  have hv : NFt u98 := by decide
  have reach : Betas (Floor40.call e605649533382 u0 u2 u1 []) u98 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left],[.left],[.left],[],[],[],[.left],[]] (Floor40.call e605649533382 u0 u2 u1 []) = some u96 := by decide
  exact mismatches hv reach hr 2 (by decide)
#print axioms nege605649533382
end Witness605649533382
end Blc.Floor41
