import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605775117226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))) (.var 0))))
theorem wire_e605775117226 : Closed e605775117226 ∧ code e605775117226 = 2804798372778 := by decide
private def t_e605775117226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))) (.var 0))))
theorem cert_e605775117226 : ¬ IsSelfInterpreter e605775117226 :=
  wSource (t := t_e605775117226) (replay_sound (ps := []) (t := e605775117226) (by decide)) (by decide)
def e605775117658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))) (.var 0))))
theorem wire_e605775117658 : Closed e605775117658 ∧ code e605775117658 = 2804798373210 := by decide
def e605775117674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))) (.var 0))))
theorem wire_e605775117674 : Closed e605775117674 ∧ code e605775117674 = 2804798373226 := by decide
def e605775117738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))) (.var 0))))
theorem wire_e605775117738 : Closed e605775117738 ∧ code e605775117738 = 2804798373290 := by decide
private def t_e605775117738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))) (.var 0))))
theorem cert_e605775117738 : ¬ IsSelfInterpreter e605775117738 :=
  wSource (t := t_e605775117738) (replay_sound (ps := []) (t := e605775117738) (by decide)) (by decide)
def e605775121850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))) (.var 0))))
theorem wire_e605775121850 : Closed e605775121850 ∧ code e605775121850 = 2804798377402 := by decide
def e605775121882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))) (.var 0))))
theorem wire_e605775121882 : Closed e605775121882 ∧ code e605775121882 = 2804798377434 := by decide
def e605775122106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))) (.var 0))))
theorem wire_e605775122106 : Closed e605775122106 ∧ code e605775122106 = 2804798377658 := by decide
def e605775122154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))) (.var 0))))
theorem wire_e605775122154 : Closed e605775122154 ∧ code e605775122154 = 2804798377706 := by decide
def e605775122266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))) (.var 0))))
theorem wire_e605775122266 : Closed e605775122266 ∧ code e605775122266 = 2804798377818 := by decide
def e605775122282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))) (.var 0))))
theorem wire_e605775122282 : Closed e605775122282 ∧ code e605775122282 = 2804798377834 := by decide
def e605775123386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem wire_e605775123386 : Closed e605775123386 ∧ code e605775123386 = 2804798378938 := by decide
def e605775123418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem wire_e605775123418 : Closed e605775123418 ∧ code e605775123418 = 2804798378970 := by decide
def e605775124922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem wire_e605775124922 : Closed e605775124922 ∧ code e605775124922 = 2804798380474 := by decide
def e605775124970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem wire_e605775124970 : Closed e605775124970 ∧ code e605775124970 = 2804798380522 := by decide
def e605775125378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.lam (.var 0))))))
theorem wire_e605775125378 : Closed e605775125378 ∧ code e605775125378 = 2804798380930 := by decide
theorem cert_e605775125378 : check e605775125378 [[],[],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e605775125402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.app (.var 0) (.var 0)))))
theorem wire_e605775125402 : Closed e605775125402 ∧ code e605775125402 = 2804798380954 := by decide
def e605775125722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem wire_e605775125722 : Closed e605775125722 ∧ code e605775125722 = 2804798381274 := by decide
def e605775125738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem wire_e605775125738 : Closed e605775125738 ∧ code e605775125738 = 2804798381290 := by decide
def e605775125890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.lam (.var 0))))))
theorem wire_e605775125890 : Closed e605775125890 ∧ code e605775125890 = 2804798381442 := by decide
theorem cert_e605775125890 : check e605775125890 [[],[],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e605775125914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.app (.var 0) (.var 0)))))
theorem wire_e605775125914 : Closed e605775125914 ∧ code e605775125914 = 2804798381466 := by decide
def e605775128250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))) (.var 0))))
theorem wire_e605775128250 : Closed e605775128250 ∧ code e605775128250 = 2804798383802 := by decide
def e605775128298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))) (.var 0))))
theorem wire_e605775128298 : Closed e605775128298 ∧ code e605775128298 = 2804798383850 := by decide
def e605775128490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))) (.var 0))))
theorem wire_e605775128490 : Closed e605775128490 ∧ code e605775128490 = 2804798384042 := by decide
def e605775129018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem wire_e605775129018 : Closed e605775129018 ∧ code e605775129018 = 2804798384570 := by decide
def e605775129066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem wire_e605775129066 : Closed e605775129066 ∧ code e605775129066 = 2804798384618 := by decide
def e605775129474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.lam (.var 0))))))
theorem wire_e605775129474 : Closed e605775129474 ∧ code e605775129474 = 2804798385026 := by decide
theorem cert_e605775129474 : check e605775129474 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e605775129498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.app (.var 0) (.var 0)))))
theorem wire_e605775129498 : Closed e605775129498 ∧ code e605775129498 = 2804798385050 := by decide
def e605775130218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))) (.var 0))))
theorem wire_e605775130218 : Closed e605775130218 ∧ code e605775130218 = 2804798385770 := by decide
private def t_e605775130218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))) (.var 0))))
theorem cert_e605775130218 : ¬ IsSelfInterpreter e605775130218 :=
  wSource (t := t_e605775130218) (replay_sound (ps := []) (t := e605775130218) (by decide)) (by decide)
def e605775130242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.lam (.var 0))))))
theorem wire_e605775130242 : Closed e605775130242 ∧ code e605775130242 = 2804798385794 := by decide
private def t_e605775130242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.lam (.var 0))))))
theorem cert_e605775130242 : ¬ IsSelfInterpreter e605775130242 :=
  wSource (t := t_e605775130242) (replay_sound (ps := []) (t := e605775130242) (by decide)) (by decide)
def e605775130266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.app (.var 0) (.var 0)))))
theorem wire_e605775130266 : Closed e605775130266 ∧ code e605775130266 = 2804798385818 := by decide
private def t_e605775130266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.app (.var 0) (.var 0)))))
theorem cert_e605775130266 : ¬ IsSelfInterpreter e605775130266 :=
  wSource (t := t_e605775130266) (replay_sound (ps := []) (t := e605775130266) (by decide)) (by decide)
def e605775131482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))) (.var 0))))
theorem wire_e605775131482 : Closed e605775131482 ∧ code e605775131482 = 2804798387034 := by decide
def e605775131498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))) (.var 0))))
theorem wire_e605775131498 : Closed e605775131498 ∧ code e605775131498 = 2804798387050 := by decide
def e605775131562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))) (.var 0))))
theorem wire_e605775131562 : Closed e605775131562 ∧ code e605775131562 = 2804798387114 := by decide
def e605775131866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem wire_e605775131866 : Closed e605775131866 ∧ code e605775131866 = 2804798387418 := by decide
def e605775131882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem wire_e605775131882 : Closed e605775131882 ∧ code e605775131882 = 2804798387434 := by decide
def e605775132034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.lam (.var 0))))))
theorem wire_e605775132034 : Closed e605775132034 ∧ code e605775132034 = 2804798387586 := by decide
theorem cert_e605775132034 : check e605775132034 [[],[],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e605775132058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.app (.var 0) (.var 0)))))
theorem wire_e605775132058 : Closed e605775132058 ∧ code e605775132058 = 2804798387610 := by decide
def e605775132266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))) (.var 0))))
theorem wire_e605775132266 : Closed e605775132266 ∧ code e605775132266 = 2804798387818 := by decide
private def t_e605775132266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))) (.var 0))))
theorem cert_e605775132266 : ¬ IsSelfInterpreter e605775132266 :=
  wSource (t := t_e605775132266) (replay_sound (ps := []) (t := e605775132266) (by decide)) (by decide)
def e605775132290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.lam (.var 0))))))
theorem wire_e605775132290 : Closed e605775132290 ∧ code e605775132290 = 2804798387842 := by decide
private def t_e605775132290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.lam (.var 0))))))
theorem cert_e605775132290 : ¬ IsSelfInterpreter e605775132290 :=
  wSource (t := t_e605775132290) (replay_sound (ps := []) (t := e605775132290) (by decide)) (by decide)
def e605775132314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.app (.var 0) (.var 0)))))
theorem wire_e605775132314 : Closed e605775132314 ∧ code e605775132314 = 2804798387866 := by decide
private def t_e605775132314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.app (.var 0) (.var 0)))))
theorem cert_e605775132314 : ¬ IsSelfInterpreter e605775132314 :=
  wSource (t := t_e605775132314) (replay_sound (ps := []) (t := e605775132314) (by decide)) (by decide)
def e605775138682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))) (.var 0))))
theorem wire_e605775138682 : Closed e605775138682 ∧ code e605775138682 = 2804798394234 := by decide
theorem cert_e605775138682 : check e605775138682 [[],[],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left],[],[],[],[]] .sourceHead = true := by decide
def e605775138746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))) (.var 0))))
theorem wire_e605775138746 : Closed e605775138746 ∧ code e605775138746 = 2804798394298 := by decide
theorem cert_e605775138746 : check e605775138746 [[],[],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left],[.left],[],[],[],[.left],[.left],[.left,.left],[.left],[.left],[],[],[],[.left],[],[]] .sourceHead = true := by decide
def e605775146426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))))
theorem wire_e605775146426 : Closed e605775146426 ∧ code e605775146426 = 2804798401978 := by decide
def e605775146458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))))
theorem wire_e605775146458 : Closed e605775146458 ∧ code e605775146458 = 2804798402010 := by decide
def e605775146682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e605775146682 : Closed e605775146682 ∧ code e605775146682 = 2804798402234 := by decide
def e605775146730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e605775146730 : Closed e605775146730 ∧ code e605775146730 = 2804798402282 := by decide
def e605775146842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e605775146842 : Closed e605775146842 ∧ code e605775146842 = 2804798402394 := by decide
def e605775146858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e605775146858 : Closed e605775146858 ∧ code e605775146858 = 2804798402410 := by decide
def e605775147962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e605775147962 : Closed e605775147962 ∧ code e605775147962 = 2804798403514 := by decide
def e605775147994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e605775147994 : Closed e605775147994 ∧ code e605775147994 = 2804798403546 := by decide
def e605775149498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e605775149498 : Closed e605775149498 ∧ code e605775149498 = 2804798405050 := by decide
def e605775149546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e605775149546 : Closed e605775149546 ∧ code e605775149546 = 2804798405098 := by decide
def e605775149954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.lam (.var 0))))))
theorem wire_e605775149954 : Closed e605775149954 ∧ code e605775149954 = 2804798405506 := by decide
theorem cert_e605775149954 : check e605775149954 [[],[],[.left],[.left,.left],[.left],[.left]] .smaller = true := by decide
def e605775149978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.app (.var 0) (.var 0)))))
theorem wire_e605775149978 : Closed e605775149978 ∧ code e605775149978 = 2804798405530 := by decide
def e605775150298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e605775150298 : Closed e605775150298 ∧ code e605775150298 = 2804798405850 := by decide
def e605775150314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e605775150314 : Closed e605775150314 ∧ code e605775150314 = 2804798405866 := by decide
def e605775150466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.lam (.var 0))))))
theorem wire_e605775150466 : Closed e605775150466 ∧ code e605775150466 = 2804798406018 := by decide
theorem cert_e605775150466 : check e605775150466 [[],[],[.left],[.left,.left],[.left],[.left]] .smaller = true := by decide
def e605775150490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.app (.var 0) (.var 0)))))
theorem wire_e605775150490 : Closed e605775150490 ∧ code e605775150490 = 2804798406042 := by decide
def e605775169402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))) (.var 0))))
theorem wire_e605775169402 : Closed e605775169402 ∧ code e605775169402 = 2804798424954 := by decide
theorem cert_e605775169402 : check e605775169402 [[],[],[.left],[.left,.left],[.left],[.left],[],[],[],[.under],[.under,.left]] .sourceHead = true := by decide
def e605775169498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))) (.var 0))))
theorem wire_e605775169498 : Closed e605775169498 ∧ code e605775169498 = 2804798425050 := by decide
theorem cert_e605775169498 : check e605775169498 [[],[],[.left],[.left,.left],[.left],[.left],[],[],[],[.left],[],[],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e605775173306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e605775173306 : Closed e605775173306 ∧ code e605775173306 = 2804798428858 := by decide
def e605775173354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e605775173354 : Closed e605775173354 ∧ code e605775173354 = 2804798428906 := by decide
def e605775173546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))) (.var 0))))
theorem wire_e605775173546 : Closed e605775173546 ∧ code e605775173546 = 2804798429098 := by decide
def e605775174074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e605775174074 : Closed e605775174074 ∧ code e605775174074 = 2804798429626 := by decide
def e605775174122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e605775174122 : Closed e605775174122 ∧ code e605775174122 = 2804798429674 := by decide
def e605775174530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.lam (.var 0))))))
theorem wire_e605775174530 : Closed e605775174530 ∧ code e605775174530 = 2804798430082 := by decide
theorem cert_e605775174530 : check e605775174530 [[],[],[.left],[.left,.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e605775174554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.app (.var 0) (.var 0)))))
theorem wire_e605775174554 : Closed e605775174554 ∧ code e605775174554 = 2804798430106 := by decide
def e605775175274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))) (.var 0))))
theorem wire_e605775175274 : Closed e605775175274 ∧ code e605775175274 = 2804798430826 := by decide
def e605775175298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.lam (.var 0))))))
theorem wire_e605775175298 : Closed e605775175298 ∧ code e605775175298 = 2804798430850 := by decide
theorem cert_e605775175298 : check e605775175298 [[],[],[.left],[.left,.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e605775175322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.app (.var 0) (.var 0)))))
theorem wire_e605775175322 : Closed e605775175322 ∧ code e605775175322 = 2804798430874 := by decide
def e605775184826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e605775184826 : Closed e605775184826 ∧ code e605775184826 = 2804798440378 := by decide
def e605775184858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e605775184858 : Closed e605775184858 ∧ code e605775184858 = 2804798440410 := by decide
def e605775186778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e605775186778 : Closed e605775186778 ∧ code e605775186778 = 2804798442330 := by decide
def e605775186794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e605775186794 : Closed e605775186794 ∧ code e605775186794 = 2804798442346 := by decide
def e605775186858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))) (.var 0))))
theorem wire_e605775186858 : Closed e605775186858 ∧ code e605775186858 = 2804798442410 := by decide
def e605775187162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e605775187162 : Closed e605775187162 ∧ code e605775187162 = 2804798442714 := by decide
def e605775187178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e605775187178 : Closed e605775187178 ∧ code e605775187178 = 2804798442730 := by decide
def e605775187330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.lam (.var 0))))))
theorem wire_e605775187330 : Closed e605775187330 ∧ code e605775187330 = 2804798442882 := by decide
theorem cert_e605775187330 : check e605775187330 [[],[],[.left],[.left,.left],[.left],[.left],[.left,.left,.left]] .chain = true := by decide
def e605775187354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.app (.var 0) (.var 0)))))
theorem wire_e605775187354 : Closed e605775187354 ∧ code e605775187354 = 2804798442906 := by decide
def e605775187562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))) (.var 0))))
theorem wire_e605775187562 : Closed e605775187562 ∧ code e605775187562 = 2804798443114 := by decide
def e605775187586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.lam (.var 0))))))
theorem wire_e605775187586 : Closed e605775187586 ∧ code e605775187586 = 2804798443138 := by decide
theorem cert_e605775187586 : check e605775187586 [[],[],[.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left,.left]] .chain = true := by decide
def e605775187610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.app (.var 0) (.var 0)))))
theorem wire_e605775187610 : Closed e605775187610 ∧ code e605775187610 = 2804798443162 := by decide
def e605775203182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605775203182 : Closed e605775203182 ∧ code e605775203182 = 2804798458734 := by decide
theorem cert_e605775203182 : check e605775203182 [[],[],[.left]] .chain = true := by decide
def e605775203190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605775203190 : Closed e605775203190 ∧ code e605775203190 = 2804798458742 := by decide
theorem cert_e605775203190 : check e605775203190 [[],[],[.left]] .chain = true := by decide
def e605775203246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605775203246 : Closed e605775203246 ∧ code e605775203246 = 2804798458798 := by decide
theorem cert_e605775203246 : check e605775203246 [[],[],[.left]] .chain = true := by decide
def e605775203258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605775203258 : Closed e605775203258 ∧ code e605775203258 = 2804798458810 := by decide
theorem cert_e605775203258 : check e605775203258 [[],[],[.left]] .chain = true := by decide
def e605775203286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605775203286 : Closed e605775203286 ∧ code e605775203286 = 2804798458838 := by decide
theorem cert_e605775203286 : check e605775203286 [[],[],[.left]] .chain = true := by decide
def e605775203290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605775203290 : Closed e605775203290 ∧ code e605775203290 = 2804798458842 := by decide
theorem cert_e605775203290 : check e605775203290 [[],[],[.left]] .chain = true := by decide
def e605775203566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605775203566 : Closed e605775203566 ∧ code e605775203566 = 2804798459118 := by decide
theorem cert_e605775203566 : check e605775203566 [[],[],[.left]] .chain = true := by decide
def e605775203574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605775203574 : Closed e605775203574 ∧ code e605775203574 = 2804798459126 := by decide
theorem cert_e605775203574 : check e605775203574 [[],[],[.left]] .chain = true := by decide
def e605775203950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605775203950 : Closed e605775203950 ∧ code e605775203950 = 2804798459502 := by decide
theorem cert_e605775203950 : check e605775203950 [[],[],[.left]] .chain = true := by decide
def e605775203962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605775203962 : Closed e605775203962 ∧ code e605775203962 = 2804798459514 := by decide
theorem cert_e605775203962 : check e605775203962 [[],[],[.left]] .chain = true := by decide
def e605775204150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605775204150 : Closed e605775204150 ∧ code e605775204150 = 2804798459702 := by decide
theorem cert_e605775204150 : check e605775204150 [[],[],[.left]] .chain = true := by decide
def e605775204154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605775204154 : Closed e605775204154 ∧ code e605775204154 = 2804798459706 := by decide
theorem cert_e605775204154 : check e605775204154 [[],[],[.left]] .chain = true := by decide
def e605775736250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))))
theorem wire_e605775736250 : Closed e605775736250 ∧ code e605775736250 = 2804798991802 := by decide
private def t_e605775736250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))))
theorem cert_e605775736250 : ¬ IsSelfInterpreter e605775736250 :=
  wSource (t := t_e605775736250) (replay_sound (ps := []) (t := e605775736250) (by decide)) (by decide)
def e605775736282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))))
theorem wire_e605775736282 : Closed e605775736282 ∧ code e605775736282 = 2804798991834 := by decide
private def t_e605775736282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))))
theorem cert_e605775736282 : ¬ IsSelfInterpreter e605775736282 :=
  wSource (t := t_e605775736282) (replay_sound (ps := []) (t := e605775736282) (by decide)) (by decide)
def e605775736506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e605775736506 : Closed e605775736506 ∧ code e605775736506 = 2804798992058 := by decide
private def t_e605775736506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))))
theorem cert_e605775736506 : ¬ IsSelfInterpreter e605775736506 :=
  wSource (t := t_e605775736506) (replay_sound (ps := []) (t := e605775736506) (by decide)) (by decide)
def e605775736554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e605775736554 : Closed e605775736554 ∧ code e605775736554 = 2804798992106 := by decide
private def t_e605775736554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem cert_e605775736554 : ¬ IsSelfInterpreter e605775736554 :=
  wSource (t := t_e605775736554) (replay_sound (ps := []) (t := e605775736554) (by decide)) (by decide)
def e605775736666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e605775736666 : Closed e605775736666 ∧ code e605775736666 = 2804798992218 := by decide
private def t_e605775736666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))))
theorem cert_e605775736666 : ¬ IsSelfInterpreter e605775736666 :=
  wSource (t := t_e605775736666) (replay_sound (ps := []) (t := e605775736666) (by decide)) (by decide)
def e605775736682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e605775736682 : Closed e605775736682 ∧ code e605775736682 = 2804798992234 := by decide
private def t_e605775736682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem cert_e605775736682 : ¬ IsSelfInterpreter e605775736682 :=
  wSource (t := t_e605775736682) (replay_sound (ps := []) (t := e605775736682) (by decide)) (by decide)
def e605775737786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e605775737786 : Closed e605775737786 ∧ code e605775737786 = 2804798993338 := by decide
private def t_e605775737786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem cert_e605775737786 : ¬ IsSelfInterpreter e605775737786 :=
  wSource (t := t_e605775737786) (replay_sound (ps := []) (t := e605775737786) (by decide)) (by decide)
def e605775737818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e605775737818 : Closed e605775737818 ∧ code e605775737818 = 2804798993370 := by decide
private def t_e605775737818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem cert_e605775737818 : ¬ IsSelfInterpreter e605775737818 :=
  wSource (t := t_e605775737818) (replay_sound (ps := []) (t := e605775737818) (by decide)) (by decide)
def e605775739322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e605775739322 : Closed e605775739322 ∧ code e605775739322 = 2804798994874 := by decide
private def t_e605775739322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem cert_e605775739322 : ¬ IsSelfInterpreter e605775739322 :=
  wSource (t := t_e605775739322) (replay_sound (ps := []) (t := e605775739322) (by decide)) (by decide)
def e605775739370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e605775739370 : Closed e605775739370 ∧ code e605775739370 = 2804798994922 := by decide
private def t_e605775739370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem cert_e605775739370 : ¬ IsSelfInterpreter e605775739370 :=
  wSource (t := t_e605775739370) (replay_sound (ps := []) (t := e605775739370) (by decide)) (by decide)
def e605775740122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e605775740122 : Closed e605775740122 ∧ code e605775740122 = 2804798995674 := by decide
private def t_e605775740122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem cert_e605775740122 : ¬ IsSelfInterpreter e605775740122 :=
  wSource (t := t_e605775740122) (replay_sound (ps := []) (t := e605775740122) (by decide)) (by decide)
def e605775740138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e605775740138 : Closed e605775740138 ∧ code e605775740138 = 2804798995690 := by decide
private def t_e605775740138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem cert_e605775740138 : ¬ IsSelfInterpreter e605775740138 :=
  wSource (t := t_e605775740138) (replay_sound (ps := []) (t := e605775740138) (by decide)) (by decide)
def e605778095546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))))
theorem wire_e605778095546 : Closed e605778095546 ∧ code e605778095546 = 2804801351098 := by decide
def e605778095578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))))
theorem wire_e605778095578 : Closed e605778095578 ∧ code e605778095578 = 2804801351130 := by decide
def e605778095802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e605778095802 : Closed e605778095802 ∧ code e605778095802 = 2804801351354 := by decide
def e605778095850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e605778095850 : Closed e605778095850 ∧ code e605778095850 = 2804801351402 := by decide
private def t_e605778095850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem cert_e605778095850 : ¬ IsSelfInterpreter e605778095850 :=
  wSource (t := t_e605778095850) (replay_sound (ps := []) (t := e605778095850) (by decide)) (by decide)
def e605778095962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e605778095962 : Closed e605778095962 ∧ code e605778095962 = 2804801351514 := by decide
def e605778095978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e605778095978 : Closed e605778095978 ∧ code e605778095978 = 2804801351530 := by decide
private def t_e605778095978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem cert_e605778095978 : ¬ IsSelfInterpreter e605778095978 :=
  wSource (t := t_e605778095978) (replay_sound (ps := []) (t := e605778095978) (by decide)) (by decide)
def e605778097082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e605778097082 : Closed e605778097082 ∧ code e605778097082 = 2804801352634 := by decide
def e605778097114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e605778097114 : Closed e605778097114 ∧ code e605778097114 = 2804801352666 := by decide
def e605778098618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e605778098618 : Closed e605778098618 ∧ code e605778098618 = 2804801354170 := by decide
def e605778098666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e605778098666 : Closed e605778098666 ∧ code e605778098666 = 2804801354218 := by decide
def e605778099418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e605778099418 : Closed e605778099418 ∧ code e605778099418 = 2804801354970 := by decide
def e605778099434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e605778099434 : Closed e605778099434 ∧ code e605778099434 = 2804801354986 := by decide
def e605778348910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605778348910 : Closed e605778348910 ∧ code e605778348910 = 2804801604462 := by decide
private def t_e605778348910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem cert_e605778348910 : ¬ IsSelfInterpreter e605778348910 :=
  wSource (t := t_e605778348910) (replay_sound (ps := []) (t := e605778348910) (by decide)) (by decide)
def e605778348918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605778348918 : Closed e605778348918 ∧ code e605778348918 = 2804801604470 := by decide
private def t_e605778348918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e605778348918 : ¬ IsSelfInterpreter e605778348918 :=
  wSource (t := t_e605778348918) (replay_sound (ps := []) (t := e605778348918) (by decide)) (by decide)
def e605778348974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605778348974 : Closed e605778348974 ∧ code e605778348974 = 2804801604526 := by decide
private def t_e605778348974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem cert_e605778348974 : ¬ IsSelfInterpreter e605778348974 :=
  wSource (t := t_e605778348974) (replay_sound (ps := []) (t := e605778348974) (by decide)) (by decide)
def e605778348986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605778348986 : Closed e605778348986 ∧ code e605778348986 = 2804801604538 := by decide
private def t_e605778348986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e605778348986 : ¬ IsSelfInterpreter e605778348986 :=
  wSource (t := t_e605778348986) (replay_sound (ps := []) (t := e605778348986) (by decide)) (by decide)
def e605778349014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605778349014 : Closed e605778349014 ∧ code e605778349014 = 2804801604566 := by decide
private def t_e605778349014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e605778349014 : ¬ IsSelfInterpreter e605778349014 :=
  wSource (t := t_e605778349014) (replay_sound (ps := []) (t := e605778349014) (by decide)) (by decide)
def e605778349018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605778349018 : Closed e605778349018 ∧ code e605778349018 = 2804801604570 := by decide
private def t_e605778349018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e605778349018 : ¬ IsSelfInterpreter e605778349018 :=
  wSource (t := t_e605778349018) (replay_sound (ps := []) (t := e605778349018) (by decide)) (by decide)
def e605778349294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605778349294 : Closed e605778349294 ∧ code e605778349294 = 2804801604846 := by decide
private def t_e605778349294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem cert_e605778349294 : ¬ IsSelfInterpreter e605778349294 :=
  wSource (t := t_e605778349294) (replay_sound (ps := []) (t := e605778349294) (by decide)) (by decide)
def e605778349302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605778349302 : Closed e605778349302 ∧ code e605778349302 = 2804801604854 := by decide
private def t_e605778349302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem cert_e605778349302 : ¬ IsSelfInterpreter e605778349302 :=
  wSource (t := t_e605778349302) (replay_sound (ps := []) (t := e605778349302) (by decide)) (by decide)
def e605778349678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605778349678 : Closed e605778349678 ∧ code e605778349678 = 2804801605230 := by decide
private def t_e605778349678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem cert_e605778349678 : ¬ IsSelfInterpreter e605778349678 :=
  wSource (t := t_e605778349678) (replay_sound (ps := []) (t := e605778349678) (by decide)) (by decide)
def e605778349690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605778349690 : Closed e605778349690 ∧ code e605778349690 = 2804801605242 := by decide
private def t_e605778349690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem cert_e605778349690 : ¬ IsSelfInterpreter e605778349690 :=
  wSource (t := t_e605778349690) (replay_sound (ps := []) (t := e605778349690) (by decide)) (by decide)
def e605778349878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605778349878 : Closed e605778349878 ∧ code e605778349878 = 2804801605430 := by decide
private def t_e605778349878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem cert_e605778349878 : ¬ IsSelfInterpreter e605778349878 :=
  wSource (t := t_e605778349878) (replay_sound (ps := []) (t := e605778349878) (by decide)) (by decide)
def e605778349882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605778349882 : Closed e605778349882 ∧ code e605778349882 = 2804801605434 := by decide
private def t_e605778349882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem cert_e605778349882 : ¬ IsSelfInterpreter e605778349882 :=
  wSource (t := t_e605778349882) (replay_sound (ps := []) (t := e605778349882) (by decide)) (by decide)
def e605779135342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605779135342 : Closed e605779135342 ∧ code e605779135342 = 2804802390894 := by decide
private def t_e605779135342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem cert_e605779135342 : ¬ IsSelfInterpreter e605779135342 :=
  wSource (t := t_e605779135342) (replay_sound (ps := []) (t := e605779135342) (by decide)) (by decide)
def e605779135350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605779135350 : Closed e605779135350 ∧ code e605779135350 = 2804802390902 := by decide
private def t_e605779135350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem cert_e605779135350 : ¬ IsSelfInterpreter e605779135350 :=
  wSource (t := t_e605779135350) (replay_sound (ps := []) (t := e605779135350) (by decide)) (by decide)
def e605779135406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605779135406 : Closed e605779135406 ∧ code e605779135406 = 2804802390958 := by decide
private def t_e605779135406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem cert_e605779135406 : ¬ IsSelfInterpreter e605779135406 :=
  wSource (t := t_e605779135406) (replay_sound (ps := []) (t := e605779135406) (by decide)) (by decide)
def e605779135418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605779135418 : Closed e605779135418 ∧ code e605779135418 = 2804802390970 := by decide
private def t_e605779135418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e605779135418 : ¬ IsSelfInterpreter e605779135418 :=
  wSource (t := t_e605779135418) (replay_sound (ps := []) (t := e605779135418) (by decide)) (by decide)
def e605779135446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605779135446 : Closed e605779135446 ∧ code e605779135446 = 2804802390998 := by decide
private def t_e605779135446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem cert_e605779135446 : ¬ IsSelfInterpreter e605779135446 :=
  wSource (t := t_e605779135446) (replay_sound (ps := []) (t := e605779135446) (by decide)) (by decide)
def e605779135450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605779135450 : Closed e605779135450 ∧ code e605779135450 = 2804802391002 := by decide
private def t_e605779135450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e605779135450 : ¬ IsSelfInterpreter e605779135450 :=
  wSource (t := t_e605779135450) (replay_sound (ps := []) (t := e605779135450) (by decide)) (by decide)
def e605779135726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605779135726 : Closed e605779135726 ∧ code e605779135726 = 2804802391278 := by decide
private def t_e605779135726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem cert_e605779135726 : ¬ IsSelfInterpreter e605779135726 :=
  wSource (t := t_e605779135726) (replay_sound (ps := []) (t := e605779135726) (by decide)) (by decide)
def e605779135734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605779135734 : Closed e605779135734 ∧ code e605779135734 = 2804802391286 := by decide
private def t_e605779135734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem cert_e605779135734 : ¬ IsSelfInterpreter e605779135734 :=
  wSource (t := t_e605779135734) (replay_sound (ps := []) (t := e605779135734) (by decide)) (by decide)
def e605779136110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605779136110 : Closed e605779136110 ∧ code e605779136110 = 2804802391662 := by decide
private def t_e605779136110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem cert_e605779136110 : ¬ IsSelfInterpreter e605779136110 :=
  wSource (t := t_e605779136110) (replay_sound (ps := []) (t := e605779136110) (by decide)) (by decide)
def e605779136122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605779136122 : Closed e605779136122 ∧ code e605779136122 = 2804802391674 := by decide
private def t_e605779136122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem cert_e605779136122 : ¬ IsSelfInterpreter e605779136122 :=
  wSource (t := t_e605779136122) (replay_sound (ps := []) (t := e605779136122) (by decide)) (by decide)
def e605779136310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605779136310 : Closed e605779136310 ∧ code e605779136310 = 2804802391862 := by decide
private def t_e605779136310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem cert_e605779136310 : ¬ IsSelfInterpreter e605779136310 :=
  wSource (t := t_e605779136310) (replay_sound (ps := []) (t := e605779136310) (by decide)) (by decide)
def e605779136314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605779136314 : Closed e605779136314 ∧ code e605779136314 = 2804802391866 := by decide
private def t_e605779136314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem cert_e605779136314 : ¬ IsSelfInterpreter e605779136314 :=
  wSource (t := t_e605779136314) (replay_sound (ps := []) (t := e605779136314) (by decide)) (by decide)
def e605779144158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e605779144158 : Closed e605779144158 ∧ code e605779144158 = 2804802399710 := by decide
private def t_e605779144158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem cert_e605779144158 : ¬ IsSelfInterpreter e605779144158 :=
  wSource (t := t_e605779144158) (replay_sound (ps := []) (t := e605779144158) (by decide)) (by decide)
def e605779144174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e605779144174 : Closed e605779144174 ∧ code e605779144174 = 2804802399726 := by decide
private def t_e605779144174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem cert_e605779144174 : ¬ IsSelfInterpreter e605779144174 :=
  wSource (t := t_e605779144174) (replay_sound (ps := []) (t := e605779144174) (by decide)) (by decide)
def e605779144542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e605779144542 : Closed e605779144542 ∧ code e605779144542 = 2804802400094 := by decide
private def t_e605779144542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem cert_e605779144542 : ¬ IsSelfInterpreter e605779144542 :=
  wSource (t := t_e605779144542) (replay_sound (ps := []) (t := e605779144542) (by decide)) (by decide)
def e605779144570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e605779144570 : Closed e605779144570 ∧ code e605779144570 = 2804802400122 := by decide
private def t_e605779144570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem cert_e605779144570 : ¬ IsSelfInterpreter e605779144570 :=
  wSource (t := t_e605779144570) (replay_sound (ps := []) (t := e605779144570) (by decide)) (by decide)
def e605779144622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e605779144622 : Closed e605779144622 ∧ code e605779144622 = 2804802400174 := by decide
private def t_e605779144622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem cert_e605779144622 : ¬ IsSelfInterpreter e605779144622 :=
  wSource (t := t_e605779144622) (replay_sound (ps := []) (t := e605779144622) (by decide)) (by decide)
def e605779144634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e605779144634 : Closed e605779144634 ∧ code e605779144634 = 2804802400186 := by decide
private def t_e605779144634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem cert_e605779144634 : ¬ IsSelfInterpreter e605779144634 :=
  wSource (t := t_e605779144634) (replay_sound (ps := []) (t := e605779144634) (by decide)) (by decide)
def e605779145694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e605779145694 : Closed e605779145694 ∧ code e605779145694 = 2804802401246 := by decide
private def t_e605779145694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem cert_e605779145694 : ¬ IsSelfInterpreter e605779145694 :=
  wSource (t := t_e605779145694) (replay_sound (ps := []) (t := e605779145694) (by decide)) (by decide)
def e605779145710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e605779145710 : Closed e605779145710 ∧ code e605779145710 = 2804802401262 := by decide
private def t_e605779145710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem cert_e605779145710 : ¬ IsSelfInterpreter e605779145710 :=
  wSource (t := t_e605779145710) (replay_sound (ps := []) (t := e605779145710) (by decide)) (by decide)
def e605779147998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e605779147998 : Closed e605779147998 ∧ code e605779147998 = 2804802403550 := by decide
private def t_e605779147998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem cert_e605779147998 : ¬ IsSelfInterpreter e605779147998 :=
  wSource (t := t_e605779147998) (replay_sound (ps := []) (t := e605779147998) (by decide)) (by decide)
def e605779148026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e605779148026 : Closed e605779148026 ∧ code e605779148026 = 2804802403578 := by decide
private def t_e605779148026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem cert_e605779148026 : ¬ IsSelfInterpreter e605779148026 :=
  wSource (t := t_e605779148026) (replay_sound (ps := []) (t := e605779148026) (by decide)) (by decide)
def e605779148398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e605779148398 : Closed e605779148398 ∧ code e605779148398 = 2804802403950 := by decide
private def t_e605779148398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem cert_e605779148398 : ¬ IsSelfInterpreter e605779148398 :=
  wSource (t := t_e605779148398) (replay_sound (ps := []) (t := e605779148398) (by decide)) (by decide)
def e605779148410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e605779148410 : Closed e605779148410 ∧ code e605779148410 = 2804802403962 := by decide
private def t_e605779148410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem cert_e605779148410 : ¬ IsSelfInterpreter e605779148410 :=
  wSource (t := t_e605779148410) (replay_sound (ps := []) (t := e605779148410) (by decide)) (by decide)
def e605779176814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605779176814 : Closed e605779176814 ∧ code e605779176814 = 2804802432366 := by decide
private def t_e605779176814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem cert_e605779176814 : ¬ IsSelfInterpreter e605779176814 :=
  wSource (t := t_e605779176814) (replay_sound (ps := []) (t := e605779176814) (by decide)) (by decide)
def e605779176822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605779176822 : Closed e605779176822 ∧ code e605779176822 = 2804802432374 := by decide
private def t_e605779176822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem cert_e605779176822 : ¬ IsSelfInterpreter e605779176822 :=
  wSource (t := t_e605779176822) (replay_sound (ps := []) (t := e605779176822) (by decide)) (by decide)
def e605779176878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605779176878 : Closed e605779176878 ∧ code e605779176878 = 2804802432430 := by decide
private def t_e605779176878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem cert_e605779176878 : ¬ IsSelfInterpreter e605779176878 :=
  wSource (t := t_e605779176878) (replay_sound (ps := []) (t := e605779176878) (by decide)) (by decide)
def e605779176890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605779176890 : Closed e605779176890 ∧ code e605779176890 = 2804802432442 := by decide
private def t_e605779176890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem cert_e605779176890 : ¬ IsSelfInterpreter e605779176890 :=
  wSource (t := t_e605779176890) (replay_sound (ps := []) (t := e605779176890) (by decide)) (by decide)
def e605779176918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605779176918 : Closed e605779176918 ∧ code e605779176918 = 2804802432470 := by decide
private def t_e605779176918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e605779176918 : ¬ IsSelfInterpreter e605779176918 :=
  wSource (t := t_e605779176918) (replay_sound (ps := []) (t := e605779176918) (by decide)) (by decide)
def e605779176922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605779176922 : Closed e605779176922 ∧ code e605779176922 = 2804802432474 := by decide
private def t_e605779176922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e605779176922 : ¬ IsSelfInterpreter e605779176922 :=
  wSource (t := t_e605779176922) (replay_sound (ps := []) (t := e605779176922) (by decide)) (by decide)
end Blc.Floor41
