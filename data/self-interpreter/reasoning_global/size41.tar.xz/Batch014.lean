import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e552829945358 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552829945358 : Closed e552829945358 ∧ code e552829945358 = 2751853200910 := by decide
theorem cert_e552829945358 : check e552829945358 [[]] .width = true := by decide
def e552829945370 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552829945370 : Closed e552829945370 ∧ code e552829945370 = 2751853200922 := by decide
theorem cert_e552829945370 : check e552829945370 [[]] .width = true := by decide
def e552829945442 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552829945442 : Closed e552829945442 ∧ code e552829945442 = 2751853200994 := by decide
theorem cert_e552829945442 : check e552829945442 [[]] .width = true := by decide
def e552830037530 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552830037530 : Closed e552830037530 ∧ code e552830037530 = 2751853293082 := by decide
theorem cert_e552830037530 : check e552830037530 [[]] .width = true := by decide
def e552830039578 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552830039578 : Closed e552830039578 ∧ code e552830039578 = 2751853295130 := by decide
theorem cert_e552830039578 : check e552830039578 [[]] .width = true := by decide
def e552830074906 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552830074906 : Closed e552830074906 ∧ code e552830074906 = 2751853330458 := by decide
theorem cert_e552830074906 : check e552830074906 [[]] .width = true := by decide
def e552830074998 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552830074998 : Closed e552830074998 ∧ code e552830074998 = 2751853330550 := by decide
theorem cert_e552830074998 : check e552830074998 [[]] .width = true := by decide
def e552830075242 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552830075242 : Closed e552830075242 ∧ code e552830075242 = 2751853330794 := by decide
theorem cert_e552830075242 : check e552830075242 [[]] .width = true := by decide
def e552830075290 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552830075290 : Closed e552830075290 ∧ code e552830075290 = 2751853330842 := by decide
theorem cert_e552830075290 : check e552830075290 [[]] .width = true := by decide
def e552830076298 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552830076298 : Closed e552830076298 ∧ code e552830076298 = 2751853331850 := by decide
theorem cert_e552830076298 : check e552830076298 [[]] .width = true := by decide
def e552830076322 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552830076322 : Closed e552830076322 ∧ code e552830076322 = 2751853331874 := by decide
theorem cert_e552830076322 : check e552830076322 [[]] .width = true := by decide
def e552830076430 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552830076430 : Closed e552830076430 ∧ code e552830076430 = 2751853331982 := by decide
theorem cert_e552830076430 : check e552830076430 [[]] .width = true := by decide
def e552830076442 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552830076442 : Closed e552830076442 ∧ code e552830076442 = 2751853331994 := by decide
theorem cert_e552830076442 : check e552830076442 [[]] .width = true := by decide
def e552830076514 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552830076514 : Closed e552830076514 ∧ code e552830076514 = 2751853332066 := by decide
theorem cert_e552830076514 : check e552830076514 [[]] .width = true := by decide
def e552866868762 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552866868762 : Closed e552866868762 ∧ code e552866868762 = 2751890124314 := by decide
theorem cert_e552866868762 : check e552866868762 [[]] .width = true := by decide
def e552867655194 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552867655194 : Closed e552867655194 ∧ code e552867655194 = 2751890910746 := by decide
theorem cert_e552867655194 : check e552867655194 [[]] .width = true := by decide
def e552867704346 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552867704346 : Closed e552867704346 ∧ code e552867704346 = 2751890959898 := by decide
theorem cert_e552867704346 : check e552867704346 [[]] .width = true := by decide
def e552867707418 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552867707418 : Closed e552867707418 ∧ code e552867707418 = 2751890962970 := by decide
theorem cert_e552867707418 : check e552867707418 [[]] .width = true := by decide
def e552870014490 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552870014490 : Closed e552870014490 ∧ code e552870014490 = 2751893270042 := by decide
theorem cert_e552870014490 : check e552870014490 [[]] .width = true := by decide
def e552871783962 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552871783962 : Closed e552871783962 ∧ code e552871783962 = 2751895039514 := by decide
theorem cert_e552871783962 : check e552871783962 [[]] .width = true := by decide
def e552871886874 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552871886874 : Closed e552871886874 ∧ code e552871886874 = 2751895142426 := by decide
theorem cert_e552871886874 : check e552871886874 [[]] .width = true := by decide
def e552871886966 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552871886966 : Closed e552871886966 ∧ code e552871886966 = 2751895142518 := by decide
theorem cert_e552871886966 : check e552871886966 [[]] .width = true := by decide
def e552871887210 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552871887210 : Closed e552871887210 ∧ code e552871887210 = 2751895142762 := by decide
theorem cert_e552871887210 : check e552871887210 [[]] .width = true := by decide
def e552871887258 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552871887258 : Closed e552871887258 ∧ code e552871887258 = 2751895142810 := by decide
theorem cert_e552871887258 : check e552871887258 [[]] .width = true := by decide
def e552871888266 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552871888266 : Closed e552871888266 ∧ code e552871888266 = 2751895143818 := by decide
theorem cert_e552871888266 : check e552871888266 [[]] .width = true := by decide
def e552871888290 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552871888290 : Closed e552871888290 ∧ code e552871888290 = 2751895143842 := by decide
theorem cert_e552871888290 : check e552871888290 [[]] .width = true := by decide
def e552871888398 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552871888398 : Closed e552871888398 ∧ code e552871888398 = 2751895143950 := by decide
theorem cert_e552871888398 : check e552871888398 [[]] .width = true := by decide
def e552871888410 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552871888410 : Closed e552871888410 ∧ code e552871888410 = 2751895143962 := by decide
theorem cert_e552871888410 : check e552871888410 [[]] .width = true := by decide
def e552871888482 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552871888482 : Closed e552871888482 ∧ code e552871888482 = 2751895144034 := by decide
theorem cert_e552871888482 : check e552871888482 [[]] .width = true := by decide
def e552874733082 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552874733082 : Closed e552874733082 ∧ code e552874733082 = 2751897988634 := by decide
theorem cert_e552874733082 : check e552874733082 [[]] .width = true := by decide
def e552874782234 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552874782234 : Closed e552874782234 ∧ code e552874782234 = 2751898037786 := by decide
theorem cert_e552874782234 : check e552874782234 [[]] .width = true := by decide
def e552874785306 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552874785306 : Closed e552874785306 ∧ code e552874785306 = 2751898040858 := by decide
theorem cert_e552874785306 : check e552874785306 [[]] .width = true := by decide
def e552874929690 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552874929690 : Closed e552874929690 ∧ code e552874929690 = 2751898185242 := by decide
theorem cert_e552874929690 : check e552874929690 [[]] .width = true := by decide
def e552875032602 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552875032602 : Closed e552875032602 ∧ code e552875032602 = 2751898288154 := by decide
theorem cert_e552875032602 : check e552875032602 [[]] .width = true := by decide
def e552875032694 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552875032694 : Closed e552875032694 ∧ code e552875032694 = 2751898288246 := by decide
theorem cert_e552875032694 : check e552875032694 [[]] .width = true := by decide
def e552875032938 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552875032938 : Closed e552875032938 ∧ code e552875032938 = 2751898288490 := by decide
theorem cert_e552875032938 : check e552875032938 [[]] .width = true := by decide
def e552875032986 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552875032986 : Closed e552875032986 ∧ code e552875032986 = 2751898288538 := by decide
theorem cert_e552875032986 : check e552875032986 [[]] .width = true := by decide
def e552875033994 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552875033994 : Closed e552875033994 ∧ code e552875033994 = 2751898289546 := by decide
theorem cert_e552875033994 : check e552875033994 [[]] .width = true := by decide
def e552875034018 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552875034018 : Closed e552875034018 ∧ code e552875034018 = 2751898289570 := by decide
theorem cert_e552875034018 : check e552875034018 [[]] .width = true := by decide
def e552875034126 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552875034126 : Closed e552875034126 ∧ code e552875034126 = 2751898289678 := by decide
theorem cert_e552875034126 : check e552875034126 [[]] .width = true := by decide
def e552875034138 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552875034138 : Closed e552875034138 ∧ code e552875034138 = 2751898289690 := by decide
theorem cert_e552875034138 : check e552875034138 [[]] .width = true := by decide
def e552875034210 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552875034210 : Closed e552875034210 ∧ code e552875034210 = 2751898289762 := by decide
theorem cert_e552875034210 : check e552875034210 [[]] .width = true := by decide
def e552875224602 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552875224602 : Closed e552875224602 ∧ code e552875224602 = 2751898480154 := by decide
theorem cert_e552875224602 : check e552875224602 [[]] .width = true := by decide
def e552875227674 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552875227674 : Closed e552875227674 ∧ code e552875227674 = 2751898483226 := by decide
theorem cert_e552875227674 : check e552875227674 [[]] .width = true := by decide
def e552875229210 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552875229210 : Closed e552875229210 ∧ code e552875229210 = 2751898484762 := by decide
theorem cert_e552875229210 : check e552875229210 [[]] .width = true := by decide
def e552875229302 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552875229302 : Closed e552875229302 ∧ code e552875229302 = 2751898484854 := by decide
theorem cert_e552875229302 : check e552875229302 [[]] .width = true := by decide
def e552875229546 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552875229546 : Closed e552875229546 ∧ code e552875229546 = 2751898485098 := by decide
theorem cert_e552875229546 : check e552875229546 [[]] .width = true := by decide
def e552875229594 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552875229594 : Closed e552875229594 ∧ code e552875229594 = 2751898485146 := by decide
theorem cert_e552875229594 : check e552875229594 [[]] .width = true := by decide
def e552875230602 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552875230602 : Closed e552875230602 ∧ code e552875230602 = 2751898486154 := by decide
theorem cert_e552875230602 : check e552875230602 [[]] .width = true := by decide
def e552875230626 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552875230626 : Closed e552875230626 ∧ code e552875230626 = 2751898486178 := by decide
theorem cert_e552875230626 : check e552875230626 [[]] .width = true := by decide
def e552875230734 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552875230734 : Closed e552875230734 ∧ code e552875230734 = 2751898486286 := by decide
theorem cert_e552875230734 : check e552875230734 [[]] .width = true := by decide
def e552875230746 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552875230746 : Closed e552875230746 ∧ code e552875230746 = 2751898486298 := by decide
theorem cert_e552875230746 : check e552875230746 [[]] .width = true := by decide
def e552875230818 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552875230818 : Closed e552875230818 ∧ code e552875230818 = 2751898486370 := by decide
theorem cert_e552875230818 : check e552875230818 [[]] .width = true := by decide
def e552882597402 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552882597402 : Closed e552882597402 ∧ code e552882597402 = 2751905852954 := by decide
theorem cert_e552882597402 : check e552882597402 [[]] .width = true := by decide
def e552884366874 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552884366874 : Closed e552884366874 ∧ code e552884366874 = 2751907622426 := by decide
theorem cert_e552884366874 : check e552884366874 [[]] .width = true := by decide
def e552884469786 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552884469786 : Closed e552884469786 ∧ code e552884469786 = 2751907725338 := by decide
theorem cert_e552884469786 : check e552884469786 [[]] .width = true := by decide
def e552884469878 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552884469878 : Closed e552884469878 ∧ code e552884469878 = 2751907725430 := by decide
theorem cert_e552884469878 : check e552884469878 [[]] .width = true := by decide
def e552884470122 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552884470122 : Closed e552884470122 ∧ code e552884470122 = 2751907725674 := by decide
theorem cert_e552884470122 : check e552884470122 [[]] .width = true := by decide
def e552884470170 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552884470170 : Closed e552884470170 ∧ code e552884470170 = 2751907725722 := by decide
theorem cert_e552884470170 : check e552884470170 [[]] .width = true := by decide
def e552884471178 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552884471178 : Closed e552884471178 ∧ code e552884471178 = 2751907726730 := by decide
theorem cert_e552884471178 : check e552884471178 [[]] .width = true := by decide
def e552884471202 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552884471202 : Closed e552884471202 ∧ code e552884471202 = 2751907726754 := by decide
theorem cert_e552884471202 : check e552884471202 [[]] .width = true := by decide
def e552884471310 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552884471310 : Closed e552884471310 ∧ code e552884471310 = 2751907726862 := by decide
theorem cert_e552884471310 : check e552884471310 [[]] .width = true := by decide
def e552884471322 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552884471322 : Closed e552884471322 ∧ code e552884471322 = 2751907726874 := by decide
theorem cert_e552884471322 : check e552884471322 [[]] .width = true := by decide
def e552884471394 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552884471394 : Closed e552884471394 ∧ code e552884471394 = 2751907726946 := by decide
theorem cert_e552884471394 : check e552884471394 [[]] .width = true := by decide
def e552903044634 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552903044634 : Closed e552903044634 ∧ code e552903044634 = 2751926300186 := by decide
theorem cert_e552903044634 : check e552903044634 [[]] .width = true := by decide
def e552903093786 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552903093786 : Closed e552903093786 ∧ code e552903093786 = 2751926349338 := by decide
theorem cert_e552903093786 : check e552903093786 [[]] .width = true := by decide
def e552903096858 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552903096858 : Closed e552903096858 ∧ code e552903096858 = 2751926352410 := by decide
theorem cert_e552903096858 : check e552903096858 [[]] .width = true := by decide
def e552903241242 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552903241242 : Closed e552903241242 ∧ code e552903241242 = 2751926496794 := by decide
theorem cert_e552903241242 : check e552903241242 [[]] .width = true := by decide
def e552903344154 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552903344154 : Closed e552903344154 ∧ code e552903344154 = 2751926599706 := by decide
theorem cert_e552903344154 : check e552903344154 [[]] .width = true := by decide
def e552903344246 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552903344246 : Closed e552903344246 ∧ code e552903344246 = 2751926599798 := by decide
theorem cert_e552903344246 : check e552903344246 [[]] .width = true := by decide
def e552903344490 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552903344490 : Closed e552903344490 ∧ code e552903344490 = 2751926600042 := by decide
theorem cert_e552903344490 : check e552903344490 [[]] .width = true := by decide
def e552903344538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552903344538 : Closed e552903344538 ∧ code e552903344538 = 2751926600090 := by decide
theorem cert_e552903344538 : check e552903344538 [[]] .width = true := by decide
def e552903345546 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552903345546 : Closed e552903345546 ∧ code e552903345546 = 2751926601098 := by decide
theorem cert_e552903345546 : check e552903345546 [[]] .width = true := by decide
def e552903345570 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552903345570 : Closed e552903345570 ∧ code e552903345570 = 2751926601122 := by decide
theorem cert_e552903345570 : check e552903345570 [[]] .width = true := by decide
def e552903345678 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552903345678 : Closed e552903345678 ∧ code e552903345678 = 2751926601230 := by decide
theorem cert_e552903345678 : check e552903345678 [[]] .width = true := by decide
def e552903345690 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552903345690 : Closed e552903345690 ∧ code e552903345690 = 2751926601242 := by decide
theorem cert_e552903345690 : check e552903345690 [[]] .width = true := by decide
def e552903345762 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552903345762 : Closed e552903345762 ∧ code e552903345762 = 2751926601314 := by decide
theorem cert_e552903345762 : check e552903345762 [[]] .width = true := by decide
def e552903536154 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552903536154 : Closed e552903536154 ∧ code e552903536154 = 2751926791706 := by decide
theorem cert_e552903536154 : check e552903536154 [[]] .width = true := by decide
def e552903539226 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552903539226 : Closed e552903539226 ∧ code e552903539226 = 2751926794778 := by decide
theorem cert_e552903539226 : check e552903539226 [[]] .width = true := by decide
def e552903540762 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552903540762 : Closed e552903540762 ∧ code e552903540762 = 2751926796314 := by decide
theorem cert_e552903540762 : check e552903540762 [[]] .width = true := by decide
def e552903540854 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552903540854 : Closed e552903540854 ∧ code e552903540854 = 2751926796406 := by decide
theorem cert_e552903540854 : check e552903540854 [[]] .width = true := by decide
def e552903541098 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552903541098 : Closed e552903541098 ∧ code e552903541098 = 2751926796650 := by decide
theorem cert_e552903541098 : check e552903541098 [[]] .width = true := by decide
def e552903541146 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552903541146 : Closed e552903541146 ∧ code e552903541146 = 2751926796698 := by decide
theorem cert_e552903541146 : check e552903541146 [[]] .width = true := by decide
def e552903542154 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552903542154 : Closed e552903542154 ∧ code e552903542154 = 2751926797706 := by decide
theorem cert_e552903542154 : check e552903542154 [[]] .width = true := by decide
def e552903542178 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552903542178 : Closed e552903542178 ∧ code e552903542178 = 2751926797730 := by decide
theorem cert_e552903542178 : check e552903542178 [[]] .width = true := by decide
def e552903542286 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552903542286 : Closed e552903542286 ∧ code e552903542286 = 2751926797838 := by decide
theorem cert_e552903542286 : check e552903542286 [[]] .width = true := by decide
def e552903542298 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552903542298 : Closed e552903542298 ∧ code e552903542298 = 2751926797850 := by decide
theorem cert_e552903542298 : check e552903542298 [[]] .width = true := by decide
def e552903542370 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552903542370 : Closed e552903542370 ∧ code e552903542370 = 2751926797922 := by decide
theorem cert_e552903542370 : check e552903542370 [[]] .width = true := by decide
def e552921919002 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552921919002 : Closed e552921919002 ∧ code e552921919002 = 2751945174554 := by decide
theorem cert_e552921919002 : check e552921919002 [[]] .width = true := by decide
def e552921951770 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552921951770 : Closed e552921951770 ∧ code e552921951770 = 2751945207322 := by decide
theorem cert_e552921951770 : check e552921951770 [[]] .width = true := by decide
def e552921953818 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552921953818 : Closed e552921953818 ∧ code e552921953818 = 2751945209370 := by decide
theorem cert_e552921953818 : check e552921953818 [[]] .width = true := by decide
def e552922181146 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552922181146 : Closed e552922181146 ∧ code e552922181146 = 2751945436698 := by decide
theorem cert_e552922181146 : check e552922181146 [[]] .width = true := by decide
def e552922230298 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552922230298 : Closed e552922230298 ∧ code e552922230298 = 2751945485850 := by decide
theorem cert_e552922230298 : check e552922230298 [[]] .width = true := by decide
def e552922233370 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552922233370 : Closed e552922233370 ∧ code e552922233370 = 2751945488922 := by decide
theorem cert_e552922233370 : check e552922233370 [[]] .width = true := by decide
def e552922344986 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552922344986 : Closed e552922344986 ∧ code e552922344986 = 2751945600538 := by decide
theorem cert_e552922344986 : check e552922344986 [[]] .width = true := by decide
def e552922347034 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552922347034 : Closed e552922347034 ∧ code e552922347034 = 2751945602586 := by decide
theorem cert_e552922347034 : check e552922347034 [[]] .width = true := by decide
def e552922361370 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552922361370 : Closed e552922361370 ∧ code e552922361370 = 2751945616922 := by decide
theorem cert_e552922361370 : check e552922361370 [[]] .width = true := by decide
def e552922364442 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552922364442 : Closed e552922364442 ∧ code e552922364442 = 2751945619994 := by decide
theorem cert_e552922364442 : check e552922364442 [[]] .width = true := by decide
def e552922371610 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552922371610 : Closed e552922371610 ∧ code e552922371610 = 2751945627162 := by decide
private def t_e552922371610 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552922371610 : ¬ IsSelfInterpreter e552922371610 :=
  wSource (t := t_e552922371610) (replay_sound (ps := []) (t := e552922371610) (by decide)) (by decide)
def e552922372634 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552922372634 : Closed e552922372634 ∧ code e552922372634 = 2751945628186 := by decide
private def t_e552922372634 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552922372634 : ¬ IsSelfInterpreter e552922372634 :=
  wSource (t := t_e552922372634) (replay_sound (ps := []) (t := e552922372634) (by decide)) (by decide)
def e552923491866 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552923491866 : Closed e552923491866 ∧ code e552923491866 = 2751946747418 := by decide
theorem cert_e552923491866 : check e552923491866 [[]] .width = true := by decide
def e552923524634 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552923524634 : Closed e552923524634 ∧ code e552923524634 = 2751946780186 := by decide
theorem cert_e552923524634 : check e552923524634 [[]] .width = true := by decide
def e552923526682 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552923526682 : Closed e552923526682 ∧ code e552923526682 = 2751946782234 := by decide
theorem cert_e552923526682 : check e552923526682 [[]] .width = true := by decide
def e552924212762 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552924212762 : Closed e552924212762 ∧ code e552924212762 = 2751947468314 := by decide
theorem cert_e552924212762 : check e552924212762 [[]] .width = true := by decide
def e552924315674 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552924315674 : Closed e552924315674 ∧ code e552924315674 = 2751947571226 := by decide
theorem cert_e552924315674 : check e552924315674 [[]] .width = true := by decide
def e552924315766 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552924315766 : Closed e552924315766 ∧ code e552924315766 = 2751947571318 := by decide
theorem cert_e552924315766 : check e552924315766 [[]] .width = true := by decide
def e552924316010 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552924316010 : Closed e552924316010 ∧ code e552924316010 = 2751947571562 := by decide
theorem cert_e552924316010 : check e552924316010 [[]] .width = true := by decide
def e552924316058 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552924316058 : Closed e552924316058 ∧ code e552924316058 = 2751947571610 := by decide
theorem cert_e552924316058 : check e552924316058 [[]] .width = true := by decide
def e552924317066 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552924317066 : Closed e552924317066 ∧ code e552924317066 = 2751947572618 := by decide
theorem cert_e552924317066 : check e552924317066 [[]] .width = true := by decide
def e552924317090 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552924317090 : Closed e552924317090 ∧ code e552924317090 = 2751947572642 := by decide
theorem cert_e552924317090 : check e552924317090 [[]] .width = true := by decide
def e552924317198 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552924317198 : Closed e552924317198 ∧ code e552924317198 = 2751947572750 := by decide
theorem cert_e552924317198 : check e552924317198 [[]] .width = true := by decide
def e552924317210 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552924317210 : Closed e552924317210 ∧ code e552924317210 = 2751947572762 := by decide
theorem cert_e552924317210 : check e552924317210 [[]] .width = true := by decide
def e552924317282 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552924317282 : Closed e552924317282 ∧ code e552924317282 = 2751947572834 := by decide
theorem cert_e552924317282 : check e552924317282 [[]] .width = true := by decide
def e552924409370 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552924409370 : Closed e552924409370 ∧ code e552924409370 = 2751947664922 := by decide
theorem cert_e552924409370 : check e552924409370 [[]] .width = true := by decide
def e552924411418 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552924411418 : Closed e552924411418 ∧ code e552924411418 = 2751947666970 := by decide
theorem cert_e552924411418 : check e552924411418 [[]] .width = true := by decide
def e552924446746 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552924446746 : Closed e552924446746 ∧ code e552924446746 = 2751947702298 := by decide
theorem cert_e552924446746 : check e552924446746 [[]] .width = true := by decide
def e552924446838 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552924446838 : Closed e552924446838 ∧ code e552924446838 = 2751947702390 := by decide
theorem cert_e552924446838 : check e552924446838 [[]] .width = true := by decide
def e552924447082 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552924447082 : Closed e552924447082 ∧ code e552924447082 = 2751947702634 := by decide
theorem cert_e552924447082 : check e552924447082 [[]] .width = true := by decide
def e552924447130 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552924447130 : Closed e552924447130 ∧ code e552924447130 = 2751947702682 := by decide
theorem cert_e552924447130 : check e552924447130 [[]] .width = true := by decide
def e552924448138 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552924448138 : Closed e552924448138 ∧ code e552924448138 = 2751947703690 := by decide
theorem cert_e552924448138 : check e552924448138 [[]] .width = true := by decide
def e552924448162 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552924448162 : Closed e552924448162 ∧ code e552924448162 = 2751947703714 := by decide
theorem cert_e552924448162 : check e552924448162 [[]] .width = true := by decide
def e552924448270 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552924448270 : Closed e552924448270 ∧ code e552924448270 = 2751947703822 := by decide
theorem cert_e552924448270 : check e552924448270 [[]] .width = true := by decide
def e552924448282 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552924448282 : Closed e552924448282 ∧ code e552924448282 = 2751947703834 := by decide
theorem cert_e552924448282 : check e552924448282 [[]] .width = true := by decide
def e552924448354 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552924448354 : Closed e552924448354 ∧ code e552924448354 = 2751947703906 := by decide
theorem cert_e552924448354 : check e552924448354 [[]] .width = true := by decide
def e552925064730 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925064730 : Closed e552925064730 ∧ code e552925064730 = 2751948320282 := by decide
theorem cert_e552925064730 : check e552925064730 [[]] .width = true := by decide
def e552925113882 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925113882 : Closed e552925113882 ∧ code e552925113882 = 2751948369434 := by decide
theorem cert_e552925113882 : check e552925113882 [[]] .width = true := by decide
def e552925116954 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925116954 : Closed e552925116954 ∧ code e552925116954 = 2751948372506 := by decide
theorem cert_e552925116954 : check e552925116954 [[]] .width = true := by decide
def e552925261338 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925261338 : Closed e552925261338 ∧ code e552925261338 = 2751948516890 := by decide
theorem cert_e552925261338 : check e552925261338 [[]] .width = true := by decide
def e552925364250 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552925364250 : Closed e552925364250 ∧ code e552925364250 = 2751948619802 := by decide
theorem cert_e552925364250 : check e552925364250 [[]] .width = true := by decide
def e552925364342 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552925364342 : Closed e552925364342 ∧ code e552925364342 = 2751948619894 := by decide
theorem cert_e552925364342 : check e552925364342 [[]] .width = true := by decide
def e552925364586 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552925364586 : Closed e552925364586 ∧ code e552925364586 = 2751948620138 := by decide
theorem cert_e552925364586 : check e552925364586 [[]] .width = true := by decide
def e552925364634 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552925364634 : Closed e552925364634 ∧ code e552925364634 = 2751948620186 := by decide
theorem cert_e552925364634 : check e552925364634 [[]] .width = true := by decide
def e552925365642 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552925365642 : Closed e552925365642 ∧ code e552925365642 = 2751948621194 := by decide
theorem cert_e552925365642 : check e552925365642 [[]] .width = true := by decide
def e552925365666 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552925365666 : Closed e552925365666 ∧ code e552925365666 = 2751948621218 := by decide
theorem cert_e552925365666 : check e552925365666 [[]] .width = true := by decide
def e552925365774 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552925365774 : Closed e552925365774 ∧ code e552925365774 = 2751948621326 := by decide
theorem cert_e552925365774 : check e552925365774 [[]] .width = true := by decide
def e552925365786 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552925365786 : Closed e552925365786 ∧ code e552925365786 = 2751948621338 := by decide
theorem cert_e552925365786 : check e552925365786 [[]] .width = true := by decide
def e552925365858 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552925365858 : Closed e552925365858 ∧ code e552925365858 = 2751948621410 := by decide
theorem cert_e552925365858 : check e552925365858 [[]] .width = true := by decide
def e552925556250 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925556250 : Closed e552925556250 ∧ code e552925556250 = 2751948811802 := by decide
theorem cert_e552925556250 : check e552925556250 [[]] .width = true := by decide
def e552925559322 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925559322 : Closed e552925559322 ∧ code e552925559322 = 2751948814874 := by decide
theorem cert_e552925559322 : check e552925559322 [[]] .width = true := by decide
def e552925560858 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552925560858 : Closed e552925560858 ∧ code e552925560858 = 2751948816410 := by decide
theorem cert_e552925560858 : check e552925560858 [[]] .width = true := by decide
def e552925560950 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552925560950 : Closed e552925560950 ∧ code e552925560950 = 2751948816502 := by decide
theorem cert_e552925560950 : check e552925560950 [[]] .width = true := by decide
def e552925561194 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552925561194 : Closed e552925561194 ∧ code e552925561194 = 2751948816746 := by decide
theorem cert_e552925561194 : check e552925561194 [[]] .width = true := by decide
def e552925561242 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552925561242 : Closed e552925561242 ∧ code e552925561242 = 2751948816794 := by decide
theorem cert_e552925561242 : check e552925561242 [[]] .width = true := by decide
def e552925562250 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552925562250 : Closed e552925562250 ∧ code e552925562250 = 2751948817802 := by decide
theorem cert_e552925562250 : check e552925562250 [[]] .width = true := by decide
def e552925562274 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552925562274 : Closed e552925562274 ∧ code e552925562274 = 2751948817826 := by decide
theorem cert_e552925562274 : check e552925562274 [[]] .width = true := by decide
def e552925562382 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552925562382 : Closed e552925562382 ∧ code e552925562382 = 2751948817934 := by decide
theorem cert_e552925562382 : check e552925562382 [[]] .width = true := by decide
def e552925562394 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552925562394 : Closed e552925562394 ∧ code e552925562394 = 2751948817946 := by decide
theorem cert_e552925562394 : check e552925562394 [[]] .width = true := by decide
def e552925562466 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552925562466 : Closed e552925562466 ∧ code e552925562466 = 2751948818018 := by decide
theorem cert_e552925562466 : check e552925562466 [[]] .width = true := by decide
def e552925883930 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925883930 : Closed e552925883930 ∧ code e552925883930 = 2751949139482 := by decide
theorem cert_e552925883930 : check e552925883930 [[]] .width = true := by decide
def e552925885978 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925885978 : Closed e552925885978 ∧ code e552925885978 = 2751949141530 := by decide
theorem cert_e552925885978 : check e552925885978 [[]] .width = true := by decide
def e552925900314 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925900314 : Closed e552925900314 ∧ code e552925900314 = 2751949155866 := by decide
theorem cert_e552925900314 : check e552925900314 [[]] .width = true := by decide
def e552925903386 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925903386 : Closed e552925903386 ∧ code e552925903386 = 2751949158938 := by decide
theorem cert_e552925903386 : check e552925903386 [[]] .width = true := by decide
def e552925910554 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925910554 : Closed e552925910554 ∧ code e552925910554 = 2751949166106 := by decide
theorem cert_e552925910554 : check e552925910554 [[]] .width = true := by decide
def e552925911578 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925911578 : Closed e552925911578 ∧ code e552925911578 = 2751949167130 := by decide
theorem cert_e552925911578 : check e552925911578 [[]] .width = true := by decide
def e552925982234 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925982234 : Closed e552925982234 ∧ code e552925982234 = 2751949237786 := by decide
theorem cert_e552925982234 : check e552925982234 [[]] .width = true := by decide
def e552925984282 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552925984282 : Closed e552925984282 ∧ code e552925984282 = 2751949239834 := by decide
theorem cert_e552925984282 : check e552925984282 [[]] .width = true := by decide
def e552926019610 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552926019610 : Closed e552926019610 ∧ code e552926019610 = 2751949275162 := by decide
theorem cert_e552926019610 : check e552926019610 [[]] .width = true := by decide
def e552926019702 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552926019702 : Closed e552926019702 ∧ code e552926019702 = 2751949275254 := by decide
theorem cert_e552926019702 : check e552926019702 [[]] .width = true := by decide
def e552926019946 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552926019946 : Closed e552926019946 ∧ code e552926019946 = 2751949275498 := by decide
theorem cert_e552926019946 : check e552926019946 [[]] .width = true := by decide
def e552926019994 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552926019994 : Closed e552926019994 ∧ code e552926019994 = 2751949275546 := by decide
theorem cert_e552926019994 : check e552926019994 [[]] .width = true := by decide
end Blc.Floor41
