import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605649570774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605649570774 : Closed e605649570774 ∧ code e605649570774 = 2804672826326 := by decide
theorem cert_e605649570774 : check e605649570774 [[],[]] .chain = true := by decide
def e605649570778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605649570778 : Closed e605649570778 ∧ code e605649570778 = 2804672826330 := by decide
theorem cert_e605649570778 : check e605649570778 [[],[]] .chain = true := by decide
def e605649571054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605649571054 : Closed e605649571054 ∧ code e605649571054 = 2804672826606 := by decide
theorem cert_e605649571054 : check e605649571054 [[],[]] .chain = true := by decide
def e605649571062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605649571062 : Closed e605649571062 ∧ code e605649571062 = 2804672826614 := by decide
theorem cert_e605649571062 : check e605649571062 [[],[]] .chain = true := by decide
def e605649571390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e605649571390 : Closed e605649571390 ∧ code e605649571390 = 2804672826942 := by decide
theorem cert_e605649571390 : check e605649571390 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649571438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605649571438 : Closed e605649571438 ∧ code e605649571438 = 2804672826990 := by decide
theorem cert_e605649571438 : check e605649571438 [[],[]] .chain = true := by decide
def e605649571450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605649571450 : Closed e605649571450 ∧ code e605649571450 = 2804672827002 := by decide
theorem cert_e605649571450 : check e605649571450 [[],[]] .chain = true := by decide
def e605649571638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605649571638 : Closed e605649571638 ∧ code e605649571638 = 2804672827190 := by decide
theorem cert_e605649571638 : check e605649571638 [[],[]] .chain = true := by decide
def e605649571642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605649571642 : Closed e605649571642 ∧ code e605649571642 = 2804672827194 := by decide
theorem cert_e605649571642 : check e605649571642 [[],[]] .chain = true := by decide
def e605649571726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e605649571726 : Closed e605649571726 ∧ code e605649571726 = 2804672827278 := by decide
theorem cert_e605649571726 : check e605649571726 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649579118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605649579118 : Closed e605649579118 ∧ code e605649579118 = 2804672834670 := by decide
theorem cert_e605649579118 : check e605649579118 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649579130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605649579130 : Closed e605649579130 ∧ code e605649579130 = 2804672834682 := by decide
theorem cert_e605649579130 : check e605649579130 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649579294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605649579294 : Closed e605649579294 ∧ code e605649579294 = 2804672834846 := by decide
theorem cert_e605649579294 : check e605649579294 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649579462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605649579462 : Closed e605649579462 ∧ code e605649579462 = 2804672835014 := by decide
theorem cert_e605649579462 : check e605649579462 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649579802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e605649579802 : Closed e605649579802 ∧ code e605649579802 = 2804672835354 := by decide
theorem cert_e605649579802 : check e605649579802 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649579846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e605649579846 : Closed e605649579846 ∧ code e605649579846 = 2804672835398 := by decide
theorem cert_e605649579846 : check e605649579846 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649580254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e605649580254 : Closed e605649580254 ∧ code e605649580254 = 2804672835806 := by decide
theorem cert_e605649580254 : check e605649580254 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649580282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e605649580282 : Closed e605649580282 ∧ code e605649580282 = 2804672835834 := by decide
theorem cert_e605649580282 : check e605649580282 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649580830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605649580830 : Closed e605649580830 ∧ code e605649580830 = 2804672836382 := by decide
theorem cert_e605649580830 : check e605649580830 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649580998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605649580998 : Closed e605649580998 ∧ code e605649580998 = 2804672836550 := by decide
theorem cert_e605649580998 : check e605649580998 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649583158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e605649583158 : Closed e605649583158 ∧ code e605649583158 = 2804672838710 := by decide
theorem cert_e605649583158 : check e605649583158 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649583162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e605649583162 : Closed e605649583162 ∧ code e605649583162 = 2804672838714 := by decide
theorem cert_e605649583162 : check e605649583162 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649583302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e605649583302 : Closed e605649583302 ∧ code e605649583302 = 2804672838854 := by decide
theorem cert_e605649583302 : check e605649583302 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e605649602334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605649602334 : Closed e605649602334 ∧ code e605649602334 = 2804672857886 := by decide
theorem cert_e605649602334 : check e605649602334 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605649602446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605649602446 : Closed e605649602446 ∧ code e605649602446 = 2804672857998 := by decide
theorem cert_e605649602446 : check e605649602446 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605649606198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605649606198 : Closed e605649606198 ∧ code e605649606198 = 2804672861750 := by decide
theorem cert_e605649606198 : check e605649606198 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605649606202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605649606202 : Closed e605649606202 ∧ code e605649606202 = 2804672861754 := by decide
theorem cert_e605649606202 : check e605649606202 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605649606286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605649606286 : Closed e605649606286 ∧ code e605649606286 = 2804672861838 := by decide
private def t_e605649606286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem cert_e605649606286 : ¬ IsSelfInterpreter e605649606286 :=
  wSource (t := t_e605649606286) (replay_sound (ps := []) (t := e605649606286) (by decide)) (by decide)
def e605649606342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605649606342 : Closed e605649606342 ∧ code e605649606342 = 2804672861894 := by decide
theorem cert_e605649606342 : check e605649606342 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605649606426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e605649606426 : Closed e605649606426 ∧ code e605649606426 = 2804672861978 := by decide
theorem cert_e605649606426 : check e605649606426 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605649606470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e605649606470 : Closed e605649606470 ∧ code e605649606470 = 2804672862022 := by decide
theorem cert_e605649606470 : check e605649606470 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605649606766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e605649606766 : Closed e605649606766 ∧ code e605649606766 = 2804672862318 := by decide
theorem cert_e605649606766 : check e605649606766 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605649606778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e605649606778 : Closed e605649606778 ∧ code e605649606778 = 2804672862330 := by decide
theorem cert_e605649606778 : check e605649606778 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605649607054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605649607054 : Closed e605649607054 ∧ code e605649607054 = 2804672862606 := by decide
theorem cert_e605649607054 : check e605649607054 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605649607110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605649607110 : Closed e605649607110 ∧ code e605649607110 = 2804672862662 := by decide
theorem cert_e605649607110 : check e605649607110 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605649607734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e605649607734 : Closed e605649607734 ∧ code e605649607734 = 2804672863286 := by decide
theorem cert_e605649607734 : check e605649607734 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605649607738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e605649607738 : Closed e605649607738 ∧ code e605649607738 = 2804672863290 := by decide
theorem cert_e605649607738 : check e605649607738 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605649607878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e605649607878 : Closed e605649607878 ∧ code e605649607878 = 2804672863430 := by decide
theorem cert_e605649607878 : check e605649607878 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e605650687710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605650687710 : Closed e605650687710 ∧ code e605650687710 = 2804673943262 := by decide
theorem cert_e605650687710 : checkPay e605650687710 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650687734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605650687734 : Closed e605650687734 ∧ code e605650687734 = 2804673943286 := by decide
theorem cert_e605650687734 : checkPay e605650687734 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650687838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605650687838 : Closed e605650687838 ∧ code e605650687838 = 2804673943390 := by decide
theorem cert_e605650687838 : checkPay e605650687838 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650687866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605650687866 : Closed e605650687866 ∧ code e605650687866 = 2804673943418 := by decide
theorem cert_e605650687866 : checkPay e605650687866 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650687958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605650687958 : Closed e605650687958 ∧ code e605650687958 = 2804673943510 := by decide
theorem cert_e605650687958 : checkPay e605650687958 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under,.left],[.under,.under]] = true := by decide
def e605650687962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605650687962 : Closed e605650687962 ∧ code e605650687962 = 2804673943514 := by decide
theorem cert_e605650687962 : checkPay e605650687962 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under,.left],[.under,.under]] = true := by decide
def e605650688478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605650688478 : Closed e605650688478 ∧ code e605650688478 = 2804673944030 := by decide
theorem cert_e605650688478 : checkPay e605650688478 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650688502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605650688502 : Closed e605650688502 ∧ code e605650688502 = 2804673944054 := by decide
theorem cert_e605650688502 : checkPay e605650688502 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under,.right]] = true := by decide
def e605650689246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605650689246 : Closed e605650689246 ∧ code e605650689246 = 2804673944798 := by decide
theorem cert_e605650689246 : checkPay e605650689246 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650689274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605650689274 : Closed e605650689274 ∧ code e605650689274 = 2804673944826 := by decide
theorem cert_e605650689274 : checkPay e605650689274 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under,.right]] = true := by decide
def e605650689846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605650689846 : Closed e605650689846 ∧ code e605650689846 = 2804673945398 := by decide
theorem cert_e605650689846 : checkPay e605650689846 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under]] = true := by decide
def e605650689850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605650689850 : Closed e605650689850 ∧ code e605650689850 = 2804673945402 := by decide
theorem cert_e605650689850 : checkPay e605650689850 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under]] = true := by decide
def e605650704622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605650704622 : Closed e605650704622 ∧ code e605650704622 = 2804673960174 := by decide
theorem cert_e605650704622 : checkPay e605650704622 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650704630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605650704630 : Closed e605650704630 ∧ code e605650704630 = 2804673960182 := by decide
theorem cert_e605650704630 : checkPay e605650704630 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650705182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605650705182 : Closed e605650705182 ∧ code e605650705182 = 2804673960734 := by decide
theorem cert_e605650705182 : checkPay e605650705182 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650705294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605650705294 : Closed e605650705294 ∧ code e605650705294 = 2804673960846 := by decide
theorem cert_e605650705294 : checkPay e605650705294 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650705518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605650705518 : Closed e605650705518 ∧ code e605650705518 = 2804673961070 := by decide
theorem cert_e605650705518 : checkPay e605650705518 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650705530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605650705530 : Closed e605650705530 ∧ code e605650705530 = 2804673961082 := by decide
theorem cert_e605650705530 : checkPay e605650705530 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650705694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605650705694 : Closed e605650705694 ∧ code e605650705694 = 2804673961246 := by decide
theorem cert_e605650705694 : checkPay e605650705694 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650705862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605650705862 : Closed e605650705862 ∧ code e605650705862 = 2804673961414 := by decide
theorem cert_e605650705862 : checkPay e605650705862 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650705974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605650705974 : Closed e605650705974 ∧ code e605650705974 = 2804673961526 := by decide
theorem cert_e605650705974 : checkPay e605650705974 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left],[.under],[.under]] = true := by decide
def e605650705978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605650705978 : Closed e605650705978 ∧ code e605650705978 = 2804673961530 := by decide
theorem cert_e605650705978 : checkPay e605650705978 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left],[.under],[.under]] = true := by decide
def e605650706062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605650706062 : Closed e605650706062 ∧ code e605650706062 = 2804673961614 := by decide
theorem cert_e605650706062 : checkPay e605650706062 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left],[.under],[.under,.right]] = true := by decide
def e605650706118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605650706118 : Closed e605650706118 ∧ code e605650706118 = 2804673961670 := by decide
theorem cert_e605650706118 : checkPay e605650706118 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.left],[.under],[.under,.right]] = true := by decide
def e605650708254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605650708254 : Closed e605650708254 ∧ code e605650708254 = 2804673963806 := by decide
theorem cert_e605650708254 : checkPay e605650708254 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650708366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605650708366 : Closed e605650708366 ∧ code e605650708366 = 2804673963918 := by decide
theorem cert_e605650708366 : checkPay e605650708366 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right],[.under,.right,.under]] = true := by decide
def e605650711326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605650711326 : Closed e605650711326 ∧ code e605650711326 = 2804673966878 := by decide
theorem cert_e605650711326 : checkPay e605650711326 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605650711494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605650711494 : Closed e605650711494 ∧ code e605650711494 = 2804673967046 := by decide
theorem cert_e605650711494 : checkPay e605650711494 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.right],[.under,.right,.under]] = true := by decide
def e605650712974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605650712974 : Closed e605650712974 ∧ code e605650712974 = 2804673968526 := by decide
theorem cert_e605650712974 : checkPay e605650712974 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e605650713030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605650713030 : Closed e605650713030 ∧ code e605650713030 = 2804673968582 := by decide
theorem cert_e605650713030 : checkPay e605650713030 [[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e605650946926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605650946926 : Closed e605650946926 ∧ code e605650946926 = 2804674202478 := by decide
theorem cert_e605650946926 : check e605650946926 [[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e605650946934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605650946934 : Closed e605650946934 ∧ code e605650946934 = 2804674202486 := by decide
theorem cert_e605650946934 : check e605650946934 [[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e605650946990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605650946990 : Closed e605650946990 ∧ code e605650946990 = 2804674202542 := by decide
theorem cert_e605650946990 : check e605650946990 [[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e605650947002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605650947002 : Closed e605650947002 ∧ code e605650947002 = 2804674202554 := by decide
theorem cert_e605650947002 : check e605650947002 [[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e605650947030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605650947030 : Closed e605650947030 ∧ code e605650947030 = 2804674202582 := by decide
theorem cert_e605650947030 : check e605650947030 [[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e605650947034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605650947034 : Closed e605650947034 ∧ code e605650947034 = 2804674202586 := by decide
theorem cert_e605650947034 : check e605650947034 [[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e605650947310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605650947310 : Closed e605650947310 ∧ code e605650947310 = 2804674202862 := by decide
theorem cert_e605650947310 : check e605650947310 [[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e605650947318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605650947318 : Closed e605650947318 ∧ code e605650947318 = 2804674202870 := by decide
theorem cert_e605650947318 : check e605650947318 [[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e605650947694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605650947694 : Closed e605650947694 ∧ code e605650947694 = 2804674203246 := by decide
theorem cert_e605650947694 : check e605650947694 [[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e605650947706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605650947706 : Closed e605650947706 ∧ code e605650947706 = 2804674203258 := by decide
theorem cert_e605650947706 : check e605650947706 [[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e605650947894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605650947894 : Closed e605650947894 ∧ code e605650947894 = 2804674203446 := by decide
theorem cert_e605650947894 : check e605650947894 [[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e605650947898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605650947898 : Closed e605650947898 ∧ code e605650947898 = 2804674203450 := by decide
theorem cert_e605650947898 : check e605650947898 [[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e605738240878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605738240878 : Closed e605738240878 ∧ code e605738240878 = 2804761496430 := by decide
theorem cert_e605738240878 : check e605738240878 [[],[]] .smaller = true := by decide
def e605738240886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605738240886 : Closed e605738240886 ∧ code e605738240886 = 2804761496438 := by decide
theorem cert_e605738240886 : check e605738240886 [[],[]] .smaller = true := by decide
def e605738240942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605738240942 : Closed e605738240942 ∧ code e605738240942 = 2804761496494 := by decide
theorem cert_e605738240942 : check e605738240942 [[],[]] .smaller = true := by decide
def e605738240954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605738240954 : Closed e605738240954 ∧ code e605738240954 = 2804761496506 := by decide
theorem cert_e605738240954 : check e605738240954 [[],[]] .smaller = true := by decide
def e605738240982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605738240982 : Closed e605738240982 ∧ code e605738240982 = 2804761496534 := by decide
theorem cert_e605738240982 : check e605738240982 [[],[]] .smaller = true := by decide
def e605738240986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605738240986 : Closed e605738240986 ∧ code e605738240986 = 2804761496538 := by decide
theorem cert_e605738240986 : check e605738240986 [[],[]] .smaller = true := by decide
def e605738241262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605738241262 : Closed e605738241262 ∧ code e605738241262 = 2804761496814 := by decide
theorem cert_e605738241262 : check e605738241262 [[],[]] .smaller = true := by decide
def e605738241270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605738241270 : Closed e605738241270 ∧ code e605738241270 = 2804761496822 := by decide
theorem cert_e605738241270 : check e605738241270 [[],[]] .smaller = true := by decide
def e605738241646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605738241646 : Closed e605738241646 ∧ code e605738241646 = 2804761497198 := by decide
theorem cert_e605738241646 : check e605738241646 [[],[]] .smaller = true := by decide
def e605738241658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605738241658 : Closed e605738241658 ∧ code e605738241658 = 2804761497210 := by decide
theorem cert_e605738241658 : check e605738241658 [[],[]] .smaller = true := by decide
def e605738241846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605738241846 : Closed e605738241846 ∧ code e605738241846 = 2804761497398 := by decide
theorem cert_e605738241846 : check e605738241846 [[],[]] .smaller = true := by decide
def e605738241850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605738241850 : Closed e605738241850 ∧ code e605738241850 = 2804761497402 := by decide
theorem cert_e605738241850 : check e605738241850 [[],[]] .smaller = true := by decide
def e605770790634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)) (.var 0))))
theorem wire_e605770790634 : Closed e605770790634 ∧ code e605770790634 = 2804794046186 := by decide
def e605770790762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)) (.var 0))))
theorem wire_e605770790762 : Closed e605770790762 ∧ code e605770790762 = 2804794046314 := by decide
def e605770791658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)) (.var 0))))
theorem wire_e605770791658 : Closed e605770791658 ∧ code e605770791658 = 2804794047210 := by decide
def e605770791850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)) (.var 0))))
theorem wire_e605770791850 : Closed e605770791850 ∧ code e605770791850 = 2804794047402 := by decide
private def t_e605770791850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)) (.var 0))))
theorem cert_e605770791850 : ¬ IsSelfInterpreter e605770791850 :=
  wSource (t := t_e605770791850) (replay_sound (ps := []) (t := e605770791850) (by decide)) (by decide)
def e605770792298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)) (.var 0))))
theorem wire_e605770792298 : Closed e605770792298 ∧ code e605770792298 = 2804794047850 := by decide
def e605770792362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)) (.var 0))))
theorem wire_e605770792362 : Closed e605770792362 ∧ code e605770792362 = 2804794047914 := by decide
private def t_e605770792362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)) (.var 0))))
theorem cert_e605770792362 : ¬ IsSelfInterpreter e605770792362 :=
  wSource (t := t_e605770792362) (replay_sound (ps := []) (t := e605770792362) (by decide)) (by decide)
def e605770796778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)) (.var 0))))
theorem wire_e605770796778 : Closed e605770796778 ∧ code e605770796778 = 2804794052330 := by decide
def e605770796906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)) (.var 0))))
theorem wire_e605770796906 : Closed e605770796906 ∧ code e605770796906 = 2804794052458 := by decide
def e605770802922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)) (.var 0))))
theorem wire_e605770802922 : Closed e605770802922 ∧ code e605770802922 = 2804794058474 := by decide
def e605770803114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)) (.var 0))))
theorem wire_e605770803114 : Closed e605770803114 ∧ code e605770803114 = 2804794058666 := by decide
def e605770806122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)) (.var 0))))
theorem wire_e605770806122 : Closed e605770806122 ∧ code e605770806122 = 2804794061674 := by decide
def e605770806186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)) (.var 0))))
theorem wire_e605770806186 : Closed e605770806186 ∧ code e605770806186 = 2804794061738 := by decide
def e605771804090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))
theorem wire_e605771804090 : Closed e605771804090 ∧ code e605771804090 = 2804795059642 := by decide
private def t_e605771804090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))
theorem cert_e605771804090 : ¬ IsSelfInterpreter e605771804090 :=
  wSource (t := t_e605771804090) (replay_sound (ps := []) (t := e605771804090) (by decide)) (by decide)
def e605771804122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))
theorem wire_e605771804122 : Closed e605771804122 ∧ code e605771804122 = 2804795059674 := by decide
private def t_e605771804122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))
theorem cert_e605771804122 : ¬ IsSelfInterpreter e605771804122 :=
  wSource (t := t_e605771804122) (replay_sound (ps := []) (t := e605771804122) (by decide)) (by decide)
def e605771804346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))
theorem wire_e605771804346 : Closed e605771804346 ∧ code e605771804346 = 2804795059898 := by decide
private def t_e605771804346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))
theorem cert_e605771804346 : ¬ IsSelfInterpreter e605771804346 :=
  wSource (t := t_e605771804346) (replay_sound (ps := []) (t := e605771804346) (by decide)) (by decide)
def e605771804394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem wire_e605771804394 : Closed e605771804394 ∧ code e605771804394 = 2804795059946 := by decide
private def t_e605771804394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem cert_e605771804394 : ¬ IsSelfInterpreter e605771804394 :=
  wSource (t := t_e605771804394) (replay_sound (ps := []) (t := e605771804394) (by decide)) (by decide)
def e605771804506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))
theorem wire_e605771804506 : Closed e605771804506 ∧ code e605771804506 = 2804795060058 := by decide
private def t_e605771804506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))
theorem cert_e605771804506 : ¬ IsSelfInterpreter e605771804506 :=
  wSource (t := t_e605771804506) (replay_sound (ps := []) (t := e605771804506) (by decide)) (by decide)
def e605771804522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem wire_e605771804522 : Closed e605771804522 ∧ code e605771804522 = 2804795060074 := by decide
private def t_e605771804522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem cert_e605771804522 : ¬ IsSelfInterpreter e605771804522 :=
  wSource (t := t_e605771804522) (replay_sound (ps := []) (t := e605771804522) (by decide)) (by decide)
def e605771805626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem wire_e605771805626 : Closed e605771805626 ∧ code e605771805626 = 2804795061178 := by decide
private def t_e605771805626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem cert_e605771805626 : ¬ IsSelfInterpreter e605771805626 :=
  wSource (t := t_e605771805626) (replay_sound (ps := []) (t := e605771805626) (by decide)) (by decide)
def e605771805658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem wire_e605771805658 : Closed e605771805658 ∧ code e605771805658 = 2804795061210 := by decide
private def t_e605771805658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem cert_e605771805658 : ¬ IsSelfInterpreter e605771805658 :=
  wSource (t := t_e605771805658) (replay_sound (ps := []) (t := e605771805658) (by decide)) (by decide)
def e605771807162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem wire_e605771807162 : Closed e605771807162 ∧ code e605771807162 = 2804795062714 := by decide
private def t_e605771807162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem cert_e605771807162 : ¬ IsSelfInterpreter e605771807162 :=
  wSource (t := t_e605771807162) (replay_sound (ps := []) (t := e605771807162) (by decide)) (by decide)
def e605771807210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem wire_e605771807210 : Closed e605771807210 ∧ code e605771807210 = 2804795062762 := by decide
private def t_e605771807210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem cert_e605771807210 : ¬ IsSelfInterpreter e605771807210 :=
  wSource (t := t_e605771807210) (replay_sound (ps := []) (t := e605771807210) (by decide)) (by decide)
def e605771807962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem wire_e605771807962 : Closed e605771807962 ∧ code e605771807962 = 2804795063514 := by decide
private def t_e605771807962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem cert_e605771807962 : ¬ IsSelfInterpreter e605771807962 :=
  wSource (t := t_e605771807962) (replay_sound (ps := []) (t := e605771807962) (by decide)) (by decide)
def e605771807978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem wire_e605771807978 : Closed e605771807978 ∧ code e605771807978 = 2804795063530 := by decide
private def t_e605771807978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem cert_e605771807978 : ¬ IsSelfInterpreter e605771807978 :=
  wSource (t := t_e605771807978) (replay_sound (ps := []) (t := e605771807978) (by decide)) (by decide)
def e605772057454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605772057454 : Closed e605772057454 ∧ code e605772057454 = 2804795313006 := by decide
private def t_e605772057454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem cert_e605772057454 : ¬ IsSelfInterpreter e605772057454 :=
  wSource (t := t_e605772057454) (replay_sound (ps := []) (t := e605772057454) (by decide)) (by decide)
def e605772057462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605772057462 : Closed e605772057462 ∧ code e605772057462 = 2804795313014 := by decide
private def t_e605772057462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e605772057462 : ¬ IsSelfInterpreter e605772057462 :=
  wSource (t := t_e605772057462) (replay_sound (ps := []) (t := e605772057462) (by decide)) (by decide)
def e605772057518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605772057518 : Closed e605772057518 ∧ code e605772057518 = 2804795313070 := by decide
private def t_e605772057518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem cert_e605772057518 : ¬ IsSelfInterpreter e605772057518 :=
  wSource (t := t_e605772057518) (replay_sound (ps := []) (t := e605772057518) (by decide)) (by decide)
def e605772057530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605772057530 : Closed e605772057530 ∧ code e605772057530 = 2804795313082 := by decide
private def t_e605772057530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e605772057530 : ¬ IsSelfInterpreter e605772057530 :=
  wSource (t := t_e605772057530) (replay_sound (ps := []) (t := e605772057530) (by decide)) (by decide)
def e605772057558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605772057558 : Closed e605772057558 ∧ code e605772057558 = 2804795313110 := by decide
private def t_e605772057558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e605772057558 : ¬ IsSelfInterpreter e605772057558 :=
  wSource (t := t_e605772057558) (replay_sound (ps := []) (t := e605772057558) (by decide)) (by decide)
def e605772057562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605772057562 : Closed e605772057562 ∧ code e605772057562 = 2804795313114 := by decide
private def t_e605772057562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e605772057562 : ¬ IsSelfInterpreter e605772057562 :=
  wSource (t := t_e605772057562) (replay_sound (ps := []) (t := e605772057562) (by decide)) (by decide)
def e605772057838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605772057838 : Closed e605772057838 ∧ code e605772057838 = 2804795313390 := by decide
private def t_e605772057838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem cert_e605772057838 : ¬ IsSelfInterpreter e605772057838 :=
  wSource (t := t_e605772057838) (replay_sound (ps := []) (t := e605772057838) (by decide)) (by decide)
def e605772057846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605772057846 : Closed e605772057846 ∧ code e605772057846 = 2804795313398 := by decide
private def t_e605772057846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem cert_e605772057846 : ¬ IsSelfInterpreter e605772057846 :=
  wSource (t := t_e605772057846) (replay_sound (ps := []) (t := e605772057846) (by decide)) (by decide)
def e605772058222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605772058222 : Closed e605772058222 ∧ code e605772058222 = 2804795313774 := by decide
private def t_e605772058222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem cert_e605772058222 : ¬ IsSelfInterpreter e605772058222 :=
  wSource (t := t_e605772058222) (replay_sound (ps := []) (t := e605772058222) (by decide)) (by decide)
def e605772058234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605772058234 : Closed e605772058234 ∧ code e605772058234 = 2804795313786 := by decide
private def t_e605772058234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem cert_e605772058234 : ¬ IsSelfInterpreter e605772058234 :=
  wSource (t := t_e605772058234) (replay_sound (ps := []) (t := e605772058234) (by decide)) (by decide)
def e605772058422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605772058422 : Closed e605772058422 ∧ code e605772058422 = 2804795313974 := by decide
private def t_e605772058422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem cert_e605772058422 : ¬ IsSelfInterpreter e605772058422 :=
  wSource (t := t_e605772058422) (replay_sound (ps := []) (t := e605772058422) (by decide)) (by decide)
def e605772058426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605772058426 : Closed e605772058426 ∧ code e605772058426 = 2804795313978 := by decide
private def t_e605772058426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem cert_e605772058426 : ¬ IsSelfInterpreter e605772058426 :=
  wSource (t := t_e605772058426) (replay_sound (ps := []) (t := e605772058426) (by decide)) (by decide)
def e605774949818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0))))
theorem wire_e605774949818 : Closed e605774949818 ∧ code e605774949818 = 2804798205370 := by decide
theorem cert_e605774949818 : check e605774949818 [[],[],[.left]] .chain = true := by decide
def e605774949850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0))))
theorem wire_e605774949850 : Closed e605774949850 ∧ code e605774949850 = 2804798205402 := by decide
theorem cert_e605774949850 : check e605774949850 [[],[],[.left]] .chain = true := by decide
def e605774950074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0))))
theorem wire_e605774950074 : Closed e605774950074 ∧ code e605774950074 = 2804798205626 := by decide
theorem cert_e605774950074 : check e605774950074 [[],[],[.left]] .chain = true := by decide
def e605774950122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))))
theorem wire_e605774950122 : Closed e605774950122 ∧ code e605774950122 = 2804798205674 := by decide
theorem cert_e605774950122 : check e605774950122 [[],[],[.left]] .chain = true := by decide
def e605774950234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0))))
theorem wire_e605774950234 : Closed e605774950234 ∧ code e605774950234 = 2804798205786 := by decide
theorem cert_e605774950234 : check e605774950234 [[],[],[.left]] .chain = true := by decide
def e605774950250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))))
theorem wire_e605774950250 : Closed e605774950250 ∧ code e605774950250 = 2804798205802 := by decide
theorem cert_e605774950250 : check e605774950250 [[],[],[.left]] .chain = true := by decide
def e605774951354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0))))
theorem wire_e605774951354 : Closed e605774951354 ∧ code e605774951354 = 2804798206906 := by decide
theorem cert_e605774951354 : check e605774951354 [[],[],[.left]] .chain = true := by decide
def e605774951386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0))))
theorem wire_e605774951386 : Closed e605774951386 ∧ code e605774951386 = 2804798206938 := by decide
theorem cert_e605774951386 : check e605774951386 [[],[],[.left]] .chain = true := by decide
def e605774952890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0))))
theorem wire_e605774952890 : Closed e605774952890 ∧ code e605774952890 = 2804798208442 := by decide
theorem cert_e605774952890 : check e605774952890 [[],[],[.left]] .chain = true := by decide
def e605774952938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0))))
theorem wire_e605774952938 : Closed e605774952938 ∧ code e605774952938 = 2804798208490 := by decide
theorem cert_e605774952938 : check e605774952938 [[],[],[.left]] .chain = true := by decide
def e605774953690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0))))
theorem wire_e605774953690 : Closed e605774953690 ∧ code e605774953690 = 2804798209242 := by decide
theorem cert_e605774953690 : check e605774953690 [[],[],[.left]] .chain = true := by decide
def e605774953706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0))))
theorem wire_e605774953706 : Closed e605774953706 ∧ code e605774953706 = 2804798209258 := by decide
theorem cert_e605774953706 : check e605774953706 [[],[],[.left]] .chain = true := by decide
def e605774985082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))) (.var 0))))
theorem wire_e605774985082 : Closed e605774985082 ∧ code e605774985082 = 2804798240634 := by decide
theorem cert_e605774985082 : check e605774985082 [[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e605774985146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))) (.var 0))))
theorem wire_e605774985146 : Closed e605774985146 ∧ code e605774985146 = 2804798240698 := by decide
def e605774986618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))) (.var 0))))
theorem wire_e605774986618 : Closed e605774986618 ∧ code e605774986618 = 2804798242170 := by decide
theorem cert_e605774986618 : check e605774986618 [[],[],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left]] .chain = true := by decide
def e605774986730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))) (.var 0))))
theorem wire_e605774986730 : Closed e605774986730 ∧ code e605774986730 = 2804798242282 := by decide
private def t_e605774986730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))) (.var 0))))
theorem cert_e605774986730 : ¬ IsSelfInterpreter e605774986730 :=
  wSource (t := t_e605774986730) (replay_sound (ps := []) (t := e605774986730) (by decide)) (by decide)
def e605774986938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e605774986938 : Closed e605774986938 ∧ code e605774986938 = 2804798242490 := by decide
def e605774986986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e605774986986 : Closed e605774986986 ∧ code e605774986986 = 2804798242538 := by decide
private def t_e605774986986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))) (.var 0))))
theorem cert_e605774986986 : ¬ IsSelfInterpreter e605774986986 :=
  wSource (t := t_e605774986986) (replay_sound (ps := []) (t := e605774986986) (by decide)) (by decide)
def e605774991226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))) (.var 0))))
theorem wire_e605774991226 : Closed e605774991226 ∧ code e605774991226 = 2804798246778 := by decide
theorem cert_e605774991226 : check e605774991226 [[],[],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e605774991290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))) (.var 0))))
theorem wire_e605774991290 : Closed e605774991290 ∧ code e605774991290 = 2804798246842 := by decide
theorem cert_e605774991290 : check e605774991290 [[],[],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .sourceHead = true := by decide
def e605775000442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))) (.var 0))))
theorem wire_e605775000442 : Closed e605775000442 ∧ code e605775000442 = 2804798255994 := by decide
theorem cert_e605775000442 : check e605775000442 [[],[],[.left],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605775000554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))) (.var 0))))
theorem wire_e605775000554 : Closed e605775000554 ∧ code e605775000554 = 2804798256106 := by decide
theorem cert_e605775000554 : check e605775000554 [[],[],[.left],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605775002042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e605775002042 : Closed e605775002042 ∧ code e605775002042 = 2804798257594 := by decide
def e605775002090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e605775002090 : Closed e605775002090 ∧ code e605775002090 = 2804798257642 := by decide
def e605775115706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))) (.var 0))))
theorem wire_e605775115706 : Closed e605775115706 ∧ code e605775115706 = 2804798371258 := by decide
def e605775115738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))) (.var 0))))
theorem wire_e605775115738 : Closed e605775115738 ∧ code e605775115738 = 2804798371290 := by decide
def e605775115962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) (.var 0))))
theorem wire_e605775115962 : Closed e605775115962 ∧ code e605775115962 = 2804798371514 := by decide
def e605775116010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))) (.var 0))))
theorem wire_e605775116010 : Closed e605775116010 ∧ code e605775116010 = 2804798371562 := by decide
def e605775116122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) (.var 0))))
theorem wire_e605775116122 : Closed e605775116122 ∧ code e605775116122 = 2804798371674 := by decide
def e605775116138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))) (.var 0))))
theorem wire_e605775116138 : Closed e605775116138 ∧ code e605775116138 = 2804798371690 := by decide
def e605775116986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))) (.var 0))))
theorem wire_e605775116986 : Closed e605775116986 ∧ code e605775116986 = 2804798372538 := by decide
def e605775117034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))) (.var 0))))
theorem wire_e605775117034 : Closed e605775117034 ∧ code e605775117034 = 2804798372586 := by decide
end Blc.Floor41
