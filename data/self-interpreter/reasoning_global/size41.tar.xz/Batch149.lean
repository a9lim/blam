import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e701157390978 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701157390978 : Closed e701157390978 ∧ code e701157390978 = 2900180646530 := by decide
theorem cert_e701157390978 : check e701157390978 [[.left],[.left]] .chain = true := by decide
def e701157391074 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701157391074 : Closed e701157391074 ∧ code e701157391074 = 2900180646626 := by decide
theorem cert_e701157391074 : check e701157391074 [[.left],[.left],[],[.under]] .three = true := by decide
def e701157391266 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701157391266 : Closed e701157391266 ∧ code e701157391266 = 2900180646818 := by decide
theorem cert_e701157391266 : check e701157391266 [[.left],[.left],[],[.under]] .three = true := by decide
def e701157391714 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e701157391714 : Closed e701157391714 ∧ code e701157391714 = 2900180647266 := by decide
theorem cert_e701157391714 : check e701157391714 [[.left],[.left],[],[.under]] .three = true := by decide
def e701157391778 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701157391778 : Closed e701157391778 ∧ code e701157391778 = 2900180647330 := by decide
theorem cert_e701157391778 : check e701157391778 [[.left],[.left],[],[.under]] .three = true := by decide
def e701157395842 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e701157395842 : Closed e701157395842 ∧ code e701157395842 = 2900180651394 := by decide
theorem cert_e701157395842 : check e701157395842 [[.left],[.left]] .chain = true := by decide
def e701157396098 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e701157396098 : Closed e701157396098 ∧ code e701157396098 = 2900180651650 := by decide
theorem cert_e701157396098 : check e701157396098 [[.left],[.left]] .chain = true := by decide
def e701157396194 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701157396194 : Closed e701157396194 ∧ code e701157396194 = 2900180651746 := by decide
theorem cert_e701157396194 : check e701157396194 [[.left],[.left],[],[.under]] .three = true := by decide
def e701157396322 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e701157396322 : Closed e701157396322 ∧ code e701157396322 = 2900180651874 := by decide
theorem cert_e701157396322 : check e701157396322 [[.left],[.left],[],[.under]] .three = true := by decide
def e701157398554 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e701157398554 : Closed e701157398554 ∧ code e701157398554 = 2900180654106 := by decide
theorem cert_e701157398554 : check e701157398554 [[.left]] .chain = true := by decide
def e701157402242 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e701157402242 : Closed e701157402242 ∧ code e701157402242 = 2900180657794 := by decide
theorem cert_e701157402242 : check e701157402242 [[.left],[.left]] .chain = true := by decide
def e701157402338 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701157402338 : Closed e701157402338 ∧ code e701157402338 = 2900180657890 := by decide
theorem cert_e701157402338 : check e701157402338 [[.left],[.left],[],[.under]] .three = true := by decide
def e701157402530 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701157402530 : Closed e701157402530 ∧ code e701157402530 = 2900180658082 := by decide
theorem cert_e701157402530 : check e701157402530 [[.left],[.left],[],[.under]] .three = true := by decide
def e701157402650 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e701157402650 : Closed e701157402650 ∧ code e701157402650 = 2900180658202 := by decide
theorem cert_e701157402650 : check e701157402650 [[.left]] .chain = true := by decide
def e701157405538 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e701157405538 : Closed e701157405538 ∧ code e701157405538 = 2900180661090 := by decide
theorem cert_e701157405538 : check e701157405538 [[.left],[.left],[],[.under]] .three = true := by decide
def e701157405602 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701157405602 : Closed e701157405602 ∧ code e701157405602 = 2900180661154 := by decide
theorem cert_e701157405602 : check e701157405602 [[.left],[.left],[],[.under]] .three = true := by decide
def e701166040802 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701166040802 : Closed e701166040802 ∧ code e701166040802 = 2900189296354 := by decide
theorem cert_e701166040802 : check e701166040802 [[.left],[.left]] .smaller = true := by decide
def e701166040930 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e701166040930 : Closed e701166040930 ∧ code e701166040930 = 2900189296482 := by decide
theorem cert_e701166040930 : check e701166040930 [[.left],[.left]] .smaller = true := by decide
def e701166041826 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701166041826 : Closed e701166041826 ∧ code e701166041826 = 2900189297378 := by decide
theorem cert_e701166041826 : check e701166041826 [[.left],[.left]] .smaller = true := by decide
def e701166042018 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701166042018 : Closed e701166042018 ∧ code e701166042018 = 2900189297570 := by decide
theorem cert_e701166042018 : check e701166042018 [[.left],[.left]] .smaller = true := by decide
def e701166042466 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e701166042466 : Closed e701166042466 ∧ code e701166042466 = 2900189298018 := by decide
theorem cert_e701166042466 : check e701166042466 [[.left],[.left]] .smaller = true := by decide
def e701166042530 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701166042530 : Closed e701166042530 ∧ code e701166042530 = 2900189298082 := by decide
theorem cert_e701166042530 : check e701166042530 [[.left],[.left]] .smaller = true := by decide
def e701166046946 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.var 0)))
theorem wire_e701166046946 : Closed e701166046946 ∧ code e701166046946 = 2900189302498 := by decide
theorem cert_e701166046946 : check e701166046946 [[.left],[.left]] .smaller = true := by decide
def e701166047074 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e701166047074 : Closed e701166047074 ∧ code e701166047074 = 2900189302626 := by decide
theorem cert_e701166047074 : check e701166047074 [[.left],[.left]] .smaller = true := by decide
def e701166053090 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.var 0)))
theorem wire_e701166053090 : Closed e701166053090 ∧ code e701166053090 = 2900189308642 := by decide
theorem cert_e701166053090 : check e701166053090 [[.left],[.left]] .smaller = true := by decide
def e701166053282 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e701166053282 : Closed e701166053282 ∧ code e701166053282 = 2900189308834 := by decide
theorem cert_e701166053282 : check e701166053282 [[.left],[.left]] .smaller = true := by decide
def e701166056290 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.var 0)))
theorem wire_e701166056290 : Closed e701166056290 ∧ code e701166056290 = 2900189311842 := by decide
theorem cert_e701166056290 : check e701166056290 [[.left],[.left]] .smaller = true := by decide
def e701166056354 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.var 0)))
theorem wire_e701166056354 : Closed e701166056354 ∧ code e701166056354 = 2900189311906 := by decide
theorem cert_e701166056354 : check e701166056354 [[.left],[.left]] .smaller = true := by decide
def e701166181250 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e701166181250 : Closed e701166181250 ∧ code e701166181250 = 2900189436802 := by decide
theorem cert_e701166181250 : check e701166181250 [[.left],[.left]] .chain = true := by decide
def e701166181762 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e701166181762 : Closed e701166181762 ∧ code e701166181762 = 2900189437314 := by decide
theorem cert_e701166181762 : check e701166181762 [[.left],[.left]] .chain = true := by decide
def e701166185346 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e701166185346 : Closed e701166185346 ∧ code e701166185346 = 2900189440898 := by decide
theorem cert_e701166185346 : check e701166185346 [[.left],[.left]] .chain = true := by decide
def e701166186114 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701166186114 : Closed e701166186114 ∧ code e701166186114 = 2900189441666 := by decide
theorem cert_e701166186114 : check e701166186114 [[.left],[.left]] .chain = true := by decide
def e701166187906 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e701166187906 : Closed e701166187906 ∧ code e701166187906 = 2900189443458 := by decide
theorem cert_e701166187906 : check e701166187906 [[.left],[.left]] .chain = true := by decide
def e701166188162 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701166188162 : Closed e701166188162 ∧ code e701166188162 = 2900189443714 := by decide
theorem cert_e701166188162 : check e701166188162 [[.left],[.left]] .chain = true := by decide
def e701166205826 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.var 0))))
theorem wire_e701166205826 : Closed e701166205826 ∧ code e701166205826 = 2900189461378 := by decide
theorem cert_e701166205826 : check e701166205826 [[.left],[.left]] .chain = true := by decide
def e701166206338 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e701166206338 : Closed e701166206338 ∧ code e701166206338 = 2900189461890 := by decide
theorem cert_e701166206338 : check e701166206338 [[.left],[.left]] .chain = true := by decide
def e701166230402 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.var 0))))
theorem wire_e701166230402 : Closed e701166230402 ∧ code e701166230402 = 2900189485954 := by decide
theorem cert_e701166230402 : check e701166230402 [[.left],[.left]] .chain = true := by decide
def e701166231170 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e701166231170 : Closed e701166231170 ∧ code e701166231170 = 2900189486722 := by decide
theorem cert_e701166231170 : check e701166231170 [[.left],[.left]] .chain = true := by decide
def e701166243202 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e701166243202 : Closed e701166243202 ∧ code e701166243202 = 2900189498754 := by decide
theorem cert_e701166243202 : check e701166243202 [[.left],[.left]] .chain = true := by decide
def e701166243458 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e701166243458 : Closed e701166243458 ∧ code e701166243458 = 2900189499010 := by decide
theorem cert_e701166243458 : check e701166243458 [[.left],[.left]] .chain = true := by decide
def e701167045486 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))
theorem wire_e701167045486 : Closed e701167045486 ∧ code e701167045486 = 2900190301038 := by decide
theorem cert_e701167045486 : check e701167045486 [[.left],[.left]] .smaller = true := by decide
def e701167045494 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))
theorem wire_e701167045494 : Closed e701167045494 ∧ code e701167045494 = 2900190301046 := by decide
theorem cert_e701167045494 : check e701167045494 [[.left],[.left]] .smaller = true := by decide
def e701167045550 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))
theorem wire_e701167045550 : Closed e701167045550 ∧ code e701167045550 = 2900190301102 := by decide
theorem cert_e701167045550 : check e701167045550 [[.left],[.left]] .smaller = true := by decide
def e701167045562 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))
theorem wire_e701167045562 : Closed e701167045562 ∧ code e701167045562 = 2900190301114 := by decide
theorem cert_e701167045562 : check e701167045562 [[.left],[.left]] .smaller = true := by decide
def e701167045590 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))
theorem wire_e701167045590 : Closed e701167045590 ∧ code e701167045590 = 2900190301142 := by decide
theorem cert_e701167045590 : check e701167045590 [[.left],[.left]] .smaller = true := by decide
def e701167045594 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))
theorem wire_e701167045594 : Closed e701167045594 ∧ code e701167045594 = 2900190301146 := by decide
theorem cert_e701167045594 : check e701167045594 [[.left],[.left]] .smaller = true := by decide
def e701167045870 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))
theorem wire_e701167045870 : Closed e701167045870 ∧ code e701167045870 = 2900190301422 := by decide
theorem cert_e701167045870 : check e701167045870 [[.left],[.left]] .smaller = true := by decide
def e701167045878 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))
theorem wire_e701167045878 : Closed e701167045878 ∧ code e701167045878 = 2900190301430 := by decide
theorem cert_e701167045878 : check e701167045878 [[.left],[.left]] .smaller = true := by decide
def e701167046254 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))
theorem wire_e701167046254 : Closed e701167046254 ∧ code e701167046254 = 2900190301806 := by decide
theorem cert_e701167046254 : check e701167046254 [[.left],[.left]] .smaller = true := by decide
def e701167046266 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))
theorem wire_e701167046266 : Closed e701167046266 ∧ code e701167046266 = 2900190301818 := by decide
theorem cert_e701167046266 : check e701167046266 [[.left],[.left]] .smaller = true := by decide
def e701167046454 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))
theorem wire_e701167046454 : Closed e701167046454 ∧ code e701167046454 = 2900190302006 := by decide
theorem cert_e701167046454 : check e701167046454 [[.left],[.left]] .smaller = true := by decide
def e701167046458 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))
theorem wire_e701167046458 : Closed e701167046458 ∧ code e701167046458 = 2900190302010 := by decide
theorem cert_e701167046458 : check e701167046458 [[.left],[.left]] .smaller = true := by decide
def e701203929986 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e701203929986 : Closed e701203929986 ∧ code e701203929986 = 2900227185538 := by decide
theorem cert_e701203929986 : check e701203929986 [[.left],[.left],[.left],[.left],[],[.left]] .smaller = true := by decide
def e701203930498 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e701203930498 : Closed e701203930498 ∧ code e701203930498 = 2900227186050 := by decide
theorem cert_e701203930498 : check e701203930498 [[.left],[.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e701203934082 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.var 0))))
theorem wire_e701203934082 : Closed e701203934082 ∧ code e701203934082 = 2900227189634 := by decide
theorem cert_e701203934082 : check e701203934082 [[.left],[.left],[.left],[.left],[],[.left],[],[.left]] .chain = true := by decide
def e701203934850 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701203934850 : Closed e701203934850 ∧ code e701203934850 = 2900227190402 := by decide
private def t_e701203934850 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem cert_e701203934850 : ¬ IsSelfInterpreter e701203934850 :=
  wSource (t := t_e701203934850) (replay_sound (ps := []) (t := e701203934850) (by decide)) (by decide)
def e701203936642 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.var 0))))
theorem wire_e701203936642 : Closed e701203936642 ∧ code e701203936642 = 2900227192194 := by decide
theorem cert_e701203936642 : check e701203936642 [[.left],[.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e701203936898 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem wire_e701203936898 : Closed e701203936898 ∧ code e701203936898 = 2900227192450 := by decide
private def t_e701203936898 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.var 0))))
theorem cert_e701203936898 : ¬ IsSelfInterpreter e701203936898 :=
  wSource (t := t_e701203936898) (replay_sound (ps := []) (t := e701203936898) (by decide)) (by decide)
def e701203954562 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.var 0))))
theorem wire_e701203954562 : Closed e701203954562 ∧ code e701203954562 = 2900227210114 := by decide
theorem cert_e701203954562 : check e701203954562 [[.left],[.left],[.left],[.left],[],[]] .smaller = true := by decide
def e701203955074 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e701203955074 : Closed e701203955074 ∧ code e701203955074 = 2900227210626 := by decide
theorem cert_e701203955074 : check e701203955074 [[.left],[.left],[.left],[.left],[],[]] .smaller = true := by decide
def e701203979138 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.var 0))))
theorem wire_e701203979138 : Closed e701203979138 ∧ code e701203979138 = 2900227234690 := by decide
theorem cert_e701203979138 : check e701203979138 [[.left],[.left],[.left],[.left],[],[],[.under,.left]] .chain = true := by decide
def e701203979906 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e701203979906 : Closed e701203979906 ∧ code e701203979906 = 2900227235458 := by decide
theorem cert_e701203979906 : check e701203979906 [[.left],[.left],[.left],[.left],[],[],[.under,.left]] .chain = true := by decide
def e701203991938 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.var 0))))
theorem wire_e701203991938 : Closed e701203991938 ∧ code e701203991938 = 2900227247490 := by decide
theorem cert_e701203991938 : check e701203991938 [[.left],[.left],[.left],[.left],[],[],[.left]] .chain = true := by decide
def e701203992194 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.var 0))))
theorem wire_e701203992194 : Closed e701203992194 ∧ code e701203992194 = 2900227247746 := by decide
theorem cert_e701203992194 : check e701203992194 [[.left],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left]] .chain = true := by decide
def e701207939950 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e701207939950 : Closed e701207939950 ∧ code e701207939950 = 2900231195502 := by decide
private def t_e701207939950 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem cert_e701207939950 : ¬ IsSelfInterpreter e701207939950 :=
  wSource (t := t_e701207939950) (replay_sound (ps := []) (t := e701207939950) (by decide)) (by decide)
def e701207939958 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e701207939958 : Closed e701207939958 ∧ code e701207939958 = 2900231195510 := by decide
private def t_e701207939958 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e701207939958 : ¬ IsSelfInterpreter e701207939958 :=
  wSource (t := t_e701207939958) (replay_sound (ps := []) (t := e701207939958) (by decide)) (by decide)
def e701207940014 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e701207940014 : Closed e701207940014 ∧ code e701207940014 = 2900231195566 := by decide
private def t_e701207940014 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem cert_e701207940014 : ¬ IsSelfInterpreter e701207940014 :=
  wSource (t := t_e701207940014) (replay_sound (ps := []) (t := e701207940014) (by decide)) (by decide)
def e701207940026 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e701207940026 : Closed e701207940026 ∧ code e701207940026 = 2900231195578 := by decide
private def t_e701207940026 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e701207940026 : ¬ IsSelfInterpreter e701207940026 :=
  wSource (t := t_e701207940026) (replay_sound (ps := []) (t := e701207940026) (by decide)) (by decide)
def e701207940054 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e701207940054 : Closed e701207940054 ∧ code e701207940054 = 2900231195606 := by decide
private def t_e701207940054 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e701207940054 : ¬ IsSelfInterpreter e701207940054 :=
  wSource (t := t_e701207940054) (replay_sound (ps := []) (t := e701207940054) (by decide)) (by decide)
def e701207940058 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e701207940058 : Closed e701207940058 ∧ code e701207940058 = 2900231195610 := by decide
private def t_e701207940058 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e701207940058 : ¬ IsSelfInterpreter e701207940058 :=
  wSource (t := t_e701207940058) (replay_sound (ps := []) (t := e701207940058) (by decide)) (by decide)
def e701207940334 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e701207940334 : Closed e701207940334 ∧ code e701207940334 = 2900231195886 := by decide
private def t_e701207940334 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem cert_e701207940334 : ¬ IsSelfInterpreter e701207940334 :=
  wSource (t := t_e701207940334) (replay_sound (ps := []) (t := e701207940334) (by decide)) (by decide)
def e701207940342 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e701207940342 : Closed e701207940342 ∧ code e701207940342 = 2900231195894 := by decide
private def t_e701207940342 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem cert_e701207940342 : ¬ IsSelfInterpreter e701207940342 :=
  wSource (t := t_e701207940342) (replay_sound (ps := []) (t := e701207940342) (by decide)) (by decide)
def e701207940718 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e701207940718 : Closed e701207940718 ∧ code e701207940718 = 2900231196270 := by decide
private def t_e701207940718 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem cert_e701207940718 : ¬ IsSelfInterpreter e701207940718 :=
  wSource (t := t_e701207940718) (replay_sound (ps := []) (t := e701207940718) (by decide)) (by decide)
def e701207940730 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e701207940730 : Closed e701207940730 ∧ code e701207940730 = 2900231196282 := by decide
private def t_e701207940730 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem cert_e701207940730 : ¬ IsSelfInterpreter e701207940730 :=
  wSource (t := t_e701207940730) (replay_sound (ps := []) (t := e701207940730) (by decide)) (by decide)
def e701207940918 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e701207940918 : Closed e701207940918 ∧ code e701207940918 = 2900231196470 := by decide
private def t_e701207940918 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem cert_e701207940918 : ¬ IsSelfInterpreter e701207940918 :=
  wSource (t := t_e701207940918) (replay_sound (ps := []) (t := e701207940918) (by decide)) (by decide)
def e701207940922 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e701207940922 : Closed e701207940922 ∧ code e701207940922 = 2900231196474 := by decide
private def t_e701207940922 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem cert_e701207940922 : ¬ IsSelfInterpreter e701207940922 :=
  wSource (t := t_e701207940922) (replay_sound (ps := []) (t := e701207940922) (by decide)) (by decide)
end Blc.Floor41
