import R598355273194Data
namespace Certgen.R598355273194
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl144 : FloorIndex.rangeOK validState 144 10 = true := by decide +kernel
end Certgen.R598355273194
