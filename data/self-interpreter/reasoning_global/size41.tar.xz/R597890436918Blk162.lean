import R597890436918Data
namespace Certgen.R597890436918
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl1944 : FloorIndex.rangeOK validState 1944 12 = true := by decide +kernel
theorem bl1956 : FloorIndex.rangeOK validState 1956 12 = true := by decide +kernel
theorem bl1968 : FloorIndex.rangeOK validState 1968 12 = true := by decide +kernel
theorem bl1980 : FloorIndex.rangeOK validState 1980 12 = true := by decide +kernel
theorem bl1992 : FloorIndex.rangeOK validState 1992 12 = true := by decide +kernel
theorem bl2004 : FloorIndex.rangeOK validState 2004 12 = true := by decide +kernel
end Certgen.R597890436918
