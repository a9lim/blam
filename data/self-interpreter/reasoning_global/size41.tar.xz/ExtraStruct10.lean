import Extra41
import Batch044
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness598355261930
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.var 2
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private def u14 := Term.lam u1
private def u15 := Term.app u13 u14
theorem nege598355261930 : ¬ IsSelfInterpreter e598355261930 := by
  intro he
  have h : replay [] (.app e598355261930 diag) = some u15 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u15) (by decide) (by decide) hj
#print axioms nege598355261930
end Witness598355261930
namespace Witness598355262062
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.app u0 u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u2 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u1 u9
private def u11 := Term.app u2 u10
private def u12 := Term.lam u11
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.app u2 u14
private def u16 := Term.lam u15
private def u17 := Term.lam u16
private def u18 := Term.app u17 u9
private def u19 := Term.app u9 u9
private def u20 := Term.app u18 u19
theorem nege598355262062 : ¬ IsSelfInterpreter e598355262062 := by
  intro he
  have h : replay [[],[.left],[.left],[.left],[]] e598355262062 = some u20 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u20) (by decide) (by decide) hj
#print axioms nege598355262062
end Witness598355262062
namespace Witness598355262074
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.app u0 u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u2 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u1
private def u11 := Term.app u2 u10
private def u12 := Term.lam u11
private def u13 := Term.lam u12
private def u14 := Term.app u13 u1
private def u15 := Term.app u2 u14
private def u16 := Term.lam u15
private def u17 := Term.lam u16
private def u18 := Term.app u17 u9
private def u19 := Term.app u9 u9
private def u20 := Term.app u18 u19
theorem nege598355262074 : ¬ IsSelfInterpreter e598355262074 := by
  intro he
  have h : replay [[],[.left],[.left],[.left],[]] e598355262074 = some u20 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u20) (by decide) (by decide) hj
#print axioms nege598355262074
end Witness598355262074
namespace Witness598355262682
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private def u14 := Term.lam u1
private def u15 := Term.app u13 u14
theorem nege598355262682 : ¬ IsSelfInterpreter e598355262682 := by
  intro he
  have h : replay [] (.app e598355262682 diag) = some u15 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u15) (by decide) (by decide) hj
#print axioms nege598355262682
end Witness598355262682
namespace Witness598355262698
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private def u14 := Term.lam u1
private def u15 := Term.app u13 u14
theorem nege598355262698 : ¬ IsSelfInterpreter e598355262698 := by
  intro he
  have h : replay [] (.app e598355262698 diag) = some u15 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u15) (by decide) (by decide) hj
#print axioms nege598355262698
end Witness598355262698
namespace Witness598355262774
private def u0 := Term.var 0
private def u1 := Term.var 2
private def u2 := Term.app u1 u0
private def u3 := Term.var 1
private def u4 := Term.app u0 u3
private def u5 := Term.app u2 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u9 u0
private def u12 := Term.app u11 u4
private def u13 := Term.lam u12
private def u14 := Term.lam u13
private def u15 := Term.app u14 u0
private def u16 := Term.app u15 u4
private def u17 := Term.lam u16
private def u18 := Term.lam u17
private def u19 := Term.app u9 u18
private def u20 := Term.app u10 u19
theorem nege598355262774 : ¬ IsSelfInterpreter e598355262774 := by
  intro he
  have h : replay [[],[.left],[.left],[.left],[]] e598355262774 = some u20 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u20) (by decide) (by decide) hj
#print axioms nege598355262774
end Witness598355262774
namespace Witness598355262778
private def u0 := Term.var 0
private def u1 := Term.var 2
private def u2 := Term.app u1 u0
private def u3 := Term.var 1
private def u4 := Term.app u3 u0
private def u5 := Term.app u2 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u9 u0
private def u12 := Term.app u11 u4
private def u13 := Term.lam u12
private def u14 := Term.lam u13
private def u15 := Term.app u14 u0
private def u16 := Term.app u15 u4
private def u17 := Term.lam u16
private def u18 := Term.lam u17
private def u19 := Term.app u18 u9
private def u20 := Term.app u10 u19
theorem nege598355262778 : ¬ IsSelfInterpreter e598355262778 := by
  intro he
  have h : replay [[],[.left],[.left],[.left],[]] e598355262778 = some u20 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u20) (by decide) (by decide) hj
#print axioms nege598355262778
end Witness598355262778
namespace Witness598355266414
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.app u0 u4
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private def u14 := Term.lam u1
private def u15 := Term.app u13 u14
theorem nege598355266414 : ¬ IsSelfInterpreter e598355266414 := by
  intro he
  have h : replay [] (.app e598355266414 diag) = some u15 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u15) (by decide) (by decide) hj
#print axioms nege598355266414
end Witness598355266414
end Blc.Floor41
