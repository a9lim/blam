import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e597889847094 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e597889847094 : Closed e597889847094 ∧ code e597889847094 = 2796913102646 := by decide
theorem cert_e597889847094 : check e597889847094 [[],[.left],[],[]] .sourceHead = true := by decide
def e597889847098 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e597889847098 : Closed e597889847098 ∧ code e597889847098 = 2796913102650 := by decide
theorem cert_e597889847098 : check e597889847098 [[],[.left],[],[]] .sourceHead = true := by decide
def e597890435950 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e597890435950 : Closed e597890435950 ∧ code e597890435950 = 2796913691502 := by decide
def e597890435958 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e597890435958 : Closed e597890435958 ∧ code e597890435958 = 2796913691510 := by decide
def e597890436014 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e597890436014 : Closed e597890436014 ∧ code e597890436014 = 2796913691566 := by decide
def e597890436026 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e597890436026 : Closed e597890436026 ∧ code e597890436026 = 2796913691578 := by decide
private def t_e597890436026 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e597890436026 : ¬ IsSelfInterpreter e597890436026 :=
  wSource (t := t_e597890436026) (replay_sound (ps := []) (t := e597890436026) (by decide)) (by decide)
def e597890436054 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e597890436054 : Closed e597890436054 ∧ code e597890436054 = 2796913691606 := by decide
def e597890436058 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e597890436058 : Closed e597890436058 ∧ code e597890436058 = 2796913691610 := by decide
private def t_e597890436058 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e597890436058 : ¬ IsSelfInterpreter e597890436058 :=
  wSource (t := t_e597890436058) (replay_sound (ps := []) (t := e597890436058) (by decide)) (by decide)
def e597890436334 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e597890436334 : Closed e597890436334 ∧ code e597890436334 = 2796913691886 := by decide
def e597890436342 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e597890436342 : Closed e597890436342 ∧ code e597890436342 = 2796913691894 := by decide
def e597890436718 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e597890436718 : Closed e597890436718 ∧ code e597890436718 = 2796913692270 := by decide
def e597890436730 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e597890436730 : Closed e597890436730 ∧ code e597890436730 = 2796913692282 := by decide
def e597890436918 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e597890436918 : Closed e597890436918 ∧ code e597890436918 = 2796913692470 := by decide
def e597890436922 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e597890436922 : Closed e597890436922 ∧ code e597890436922 = 2796913692474 := by decide
def e598074945050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598074945050 : Closed e598074945050 ∧ code e598074945050 = 2797098200602 := by decide
private def t_e598074945050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598074945050 : ¬ IsSelfInterpreter e598074945050 :=
  wSource (t := t_e598074945050) (replay_sound (ps := []) (t := e598074945050) (by decide)) (by decide)
def e598074947098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598074947098 : Closed e598074947098 ∧ code e598074947098 = 2797098202650 := by decide
private def t_e598074947098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598074947098 : ¬ IsSelfInterpreter e598074947098 :=
  wSource (t := t_e598074947098) (replay_sound (ps := []) (t := e598074947098) (by decide)) (by decide)
def e598074961434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598074961434 : Closed e598074961434 ∧ code e598074961434 = 2797098216986 := by decide
private def t_e598074961434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598074961434 : ¬ IsSelfInterpreter e598074961434 :=
  wSource (t := t_e598074961434) (replay_sound (ps := []) (t := e598074961434) (by decide)) (by decide)
def e598074964506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598074964506 : Closed e598074964506 ∧ code e598074964506 = 2797098220058 := by decide
private def t_e598074964506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598074964506 : ¬ IsSelfInterpreter e598074964506 :=
  wSource (t := t_e598074964506) (replay_sound (ps := []) (t := e598074964506) (by decide)) (by decide)
def e598074971674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598074971674 : Closed e598074971674 ∧ code e598074971674 = 2797098227226 := by decide
private def t_e598074971674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598074971674 : ¬ IsSelfInterpreter e598074971674 :=
  wSource (t := t_e598074971674) (replay_sound (ps := []) (t := e598074971674) (by decide)) (by decide)
def e598074972698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598074972698 : Closed e598074972698 ∧ code e598074972698 = 2797098228250 := by decide
private def t_e598074972698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598074972698 : ¬ IsSelfInterpreter e598074972698 :=
  wSource (t := t_e598074972698) (replay_sound (ps := []) (t := e598074972698) (by decide)) (by decide)
def e598075043354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598075043354 : Closed e598075043354 ∧ code e598075043354 = 2797098298906 := by decide
private def t_e598075043354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598075043354 : ¬ IsSelfInterpreter e598075043354 :=
  wSource (t := t_e598075043354) (replay_sound (ps := []) (t := e598075043354) (by decide)) (by decide)
def e598075045402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598075045402 : Closed e598075045402 ∧ code e598075045402 = 2797098300954 := by decide
private def t_e598075045402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598075045402 : ¬ IsSelfInterpreter e598075045402 :=
  wSource (t := t_e598075045402) (replay_sound (ps := []) (t := e598075045402) (by decide)) (by decide)
def e598075141658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598075141658 : Closed e598075141658 ∧ code e598075141658 = 2797098397210 := by decide
private def t_e598075141658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598075141658 : ¬ IsSelfInterpreter e598075141658 :=
  wSource (t := t_e598075141658) (replay_sound (ps := []) (t := e598075141658) (by decide)) (by decide)
def e598075144730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598075144730 : Closed e598075144730 ∧ code e598075144730 = 2797098400282 := by decide
private def t_e598075144730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598075144730 : ¬ IsSelfInterpreter e598075144730 :=
  wSource (t := t_e598075144730) (replay_sound (ps := []) (t := e598075144730) (by decide)) (by decide)
def e598075192858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598075192858 : Closed e598075192858 ∧ code e598075192858 = 2797098448410 := by decide
private def t_e598075192858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598075192858 : ¬ IsSelfInterpreter e598075192858 :=
  wSource (t := t_e598075192858) (replay_sound (ps := []) (t := e598075192858) (by decide)) (by decide)
def e598075193882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598075193882 : Closed e598075193882 ∧ code e598075193882 = 2797098449434 := by decide
private def t_e598075193882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598075193882 : ¬ IsSelfInterpreter e598075193882 :=
  wSource (t := t_e598075193882) (replay_sound (ps := []) (t := e598075193882) (by decide)) (by decide)
def e598077192218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e598077192218 : Closed e598077192218 ∧ code e598077192218 = 2797100447770 := by decide
theorem cert_e598077192218 : check e598077192218 [[],[.left]] .smaller = true := by decide
def e598077200410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e598077200410 : Closed e598077200410 ∧ code e598077200410 = 2797100455962 := by decide
theorem cert_e598077200410 : check e598077200410 [[],[.left]] .smaller = true := by decide
def e598077201946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598077201946 : Closed e598077201946 ∧ code e598077201946 = 2797100457498 := by decide
private def t_e598077201946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598077201946 : ¬ IsSelfInterpreter e598077201946 :=
  wSource (t := t_e598077201946) (replay_sound (ps := []) (t := e598077201946) (by decide)) (by decide)
def e598077206042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598077206042 : Closed e598077206042 ∧ code e598077206042 = 2797100461594 := by decide
private def t_e598077206042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598077206042 : ¬ IsSelfInterpreter e598077206042 :=
  wSource (t := t_e598077206042) (replay_sound (ps := []) (t := e598077206042) (by decide)) (by decide)
def e598077257754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e598077257754 : Closed e598077257754 ∧ code e598077257754 = 2797100513306 := by decide
theorem cert_e598077257754 : check e598077257754 [[],[.left]] .smaller = true := by decide
def e598077270042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e598077270042 : Closed e598077270042 ∧ code e598077270042 = 2797100525594 := by decide
theorem cert_e598077270042 : check e598077270042 [[],[.left]] .smaller = true := by decide
def e598077298714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e598077298714 : Closed e598077298714 ∧ code e598077298714 = 2797100554266 := by decide
theorem cert_e598077298714 : check e598077298714 [[],[.left]] .smaller = true := by decide
def e598077300250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598077300250 : Closed e598077300250 ∧ code e598077300250 = 2797100555802 := by decide
private def t_e598077300250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598077300250 : ¬ IsSelfInterpreter e598077300250 :=
  wSource (t := t_e598077300250) (replay_sound (ps := []) (t := e598077300250) (by decide)) (by decide)
def e598077302810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e598077302810 : Closed e598077302810 ∧ code e598077302810 = 2797100558362 := by decide
theorem cert_e598077302810 : check e598077302810 [[],[.left]] .smaller = true := by decide
def e598077307418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598077307418 : Closed e598077307418 ∧ code e598077307418 = 2797100562970 := by decide
private def t_e598077307418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598077307418 : ¬ IsSelfInterpreter e598077307418 :=
  wSource (t := t_e598077307418) (replay_sound (ps := []) (t := e598077307418) (by decide)) (by decide)
def e598077320730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598077320730 : Closed e598077320730 ∧ code e598077320730 = 2797100576282 := by decide
private def t_e598077320730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598077320730 : ¬ IsSelfInterpreter e598077320730 :=
  wSource (t := t_e598077320730) (replay_sound (ps := []) (t := e598077320730) (by decide)) (by decide)
def e598077323802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598077323802 : Closed e598077323802 ∧ code e598077323802 = 2797100579354 := by decide
private def t_e598077323802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598077323802 : ¬ IsSelfInterpreter e598077323802 :=
  wSource (t := t_e598077323802) (replay_sound (ps := []) (t := e598077323802) (by decide)) (by decide)
def e598077585434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e598077585434 : Closed e598077585434 ∧ code e598077585434 = 2797100840986 := by decide
theorem cert_e598077585434 : check e598077585434 [[],[.left]] .smaller = true := by decide
def e598077593626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e598077593626 : Closed e598077593626 ∧ code e598077593626 = 2797100849178 := by decide
theorem cert_e598077593626 : check e598077593626 [[],[.left]] .smaller = true := by decide
def e598077595162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598077595162 : Closed e598077595162 ∧ code e598077595162 = 2797100850714 := by decide
private def t_e598077595162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598077595162 : ¬ IsSelfInterpreter e598077595162 :=
  wSource (t := t_e598077595162) (replay_sound (ps := []) (t := e598077595162) (by decide)) (by decide)
def e598077599258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598077599258 : Closed e598077599258 ∧ code e598077599258 = 2797100854810 := by decide
private def t_e598077599258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598077599258 : ¬ IsSelfInterpreter e598077599258 :=
  wSource (t := t_e598077599258) (replay_sound (ps := []) (t := e598077599258) (by decide)) (by decide)
def e598077978650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e598077978650 : Closed e598077978650 ∧ code e598077978650 = 2797101234202 := by decide
theorem cert_e598077978650 : check e598077978650 [[],[.left]] .smaller = true := by decide
def e598077990938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e598077990938 : Closed e598077990938 ∧ code e598077990938 = 2797101246490 := by decide
theorem cert_e598077990938 : check e598077990938 [[],[.left]] .smaller = true := by decide
def e598078183450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e598078183450 : Closed e598078183450 ∧ code e598078183450 = 2797101439002 := by decide
theorem cert_e598078183450 : check e598078183450 [[],[.left]] .smaller = true := by decide
def e598078184986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598078184986 : Closed e598078184986 ∧ code e598078184986 = 2797101440538 := by decide
private def t_e598078184986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598078184986 : ¬ IsSelfInterpreter e598078184986 :=
  wSource (t := t_e598078184986) (replay_sound (ps := []) (t := e598078184986) (by decide)) (by decide)
def e598078187546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e598078187546 : Closed e598078187546 ∧ code e598078187546 = 2797101443098 := by decide
theorem cert_e598078187546 : check e598078187546 [[],[.left]] .smaller = true := by decide
def e598078192154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598078192154 : Closed e598078192154 ∧ code e598078192154 = 2797101447706 := by decide
private def t_e598078192154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598078192154 : ¬ IsSelfInterpreter e598078192154 :=
  wSource (t := t_e598078192154) (replay_sound (ps := []) (t := e598078192154) (by decide)) (by decide)
def e598078287386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598078287386 : Closed e598078287386 ∧ code e598078287386 = 2797101542938 := by decide
private def t_e598078287386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598078287386 : ¬ IsSelfInterpreter e598078287386 :=
  wSource (t := t_e598078287386) (replay_sound (ps := []) (t := e598078287386) (by decide)) (by decide)
def e598078290458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598078290458 : Closed e598078290458 ∧ code e598078290458 = 2797101546010 := by decide
private def t_e598078290458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598078290458 : ¬ IsSelfInterpreter e598078290458 :=
  wSource (t := t_e598078290458) (replay_sound (ps := []) (t := e598078290458) (by decide)) (by decide)
def e598085561882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085561882 : Closed e598085561882 ∧ code e598085561882 = 2797108817434 := by decide
private def t_e598085561882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085561882 : ¬ IsSelfInterpreter e598085561882 :=
  wSource (t := t_e598085561882) (replay_sound (ps := []) (t := e598085561882) (by decide)) (by decide)
def e598085563930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085563930 : Closed e598085563930 ∧ code e598085563930 = 2797108819482 := by decide
private def t_e598085563930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085563930 : ¬ IsSelfInterpreter e598085563930 :=
  wSource (t := t_e598085563930) (replay_sound (ps := []) (t := e598085563930) (by decide)) (by decide)
def e598085578266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085578266 : Closed e598085578266 ∧ code e598085578266 = 2797108833818 := by decide
private def t_e598085578266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085578266 : ¬ IsSelfInterpreter e598085578266 :=
  wSource (t := t_e598085578266) (replay_sound (ps := []) (t := e598085578266) (by decide)) (by decide)
def e598085581338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085581338 : Closed e598085581338 ∧ code e598085581338 = 2797108836890 := by decide
private def t_e598085581338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085581338 : ¬ IsSelfInterpreter e598085581338 :=
  wSource (t := t_e598085581338) (replay_sound (ps := []) (t := e598085581338) (by decide)) (by decide)
def e598085588506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085588506 : Closed e598085588506 ∧ code e598085588506 = 2797108844058 := by decide
private def t_e598085588506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085588506 : ¬ IsSelfInterpreter e598085588506 :=
  wSource (t := t_e598085588506) (replay_sound (ps := []) (t := e598085588506) (by decide)) (by decide)
def e598085589530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085589530 : Closed e598085589530 ∧ code e598085589530 = 2797108845082 := by decide
private def t_e598085589530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085589530 : ¬ IsSelfInterpreter e598085589530 :=
  wSource (t := t_e598085589530) (replay_sound (ps := []) (t := e598085589530) (by decide)) (by decide)
def e598085643802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085643802 : Closed e598085643802 ∧ code e598085643802 = 2797108899354 := by decide
private def t_e598085643802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085643802 : ¬ IsSelfInterpreter e598085643802 :=
  wSource (t := t_e598085643802) (replay_sound (ps := []) (t := e598085643802) (by decide)) (by decide)
def e598085646874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085646874 : Closed e598085646874 ∧ code e598085646874 = 2797108902426 := by decide
private def t_e598085646874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085646874 : ¬ IsSelfInterpreter e598085646874 :=
  wSource (t := t_e598085646874) (replay_sound (ps := []) (t := e598085646874) (by decide)) (by decide)
def e598085659162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085659162 : Closed e598085659162 ∧ code e598085659162 = 2797108914714 := by decide
private def t_e598085659162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085659162 : ¬ IsSelfInterpreter e598085659162 :=
  wSource (t := t_e598085659162) (replay_sound (ps := []) (t := e598085659162) (by decide)) (by decide)
def e598085686810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085686810 : Closed e598085686810 ∧ code e598085686810 = 2797108942362 := by decide
private def t_e598085686810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085686810 : ¬ IsSelfInterpreter e598085686810 :=
  wSource (t := t_e598085686810) (replay_sound (ps := []) (t := e598085686810) (by decide)) (by decide)
def e598085687834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085687834 : Closed e598085687834 ∧ code e598085687834 = 2797108943386 := by decide
private def t_e598085687834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085687834 : ¬ IsSelfInterpreter e598085687834 :=
  wSource (t := t_e598085687834) (replay_sound (ps := []) (t := e598085687834) (by decide)) (by decide)
def e598085691930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085691930 : Closed e598085691930 ∧ code e598085691930 = 2797108947482 := by decide
private def t_e598085691930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085691930 : ¬ IsSelfInterpreter e598085691930 :=
  wSource (t := t_e598085691930) (replay_sound (ps := []) (t := e598085691930) (by decide)) (by decide)
def e598085955098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085955098 : Closed e598085955098 ∧ code e598085955098 = 2797109210650 := by decide
private def t_e598085955098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085955098 : ¬ IsSelfInterpreter e598085955098 :=
  wSource (t := t_e598085955098) (replay_sound (ps := []) (t := e598085955098) (by decide)) (by decide)
def e598085957146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085957146 : Closed e598085957146 ∧ code e598085957146 = 2797109212698 := by decide
private def t_e598085957146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085957146 : ¬ IsSelfInterpreter e598085957146 :=
  wSource (t := t_e598085957146) (replay_sound (ps := []) (t := e598085957146) (by decide)) (by decide)
def e598085971482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085971482 : Closed e598085971482 ∧ code e598085971482 = 2797109227034 := by decide
private def t_e598085971482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085971482 : ¬ IsSelfInterpreter e598085971482 :=
  wSource (t := t_e598085971482) (replay_sound (ps := []) (t := e598085971482) (by decide)) (by decide)
def e598085974554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085974554 : Closed e598085974554 ∧ code e598085974554 = 2797109230106 := by decide
private def t_e598085974554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085974554 : ¬ IsSelfInterpreter e598085974554 :=
  wSource (t := t_e598085974554) (replay_sound (ps := []) (t := e598085974554) (by decide)) (by decide)
def e598085981722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085981722 : Closed e598085981722 ∧ code e598085981722 = 2797109237274 := by decide
private def t_e598085981722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085981722 : ¬ IsSelfInterpreter e598085981722 :=
  wSource (t := t_e598085981722) (replay_sound (ps := []) (t := e598085981722) (by decide)) (by decide)
def e598085982746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598085982746 : Closed e598085982746 ∧ code e598085982746 = 2797109238298 := by decide
private def t_e598085982746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598085982746 : ¬ IsSelfInterpreter e598085982746 :=
  wSource (t := t_e598085982746) (replay_sound (ps := []) (t := e598085982746) (by decide)) (by decide)
def e598086053402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086053402 : Closed e598086053402 ∧ code e598086053402 = 2797109308954 := by decide
private def t_e598086053402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086053402 : ¬ IsSelfInterpreter e598086053402 :=
  wSource (t := t_e598086053402) (replay_sound (ps := []) (t := e598086053402) (by decide)) (by decide)
def e598086055450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086055450 : Closed e598086055450 ∧ code e598086055450 = 2797109311002 := by decide
private def t_e598086055450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086055450 : ¬ IsSelfInterpreter e598086055450 :=
  wSource (t := t_e598086055450) (replay_sound (ps := []) (t := e598086055450) (by decide)) (by decide)
def e598086151706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086151706 : Closed e598086151706 ∧ code e598086151706 = 2797109407258 := by decide
private def t_e598086151706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086151706 : ¬ IsSelfInterpreter e598086151706 :=
  wSource (t := t_e598086151706) (replay_sound (ps := []) (t := e598086151706) (by decide)) (by decide)
def e598086154778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086154778 : Closed e598086154778 ∧ code e598086154778 = 2797109410330 := by decide
private def t_e598086154778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086154778 : ¬ IsSelfInterpreter e598086154778 :=
  wSource (t := t_e598086154778) (replay_sound (ps := []) (t := e598086154778) (by decide)) (by decide)
def e598086180890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598086180890 : Closed e598086180890 ∧ code e598086180890 = 2797109436442 := by decide
theorem cert_e598086180890 : check e598086180890 [[]] .width = true := by decide
def e598086180982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e598086180982 : Closed e598086180982 ∧ code e598086180982 = 2797109436534 := by decide
private def t_e598086180982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e598086180982 : ¬ IsSelfInterpreter e598086180982 :=
  wSource (t := t_e598086180982) (replay_sound (ps := []) (t := e598086180982) (by decide)) (by decide)
def e598086181226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e598086181226 : Closed e598086181226 ∧ code e598086181226 = 2797109436778 := by decide
private def t_e598086181226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e598086181226 : ¬ IsSelfInterpreter e598086181226 :=
  wSource (t := t_e598086181226) (replay_sound (ps := []) (t := e598086181226) (by decide)) (by decide)
def e598086181274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e598086181274 : Closed e598086181274 ∧ code e598086181274 = 2797109436826 := by decide
private def t_e598086181274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e598086181274 : ¬ IsSelfInterpreter e598086181274 :=
  wSource (t := t_e598086181274) (replay_sound (ps := []) (t := e598086181274) (by decide)) (by decide)
def e598086202906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086202906 : Closed e598086202906 ∧ code e598086202906 = 2797109458458 := by decide
private def t_e598086202906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086202906 : ¬ IsSelfInterpreter e598086202906 :=
  wSource (t := t_e598086202906) (replay_sound (ps := []) (t := e598086202906) (by decide)) (by decide)
def e598086203930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086203930 : Closed e598086203930 ∧ code e598086203930 = 2797109459482 := by decide
private def t_e598086203930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086203930 : ¬ IsSelfInterpreter e598086203930 :=
  wSource (t := t_e598086203930) (replay_sound (ps := []) (t := e598086203930) (by decide)) (by decide)
def e598086213658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598086213658 : Closed e598086213658 ∧ code e598086213658 = 2797109469210 := by decide
theorem cert_e598086213658 : check e598086213658 [[]] .width = true := by decide
def e598086213750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e598086213750 : Closed e598086213750 ∧ code e598086213750 = 2797109469302 := by decide
private def t_e598086213750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e598086213750 : ¬ IsSelfInterpreter e598086213750 :=
  wSource (t := t_e598086213750) (replay_sound (ps := []) (t := e598086213750) (by decide)) (by decide)
def e598086213994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e598086213994 : Closed e598086213994 ∧ code e598086213994 = 2797109469546 := by decide
private def t_e598086213994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e598086213994 : ¬ IsSelfInterpreter e598086213994 :=
  wSource (t := t_e598086213994) (replay_sound (ps := []) (t := e598086213994) (by decide)) (by decide)
def e598086214042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e598086214042 : Closed e598086214042 ∧ code e598086214042 = 2797109469594 := by decide
private def t_e598086214042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e598086214042 : ¬ IsSelfInterpreter e598086214042 :=
  wSource (t := t_e598086214042) (replay_sound (ps := []) (t := e598086214042) (by decide)) (by decide)
def e598086364698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086364698 : Closed e598086364698 ∧ code e598086364698 = 2797109620250 := by decide
private def t_e598086364698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086364698 : ¬ IsSelfInterpreter e598086364698 :=
  wSource (t := t_e598086364698) (replay_sound (ps := []) (t := e598086364698) (by decide)) (by decide)
def e598086367770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086367770 : Closed e598086367770 ∧ code e598086367770 = 2797109623322 := by decide
private def t_e598086367770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086367770 : ¬ IsSelfInterpreter e598086367770 :=
  wSource (t := t_e598086367770) (replay_sound (ps := []) (t := e598086367770) (by decide)) (by decide)
def e598086380058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086380058 : Closed e598086380058 ∧ code e598086380058 = 2797109635610 := by decide
private def t_e598086380058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086380058 : ¬ IsSelfInterpreter e598086380058 :=
  wSource (t := t_e598086380058) (replay_sound (ps := []) (t := e598086380058) (by decide)) (by decide)
def e598086413850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086413850 : Closed e598086413850 ∧ code e598086413850 = 2797109669402 := by decide
private def t_e598086413850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086413850 : ¬ IsSelfInterpreter e598086413850 :=
  wSource (t := t_e598086413850) (replay_sound (ps := []) (t := e598086413850) (by decide)) (by decide)
def e598086416922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086416922 : Closed e598086416922 ∧ code e598086416922 = 2797109672474 := by decide
private def t_e598086416922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086416922 : ¬ IsSelfInterpreter e598086416922 :=
  wSource (t := t_e598086416922) (replay_sound (ps := []) (t := e598086416922) (by decide)) (by decide)
def e598086443034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598086443034 : Closed e598086443034 ∧ code e598086443034 = 2797109698586 := by decide
theorem cert_e598086443034 : check e598086443034 [[]] .width = true := by decide
def e598086443126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e598086443126 : Closed e598086443126 ∧ code e598086443126 = 2797109698678 := by decide
private def t_e598086443126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e598086443126 : ¬ IsSelfInterpreter e598086443126 :=
  wSource (t := t_e598086443126) (replay_sound (ps := []) (t := e598086443126) (by decide)) (by decide)
def e598086443370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e598086443370 : Closed e598086443370 ∧ code e598086443370 = 2797109698922 := by decide
private def t_e598086443370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e598086443370 : ¬ IsSelfInterpreter e598086443370 :=
  wSource (t := t_e598086443370) (replay_sound (ps := []) (t := e598086443370) (by decide)) (by decide)
def e598086443418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e598086443418 : Closed e598086443418 ∧ code e598086443418 = 2797109698970 := by decide
private def t_e598086443418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e598086443418 : ¬ IsSelfInterpreter e598086443418 :=
  wSource (t := t_e598086443418) (replay_sound (ps := []) (t := e598086443418) (by decide)) (by decide)
def e598086490650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086490650 : Closed e598086490650 ∧ code e598086490650 = 2797109746202 := by decide
private def t_e598086490650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086490650 : ¬ IsSelfInterpreter e598086490650 :=
  wSource (t := t_e598086490650) (replay_sound (ps := []) (t := e598086490650) (by decide)) (by decide)
def e598086492186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598086492186 : Closed e598086492186 ∧ code e598086492186 = 2797109747738 := by decide
theorem cert_e598086492186 : check e598086492186 [[]] .width = true := by decide
def e598086492278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e598086492278 : Closed e598086492278 ∧ code e598086492278 = 2797109747830 := by decide
private def t_e598086492278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e598086492278 : ¬ IsSelfInterpreter e598086492278 :=
  wSource (t := t_e598086492278) (replay_sound (ps := []) (t := e598086492278) (by decide)) (by decide)
def e598086492522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e598086492522 : Closed e598086492522 ∧ code e598086492522 = 2797109748074 := by decide
private def t_e598086492522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e598086492522 : ¬ IsSelfInterpreter e598086492522 :=
  wSource (t := t_e598086492522) (replay_sound (ps := []) (t := e598086492522) (by decide)) (by decide)
def e598086492570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e598086492570 : Closed e598086492570 ∧ code e598086492570 = 2797109748122 := by decide
private def t_e598086492570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e598086492570 : ¬ IsSelfInterpreter e598086492570 :=
  wSource (t := t_e598086492570) (replay_sound (ps := []) (t := e598086492570) (by decide)) (by decide)
def e598086571546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086571546 : Closed e598086571546 ∧ code e598086571546 = 2797109827098 := by decide
private def t_e598086571546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086571546 : ¬ IsSelfInterpreter e598086571546 :=
  wSource (t := t_e598086571546) (replay_sound (ps := []) (t := e598086571546) (by decide)) (by decide)
def e598086572570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086572570 : Closed e598086572570 ∧ code e598086572570 = 2797109828122 := by decide
private def t_e598086572570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086572570 : ¬ IsSelfInterpreter e598086572570 :=
  wSource (t := t_e598086572570) (replay_sound (ps := []) (t := e598086572570) (by decide)) (by decide)
def e598086576666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086576666 : Closed e598086576666 ∧ code e598086576666 = 2797109832218 := by decide
private def t_e598086576666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086576666 : ¬ IsSelfInterpreter e598086576666 :=
  wSource (t := t_e598086576666) (replay_sound (ps := []) (t := e598086576666) (by decide)) (by decide)
def e598086596122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086596122 : Closed e598086596122 ∧ code e598086596122 = 2797109851674 := by decide
private def t_e598086596122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086596122 : ¬ IsSelfInterpreter e598086596122 :=
  wSource (t := t_e598086596122) (replay_sound (ps := []) (t := e598086596122) (by decide)) (by decide)
def e598086597146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086597146 : Closed e598086597146 ∧ code e598086597146 = 2797109852698 := by decide
private def t_e598086597146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086597146 : ¬ IsSelfInterpreter e598086597146 :=
  wSource (t := t_e598086597146) (replay_sound (ps := []) (t := e598086597146) (by decide)) (by decide)
def e598086606874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598086606874 : Closed e598086606874 ∧ code e598086606874 = 2797109862426 := by decide
theorem cert_e598086606874 : check e598086606874 [[]] .width = true := by decide
def e598086606966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e598086606966 : Closed e598086606966 ∧ code e598086606966 = 2797109862518 := by decide
private def t_e598086606966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e598086606966 : ¬ IsSelfInterpreter e598086606966 :=
  wSource (t := t_e598086606966) (replay_sound (ps := []) (t := e598086606966) (by decide)) (by decide)
def e598086607210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e598086607210 : Closed e598086607210 ∧ code e598086607210 = 2797109862762 := by decide
private def t_e598086607210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e598086607210 : ¬ IsSelfInterpreter e598086607210 :=
  wSource (t := t_e598086607210) (replay_sound (ps := []) (t := e598086607210) (by decide)) (by decide)
def e598086607258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e598086607258 : Closed e598086607258 ∧ code e598086607258 = 2797109862810 := by decide
private def t_e598086607258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e598086607258 : ¬ IsSelfInterpreter e598086607258 :=
  wSource (t := t_e598086607258) (replay_sound (ps := []) (t := e598086607258) (by decide)) (by decide)
def e598086621722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598086621722 : Closed e598086621722 ∧ code e598086621722 = 2797109877274 := by decide
private def t_e598086621722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598086621722 : ¬ IsSelfInterpreter e598086621722 :=
  wSource (t := t_e598086621722) (replay_sound (ps := []) (t := e598086621722) (by decide)) (by decide)
def e598086623258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598086623258 : Closed e598086623258 ∧ code e598086623258 = 2797109878810 := by decide
theorem cert_e598086623258 : check e598086623258 [[]] .width = true := by decide
def e598086623350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e598086623350 : Closed e598086623350 ∧ code e598086623350 = 2797109878902 := by decide
private def t_e598086623350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e598086623350 : ¬ IsSelfInterpreter e598086623350 :=
  wSource (t := t_e598086623350) (replay_sound (ps := []) (t := e598086623350) (by decide)) (by decide)
def e598086623594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e598086623594 : Closed e598086623594 ∧ code e598086623594 = 2797109879146 := by decide
private def t_e598086623594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e598086623594 : ¬ IsSelfInterpreter e598086623594 :=
  wSource (t := t_e598086623594) (replay_sound (ps := []) (t := e598086623594) (by decide)) (by decide)
def e598086623642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e598086623642 : Closed e598086623642 ∧ code e598086623642 = 2797109879194 := by decide
private def t_e598086623642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e598086623642 : ¬ IsSelfInterpreter e598086623642 :=
  wSource (t := t_e598086623642) (replay_sound (ps := []) (t := e598086623642) (by decide)) (by decide)
def e598087032346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087032346 : Closed e598087032346 ∧ code e598087032346 = 2797110287898 := by decide
private def t_e598087032346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087032346 : ¬ IsSelfInterpreter e598087032346 :=
  wSource (t := t_e598087032346) (replay_sound (ps := []) (t := e598087032346) (by decide)) (by decide)
def e598087036442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087036442 : Closed e598087036442 ∧ code e598087036442 = 2797110291994 := by decide
private def t_e598087036442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087036442 : ¬ IsSelfInterpreter e598087036442 :=
  wSource (t := t_e598087036442) (replay_sound (ps := []) (t := e598087036442) (by decide)) (by decide)
def e598087527962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087527962 : Closed e598087527962 ∧ code e598087527962 = 2797110783514 := by decide
private def t_e598087527962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087527962 : ¬ IsSelfInterpreter e598087527962 :=
  wSource (t := t_e598087527962) (replay_sound (ps := []) (t := e598087527962) (by decide)) (by decide)
def e598087530010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087530010 : Closed e598087530010 ∧ code e598087530010 = 2797110785562 := by decide
private def t_e598087530010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087530010 : ¬ IsSelfInterpreter e598087530010 :=
  wSource (t := t_e598087530010) (replay_sound (ps := []) (t := e598087530010) (by decide)) (by decide)
def e598087544346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087544346 : Closed e598087544346 ∧ code e598087544346 = 2797110799898 := by decide
private def t_e598087544346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087544346 : ¬ IsSelfInterpreter e598087544346 :=
  wSource (t := t_e598087544346) (replay_sound (ps := []) (t := e598087544346) (by decide)) (by decide)
def e598087547418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087547418 : Closed e598087547418 ∧ code e598087547418 = 2797110802970 := by decide
private def t_e598087547418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087547418 : ¬ IsSelfInterpreter e598087547418 :=
  wSource (t := t_e598087547418) (replay_sound (ps := []) (t := e598087547418) (by decide)) (by decide)
def e598087554586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087554586 : Closed e598087554586 ∧ code e598087554586 = 2797110810138 := by decide
private def t_e598087554586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087554586 : ¬ IsSelfInterpreter e598087554586 :=
  wSource (t := t_e598087554586) (replay_sound (ps := []) (t := e598087554586) (by decide)) (by decide)
def e598087555610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087555610 : Closed e598087555610 ∧ code e598087555610 = 2797110811162 := by decide
private def t_e598087555610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087555610 : ¬ IsSelfInterpreter e598087555610 :=
  wSource (t := t_e598087555610) (replay_sound (ps := []) (t := e598087555610) (by decide)) (by decide)
def e598087626266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087626266 : Closed e598087626266 ∧ code e598087626266 = 2797110881818 := by decide
private def t_e598087626266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087626266 : ¬ IsSelfInterpreter e598087626266 :=
  wSource (t := t_e598087626266) (replay_sound (ps := []) (t := e598087626266) (by decide)) (by decide)
def e598087628314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087628314 : Closed e598087628314 ∧ code e598087628314 = 2797110883866 := by decide
private def t_e598087628314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087628314 : ¬ IsSelfInterpreter e598087628314 :=
  wSource (t := t_e598087628314) (replay_sound (ps := []) (t := e598087628314) (by decide)) (by decide)
def e598087724570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087724570 : Closed e598087724570 ∧ code e598087724570 = 2797110980122 := by decide
private def t_e598087724570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087724570 : ¬ IsSelfInterpreter e598087724570 :=
  wSource (t := t_e598087724570) (replay_sound (ps := []) (t := e598087724570) (by decide)) (by decide)
def e598087727642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087727642 : Closed e598087727642 ∧ code e598087727642 = 2797110983194 := by decide
private def t_e598087727642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087727642 : ¬ IsSelfInterpreter e598087727642 :=
  wSource (t := t_e598087727642) (replay_sound (ps := []) (t := e598087727642) (by decide)) (by decide)
def e598087753754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598087753754 : Closed e598087753754 ∧ code e598087753754 = 2797111009306 := by decide
theorem cert_e598087753754 : check e598087753754 [[]] .width = true := by decide
def e598087753846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e598087753846 : Closed e598087753846 ∧ code e598087753846 = 2797111009398 := by decide
private def t_e598087753846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e598087753846 : ¬ IsSelfInterpreter e598087753846 :=
  wSource (t := t_e598087753846) (replay_sound (ps := []) (t := e598087753846) (by decide)) (by decide)
def e598087754090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e598087754090 : Closed e598087754090 ∧ code e598087754090 = 2797111009642 := by decide
private def t_e598087754090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e598087754090 : ¬ IsSelfInterpreter e598087754090 :=
  wSource (t := t_e598087754090) (replay_sound (ps := []) (t := e598087754090) (by decide)) (by decide)
def e598087754138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e598087754138 : Closed e598087754138 ∧ code e598087754138 = 2797111009690 := by decide
private def t_e598087754138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e598087754138 : ¬ IsSelfInterpreter e598087754138 :=
  wSource (t := t_e598087754138) (replay_sound (ps := []) (t := e598087754138) (by decide)) (by decide)
def e598087775770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087775770 : Closed e598087775770 ∧ code e598087775770 = 2797111031322 := by decide
private def t_e598087775770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087775770 : ¬ IsSelfInterpreter e598087775770 :=
  wSource (t := t_e598087775770) (replay_sound (ps := []) (t := e598087775770) (by decide)) (by decide)
def e598087776794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598087776794 : Closed e598087776794 ∧ code e598087776794 = 2797111032346 := by decide
private def t_e598087776794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598087776794 : ¬ IsSelfInterpreter e598087776794 :=
  wSource (t := t_e598087776794) (replay_sound (ps := []) (t := e598087776794) (by decide)) (by decide)
def e598087786522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598087786522 : Closed e598087786522 ∧ code e598087786522 = 2797111042074 := by decide
theorem cert_e598087786522 : check e598087786522 [[]] .width = true := by decide
def e598087786614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e598087786614 : Closed e598087786614 ∧ code e598087786614 = 2797111042166 := by decide
private def t_e598087786614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e598087786614 : ¬ IsSelfInterpreter e598087786614 :=
  wSource (t := t_e598087786614) (replay_sound (ps := []) (t := e598087786614) (by decide)) (by decide)
def e598087786858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e598087786858 : Closed e598087786858 ∧ code e598087786858 = 2797111042410 := by decide
private def t_e598087786858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e598087786858 : ¬ IsSelfInterpreter e598087786858 :=
  wSource (t := t_e598087786858) (replay_sound (ps := []) (t := e598087786858) (by decide)) (by decide)
def e598087786906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e598087786906 : Closed e598087786906 ∧ code e598087786906 = 2797111042458 := by decide
private def t_e598087786906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e598087786906 : ¬ IsSelfInterpreter e598087786906 :=
  wSource (t := t_e598087786906) (replay_sound (ps := []) (t := e598087786906) (by decide)) (by decide)
def e598088998426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598088998426 : Closed e598088998426 ∧ code e598088998426 = 2797112253978 := by decide
private def t_e598088998426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598088998426 : ¬ IsSelfInterpreter e598088998426 :=
  wSource (t := t_e598088998426) (replay_sound (ps := []) (t := e598088998426) (by decide)) (by decide)
def e598089004570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598089004570 : Closed e598089004570 ∧ code e598089004570 = 2797112260122 := by decide
private def t_e598089004570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598089004570 : ¬ IsSelfInterpreter e598089004570 :=
  wSource (t := t_e598089004570) (replay_sound (ps := []) (t := e598089004570) (by decide)) (by decide)
def e598089248282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598089248282 : Closed e598089248282 ∧ code e598089248282 = 2797112503834 := by decide
private def t_e598089248282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598089248282 : ¬ IsSelfInterpreter e598089248282 :=
  wSource (t := t_e598089248282) (replay_sound (ps := []) (t := e598089248282) (by decide)) (by decide)
def e598089251354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598089251354 : Closed e598089251354 ∧ code e598089251354 = 2797112506906 := by decide
private def t_e598089251354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598089251354 : ¬ IsSelfInterpreter e598089251354 :=
  wSource (t := t_e598089251354) (replay_sound (ps := []) (t := e598089251354) (by decide)) (by decide)
def e598089263642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598089263642 : Closed e598089263642 ∧ code e598089263642 = 2797112519194 := by decide
private def t_e598089263642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598089263642 : ¬ IsSelfInterpreter e598089263642 :=
  wSource (t := t_e598089263642) (replay_sound (ps := []) (t := e598089263642) (by decide)) (by decide)
def e598089297434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598089297434 : Closed e598089297434 ∧ code e598089297434 = 2797112552986 := by decide
private def t_e598089297434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598089297434 : ¬ IsSelfInterpreter e598089297434 :=
  wSource (t := t_e598089297434) (replay_sound (ps := []) (t := e598089297434) (by decide)) (by decide)
def e598089300506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598089300506 : Closed e598089300506 ∧ code e598089300506 = 2797112556058 := by decide
private def t_e598089300506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598089300506 : ¬ IsSelfInterpreter e598089300506 :=
  wSource (t := t_e598089300506) (replay_sound (ps := []) (t := e598089300506) (by decide)) (by decide)
def e598089326618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598089326618 : Closed e598089326618 ∧ code e598089326618 = 2797112582170 := by decide
theorem cert_e598089326618 : check e598089326618 [[]] .width = true := by decide
def e598089326710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e598089326710 : Closed e598089326710 ∧ code e598089326710 = 2797112582262 := by decide
private def t_e598089326710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e598089326710 : ¬ IsSelfInterpreter e598089326710 :=
  wSource (t := t_e598089326710) (replay_sound (ps := []) (t := e598089326710) (by decide)) (by decide)
def e598089326954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e598089326954 : Closed e598089326954 ∧ code e598089326954 = 2797112582506 := by decide
private def t_e598089326954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e598089326954 : ¬ IsSelfInterpreter e598089326954 :=
  wSource (t := t_e598089326954) (replay_sound (ps := []) (t := e598089326954) (by decide)) (by decide)
def e598089327002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e598089327002 : Closed e598089327002 ∧ code e598089327002 = 2797112582554 := by decide
private def t_e598089327002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e598089327002 : ¬ IsSelfInterpreter e598089327002 :=
  wSource (t := t_e598089327002) (replay_sound (ps := []) (t := e598089327002) (by decide)) (by decide)
def e598089374234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598089374234 : Closed e598089374234 ∧ code e598089374234 = 2797112629786 := by decide
private def t_e598089374234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598089374234 : ¬ IsSelfInterpreter e598089374234 :=
  wSource (t := t_e598089374234) (replay_sound (ps := []) (t := e598089374234) (by decide)) (by decide)
def e598089375770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598089375770 : Closed e598089375770 ∧ code e598089375770 = 2797112631322 := by decide
theorem cert_e598089375770 : check e598089375770 [[]] .width = true := by decide
def e598089375862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e598089375862 : Closed e598089375862 ∧ code e598089375862 = 2797112631414 := by decide
private def t_e598089375862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e598089375862 : ¬ IsSelfInterpreter e598089375862 :=
  wSource (t := t_e598089375862) (replay_sound (ps := []) (t := e598089375862) (by decide)) (by decide)
def e598089376106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e598089376106 : Closed e598089376106 ∧ code e598089376106 = 2797112631658 := by decide
private def t_e598089376106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e598089376106 : ¬ IsSelfInterpreter e598089376106 :=
  wSource (t := t_e598089376106) (replay_sound (ps := []) (t := e598089376106) (by decide)) (by decide)
def e598089376154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e598089376154 : Closed e598089376154 ∧ code e598089376154 = 2797112631706 := by decide
private def t_e598089376154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e598089376154 : ¬ IsSelfInterpreter e598089376154 :=
  wSource (t := t_e598089376154) (replay_sound (ps := []) (t := e598089376154) (by decide)) (by decide)
def e598089985562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598089985562 : Closed e598089985562 ∧ code e598089985562 = 2797113241114 := by decide
private def t_e598089985562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598089985562 : ¬ IsSelfInterpreter e598089985562 :=
  wSource (t := t_e598089985562) (replay_sound (ps := []) (t := e598089985562) (by decide)) (by decide)
def e598089987610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598089987610 : Closed e598089987610 ∧ code e598089987610 = 2797113243162 := by decide
private def t_e598089987610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598089987610 : ¬ IsSelfInterpreter e598089987610 :=
  wSource (t := t_e598089987610) (replay_sound (ps := []) (t := e598089987610) (by decide)) (by decide)
def e598090110490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598090110490 : Closed e598090110490 ∧ code e598090110490 = 2797113366042 := by decide
private def t_e598090110490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598090110490 : ¬ IsSelfInterpreter e598090110490 :=
  wSource (t := t_e598090110490) (replay_sound (ps := []) (t := e598090110490) (by decide)) (by decide)
def e598090111514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598090111514 : Closed e598090111514 ∧ code e598090111514 = 2797113367066 := by decide
private def t_e598090111514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598090111514 : ¬ IsSelfInterpreter e598090111514 :=
  wSource (t := t_e598090111514) (replay_sound (ps := []) (t := e598090111514) (by decide)) (by decide)
def e598090115610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598090115610 : Closed e598090115610 ∧ code e598090115610 = 2797113371162 := by decide
private def t_e598090115610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598090115610 : ¬ IsSelfInterpreter e598090115610 :=
  wSource (t := t_e598090115610) (replay_sound (ps := []) (t := e598090115610) (by decide)) (by decide)
def e598090135066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598090135066 : Closed e598090135066 ∧ code e598090135066 = 2797113390618 := by decide
private def t_e598090135066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598090135066 : ¬ IsSelfInterpreter e598090135066 :=
  wSource (t := t_e598090135066) (replay_sound (ps := []) (t := e598090135066) (by decide)) (by decide)
def e598090136090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598090136090 : Closed e598090136090 ∧ code e598090136090 = 2797113391642 := by decide
private def t_e598090136090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598090136090 : ¬ IsSelfInterpreter e598090136090 :=
  wSource (t := t_e598090136090) (replay_sound (ps := []) (t := e598090136090) (by decide)) (by decide)
def e598090145818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598090145818 : Closed e598090145818 ∧ code e598090145818 = 2797113401370 := by decide
theorem cert_e598090145818 : check e598090145818 [[]] .width = true := by decide
def e598090145910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e598090145910 : Closed e598090145910 ∧ code e598090145910 = 2797113401462 := by decide
private def t_e598090145910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e598090145910 : ¬ IsSelfInterpreter e598090145910 :=
  wSource (t := t_e598090145910) (replay_sound (ps := []) (t := e598090145910) (by decide)) (by decide)
def e598090146154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e598090146154 : Closed e598090146154 ∧ code e598090146154 = 2797113401706 := by decide
private def t_e598090146154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e598090146154 : ¬ IsSelfInterpreter e598090146154 :=
  wSource (t := t_e598090146154) (replay_sound (ps := []) (t := e598090146154) (by decide)) (by decide)
def e598090146202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e598090146202 : Closed e598090146202 ∧ code e598090146202 = 2797113401754 := by decide
private def t_e598090146202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e598090146202 : ¬ IsSelfInterpreter e598090146202 :=
  wSource (t := t_e598090146202) (replay_sound (ps := []) (t := e598090146202) (by decide)) (by decide)
def e598090160666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598090160666 : Closed e598090160666 ∧ code e598090160666 = 2797113416218 := by decide
private def t_e598090160666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598090160666 : ¬ IsSelfInterpreter e598090160666 :=
  wSource (t := t_e598090160666) (replay_sound (ps := []) (t := e598090160666) (by decide)) (by decide)
end Blc.Floor41
