import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605603167118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605603167118 : Closed e605603167118 ∧ code e605603167118 = 2804626422670 := by decide
theorem cert_e605603167118 : check e605603167118 [[],[]] .chain = true := by decide
def e605603167130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603167130 : Closed e605603167130 ∧ code e605603167130 = 2804626422682 := by decide
theorem cert_e605603167130 : check e605603167130 [[],[]] .chain = true := by decide
def e605603171182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605603171182 : Closed e605603171182 ∧ code e605603171182 = 2804626426734 := by decide
theorem cert_e605603171182 : check e605603171182 [[],[]] .smaller = true := by decide
def e605603171190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605603171190 : Closed e605603171190 ∧ code e605603171190 = 2804626426742 := by decide
theorem cert_e605603171190 : check e605603171190 [[],[]] .smaller = true := by decide
def e605603171246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605603171246 : Closed e605603171246 ∧ code e605603171246 = 2804626426798 := by decide
theorem cert_e605603171246 : check e605603171246 [[],[]] .smaller = true := by decide
def e605603171258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605603171258 : Closed e605603171258 ∧ code e605603171258 = 2804626426810 := by decide
theorem cert_e605603171258 : check e605603171258 [[],[]] .smaller = true := by decide
def e605603171286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605603171286 : Closed e605603171286 ∧ code e605603171286 = 2804626426838 := by decide
theorem cert_e605603171286 : check e605603171286 [[],[]] .smaller = true := by decide
def e605603171290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605603171290 : Closed e605603171290 ∧ code e605603171290 = 2804626426842 := by decide
theorem cert_e605603171290 : check e605603171290 [[],[]] .smaller = true := by decide
def e605603171566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605603171566 : Closed e605603171566 ∧ code e605603171566 = 2804626427118 := by decide
theorem cert_e605603171566 : check e605603171566 [[],[]] .smaller = true := by decide
def e605603171574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605603171574 : Closed e605603171574 ∧ code e605603171574 = 2804626427126 := by decide
theorem cert_e605603171574 : check e605603171574 [[],[]] .smaller = true := by decide
def e605603171950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605603171950 : Closed e605603171950 ∧ code e605603171950 = 2804626427502 := by decide
theorem cert_e605603171950 : check e605603171950 [[],[]] .smaller = true := by decide
def e605603171962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605603171962 : Closed e605603171962 ∧ code e605603171962 = 2804626427514 := by decide
theorem cert_e605603171962 : check e605603171962 [[],[]] .smaller = true := by decide
def e605603172150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605603172150 : Closed e605603172150 ∧ code e605603172150 = 2804626427702 := by decide
theorem cert_e605603172150 : check e605603172150 [[],[]] .smaller = true := by decide
def e605603172154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605603172154 : Closed e605603172154 ∧ code e605603172154 = 2804626427706 := by decide
theorem cert_e605603172154 : check e605603172154 [[],[]] .smaller = true := by decide
def e605603179998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605603179998 : Closed e605603179998 ∧ code e605603179998 = 2804626435550 := by decide
theorem cert_e605603179998 : check e605603179998 [[],[]] .chain = true := by decide
def e605603180014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605603180014 : Closed e605603180014 ∧ code e605603180014 = 2804626435566 := by decide
theorem cert_e605603180014 : check e605603180014 [[],[]] .chain = true := by decide
def e605603180078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e605603180078 : Closed e605603180078 ∧ code e605603180078 = 2804626435630 := by decide
theorem cert_e605603180078 : check e605603180078 [[],[]] .smaller = true := by decide
def e605603180254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e605603180254 : Closed e605603180254 ∧ code e605603180254 = 2804626435806 := by decide
theorem cert_e605603180254 : check e605603180254 [[],[]] .chain = true := by decide
def e605603180258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e605603180258 : Closed e605603180258 ∧ code e605603180258 = 2804626435810 := by decide
theorem cert_e605603180258 : check e605603180258 [[],[]] .smaller = true := by decide
def e605603180270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e605603180270 : Closed e605603180270 ∧ code e605603180270 = 2804626435822 := by decide
theorem cert_e605603180270 : check e605603180270 [[],[]] .smaller = true := by decide
def e605603180278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e605603180278 : Closed e605603180278 ∧ code e605603180278 = 2804626435830 := by decide
theorem cert_e605603180278 : check e605603180278 [[],[]] .chain = true := by decide
def e605603180310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e605603180310 : Closed e605603180310 ∧ code e605603180310 = 2804626435862 := by decide
theorem cert_e605603180310 : check e605603180310 [[],[]] .smaller = true := by decide
def e605603180382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605603180382 : Closed e605603180382 ∧ code e605603180382 = 2804626435934 := by decide
theorem cert_e605603180382 : check e605603180382 [[],[]] .chain = true := by decide
def e605603180386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e605603180386 : Closed e605603180386 ∧ code e605603180386 = 2804626435938 := by decide
theorem cert_e605603180386 : check e605603180386 [[],[]] .smaller = true := by decide
def e605603180398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e605603180398 : Closed e605603180398 ∧ code e605603180398 = 2804626435950 := by decide
theorem cert_e605603180398 : check e605603180398 [[],[]] .smaller = true := by decide
def e605603180406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e605603180406 : Closed e605603180406 ∧ code e605603180406 = 2804626435958 := by decide
theorem cert_e605603180406 : check e605603180406 [[],[]] .smaller = true := by decide
def e605603180410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605603180410 : Closed e605603180410 ∧ code e605603180410 = 2804626435962 := by decide
theorem cert_e605603180410 : check e605603180410 [[],[]] .chain = true := by decide
def e605603180462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605603180462 : Closed e605603180462 ∧ code e605603180462 = 2804626436014 := by decide
theorem cert_e605603180462 : check e605603180462 [[],[]] .chain = true := by decide
def e605603180470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e605603180470 : Closed e605603180470 ∧ code e605603180470 = 2804626436022 := by decide
theorem cert_e605603180470 : check e605603180470 [[],[]] .chain = true := by decide
def e605603180474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605603180474 : Closed e605603180474 ∧ code e605603180474 = 2804626436026 := by decide
theorem cert_e605603180474 : check e605603180474 [[],[]] .chain = true := by decide
def e605603181534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605603181534 : Closed e605603181534 ∧ code e605603181534 = 2804626437086 := by decide
theorem cert_e605603181534 : check e605603181534 [[],[]] .chain = true := by decide
def e605603181550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605603181550 : Closed e605603181550 ∧ code e605603181550 = 2804626437102 := by decide
theorem cert_e605603181550 : check e605603181550 [[],[]] .chain = true := by decide
def e605603182654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4)))))))))))
theorem wire_e605603182654 : Closed e605603182654 ∧ code e605603182654 = 2804626438206 := by decide
theorem cert_e605603182654 : check e605603182654 [[],[]] .smaller = true := by decide
def e605603183070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e605603183070 : Closed e605603183070 ∧ code e605603183070 = 2804626438622 := by decide
theorem cert_e605603183070 : check e605603183070 [[],[]] .chain = true := by decide
def e605603183074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e605603183074 : Closed e605603183074 ∧ code e605603183074 = 2804626438626 := by decide
theorem cert_e605603183074 : check e605603183074 [[],[]] .smaller = true := by decide
def e605603183086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e605603183086 : Closed e605603183086 ∧ code e605603183086 = 2804626438638 := by decide
theorem cert_e605603183086 : check e605603183086 [[],[]] .smaller = true := by decide
def e605603183094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e605603183094 : Closed e605603183094 ∧ code e605603183094 = 2804626438646 := by decide
theorem cert_e605603183094 : check e605603183094 [[],[]] .chain = true := by decide
def e605603183646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3)))))))))))
theorem wire_e605603183646 : Closed e605603183646 ∧ code e605603183646 = 2804626439198 := by decide
theorem cert_e605603183646 : check e605603183646 [[],[]] .smaller = true := by decide
def e605603183838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605603183838 : Closed e605603183838 ∧ code e605603183838 = 2804626439390 := by decide
theorem cert_e605603183838 : check e605603183838 [[],[]] .chain = true := by decide
def e605603183842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e605603183842 : Closed e605603183842 ∧ code e605603183842 = 2804626439394 := by decide
theorem cert_e605603183842 : check e605603183842 [[],[]] .smaller = true := by decide
def e605603183854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e605603183854 : Closed e605603183854 ∧ code e605603183854 = 2804626439406 := by decide
theorem cert_e605603183854 : check e605603183854 [[],[]] .smaller = true := by decide
def e605603183862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e605603183862 : Closed e605603183862 ∧ code e605603183862 = 2804626439414 := by decide
theorem cert_e605603183862 : check e605603183862 [[],[]] .smaller = true := by decide
def e605603183866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605603183866 : Closed e605603183866 ∧ code e605603183866 = 2804626439418 := by decide
theorem cert_e605603183866 : check e605603183866 [[],[]] .chain = true := by decide
def e605603184238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605603184238 : Closed e605603184238 ∧ code e605603184238 = 2804626439790 := by decide
theorem cert_e605603184238 : check e605603184238 [[],[]] .chain = true := by decide
def e605603184246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e605603184246 : Closed e605603184246 ∧ code e605603184246 = 2804626439798 := by decide
theorem cert_e605603184246 : check e605603184246 [[],[]] .chain = true := by decide
def e605603184250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605603184250 : Closed e605603184250 ∧ code e605603184250 = 2804626439802 := by decide
theorem cert_e605603184250 : check e605603184250 [[],[]] .chain = true := by decide
def e605603206702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e605603206702 : Closed e605603206702 ∧ code e605603206702 = 2804626462254 := by decide
theorem cert_e605603206702 : check e605603206702 [[],[]] .smaller = true := by decide
def e605603206878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605603206878 : Closed e605603206878 ∧ code e605603206878 = 2804626462430 := by decide
theorem cert_e605603206878 : check e605603206878 [[],[]] .chain = true := by decide
def e605603206882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e605603206882 : Closed e605603206882 ∧ code e605603206882 = 2804626462434 := by decide
theorem cert_e605603206882 : check e605603206882 [[],[]] .smaller = true := by decide
def e605603206894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e605603206894 : Closed e605603206894 ∧ code e605603206894 = 2804626462446 := by decide
theorem cert_e605603206894 : check e605603206894 [[],[]] .smaller = true := by decide
def e605603206902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605603206902 : Closed e605603206902 ∧ code e605603206902 = 2804626462454 := by decide
theorem cert_e605603206902 : check e605603206902 [[],[]] .chain = true := by decide
def e605603207006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605603207006 : Closed e605603207006 ∧ code e605603207006 = 2804626462558 := by decide
theorem cert_e605603207006 : check e605603207006 [[],[]] .chain = true := by decide
def e605603207034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605603207034 : Closed e605603207034 ∧ code e605603207034 = 2804626462586 := by decide
theorem cert_e605603207034 : check e605603207034 [[],[]] .chain = true := by decide
def e605603207050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e605603207050 : Closed e605603207050 ∧ code e605603207050 = 2804626462602 := by decide
theorem cert_e605603207050 : check e605603207050 [[],[]] .smaller = true := by decide
def e605603207074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e605603207074 : Closed e605603207074 ∧ code e605603207074 = 2804626462626 := by decide
theorem cert_e605603207074 : check e605603207074 [[],[]] .smaller = true := by decide
def e605603207086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e605603207086 : Closed e605603207086 ∧ code e605603207086 = 2804626462638 := by decide
theorem cert_e605603207086 : check e605603207086 [[],[]] .smaller = true := by decide
def e605603207098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e605603207098 : Closed e605603207098 ∧ code e605603207098 = 2804626462650 := by decide
theorem cert_e605603207098 : check e605603207098 [[],[]] .smaller = true := by decide
def e605603207126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605603207126 : Closed e605603207126 ∧ code e605603207126 = 2804626462678 := by decide
theorem cert_e605603207126 : check e605603207126 [[],[]] .chain = true := by decide
def e605603207130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605603207130 : Closed e605603207130 ∧ code e605603207130 = 2804626462682 := by decide
theorem cert_e605603207130 : check e605603207130 [[],[]] .chain = true := by decide
def e605603207230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4)))))))))))
theorem wire_e605603207230 : Closed e605603207230 ∧ code e605603207230 = 2804626462782 := by decide
theorem cert_e605603207230 : check e605603207230 [[],[]] .smaller = true := by decide
def e605603207646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605603207646 : Closed e605603207646 ∧ code e605603207646 = 2804626463198 := by decide
theorem cert_e605603207646 : check e605603207646 [[],[]] .chain = true := by decide
def e605603207650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e605603207650 : Closed e605603207650 ∧ code e605603207650 = 2804626463202 := by decide
theorem cert_e605603207650 : check e605603207650 [[],[]] .smaller = true := by decide
def e605603207662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e605603207662 : Closed e605603207662 ∧ code e605603207662 = 2804626463214 := by decide
theorem cert_e605603207662 : check e605603207662 [[],[]] .smaller = true := by decide
def e605603207670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605603207670 : Closed e605603207670 ∧ code e605603207670 = 2804626463222 := by decide
theorem cert_e605603207670 : check e605603207670 [[],[]] .chain = true := by decide
def e605603208414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605603208414 : Closed e605603208414 ∧ code e605603208414 = 2804626463966 := by decide
theorem cert_e605603208414 : check e605603208414 [[],[]] .chain = true := by decide
def e605603208442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605603208442 : Closed e605603208442 ∧ code e605603208442 = 2804626463994 := by decide
theorem cert_e605603208442 : check e605603208442 [[],[]] .chain = true := by decide
def e605603208718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2)))))))))))
theorem wire_e605603208718 : Closed e605603208718 ∧ code e605603208718 = 2804626464270 := by decide
theorem cert_e605603208718 : check e605603208718 [[],[]] .smaller = true := by decide
def e605603208766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e605603208766 : Closed e605603208766 ∧ code e605603208766 = 2804626464318 := by decide
theorem cert_e605603208766 : check e605603208766 [[],[]] .chain = true := by decide
def e605603208802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e605603208802 : Closed e605603208802 ∧ code e605603208802 = 2804626464354 := by decide
theorem cert_e605603208802 : check e605603208802 [[],[]] .smaller = true := by decide
def e605603208814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e605603208814 : Closed e605603208814 ∧ code e605603208814 = 2804626464366 := by decide
theorem cert_e605603208814 : check e605603208814 [[],[]] .smaller = true := by decide
def e605603208826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e605603208826 : Closed e605603208826 ∧ code e605603208826 = 2804626464378 := by decide
theorem cert_e605603208826 : check e605603208826 [[],[]] .smaller = true := by decide
def e605603208990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e605603208990 : Closed e605603208990 ∧ code e605603208990 = 2804626464542 := by decide
theorem cert_e605603208990 : check e605603208990 [[],[]] .chain = true := by decide
def e605603209014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605603209014 : Closed e605603209014 ∧ code e605603209014 = 2804626464566 := by decide
theorem cert_e605603209014 : check e605603209014 [[],[]] .chain = true := by decide
def e605603209018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605603209018 : Closed e605603209018 ∧ code e605603209018 = 2804626464570 := by decide
theorem cert_e605603209018 : check e605603209018 [[],[]] .chain = true := by decide
def e605603220246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e605603220246 : Closed e605603220246 ∧ code e605603220246 = 2804626475798 := by decide
theorem cert_e605603220246 : check e605603220246 [[],[]] .smaller = true := by decide
def e605603220318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e605603220318 : Closed e605603220318 ∧ code e605603220318 = 2804626475870 := by decide
theorem cert_e605603220318 : check e605603220318 [[],[]] .chain = true := by decide
def e605603220322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e605603220322 : Closed e605603220322 ∧ code e605603220322 = 2804626475874 := by decide
theorem cert_e605603220322 : check e605603220322 [[],[]] .smaller = true := by decide
def e605603220334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605603220334 : Closed e605603220334 ∧ code e605603220334 = 2804626475886 := by decide
theorem cert_e605603220334 : check e605603220334 [[],[]] .smaller = true := by decide
def e605603220342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605603220342 : Closed e605603220342 ∧ code e605603220342 = 2804626475894 := by decide
theorem cert_e605603220342 : check e605603220342 [[],[]] .smaller = true := by decide
def e605603220346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e605603220346 : Closed e605603220346 ∧ code e605603220346 = 2804626475898 := by decide
theorem cert_e605603220346 : check e605603220346 [[],[]] .chain = true := by decide
def e605603220362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e605603220362 : Closed e605603220362 ∧ code e605603220362 = 2804626475914 := by decide
theorem cert_e605603220362 : check e605603220362 [[],[]] .smaller = true := by decide
def e605603220386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e605603220386 : Closed e605603220386 ∧ code e605603220386 = 2804626475938 := by decide
theorem cert_e605603220386 : check e605603220386 [[],[]] .smaller = true := by decide
def e605603220398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605603220398 : Closed e605603220398 ∧ code e605603220398 = 2804626475950 := by decide
theorem cert_e605603220398 : check e605603220398 [[],[]] .smaller = true := by decide
def e605603220410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605603220410 : Closed e605603220410 ∧ code e605603220410 = 2804626475962 := by decide
theorem cert_e605603220410 : check e605603220410 [[],[]] .smaller = true := by decide
def e605603220438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605603220438 : Closed e605603220438 ∧ code e605603220438 = 2804626475990 := by decide
theorem cert_e605603220438 : check e605603220438 [[],[]] .smaller = true := by decide
def e605603220442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605603220442 : Closed e605603220442 ∧ code e605603220442 = 2804626475994 := by decide
theorem cert_e605603220442 : check e605603220442 [[],[]] .smaller = true := by decide
def e605603220458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e605603220458 : Closed e605603220458 ∧ code e605603220458 = 2804626476010 := by decide
theorem cert_e605603220458 : check e605603220458 [[],[]] .chain = true := by decide
def e605603220510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e605603220510 : Closed e605603220510 ∧ code e605603220510 = 2804626476062 := by decide
theorem cert_e605603220510 : check e605603220510 [[],[]] .smaller = true := by decide
def e605603220702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e605603220702 : Closed e605603220702 ∧ code e605603220702 = 2804626476254 := by decide
theorem cert_e605603220702 : check e605603220702 [[],[]] .chain = true := by decide
def e605603220706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e605603220706 : Closed e605603220706 ∧ code e605603220706 = 2804626476258 := by decide
theorem cert_e605603220706 : check e605603220706 [[],[]] .smaller = true := by decide
def e605603220718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605603220718 : Closed e605603220718 ∧ code e605603220718 = 2804626476270 := by decide
theorem cert_e605603220718 : check e605603220718 [[],[]] .smaller = true := by decide
def e605603220726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605603220726 : Closed e605603220726 ∧ code e605603220726 = 2804626476278 := by decide
theorem cert_e605603220726 : check e605603220726 [[],[]] .smaller = true := by decide
def e605603220730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e605603220730 : Closed e605603220730 ∧ code e605603220730 = 2804626476282 := by decide
theorem cert_e605603220730 : check e605603220730 [[],[]] .chain = true := by decide
def e605603221006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e605603221006 : Closed e605603221006 ∧ code e605603221006 = 2804626476558 := by decide
theorem cert_e605603221006 : check e605603221006 [[],[]] .smaller = true := by decide
def e605603221054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e605603221054 : Closed e605603221054 ∧ code e605603221054 = 2804626476606 := by decide
theorem cert_e605603221054 : check e605603221054 [[],[]] .chain = true := by decide
def e605603221090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e605603221090 : Closed e605603221090 ∧ code e605603221090 = 2804626476642 := by decide
theorem cert_e605603221090 : check e605603221090 [[],[]] .smaller = true := by decide
def e605603221102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605603221102 : Closed e605603221102 ∧ code e605603221102 = 2804626476654 := by decide
theorem cert_e605603221102 : check e605603221102 [[],[]] .smaller = true := by decide
def e605603221114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605603221114 : Closed e605603221114 ∧ code e605603221114 = 2804626476666 := by decide
theorem cert_e605603221114 : check e605603221114 [[],[]] .smaller = true := by decide
def e605603221302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605603221302 : Closed e605603221302 ∧ code e605603221302 = 2804626476854 := by decide
theorem cert_e605603221302 : check e605603221302 [[],[]] .smaller = true := by decide
def e605603221306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605603221306 : Closed e605603221306 ∧ code e605603221306 = 2804626476858 := by decide
theorem cert_e605603221306 : check e605603221306 [[],[]] .smaller = true := by decide
def e605603221390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e605603221390 : Closed e605603221390 ∧ code e605603221390 = 2804626476942 := by decide
theorem cert_e605603221390 : check e605603221390 [[],[]] .chain = true := by decide
def e605603221402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e605603221402 : Closed e605603221402 ∧ code e605603221402 = 2804626476954 := by decide
theorem cert_e605603221402 : check e605603221402 [[],[]] .chain = true := by decide
def e605603227054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605603227054 : Closed e605603227054 ∧ code e605603227054 = 2804626482606 := by decide
theorem cert_e605603227054 : check e605603227054 [[],[]] .chain = true := by decide
def e605603227062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605603227062 : Closed e605603227062 ∧ code e605603227062 = 2804626482614 := by decide
theorem cert_e605603227062 : check e605603227062 [[],[]] .chain = true := by decide
def e605603227066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605603227066 : Closed e605603227066 ∧ code e605603227066 = 2804626482618 := by decide
theorem cert_e605603227066 : check e605603227066 [[],[]] .chain = true := by decide
def e605603227094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605603227094 : Closed e605603227094 ∧ code e605603227094 = 2804626482646 := by decide
theorem cert_e605603227094 : check e605603227094 [[],[]] .chain = true := by decide
def e605603227098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605603227098 : Closed e605603227098 ∧ code e605603227098 = 2804626482650 := by decide
theorem cert_e605603227098 : check e605603227098 [[],[]] .chain = true := by decide
def e605603227114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605603227114 : Closed e605603227114 ∧ code e605603227114 = 2804626482666 := by decide
theorem cert_e605603227114 : check e605603227114 [[],[]] .chain = true := by decide
def e605603227246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605603227246 : Closed e605603227246 ∧ code e605603227246 = 2804626482798 := by decide
theorem cert_e605603227246 : check e605603227246 [[],[]] .chain = true := by decide
def e605603227254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605603227254 : Closed e605603227254 ∧ code e605603227254 = 2804626482806 := by decide
theorem cert_e605603227254 : check e605603227254 [[],[]] .chain = true := by decide
def e605603227258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605603227258 : Closed e605603227258 ∧ code e605603227258 = 2804626482810 := by decide
theorem cert_e605603227258 : check e605603227258 [[],[]] .chain = true := by decide
def e605603227422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605603227422 : Closed e605603227422 ∧ code e605603227422 = 2804626482974 := by decide
theorem cert_e605603227422 : check e605603227422 [[],[]] .chain = true := by decide
def e605603227446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605603227446 : Closed e605603227446 ∧ code e605603227446 = 2804626482998 := by decide
theorem cert_e605603227446 : check e605603227446 [[],[]] .chain = true := by decide
def e605603227450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605603227450 : Closed e605603227450 ∧ code e605603227450 = 2804626483002 := by decide
theorem cert_e605603227450 : check e605603227450 [[],[]] .chain = true := by decide
def e605603227534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605603227534 : Closed e605603227534 ∧ code e605603227534 = 2804626483086 := by decide
theorem cert_e605603227534 : check e605603227534 [[],[]] .chain = true := by decide
def e605603227546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605603227546 : Closed e605603227546 ∧ code e605603227546 = 2804626483098 := by decide
theorem cert_e605603227546 : check e605603227546 [[],[]] .chain = true := by decide
def e605603673454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605603673454 : Closed e605603673454 ∧ code e605603673454 = 2804626929006 := by decide
theorem cert_e605603673454 : check e605603673454 [[],[]] .chain = true := by decide
def e605603673462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605603673462 : Closed e605603673462 ∧ code e605603673462 = 2804626929014 := by decide
theorem cert_e605603673462 : check e605603673462 [[],[]] .chain = true := by decide
def e605603673518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605603673518 : Closed e605603673518 ∧ code e605603673518 = 2804626929070 := by decide
theorem cert_e605603673518 : check e605603673518 [[],[]] .chain = true := by decide
def e605603673530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605603673530 : Closed e605603673530 ∧ code e605603673530 = 2804626929082 := by decide
theorem cert_e605603673530 : check e605603673530 [[],[]] .chain = true := by decide
def e605603673558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605603673558 : Closed e605603673558 ∧ code e605603673558 = 2804626929110 := by decide
theorem cert_e605603673558 : check e605603673558 [[],[]] .chain = true := by decide
def e605603673562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605603673562 : Closed e605603673562 ∧ code e605603673562 = 2804626929114 := by decide
theorem cert_e605603673562 : check e605603673562 [[],[]] .chain = true := by decide
def e605603673774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605603673774 : Closed e605603673774 ∧ code e605603673774 = 2804626929326 := by decide
theorem cert_e605603673774 : check e605603673774 [[],[]] .chain = true := by decide
def e605603673786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605603673786 : Closed e605603673786 ∧ code e605603673786 = 2804626929338 := by decide
theorem cert_e605603673786 : check e605603673786 [[],[]] .chain = true := by decide
def e605603673834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605603673834 : Closed e605603673834 ∧ code e605603673834 = 2804626929386 := by decide
theorem cert_e605603673834 : check e605603673834 [[],[]] .chain = true := by decide
def e605603673942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605603673942 : Closed e605603673942 ∧ code e605603673942 = 2804626929494 := by decide
theorem cert_e605603673942 : check e605603673942 [[],[]] .chain = true := by decide
def e605603673946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605603673946 : Closed e605603673946 ∧ code e605603673946 = 2804626929498 := by decide
theorem cert_e605603673946 : check e605603673946 [[],[]] .chain = true := by decide
def e605603673962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605603673962 : Closed e605603673962 ∧ code e605603673962 = 2804626929514 := by decide
theorem cert_e605603673962 : check e605603673962 [[],[]] .chain = true := by decide
def e605603674798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605603674798 : Closed e605603674798 ∧ code e605603674798 = 2804626930350 := by decide
theorem cert_e605603674798 : check e605603674798 [[],[]] .chain = true := by decide
def e605603674810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605603674810 : Closed e605603674810 ∧ code e605603674810 = 2804626930362 := by decide
theorem cert_e605603674810 : check e605603674810 [[],[]] .chain = true := by decide
def e605603674858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605603674858 : Closed e605603674858 ∧ code e605603674858 = 2804626930410 := by decide
theorem cert_e605603674858 : check e605603674858 [[],[]] .chain = true := by decide
def e605603675050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605603675050 : Closed e605603675050 ∧ code e605603675050 = 2804626930602 := by decide
theorem cert_e605603675050 : check e605603675050 [[],[]] .chain = true := by decide
def e605603675478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605603675478 : Closed e605603675478 ∧ code e605603675478 = 2804626931030 := by decide
theorem cert_e605603675478 : check e605603675478 [[],[]] .chain = true := by decide
def e605603675482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605603675482 : Closed e605603675482 ∧ code e605603675482 = 2804626931034 := by decide
theorem cert_e605603675482 : check e605603675482 [[],[]] .chain = true := by decide
def e605603675498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605603675498 : Closed e605603675498 ∧ code e605603675498 = 2804626931050 := by decide
theorem cert_e605603675498 : check e605603675498 [[],[]] .chain = true := by decide
def e605603675562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605603675562 : Closed e605603675562 ∧ code e605603675562 = 2804626931114 := by decide
theorem cert_e605603675562 : check e605603675562 [[],[]] .chain = true := by decide
def e605603676526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e605603676526 : Closed e605603676526 ∧ code e605603676526 = 2804626932078 := by decide
theorem cert_e605603676526 : check e605603676526 [[],[]] .chain = true := by decide
def e605603676534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e605603676534 : Closed e605603676534 ∧ code e605603676534 = 2804626932086 := by decide
theorem cert_e605603676534 : check e605603676534 [[],[]] .chain = true := by decide
def e605603678062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e605603678062 : Closed e605603678062 ∧ code e605603678062 = 2804626933614 := by decide
theorem cert_e605603678062 : check e605603678062 [[],[]] .chain = true := by decide
def e605603678070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e605603678070 : Closed e605603678070 ∧ code e605603678070 = 2804626933622 := by decide
theorem cert_e605603678070 : check e605603678070 [[],[]] .chain = true := by decide
def e605603678134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e605603678134 : Closed e605603678134 ∧ code e605603678134 = 2804626933686 := by decide
theorem cert_e605603678134 : check e605603678134 [[],[]] .chain = true := by decide
def e605603679598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e605603679598 : Closed e605603679598 ∧ code e605603679598 = 2804626935150 := by decide
theorem cert_e605603679598 : check e605603679598 [[],[]] .chain = true := by decide
def e605603679606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e605603679606 : Closed e605603679606 ∧ code e605603679606 = 2804626935158 := by decide
theorem cert_e605603679606 : check e605603679606 [[],[]] .chain = true := by decide
def e605603679662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e605603679662 : Closed e605603679662 ∧ code e605603679662 = 2804626935214 := by decide
theorem cert_e605603679662 : check e605603679662 [[],[]] .chain = true := by decide
def e605603679674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e605603679674 : Closed e605603679674 ∧ code e605603679674 = 2804626935226 := by decide
theorem cert_e605603679674 : check e605603679674 [[],[]] .chain = true := by decide
def e605603679702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e605603679702 : Closed e605603679702 ∧ code e605603679702 = 2804626935254 := by decide
theorem cert_e605603679702 : check e605603679702 [[],[]] .chain = true := by decide
def e605603679706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e605603679706 : Closed e605603679706 ∧ code e605603679706 = 2804626935258 := by decide
theorem cert_e605603679706 : check e605603679706 [[],[]] .chain = true := by decide
def e605603679918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605603679918 : Closed e605603679918 ∧ code e605603679918 = 2804626935470 := by decide
theorem cert_e605603679918 : check e605603679918 [[],[]] .chain = true := by decide
def e605603679930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605603679930 : Closed e605603679930 ∧ code e605603679930 = 2804626935482 := by decide
theorem cert_e605603679930 : check e605603679930 [[],[]] .chain = true := by decide
def e605603679978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605603679978 : Closed e605603679978 ∧ code e605603679978 = 2804626935530 := by decide
theorem cert_e605603679978 : check e605603679978 [[],[]] .chain = true := by decide
def e605603680086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e605603680086 : Closed e605603680086 ∧ code e605603680086 = 2804626935638 := by decide
theorem cert_e605603680086 : check e605603680086 [[],[]] .chain = true := by decide
def e605603680090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e605603680090 : Closed e605603680090 ∧ code e605603680090 = 2804626935642 := by decide
theorem cert_e605603680090 : check e605603680090 [[],[]] .chain = true := by decide
def e605603680106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e605603680106 : Closed e605603680106 ∧ code e605603680106 = 2804626935658 := by decide
theorem cert_e605603680106 : check e605603680106 [[],[]] .chain = true := by decide
def e605603681134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605603681134 : Closed e605603681134 ∧ code e605603681134 = 2804626936686 := by decide
theorem cert_e605603681134 : check e605603681134 [[],[]] .chain = true := by decide
def e605603681142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605603681142 : Closed e605603681142 ∧ code e605603681142 = 2804626936694 := by decide
theorem cert_e605603681142 : check e605603681142 [[],[]] .chain = true := by decide
def e605603681198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605603681198 : Closed e605603681198 ∧ code e605603681198 = 2804626936750 := by decide
theorem cert_e605603681198 : check e605603681198 [[],[]] .chain = true := by decide
def e605603681210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605603681210 : Closed e605603681210 ∧ code e605603681210 = 2804626936762 := by decide
theorem cert_e605603681210 : check e605603681210 [[],[]] .chain = true := by decide
def e605603681238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605603681238 : Closed e605603681238 ∧ code e605603681238 = 2804626936790 := by decide
theorem cert_e605603681238 : check e605603681238 [[],[]] .chain = true := by decide
def e605603681242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605603681242 : Closed e605603681242 ∧ code e605603681242 = 2804626936794 := by decide
theorem cert_e605603681242 : check e605603681242 [[],[]] .chain = true := by decide
def e605603681518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605603681518 : Closed e605603681518 ∧ code e605603681518 = 2804626937070 := by decide
theorem cert_e605603681518 : check e605603681518 [[],[]] .chain = true := by decide
end Blc.Floor41
