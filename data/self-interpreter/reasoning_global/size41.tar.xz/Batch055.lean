import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e602907458358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e602907458358 : Closed e602907458358 ∧ code e602907458358 = 2801930713910 := by decide
theorem cert_e602907458358 : check e602907458358 [[],[]] .chain = true := by decide
def e602907458362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e602907458362 : Closed e602907458362 ∧ code e602907458362 = 2801930713914 := by decide
theorem cert_e602907458362 : check e602907458362 [[],[]] .chain = true := by decide
def e602907458446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e602907458446 : Closed e602907458446 ∧ code e602907458446 = 2801930713998 := by decide
theorem cert_e602907458446 : checkPay e602907458446 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] 0 [] = true := by decide
def e602907461358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e602907461358 : Closed e602907461358 ∧ code e602907461358 = 2801930716910 := by decide
theorem cert_e602907461358 : check e602907461358 [[],[]] .sourceHead = true := by decide
def e602907461550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2))))))
theorem wire_e602907461550 : Closed e602907461550 ∧ code e602907461550 = 2801930717102 := by decide
theorem cert_e602907461550 : check e602907461550 [[],[]] .sourceHead = true := by decide
def e602907461562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0))))))
theorem wire_e602907461562 : Closed e602907461562 ∧ code e602907461562 = 2801930717114 := by decide
theorem cert_e602907461562 : check e602907461562 [[],[]] .sourceHead = true := by decide
def e602907463022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e602907463022 : Closed e602907463022 ∧ code e602907463022 = 2801930718574 := by decide
theorem cert_e602907463022 : check e602907463022 [[],[]] .chain = true := by decide
def e602907463030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e602907463030 : Closed e602907463030 ∧ code e602907463030 = 2801930718582 := by decide
theorem cert_e602907463030 : check e602907463030 [[],[]] .chain = true := by decide
def e602907463086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e602907463086 : Closed e602907463086 ∧ code e602907463086 = 2801930718638 := by decide
theorem cert_e602907463086 : check e602907463086 [[],[]] .chain = true := by decide
def e602907463098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e602907463098 : Closed e602907463098 ∧ code e602907463098 = 2801930718650 := by decide
theorem cert_e602907463098 : check e602907463098 [[],[]] .chain = true := by decide
def e602907463126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e602907463126 : Closed e602907463126 ∧ code e602907463126 = 2801930718678 := by decide
theorem cert_e602907463126 : check e602907463126 [[],[]] .chain = true := by decide
def e602907463130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e602907463130 : Closed e602907463130 ∧ code e602907463130 = 2801930718682 := by decide
theorem cert_e602907463130 : check e602907463130 [[],[]] .chain = true := by decide
def e602907463342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e602907463342 : Closed e602907463342 ∧ code e602907463342 = 2801930718894 := by decide
theorem cert_e602907463342 : check e602907463342 [[],[]] .chain = true := by decide
def e602907463354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e602907463354 : Closed e602907463354 ∧ code e602907463354 = 2801930718906 := by decide
theorem cert_e602907463354 : check e602907463354 [[],[]] .chain = true := by decide
def e602907463402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e602907463402 : Closed e602907463402 ∧ code e602907463402 = 2801930718954 := by decide
theorem cert_e602907463402 : check e602907463402 [[],[]] .chain = true := by decide
def e602907463510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e602907463510 : Closed e602907463510 ∧ code e602907463510 = 2801930719062 := by decide
theorem cert_e602907463510 : check e602907463510 [[],[]] .chain = true := by decide
def e602907463514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e602907463514 : Closed e602907463514 ∧ code e602907463514 = 2801930719066 := by decide
theorem cert_e602907463514 : check e602907463514 [[],[]] .chain = true := by decide
def e602907463530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e602907463530 : Closed e602907463530 ∧ code e602907463530 = 2801930719082 := by decide
theorem cert_e602907463530 : check e602907463530 [[],[]] .chain = true := by decide
def e602907464174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2))))))
theorem wire_e602907464174 : Closed e602907464174 ∧ code e602907464174 = 2801930719726 := by decide
theorem cert_e602907464174 : check e602907464174 [[],[]] .sourceHead = true := by decide
def e602907464558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e602907464558 : Closed e602907464558 ∧ code e602907464558 = 2801930720110 := by decide
theorem cert_e602907464558 : check e602907464558 [[],[]] .chain = true := by decide
def e602907464566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e602907464566 : Closed e602907464566 ∧ code e602907464566 = 2801930720118 := by decide
theorem cert_e602907464566 : check e602907464566 [[],[]] .chain = true := by decide
def e602907464622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e602907464622 : Closed e602907464622 ∧ code e602907464622 = 2801930720174 := by decide
theorem cert_e602907464622 : check e602907464622 [[],[]] .chain = true := by decide
def e602907464634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e602907464634 : Closed e602907464634 ∧ code e602907464634 = 2801930720186 := by decide
theorem cert_e602907464634 : check e602907464634 [[],[]] .chain = true := by decide
def e602907464662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e602907464662 : Closed e602907464662 ∧ code e602907464662 = 2801930720214 := by decide
theorem cert_e602907464662 : check e602907464662 [[],[]] .chain = true := by decide
def e602907464666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e602907464666 : Closed e602907464666 ∧ code e602907464666 = 2801930720218 := by decide
theorem cert_e602907464666 : check e602907464666 [[],[]] .chain = true := by decide
def e602907464942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e602907464942 : Closed e602907464942 ∧ code e602907464942 = 2801930720494 := by decide
theorem cert_e602907464942 : check e602907464942 [[],[]] .chain = true := by decide
def e602907464950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e602907464950 : Closed e602907464950 ∧ code e602907464950 = 2801930720502 := by decide
theorem cert_e602907464950 : check e602907464950 [[],[]] .chain = true := by decide
def e602907465326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e602907465326 : Closed e602907465326 ∧ code e602907465326 = 2801930720878 := by decide
theorem cert_e602907465326 : check e602907465326 [[],[]] .chain = true := by decide
def e602907465338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e602907465338 : Closed e602907465338 ∧ code e602907465338 = 2801930720890 := by decide
theorem cert_e602907465338 : check e602907465338 [[],[]] .chain = true := by decide
def e602907465502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e602907465502 : Closed e602907465502 ∧ code e602907465502 = 2801930721054 := by decide
theorem cert_e602907465502 : check e602907465502 [[],[]] .sourceHead = true := by decide
def e602907465526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e602907465526 : Closed e602907465526 ∧ code e602907465526 = 2801930721078 := by decide
theorem cert_e602907465526 : check e602907465526 [[],[]] .chain = true := by decide
def e602907465530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e602907465530 : Closed e602907465530 ∧ code e602907465530 = 2801930721082 := by decide
theorem cert_e602907465530 : check e602907465530 [[],[]] .chain = true := by decide
def e602907466158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e602907466158 : Closed e602907466158 ∧ code e602907466158 = 2801930721710 := by decide
theorem cert_e602907466158 : check e602907466158 [[],[]] .chain = true := by decide
def e602907466170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e602907466170 : Closed e602907466170 ∧ code e602907466170 = 2801930721722 := by decide
theorem cert_e602907466170 : check e602907466170 [[],[]] .chain = true := by decide
def e602907466218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e602907466218 : Closed e602907466218 ∧ code e602907466218 = 2801930721770 := by decide
theorem cert_e602907466218 : check e602907466218 [[],[]] .chain = true := by decide
def e602907466350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e602907466350 : Closed e602907466350 ∧ code e602907466350 = 2801930721902 := by decide
theorem cert_e602907466350 : check e602907466350 [[],[]] .chain = true := by decide
def e602907466362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e602907466362 : Closed e602907466362 ∧ code e602907466362 = 2801930721914 := by decide
theorem cert_e602907466362 : check e602907466362 [[],[]] .chain = true := by decide
def e602907466650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e602907466650 : Closed e602907466650 ∧ code e602907466650 = 2801930722202 := by decide
theorem cert_e602907466650 : check e602907466650 [[],[]] .chain = true := by decide
def e602907466862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2))))))
theorem wire_e602907466862 : Closed e602907466862 ∧ code e602907466862 = 2801930722414 := by decide
theorem cert_e602907466862 : check e602907466862 [[],[]] .sourceHead = true := by decide
def e602907466874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0))))))
theorem wire_e602907466874 : Closed e602907466874 ∧ code e602907466874 = 2801930722426 := by decide
theorem cert_e602907466874 : check e602907466874 [[],[]] .sourceHead = true := by decide
def e602907466966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e602907466966 : Closed e602907466966 ∧ code e602907466966 = 2801930722518 := by decide
theorem cert_e602907466966 : check e602907466966 [[],[]] .chain = true := by decide
def e602907466970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e602907466970 : Closed e602907466970 ∧ code e602907466970 = 2801930722522 := by decide
theorem cert_e602907466970 : check e602907466970 [[],[]] .chain = true := by decide
def e602907466986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e602907466986 : Closed e602907466986 ∧ code e602907466986 = 2801930722538 := by decide
theorem cert_e602907466986 : check e602907466986 [[],[]] .chain = true := by decide
def e602907467038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e602907467038 : Closed e602907467038 ∧ code e602907467038 = 2801930722590 := by decide
theorem cert_e602907467038 : check e602907467038 [[],[]] .sourceHead = true := by decide
def e602907467062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e602907467062 : Closed e602907467062 ∧ code e602907467062 = 2801930722614 := by decide
theorem cert_e602907467062 : check e602907467062 [[],[]] .chain = true := by decide
def e602907467066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e602907467066 : Closed e602907467066 ∧ code e602907467066 = 2801930722618 := by decide
theorem cert_e602907467066 : check e602907467066 [[],[]] .chain = true := by decide
def e602907467162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e602907467162 : Closed e602907467162 ∧ code e602907467162 = 2801930722714 := by decide
theorem cert_e602907467162 : check e602907467162 [[],[]] .chain = true := by decide
def e602907467206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e602907467206 : Closed e602907467206 ∧ code e602907467206 = 2801930722758 := by decide
theorem cert_e602907467206 : check e602907467206 [[],[]] .sourceHead = true := by decide
def e602907468654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e602907468654 : Closed e602907468654 ∧ code e602907468654 = 2801930724206 := by decide
theorem cert_e602907468654 : check e602907468654 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e602907468662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e602907468662 : Closed e602907468662 ∧ code e602907468662 = 2801930724214 := by decide
theorem cert_e602907468662 : check e602907468662 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907468718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e602907468718 : Closed e602907468718 ∧ code e602907468718 = 2801930724270 := by decide
theorem cert_e602907468718 : check e602907468718 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e602907468730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e602907468730 : Closed e602907468730 ∧ code e602907468730 = 2801930724282 := by decide
theorem cert_e602907468730 : check e602907468730 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907468758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e602907468758 : Closed e602907468758 ∧ code e602907468758 = 2801930724310 := by decide
theorem cert_e602907468758 : check e602907468758 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e602907468762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e602907468762 : Closed e602907468762 ∧ code e602907468762 = 2801930724314 := by decide
theorem cert_e602907468762 : check e602907468762 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e602907469494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e602907469494 : Closed e602907469494 ∧ code e602907469494 = 2801930725046 := by decide
theorem cert_e602907469494 : check e602907469494 [[],[]] .chain = true := by decide
def e602907469526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e602907469526 : Closed e602907469526 ∧ code e602907469526 = 2801930725078 := by decide
theorem cert_e602907469526 : check e602907469526 [[],[]] .chain = true := by decide
def e602907469530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e602907469530 : Closed e602907469530 ∧ code e602907469530 = 2801930725082 := by decide
theorem cert_e602907469530 : check e602907469530 [[],[]] .chain = true := by decide
def e602907469654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e602907469654 : Closed e602907469654 ∧ code e602907469654 = 2801930725206 := by decide
theorem cert_e602907469654 : check e602907469654 [[],[]] .chain = true := by decide
def e602907469658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e602907469658 : Closed e602907469658 ∧ code e602907469658 = 2801930725210 := by decide
theorem cert_e602907469658 : check e602907469658 [[],[]] .chain = true := by decide
def e602907469674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e602907469674 : Closed e602907469674 ∧ code e602907469674 = 2801930725226 := by decide
theorem cert_e602907469674 : check e602907469674 [[],[]] .chain = true := by decide
def e602907470062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e602907470062 : Closed e602907470062 ∧ code e602907470062 = 2801930725614 := by decide
theorem cert_e602907470062 : check e602907470062 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e602907470070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e602907470070 : Closed e602907470070 ∧ code e602907470070 = 2801930725622 := by decide
theorem cert_e602907470070 : check e602907470070 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907470262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e602907470262 : Closed e602907470262 ∧ code e602907470262 = 2801930725814 := by decide
theorem cert_e602907470262 : check e602907470262 [[],[]] .chain = true := by decide
def e602907470294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e602907470294 : Closed e602907470294 ∧ code e602907470294 = 2801930725846 := by decide
theorem cert_e602907470294 : check e602907470294 [[],[]] .chain = true := by decide
def e602907470298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e602907470298 : Closed e602907470298 ∧ code e602907470298 = 2801930725850 := by decide
theorem cert_e602907470298 : check e602907470298 [[],[]] .chain = true := by decide
def e602907470454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e602907470454 : Closed e602907470454 ∧ code e602907470454 = 2801930726006 := by decide
theorem cert_e602907470454 : check e602907470454 [[],[]] .chain = true := by decide
def e602907470622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e602907470622 : Closed e602907470622 ∧ code e602907470622 = 2801930726174 := by decide
theorem cert_e602907470622 : check e602907470622 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e602907470646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e602907470646 : Closed e602907470646 ∧ code e602907470646 = 2801930726198 := by decide
theorem cert_e602907470646 : check e602907470646 [[],[]] .chain = true := by decide
def e602907470650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e602907470650 : Closed e602907470650 ∧ code e602907470650 = 2801930726202 := by decide
theorem cert_e602907470650 : check e602907470650 [[],[]] .chain = true := by decide
def e602907470734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e602907470734 : Closed e602907470734 ∧ code e602907470734 = 2801930726286 := by decide
theorem cert_e602907470734 : check e602907470734 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907470958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e602907470958 : Closed e602907470958 ∧ code e602907470958 = 2801930726510 := by decide
theorem cert_e602907470958 : check e602907470958 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e602907470970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e602907470970 : Closed e602907470970 ∧ code e602907470970 = 2801930726522 := by decide
theorem cert_e602907470970 : check e602907470970 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907471062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e602907471062 : Closed e602907471062 ∧ code e602907471062 = 2801930726614 := by decide
theorem cert_e602907471062 : check e602907471062 [[],[]] .chain = true := by decide
def e602907471066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e602907471066 : Closed e602907471066 ∧ code e602907471066 = 2801930726618 := by decide
theorem cert_e602907471066 : check e602907471066 [[],[]] .chain = true := by decide
def e602907471082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e602907471082 : Closed e602907471082 ∧ code e602907471082 = 2801930726634 := by decide
theorem cert_e602907471082 : check e602907471082 [[],[]] .chain = true := by decide
def e602907471134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e602907471134 : Closed e602907471134 ∧ code e602907471134 = 2801930726686 := by decide
theorem cert_e602907471134 : check e602907471134 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e602907471158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e602907471158 : Closed e602907471158 ∧ code e602907471158 = 2801930726710 := by decide
theorem cert_e602907471158 : check e602907471158 [[],[]] .chain = true := by decide
def e602907471162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e602907471162 : Closed e602907471162 ∧ code e602907471162 = 2801930726714 := by decide
theorem cert_e602907471162 : check e602907471162 [[],[]] .chain = true := by decide
def e602907471258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e602907471258 : Closed e602907471258 ∧ code e602907471258 = 2801930726810 := by decide
theorem cert_e602907471258 : check e602907471258 [[],[]] .chain = true := by decide
def e602907471302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e602907471302 : Closed e602907471302 ∧ code e602907471302 = 2801930726854 := by decide
theorem cert_e602907471302 : check e602907471302 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e602907471414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e602907471414 : Closed e602907471414 ∧ code e602907471414 = 2801930726966 := by decide
theorem cert_e602907471414 : check e602907471414 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e602907471418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e602907471418 : Closed e602907471418 ∧ code e602907471418 = 2801930726970 := by decide
theorem cert_e602907471418 : check e602907471418 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e602907471502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e602907471502 : Closed e602907471502 ∧ code e602907471502 = 2801930727054 := by decide
theorem cert_e602907471502 : check e602907471502 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e602907471558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e602907471558 : Closed e602907471558 ∧ code e602907471558 = 2801930727110 := by decide
theorem cert_e602907471558 : check e602907471558 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e602907483886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 2))))))
theorem wire_e602907483886 : Closed e602907483886 ∧ code e602907483886 = 2801930739438 := by decide
theorem cert_e602907483886 : check e602907483886 [[],[]] .chain = true := by decide
def e602907483894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 1))))))
theorem wire_e602907483894 : Closed e602907483894 ∧ code e602907483894 = 2801930739446 := by decide
theorem cert_e602907483894 : check e602907483894 [[],[]] .chain = true := by decide
def e602907484022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 1))))))
theorem wire_e602907484022 : Closed e602907484022 ∧ code e602907484022 = 2801930739574 := by decide
theorem cert_e602907484022 : check e602907484022 [[],[]] .chain = true := by decide
def e602907490798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2)))))))
theorem wire_e602907490798 : Closed e602907490798 ∧ code e602907490798 = 2801930746350 := by decide
theorem cert_e602907490798 : checkPay e602907490798 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e602907491566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2)))))))
theorem wire_e602907491566 : Closed e602907491566 ∧ code e602907491566 = 2801930747118 := by decide
theorem cert_e602907491566 : check e602907491566 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602907491574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1)))))))
theorem wire_e602907491574 : Closed e602907491574 ∧ code e602907491574 = 2801930747126 := by decide
theorem cert_e602907491574 : check e602907491574 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602907499374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e602907499374 : Closed e602907499374 ∧ code e602907499374 = 2801930754926 := by decide
theorem cert_e602907499374 : check e602907499374 [[],[]] .chain = true := by decide
def e602907499382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e602907499382 : Closed e602907499382 ∧ code e602907499382 = 2801930754934 := by decide
theorem cert_e602907499382 : check e602907499382 [[],[]] .chain = true := by decide
def e602907499446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e602907499446 : Closed e602907499446 ∧ code e602907499446 = 2801930754998 := by decide
theorem cert_e602907499446 : check e602907499446 [[],[]] .chain = true := by decide
def e602907499886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e602907499886 : Closed e602907499886 ∧ code e602907499886 = 2801930755438 := by decide
theorem cert_e602907499886 : check e602907499886 [[],[]] .chain = true := by decide
def e602907499894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e602907499894 : Closed e602907499894 ∧ code e602907499894 = 2801930755446 := by decide
theorem cert_e602907499894 : check e602907499894 [[],[]] .chain = true := by decide
def e602907499950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e602907499950 : Closed e602907499950 ∧ code e602907499950 = 2801930755502 := by decide
theorem cert_e602907499950 : check e602907499950 [[],[]] .chain = true := by decide
def e602907499962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e602907499962 : Closed e602907499962 ∧ code e602907499962 = 2801930755514 := by decide
theorem cert_e602907499962 : check e602907499962 [[],[]] .chain = true := by decide
def e602907499990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e602907499990 : Closed e602907499990 ∧ code e602907499990 = 2801930755542 := by decide
theorem cert_e602907499990 : check e602907499990 [[],[]] .chain = true := by decide
def e602907499994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e602907499994 : Closed e602907499994 ∧ code e602907499994 = 2801930755546 := by decide
theorem cert_e602907499994 : check e602907499994 [[],[]] .chain = true := by decide
def e602907500214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e602907500214 : Closed e602907500214 ∧ code e602907500214 = 2801930755766 := by decide
theorem cert_e602907500214 : check e602907500214 [[],[]] .chain = true := by decide
def e602907500246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e602907500246 : Closed e602907500246 ∧ code e602907500246 = 2801930755798 := by decide
theorem cert_e602907500246 : check e602907500246 [[],[]] .chain = true := by decide
def e602907500250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e602907500250 : Closed e602907500250 ∧ code e602907500250 = 2801930755802 := by decide
theorem cert_e602907500250 : check e602907500250 [[],[]] .chain = true := by decide
def e602907502446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e602907502446 : Closed e602907502446 ∧ code e602907502446 = 2801930757998 := by decide
theorem cert_e602907502446 : check e602907502446 [[],[]] .chain = true := by decide
def e602907502454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e602907502454 : Closed e602907502454 ∧ code e602907502454 = 2801930758006 := by decide
theorem cert_e602907502454 : check e602907502454 [[],[]] .chain = true := by decide
def e602907502518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e602907502518 : Closed e602907502518 ∧ code e602907502518 = 2801930758070 := by decide
theorem cert_e602907502518 : check e602907502518 [[],[]] .chain = true := by decide
def e602907503854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e602907503854 : Closed e602907503854 ∧ code e602907503854 = 2801930759406 := by decide
theorem cert_e602907503854 : check e602907503854 [[],[]] .chain = true := by decide
def e602907503862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e602907503862 : Closed e602907503862 ∧ code e602907503862 = 2801930759414 := by decide
theorem cert_e602907503862 : check e602907503862 [[],[]] .chain = true := by decide
def e602907504246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e602907504246 : Closed e602907504246 ∧ code e602907504246 = 2801930759798 := by decide
theorem cert_e602907504246 : check e602907504246 [[],[]] .chain = true := by decide
def e602907505134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2))))))
theorem wire_e602907505134 : Closed e602907505134 ∧ code e602907505134 = 2801930760686 := by decide
theorem cert_e602907505134 : check e602907505134 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e602907505518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e602907505518 : Closed e602907505518 ∧ code e602907505518 = 2801930761070 := by decide
theorem cert_e602907505518 : check e602907505518 [[],[]] .chain = true := by decide
def e602907505526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e602907505526 : Closed e602907505526 ∧ code e602907505526 = 2801930761078 := by decide
theorem cert_e602907505526 : check e602907505526 [[],[]] .chain = true := by decide
def e602907505582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e602907505582 : Closed e602907505582 ∧ code e602907505582 = 2801930761134 := by decide
theorem cert_e602907505582 : check e602907505582 [[],[]] .chain = true := by decide
def e602907505594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e602907505594 : Closed e602907505594 ∧ code e602907505594 = 2801930761146 := by decide
theorem cert_e602907505594 : check e602907505594 [[],[]] .chain = true := by decide
def e602907505622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e602907505622 : Closed e602907505622 ∧ code e602907505622 = 2801930761174 := by decide
theorem cert_e602907505622 : check e602907505622 [[],[]] .chain = true := by decide
def e602907505626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e602907505626 : Closed e602907505626 ∧ code e602907505626 = 2801930761178 := by decide
theorem cert_e602907505626 : check e602907505626 [[],[]] .chain = true := by decide
def e602907505902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e602907505902 : Closed e602907505902 ∧ code e602907505902 = 2801930761454 := by decide
theorem cert_e602907505902 : check e602907505902 [[],[]] .chain = true := by decide
def e602907505910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e602907505910 : Closed e602907505910 ∧ code e602907505910 = 2801930761462 := by decide
theorem cert_e602907505910 : check e602907505910 [[],[]] .chain = true := by decide
def e602907506286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e602907506286 : Closed e602907506286 ∧ code e602907506286 = 2801930761838 := by decide
theorem cert_e602907506286 : check e602907506286 [[],[]] .chain = true := by decide
def e602907506298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e602907506298 : Closed e602907506298 ∧ code e602907506298 = 2801930761850 := by decide
theorem cert_e602907506298 : check e602907506298 [[],[]] .chain = true := by decide
def e602907506462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3)))))))
theorem wire_e602907506462 : Closed e602907506462 ∧ code e602907506462 = 2801930762014 := by decide
theorem cert_e602907506462 : check e602907506462 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e602907506486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e602907506486 : Closed e602907506486 ∧ code e602907506486 = 2801930762038 := by decide
theorem cert_e602907506486 : check e602907506486 [[],[]] .chain = true := by decide
def e602907506490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e602907506490 : Closed e602907506490 ∧ code e602907506490 = 2801930762042 := by decide
theorem cert_e602907506490 : check e602907506490 [[],[]] .chain = true := by decide
def e602907506926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2))))))
theorem wire_e602907506926 : Closed e602907506926 ∧ code e602907506926 = 2801930762478 := by decide
theorem cert_e602907506926 : check e602907506926 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e602907506934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1))))))
theorem wire_e602907506934 : Closed e602907506934 ∧ code e602907506934 = 2801930762486 := by decide
theorem cert_e602907506934 : checkPay e602907506934 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e602907507126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e602907507126 : Closed e602907507126 ∧ code e602907507126 = 2801930762678 := by decide
theorem cert_e602907507126 : check e602907507126 [[],[]] .chain = true := by decide
def e602907507158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e602907507158 : Closed e602907507158 ∧ code e602907507158 = 2801930762710 := by decide
theorem cert_e602907507158 : check e602907507158 [[],[]] .chain = true := by decide
def e602907507162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e602907507162 : Closed e602907507162 ∧ code e602907507162 = 2801930762714 := by decide
theorem cert_e602907507162 : check e602907507162 [[],[]] .chain = true := by decide
def e602907507318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e602907507318 : Closed e602907507318 ∧ code e602907507318 = 2801930762870 := by decide
theorem cert_e602907507318 : check e602907507318 [[],[]] .chain = true := by decide
def e602907507486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3)))))))
theorem wire_e602907507486 : Closed e602907507486 ∧ code e602907507486 = 2801930763038 := by decide
theorem cert_e602907507486 : check e602907507486 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e602907507510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e602907507510 : Closed e602907507510 ∧ code e602907507510 = 2801930763062 := by decide
theorem cert_e602907507510 : check e602907507510 [[],[]] .chain = true := by decide
def e602907507514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e602907507514 : Closed e602907507514 ∧ code e602907507514 = 2801930763066 := by decide
theorem cert_e602907507514 : check e602907507514 [[],[]] .chain = true := by decide
def e602907507598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2)))))))
theorem wire_e602907507598 : Closed e602907507598 ∧ code e602907507598 = 2801930763150 := by decide
theorem cert_e602907507598 : check e602907507598 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e602907514734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e602907514734 : Closed e602907514734 ∧ code e602907514734 = 2801930770286 := by decide
theorem cert_e602907514734 : check e602907514734 [[],[]] .chain = true := by decide
def e602907514742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e602907514742 : Closed e602907514742 ∧ code e602907514742 = 2801930770294 := by decide
theorem cert_e602907514742 : check e602907514742 [[],[]] .chain = true := by decide
def e602907514806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e602907514806 : Closed e602907514806 ∧ code e602907514806 = 2801930770358 := by decide
theorem cert_e602907514806 : check e602907514806 [[],[]] .chain = true := by decide
def e602907516142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e602907516142 : Closed e602907516142 ∧ code e602907516142 = 2801930771694 := by decide
theorem cert_e602907516142 : check e602907516142 [[],[]] .chain = true := by decide
def e602907516150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e602907516150 : Closed e602907516150 ∧ code e602907516150 = 2801930771702 := by decide
theorem cert_e602907516150 : check e602907516150 [[],[]] .chain = true := by decide
def e602907516534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e602907516534 : Closed e602907516534 ∧ code e602907516534 = 2801930772086 := by decide
theorem cert_e602907516534 : check e602907516534 [[],[]] .chain = true := by decide
def e602907526110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e602907526110 : Closed e602907526110 ∧ code e602907526110 = 2801930781662 := by decide
theorem cert_e602907526110 : check e602907526110 [[],[]] .chain = true := by decide
def e602907526126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e602907526126 : Closed e602907526126 ∧ code e602907526126 = 2801930781678 := by decide
theorem cert_e602907526126 : check e602907526126 [[],[]] .chain = true := by decide
def e602907528046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e602907528046 : Closed e602907528046 ∧ code e602907528046 = 2801930783598 := by decide
theorem cert_e602907528046 : check e602907528046 [[],[]] .chain = true := by decide
def e602907528054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e602907528054 : Closed e602907528054 ∧ code e602907528054 = 2801930783606 := by decide
theorem cert_e602907528054 : check e602907528054 [[],[]] .chain = true := by decide
def e602907528110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e602907528110 : Closed e602907528110 ∧ code e602907528110 = 2801930783662 := by decide
theorem cert_e602907528110 : check e602907528110 [[],[]] .chain = true := by decide
def e602907528122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e602907528122 : Closed e602907528122 ∧ code e602907528122 = 2801930783674 := by decide
theorem cert_e602907528122 : check e602907528122 [[],[]] .chain = true := by decide
def e602907528150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e602907528150 : Closed e602907528150 ∧ code e602907528150 = 2801930783702 := by decide
theorem cert_e602907528150 : check e602907528150 [[],[]] .chain = true := by decide
def e602907528154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e602907528154 : Closed e602907528154 ∧ code e602907528154 = 2801930783706 := by decide
theorem cert_e602907528154 : check e602907528154 [[],[]] .chain = true := by decide
def e602907528430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e602907528430 : Closed e602907528430 ∧ code e602907528430 = 2801930783982 := by decide
theorem cert_e602907528430 : check e602907528430 [[],[]] .chain = true := by decide
def e602907528438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e602907528438 : Closed e602907528438 ∧ code e602907528438 = 2801930783990 := by decide
theorem cert_e602907528438 : check e602907528438 [[],[]] .chain = true := by decide
def e602907528814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e602907528814 : Closed e602907528814 ∧ code e602907528814 = 2801930784366 := by decide
theorem cert_e602907528814 : check e602907528814 [[],[]] .chain = true := by decide
def e602907528826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e602907528826 : Closed e602907528826 ∧ code e602907528826 = 2801930784378 := by decide
theorem cert_e602907528826 : check e602907528826 [[],[]] .chain = true := by decide
def e602907528990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e602907528990 : Closed e602907528990 ∧ code e602907528990 = 2801930784542 := by decide
theorem cert_e602907528990 : check e602907528990 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e602907529014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e602907529014 : Closed e602907529014 ∧ code e602907529014 = 2801930784566 := by decide
theorem cert_e602907529014 : check e602907529014 [[],[]] .chain = true := by decide
def e602907529018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e602907529018 : Closed e602907529018 ∧ code e602907529018 = 2801930784570 := by decide
theorem cert_e602907529018 : check e602907529018 [[],[]] .chain = true := by decide
def e602907533806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e602907533806 : Closed e602907533806 ∧ code e602907533806 = 2801930789358 := by decide
theorem cert_e602907533806 : check e602907533806 [[],[]] .chain = true := by decide
def e602907534774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e602907534774 : Closed e602907534774 ∧ code e602907534774 = 2801930790326 := by decide
theorem cert_e602907534774 : check e602907534774 [[],[]] .chain = true := by decide
def e602907534806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e602907534806 : Closed e602907534806 ∧ code e602907534806 = 2801930790358 := by decide
theorem cert_e602907534806 : check e602907534806 [[],[]] .chain = true := by decide
def e602907534810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e602907534810 : Closed e602907534810 ∧ code e602907534810 = 2801930790362 := by decide
theorem cert_e602907534810 : check e602907534810 [[],[]] .chain = true := by decide
def e602907534966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e602907534966 : Closed e602907534966 ∧ code e602907534966 = 2801930790518 := by decide
theorem cert_e602907534966 : check e602907534966 [[],[]] .chain = true := by decide
def e602907535134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e602907535134 : Closed e602907535134 ∧ code e602907535134 = 2801930790686 := by decide
theorem cert_e602907535134 : check e602907535134 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e602907535158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e602907535158 : Closed e602907535158 ∧ code e602907535158 = 2801930790710 := by decide
theorem cert_e602907535158 : check e602907535158 [[],[]] .chain = true := by decide
end Blc.Floor41
