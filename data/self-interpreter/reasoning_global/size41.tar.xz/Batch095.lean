import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605601636010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e605601636010 : Closed e605601636010 ∧ code e605601636010 = 2804624891562 := by decide
theorem cert_e605601636010 : check e605601636010 [[],[]] .chain = true := by decide
def e605601636526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e605601636526 : Closed e605601636526 ∧ code e605601636526 = 2804624892078 := by decide
theorem cert_e605601636526 : check e605601636526 [[],[]] .chain = true := by decide
def e605601636538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e605601636538 : Closed e605601636538 ∧ code e605601636538 = 2804624892090 := by decide
theorem cert_e605601636538 : check e605601636538 [[],[]] .chain = true := by decide
def e605601637102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e605601637102 : Closed e605601637102 ∧ code e605601637102 = 2804624892654 := by decide
theorem cert_e605601637102 : check e605601637102 [[],[]] .sourceHead = true := by decide
def e605601637230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e605601637230 : Closed e605601637230 ∧ code e605601637230 = 2804624892782 := by decide
theorem cert_e605601637230 : check e605601637230 [[],[]] .chain = true := by decide
def e605601637238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e605601637238 : Closed e605601637238 ∧ code e605601637238 = 2804624892790 := by decide
theorem cert_e605601637238 : check e605601637238 [[],[]] .chain = true := by decide
def e605601637294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e605601637294 : Closed e605601637294 ∧ code e605601637294 = 2804624892846 := by decide
theorem cert_e605601637294 : check e605601637294 [[],[]] .chain = true := by decide
def e605601637306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e605601637306 : Closed e605601637306 ∧ code e605601637306 = 2804624892858 := by decide
theorem cert_e605601637306 : check e605601637306 [[],[]] .chain = true := by decide
def e605601637334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e605601637334 : Closed e605601637334 ∧ code e605601637334 = 2804624892886 := by decide
theorem cert_e605601637334 : check e605601637334 [[],[]] .chain = true := by decide
def e605601637338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e605601637338 : Closed e605601637338 ∧ code e605601637338 = 2804624892890 := by decide
theorem cert_e605601637338 : check e605601637338 [[],[]] .chain = true := by decide
def e605601638062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e605601638062 : Closed e605601638062 ∧ code e605601638062 = 2804624893614 := by decide
theorem cert_e605601638062 : check e605601638062 [[],[]] .chain = true := by decide
def e605601638074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e605601638074 : Closed e605601638074 ∧ code e605601638074 = 2804624893626 := by decide
theorem cert_e605601638074 : check e605601638074 [[],[]] .chain = true := by decide
def e605601638122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e605601638122 : Closed e605601638122 ∧ code e605601638122 = 2804624893674 := by decide
theorem cert_e605601638122 : check e605601638122 [[],[]] .chain = true := by decide
def e605601638314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e605601638314 : Closed e605601638314 ∧ code e605601638314 = 2804624893866 := by decide
theorem cert_e605601638314 : check e605601638314 [[],[]] .chain = true := by decide
def e605601638446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e605601638446 : Closed e605601638446 ∧ code e605601638446 = 2804624893998 := by decide
theorem cert_e605601638446 : check e605601638446 [[],[]] .chain = true := by decide
def e605601638638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e605601638638 : Closed e605601638638 ∧ code e605601638638 = 2804624894190 := by decide
theorem cert_e605601638638 : check e605601638638 [[],[]] .chain = true := by decide
def e605601638646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e605601638646 : Closed e605601638646 ∧ code e605601638646 = 2804624894198 := by decide
theorem cert_e605601638646 : check e605601638646 [[],[]] .chain = true := by decide
def e605601638830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e605601638830 : Closed e605601638830 ∧ code e605601638830 = 2804624894382 := by decide
theorem cert_e605601638830 : check e605601638830 [[],[]] .chain = true := by decide
def e605601638842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e605601638842 : Closed e605601638842 ∧ code e605601638842 = 2804624894394 := by decide
theorem cert_e605601638842 : check e605601638842 [[],[]] .chain = true := by decide
def e605601638890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e605601638890 : Closed e605601638890 ∧ code e605601638890 = 2804624894442 := by decide
theorem cert_e605601638890 : check e605601638890 [[],[]] .chain = true := by decide
def e605601639022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601639022 : Closed e605601639022 ∧ code e605601639022 = 2804624894574 := by decide
theorem cert_e605601639022 : check e605601639022 [[],[]] .chain = true := by decide
def e605601639034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601639034 : Closed e605601639034 ∧ code e605601639034 = 2804624894586 := by decide
theorem cert_e605601639034 : check e605601639034 [[],[]] .chain = true := by decide
def e605601639198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e605601639198 : Closed e605601639198 ∧ code e605601639198 = 2804624894750 := by decide
theorem cert_e605601639198 : check e605601639198 [[],[]] .chain = true := by decide
def e605601639298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e605601639298 : Closed e605601639298 ∧ code e605601639298 = 2804624894850 := by decide
theorem cert_e605601639298 : check e605601639298 [[],[]] .chain = true := by decide
def e605601639310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e605601639310 : Closed e605601639310 ∧ code e605601639310 = 2804624894862 := by decide
theorem cert_e605601639310 : check e605601639310 [[],[]] .chain = true := by decide
def e605601639322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601639322 : Closed e605601639322 ∧ code e605601639322 = 2804624894874 := by decide
theorem cert_e605601639322 : check e605601639322 [[],[]] .chain = true := by decide
def e605601639534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e605601639534 : Closed e605601639534 ∧ code e605601639534 = 2804624895086 := by decide
theorem cert_e605601639534 : check e605601639534 [[],[]] .chain = true := by decide
def e605601639546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e605601639546 : Closed e605601639546 ∧ code e605601639546 = 2804624895098 := by decide
theorem cert_e605601639546 : check e605601639546 [[],[]] .chain = true := by decide
def e605601639710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e605601639710 : Closed e605601639710 ∧ code e605601639710 = 2804624895262 := by decide
theorem cert_e605601639710 : check e605601639710 [[],[]] .chain = true := by decide
def e605601639878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e605601639878 : Closed e605601639878 ∧ code e605601639878 = 2804624895430 := by decide
theorem cert_e605601639878 : check e605601639878 [[],[]] .chain = true := by decide
def e605601639946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601639946 : Closed e605601639946 ∧ code e605601639946 = 2804624895498 := by decide
theorem cert_e605601639946 : check e605601639946 [[],[]] .chain = true := by decide
def e605601639982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 2))))))
theorem wire_e605601639982 : Closed e605601639982 ∧ code e605601639982 = 2804624895534 := by decide
theorem cert_e605601639982 : check e605601639982 [[],[]] .sourceHead = true := by decide
def e605601639990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e605601639990 : Closed e605601639990 ∧ code e605601639990 = 2804624895542 := by decide
theorem cert_e605601639990 : check e605601639990 [[],[]] .chain = true := by decide
def e605601639994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e605601639994 : Closed e605601639994 ∧ code e605601639994 = 2804624895546 := by decide
theorem cert_e605601639994 : check e605601639994 [[],[]] .chain = true := by decide
def e605601640042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e605601640042 : Closed e605601640042 ∧ code e605601640042 = 2804624895594 := by decide
theorem cert_e605601640042 : check e605601640042 [[],[]] .chain = true := by decide
def e605601640066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e605601640066 : Closed e605601640066 ∧ code e605601640066 = 2804624895618 := by decide
theorem cert_e605601640066 : check e605601640066 [[],[]] .chain = true := by decide
def e605601640078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e605601640078 : Closed e605601640078 ∧ code e605601640078 = 2804624895630 := by decide
theorem cert_e605601640078 : check e605601640078 [[],[]] .chain = true := by decide
def e605601640090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601640090 : Closed e605601640090 ∧ code e605601640090 = 2804624895642 := by decide
theorem cert_e605601640090 : check e605601640090 [[],[]] .chain = true := by decide
def e605601640134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e605601640134 : Closed e605601640134 ∧ code e605601640134 = 2804624895686 := by decide
theorem cert_e605601640134 : check e605601640134 [[],[]] .chain = true := by decide
def e605601640162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e605601640162 : Closed e605601640162 ∧ code e605601640162 = 2804624895714 := by decide
theorem cert_e605601640162 : check e605601640162 [[],[]] .sourceHead = true := by decide
def e605601640174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 2))))))
theorem wire_e605601640174 : Closed e605601640174 ∧ code e605601640174 = 2804624895726 := by decide
theorem cert_e605601640174 : check e605601640174 [[],[]] .sourceHead = true := by decide
def e605601640878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e605601640878 : Closed e605601640878 ∧ code e605601640878 = 2804624896430 := by decide
theorem cert_e605601640878 : check e605601640878 [[],[]] .chain = true := by decide
def e605601640890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e605601640890 : Closed e605601640890 ∧ code e605601640890 = 2804624896442 := by decide
theorem cert_e605601640890 : check e605601640890 [[],[]] .chain = true := by decide
def e605601640938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e605601640938 : Closed e605601640938 ∧ code e605601640938 = 2804624896490 := by decide
theorem cert_e605601640938 : check e605601640938 [[],[]] .chain = true := by decide
def e605601641582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e605601641582 : Closed e605601641582 ∧ code e605601641582 = 2804624897134 := by decide
theorem cert_e605601641582 : check e605601641582 [[],[]] .chain = true := by decide
def e605601641594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e605601641594 : Closed e605601641594 ∧ code e605601641594 = 2804624897146 := by decide
theorem cert_e605601641594 : check e605601641594 [[],[]] .chain = true := by decide
def e605601641758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e605601641758 : Closed e605601641758 ∧ code e605601641758 = 2804624897310 := by decide
theorem cert_e605601641758 : check e605601641758 [[],[]] .chain = true := by decide
def e605601641926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e605601641926 : Closed e605601641926 ∧ code e605601641926 = 2804624897478 := by decide
theorem cert_e605601641926 : check e605601641926 [[],[]] .chain = true := by decide
def e605601642266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e605601642266 : Closed e605601642266 ∧ code e605601642266 = 2804624897818 := by decide
theorem cert_e605601642266 : check e605601642266 [[],[]] .chain = true := by decide
def e605601642310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e605601642310 : Closed e605601642310 ∧ code e605601642310 = 2804624897862 := by decide
theorem cert_e605601642310 : check e605601642310 [[],[]] .chain = true := by decide
def e605601642538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e605601642538 : Closed e605601642538 ∧ code e605601642538 = 2804624898090 := by decide
theorem cert_e605601642538 : check e605601642538 [[],[]] .chain = true := by decide
def e605601642670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e605601642670 : Closed e605601642670 ∧ code e605601642670 = 2804624898222 := by decide
theorem cert_e605601642670 : check e605601642670 [[],[]] .sourceHead = true := by decide
def e605601642682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e605601642682 : Closed e605601642682 ∧ code e605601642682 = 2804624898234 := by decide
theorem cert_e605601642682 : check e605601642682 [[],[]] .sourceHead = true := by decide
def e605601642710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e605601642710 : Closed e605601642710 ∧ code e605601642710 = 2804624898262 := by decide
theorem cert_e605601642710 : check e605601642710 [[],[]] .chain = true := by decide
def e605601642714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e605601642714 : Closed e605601642714 ∧ code e605601642714 = 2804624898266 := by decide
theorem cert_e605601642714 : check e605601642714 [[],[]] .chain = true := by decide
def e605601642730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e605601642730 : Closed e605601642730 ∧ code e605601642730 = 2804624898282 := by decide
theorem cert_e605601642730 : check e605601642730 [[],[]] .chain = true := by decide
def e605601642922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e605601642922 : Closed e605601642922 ∧ code e605601642922 = 2804624898474 := by decide
theorem cert_e605601642922 : check e605601642922 [[],[]] .chain = true := by decide
def e605601643018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601643018 : Closed e605601643018 ∧ code e605601643018 = 2804624898570 := by decide
theorem cert_e605601643018 : check e605601643018 [[],[]] .chain = true := by decide
def e605601643054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e605601643054 : Closed e605601643054 ∧ code e605601643054 = 2804624898606 := by decide
theorem cert_e605601643054 : check e605601643054 [[],[]] .sourceHead = true := by decide
def e605601643062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e605601643062 : Closed e605601643062 ∧ code e605601643062 = 2804624898614 := by decide
theorem cert_e605601643062 : check e605601643062 [[],[]] .chain = true := by decide
def e605601643066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e605601643066 : Closed e605601643066 ∧ code e605601643066 = 2804624898618 := by decide
theorem cert_e605601643066 : check e605601643066 [[],[]] .chain = true := by decide
def e605601643114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e605601643114 : Closed e605601643114 ∧ code e605601643114 = 2804624898666 := by decide
theorem cert_e605601643114 : check e605601643114 [[],[]] .chain = true := by decide
def e605601643138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e605601643138 : Closed e605601643138 ∧ code e605601643138 = 2804624898690 := by decide
theorem cert_e605601643138 : check e605601643138 [[],[]] .chain = true := by decide
def e605601643150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e605601643150 : Closed e605601643150 ∧ code e605601643150 = 2804624898702 := by decide
theorem cert_e605601643150 : check e605601643150 [[],[]] .chain = true := by decide
def e605601643162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601643162 : Closed e605601643162 ∧ code e605601643162 = 2804624898714 := by decide
theorem cert_e605601643162 : check e605601643162 [[],[]] .chain = true := by decide
def e605601643206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e605601643206 : Closed e605601643206 ∧ code e605601643206 = 2804624898758 := by decide
theorem cert_e605601643206 : check e605601643206 [[],[]] .chain = true := by decide
def e605601643234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e605601643234 : Closed e605601643234 ∧ code e605601643234 = 2804624898786 := by decide
theorem cert_e605601643234 : check e605601643234 [[],[]] .sourceHead = true := by decide
def e605601643246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e605601643246 : Closed e605601643246 ∧ code e605601643246 = 2804624898798 := by decide
theorem cert_e605601643246 : check e605601643246 [[],[]] .sourceHead = true := by decide
def e605601643290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e605601643290 : Closed e605601643290 ∧ code e605601643290 = 2804624898842 := by decide
theorem cert_e605601643290 : check e605601643290 [[],[]] .chain = true := by decide
def e605601643334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e605601643334 : Closed e605601643334 ∧ code e605601643334 = 2804624898886 := by decide
theorem cert_e605601643334 : check e605601643334 [[],[]] .chain = true := by decide
def e605601643402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e605601643402 : Closed e605601643402 ∧ code e605601643402 = 2804624898954 := by decide
theorem cert_e605601643402 : check e605601643402 [[],[]] .sourceHead = true := by decide
def e605601643426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e605601643426 : Closed e605601643426 ∧ code e605601643426 = 2804624898978 := by decide
theorem cert_e605601643426 : check e605601643426 [[],[]] .sourceHead = true := by decide
def e605601643438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e605601643438 : Closed e605601643438 ∧ code e605601643438 = 2804624898990 := by decide
theorem cert_e605601643438 : check e605601643438 [[],[]] .sourceHead = true := by decide
def e605601643450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e605601643450 : Closed e605601643450 ∧ code e605601643450 = 2804624899002 := by decide
theorem cert_e605601643450 : check e605601643450 [[],[]] .sourceHead = true := by decide
def e605601644886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e605601644886 : Closed e605601644886 ∧ code e605601644886 = 2804624900438 := by decide
theorem cert_e605601644886 : check e605601644886 [[],[]] .chain = true := by decide
def e605601644890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e605601644890 : Closed e605601644890 ∧ code e605601644890 = 2804624900442 := by decide
theorem cert_e605601644890 : check e605601644890 [[],[]] .chain = true := by decide
def e605601644906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e605601644906 : Closed e605601644906 ∧ code e605601644906 = 2804624900458 := by decide
theorem cert_e605601644906 : check e605601644906 [[],[]] .chain = true := by decide
def e605601645934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e605601645934 : Closed e605601645934 ∧ code e605601645934 = 2804624901486 := by decide
theorem cert_e605601645934 : check e605601645934 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601645942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e605601645942 : Closed e605601645942 ∧ code e605601645942 = 2804624901494 := by decide
theorem cert_e605601645942 : check e605601645942 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601645998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e605601645998 : Closed e605601645998 ∧ code e605601645998 = 2804624901550 := by decide
theorem cert_e605601645998 : check e605601645998 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601646010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e605601646010 : Closed e605601646010 ∧ code e605601646010 = 2804624901562 := by decide
theorem cert_e605601646010 : check e605601646010 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601646038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e605601646038 : Closed e605601646038 ∧ code e605601646038 = 2804624901590 := by decide
theorem cert_e605601646038 : check e605601646038 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601646042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e605601646042 : Closed e605601646042 ∧ code e605601646042 = 2804624901594 := by decide
theorem cert_e605601646042 : check e605601646042 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601646262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e605601646262 : Closed e605601646262 ∧ code e605601646262 = 2804624901814 := by decide
theorem cert_e605601646262 : check e605601646262 [[],[]] .chain = true := by decide
def e605601646294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e605601646294 : Closed e605601646294 ∧ code e605601646294 = 2804624901846 := by decide
theorem cert_e605601646294 : check e605601646294 [[],[]] .chain = true := by decide
def e605601646298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e605601646298 : Closed e605601646298 ∧ code e605601646298 = 2804624901850 := by decide
theorem cert_e605601646298 : check e605601646298 [[],[]] .chain = true := by decide
def e605601646422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e605601646422 : Closed e605601646422 ∧ code e605601646422 = 2804624901974 := by decide
theorem cert_e605601646422 : check e605601646422 [[],[]] .chain = true := by decide
def e605601646426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e605601646426 : Closed e605601646426 ∧ code e605601646426 = 2804624901978 := by decide
theorem cert_e605601646426 : check e605601646426 [[],[]] .chain = true := by decide
def e605601646442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e605601646442 : Closed e605601646442 ∧ code e605601646442 = 2804624901994 := by decide
theorem cert_e605601646442 : check e605601646442 [[],[]] .chain = true := by decide
def e605601647958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e605601647958 : Closed e605601647958 ∧ code e605601647958 = 2804624903510 := by decide
theorem cert_e605601647958 : check e605601647958 [[],[]] .chain = true := by decide
def e605601647962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e605601647962 : Closed e605601647962 ∧ code e605601647962 = 2804624903514 := by decide
theorem cert_e605601647962 : check e605601647962 [[],[]] .chain = true := by decide
def e605601647978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e605601647978 : Closed e605601647978 ∧ code e605601647978 = 2804624903530 := by decide
theorem cert_e605601647978 : check e605601647978 [[],[]] .chain = true := by decide
def e605601648042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e605601648042 : Closed e605601648042 ∧ code e605601648042 = 2804624903594 := by decide
theorem cert_e605601648042 : check e605601648042 [[],[]] .chain = true := by decide
def e605601648298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e605601648298 : Closed e605601648298 ∧ code e605601648298 = 2804624903850 := by decide
theorem cert_e605601648298 : check e605601648298 [[],[]] .chain = true := by decide
def e605601648726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e605601648726 : Closed e605601648726 ∧ code e605601648726 = 2804624904278 := by decide
theorem cert_e605601648726 : check e605601648726 [[],[]] .chain = true := by decide
def e605601648730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e605601648730 : Closed e605601648730 ∧ code e605601648730 = 2804624904282 := by decide
theorem cert_e605601648730 : check e605601648730 [[],[]] .chain = true := by decide
def e605601649006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e605601649006 : Closed e605601649006 ∧ code e605601649006 = 2804624904558 := by decide
theorem cert_e605601649006 : check e605601649006 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601649014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e605601649014 : Closed e605601649014 ∧ code e605601649014 = 2804624904566 := by decide
theorem cert_e605601649014 : check e605601649014 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601649078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e605601649078 : Closed e605601649078 ∧ code e605601649078 = 2804624904630 := by decide
theorem cert_e605601649078 : check e605601649078 [[],[]] .chain = true := by decide
def e605601649110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e605601649110 : Closed e605601649110 ∧ code e605601649110 = 2804624904662 := by decide
theorem cert_e605601649110 : check e605601649110 [[],[]] .chain = true := by decide
def e605601649114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e605601649114 : Closed e605601649114 ∧ code e605601649114 = 2804624904666 := by decide
theorem cert_e605601649114 : check e605601649114 [[],[]] .chain = true := by decide
def e605601649494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e605601649494 : Closed e605601649494 ∧ code e605601649494 = 2804624905046 := by decide
theorem cert_e605601649494 : check e605601649494 [[],[]] .chain = true := by decide
def e605601649498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e605601649498 : Closed e605601649498 ∧ code e605601649498 = 2804624905050 := by decide
theorem cert_e605601649498 : check e605601649498 [[],[]] .chain = true := by decide
def e605601649514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e605601649514 : Closed e605601649514 ∧ code e605601649514 = 2804624905066 := by decide
theorem cert_e605601649514 : check e605601649514 [[],[]] .chain = true := by decide
def e605601649578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e605601649578 : Closed e605601649578 ∧ code e605601649578 = 2804624905130 := by decide
theorem cert_e605601649578 : check e605601649578 [[],[]] .chain = true := by decide
def e605601649686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e605601649686 : Closed e605601649686 ∧ code e605601649686 = 2804624905238 := by decide
theorem cert_e605601649686 : check e605601649686 [[],[]] .chain = true := by decide
def e605601649782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e605601649782 : Closed e605601649782 ∧ code e605601649782 = 2804624905334 := by decide
theorem cert_e605601649782 : check e605601649782 [[],[]] .chain = true := by decide
def e605601649878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e605601649878 : Closed e605601649878 ∧ code e605601649878 = 2804624905430 := by decide
theorem cert_e605601649878 : check e605601649878 [[],[]] .chain = true := by decide
def e605601649882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e605601649882 : Closed e605601649882 ∧ code e605601649882 = 2804624905434 := by decide
theorem cert_e605601649882 : check e605601649882 [[],[]] .chain = true := by decide
def e605601649898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e605601649898 : Closed e605601649898 ∧ code e605601649898 = 2804624905450 := by decide
theorem cert_e605601649898 : check e605601649898 [[],[]] .chain = true := by decide
def e605601649974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601649974 : Closed e605601649974 ∧ code e605601649974 = 2804624905526 := by decide
theorem cert_e605601649974 : check e605601649974 [[],[]] .chain = true := by decide
def e605601649978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601649978 : Closed e605601649978 ∧ code e605601649978 = 2804624905530 := by decide
theorem cert_e605601649978 : check e605601649978 [[],[]] .chain = true := by decide
def e605601650050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e605601650050 : Closed e605601650050 ∧ code e605601650050 = 2804624905602 := by decide
theorem cert_e605601650050 : check e605601650050 [[],[]] .chain = true := by decide
def e605601650062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e605601650062 : Closed e605601650062 ∧ code e605601650062 = 2804624905614 := by decide
theorem cert_e605601650062 : check e605601650062 [[],[]] .chain = true := by decide
def e605601650074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601650074 : Closed e605601650074 ∧ code e605601650074 = 2804624905626 := by decide
theorem cert_e605601650074 : check e605601650074 [[],[]] .chain = true := by decide
def e605601650186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601650186 : Closed e605601650186 ∧ code e605601650186 = 2804624905738 := by decide
theorem cert_e605601650186 : check e605601650186 [[],[]] .chain = true := by decide
def e605601650222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e605601650222 : Closed e605601650222 ∧ code e605601650222 = 2804624905774 := by decide
theorem cert_e605601650222 : check e605601650222 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601650230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e605601650230 : Closed e605601650230 ∧ code e605601650230 = 2804624905782 := by decide
theorem cert_e605601650230 : check e605601650230 [[],[]] .chain = true := by decide
def e605601650234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e605601650234 : Closed e605601650234 ∧ code e605601650234 = 2804624905786 := by decide
theorem cert_e605601650234 : check e605601650234 [[],[]] .chain = true := by decide
def e605601650282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e605601650282 : Closed e605601650282 ∧ code e605601650282 = 2804624905834 := by decide
theorem cert_e605601650282 : check e605601650282 [[],[]] .chain = true := by decide
def e605601650306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e605601650306 : Closed e605601650306 ∧ code e605601650306 = 2804624905858 := by decide
theorem cert_e605601650306 : check e605601650306 [[],[]] .chain = true := by decide
def e605601650318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e605601650318 : Closed e605601650318 ∧ code e605601650318 = 2804624905870 := by decide
theorem cert_e605601650318 : check e605601650318 [[],[]] .chain = true := by decide
def e605601650330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601650330 : Closed e605601650330 ∧ code e605601650330 = 2804624905882 := by decide
theorem cert_e605601650330 : check e605601650330 [[],[]] .chain = true := by decide
def e605601650374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e605601650374 : Closed e605601650374 ∧ code e605601650374 = 2804624905926 := by decide
theorem cert_e605601650374 : check e605601650374 [[],[]] .chain = true := by decide
def e605601650402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e605601650402 : Closed e605601650402 ∧ code e605601650402 = 2804624905954 := by decide
theorem cert_e605601650402 : check e605601650402 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601650414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e605601650414 : Closed e605601650414 ∧ code e605601650414 = 2804624905966 := by decide
theorem cert_e605601650414 : check e605601650414 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e605601650454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e605601650454 : Closed e605601650454 ∧ code e605601650454 = 2804624906006 := by decide
theorem cert_e605601650454 : check e605601650454 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601650530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e605601650530 : Closed e605601650530 ∧ code e605601650530 = 2804624906082 := by decide
theorem cert_e605601650530 : check e605601650530 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601650542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e605601650542 : Closed e605601650542 ∧ code e605601650542 = 2804624906094 := by decide
theorem cert_e605601650542 : check e605601650542 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e605601650550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e605601650550 : Closed e605601650550 ∧ code e605601650550 = 2804624906102 := by decide
theorem cert_e605601650550 : checkPay e605601650550 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e605601650730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e605601650730 : Closed e605601650730 ∧ code e605601650730 = 2804624906282 := by decide
theorem cert_e605601650730 : check e605601650730 [[],[]] .chain = true := by decide
def e605601650862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e605601650862 : Closed e605601650862 ∧ code e605601650862 = 2804624906414 := by decide
theorem cert_e605601650862 : check e605601650862 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601650874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e605601650874 : Closed e605601650874 ∧ code e605601650874 = 2804624906426 := by decide
theorem cert_e605601650874 : check e605601650874 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601650902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e605601650902 : Closed e605601650902 ∧ code e605601650902 = 2804624906454 := by decide
theorem cert_e605601650902 : check e605601650902 [[],[]] .chain = true := by decide
def e605601650906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e605601650906 : Closed e605601650906 ∧ code e605601650906 = 2804624906458 := by decide
theorem cert_e605601650906 : check e605601650906 [[],[]] .chain = true := by decide
def e605601650922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e605601650922 : Closed e605601650922 ∧ code e605601650922 = 2804624906474 := by decide
theorem cert_e605601650922 : check e605601650922 [[],[]] .chain = true := by decide
def e605601651114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e605601651114 : Closed e605601651114 ∧ code e605601651114 = 2804624906666 := by decide
theorem cert_e605601651114 : check e605601651114 [[],[]] .chain = true := by decide
def e605601651210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601651210 : Closed e605601651210 ∧ code e605601651210 = 2804624906762 := by decide
theorem cert_e605601651210 : check e605601651210 [[],[]] .chain = true := by decide
def e605601651246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e605601651246 : Closed e605601651246 ∧ code e605601651246 = 2804624906798 := by decide
theorem cert_e605601651246 : check e605601651246 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601651254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e605601651254 : Closed e605601651254 ∧ code e605601651254 = 2804624906806 := by decide
theorem cert_e605601651254 : check e605601651254 [[],[]] .chain = true := by decide
def e605601651258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e605601651258 : Closed e605601651258 ∧ code e605601651258 = 2804624906810 := by decide
theorem cert_e605601651258 : check e605601651258 [[],[]] .chain = true := by decide
def e605601651306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e605601651306 : Closed e605601651306 ∧ code e605601651306 = 2804624906858 := by decide
theorem cert_e605601651306 : check e605601651306 [[],[]] .chain = true := by decide
def e605601651330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e605601651330 : Closed e605601651330 ∧ code e605601651330 = 2804624906882 := by decide
theorem cert_e605601651330 : check e605601651330 [[],[]] .chain = true := by decide
def e605601651342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e605601651342 : Closed e605601651342 ∧ code e605601651342 = 2804624906894 := by decide
theorem cert_e605601651342 : check e605601651342 [[],[]] .chain = true := by decide
def e605601651354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601651354 : Closed e605601651354 ∧ code e605601651354 = 2804624906906 := by decide
theorem cert_e605601651354 : check e605601651354 [[],[]] .chain = true := by decide
def e605601651398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e605601651398 : Closed e605601651398 ∧ code e605601651398 = 2804624906950 := by decide
theorem cert_e605601651398 : check e605601651398 [[],[]] .chain = true := by decide
def e605601651426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e605601651426 : Closed e605601651426 ∧ code e605601651426 = 2804624906978 := by decide
theorem cert_e605601651426 : check e605601651426 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601651438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e605601651438 : Closed e605601651438 ∧ code e605601651438 = 2804624906990 := by decide
theorem cert_e605601651438 : check e605601651438 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e605601651482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e605601651482 : Closed e605601651482 ∧ code e605601651482 = 2804624907034 := by decide
theorem cert_e605601651482 : check e605601651482 [[],[]] .chain = true := by decide
def e605601651526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e605601651526 : Closed e605601651526 ∧ code e605601651526 = 2804624907078 := by decide
theorem cert_e605601651526 : check e605601651526 [[],[]] .chain = true := by decide
def e605601651594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e605601651594 : Closed e605601651594 ∧ code e605601651594 = 2804624907146 := by decide
theorem cert_e605601651594 : check e605601651594 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601651618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e605601651618 : Closed e605601651618 ∧ code e605601651618 = 2804624907170 := by decide
theorem cert_e605601651618 : check e605601651618 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e605601651630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e605601651630 : Closed e605601651630 ∧ code e605601651630 = 2804624907182 := by decide
theorem cert_e605601651630 : check e605601651630 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e605601651642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e605601651642 : Closed e605601651642 ∧ code e605601651642 = 2804624907194 := by decide
theorem cert_e605601651642 : check e605601651642 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e605601651798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e605601651798 : Closed e605601651798 ∧ code e605601651798 = 2804624907350 := by decide
private def t_e605601651798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem cert_e605601651798 : ¬ IsSelfInterpreter e605601651798 :=
  wSource (t := t_e605601651798) (replay_sound (ps := []) (t := e605601651798) (by decide)) (by decide)
def e605601651802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e605601651802 : Closed e605601651802 ∧ code e605601651802 = 2804624907354 := by decide
private def t_e605601651802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem cert_e605601651802 : ¬ IsSelfInterpreter e605601651802 :=
  wSource (t := t_e605601651802) (replay_sound (ps := []) (t := e605601651802) (by decide)) (by decide)
def e605601651990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e605601651990 : Closed e605601651990 ∧ code e605601651990 = 2804624907542 := by decide
private def t_e605601651990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem cert_e605601651990 : ¬ IsSelfInterpreter e605601651990 :=
  wSource (t := t_e605601651990) (replay_sound (ps := []) (t := e605601651990) (by decide)) (by decide)
def e605601652066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e605601652066 : Closed e605601652066 ∧ code e605601652066 = 2804624907618 := by decide
private def t_e605601652066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem cert_e605601652066 : ¬ IsSelfInterpreter e605601652066 :=
  wSource (t := t_e605601652066) (replay_sound (ps := []) (t := e605601652066) (by decide)) (by decide)
def e605601652078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e605601652078 : Closed e605601652078 ∧ code e605601652078 = 2804624907630 := by decide
private def t_e605601652078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 2))))))
theorem cert_e605601652078 : ¬ IsSelfInterpreter e605601652078 :=
  wSource (t := t_e605601652078) (replay_sound (ps := []) (t := e605601652078) (by decide)) (by decide)
def e605601652086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e605601652086 : Closed e605601652086 ∧ code e605601652086 = 2804624907638 := by decide
private def t_e605601652086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 2)) (.var 1))))))
theorem cert_e605601652086 : ¬ IsSelfInterpreter e605601652086 :=
  wSource (t := t_e605601652086) (replay_sound (ps := []) (t := e605601652086) (by decide)) (by decide)
end Blc.Floor41
