import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e565593761210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e565593761210 : Closed e565593761210 ∧ code e565593761210 = 2764617016762 := by decide
theorem cert_e565593761210 : check e565593761210 [[],[.under]] .three = true := by decide
def e565593761238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e565593761238 : Closed e565593761238 ∧ code e565593761238 = 2764617016790 := by decide
theorem cert_e565593761238 : check e565593761238 [[],[.under]] .three = true := by decide
def e565593761242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e565593761242 : Closed e565593761242 ∧ code e565593761242 = 2764617016794 := by decide
theorem cert_e565593761242 : check e565593761242 [[],[.under]] .three = true := by decide
def e565593761258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e565593761258 : Closed e565593761258 ∧ code e565593761258 = 2764617016810 := by decide
theorem cert_e565593761258 : check e565593761258 [[],[.under]] .three = true := by decide
def e565593761390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e565593761390 : Closed e565593761390 ∧ code e565593761390 = 2764617016942 := by decide
theorem cert_e565593761390 : check e565593761390 [[],[.under]] .three = true := by decide
def e565593761398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e565593761398 : Closed e565593761398 ∧ code e565593761398 = 2764617016950 := by decide
theorem cert_e565593761398 : check e565593761398 [[],[.under]] .three = true := by decide
def e565593761402 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e565593761402 : Closed e565593761402 ∧ code e565593761402 = 2764617016954 := by decide
theorem cert_e565593761402 : check e565593761402 [[],[.under]] .three = true := by decide
def e565593761590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e565593761590 : Closed e565593761590 ∧ code e565593761590 = 2764617017142 := by decide
theorem cert_e565593761590 : check e565593761590 [[],[.under]] .three = true := by decide
def e565593761594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e565593761594 : Closed e565593761594 ∧ code e565593761594 = 2764617017146 := by decide
theorem cert_e565593761594 : check e565593761594 [[],[.under]] .three = true := by decide
def e565593761690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e565593761690 : Closed e565593761690 ∧ code e565593761690 = 2764617017242 := by decide
theorem cert_e565593761690 : check e565593761690 [[],[.under]] .three = true := by decide
def e565594207598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e565594207598 : Closed e565594207598 ∧ code e565594207598 = 2764617463150 := by decide
theorem cert_e565594207598 : check e565594207598 [[],[.under]] .three = true := by decide
def e565594207606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e565594207606 : Closed e565594207606 ∧ code e565594207606 = 2764617463158 := by decide
theorem cert_e565594207606 : check e565594207606 [[],[.under]] .three = true := by decide
def e565594207662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e565594207662 : Closed e565594207662 ∧ code e565594207662 = 2764617463214 := by decide
theorem cert_e565594207662 : check e565594207662 [[],[.under]] .three = true := by decide
def e565594207674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e565594207674 : Closed e565594207674 ∧ code e565594207674 = 2764617463226 := by decide
theorem cert_e565594207674 : check e565594207674 [[],[.under]] .three = true := by decide
def e565594207702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e565594207702 : Closed e565594207702 ∧ code e565594207702 = 2764617463254 := by decide
theorem cert_e565594207702 : check e565594207702 [[],[.under]] .three = true := by decide
def e565594207706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e565594207706 : Closed e565594207706 ∧ code e565594207706 = 2764617463258 := by decide
theorem cert_e565594207706 : check e565594207706 [[],[.under]] .three = true := by decide
def e565594207918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e565594207918 : Closed e565594207918 ∧ code e565594207918 = 2764617463470 := by decide
theorem cert_e565594207918 : check e565594207918 [[],[.under]] .three = true := by decide
def e565594207930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e565594207930 : Closed e565594207930 ∧ code e565594207930 = 2764617463482 := by decide
theorem cert_e565594207930 : check e565594207930 [[],[.under]] .three = true := by decide
def e565594207978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e565594207978 : Closed e565594207978 ∧ code e565594207978 = 2764617463530 := by decide
theorem cert_e565594207978 : check e565594207978 [[],[.under]] .three = true := by decide
def e565594208086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e565594208086 : Closed e565594208086 ∧ code e565594208086 = 2764617463638 := by decide
theorem cert_e565594208086 : check e565594208086 [[],[.under]] .three = true := by decide
def e565594208090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e565594208090 : Closed e565594208090 ∧ code e565594208090 = 2764617463642 := by decide
theorem cert_e565594208090 : check e565594208090 [[],[.under]] .three = true := by decide
def e565594208106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e565594208106 : Closed e565594208106 ∧ code e565594208106 = 2764617463658 := by decide
theorem cert_e565594208106 : check e565594208106 [[],[.under]] .three = true := by decide
def e565594208942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e565594208942 : Closed e565594208942 ∧ code e565594208942 = 2764617464494 := by decide
theorem cert_e565594208942 : check e565594208942 [[],[.under]] .three = true := by decide
def e565594208954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e565594208954 : Closed e565594208954 ∧ code e565594208954 = 2764617464506 := by decide
theorem cert_e565594208954 : check e565594208954 [[],[.under]] .three = true := by decide
def e565594209002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e565594209002 : Closed e565594209002 ∧ code e565594209002 = 2764617464554 := by decide
theorem cert_e565594209002 : check e565594209002 [[],[.under]] .three = true := by decide
def e565594209194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e565594209194 : Closed e565594209194 ∧ code e565594209194 = 2764617464746 := by decide
theorem cert_e565594209194 : check e565594209194 [[],[.under]] .three = true := by decide
def e565594209622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e565594209622 : Closed e565594209622 ∧ code e565594209622 = 2764617465174 := by decide
theorem cert_e565594209622 : check e565594209622 [[],[.under]] .three = true := by decide
def e565594209626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e565594209626 : Closed e565594209626 ∧ code e565594209626 = 2764617465178 := by decide
theorem cert_e565594209626 : check e565594209626 [[],[.under]] .three = true := by decide
def e565594209642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e565594209642 : Closed e565594209642 ∧ code e565594209642 = 2764617465194 := by decide
theorem cert_e565594209642 : check e565594209642 [[],[.under]] .three = true := by decide
def e565594209706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e565594209706 : Closed e565594209706 ∧ code e565594209706 = 2764617465258 := by decide
theorem cert_e565594209706 : check e565594209706 [[],[.under]] .three = true := by decide
def e565594212206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e565594212206 : Closed e565594212206 ∧ code e565594212206 = 2764617467758 := by decide
theorem cert_e565594212206 : check e565594212206 [[],[.under]] .three = true := by decide
def e565594212214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e565594212214 : Closed e565594212214 ∧ code e565594212214 = 2764617467766 := by decide
theorem cert_e565594212214 : check e565594212214 [[],[.under]] .three = true := by decide
def e565594212278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e565594212278 : Closed e565594212278 ∧ code e565594212278 = 2764617467830 := by decide
theorem cert_e565594212278 : check e565594212278 [[],[.under]] .three = true := by decide
def e565594213742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e565594213742 : Closed e565594213742 ∧ code e565594213742 = 2764617469294 := by decide
theorem cert_e565594213742 : check e565594213742 [[],[.under]] .three = true := by decide
def e565594213750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e565594213750 : Closed e565594213750 ∧ code e565594213750 = 2764617469302 := by decide
theorem cert_e565594213750 : check e565594213750 [[],[.under]] .three = true := by decide
def e565594213806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e565594213806 : Closed e565594213806 ∧ code e565594213806 = 2764617469358 := by decide
theorem cert_e565594213806 : check e565594213806 [[],[.under]] .three = true := by decide
def e565594213818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e565594213818 : Closed e565594213818 ∧ code e565594213818 = 2764617469370 := by decide
theorem cert_e565594213818 : check e565594213818 [[],[.under]] .three = true := by decide
def e565594213846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e565594213846 : Closed e565594213846 ∧ code e565594213846 = 2764617469398 := by decide
theorem cert_e565594213846 : check e565594213846 [[],[.under]] .three = true := by decide
def e565594213850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e565594213850 : Closed e565594213850 ∧ code e565594213850 = 2764617469402 := by decide
theorem cert_e565594213850 : check e565594213850 [[],[.under]] .three = true := by decide
def e565594214062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e565594214062 : Closed e565594214062 ∧ code e565594214062 = 2764617469614 := by decide
theorem cert_e565594214062 : check e565594214062 [[],[.under]] .three = true := by decide
def e565594214074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e565594214074 : Closed e565594214074 ∧ code e565594214074 = 2764617469626 := by decide
theorem cert_e565594214074 : check e565594214074 [[],[.under]] .three = true := by decide
def e565594214122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e565594214122 : Closed e565594214122 ∧ code e565594214122 = 2764617469674 := by decide
theorem cert_e565594214122 : check e565594214122 [[],[.under]] .three = true := by decide
def e565594214230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e565594214230 : Closed e565594214230 ∧ code e565594214230 = 2764617469782 := by decide
theorem cert_e565594214230 : check e565594214230 [[],[.under]] .three = true := by decide
def e565594214234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e565594214234 : Closed e565594214234 ∧ code e565594214234 = 2764617469786 := by decide
theorem cert_e565594214234 : check e565594214234 [[],[.under]] .three = true := by decide
def e565594214250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e565594214250 : Closed e565594214250 ∧ code e565594214250 = 2764617469802 := by decide
theorem cert_e565594214250 : check e565594214250 [[],[.under]] .three = true := by decide
def e565594215278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e565594215278 : Closed e565594215278 ∧ code e565594215278 = 2764617470830 := by decide
theorem cert_e565594215278 : check e565594215278 [[],[.under]] .three = true := by decide
def e565594215286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e565594215286 : Closed e565594215286 ∧ code e565594215286 = 2764617470838 := by decide
theorem cert_e565594215286 : check e565594215286 [[],[.under]] .three = true := by decide
def e565594215342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e565594215342 : Closed e565594215342 ∧ code e565594215342 = 2764617470894 := by decide
theorem cert_e565594215342 : check e565594215342 [[],[.under]] .three = true := by decide
def e565594215354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e565594215354 : Closed e565594215354 ∧ code e565594215354 = 2764617470906 := by decide
theorem cert_e565594215354 : check e565594215354 [[],[.under]] .three = true := by decide
def e565594215382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e565594215382 : Closed e565594215382 ∧ code e565594215382 = 2764617470934 := by decide
theorem cert_e565594215382 : check e565594215382 [[],[.under]] .three = true := by decide
def e565594215386 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e565594215386 : Closed e565594215386 ∧ code e565594215386 = 2764617470938 := by decide
theorem cert_e565594215386 : check e565594215386 [[],[.under]] .three = true := by decide
def e565594215662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e565594215662 : Closed e565594215662 ∧ code e565594215662 = 2764617471214 := by decide
theorem cert_e565594215662 : check e565594215662 [[],[.under]] .three = true := by decide
def e565594215670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e565594215670 : Closed e565594215670 ∧ code e565594215670 = 2764617471222 := by decide
theorem cert_e565594215670 : check e565594215670 [[],[.under]] .three = true := by decide
def e565594216046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e565594216046 : Closed e565594216046 ∧ code e565594216046 = 2764617471598 := by decide
theorem cert_e565594216046 : check e565594216046 [[],[.under]] .three = true := by decide
def e565594216058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e565594216058 : Closed e565594216058 ∧ code e565594216058 = 2764617471610 := by decide
theorem cert_e565594216058 : check e565594216058 [[],[.under]] .three = true := by decide
def e565594216246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e565594216246 : Closed e565594216246 ∧ code e565594216246 = 2764617471798 := by decide
theorem cert_e565594216246 : check e565594216246 [[],[.under]] .three = true := by decide
def e565594216250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e565594216250 : Closed e565594216250 ∧ code e565594216250 = 2764617471802 := by decide
theorem cert_e565594216250 : check e565594216250 [[],[.under]] .three = true := by decide
def e565594216686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e565594216686 : Closed e565594216686 ∧ code e565594216686 = 2764617472238 := by decide
theorem cert_e565594216686 : check e565594216686 [[],[.under]] .three = true := by decide
def e565594216694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e565594216694 : Closed e565594216694 ∧ code e565594216694 = 2764617472246 := by decide
theorem cert_e565594216694 : check e565594216694 [[],[.under]] .three = true := by decide
def e565594216878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e565594216878 : Closed e565594216878 ∧ code e565594216878 = 2764617472430 := by decide
theorem cert_e565594216878 : check e565594216878 [[],[.under]] .three = true := by decide
def e565594216890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e565594216890 : Closed e565594216890 ∧ code e565594216890 = 2764617472442 := by decide
theorem cert_e565594216890 : check e565594216890 [[],[.under]] .three = true := by decide
def e565594216938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e565594216938 : Closed e565594216938 ∧ code e565594216938 = 2764617472490 := by decide
theorem cert_e565594216938 : check e565594216938 [[],[.under]] .three = true := by decide
def e565594217070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e565594217070 : Closed e565594217070 ∧ code e565594217070 = 2764617472622 := by decide
theorem cert_e565594217070 : check e565594217070 [[],[.under]] .three = true := by decide
def e565594217082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e565594217082 : Closed e565594217082 ∧ code e565594217082 = 2764617472634 := by decide
theorem cert_e565594217082 : check e565594217082 [[],[.under]] .three = true := by decide
def e565594217246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e565594217246 : Closed e565594217246 ∧ code e565594217246 = 2764617472798 := by decide
theorem cert_e565594217246 : check e565594217246 [[],[.under]] .three = true := by decide
def e565594217358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e565594217358 : Closed e565594217358 ∧ code e565594217358 = 2764617472910 := by decide
theorem cert_e565594217358 : check e565594217358 [[],[.under]] .three = true := by decide
def e565594217370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e565594217370 : Closed e565594217370 ∧ code e565594217370 = 2764617472922 := by decide
theorem cert_e565594217370 : check e565594217370 [[],[.under]] .three = true := by decide
def e565594217590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e565594217590 : Closed e565594217590 ∧ code e565594217590 = 2764617473142 := by decide
theorem cert_e565594217590 : check e565594217590 [[],[.under]] .three = true := by decide
def e565594217686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e565594217686 : Closed e565594217686 ∧ code e565594217686 = 2764617473238 := by decide
theorem cert_e565594217686 : check e565594217686 [[],[.under]] .three = true := by decide
def e565594217690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e565594217690 : Closed e565594217690 ∧ code e565594217690 = 2764617473242 := by decide
theorem cert_e565594217690 : check e565594217690 [[],[.under]] .three = true := by decide
def e565594217706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e565594217706 : Closed e565594217706 ∧ code e565594217706 = 2764617473258 := by decide
theorem cert_e565594217706 : check e565594217706 [[],[.under]] .three = true := by decide
def e565594217782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e565594217782 : Closed e565594217782 ∧ code e565594217782 = 2764617473334 := by decide
theorem cert_e565594217782 : check e565594217782 [[],[.under]] .three = true := by decide
def e565594217786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e565594217786 : Closed e565594217786 ∧ code e565594217786 = 2764617473338 := by decide
theorem cert_e565594217786 : check e565594217786 [[],[.under]] .three = true := by decide
def e565594217870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e565594217870 : Closed e565594217870 ∧ code e565594217870 = 2764617473422 := by decide
theorem cert_e565594217870 : check e565594217870 [[],[.under]] .three = true := by decide
def e565594217882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e565594217882 : Closed e565594217882 ∧ code e565594217882 = 2764617473434 := by decide
theorem cert_e565594217882 : check e565594217882 [[],[.under]] .three = true := by decide
def e565594219374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e565594219374 : Closed e565594219374 ∧ code e565594219374 = 2764617474926 := by decide
theorem cert_e565594219374 : check e565594219374 [[],[.under]] .three = true := by decide
def e565594219382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e565594219382 : Closed e565594219382 ∧ code e565594219382 = 2764617474934 := by decide
theorem cert_e565594219382 : check e565594219382 [[],[.under]] .three = true := by decide
def e565594219438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e565594219438 : Closed e565594219438 ∧ code e565594219438 = 2764617474990 := by decide
theorem cert_e565594219438 : check e565594219438 [[],[.under]] .three = true := by decide
def e565594219450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e565594219450 : Closed e565594219450 ∧ code e565594219450 = 2764617475002 := by decide
theorem cert_e565594219450 : check e565594219450 [[],[.under]] .three = true := by decide
def e565594219478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e565594219478 : Closed e565594219478 ∧ code e565594219478 = 2764617475030 := by decide
theorem cert_e565594219478 : check e565594219478 [[],[.under]] .three = true := by decide
def e565594219482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e565594219482 : Closed e565594219482 ∧ code e565594219482 = 2764617475034 := by decide
theorem cert_e565594219482 : check e565594219482 [[],[.under]] .three = true := by decide
def e565594220206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e565594220206 : Closed e565594220206 ∧ code e565594220206 = 2764617475758 := by decide
theorem cert_e565594220206 : check e565594220206 [[],[.under]] .three = true := by decide
def e565594220218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e565594220218 : Closed e565594220218 ∧ code e565594220218 = 2764617475770 := by decide
theorem cert_e565594220218 : check e565594220218 [[],[.under]] .three = true := by decide
def e565594220266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e565594220266 : Closed e565594220266 ∧ code e565594220266 = 2764617475818 := by decide
theorem cert_e565594220266 : check e565594220266 [[],[.under]] .three = true := by decide
def e565594220458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e565594220458 : Closed e565594220458 ∧ code e565594220458 = 2764617476010 := by decide
theorem cert_e565594220458 : check e565594220458 [[],[.under]] .three = true := by decide
def e565594220782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e565594220782 : Closed e565594220782 ∧ code e565594220782 = 2764617476334 := by decide
theorem cert_e565594220782 : check e565594220782 [[],[.under]] .three = true := by decide
def e565594220790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e565594220790 : Closed e565594220790 ∧ code e565594220790 = 2764617476342 := by decide
theorem cert_e565594220790 : check e565594220790 [[],[.under]] .three = true := by decide
def e565594220974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e565594220974 : Closed e565594220974 ∧ code e565594220974 = 2764617476526 := by decide
theorem cert_e565594220974 : check e565594220974 [[],[.under]] .three = true := by decide
def e565594220986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e565594220986 : Closed e565594220986 ∧ code e565594220986 = 2764617476538 := by decide
theorem cert_e565594220986 : check e565594220986 [[],[.under]] .three = true := by decide
def e565594221034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e565594221034 : Closed e565594221034 ∧ code e565594221034 = 2764617476586 := by decide
theorem cert_e565594221034 : check e565594221034 [[],[.under]] .three = true := by decide
def e565594221166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e565594221166 : Closed e565594221166 ∧ code e565594221166 = 2764617476718 := by decide
theorem cert_e565594221166 : check e565594221166 [[],[.under]] .three = true := by decide
def e565594221178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e565594221178 : Closed e565594221178 ∧ code e565594221178 = 2764617476730 := by decide
theorem cert_e565594221178 : check e565594221178 [[],[.under]] .three = true := by decide
def e565594221342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e565594221342 : Closed e565594221342 ∧ code e565594221342 = 2764617476894 := by decide
theorem cert_e565594221342 : check e565594221342 [[],[.under]] .three = true := by decide
def e565594221454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e565594221454 : Closed e565594221454 ∧ code e565594221454 = 2764617477006 := by decide
theorem cert_e565594221454 : check e565594221454 [[],[.under]] .three = true := by decide
def e565594221466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e565594221466 : Closed e565594221466 ∧ code e565594221466 = 2764617477018 := by decide
theorem cert_e565594221466 : check e565594221466 [[],[.under]] .three = true := by decide
def e565594221678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e565594221678 : Closed e565594221678 ∧ code e565594221678 = 2764617477230 := by decide
theorem cert_e565594221678 : check e565594221678 [[],[.under]] .three = true := by decide
def e565594221690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e565594221690 : Closed e565594221690 ∧ code e565594221690 = 2764617477242 := by decide
theorem cert_e565594221690 : check e565594221690 [[],[.under]] .three = true := by decide
def e565594221854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e565594221854 : Closed e565594221854 ∧ code e565594221854 = 2764617477406 := by decide
theorem cert_e565594221854 : check e565594221854 [[],[.under]] .three = true := by decide
def e565594222022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e565594222022 : Closed e565594222022 ∧ code e565594222022 = 2764617477574 := by decide
theorem cert_e565594222022 : check e565594222022 [[],[.under]] .three = true := by decide
def e565594222134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e565594222134 : Closed e565594222134 ∧ code e565594222134 = 2764617477686 := by decide
theorem cert_e565594222134 : check e565594222134 [[],[.under]] .three = true := by decide
def e565594222138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e565594222138 : Closed e565594222138 ∧ code e565594222138 = 2764617477690 := by decide
theorem cert_e565594222138 : check e565594222138 [[],[.under]] .three = true := by decide
def e565594222186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e565594222186 : Closed e565594222186 ∧ code e565594222186 = 2764617477738 := by decide
theorem cert_e565594222186 : check e565594222186 [[],[.under]] .three = true := by decide
def e565594222222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e565594222222 : Closed e565594222222 ∧ code e565594222222 = 2764617477774 := by decide
theorem cert_e565594222222 : check e565594222222 [[],[.under]] .three = true := by decide
def e565594222234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e565594222234 : Closed e565594222234 ∧ code e565594222234 = 2764617477786 := by decide
theorem cert_e565594222234 : check e565594222234 [[],[.under]] .three = true := by decide
def e565594222278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e565594222278 : Closed e565594222278 ∧ code e565594222278 = 2764617477830 := by decide
theorem cert_e565594222278 : check e565594222278 [[],[.under]] .three = true := by decide
def e565594223030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e565594223030 : Closed e565594223030 ∧ code e565594223030 = 2764617478582 := by decide
theorem cert_e565594223030 : check e565594223030 [[],[.under]] .three = true := by decide
def e565594223062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e565594223062 : Closed e565594223062 ∧ code e565594223062 = 2764617478614 := by decide
theorem cert_e565594223062 : check e565594223062 [[],[.under]] .three = true := by decide
def e565594223066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e565594223066 : Closed e565594223066 ∧ code e565594223066 = 2764617478618 := by decide
theorem cert_e565594223066 : check e565594223066 [[],[.under]] .three = true := by decide
def e565594223446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e565594223446 : Closed e565594223446 ∧ code e565594223446 = 2764617478998 := by decide
theorem cert_e565594223446 : check e565594223446 [[],[.under]] .three = true := by decide
def e565594223450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e565594223450 : Closed e565594223450 ∧ code e565594223450 = 2764617479002 := by decide
theorem cert_e565594223450 : check e565594223450 [[],[.under]] .three = true := by decide
def e565594223466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e565594223466 : Closed e565594223466 ∧ code e565594223466 = 2764617479018 := by decide
theorem cert_e565594223466 : check e565594223466 [[],[.under]] .three = true := by decide
def e565594223530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e565594223530 : Closed e565594223530 ∧ code e565594223530 = 2764617479082 := by decide
theorem cert_e565594223530 : check e565594223530 [[],[.under]] .three = true := by decide
def e565594223734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e565594223734 : Closed e565594223734 ∧ code e565594223734 = 2764617479286 := by decide
theorem cert_e565594223734 : check e565594223734 [[],[.under]] .three = true := by decide
def e565594223830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e565594223830 : Closed e565594223830 ∧ code e565594223830 = 2764617479382 := by decide
theorem cert_e565594223830 : check e565594223830 [[],[.under]] .three = true := by decide
def e565594223834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e565594223834 : Closed e565594223834 ∧ code e565594223834 = 2764617479386 := by decide
theorem cert_e565594223834 : check e565594223834 [[],[.under]] .three = true := by decide
def e565594223850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e565594223850 : Closed e565594223850 ∧ code e565594223850 = 2764617479402 := by decide
theorem cert_e565594223850 : check e565594223850 [[],[.under]] .three = true := by decide
def e565594223926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e565594223926 : Closed e565594223926 ∧ code e565594223926 = 2764617479478 := by decide
theorem cert_e565594223926 : check e565594223926 [[],[.under]] .three = true := by decide
def e565594223930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e565594223930 : Closed e565594223930 ∧ code e565594223930 = 2764617479482 := by decide
theorem cert_e565594223930 : check e565594223930 [[],[.under]] .three = true := by decide
def e565594224014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e565594224014 : Closed e565594224014 ∧ code e565594224014 = 2764617479566 := by decide
theorem cert_e565594224014 : check e565594224014 [[],[.under]] .three = true := by decide
def e565594224026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e565594224026 : Closed e565594224026 ∧ code e565594224026 = 2764617479578 := by decide
theorem cert_e565594224026 : check e565594224026 [[],[.under]] .three = true := by decide
def e565594224182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e565594224182 : Closed e565594224182 ∧ code e565594224182 = 2764617479734 := by decide
theorem cert_e565594224182 : check e565594224182 [[],[.under]] .three = true := by decide
def e565594224186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e565594224186 : Closed e565594224186 ∧ code e565594224186 = 2764617479738 := by decide
theorem cert_e565594224186 : check e565594224186 [[],[.under]] .three = true := by decide
def e565594224234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e565594224234 : Closed e565594224234 ∧ code e565594224234 = 2764617479786 := by decide
theorem cert_e565594224234 : check e565594224234 [[],[.under]] .three = true := by decide
def e565594224270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e565594224270 : Closed e565594224270 ∧ code e565594224270 = 2764617479822 := by decide
theorem cert_e565594224270 : check e565594224270 [[],[.under]] .three = true := by decide
def e565594224282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e565594224282 : Closed e565594224282 ∧ code e565594224282 = 2764617479834 := by decide
theorem cert_e565594224282 : check e565594224282 [[],[.under]] .three = true := by decide
def e565594224326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e565594224326 : Closed e565594224326 ∧ code e565594224326 = 2764617479878 := by decide
theorem cert_e565594224326 : check e565594224326 [[],[.under]] .three = true := by decide
def e565594230510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e565594230510 : Closed e565594230510 ∧ code e565594230510 = 2764617486062 := by decide
theorem cert_e565594230510 : check e565594230510 [[],[.under]] .three = true := by decide
def e565594230518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e565594230518 : Closed e565594230518 ∧ code e565594230518 = 2764617486070 := by decide
theorem cert_e565594230518 : check e565594230518 [[],[.under]] .three = true := by decide
def e565594230638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e565594230638 : Closed e565594230638 ∧ code e565594230638 = 2764617486190 := by decide
theorem cert_e565594230638 : check e565594230638 [[],[.under]] .three = true := by decide
def e565594230650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e565594230650 : Closed e565594230650 ∧ code e565594230650 = 2764617486202 := by decide
theorem cert_e565594230650 : check e565594230650 [[],[.under]] .three = true := by decide
def e565594230710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e565594230710 : Closed e565594230710 ∧ code e565594230710 = 2764617486262 := by decide
theorem cert_e565594230710 : check e565594230710 [[],[.under]] .three = true := by decide
def e565594230714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e565594230714 : Closed e565594230714 ∧ code e565594230714 = 2764617486266 := by decide
theorem cert_e565594230714 : check e565594230714 [[],[.under]] .three = true := by decide
def e565594234094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e565594234094 : Closed e565594234094 ∧ code e565594234094 = 2764617489646 := by decide
theorem cert_e565594234094 : check e565594234094 [[],[.under]] .three = true := by decide
def e565594234102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e565594234102 : Closed e565594234102 ∧ code e565594234102 = 2764617489654 := by decide
theorem cert_e565594234102 : check e565594234102 [[],[.under]] .three = true := by decide
def e565594234486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e565594234486 : Closed e565594234486 ∧ code e565594234486 = 2764617490038 := by decide
theorem cert_e565594234486 : check e565594234486 [[],[.under]] .three = true := by decide
def e565594238318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e565594238318 : Closed e565594238318 ∧ code e565594238318 = 2764617493870 := by decide
theorem cert_e565594238318 : check e565594238318 [[],[.under]] .three = true := by decide
def e565594238326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e565594238326 : Closed e565594238326 ∧ code e565594238326 = 2764617493878 := by decide
theorem cert_e565594238326 : check e565594238326 [[],[.under]] .three = true := by decide
def e565594238382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e565594238382 : Closed e565594238382 ∧ code e565594238382 = 2764617493934 := by decide
theorem cert_e565594238382 : check e565594238382 [[],[.under]] .three = true := by decide
def e565594238394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e565594238394 : Closed e565594238394 ∧ code e565594238394 = 2764617493946 := by decide
theorem cert_e565594238394 : check e565594238394 [[],[.under]] .three = true := by decide
def e565594238422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e565594238422 : Closed e565594238422 ∧ code e565594238422 = 2764617493974 := by decide
theorem cert_e565594238422 : check e565594238422 [[],[.under]] .three = true := by decide
def e565594238426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e565594238426 : Closed e565594238426 ∧ code e565594238426 = 2764617493978 := by decide
theorem cert_e565594238426 : check e565594238426 [[],[.under]] .three = true := by decide
def e565594238638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e565594238638 : Closed e565594238638 ∧ code e565594238638 = 2764617494190 := by decide
theorem cert_e565594238638 : check e565594238638 [[],[.under]] .three = true := by decide
def e565594238650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e565594238650 : Closed e565594238650 ∧ code e565594238650 = 2764617494202 := by decide
theorem cert_e565594238650 : check e565594238650 [[],[.under]] .three = true := by decide
def e565594238698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e565594238698 : Closed e565594238698 ∧ code e565594238698 = 2764617494250 := by decide
theorem cert_e565594238698 : check e565594238698 [[],[.under]] .three = true := by decide
def e565594238806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e565594238806 : Closed e565594238806 ∧ code e565594238806 = 2764617494358 := by decide
theorem cert_e565594238806 : check e565594238806 [[],[.under]] .three = true := by decide
def e565594238810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e565594238810 : Closed e565594238810 ∧ code e565594238810 = 2764617494362 := by decide
theorem cert_e565594238810 : check e565594238810 [[],[.under]] .three = true := by decide
def e565594238826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e565594238826 : Closed e565594238826 ∧ code e565594238826 = 2764617494378 := by decide
theorem cert_e565594238826 : check e565594238826 [[],[.under]] .three = true := by decide
def e565594239854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e565594239854 : Closed e565594239854 ∧ code e565594239854 = 2764617495406 := by decide
theorem cert_e565594239854 : check e565594239854 [[],[.under]] .three = true := by decide
def e565594239862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e565594239862 : Closed e565594239862 ∧ code e565594239862 = 2764617495414 := by decide
theorem cert_e565594239862 : check e565594239862 [[],[.under]] .three = true := by decide
def e565594239918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e565594239918 : Closed e565594239918 ∧ code e565594239918 = 2764617495470 := by decide
theorem cert_e565594239918 : check e565594239918 [[],[.under]] .three = true := by decide
def e565594239930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e565594239930 : Closed e565594239930 ∧ code e565594239930 = 2764617495482 := by decide
theorem cert_e565594239930 : check e565594239930 [[],[.under]] .three = true := by decide
def e565594239958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e565594239958 : Closed e565594239958 ∧ code e565594239958 = 2764617495510 := by decide
theorem cert_e565594239958 : check e565594239958 [[],[.under]] .three = true := by decide
def e565594239962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e565594239962 : Closed e565594239962 ∧ code e565594239962 = 2764617495514 := by decide
theorem cert_e565594239962 : check e565594239962 [[],[.under]] .three = true := by decide
def e565594240238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e565594240238 : Closed e565594240238 ∧ code e565594240238 = 2764617495790 := by decide
theorem cert_e565594240238 : check e565594240238 [[],[.under]] .three = true := by decide
def e565594240246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e565594240246 : Closed e565594240246 ∧ code e565594240246 = 2764617495798 := by decide
theorem cert_e565594240246 : check e565594240246 [[],[.under]] .three = true := by decide
def e565594240622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e565594240622 : Closed e565594240622 ∧ code e565594240622 = 2764617496174 := by decide
theorem cert_e565594240622 : check e565594240622 [[],[.under]] .three = true := by decide
def e565594240634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e565594240634 : Closed e565594240634 ∧ code e565594240634 = 2764617496186 := by decide
theorem cert_e565594240634 : check e565594240634 [[],[.under]] .three = true := by decide
def e565594240822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e565594240822 : Closed e565594240822 ∧ code e565594240822 = 2764617496374 := by decide
theorem cert_e565594240822 : check e565594240822 [[],[.under]] .three = true := by decide
def e565594240826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e565594240826 : Closed e565594240826 ∧ code e565594240826 = 2764617496378 := by decide
theorem cert_e565594240826 : check e565594240826 [[],[.under]] .three = true := by decide
def e565594241262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e565594241262 : Closed e565594241262 ∧ code e565594241262 = 2764617496814 := by decide
theorem cert_e565594241262 : check e565594241262 [[],[.under]] .three = true := by decide
end Blc.Floor41
