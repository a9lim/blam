import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605606310794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605606310794 : Closed e605606310794 ∧ code e605606310794 = 2804629566346 := by decide
theorem cert_e605606310794 : check e605606310794 [[],[],[.under,.under]] .three = true := by decide
def e605606310818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605606310818 : Closed e605606310818 ∧ code e605606310818 = 2804629566370 := by decide
theorem cert_e605606310818 : check e605606310818 [[],[],[.under,.under]] .three = true := by decide
def e605606310830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605606310830 : Closed e605606310830 ∧ code e605606310830 = 2804629566382 := by decide
theorem cert_e605606310830 : check e605606310830 [[],[],[.under,.under]] .three = true := by decide
def e605606310842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605606310842 : Closed e605606310842 ∧ code e605606310842 = 2804629566394 := by decide
theorem cert_e605606310842 : check e605606310842 [[],[],[.under,.under]] .three = true := by decide
def e605606310870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605606310870 : Closed e605606310870 ∧ code e605606310870 = 2804629566422 := by decide
theorem cert_e605606310870 : check e605606310870 [[],[],[.under,.under]] .three = true := by decide
def e605606310874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605606310874 : Closed e605606310874 ∧ code e605606310874 = 2804629566426 := by decide
theorem cert_e605606310874 : check e605606310874 [[],[],[.under,.under]] .three = true := by decide
def e605606310942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e605606310942 : Closed e605606310942 ∧ code e605606310942 = 2804629566494 := by decide
theorem cert_e605606310942 : check e605606310942 [[],[],[.under,.under]] .three = true := by decide
def e605606311138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e605606311138 : Closed e605606311138 ∧ code e605606311138 = 2804629566690 := by decide
theorem cert_e605606311138 : check e605606311138 [[],[],[.under,.under]] .three = true := by decide
def e605606311150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605606311150 : Closed e605606311150 ∧ code e605606311150 = 2804629566702 := by decide
theorem cert_e605606311150 : check e605606311150 [[],[],[.under,.under]] .three = true := by decide
def e605606311158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605606311158 : Closed e605606311158 ∧ code e605606311158 = 2804629566710 := by decide
theorem cert_e605606311158 : check e605606311158 [[],[],[.under,.under]] .three = true := by decide
def e605606311438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e605606311438 : Closed e605606311438 ∧ code e605606311438 = 2804629566990 := by decide
theorem cert_e605606311438 : check e605606311438 [[],[],[.under,.under]] .three = true := by decide
def e605606311522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605606311522 : Closed e605606311522 ∧ code e605606311522 = 2804629567074 := by decide
theorem cert_e605606311522 : check e605606311522 [[],[],[.under,.under]] .three = true := by decide
def e605606311534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605606311534 : Closed e605606311534 ∧ code e605606311534 = 2804629567086 := by decide
theorem cert_e605606311534 : check e605606311534 [[],[],[.under,.under]] .three = true := by decide
def e605606311546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605606311546 : Closed e605606311546 ∧ code e605606311546 = 2804629567098 := by decide
theorem cert_e605606311546 : check e605606311546 [[],[],[.under,.under]] .three = true := by decide
def e605606311734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605606311734 : Closed e605606311734 ∧ code e605606311734 = 2804629567286 := by decide
private def t_e605606311734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e605606311734 : ¬ IsSelfInterpreter e605606311734 :=
  wSource (t := t_e605606311734) (replay_sound (ps := []) (t := e605606311734) (by decide)) (by decide)
def e605606311738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605606311738 : Closed e605606311738 ∧ code e605606311738 = 2804629567290 := by decide
private def t_e605606311738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e605606311738 : ¬ IsSelfInterpreter e605606311738 :=
  wSource (t := t_e605606311738) (replay_sound (ps := []) (t := e605606311738) (by decide)) (by decide)
def e605606314974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e605606314974 : Closed e605606314974 ∧ code e605606314974 = 2804629570526 := by decide
theorem cert_e605606314974 : check e605606314974 [[],[]] .chain = true := by decide
def e605606314990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e605606314990 : Closed e605606314990 ∧ code e605606314990 = 2804629570542 := by decide
theorem cert_e605606314990 : check e605606314990 [[],[]] .chain = true := by decide
def e605606316910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605606316910 : Closed e605606316910 ∧ code e605606316910 = 2804629572462 := by decide
theorem cert_e605606316910 : check e605606316910 [[],[]] .chain = true := by decide
def e605606316918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605606316918 : Closed e605606316918 ∧ code e605606316918 = 2804629572470 := by decide
theorem cert_e605606316918 : check e605606316918 [[],[]] .chain = true := by decide
def e605606316974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605606316974 : Closed e605606316974 ∧ code e605606316974 = 2804629572526 := by decide
theorem cert_e605606316974 : check e605606316974 [[],[]] .chain = true := by decide
def e605606316986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605606316986 : Closed e605606316986 ∧ code e605606316986 = 2804629572538 := by decide
theorem cert_e605606316986 : check e605606316986 [[],[]] .chain = true := by decide
def e605606317014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605606317014 : Closed e605606317014 ∧ code e605606317014 = 2804629572566 := by decide
theorem cert_e605606317014 : check e605606317014 [[],[]] .chain = true := by decide
def e605606317018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605606317018 : Closed e605606317018 ∧ code e605606317018 = 2804629572570 := by decide
theorem cert_e605606317018 : check e605606317018 [[],[]] .chain = true := by decide
def e605606317294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605606317294 : Closed e605606317294 ∧ code e605606317294 = 2804629572846 := by decide
theorem cert_e605606317294 : check e605606317294 [[],[]] .chain = true := by decide
def e605606317302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605606317302 : Closed e605606317302 ∧ code e605606317302 = 2804629572854 := by decide
theorem cert_e605606317302 : check e605606317302 [[],[]] .chain = true := by decide
def e605606317678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605606317678 : Closed e605606317678 ∧ code e605606317678 = 2804629573230 := by decide
theorem cert_e605606317678 : check e605606317678 [[],[]] .chain = true := by decide
def e605606317690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605606317690 : Closed e605606317690 ∧ code e605606317690 = 2804629573242 := by decide
theorem cert_e605606317690 : check e605606317690 [[],[]] .chain = true := by decide
def e605606317854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e605606317854 : Closed e605606317854 ∧ code e605606317854 = 2804629573406 := by decide
theorem cert_e605606317854 : check e605606317854 [[],[]] .chain = true := by decide
def e605606317878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605606317878 : Closed e605606317878 ∧ code e605606317878 = 2804629573430 := by decide
theorem cert_e605606317878 : check e605606317878 [[],[]] .chain = true := by decide
def e605606317882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605606317882 : Closed e605606317882 ∧ code e605606317882 = 2804629573434 := by decide
theorem cert_e605606317882 : check e605606317882 [[],[]] .chain = true := by decide
def e605606325078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605606325078 : Closed e605606325078 ∧ code e605606325078 = 2804629580630 := by decide
theorem cert_e605606325078 : check e605606325078 [[],[]] .chain = true := by decide
def e605606325082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605606325082 : Closed e605606325082 ∧ code e605606325082 = 2804629580634 := by decide
theorem cert_e605606325082 : check e605606325082 [[],[]] .chain = true := by decide
def e605606325098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605606325098 : Closed e605606325098 ∧ code e605606325098 = 2804629580650 := by decide
theorem cert_e605606325098 : check e605606325098 [[],[]] .chain = true := by decide
def e605606325162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605606325162 : Closed e605606325162 ∧ code e605606325162 = 2804629580714 := by decide
theorem cert_e605606325162 : check e605606325162 [[],[]] .chain = true := by decide
def e605606325270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605606325270 : Closed e605606325270 ∧ code e605606325270 = 2804629580822 := by decide
theorem cert_e605606325270 : check e605606325270 [[],[]] .chain = true := by decide
def e605606325366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e605606325366 : Closed e605606325366 ∧ code e605606325366 = 2804629580918 := by decide
theorem cert_e605606325366 : check e605606325366 [[],[]] .chain = true := by decide
def e605606325462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605606325462 : Closed e605606325462 ∧ code e605606325462 = 2804629581014 := by decide
theorem cert_e605606325462 : check e605606325462 [[],[]] .chain = true := by decide
def e605606325466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605606325466 : Closed e605606325466 ∧ code e605606325466 = 2804629581018 := by decide
theorem cert_e605606325466 : check e605606325466 [[],[]] .chain = true := by decide
def e605606325482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605606325482 : Closed e605606325482 ∧ code e605606325482 = 2804629581034 := by decide
theorem cert_e605606325482 : check e605606325482 [[],[]] .chain = true := by decide
def e605606325558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605606325558 : Closed e605606325558 ∧ code e605606325558 = 2804629581110 := by decide
theorem cert_e605606325558 : check e605606325558 [[],[]] .chain = true := by decide
def e605606325562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605606325562 : Closed e605606325562 ∧ code e605606325562 = 2804629581114 := by decide
theorem cert_e605606325562 : check e605606325562 [[],[]] .chain = true := by decide
def e605606325634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e605606325634 : Closed e605606325634 ∧ code e605606325634 = 2804629581186 := by decide
theorem cert_e605606325634 : check e605606325634 [[],[]] .chain = true := by decide
def e605606325646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e605606325646 : Closed e605606325646 ∧ code e605606325646 = 2804629581198 := by decide
theorem cert_e605606325646 : check e605606325646 [[],[]] .chain = true := by decide
def e605606325658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605606325658 : Closed e605606325658 ∧ code e605606325658 = 2804629581210 := by decide
theorem cert_e605606325658 : check e605606325658 [[],[]] .chain = true := by decide
def e605606325770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605606325770 : Closed e605606325770 ∧ code e605606325770 = 2804629581322 := by decide
theorem cert_e605606325770 : check e605606325770 [[],[]] .chain = true := by decide
def e605606325806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605606325806 : Closed e605606325806 ∧ code e605606325806 = 2804629581358 := by decide
theorem cert_e605606325806 : check e605606325806 [[],[],[.under,.under]] .three = true := by decide
def e605606325814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605606325814 : Closed e605606325814 ∧ code e605606325814 = 2804629581366 := by decide
theorem cert_e605606325814 : check e605606325814 [[],[]] .chain = true := by decide
def e605606325818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605606325818 : Closed e605606325818 ∧ code e605606325818 = 2804629581370 := by decide
theorem cert_e605606325818 : check e605606325818 [[],[]] .chain = true := by decide
def e605606325866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605606325866 : Closed e605606325866 ∧ code e605606325866 = 2804629581418 := by decide
theorem cert_e605606325866 : check e605606325866 [[],[]] .chain = true := by decide
def e605606325890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e605606325890 : Closed e605606325890 ∧ code e605606325890 = 2804629581442 := by decide
theorem cert_e605606325890 : check e605606325890 [[],[]] .chain = true := by decide
def e605606325902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605606325902 : Closed e605606325902 ∧ code e605606325902 = 2804629581454 := by decide
theorem cert_e605606325902 : check e605606325902 [[],[]] .chain = true := by decide
def e605606325914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605606325914 : Closed e605606325914 ∧ code e605606325914 = 2804629581466 := by decide
theorem cert_e605606325914 : check e605606325914 [[],[]] .chain = true := by decide
def e605606325958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605606325958 : Closed e605606325958 ∧ code e605606325958 = 2804629581510 := by decide
theorem cert_e605606325958 : check e605606325958 [[],[]] .chain = true := by decide
def e605606325986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605606325986 : Closed e605606325986 ∧ code e605606325986 = 2804629581538 := by decide
theorem cert_e605606325986 : check e605606325986 [[],[],[.under,.under]] .three = true := by decide
def e605606325998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e605606325998 : Closed e605606325998 ∧ code e605606325998 = 2804629581550 := by decide
theorem cert_e605606325998 : check e605606325998 [[],[],[.under,.under]] .three = true := by decide
def e605606326038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e605606326038 : Closed e605606326038 ∧ code e605606326038 = 2804629581590 := by decide
theorem cert_e605606326038 : check e605606326038 [[],[],[.under,.under]] .three = true := by decide
def e605606326114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e605606326114 : Closed e605606326114 ∧ code e605606326114 = 2804629581666 := by decide
theorem cert_e605606326114 : check e605606326114 [[],[],[.under,.under]] .three = true := by decide
def e605606326126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e605606326126 : Closed e605606326126 ∧ code e605606326126 = 2804629581678 := by decide
theorem cert_e605606326126 : check e605606326126 [[],[],[.under,.under]] .three = true := by decide
def e605606326134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e605606326134 : Closed e605606326134 ∧ code e605606326134 = 2804629581686 := by decide
theorem cert_e605606326134 : check e605606326134 [[],[],[.under,.under]] .three = true := by decide
def e605606326510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605606326510 : Closed e605606326510 ∧ code e605606326510 = 2804629582062 := by decide
theorem cert_e605606326510 : check e605606326510 [[],[]] .chain = true := by decide
def e605606326518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605606326518 : Closed e605606326518 ∧ code e605606326518 = 2804629582070 := by decide
theorem cert_e605606326518 : check e605606326518 [[],[]] .chain = true := by decide
def e605606326998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605606326998 : Closed e605606326998 ∧ code e605606326998 = 2804629582550 := by decide
theorem cert_e605606326998 : check e605606326998 [[],[]] .chain = true := by decide
def e605606327002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605606327002 : Closed e605606327002 ∧ code e605606327002 = 2804629582554 := by decide
theorem cert_e605606327002 : check e605606327002 [[],[]] .chain = true := by decide
def e605606327018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605606327018 : Closed e605606327018 ∧ code e605606327018 = 2804629582570 := by decide
theorem cert_e605606327018 : check e605606327018 [[],[]] .chain = true := by decide
def e605606327094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605606327094 : Closed e605606327094 ∧ code e605606327094 = 2804629582646 := by decide
theorem cert_e605606327094 : check e605606327094 [[],[]] .chain = true := by decide
def e605606327098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605606327098 : Closed e605606327098 ∧ code e605606327098 = 2804629582650 := by decide
theorem cert_e605606327098 : check e605606327098 [[],[]] .chain = true := by decide
def e605606327170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e605606327170 : Closed e605606327170 ∧ code e605606327170 = 2804629582722 := by decide
theorem cert_e605606327170 : check e605606327170 [[],[]] .chain = true := by decide
def e605606327182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e605606327182 : Closed e605606327182 ∧ code e605606327182 = 2804629582734 := by decide
theorem cert_e605606327182 : check e605606327182 [[],[]] .chain = true := by decide
def e605606327194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605606327194 : Closed e605606327194 ∧ code e605606327194 = 2804629582746 := by decide
theorem cert_e605606327194 : check e605606327194 [[],[]] .chain = true := by decide
def e605606328346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e605606328346 : Closed e605606328346 ∧ code e605606328346 = 2804629583898 := by decide
theorem cert_e605606328346 : check e605606328346 [[],[],[.under,.under]] .three = true := by decide
def e605606328382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e605606328382 : Closed e605606328382 ∧ code e605606328382 = 2804629583934 := by decide
theorem cert_e605606328382 : check e605606328382 [[],[],[.under,.under]] .three = true := by decide
def e605606328430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e605606328430 : Closed e605606328430 ∧ code e605606328430 = 2804629583982 := by decide
theorem cert_e605606328430 : check e605606328430 [[],[]] .chain = true := by decide
def e605606328438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605606328438 : Closed e605606328438 ∧ code e605606328438 = 2804629583990 := by decide
theorem cert_e605606328438 : check e605606328438 [[],[]] .chain = true := by decide
def e605606328442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e605606328442 : Closed e605606328442 ∧ code e605606328442 = 2804629583994 := by decide
theorem cert_e605606328442 : check e605606328442 [[],[]] .chain = true := by decide
def e605606328682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605606328682 : Closed e605606328682 ∧ code e605606328682 = 2804629584234 := by decide
theorem cert_e605606328682 : check e605606328682 [[],[]] .chain = true := by decide
def e605606328706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e605606328706 : Closed e605606328706 ∧ code e605606328706 = 2804629584258 := by decide
theorem cert_e605606328706 : check e605606328706 [[],[]] .chain = true := by decide
def e605606328718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605606328718 : Closed e605606328718 ∧ code e605606328718 = 2804629584270 := by decide
theorem cert_e605606328718 : check e605606328718 [[],[]] .chain = true := by decide
def e605606328730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605606328730 : Closed e605606328730 ∧ code e605606328730 = 2804629584282 := by decide
theorem cert_e605606328730 : check e605606328730 [[],[]] .chain = true := by decide
def e605606328774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605606328774 : Closed e605606328774 ∧ code e605606328774 = 2804629584326 := by decide
theorem cert_e605606328774 : check e605606328774 [[],[]] .chain = true := by decide
def e605606328802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605606328802 : Closed e605606328802 ∧ code e605606328802 = 2804629584354 := by decide
theorem cert_e605606328802 : check e605606328802 [[],[],[.under,.under]] .three = true := by decide
def e605606328814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e605606328814 : Closed e605606328814 ∧ code e605606328814 = 2804629584366 := by decide
theorem cert_e605606328814 : check e605606328814 [[],[],[.under,.under]] .three = true := by decide
def e605606329374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e605606329374 : Closed e605606329374 ∧ code e605606329374 = 2804629584926 := by decide
theorem cert_e605606329374 : check e605606329374 [[],[],[.under,.under]] .three = true := by decide
def e605606329570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e605606329570 : Closed e605606329570 ∧ code e605606329570 = 2804629585122 := by decide
theorem cert_e605606329570 : check e605606329570 [[],[],[.under,.under]] .three = true := by decide
def e605606329582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e605606329582 : Closed e605606329582 ∧ code e605606329582 = 2804629585134 := by decide
theorem cert_e605606329582 : check e605606329582 [[],[],[.under,.under]] .three = true := by decide
def e605606329590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e605606329590 : Closed e605606329590 ∧ code e605606329590 = 2804629585142 := by decide
theorem cert_e605606329590 : check e605606329590 [[],[],[.under,.under]] .three = true := by decide
def e605606347246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e605606347246 : Closed e605606347246 ∧ code e605606347246 = 2804629602798 := by decide
theorem cert_e605606347246 : check e605606347246 [[],[]] .chain = true := by decide
def e605606348214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605606348214 : Closed e605606348214 ∧ code e605606348214 = 2804629603766 := by decide
theorem cert_e605606348214 : check e605606348214 [[],[]] .chain = true := by decide
def e605606348246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605606348246 : Closed e605606348246 ∧ code e605606348246 = 2804629603798 := by decide
theorem cert_e605606348246 : check e605606348246 [[],[]] .chain = true := by decide
def e605606348250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605606348250 : Closed e605606348250 ∧ code e605606348250 = 2804629603802 := by decide
theorem cert_e605606348250 : check e605606348250 [[],[]] .chain = true := by decide
def e605606348406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605606348406 : Closed e605606348406 ∧ code e605606348406 = 2804629603958 := by decide
theorem cert_e605606348406 : check e605606348406 [[],[]] .chain = true := by decide
def e605606348574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605606348574 : Closed e605606348574 ∧ code e605606348574 = 2804629604126 := by decide
theorem cert_e605606348574 : check e605606348574 [[],[]] .chain = true := by decide
def e605606348598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605606348598 : Closed e605606348598 ∧ code e605606348598 = 2804629604150 := by decide
theorem cert_e605606348598 : check e605606348598 [[],[]] .chain = true := by decide
def e605606348602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605606348602 : Closed e605606348602 ∧ code e605606348602 = 2804629604154 := by decide
theorem cert_e605606348602 : check e605606348602 [[],[]] .chain = true := by decide
def e605606348686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605606348686 : Closed e605606348686 ∧ code e605606348686 = 2804629604238 := by decide
theorem cert_e605606348686 : check e605606348686 [[],[]] .chain = true := by decide
def e605606352298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605606352298 : Closed e605606352298 ∧ code e605606352298 = 2804629607850 := by decide
theorem cert_e605606352298 : check e605606352298 [[],[]] .chain = true := by decide
def e605606352394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605606352394 : Closed e605606352394 ∧ code e605606352394 = 2804629607946 := by decide
theorem cert_e605606352394 : check e605606352394 [[],[]] .chain = true := by decide
def e605606352430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605606352430 : Closed e605606352430 ∧ code e605606352430 = 2804629607982 := by decide
theorem cert_e605606352430 : check e605606352430 [[],[],[.under,.under]] .three = true := by decide
def e605606352438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605606352438 : Closed e605606352438 ∧ code e605606352438 = 2804629607990 := by decide
theorem cert_e605606352438 : check e605606352438 [[],[]] .chain = true := by decide
def e605606352442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605606352442 : Closed e605606352442 ∧ code e605606352442 = 2804629607994 := by decide
theorem cert_e605606352442 : check e605606352442 [[],[]] .chain = true := by decide
def e605606352490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605606352490 : Closed e605606352490 ∧ code e605606352490 = 2804629608042 := by decide
theorem cert_e605606352490 : check e605606352490 [[],[]] .chain = true := by decide
def e605606352514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e605606352514 : Closed e605606352514 ∧ code e605606352514 = 2804629608066 := by decide
theorem cert_e605606352514 : check e605606352514 [[],[]] .chain = true := by decide
def e605606352526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605606352526 : Closed e605606352526 ∧ code e605606352526 = 2804629608078 := by decide
theorem cert_e605606352526 : check e605606352526 [[],[]] .chain = true := by decide
def e605606352538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605606352538 : Closed e605606352538 ∧ code e605606352538 = 2804629608090 := by decide
theorem cert_e605606352538 : check e605606352538 [[],[]] .chain = true := by decide
def e605606352582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605606352582 : Closed e605606352582 ∧ code e605606352582 = 2804629608134 := by decide
theorem cert_e605606352582 : check e605606352582 [[],[]] .chain = true := by decide
def e605606352610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605606352610 : Closed e605606352610 ∧ code e605606352610 = 2804629608162 := by decide
theorem cert_e605606352610 : check e605606352610 [[],[],[.under,.under]] .three = true := by decide
def e605606352622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e605606352622 : Closed e605606352622 ∧ code e605606352622 = 2804629608174 := by decide
theorem cert_e605606352622 : check e605606352622 [[],[],[.under,.under]] .three = true := by decide
def e605606352666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e605606352666 : Closed e605606352666 ∧ code e605606352666 = 2804629608218 := by decide
theorem cert_e605606352666 : check e605606352666 [[],[]] .chain = true := by decide
def e605606352710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e605606352710 : Closed e605606352710 ∧ code e605606352710 = 2804629608262 := by decide
theorem cert_e605606352710 : check e605606352710 [[],[]] .chain = true := by decide
def e605606352778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605606352778 : Closed e605606352778 ∧ code e605606352778 = 2804629608330 := by decide
theorem cert_e605606352778 : check e605606352778 [[],[],[.under,.under]] .three = true := by decide
def e605606352802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605606352802 : Closed e605606352802 ∧ code e605606352802 = 2804629608354 := by decide
theorem cert_e605606352802 : check e605606352802 [[],[],[.under,.under]] .three = true := by decide
def e605606352814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e605606352814 : Closed e605606352814 ∧ code e605606352814 = 2804629608366 := by decide
theorem cert_e605606352814 : check e605606352814 [[],[],[.under,.under]] .three = true := by decide
def e605606352826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e605606352826 : Closed e605606352826 ∧ code e605606352826 = 2804629608378 := by decide
theorem cert_e605606352826 : check e605606352826 [[],[],[.under,.under]] .three = true := by decide
def e605606352922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e605606352922 : Closed e605606352922 ∧ code e605606352922 = 2804629608474 := by decide
theorem cert_e605606352922 : check e605606352922 [[],[],[.under,.under]] .three = true := by decide
def e605606352958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e605606352958 : Closed e605606352958 ∧ code e605606352958 = 2804629608510 := by decide
theorem cert_e605606352958 : check e605606352958 [[],[],[.under,.under]] .three = true := by decide
def e605606353006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e605606353006 : Closed e605606353006 ∧ code e605606353006 = 2804629608558 := by decide
theorem cert_e605606353006 : check e605606353006 [[],[]] .chain = true := by decide
def e605606353014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605606353014 : Closed e605606353014 ∧ code e605606353014 = 2804629608566 := by decide
theorem cert_e605606353014 : check e605606353014 [[],[]] .chain = true := by decide
def e605606353018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e605606353018 : Closed e605606353018 ∧ code e605606353018 = 2804629608570 := by decide
theorem cert_e605606353018 : check e605606353018 [[],[]] .chain = true := by decide
def e605606353258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605606353258 : Closed e605606353258 ∧ code e605606353258 = 2804629608810 := by decide
theorem cert_e605606353258 : check e605606353258 [[],[]] .chain = true := by decide
def e605606353282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e605606353282 : Closed e605606353282 ∧ code e605606353282 = 2804629608834 := by decide
theorem cert_e605606353282 : check e605606353282 [[],[]] .chain = true := by decide
def e605606353294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605606353294 : Closed e605606353294 ∧ code e605606353294 = 2804629608846 := by decide
theorem cert_e605606353294 : check e605606353294 [[],[]] .chain = true := by decide
def e605606353306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605606353306 : Closed e605606353306 ∧ code e605606353306 = 2804629608858 := by decide
theorem cert_e605606353306 : check e605606353306 [[],[]] .chain = true := by decide
def e605606353350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605606353350 : Closed e605606353350 ∧ code e605606353350 = 2804629608902 := by decide
theorem cert_e605606353350 : check e605606353350 [[],[]] .chain = true := by decide
def e605606353378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605606353378 : Closed e605606353378 ∧ code e605606353378 = 2804629608930 := by decide
theorem cert_e605606353378 : check e605606353378 [[],[],[.under,.under]] .three = true := by decide
def e605606353390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e605606353390 : Closed e605606353390 ∧ code e605606353390 = 2804629608942 := by decide
theorem cert_e605606353390 : check e605606353390 [[],[],[.under,.under]] .three = true := by decide
def e605606353974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e605606353974 : Closed e605606353974 ∧ code e605606353974 = 2804629609526 := by decide
theorem cert_e605606353974 : check e605606353974 [[],[]] .chain = true := by decide
def e605606353978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e605606353978 : Closed e605606353978 ∧ code e605606353978 = 2804629609530 := by decide
theorem cert_e605606353978 : check e605606353978 [[],[]] .chain = true := by decide
def e605606354118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e605606354118 : Closed e605606354118 ∧ code e605606354118 = 2804629609670 := by decide
theorem cert_e605606354118 : check e605606354118 [[],[]] .chain = true := by decide
def e605606354446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e605606354446 : Closed e605606354446 ∧ code e605606354446 = 2804629609998 := by decide
theorem cert_e605606354446 : check e605606354446 [[],[],[.under,.under]] .three = true := by decide
def e605606354530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605606354530 : Closed e605606354530 ∧ code e605606354530 = 2804629610082 := by decide
theorem cert_e605606354530 : check e605606354530 [[],[],[.under,.under]] .three = true := by decide
def e605606354542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e605606354542 : Closed e605606354542 ∧ code e605606354542 = 2804629610094 := by decide
theorem cert_e605606354542 : check e605606354542 [[],[],[.under,.under]] .three = true := by decide
def e605606354554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e605606354554 : Closed e605606354554 ∧ code e605606354554 = 2804629610106 := by decide
theorem cert_e605606354554 : check e605606354554 [[],[],[.under,.under]] .three = true := by decide
def e605606365974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e605606365974 : Closed e605606365974 ∧ code e605606365974 = 2804629621526 := by decide
theorem cert_e605606365974 : check e605606365974 [[],[],[.under,.under]] .three = true := by decide
def e605606366050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e605606366050 : Closed e605606366050 ∧ code e605606366050 = 2804629621602 := by decide
theorem cert_e605606366050 : check e605606366050 [[],[],[.under,.under]] .three = true := by decide
def e605606366062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605606366062 : Closed e605606366062 ∧ code e605606366062 = 2804629621614 := by decide
theorem cert_e605606366062 : check e605606366062 [[],[],[.under,.under]] .three = true := by decide
def e605606366070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605606366070 : Closed e605606366070 ∧ code e605606366070 = 2804629621622 := by decide
theorem cert_e605606366070 : check e605606366070 [[],[],[.under,.under]] .three = true := by decide
def e605606366090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605606366090 : Closed e605606366090 ∧ code e605606366090 = 2804629621642 := by decide
theorem cert_e605606366090 : check e605606366090 [[],[],[.under,.under]] .three = true := by decide
def e605606366114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605606366114 : Closed e605606366114 ∧ code e605606366114 = 2804629621666 := by decide
theorem cert_e605606366114 : check e605606366114 [[],[],[.under,.under]] .three = true := by decide
def e605606366126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605606366126 : Closed e605606366126 ∧ code e605606366126 = 2804629621678 := by decide
theorem cert_e605606366126 : check e605606366126 [[],[],[.under,.under]] .three = true := by decide
def e605606366138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605606366138 : Closed e605606366138 ∧ code e605606366138 = 2804629621690 := by decide
theorem cert_e605606366138 : check e605606366138 [[],[],[.under,.under]] .three = true := by decide
def e605606366166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605606366166 : Closed e605606366166 ∧ code e605606366166 = 2804629621718 := by decide
theorem cert_e605606366166 : check e605606366166 [[],[],[.under,.under]] .three = true := by decide
def e605606366170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605606366170 : Closed e605606366170 ∧ code e605606366170 = 2804629621722 := by decide
theorem cert_e605606366170 : check e605606366170 [[],[],[.under,.under]] .three = true := by decide
def e605606366238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e605606366238 : Closed e605606366238 ∧ code e605606366238 = 2804629621790 := by decide
theorem cert_e605606366238 : check e605606366238 [[],[],[.under,.under]] .three = true := by decide
def e605606366434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e605606366434 : Closed e605606366434 ∧ code e605606366434 = 2804629621986 := by decide
theorem cert_e605606366434 : check e605606366434 [[],[],[.under,.under]] .three = true := by decide
def e605606366446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605606366446 : Closed e605606366446 ∧ code e605606366446 = 2804629621998 := by decide
theorem cert_e605606366446 : check e605606366446 [[],[],[.under,.under]] .three = true := by decide
def e605606366454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605606366454 : Closed e605606366454 ∧ code e605606366454 = 2804629622006 := by decide
theorem cert_e605606366454 : check e605606366454 [[],[],[.under,.under]] .three = true := by decide
def e605606366734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e605606366734 : Closed e605606366734 ∧ code e605606366734 = 2804629622286 := by decide
theorem cert_e605606366734 : check e605606366734 [[],[],[.under,.under]] .three = true := by decide
def e605606366818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605606366818 : Closed e605606366818 ∧ code e605606366818 = 2804629622370 := by decide
theorem cert_e605606366818 : check e605606366818 [[],[],[.under,.under]] .three = true := by decide
def e605606366830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605606366830 : Closed e605606366830 ∧ code e605606366830 = 2804629622382 := by decide
theorem cert_e605606366830 : check e605606366830 [[],[],[.under,.under]] .three = true := by decide
def e605606366842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605606366842 : Closed e605606366842 ∧ code e605606366842 = 2804629622394 := by decide
theorem cert_e605606366842 : check e605606366842 [[],[],[.under,.under]] .three = true := by decide
def e605606367030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605606367030 : Closed e605606367030 ∧ code e605606367030 = 2804629622582 := by decide
theorem cert_e605606367030 : check e605606367030 [[],[],[.under,.under]] .three = true := by decide
def e605606367034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605606367034 : Closed e605606367034 ∧ code e605606367034 = 2804629622586 := by decide
theorem cert_e605606367034 : check e605606367034 [[],[],[.under,.under]] .three = true := by decide
def e605627353966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605627353966 : Closed e605627353966 ∧ code e605627353966 = 2804650609518 := by decide
theorem cert_e605627353966 : check e605627353966 [[],[]] .smaller = true := by decide
def e605627353974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605627353974 : Closed e605627353974 ∧ code e605627353974 = 2804650609526 := by decide
theorem cert_e605627353974 : check e605627353974 [[],[]] .smaller = true := by decide
def e605627354030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605627354030 : Closed e605627354030 ∧ code e605627354030 = 2804650609582 := by decide
theorem cert_e605627354030 : check e605627354030 [[],[]] .smaller = true := by decide
def e605627354042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605627354042 : Closed e605627354042 ∧ code e605627354042 = 2804650609594 := by decide
theorem cert_e605627354042 : check e605627354042 [[],[]] .smaller = true := by decide
def e605627354070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605627354070 : Closed e605627354070 ∧ code e605627354070 = 2804650609622 := by decide
theorem cert_e605627354070 : check e605627354070 [[],[]] .smaller = true := by decide
def e605627354074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605627354074 : Closed e605627354074 ∧ code e605627354074 = 2804650609626 := by decide
theorem cert_e605627354074 : check e605627354074 [[],[]] .smaller = true := by decide
def e605627354350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605627354350 : Closed e605627354350 ∧ code e605627354350 = 2804650609902 := by decide
theorem cert_e605627354350 : check e605627354350 [[],[]] .smaller = true := by decide
def e605627354358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605627354358 : Closed e605627354358 ∧ code e605627354358 = 2804650609910 := by decide
theorem cert_e605627354358 : check e605627354358 [[],[]] .smaller = true := by decide
end Blc.Floor41
