import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e565274783406 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e565274783406 : Closed e565274783406 ∧ code e565274783406 = 2764298038958 := by decide
theorem cert_e565274783406 : check e565274783406 [[],[.under]] .three = true := by decide
def e565274783418 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e565274783418 : Closed e565274783418 ∧ code e565274783418 = 2764298038970 := by decide
theorem cert_e565274783418 : check e565274783418 [[],[.under]] .three = true := by decide
def e565274783466 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e565274783466 : Closed e565274783466 ∧ code e565274783466 = 2764298039018 := by decide
theorem cert_e565274783466 : check e565274783466 [[],[.under]] .three = true := by decide
def e565274783574 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e565274783574 : Closed e565274783574 ∧ code e565274783574 = 2764298039126 := by decide
theorem cert_e565274783574 : check e565274783574 [[],[.under]] .three = true := by decide
def e565274783578 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e565274783578 : Closed e565274783578 ∧ code e565274783578 = 2764298039130 := by decide
theorem cert_e565274783578 : check e565274783578 [[],[.under]] .three = true := by decide
def e565274783594 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e565274783594 : Closed e565274783594 ∧ code e565274783594 = 2764298039146 := by decide
theorem cert_e565274783594 : check e565274783594 [[],[.under]] .three = true := by decide
def e565274784622 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e565274784622 : Closed e565274784622 ∧ code e565274784622 = 2764298040174 := by decide
theorem cert_e565274784622 : check e565274784622 [[],[.under]] .three = true := by decide
def e565274784630 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e565274784630 : Closed e565274784630 ∧ code e565274784630 = 2764298040182 := by decide
theorem cert_e565274784630 : check e565274784630 [[],[.under]] .three = true := by decide
def e565274784686 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e565274784686 : Closed e565274784686 ∧ code e565274784686 = 2764298040238 := by decide
theorem cert_e565274784686 : check e565274784686 [[],[.under]] .three = true := by decide
def e565274784698 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e565274784698 : Closed e565274784698 ∧ code e565274784698 = 2764298040250 := by decide
theorem cert_e565274784698 : check e565274784698 [[],[.under]] .three = true := by decide
def e565274784726 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e565274784726 : Closed e565274784726 ∧ code e565274784726 = 2764298040278 := by decide
theorem cert_e565274784726 : check e565274784726 [[],[.under]] .three = true := by decide
def e565274784730 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e565274784730 : Closed e565274784730 ∧ code e565274784730 = 2764298040282 := by decide
theorem cert_e565274784730 : check e565274784730 [[],[.under]] .three = true := by decide
def e565274785006 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e565274785006 : Closed e565274785006 ∧ code e565274785006 = 2764298040558 := by decide
theorem cert_e565274785006 : check e565274785006 [[],[.under]] .three = true := by decide
def e565274785014 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e565274785014 : Closed e565274785014 ∧ code e565274785014 = 2764298040566 := by decide
theorem cert_e565274785014 : check e565274785014 [[],[.under]] .three = true := by decide
def e565274785390 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e565274785390 : Closed e565274785390 ∧ code e565274785390 = 2764298040942 := by decide
theorem cert_e565274785390 : check e565274785390 [[],[.under]] .three = true := by decide
def e565274785402 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e565274785402 : Closed e565274785402 ∧ code e565274785402 = 2764298040954 := by decide
theorem cert_e565274785402 : check e565274785402 [[],[.under]] .three = true := by decide
def e565274785590 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e565274785590 : Closed e565274785590 ∧ code e565274785590 = 2764298041142 := by decide
theorem cert_e565274785590 : check e565274785590 [[],[.under]] .three = true := by decide
def e565274785594 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e565274785594 : Closed e565274785594 ∧ code e565274785594 = 2764298041146 := by decide
theorem cert_e565274785594 : check e565274785594 [[],[.under]] .three = true := by decide
def e565274786222 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e565274786222 : Closed e565274786222 ∧ code e565274786222 = 2764298041774 := by decide
theorem cert_e565274786222 : check e565274786222 [[],[.under]] .three = true := by decide
def e565274786234 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e565274786234 : Closed e565274786234 ∧ code e565274786234 = 2764298041786 := by decide
theorem cert_e565274786234 : check e565274786234 [[],[.under]] .three = true := by decide
def e565274786282 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e565274786282 : Closed e565274786282 ∧ code e565274786282 = 2764298041834 := by decide
theorem cert_e565274786282 : check e565274786282 [[],[.under]] .three = true := by decide
def e565274786414 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e565274786414 : Closed e565274786414 ∧ code e565274786414 = 2764298041966 := by decide
theorem cert_e565274786414 : check e565274786414 [[],[.under]] .three = true := by decide
def e565274786426 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e565274786426 : Closed e565274786426 ∧ code e565274786426 = 2764298041978 := by decide
theorem cert_e565274786426 : check e565274786426 [[],[.under]] .three = true := by decide
def e565274786714 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e565274786714 : Closed e565274786714 ∧ code e565274786714 = 2764298042266 := by decide
theorem cert_e565274786714 : check e565274786714 [[],[.under]] .three = true := by decide
def e565274787030 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e565274787030 : Closed e565274787030 ∧ code e565274787030 = 2764298042582 := by decide
theorem cert_e565274787030 : check e565274787030 [[],[.under]] .three = true := by decide
def e565274787034 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e565274787034 : Closed e565274787034 ∧ code e565274787034 = 2764298042586 := by decide
theorem cert_e565274787034 : check e565274787034 [[],[.under]] .three = true := by decide
def e565274787050 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e565274787050 : Closed e565274787050 ∧ code e565274787050 = 2764298042602 := by decide
theorem cert_e565274787050 : check e565274787050 [[],[.under]] .three = true := by decide
def e565274787126 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e565274787126 : Closed e565274787126 ∧ code e565274787126 = 2764298042678 := by decide
theorem cert_e565274787126 : check e565274787126 [[],[.under]] .three = true := by decide
def e565274787130 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e565274787130 : Closed e565274787130 ∧ code e565274787130 = 2764298042682 := by decide
theorem cert_e565274787130 : check e565274787130 [[],[.under]] .three = true := by decide
def e565274787226 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e565274787226 : Closed e565274787226 ∧ code e565274787226 = 2764298042778 := by decide
theorem cert_e565274787226 : check e565274787226 [[],[.under]] .three = true := by decide
def e565274790766 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e565274790766 : Closed e565274790766 ∧ code e565274790766 = 2764298046318 := by decide
theorem cert_e565274790766 : check e565274790766 [[],[.under]] .three = true := by decide
def e565274790774 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e565274790774 : Closed e565274790774 ∧ code e565274790774 = 2764298046326 := by decide
theorem cert_e565274790774 : check e565274790774 [[],[.under]] .three = true := by decide
def e565274790830 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e565274790830 : Closed e565274790830 ∧ code e565274790830 = 2764298046382 := by decide
theorem cert_e565274790830 : check e565274790830 [[],[.under]] .three = true := by decide
def e565274790842 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e565274790842 : Closed e565274790842 ∧ code e565274790842 = 2764298046394 := by decide
theorem cert_e565274790842 : check e565274790842 [[],[.under]] .three = true := by decide
def e565274790870 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e565274790870 : Closed e565274790870 ∧ code e565274790870 = 2764298046422 := by decide
theorem cert_e565274790870 : check e565274790870 [[],[.under]] .three = true := by decide
def e565274790874 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e565274790874 : Closed e565274790874 ∧ code e565274790874 = 2764298046426 := by decide
theorem cert_e565274790874 : check e565274790874 [[],[.under]] .three = true := by decide
def e565274791150 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e565274791150 : Closed e565274791150 ∧ code e565274791150 = 2764298046702 := by decide
theorem cert_e565274791150 : check e565274791150 [[],[.under]] .three = true := by decide
def e565274791158 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e565274791158 : Closed e565274791158 ∧ code e565274791158 = 2764298046710 := by decide
theorem cert_e565274791158 : check e565274791158 [[],[.under]] .three = true := by decide
def e565274791534 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e565274791534 : Closed e565274791534 ∧ code e565274791534 = 2764298047086 := by decide
theorem cert_e565274791534 : check e565274791534 [[],[.under]] .three = true := by decide
def e565274791546 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e565274791546 : Closed e565274791546 ∧ code e565274791546 = 2764298047098 := by decide
theorem cert_e565274791546 : check e565274791546 [[],[.under]] .three = true := by decide
def e565274791734 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e565274791734 : Closed e565274791734 ∧ code e565274791734 = 2764298047286 := by decide
theorem cert_e565274791734 : check e565274791734 [[],[.under]] .three = true := by decide
def e565274791738 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e565274791738 : Closed e565274791738 ∧ code e565274791738 = 2764298047290 := by decide
theorem cert_e565274791738 : check e565274791738 [[],[.under]] .three = true := by decide
def e565274797486 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e565274797486 : Closed e565274797486 ∧ code e565274797486 = 2764298053038 := by decide
theorem cert_e565274797486 : check e565274797486 [[],[.under]] .three = true := by decide
def e565274797498 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e565274797498 : Closed e565274797498 ∧ code e565274797498 = 2764298053050 := by decide
theorem cert_e565274797498 : check e565274797498 [[],[.under]] .three = true := by decide
def e565274797546 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e565274797546 : Closed e565274797546 ∧ code e565274797546 = 2764298053098 := by decide
theorem cert_e565274797546 : check e565274797546 [[],[.under]] .three = true := by decide
def e565274797678 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e565274797678 : Closed e565274797678 ∧ code e565274797678 = 2764298053230 := by decide
theorem cert_e565274797678 : check e565274797678 [[],[.under]] .three = true := by decide
def e565274797690 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e565274797690 : Closed e565274797690 ∧ code e565274797690 = 2764298053242 := by decide
theorem cert_e565274797690 : check e565274797690 [[],[.under]] .three = true := by decide
def e565274797978 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e565274797978 : Closed e565274797978 ∧ code e565274797978 = 2764298053530 := by decide
theorem cert_e565274797978 : check e565274797978 [[],[.under]] .three = true := by decide
def e565274800854 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e565274800854 : Closed e565274800854 ∧ code e565274800854 = 2764298056406 := by decide
theorem cert_e565274800854 : check e565274800854 [[],[.under]] .three = true := by decide
def e565274800858 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e565274800858 : Closed e565274800858 ∧ code e565274800858 = 2764298056410 := by decide
theorem cert_e565274800858 : check e565274800858 [[],[.under]] .three = true := by decide
def e565274800874 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e565274800874 : Closed e565274800874 ∧ code e565274800874 = 2764298056426 := by decide
theorem cert_e565274800874 : check e565274800874 [[],[.under]] .three = true := by decide
def e565274800950 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e565274800950 : Closed e565274800950 ∧ code e565274800950 = 2764298056502 := by decide
theorem cert_e565274800950 : check e565274800950 [[],[.under]] .three = true := by decide
def e565274800954 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e565274800954 : Closed e565274800954 ∧ code e565274800954 = 2764298056506 := by decide
theorem cert_e565274800954 : check e565274800954 [[],[.under]] .three = true := by decide
def e565274801050 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e565274801050 : Closed e565274801050 ∧ code e565274801050 = 2764298056602 := by decide
theorem cert_e565274801050 : check e565274801050 [[],[.under]] .three = true := by decide
def e565274938222 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e565274938222 : Closed e565274938222 ∧ code e565274938222 = 2764298193774 := by decide
theorem cert_e565274938222 : check e565274938222 [[],[.under]] .chain = true := by decide
def e565274938230 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e565274938230 : Closed e565274938230 ∧ code e565274938230 = 2764298193782 := by decide
theorem cert_e565274938230 : check e565274938230 [[],[.under]] .chain = true := by decide
def e565274938286 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e565274938286 : Closed e565274938286 ∧ code e565274938286 = 2764298193838 := by decide
theorem cert_e565274938286 : check e565274938286 [[],[.under]] .chain = true := by decide
def e565274938298 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e565274938298 : Closed e565274938298 ∧ code e565274938298 = 2764298193850 := by decide
theorem cert_e565274938298 : check e565274938298 [[],[.under]] .chain = true := by decide
def e565274938326 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e565274938326 : Closed e565274938326 ∧ code e565274938326 = 2764298193878 := by decide
theorem cert_e565274938326 : check e565274938326 [[],[.under]] .chain = true := by decide
def e565274938330 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e565274938330 : Closed e565274938330 ∧ code e565274938330 = 2764298193882 := by decide
theorem cert_e565274938330 : check e565274938330 [[],[.under]] .chain = true := by decide
def e565274938606 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e565274938606 : Closed e565274938606 ∧ code e565274938606 = 2764298194158 := by decide
theorem cert_e565274938606 : check e565274938606 [[],[.under]] .chain = true := by decide
def e565274938614 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e565274938614 : Closed e565274938614 ∧ code e565274938614 = 2764298194166 := by decide
theorem cert_e565274938614 : check e565274938614 [[],[.under]] .chain = true := by decide
def e565274938990 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e565274938990 : Closed e565274938990 ∧ code e565274938990 = 2764298194542 := by decide
theorem cert_e565274938990 : check e565274938990 [[],[.under]] .chain = true := by decide
def e565274939002 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e565274939002 : Closed e565274939002 ∧ code e565274939002 = 2764298194554 := by decide
theorem cert_e565274939002 : check e565274939002 [[],[.under]] .chain = true := by decide
def e565274939190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e565274939190 : Closed e565274939190 ∧ code e565274939190 = 2764298194742 := by decide
theorem cert_e565274939190 : check e565274939190 [[],[.under]] .chain = true := by decide
def e565274939194 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e565274939194 : Closed e565274939194 ∧ code e565274939194 = 2764298194746 := by decide
theorem cert_e565274939194 : check e565274939194 [[],[.under]] .chain = true := by decide
def e565275528046 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e565275528046 : Closed e565275528046 ∧ code e565275528046 = 2764298783598 := by decide
theorem cert_e565275528046 : check e565275528046 [[],[.under],[.under,.left]] .chain = true := by decide
def e565275528054 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e565275528054 : Closed e565275528054 ∧ code e565275528054 = 2764298783606 := by decide
theorem cert_e565275528054 : check e565275528054 [[],[.under],[.under,.left]] .chain = true := by decide
def e565275528110 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e565275528110 : Closed e565275528110 ∧ code e565275528110 = 2764298783662 := by decide
theorem cert_e565275528110 : check e565275528110 [[],[.under],[.under,.left]] .chain = true := by decide
def e565275528122 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e565275528122 : Closed e565275528122 ∧ code e565275528122 = 2764298783674 := by decide
theorem cert_e565275528122 : check e565275528122 [[],[.under],[.under,.left]] .chain = true := by decide
def e565275528150 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e565275528150 : Closed e565275528150 ∧ code e565275528150 = 2764298783702 := by decide
theorem cert_e565275528150 : check e565275528150 [[],[.under],[.under,.left]] .chain = true := by decide
def e565275528154 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e565275528154 : Closed e565275528154 ∧ code e565275528154 = 2764298783706 := by decide
theorem cert_e565275528154 : check e565275528154 [[],[.under],[.under,.left]] .chain = true := by decide
def e565275528430 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e565275528430 : Closed e565275528430 ∧ code e565275528430 = 2764298783982 := by decide
theorem cert_e565275528430 : check e565275528430 [[],[.under],[.under,.left]] .chain = true := by decide
def e565275528438 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e565275528438 : Closed e565275528438 ∧ code e565275528438 = 2764298783990 := by decide
theorem cert_e565275528438 : check e565275528438 [[],[.under],[.under,.left]] .chain = true := by decide
def e565275528814 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e565275528814 : Closed e565275528814 ∧ code e565275528814 = 2764298784366 := by decide
theorem cert_e565275528814 : check e565275528814 [[],[.under],[.under,.left]] .chain = true := by decide
def e565275528826 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e565275528826 : Closed e565275528826 ∧ code e565275528826 = 2764298784378 := by decide
theorem cert_e565275528826 : check e565275528826 [[],[.under],[.under,.left]] .chain = true := by decide
def e565275529014 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e565275529014 : Closed e565275529014 ∧ code e565275529014 = 2764298784566 := by decide
theorem cert_e565275529014 : check e565275529014 [[],[.under],[.under,.left]] .chain = true := by decide
def e565275529018 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e565275529018 : Closed e565275529018 ∧ code e565275529018 = 2764298784570 := by decide
theorem cert_e565275529018 : check e565275529018 [[],[.under],[.under,.left]] .chain = true := by decide
def e565593550190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e565593550190 : Closed e565593550190 ∧ code e565593550190 = 2764616805742 := by decide
theorem cert_e565593550190 : check e565593550190 [[],[.under]] .smaller = true := by decide
def e565593550198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e565593550198 : Closed e565593550198 ∧ code e565593550198 = 2764616805750 := by decide
theorem cert_e565593550198 : check e565593550198 [[],[.under]] .smaller = true := by decide
def e565593550254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e565593550254 : Closed e565593550254 ∧ code e565593550254 = 2764616805806 := by decide
theorem cert_e565593550254 : check e565593550254 [[],[.under]] .smaller = true := by decide
def e565593550266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e565593550266 : Closed e565593550266 ∧ code e565593550266 = 2764616805818 := by decide
theorem cert_e565593550266 : check e565593550266 [[],[.under]] .smaller = true := by decide
def e565593550294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e565593550294 : Closed e565593550294 ∧ code e565593550294 = 2764616805846 := by decide
theorem cert_e565593550294 : check e565593550294 [[],[.under]] .smaller = true := by decide
def e565593550298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e565593550298 : Closed e565593550298 ∧ code e565593550298 = 2764616805850 := by decide
theorem cert_e565593550298 : check e565593550298 [[],[.under]] .smaller = true := by decide
def e565593550510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e565593550510 : Closed e565593550510 ∧ code e565593550510 = 2764616806062 := by decide
theorem cert_e565593550510 : check e565593550510 [[],[.under]] .smaller = true := by decide
def e565593550522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e565593550522 : Closed e565593550522 ∧ code e565593550522 = 2764616806074 := by decide
theorem cert_e565593550522 : check e565593550522 [[],[.under]] .smaller = true := by decide
def e565593550570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e565593550570 : Closed e565593550570 ∧ code e565593550570 = 2764616806122 := by decide
theorem cert_e565593550570 : check e565593550570 [[],[.under]] .smaller = true := by decide
def e565593550678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e565593550678 : Closed e565593550678 ∧ code e565593550678 = 2764616806230 := by decide
theorem cert_e565593550678 : check e565593550678 [[],[.under]] .smaller = true := by decide
def e565593550682 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e565593550682 : Closed e565593550682 ∧ code e565593550682 = 2764616806234 := by decide
theorem cert_e565593550682 : check e565593550682 [[],[.under]] .smaller = true := by decide
def e565593550698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e565593550698 : Closed e565593550698 ∧ code e565593550698 = 2764616806250 := by decide
theorem cert_e565593550698 : check e565593550698 [[],[.under]] .smaller = true := by decide
def e565593551726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e565593551726 : Closed e565593551726 ∧ code e565593551726 = 2764616807278 := by decide
theorem cert_e565593551726 : check e565593551726 [[],[.under]] .smaller = true := by decide
def e565593551734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e565593551734 : Closed e565593551734 ∧ code e565593551734 = 2764616807286 := by decide
theorem cert_e565593551734 : check e565593551734 [[],[.under]] .smaller = true := by decide
def e565593551790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e565593551790 : Closed e565593551790 ∧ code e565593551790 = 2764616807342 := by decide
theorem cert_e565593551790 : check e565593551790 [[],[.under]] .smaller = true := by decide
def e565593551802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e565593551802 : Closed e565593551802 ∧ code e565593551802 = 2764616807354 := by decide
theorem cert_e565593551802 : check e565593551802 [[],[.under]] .smaller = true := by decide
def e565593551830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e565593551830 : Closed e565593551830 ∧ code e565593551830 = 2764616807382 := by decide
theorem cert_e565593551830 : check e565593551830 [[],[.under]] .smaller = true := by decide
def e565593551834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e565593551834 : Closed e565593551834 ∧ code e565593551834 = 2764616807386 := by decide
theorem cert_e565593551834 : check e565593551834 [[],[.under]] .smaller = true := by decide
def e565593552110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e565593552110 : Closed e565593552110 ∧ code e565593552110 = 2764616807662 := by decide
theorem cert_e565593552110 : check e565593552110 [[],[.under]] .smaller = true := by decide
def e565593552118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e565593552118 : Closed e565593552118 ∧ code e565593552118 = 2764616807670 := by decide
theorem cert_e565593552118 : check e565593552118 [[],[.under]] .smaller = true := by decide
def e565593552494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e565593552494 : Closed e565593552494 ∧ code e565593552494 = 2764616808046 := by decide
theorem cert_e565593552494 : check e565593552494 [[],[.under]] .smaller = true := by decide
def e565593552506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e565593552506 : Closed e565593552506 ∧ code e565593552506 = 2764616808058 := by decide
theorem cert_e565593552506 : check e565593552506 [[],[.under]] .smaller = true := by decide
def e565593552694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e565593552694 : Closed e565593552694 ∧ code e565593552694 = 2764616808246 := by decide
theorem cert_e565593552694 : check e565593552694 [[],[.under]] .smaller = true := by decide
def e565593552698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e565593552698 : Closed e565593552698 ∧ code e565593552698 = 2764616808250 := by decide
theorem cert_e565593552698 : check e565593552698 [[],[.under]] .smaller = true := by decide
def e565593553326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e565593553326 : Closed e565593553326 ∧ code e565593553326 = 2764616808878 := by decide
theorem cert_e565593553326 : check e565593553326 [[],[.under]] .smaller = true := by decide
def e565593553338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e565593553338 : Closed e565593553338 ∧ code e565593553338 = 2764616808890 := by decide
theorem cert_e565593553338 : check e565593553338 [[],[.under]] .smaller = true := by decide
def e565593553386 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e565593553386 : Closed e565593553386 ∧ code e565593553386 = 2764616808938 := by decide
theorem cert_e565593553386 : check e565593553386 [[],[.under]] .smaller = true := by decide
def e565593553518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e565593553518 : Closed e565593553518 ∧ code e565593553518 = 2764616809070 := by decide
theorem cert_e565593553518 : check e565593553518 [[],[.under]] .smaller = true := by decide
def e565593553530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e565593553530 : Closed e565593553530 ∧ code e565593553530 = 2764616809082 := by decide
theorem cert_e565593553530 : check e565593553530 [[],[.under]] .smaller = true := by decide
def e565593553818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e565593553818 : Closed e565593553818 ∧ code e565593553818 = 2764616809370 := by decide
theorem cert_e565593553818 : check e565593553818 [[],[.under]] .smaller = true := by decide
def e565593554134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e565593554134 : Closed e565593554134 ∧ code e565593554134 = 2764616809686 := by decide
theorem cert_e565593554134 : check e565593554134 [[],[.under]] .smaller = true := by decide
def e565593554138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e565593554138 : Closed e565593554138 ∧ code e565593554138 = 2764616809690 := by decide
theorem cert_e565593554138 : check e565593554138 [[],[.under]] .smaller = true := by decide
def e565593554154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e565593554154 : Closed e565593554154 ∧ code e565593554154 = 2764616809706 := by decide
theorem cert_e565593554154 : check e565593554154 [[],[.under]] .smaller = true := by decide
def e565593554230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e565593554230 : Closed e565593554230 ∧ code e565593554230 = 2764616809782 := by decide
theorem cert_e565593554230 : check e565593554230 [[],[.under]] .smaller = true := by decide
def e565593554234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e565593554234 : Closed e565593554234 ∧ code e565593554234 = 2764616809786 := by decide
theorem cert_e565593554234 : check e565593554234 [[],[.under]] .smaller = true := by decide
def e565593554330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e565593554330 : Closed e565593554330 ∧ code e565593554330 = 2764616809882 := by decide
theorem cert_e565593554330 : check e565593554330 [[],[.under]] .smaller = true := by decide
def e565593557870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e565593557870 : Closed e565593557870 ∧ code e565593557870 = 2764616813422 := by decide
theorem cert_e565593557870 : check e565593557870 [[],[.under]] .smaller = true := by decide
def e565593557878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e565593557878 : Closed e565593557878 ∧ code e565593557878 = 2764616813430 := by decide
theorem cert_e565593557878 : check e565593557878 [[],[.under]] .smaller = true := by decide
def e565593557934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e565593557934 : Closed e565593557934 ∧ code e565593557934 = 2764616813486 := by decide
theorem cert_e565593557934 : check e565593557934 [[],[.under]] .smaller = true := by decide
def e565593557946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e565593557946 : Closed e565593557946 ∧ code e565593557946 = 2764616813498 := by decide
theorem cert_e565593557946 : check e565593557946 [[],[.under]] .smaller = true := by decide
def e565593557974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e565593557974 : Closed e565593557974 ∧ code e565593557974 = 2764616813526 := by decide
theorem cert_e565593557974 : check e565593557974 [[],[.under]] .smaller = true := by decide
def e565593557978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e565593557978 : Closed e565593557978 ∧ code e565593557978 = 2764616813530 := by decide
theorem cert_e565593557978 : check e565593557978 [[],[.under]] .smaller = true := by decide
def e565593558254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e565593558254 : Closed e565593558254 ∧ code e565593558254 = 2764616813806 := by decide
theorem cert_e565593558254 : check e565593558254 [[],[.under]] .smaller = true := by decide
def e565593558262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e565593558262 : Closed e565593558262 ∧ code e565593558262 = 2764616813814 := by decide
theorem cert_e565593558262 : check e565593558262 [[],[.under]] .smaller = true := by decide
def e565593558638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e565593558638 : Closed e565593558638 ∧ code e565593558638 = 2764616814190 := by decide
theorem cert_e565593558638 : check e565593558638 [[],[.under]] .smaller = true := by decide
def e565593558650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e565593558650 : Closed e565593558650 ∧ code e565593558650 = 2764616814202 := by decide
theorem cert_e565593558650 : check e565593558650 [[],[.under]] .smaller = true := by decide
def e565593558838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e565593558838 : Closed e565593558838 ∧ code e565593558838 = 2764616814390 := by decide
theorem cert_e565593558838 : check e565593558838 [[],[.under]] .smaller = true := by decide
def e565593558842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e565593558842 : Closed e565593558842 ∧ code e565593558842 = 2764616814394 := by decide
theorem cert_e565593558842 : check e565593558842 [[],[.under]] .smaller = true := by decide
def e565593564590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e565593564590 : Closed e565593564590 ∧ code e565593564590 = 2764616820142 := by decide
theorem cert_e565593564590 : check e565593564590 [[],[.under]] .smaller = true := by decide
def e565593564602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e565593564602 : Closed e565593564602 ∧ code e565593564602 = 2764616820154 := by decide
theorem cert_e565593564602 : check e565593564602 [[],[.under]] .smaller = true := by decide
def e565593564650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e565593564650 : Closed e565593564650 ∧ code e565593564650 = 2764616820202 := by decide
theorem cert_e565593564650 : check e565593564650 [[],[.under]] .smaller = true := by decide
def e565593564782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e565593564782 : Closed e565593564782 ∧ code e565593564782 = 2764616820334 := by decide
theorem cert_e565593564782 : check e565593564782 [[],[.under]] .smaller = true := by decide
def e565593564794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e565593564794 : Closed e565593564794 ∧ code e565593564794 = 2764616820346 := by decide
theorem cert_e565593564794 : check e565593564794 [[],[.under]] .smaller = true := by decide
def e565593565082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e565593565082 : Closed e565593565082 ∧ code e565593565082 = 2764616820634 := by decide
theorem cert_e565593565082 : check e565593565082 [[],[.under]] .smaller = true := by decide
def e565593567958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e565593567958 : Closed e565593567958 ∧ code e565593567958 = 2764616823510 := by decide
theorem cert_e565593567958 : check e565593567958 [[],[.under]] .smaller = true := by decide
def e565593567962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e565593567962 : Closed e565593567962 ∧ code e565593567962 = 2764616823514 := by decide
theorem cert_e565593567962 : check e565593567962 [[],[.under]] .smaller = true := by decide
def e565593567978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e565593567978 : Closed e565593567978 ∧ code e565593567978 = 2764616823530 := by decide
theorem cert_e565593567978 : check e565593567978 [[],[.under]] .smaller = true := by decide
def e565593568054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e565593568054 : Closed e565593568054 ∧ code e565593568054 = 2764616823606 := by decide
theorem cert_e565593568054 : check e565593568054 [[],[.under]] .smaller = true := by decide
def e565593568058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e565593568058 : Closed e565593568058 ∧ code e565593568058 = 2764616823610 := by decide
theorem cert_e565593568058 : check e565593568058 [[],[.under]] .smaller = true := by decide
def e565593568154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e565593568154 : Closed e565593568154 ∧ code e565593568154 = 2764616823706 := by decide
theorem cert_e565593568154 : check e565593568154 [[],[.under]] .smaller = true := by decide
def e565593683422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e565593683422 : Closed e565593683422 ∧ code e565593683422 = 2764616938974 := by decide
theorem cert_e565593683422 : check e565593683422 [[],[.under]] .three = true := by decide
def e565593683438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e565593683438 : Closed e565593683438 ∧ code e565593683438 = 2764616938990 := by decide
theorem cert_e565593683438 : check e565593683438 [[],[.under]] .three = true := by decide
def e565593683678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e565593683678 : Closed e565593683678 ∧ code e565593683678 = 2764616939230 := by decide
theorem cert_e565593683678 : check e565593683678 [[],[.under]] .three = true := by decide
def e565593683694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e565593683694 : Closed e565593683694 ∧ code e565593683694 = 2764616939246 := by decide
theorem cert_e565593683694 : check e565593683694 [[],[.under]] .smaller = true := by decide
def e565593683702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e565593683702 : Closed e565593683702 ∧ code e565593683702 = 2764616939254 := by decide
theorem cert_e565593683702 : check e565593683702 [[],[.under]] .three = true := by decide
def e565593683806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e565593683806 : Closed e565593683806 ∧ code e565593683806 = 2764616939358 := by decide
theorem cert_e565593683806 : check e565593683806 [[],[.under]] .three = true := by decide
def e565593683822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e565593683822 : Closed e565593683822 ∧ code e565593683822 = 2764616939374 := by decide
theorem cert_e565593683822 : check e565593683822 [[],[.under]] .smaller = true := by decide
def e565593683830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e565593683830 : Closed e565593683830 ∧ code e565593683830 = 2764616939382 := by decide
theorem cert_e565593683830 : check e565593683830 [[],[.under]] .smaller = true := by decide
def e565593683834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e565593683834 : Closed e565593683834 ∧ code e565593683834 = 2764616939386 := by decide
theorem cert_e565593683834 : check e565593683834 [[],[.under]] .three = true := by decide
def e565593683886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e565593683886 : Closed e565593683886 ∧ code e565593683886 = 2764616939438 := by decide
theorem cert_e565593683886 : check e565593683886 [[],[.under]] .three = true := by decide
def e565593683894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e565593683894 : Closed e565593683894 ∧ code e565593683894 = 2764616939446 := by decide
theorem cert_e565593683894 : check e565593683894 [[],[.under]] .three = true := by decide
def e565593683898 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e565593683898 : Closed e565593683898 ∧ code e565593683898 = 2764616939450 := by decide
theorem cert_e565593683898 : check e565593683898 [[],[.under]] .three = true := by decide
def e565593684702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e565593684702 : Closed e565593684702 ∧ code e565593684702 = 2764616940254 := by decide
theorem cert_e565593684702 : check e565593684702 [[],[.under]] .three = true := by decide
def e565593684718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e565593684718 : Closed e565593684718 ∧ code e565593684718 = 2764616940270 := by decide
theorem cert_e565593684718 : check e565593684718 [[],[.under]] .smaller = true := by decide
def e565593684726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e565593684726 : Closed e565593684726 ∧ code e565593684726 = 2764616940278 := by decide
theorem cert_e565593684726 : check e565593684726 [[],[.under]] .three = true := by decide
def e565593684830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e565593684830 : Closed e565593684830 ∧ code e565593684830 = 2764616940382 := by decide
theorem cert_e565593684830 : check e565593684830 [[],[.under]] .three = true := by decide
def e565593684858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e565593684858 : Closed e565593684858 ∧ code e565593684858 = 2764616940410 := by decide
theorem cert_e565593684858 : check e565593684858 [[],[.under]] .three = true := by decide
def e565593684910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e565593684910 : Closed e565593684910 ∧ code e565593684910 = 2764616940462 := by decide
theorem cert_e565593684910 : check e565593684910 [[],[.under]] .smaller = true := by decide
def e565593684922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e565593684922 : Closed e565593684922 ∧ code e565593684922 = 2764616940474 := by decide
theorem cert_e565593684922 : check e565593684922 [[],[.under]] .smaller = true := by decide
def e565593684950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e565593684950 : Closed e565593684950 ∧ code e565593684950 = 2764616940502 := by decide
theorem cert_e565593684950 : check e565593684950 [[],[.under]] .three = true := by decide
def e565593684954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e565593684954 : Closed e565593684954 ∧ code e565593684954 = 2764616940506 := by decide
theorem cert_e565593684954 : check e565593684954 [[],[.under]] .three = true := by decide
def e565593685342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e565593685342 : Closed e565593685342 ∧ code e565593685342 = 2764616940894 := by decide
theorem cert_e565593685342 : check e565593685342 [[],[.under]] .three = true := by decide
end Blc.Floor41
