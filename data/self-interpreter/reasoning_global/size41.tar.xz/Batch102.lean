import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605601880558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e605601880558 : Closed e605601880558 ∧ code e605601880558 = 2804625136110 := by decide
theorem cert_e605601880558 : check e605601880558 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e605601881118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e605601881118 : Closed e605601881118 ∧ code e605601881118 = 2804625136670 := by decide
theorem cert_e605601881118 : check e605601881118 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601881314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e605601881314 : Closed e605601881314 ∧ code e605601881314 = 2804625136866 := by decide
theorem cert_e605601881314 : check e605601881314 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601881326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e605601881326 : Closed e605601881326 ∧ code e605601881326 = 2804625136878 := by decide
theorem cert_e605601881326 : check e605601881326 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601881334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e605601881334 : Closed e605601881334 ∧ code e605601881334 = 2804625136886 := by decide
theorem cert_e605601881334 : check e605601881334 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e605601882218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e605601882218 : Closed e605601882218 ∧ code e605601882218 = 2804625137770 := by decide
theorem cert_e605601882218 : check e605601882218 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e605601882266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601882266 : Closed e605601882266 ∧ code e605601882266 = 2804625137818 := by decide
theorem cert_e605601882266 : check e605601882266 [[],[]] .chain = true := by decide
def e605601882350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e605601882350 : Closed e605601882350 ∧ code e605601882350 = 2804625137902 := by decide
theorem cert_e605601882350 : check e605601882350 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601882362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e605601882362 : Closed e605601882362 ∧ code e605601882362 = 2804625137914 := by decide
theorem cert_e605601882362 : check e605601882362 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601882550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e605601882550 : Closed e605601882550 ∧ code e605601882550 = 2804625138102 := by decide
theorem cert_e605601882550 : check e605601882550 [[],[]] .chain = true := by decide
def e605601882554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e605601882554 : Closed e605601882554 ∧ code e605601882554 = 2804625138106 := by decide
theorem cert_e605601882554 : check e605601882554 [[],[]] .chain = true := by decide
def e605601882582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e605601882582 : Closed e605601882582 ∧ code e605601882582 = 2804625138134 := by decide
theorem cert_e605601882582 : check e605601882582 [[],[]] .chain = true := by decide
def e605601882586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e605601882586 : Closed e605601882586 ∧ code e605601882586 = 2804625138138 := by decide
theorem cert_e605601882586 : check e605601882586 [[],[]] .chain = true := by decide
def e605601882602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e605601882602 : Closed e605601882602 ∧ code e605601882602 = 2804625138154 := by decide
theorem cert_e605601882602 : check e605601882602 [[],[]] .chain = true := by decide
def e605601882734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e605601882734 : Closed e605601882734 ∧ code e605601882734 = 2804625138286 := by decide
theorem cert_e605601882734 : check e605601882734 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601882746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e605601882746 : Closed e605601882746 ∧ code e605601882746 = 2804625138298 := by decide
theorem cert_e605601882746 : check e605601882746 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601882910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e605601882910 : Closed e605601882910 ∧ code e605601882910 = 2804625138462 := by decide
theorem cert_e605601882910 : check e605601882910 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601882934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601882934 : Closed e605601882934 ∧ code e605601882934 = 2804625138486 := by decide
theorem cert_e605601882934 : check e605601882934 [[],[]] .chain = true := by decide
def e605601882938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601882938 : Closed e605601882938 ∧ code e605601882938 = 2804625138490 := by decide
theorem cert_e605601882938 : check e605601882938 [[],[]] .chain = true := by decide
def e605601883034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601883034 : Closed e605601883034 ∧ code e605601883034 = 2804625138586 := by decide
theorem cert_e605601883034 : check e605601883034 [[],[]] .chain = true := by decide
def e605601883078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e605601883078 : Closed e605601883078 ∧ code e605601883078 = 2804625138630 := by decide
theorem cert_e605601883078 : check e605601883078 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601883562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e605601883562 : Closed e605601883562 ∧ code e605601883562 = 2804625139114 := by decide
theorem cert_e605601883562 : check e605601883562 [[],[]] .chain = true := by decide
def e605601883658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e605601883658 : Closed e605601883658 ∧ code e605601883658 = 2804625139210 := by decide
theorem cert_e605601883658 : check e605601883658 [[],[]] .chain = true := by decide
def e605601883694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e605601883694 : Closed e605601883694 ∧ code e605601883694 = 2804625139246 := by decide
theorem cert_e605601883694 : check e605601883694 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601883702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e605601883702 : Closed e605601883702 ∧ code e605601883702 = 2804625139254 := by decide
theorem cert_e605601883702 : check e605601883702 [[],[]] .chain = true := by decide
def e605601883706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e605601883706 : Closed e605601883706 ∧ code e605601883706 = 2804625139258 := by decide
theorem cert_e605601883706 : check e605601883706 [[],[]] .chain = true := by decide
def e605601883754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e605601883754 : Closed e605601883754 ∧ code e605601883754 = 2804625139306 := by decide
theorem cert_e605601883754 : check e605601883754 [[],[]] .chain = true := by decide
def e605601883778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e605601883778 : Closed e605601883778 ∧ code e605601883778 = 2804625139330 := by decide
theorem cert_e605601883778 : check e605601883778 [[],[]] .chain = true := by decide
def e605601883790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e605601883790 : Closed e605601883790 ∧ code e605601883790 = 2804625139342 := by decide
theorem cert_e605601883790 : check e605601883790 [[],[]] .chain = true := by decide
def e605601883802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601883802 : Closed e605601883802 ∧ code e605601883802 = 2804625139354 := by decide
theorem cert_e605601883802 : check e605601883802 [[],[]] .chain = true := by decide
def e605601883846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e605601883846 : Closed e605601883846 ∧ code e605601883846 = 2804625139398 := by decide
theorem cert_e605601883846 : check e605601883846 [[],[]] .chain = true := by decide
def e605601883874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e605601883874 : Closed e605601883874 ∧ code e605601883874 = 2804625139426 := by decide
theorem cert_e605601883874 : check e605601883874 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601883886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e605601883886 : Closed e605601883886 ∧ code e605601883886 = 2804625139438 := by decide
theorem cert_e605601883886 : check e605601883886 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605601883930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e605601883930 : Closed e605601883930 ∧ code e605601883930 = 2804625139482 := by decide
theorem cert_e605601883930 : check e605601883930 [[],[]] .chain = true := by decide
def e605601883974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e605601883974 : Closed e605601883974 ∧ code e605601883974 = 2804625139526 := by decide
theorem cert_e605601883974 : check e605601883974 [[],[]] .chain = true := by decide
def e605601884042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601884042 : Closed e605601884042 ∧ code e605601884042 = 2804625139594 := by decide
theorem cert_e605601884042 : check e605601884042 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601884066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e605601884066 : Closed e605601884066 ∧ code e605601884066 = 2804625139618 := by decide
theorem cert_e605601884066 : check e605601884066 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601884078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e605601884078 : Closed e605601884078 ∧ code e605601884078 = 2804625139630 := by decide
theorem cert_e605601884078 : check e605601884078 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605601884090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e605601884090 : Closed e605601884090 ∧ code e605601884090 = 2804625139642 := by decide
theorem cert_e605601884090 : check e605601884090 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605601884186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605601884186 : Closed e605601884186 ∧ code e605601884186 = 2804625139738 := by decide
theorem cert_e605601884186 : check e605601884186 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e605601884222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e605601884222 : Closed e605601884222 ∧ code e605601884222 = 2804625139774 := by decide
theorem cert_e605601884222 : check e605601884222 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601884270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e605601884270 : Closed e605601884270 ∧ code e605601884270 = 2804625139822 := by decide
theorem cert_e605601884270 : check e605601884270 [[],[]] .chain = true := by decide
def e605601884278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e605601884278 : Closed e605601884278 ∧ code e605601884278 = 2804625139830 := by decide
theorem cert_e605601884278 : check e605601884278 [[],[]] .chain = true := by decide
def e605601884282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e605601884282 : Closed e605601884282 ∧ code e605601884282 = 2804625139834 := by decide
theorem cert_e605601884282 : check e605601884282 [[],[]] .chain = true := by decide
def e605601884522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e605601884522 : Closed e605601884522 ∧ code e605601884522 = 2804625140074 := by decide
theorem cert_e605601884522 : check e605601884522 [[],[]] .chain = true := by decide
def e605601884546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e605601884546 : Closed e605601884546 ∧ code e605601884546 = 2804625140098 := by decide
theorem cert_e605601884546 : check e605601884546 [[],[]] .chain = true := by decide
def e605601884558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e605601884558 : Closed e605601884558 ∧ code e605601884558 = 2804625140110 := by decide
theorem cert_e605601884558 : check e605601884558 [[],[]] .chain = true := by decide
def e605601884570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e605601884570 : Closed e605601884570 ∧ code e605601884570 = 2804625140122 := by decide
theorem cert_e605601884570 : check e605601884570 [[],[]] .chain = true := by decide
def e605601884614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e605601884614 : Closed e605601884614 ∧ code e605601884614 = 2804625140166 := by decide
theorem cert_e605601884614 : check e605601884614 [[],[]] .chain = true := by decide
def e605601884642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e605601884642 : Closed e605601884642 ∧ code e605601884642 = 2804625140194 := by decide
theorem cert_e605601884642 : check e605601884642 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601884654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e605601884654 : Closed e605601884654 ∧ code e605601884654 = 2804625140206 := by decide
theorem cert_e605601884654 : check e605601884654 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605601885238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e605601885238 : Closed e605601885238 ∧ code e605601885238 = 2804625140790 := by decide
theorem cert_e605601885238 : check e605601885238 [[],[]] .chain = true := by decide
def e605601885242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e605601885242 : Closed e605601885242 ∧ code e605601885242 = 2804625140794 := by decide
theorem cert_e605601885242 : check e605601885242 [[],[]] .chain = true := by decide
def e605601885382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e605601885382 : Closed e605601885382 ∧ code e605601885382 = 2804625140934 := by decide
theorem cert_e605601885382 : check e605601885382 [[],[]] .chain = true := by decide
def e605601885710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e605601885710 : Closed e605601885710 ∧ code e605601885710 = 2804625141262 := by decide
theorem cert_e605601885710 : check e605601885710 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601885794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e605601885794 : Closed e605601885794 ∧ code e605601885794 = 2804625141346 := by decide
theorem cert_e605601885794 : check e605601885794 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e605601885806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601885806 : Closed e605601885806 ∧ code e605601885806 = 2804625141358 := by decide
theorem cert_e605601885806 : check e605601885806 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605601885818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601885818 : Closed e605601885818 ∧ code e605601885818 = 2804625141370 := by decide
theorem cert_e605601885818 : check e605601885818 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e605601886326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e605601886326 : Closed e605601886326 ∧ code e605601886326 = 2804625141878 := by decide
private def t_e605601886326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem cert_e605601886326 : ¬ IsSelfInterpreter e605601886326 :=
  wSource (t := t_e605601886326) (replay_sound (ps := []) (t := e605601886326) (by decide)) (by decide)
def e605601886330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e605601886330 : Closed e605601886330 ∧ code e605601886330 = 2804625141882 := by decide
private def t_e605601886330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem cert_e605601886330 : ¬ IsSelfInterpreter e605601886330 :=
  wSource (t := t_e605601886330) (replay_sound (ps := []) (t := e605601886330) (by decide)) (by decide)
def e605601886518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601886518 : Closed e605601886518 ∧ code e605601886518 = 2804625142070 := by decide
private def t_e605601886518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem cert_e605601886518 : ¬ IsSelfInterpreter e605601886518 :=
  wSource (t := t_e605601886518) (replay_sound (ps := []) (t := e605601886518) (by decide)) (by decide)
def e605601886522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601886522 : Closed e605601886522 ∧ code e605601886522 = 2804625142074 := by decide
private def t_e605601886522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem cert_e605601886522 : ¬ IsSelfInterpreter e605601886522 :=
  wSource (t := t_e605601886522) (replay_sound (ps := []) (t := e605601886522) (by decide)) (by decide)
def e605601886606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e605601886606 : Closed e605601886606 ∧ code e605601886606 = 2804625142158 := by decide
private def t_e605601886606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem cert_e605601886606 : ¬ IsSelfInterpreter e605601886606 :=
  wSource (t := t_e605601886606) (replay_sound (ps := []) (t := e605601886606) (by decide)) (by decide)
def e605601886662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e605601886662 : Closed e605601886662 ∧ code e605601886662 = 2804625142214 := by decide
private def t_e605601886662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem cert_e605601886662 : ¬ IsSelfInterpreter e605601886662 :=
  wSource (t := t_e605601886662) (replay_sound (ps := []) (t := e605601886662) (by decide)) (by decide)
def e605601886998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e605601886998 : Closed e605601886998 ∧ code e605601886998 = 2804625142550 := by decide
private def t_e605601886998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem cert_e605601886998 : ¬ IsSelfInterpreter e605601886998 :=
  wSource (t := t_e605601886998) (replay_sound (ps := []) (t := e605601886998) (by decide)) (by decide)
def e605601887074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e605601887074 : Closed e605601887074 ∧ code e605601887074 = 2804625142626 := by decide
private def t_e605601887074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem cert_e605601887074 : ¬ IsSelfInterpreter e605601887074 :=
  wSource (t := t_e605601887074) (replay_sound (ps := []) (t := e605601887074) (by decide)) (by decide)
def e605601887086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e605601887086 : Closed e605601887086 ∧ code e605601887086 = 2804625142638 := by decide
private def t_e605601887086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem cert_e605601887086 : ¬ IsSelfInterpreter e605601887086 :=
  wSource (t := t_e605601887086) (replay_sound (ps := []) (t := e605601887086) (by decide)) (by decide)
def e605601887094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e605601887094 : Closed e605601887094 ∧ code e605601887094 = 2804625142646 := by decide
private def t_e605601887094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem cert_e605601887094 : ¬ IsSelfInterpreter e605601887094 :=
  wSource (t := t_e605601887094) (replay_sound (ps := []) (t := e605601887094) (by decide)) (by decide)
def e605601887114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601887114 : Closed e605601887114 ∧ code e605601887114 = 2804625142666 := by decide
private def t_e605601887114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem cert_e605601887114 : ¬ IsSelfInterpreter e605601887114 :=
  wSource (t := t_e605601887114) (replay_sound (ps := []) (t := e605601887114) (by decide)) (by decide)
def e605601887138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e605601887138 : Closed e605601887138 ∧ code e605601887138 = 2804625142690 := by decide
private def t_e605601887138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem cert_e605601887138 : ¬ IsSelfInterpreter e605601887138 :=
  wSource (t := t_e605601887138) (replay_sound (ps := []) (t := e605601887138) (by decide)) (by decide)
def e605601887150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e605601887150 : Closed e605601887150 ∧ code e605601887150 = 2804625142702 := by decide
private def t_e605601887150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem cert_e605601887150 : ¬ IsSelfInterpreter e605601887150 :=
  wSource (t := t_e605601887150) (replay_sound (ps := []) (t := e605601887150) (by decide)) (by decide)
def e605601887162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e605601887162 : Closed e605601887162 ∧ code e605601887162 = 2804625142714 := by decide
private def t_e605601887162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem cert_e605601887162 : ¬ IsSelfInterpreter e605601887162 :=
  wSource (t := t_e605601887162) (replay_sound (ps := []) (t := e605601887162) (by decide)) (by decide)
def e605601887190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e605601887190 : Closed e605601887190 ∧ code e605601887190 = 2804625142742 := by decide
private def t_e605601887190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem cert_e605601887190 : ¬ IsSelfInterpreter e605601887190 :=
  wSource (t := t_e605601887190) (replay_sound (ps := []) (t := e605601887190) (by decide)) (by decide)
def e605601887194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e605601887194 : Closed e605601887194 ∧ code e605601887194 = 2804625142746 := by decide
private def t_e605601887194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem cert_e605601887194 : ¬ IsSelfInterpreter e605601887194 :=
  wSource (t := t_e605601887194) (replay_sound (ps := []) (t := e605601887194) (by decide)) (by decide)
def e605601887262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e605601887262 : Closed e605601887262 ∧ code e605601887262 = 2804625142814 := by decide
private def t_e605601887262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem cert_e605601887262 : ¬ IsSelfInterpreter e605601887262 :=
  wSource (t := t_e605601887262) (replay_sound (ps := []) (t := e605601887262) (by decide)) (by decide)
def e605601887458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e605601887458 : Closed e605601887458 ∧ code e605601887458 = 2804625143010 := by decide
private def t_e605601887458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem cert_e605601887458 : ¬ IsSelfInterpreter e605601887458 :=
  wSource (t := t_e605601887458) (replay_sound (ps := []) (t := e605601887458) (by decide)) (by decide)
def e605601887470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e605601887470 : Closed e605601887470 ∧ code e605601887470 = 2804625143022 := by decide
private def t_e605601887470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem cert_e605601887470 : ¬ IsSelfInterpreter e605601887470 :=
  wSource (t := t_e605601887470) (replay_sound (ps := []) (t := e605601887470) (by decide)) (by decide)
def e605601887478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e605601887478 : Closed e605601887478 ∧ code e605601887478 = 2804625143030 := by decide
private def t_e605601887478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem cert_e605601887478 : ¬ IsSelfInterpreter e605601887478 :=
  wSource (t := t_e605601887478) (replay_sound (ps := []) (t := e605601887478) (by decide)) (by decide)
def e605601887758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e605601887758 : Closed e605601887758 ∧ code e605601887758 = 2804625143310 := by decide
private def t_e605601887758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem cert_e605601887758 : ¬ IsSelfInterpreter e605601887758 :=
  wSource (t := t_e605601887758) (replay_sound (ps := []) (t := e605601887758) (by decide)) (by decide)
def e605601887842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e605601887842 : Closed e605601887842 ∧ code e605601887842 = 2804625143394 := by decide
private def t_e605601887842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem cert_e605601887842 : ¬ IsSelfInterpreter e605601887842 :=
  wSource (t := t_e605601887842) (replay_sound (ps := []) (t := e605601887842) (by decide)) (by decide)
def e605601887854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601887854 : Closed e605601887854 ∧ code e605601887854 = 2804625143406 := by decide
private def t_e605601887854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem cert_e605601887854 : ¬ IsSelfInterpreter e605601887854 :=
  wSource (t := t_e605601887854) (replay_sound (ps := []) (t := e605601887854) (by decide)) (by decide)
def e605601887866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601887866 : Closed e605601887866 ∧ code e605601887866 = 2804625143418 := by decide
private def t_e605601887866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem cert_e605601887866 : ¬ IsSelfInterpreter e605601887866 :=
  wSource (t := t_e605601887866) (replay_sound (ps := []) (t := e605601887866) (by decide)) (by decide)
def e605601888054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601888054 : Closed e605601888054 ∧ code e605601888054 = 2804625143606 := by decide
private def t_e605601888054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e605601888054 : ¬ IsSelfInterpreter e605601888054 :=
  wSource (t := t_e605601888054) (replay_sound (ps := []) (t := e605601888054) (by decide)) (by decide)
def e605601888058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601888058 : Closed e605601888058 ∧ code e605601888058 = 2804625143610 := by decide
private def t_e605601888058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e605601888058 : ¬ IsSelfInterpreter e605601888058 :=
  wSource (t := t_e605601888058) (replay_sound (ps := []) (t := e605601888058) (by decide)) (by decide)
def e605601934778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))))
theorem wire_e605601934778 : Closed e605601934778 ∧ code e605601934778 = 2804625190330 := by decide
theorem cert_e605601934778 : check e605601934778 [[],[]] .smaller = true := by decide
def e605601934810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))))
theorem wire_e605601934810 : Closed e605601934810 ∧ code e605601934810 = 2804625190362 := by decide
theorem cert_e605601934810 : check e605601934810 [[],[]] .smaller = true := by decide
def e605601935034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))))
theorem wire_e605601935034 : Closed e605601935034 ∧ code e605601935034 = 2804625190586 := by decide
theorem cert_e605601935034 : check e605601935034 [[],[]] .smaller = true := by decide
def e605601935082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))))
theorem wire_e605601935082 : Closed e605601935082 ∧ code e605601935082 = 2804625190634 := by decide
theorem cert_e605601935082 : check e605601935082 [[],[]] .smaller = true := by decide
def e605601935194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))))
theorem wire_e605601935194 : Closed e605601935194 ∧ code e605601935194 = 2804625190746 := by decide
theorem cert_e605601935194 : check e605601935194 [[],[]] .smaller = true := by decide
def e605601935210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))))
theorem wire_e605601935210 : Closed e605601935210 ∧ code e605601935210 = 2804625190762 := by decide
theorem cert_e605601935210 : check e605601935210 [[],[]] .smaller = true := by decide
def e605601936314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))))
theorem wire_e605601936314 : Closed e605601936314 ∧ code e605601936314 = 2804625191866 := by decide
theorem cert_e605601936314 : check e605601936314 [[],[]] .smaller = true := by decide
def e605601936346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))))
theorem wire_e605601936346 : Closed e605601936346 ∧ code e605601936346 = 2804625191898 := by decide
theorem cert_e605601936346 : check e605601936346 [[],[]] .smaller = true := by decide
def e605601936622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.app (.var 1) (.var 2)))))))
theorem wire_e605601936622 : Closed e605601936622 ∧ code e605601936622 = 2804625192174 := by decide
theorem cert_e605601936622 : check e605601936622 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601936630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.app (.var 2) (.var 1)))))))
theorem wire_e605601936630 : Closed e605601936630 ∧ code e605601936630 = 2804625192182 := by decide
theorem cert_e605601936630 : check e605601936630 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601937850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))))
theorem wire_e605601937850 : Closed e605601937850 ∧ code e605601937850 = 2804625193402 := by decide
theorem cert_e605601937850 : check e605601937850 [[],[]] .smaller = true := by decide
def e605601937898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))))
theorem wire_e605601937898 : Closed e605601937898 ∧ code e605601937898 = 2804625193450 := by decide
theorem cert_e605601937898 : check e605601937898 [[],[]] .smaller = true := by decide
def e605601938650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))))
theorem wire_e605601938650 : Closed e605601938650 ∧ code e605601938650 = 2804625194202 := by decide
theorem cert_e605601938650 : check e605601938650 [[],[]] .smaller = true := by decide
def e605601938666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))))
theorem wire_e605601938666 : Closed e605601938666 ∧ code e605601938666 = 2804625194218 := by decide
theorem cert_e605601938666 : check e605601938666 [[],[]] .smaller = true := by decide
def e605601938926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 3))))) (.var 2))))))
theorem wire_e605601938926 : Closed e605601938926 ∧ code e605601938926 = 2804625194478 := by decide
theorem cert_e605601938926 : check e605601938926 [[],[]] .chain = true := by decide
def e605601938934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 4))))) (.var 1))))))
theorem wire_e605601938934 : Closed e605601938934 ∧ code e605601938934 = 2804625194486 := by decide
theorem cert_e605601938934 : check e605601938934 [[],[]] .chain = true := by decide
def e605601939182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 2))))) (.var 2))))))
theorem wire_e605601939182 : Closed e605601939182 ∧ code e605601939182 = 2804625194734 := by decide
theorem cert_e605601939182 : check e605601939182 [[],[]] .chain = true := by decide
def e605601939194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 4))))) (.var 0))))))
theorem wire_e605601939194 : Closed e605601939194 ∧ code e605601939194 = 2804625194746 := by decide
theorem cert_e605601939194 : check e605601939194 [[],[]] .chain = true := by decide
def e605601939318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 2))))) (.var 1))))))
theorem wire_e605601939318 : Closed e605601939318 ∧ code e605601939318 = 2804625194870 := by decide
theorem cert_e605601939318 : check e605601939318 [[],[]] .chain = true := by decide
def e605601939322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 3))))) (.var 0))))))
theorem wire_e605601939322 : Closed e605601939322 ∧ code e605601939322 = 2804625194874 := by decide
theorem cert_e605601939322 : check e605601939322 [[],[]] .chain = true := by decide
def e605601942382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605601942382 : Closed e605601942382 ∧ code e605601942382 = 2804625197934 := by decide
theorem cert_e605601942382 : check e605601942382 [[],[]] .chain = true := by decide
def e605601942390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605601942390 : Closed e605601942390 ∧ code e605601942390 = 2804625197942 := by decide
theorem cert_e605601942390 : check e605601942390 [[],[]] .chain = true := by decide
def e605601942446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605601942446 : Closed e605601942446 ∧ code e605601942446 = 2804625197998 := by decide
theorem cert_e605601942446 : check e605601942446 [[],[]] .chain = true := by decide
def e605601942458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605601942458 : Closed e605601942458 ∧ code e605601942458 = 2804625198010 := by decide
theorem cert_e605601942458 : check e605601942458 [[],[]] .chain = true := by decide
def e605601942486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605601942486 : Closed e605601942486 ∧ code e605601942486 = 2804625198038 := by decide
theorem cert_e605601942486 : check e605601942486 [[],[]] .chain = true := by decide
def e605601942490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605601942490 : Closed e605601942490 ∧ code e605601942490 = 2804625198042 := by decide
theorem cert_e605601942490 : check e605601942490 [[],[]] .chain = true := by decide
def e605601942766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605601942766 : Closed e605601942766 ∧ code e605601942766 = 2804625198318 := by decide
theorem cert_e605601942766 : check e605601942766 [[],[]] .chain = true := by decide
def e605601942774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605601942774 : Closed e605601942774 ∧ code e605601942774 = 2804625198326 := by decide
theorem cert_e605601942774 : check e605601942774 [[],[]] .chain = true := by decide
def e605601943150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605601943150 : Closed e605601943150 ∧ code e605601943150 = 2804625198702 := by decide
theorem cert_e605601943150 : check e605601943150 [[],[]] .chain = true := by decide
def e605601943162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605601943162 : Closed e605601943162 ∧ code e605601943162 = 2804625198714 := by decide
theorem cert_e605601943162 : check e605601943162 [[],[]] .chain = true := by decide
def e605601943350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605601943350 : Closed e605601943350 ∧ code e605601943350 = 2804625198902 := by decide
theorem cert_e605601943350 : check e605601943350 [[],[]] .chain = true := by decide
def e605601943354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605601943354 : Closed e605601943354 ∧ code e605601943354 = 2804625198906 := by decide
theorem cert_e605601943354 : check e605601943354 [[],[]] .chain = true := by decide
def e605601954286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 2)))))))
theorem wire_e605601954286 : Closed e605601954286 ∧ code e605601954286 = 2804625209838 := by decide
theorem cert_e605601954286 : check e605601954286 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605601955054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605601955054 : Closed e605601955054 ∧ code e605601955054 = 2804625210606 := by decide
theorem cert_e605601955054 : check e605601955054 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601955062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605601955062 : Closed e605601955062 ∧ code e605601955062 = 2804625210614 := by decide
theorem cert_e605601955062 : check e605601955062 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601969890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e605601969890 : Closed e605601969890 ∧ code e605601969890 = 2804625225442 := by decide
theorem cert_e605601969890 : check e605601969890 [[],[]] .smaller = true := by decide
def e605601969902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 2))))))
theorem wire_e605601969902 : Closed e605601969902 ∧ code e605601969902 = 2804625225454 := by decide
theorem cert_e605601969902 : check e605601969902 [[],[]] .chain = true := by decide
def e605601969910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))) (.var 1))))))
theorem wire_e605601969910 : Closed e605601969910 ∧ code e605601969910 = 2804625225462 := by decide
theorem cert_e605601969910 : check e605601969910 [[],[]] .chain = true := by decide
def e605601970018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e605601970018 : Closed e605601970018 ∧ code e605601970018 = 2804625225570 := by decide
theorem cert_e605601970018 : check e605601970018 [[],[]] .smaller = true := by decide
def e605601970030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 2))))))
theorem wire_e605601970030 : Closed e605601970030 ∧ code e605601970030 = 2804625225582 := by decide
theorem cert_e605601970030 : check e605601970030 [[],[]] .chain = true := by decide
def e605601970042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))) (.var 0))))))
theorem wire_e605601970042 : Closed e605601970042 ∧ code e605601970042 = 2804625225594 := by decide
theorem cert_e605601970042 : check e605601970042 [[],[]] .chain = true := by decide
def e605601970102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))) (.var 1))))))
theorem wire_e605601970102 : Closed e605601970102 ∧ code e605601970102 = 2804625225654 := by decide
theorem cert_e605601970102 : check e605601970102 [[],[]] .chain = true := by decide
def e605601970106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))) (.var 0))))))
theorem wire_e605601970106 : Closed e605601970106 ∧ code e605601970106 = 2804625225658 := by decide
theorem cert_e605601970106 : check e605601970106 [[],[]] .chain = true := by decide
def e605601970914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e605601970914 : Closed e605601970914 ∧ code e605601970914 = 2804625226466 := by decide
theorem cert_e605601970914 : check e605601970914 [[],[]] .smaller = true := by decide
def e605601970926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 2))))))
theorem wire_e605601970926 : Closed e605601970926 ∧ code e605601970926 = 2804625226478 := by decide
theorem cert_e605601970926 : check e605601970926 [[],[]] .chain = true := by decide
def e605601970934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))) (.var 1))))))
theorem wire_e605601970934 : Closed e605601970934 ∧ code e605601970934 = 2804625226486 := by decide
theorem cert_e605601970934 : check e605601970934 [[],[]] .chain = true := by decide
def e605601971106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e605601971106 : Closed e605601971106 ∧ code e605601971106 = 2804625226658 := by decide
theorem cert_e605601971106 : check e605601971106 [[],[]] .smaller = true := by decide
def e605601971118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 2))))))
theorem wire_e605601971118 : Closed e605601971118 ∧ code e605601971118 = 2804625226670 := by decide
theorem cert_e605601971118 : check e605601971118 [[],[]] .chain = true := by decide
def e605601971158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))) (.var 1))))))
theorem wire_e605601971158 : Closed e605601971158 ∧ code e605601971158 = 2804625226710 := by decide
theorem cert_e605601971158 : check e605601971158 [[],[]] .chain = true := by decide
def e605601971554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e605601971554 : Closed e605601971554 ∧ code e605601971554 = 2804625227106 := by decide
theorem cert_e605601971554 : check e605601971554 [[],[]] .smaller = true := by decide
def e605601971566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e605601971566 : Closed e605601971566 ∧ code e605601971566 = 2804625227118 := by decide
theorem cert_e605601971566 : check e605601971566 [[],[]] .chain = true := by decide
def e605601971578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))) (.var 0))))))
theorem wire_e605601971578 : Closed e605601971578 ∧ code e605601971578 = 2804625227130 := by decide
theorem cert_e605601971578 : check e605601971578 [[],[]] .chain = true := by decide
def e605601971618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e605601971618 : Closed e605601971618 ∧ code e605601971618 = 2804625227170 := by decide
theorem cert_e605601971618 : check e605601971618 [[],[]] .smaller = true := by decide
def e605601971630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e605601971630 : Closed e605601971630 ∧ code e605601971630 = 2804625227182 := by decide
theorem cert_e605601971630 : check e605601971630 [[],[]] .chain = true := by decide
def e605601971690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))) (.var 0))))))
theorem wire_e605601971690 : Closed e605601971690 ∧ code e605601971690 = 2804625227242 := by decide
theorem cert_e605601971690 : check e605601971690 [[],[]] .chain = true := by decide
def e605601971894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e605601971894 : Closed e605601971894 ∧ code e605601971894 = 2804625227446 := by decide
theorem cert_e605601971894 : check e605601971894 [[],[]] .chain = true := by decide
def e605601971898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e605601971898 : Closed e605601971898 ∧ code e605601971898 = 2804625227450 := by decide
theorem cert_e605601971898 : check e605601971898 [[],[]] .chain = true := by decide
def e605601971926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e605601971926 : Closed e605601971926 ∧ code e605601971926 = 2804625227478 := by decide
theorem cert_e605601971926 : check e605601971926 [[],[]] .chain = true := by decide
def e605601971946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e605601971946 : Closed e605601971946 ∧ code e605601971946 = 2804625227498 := by decide
theorem cert_e605601971946 : check e605601971946 [[],[]] .chain = true := by decide
def e605601976034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 0)))))))
theorem wire_e605601976034 : Closed e605601976034 ∧ code e605601976034 = 2804625231586 := by decide
theorem cert_e605601976034 : check e605601976034 [[],[]] .smaller = true := by decide
def e605601976046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 2))))))
theorem wire_e605601976046 : Closed e605601976046 ∧ code e605601976046 = 2804625231598 := by decide
theorem cert_e605601976046 : check e605601976046 [[],[]] .chain = true := by decide
def e605601976054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))) (.var 1))))))
theorem wire_e605601976054 : Closed e605601976054 ∧ code e605601976054 = 2804625231606 := by decide
theorem cert_e605601976054 : check e605601976054 [[],[]] .chain = true := by decide
def e605601976162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 0)))))))
theorem wire_e605601976162 : Closed e605601976162 ∧ code e605601976162 = 2804625231714 := by decide
theorem cert_e605601976162 : check e605601976162 [[],[]] .smaller = true := by decide
def e605601976174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 2))))))
theorem wire_e605601976174 : Closed e605601976174 ∧ code e605601976174 = 2804625231726 := by decide
theorem cert_e605601976174 : check e605601976174 [[],[]] .chain = true := by decide
def e605601976186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))) (.var 0))))))
theorem wire_e605601976186 : Closed e605601976186 ∧ code e605601976186 = 2804625231738 := by decide
theorem cert_e605601976186 : check e605601976186 [[],[]] .chain = true := by decide
def e605601976246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))) (.var 1))))))
theorem wire_e605601976246 : Closed e605601976246 ∧ code e605601976246 = 2804625231798 := by decide
theorem cert_e605601976246 : check e605601976246 [[],[]] .chain = true := by decide
def e605601976250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))) (.var 0))))))
theorem wire_e605601976250 : Closed e605601976250 ∧ code e605601976250 = 2804625231802 := by decide
theorem cert_e605601976250 : check e605601976250 [[],[]] .chain = true := by decide
def e605601979630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605601979630 : Closed e605601979630 ∧ code e605601979630 = 2804625235182 := by decide
theorem cert_e605601979630 : check e605601979630 [[],[]] .chain = true := by decide
def e605601979638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605601979638 : Closed e605601979638 ∧ code e605601979638 = 2804625235190 := by decide
theorem cert_e605601979638 : check e605601979638 [[],[]] .chain = true := by decide
def e605601980022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 1)))))))
theorem wire_e605601980022 : Closed e605601980022 ∧ code e605601980022 = 2804625235574 := by decide
theorem cert_e605601980022 : check e605601980022 [[],[]] .chain = true := by decide
def e605601982178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 0)))))))
theorem wire_e605601982178 : Closed e605601982178 ∧ code e605601982178 = 2804625237730 := by decide
theorem cert_e605601982178 : check e605601982178 [[],[]] .smaller = true := by decide
def e605601982190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e605601982190 : Closed e605601982190 ∧ code e605601982190 = 2804625237742 := by decide
theorem cert_e605601982190 : check e605601982190 [[],[]] .chain = true := by decide
def e605601982198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))) (.var 1))))))
theorem wire_e605601982198 : Closed e605601982198 ∧ code e605601982198 = 2804625237750 := by decide
theorem cert_e605601982198 : check e605601982198 [[],[]] .chain = true := by decide
def e605601982370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e605601982370 : Closed e605601982370 ∧ code e605601982370 = 2804625237922 := by decide
theorem cert_e605601982370 : check e605601982370 [[],[]] .smaller = true := by decide
def e605601982382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e605601982382 : Closed e605601982382 ∧ code e605601982382 = 2804625237934 := by decide
theorem cert_e605601982382 : check e605601982382 [[],[]] .chain = true := by decide
def e605601982422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))) (.var 1))))))
theorem wire_e605601982422 : Closed e605601982422 ∧ code e605601982422 = 2804625237974 := by decide
theorem cert_e605601982422 : check e605601982422 [[],[]] .chain = true := by decide
end Blc.Floor41
