import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e604617414510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e604617414510 : Closed e604617414510 ∧ code e604617414510 = 2803640670062 := by decide
theorem cert_e604617414510 : check e604617414510 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604617414518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e604617414518 : Closed e604617414518 ∧ code e604617414518 = 2803640670070 := by decide
theorem cert_e604617414518 : check e604617414518 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604617414582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e604617414582 : Closed e604617414582 ∧ code e604617414582 = 2803640670134 := by decide
theorem cert_e604617414582 : check e604617414582 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e604617415918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e604617415918 : Closed e604617415918 ∧ code e604617415918 = 2803640671470 := by decide
theorem cert_e604617415918 : check e604617415918 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604617415926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e604617415926 : Closed e604617415926 ∧ code e604617415926 = 2803640671478 := by decide
theorem cert_e604617415926 : check e604617415926 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604617416310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e604617416310 : Closed e604617416310 ∧ code e604617416310 = 2803640671862 := by decide
theorem cert_e604617416310 : check e604617416310 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e604617427822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604617427822 : Closed e604617427822 ∧ code e604617427822 = 2803640683374 := by decide
theorem cert_e604617427822 : check e604617427822 [[],[]] .sourceHead = true := by decide
def e604617427830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604617427830 : Closed e604617427830 ∧ code e604617427830 = 2803640683382 := by decide
theorem cert_e604617427830 : check e604617427830 [[],[]] .sourceHead = true := by decide
def e604617427886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604617427886 : Closed e604617427886 ∧ code e604617427886 = 2803640683438 := by decide
theorem cert_e604617427886 : check e604617427886 [[],[]] .sourceHead = true := by decide
def e604617427898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604617427898 : Closed e604617427898 ∧ code e604617427898 = 2803640683450 := by decide
theorem cert_e604617427898 : check e604617427898 [[],[]] .sourceHead = true := by decide
def e604617427926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604617427926 : Closed e604617427926 ∧ code e604617427926 = 2803640683478 := by decide
theorem cert_e604617427926 : check e604617427926 [[],[]] .sourceHead = true := by decide
def e604617427930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604617427930 : Closed e604617427930 ∧ code e604617427930 = 2803640683482 := by decide
theorem cert_e604617427930 : check e604617427930 [[],[]] .sourceHead = true := by decide
def e604617428206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604617428206 : Closed e604617428206 ∧ code e604617428206 = 2803640683758 := by decide
theorem cert_e604617428206 : check e604617428206 [[],[]] .sourceHead = true := by decide
def e604617428214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604617428214 : Closed e604617428214 ∧ code e604617428214 = 2803640683766 := by decide
theorem cert_e604617428214 : check e604617428214 [[],[]] .sourceHead = true := by decide
def e604617428590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604617428590 : Closed e604617428590 ∧ code e604617428590 = 2803640684142 := by decide
theorem cert_e604617428590 : check e604617428590 [[],[]] .sourceHead = true := by decide
def e604617428602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604617428602 : Closed e604617428602 ∧ code e604617428602 = 2803640684154 := by decide
theorem cert_e604617428602 : check e604617428602 [[],[]] .sourceHead = true := by decide
def e604617428790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604617428790 : Closed e604617428790 ∧ code e604617428790 = 2803640684342 := by decide
theorem cert_e604617428790 : check e604617428790 [[],[]] .sourceHead = true := by decide
def e604617428794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604617428794 : Closed e604617428794 ∧ code e604617428794 = 2803640684346 := by decide
theorem cert_e604617428794 : check e604617428794 [[],[]] .sourceHead = true := by decide
def e604617434550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e604617434550 : Closed e604617434550 ∧ code e604617434550 = 2803640690102 := by decide
theorem cert_e604617434550 : check e604617434550 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604617434582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e604617434582 : Closed e604617434582 ∧ code e604617434582 = 2803640690134 := by decide
theorem cert_e604617434582 : check e604617434582 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604617434586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e604617434586 : Closed e604617434586 ∧ code e604617434586 = 2803640690138 := by decide
theorem cert_e604617434586 : check e604617434586 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604617434742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e604617434742 : Closed e604617434742 ∧ code e604617434742 = 2803640690294 := by decide
theorem cert_e604617434742 : check e604617434742 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604617434934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e604617434934 : Closed e604617434934 ∧ code e604617434934 = 2803640690486 := by decide
theorem cert_e604617434934 : check e604617434934 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604617434938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e604617434938 : Closed e604617434938 ∧ code e604617434938 = 2803640690490 := by decide
theorem cert_e604617434938 : check e604617434938 [[],[],[.under,.under,.left]] .chain = true := by decide
def e604617771886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604617771886 : Closed e604617771886 ∧ code e604617771886 = 2803641027438 := by decide
theorem cert_e604617771886 : check e604617771886 [[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e604617771894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604617771894 : Closed e604617771894 ∧ code e604617771894 = 2803641027446 := by decide
theorem cert_e604617771894 : check e604617771894 [[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e604617771950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604617771950 : Closed e604617771950 ∧ code e604617771950 = 2803641027502 := by decide
theorem cert_e604617771950 : check e604617771950 [[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e604617771962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604617771962 : Closed e604617771962 ∧ code e604617771962 = 2803641027514 := by decide
theorem cert_e604617771962 : check e604617771962 [[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e604617771990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604617771990 : Closed e604617771990 ∧ code e604617771990 = 2803641027542 := by decide
theorem cert_e604617771990 : check e604617771990 [[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e604617771994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604617771994 : Closed e604617771994 ∧ code e604617771994 = 2803641027546 := by decide
theorem cert_e604617771994 : check e604617771994 [[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e604617772270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604617772270 : Closed e604617772270 ∧ code e604617772270 = 2803641027822 := by decide
theorem cert_e604617772270 : check e604617772270 [[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e604617772278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604617772278 : Closed e604617772278 ∧ code e604617772278 = 2803641027830 := by decide
theorem cert_e604617772278 : check e604617772278 [[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e604617772654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604617772654 : Closed e604617772654 ∧ code e604617772654 = 2803641028206 := by decide
theorem cert_e604617772654 : check e604617772654 [[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e604617772666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604617772666 : Closed e604617772666 ∧ code e604617772666 = 2803641028218 := by decide
theorem cert_e604617772666 : check e604617772666 [[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e604617772854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604617772854 : Closed e604617772854 ∧ code e604617772854 = 2803641028406 := by decide
theorem cert_e604617772854 : check e604617772854 [[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e604617772858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604617772858 : Closed e604617772858 ∧ code e604617772858 = 2803641028410 := by decide
theorem cert_e604617772858 : check e604617772858 [[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e604718722586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604718722586 : Closed e604718722586 ∧ code e604718722586 = 2803741978138 := by decide
theorem cert_e604718722586 : check e604718722586 [[]] .width = true := by decide
def e604718724634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604718724634 : Closed e604718724634 ∧ code e604718724634 = 2803741980186 := by decide
theorem cert_e604718724634 : check e604718724634 [[]] .width = true := by decide
def e604718738970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604718738970 : Closed e604718738970 ∧ code e604718738970 = 2803741994522 := by decide
theorem cert_e604718738970 : check e604718738970 [[]] .width = true := by decide
def e604718742042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604718742042 : Closed e604718742042 ∧ code e604718742042 = 2803741997594 := by decide
private def t_e604718742042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604718742042 : ¬ IsSelfInterpreter e604718742042 :=
  wSource (t := t_e604718742042) (replay_sound (ps := []) (t := e604718742042) (by decide)) (by decide)
def e604718749210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604718749210 : Closed e604718749210 ∧ code e604718749210 = 2803742004762 := by decide
theorem cert_e604718749210 : check e604718749210 [[]] .width = true := by decide
def e604718750234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604718750234 : Closed e604718750234 ∧ code e604718750234 = 2803742005786 := by decide
private def t_e604718750234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604718750234 : ¬ IsSelfInterpreter e604718750234 :=
  wSource (t := t_e604718750234) (replay_sound (ps := []) (t := e604718750234) (by decide)) (by decide)
def e604718820890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604718820890 : Closed e604718820890 ∧ code e604718820890 = 2803742076442 := by decide
theorem cert_e604718820890 : check e604718820890 [[]] .width = true := by decide
def e604718822938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604718822938 : Closed e604718822938 ∧ code e604718822938 = 2803742078490 := by decide
theorem cert_e604718822938 : check e604718822938 [[]] .width = true := by decide
def e604718919194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604718919194 : Closed e604718919194 ∧ code e604718919194 = 2803742174746 := by decide
theorem cert_e604718919194 : check e604718919194 [[]] .width = true := by decide
def e604718922266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604718922266 : Closed e604718922266 ∧ code e604718922266 = 2803742177818 := by decide
theorem cert_e604718922266 : check e604718922266 [[]] .width = true := by decide
def e604718970394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604718970394 : Closed e604718970394 ∧ code e604718970394 = 2803742225946 := by decide
theorem cert_e604718970394 : check e604718970394 [[]] .width = true := by decide
def e604718971418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604718971418 : Closed e604718971418 ∧ code e604718971418 = 2803742226970 := by decide
theorem cert_e604718971418 : check e604718971418 [[]] .width = true := by decide
def e604734795118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e604734795118 : Closed e604734795118 ∧ code e604734795118 = 2803758050670 := by decide
theorem cert_e604734795118 : check e604734795118 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e604734795126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e604734795126 : Closed e604734795126 ∧ code e604734795126 = 2803758050678 := by decide
theorem cert_e604734795126 : checkPay e604734795126 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604734795182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e604734795182 : Closed e604734795182 ∧ code e604734795182 = 2803758050734 := by decide
theorem cert_e604734795182 : check e604734795182 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604734795194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e604734795194 : Closed e604734795194 ∧ code e604734795194 = 2803758050746 := by decide
theorem cert_e604734795194 : check e604734795194 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e604734795222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e604734795222 : Closed e604734795222 ∧ code e604734795222 = 2803758050774 := by decide
theorem cert_e604734795222 : check e604734795222 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604734795226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e604734795226 : Closed e604734795226 ∧ code e604734795226 = 2803758050778 := by decide
theorem cert_e604734795226 : check e604734795226 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e604734795438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e604734795438 : Closed e604734795438 ∧ code e604734795438 = 2803758050990 := by decide
theorem cert_e604734795438 : check e604734795438 [[],[]] .sourceHead = true := by decide
def e604734795450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e604734795450 : Closed e604734795450 ∧ code e604734795450 = 2803758051002 := by decide
theorem cert_e604734795450 : check e604734795450 [[],[]] .sourceHead = true := by decide
def e604734795498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e604734795498 : Closed e604734795498 ∧ code e604734795498 = 2803758051050 := by decide
theorem cert_e604734795498 : check e604734795498 [[],[]] .sourceHead = true := by decide
def e604734795606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e604734795606 : Closed e604734795606 ∧ code e604734795606 = 2803758051158 := by decide
theorem cert_e604734795606 : check e604734795606 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e604734795610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e604734795610 : Closed e604734795610 ∧ code e604734795610 = 2803758051162 := by decide
theorem cert_e604734795610 : check e604734795610 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e604734795626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e604734795626 : Closed e604734795626 ∧ code e604734795626 = 2803758051178 := by decide
theorem cert_e604734795626 : check e604734795626 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e604734796654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e604734796654 : Closed e604734796654 ∧ code e604734796654 = 2803758052206 := by decide
theorem cert_e604734796654 : check e604734796654 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e604734796662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e604734796662 : Closed e604734796662 ∧ code e604734796662 = 2803758052214 := by decide
theorem cert_e604734796662 : check e604734796662 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e604734796718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e604734796718 : Closed e604734796718 ∧ code e604734796718 = 2803758052270 := by decide
theorem cert_e604734796718 : check e604734796718 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604734796730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e604734796730 : Closed e604734796730 ∧ code e604734796730 = 2803758052282 := by decide
theorem cert_e604734796730 : check e604734796730 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604734796758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e604734796758 : Closed e604734796758 ∧ code e604734796758 = 2803758052310 := by decide
theorem cert_e604734796758 : check e604734796758 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604734796762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e604734796762 : Closed e604734796762 ∧ code e604734796762 = 2803758052314 := by decide
theorem cert_e604734796762 : check e604734796762 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604734797038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e604734797038 : Closed e604734797038 ∧ code e604734797038 = 2803758052590 := by decide
theorem cert_e604734797038 : check e604734797038 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604734797046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e604734797046 : Closed e604734797046 ∧ code e604734797046 = 2803758052598 := by decide
theorem cert_e604734797046 : check e604734797046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604734797422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e604734797422 : Closed e604734797422 ∧ code e604734797422 = 2803758052974 := by decide
theorem cert_e604734797422 : check e604734797422 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604734797434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e604734797434 : Closed e604734797434 ∧ code e604734797434 = 2803758052986 := by decide
theorem cert_e604734797434 : check e604734797434 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e604734797622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e604734797622 : Closed e604734797622 ∧ code e604734797622 = 2803758053174 := by decide
theorem cert_e604734797622 : check e604734797622 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e604734797626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e604734797626 : Closed e604734797626 ∧ code e604734797626 = 2803758053178 := by decide
theorem cert_e604734797626 : check e604734797626 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604734798254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e604734798254 : Closed e604734798254 ∧ code e604734798254 = 2803758053806 := by decide
theorem cert_e604734798254 : checkPay e604734798254 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e604734798266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e604734798266 : Closed e604734798266 ∧ code e604734798266 = 2803758053818 := by decide
theorem cert_e604734798266 : checkPay e604734798266 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left]] = true := by decide
def e604734798314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e604734798314 : Closed e604734798314 ∧ code e604734798314 = 2803758053866 := by decide
theorem cert_e604734798314 : checkPay e604734798314 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left,.right],[.under,.left,.left,.left,.right,.under,.under,.left,.right]] = true := by decide
def e604734798446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e604734798446 : Closed e604734798446 ∧ code e604734798446 = 2803758053998 := by decide
theorem cert_e604734798446 : checkPay e604734798446 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604734798458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e604734798458 : Closed e604734798458 ∧ code e604734798458 = 2803758054010 := by decide
theorem cert_e604734798458 : checkPay e604734798458 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e604734798746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e604734798746 : Closed e604734798746 ∧ code e604734798746 = 2803758054298 := by decide
theorem cert_e604734798746 : checkPay e604734798746 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e604734799062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e604734799062 : Closed e604734799062 ∧ code e604734799062 = 2803758054614 := by decide
theorem cert_e604734799062 : check e604734799062 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e604734799066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e604734799066 : Closed e604734799066 ∧ code e604734799066 = 2803758054618 := by decide
theorem cert_e604734799066 : check e604734799066 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e604734799082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e604734799082 : Closed e604734799082 ∧ code e604734799082 = 2803758054634 := by decide
theorem cert_e604734799082 : check e604734799082 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e604734799158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e604734799158 : Closed e604734799158 ∧ code e604734799158 = 2803758054710 := by decide
theorem cert_e604734799158 : check e604734799158 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e604734799162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e604734799162 : Closed e604734799162 ∧ code e604734799162 = 2803758054714 := by decide
theorem cert_e604734799162 : check e604734799162 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e604734799258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e604734799258 : Closed e604734799258 ∧ code e604734799258 = 2803758054810 := by decide
theorem cert_e604734799258 : check e604734799258 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e604734802798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604734802798 : Closed e604734802798 ∧ code e604734802798 = 2803758058350 := by decide
theorem cert_e604734802798 : check e604734802798 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e604734802806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604734802806 : Closed e604734802806 ∧ code e604734802806 = 2803758058358 := by decide
theorem cert_e604734802806 : check e604734802806 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e604734802862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604734802862 : Closed e604734802862 ∧ code e604734802862 = 2803758058414 := by decide
theorem cert_e604734802862 : check e604734802862 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604734802874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604734802874 : Closed e604734802874 ∧ code e604734802874 = 2803758058426 := by decide
theorem cert_e604734802874 : check e604734802874 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604734802902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604734802902 : Closed e604734802902 ∧ code e604734802902 = 2803758058454 := by decide
theorem cert_e604734802902 : check e604734802902 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e604734802906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604734802906 : Closed e604734802906 ∧ code e604734802906 = 2803758058458 := by decide
theorem cert_e604734802906 : check e604734802906 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604734803182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604734803182 : Closed e604734803182 ∧ code e604734803182 = 2803758058734 := by decide
theorem cert_e604734803182 : check e604734803182 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e604734803190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604734803190 : Closed e604734803190 ∧ code e604734803190 = 2803758058742 := by decide
theorem cert_e604734803190 : check e604734803190 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604734803566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604734803566 : Closed e604734803566 ∧ code e604734803566 = 2803758059118 := by decide
theorem cert_e604734803566 : check e604734803566 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604734803578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604734803578 : Closed e604734803578 ∧ code e604734803578 = 2803758059130 := by decide
theorem cert_e604734803578 : check e604734803578 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604734803766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604734803766 : Closed e604734803766 ∧ code e604734803766 = 2803758059318 := by decide
theorem cert_e604734803766 : check e604734803766 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e604734803770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604734803770 : Closed e604734803770 ∧ code e604734803770 = 2803758059322 := by decide
theorem cert_e604734803770 : check e604734803770 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e604734809518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e604734809518 : Closed e604734809518 ∧ code e604734809518 = 2803758065070 := by decide
theorem cert_e604734809518 : check e604734809518 [[],[]] .sourceHead = true := by decide
def e604734809530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e604734809530 : Closed e604734809530 ∧ code e604734809530 = 2803758065082 := by decide
theorem cert_e604734809530 : check e604734809530 [[],[]] .sourceHead = true := by decide
def e604734809578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e604734809578 : Closed e604734809578 ∧ code e604734809578 = 2803758065130 := by decide
theorem cert_e604734809578 : check e604734809578 [[],[]] .sourceHead = true := by decide
def e604734809710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e604734809710 : Closed e604734809710 ∧ code e604734809710 = 2803758065262 := by decide
theorem cert_e604734809710 : check e604734809710 [[],[]] .sourceHead = true := by decide
def e604734809722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e604734809722 : Closed e604734809722 ∧ code e604734809722 = 2803758065274 := by decide
theorem cert_e604734809722 : check e604734809722 [[],[]] .sourceHead = true := by decide
def e604734810010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e604734810010 : Closed e604734810010 ∧ code e604734810010 = 2803758065562 := by decide
theorem cert_e604734810010 : check e604734810010 [[],[]] .sourceHead = true := by decide
def e604734812886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e604734812886 : Closed e604734812886 ∧ code e604734812886 = 2803758068438 := by decide
theorem cert_e604734812886 : check e604734812886 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e604734812890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e604734812890 : Closed e604734812890 ∧ code e604734812890 = 2803758068442 := by decide
theorem cert_e604734812890 : check e604734812890 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e604734812906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e604734812906 : Closed e604734812906 ∧ code e604734812906 = 2803758068458 := by decide
theorem cert_e604734812906 : check e604734812906 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e604734812982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e604734812982 : Closed e604734812982 ∧ code e604734812982 = 2803758068534 := by decide
theorem cert_e604734812982 : check e604734812982 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e604734812986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e604734812986 : Closed e604734812986 ∧ code e604734812986 = 2803758068538 := by decide
theorem cert_e604734812986 : check e604734812986 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e604734813082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e604734813082 : Closed e604734813082 ∧ code e604734813082 = 2803758068634 := by decide
theorem cert_e604734813082 : check e604734813082 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e604734950254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604734950254 : Closed e604734950254 ∧ code e604734950254 = 2803758205806 := by decide
theorem cert_e604734950254 : check e604734950254 [[],[]] .sourceHead = true := by decide
def e604734950262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604734950262 : Closed e604734950262 ∧ code e604734950262 = 2803758205814 := by decide
theorem cert_e604734950262 : check e604734950262 [[],[]] .sourceHead = true := by decide
def e604734950318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604734950318 : Closed e604734950318 ∧ code e604734950318 = 2803758205870 := by decide
theorem cert_e604734950318 : check e604734950318 [[],[]] .sourceHead = true := by decide
def e604734950330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604734950330 : Closed e604734950330 ∧ code e604734950330 = 2803758205882 := by decide
theorem cert_e604734950330 : check e604734950330 [[],[]] .sourceHead = true := by decide
def e604734950358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604734950358 : Closed e604734950358 ∧ code e604734950358 = 2803758205910 := by decide
theorem cert_e604734950358 : check e604734950358 [[],[]] .sourceHead = true := by decide
def e604734950362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604734950362 : Closed e604734950362 ∧ code e604734950362 = 2803758205914 := by decide
theorem cert_e604734950362 : check e604734950362 [[],[]] .sourceHead = true := by decide
def e604734950638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604734950638 : Closed e604734950638 ∧ code e604734950638 = 2803758206190 := by decide
theorem cert_e604734950638 : check e604734950638 [[],[]] .sourceHead = true := by decide
def e604734950646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604734950646 : Closed e604734950646 ∧ code e604734950646 = 2803758206198 := by decide
theorem cert_e604734950646 : check e604734950646 [[],[]] .sourceHead = true := by decide
def e604734951022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604734951022 : Closed e604734951022 ∧ code e604734951022 = 2803758206574 := by decide
theorem cert_e604734951022 : check e604734951022 [[],[]] .sourceHead = true := by decide
def e604734951034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604734951034 : Closed e604734951034 ∧ code e604734951034 = 2803758206586 := by decide
theorem cert_e604734951034 : check e604734951034 [[],[]] .sourceHead = true := by decide
def e604734951222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604734951222 : Closed e604734951222 ∧ code e604734951222 = 2803758206774 := by decide
theorem cert_e604734951222 : check e604734951222 [[],[]] .sourceHead = true := by decide
def e604734951226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604734951226 : Closed e604734951226 ∧ code e604734951226 = 2803758206778 := by decide
theorem cert_e604734951226 : check e604734951226 [[],[]] .sourceHead = true := by decide
def e604735540078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604735540078 : Closed e604735540078 ∧ code e604735540078 = 2803758795630 := by decide
def e604735540086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604735540086 : Closed e604735540086 ∧ code e604735540086 = 2803758795638 := by decide
def e604735540142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604735540142 : Closed e604735540142 ∧ code e604735540142 = 2803758795694 := by decide
def e604735540154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604735540154 : Closed e604735540154 ∧ code e604735540154 = 2803758795706 := by decide
private def t_e604735540154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e604735540154 : ¬ IsSelfInterpreter e604735540154 :=
  wSource (t := t_e604735540154) (replay_sound (ps := []) (t := e604735540154) (by decide)) (by decide)
def e604735540182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604735540182 : Closed e604735540182 ∧ code e604735540182 = 2803758795734 := by decide
def e604735540186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604735540186 : Closed e604735540186 ∧ code e604735540186 = 2803758795738 := by decide
private def t_e604735540186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e604735540186 : ¬ IsSelfInterpreter e604735540186 :=
  wSource (t := t_e604735540186) (replay_sound (ps := []) (t := e604735540186) (by decide)) (by decide)
def e604735540462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604735540462 : Closed e604735540462 ∧ code e604735540462 = 2803758796014 := by decide
theorem cert_e604735540462 : check e604735540462 [[],[],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604735540470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604735540470 : Closed e604735540470 ∧ code e604735540470 = 2803758796022 := by decide
theorem cert_e604735540470 : check e604735540470 [[],[],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604735540846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604735540846 : Closed e604735540846 ∧ code e604735540846 = 2803758796398 := by decide
def e604735540858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604735540858 : Closed e604735540858 ∧ code e604735540858 = 2803758796410 := by decide
def e604735541046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604735541046 : Closed e604735541046 ∧ code e604735541046 = 2803758796598 := by decide
def e604735541050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604735541050 : Closed e604735541050 ∧ code e604735541050 = 2803758796602 := by decide
def e604785126766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e604785126766 : Closed e604785126766 ∧ code e604785126766 = 2803808382318 := by decide
theorem cert_e604785126766 : check e604785126766 [[],[]] .smaller = true := by decide
def e604785126774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e604785126774 : Closed e604785126774 ∧ code e604785126774 = 2803808382326 := by decide
theorem cert_e604785126774 : check e604785126774 [[],[]] .smaller = true := by decide
def e604785126830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e604785126830 : Closed e604785126830 ∧ code e604785126830 = 2803808382382 := by decide
theorem cert_e604785126830 : check e604785126830 [[],[]] .smaller = true := by decide
def e604785126842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e604785126842 : Closed e604785126842 ∧ code e604785126842 = 2803808382394 := by decide
theorem cert_e604785126842 : check e604785126842 [[],[]] .smaller = true := by decide
def e604785126870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e604785126870 : Closed e604785126870 ∧ code e604785126870 = 2803808382422 := by decide
theorem cert_e604785126870 : check e604785126870 [[],[]] .smaller = true := by decide
def e604785126874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e604785126874 : Closed e604785126874 ∧ code e604785126874 = 2803808382426 := by decide
theorem cert_e604785126874 : check e604785126874 [[],[]] .smaller = true := by decide
def e604785127086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e604785127086 : Closed e604785127086 ∧ code e604785127086 = 2803808382638 := by decide
theorem cert_e604785127086 : check e604785127086 [[],[]] .smaller = true := by decide
def e604785127098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e604785127098 : Closed e604785127098 ∧ code e604785127098 = 2803808382650 := by decide
theorem cert_e604785127098 : check e604785127098 [[],[]] .smaller = true := by decide
def e604785127146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e604785127146 : Closed e604785127146 ∧ code e604785127146 = 2803808382698 := by decide
theorem cert_e604785127146 : check e604785127146 [[],[]] .smaller = true := by decide
def e604785127254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e604785127254 : Closed e604785127254 ∧ code e604785127254 = 2803808382806 := by decide
theorem cert_e604785127254 : check e604785127254 [[],[]] .smaller = true := by decide
def e604785127258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e604785127258 : Closed e604785127258 ∧ code e604785127258 = 2803808382810 := by decide
theorem cert_e604785127258 : check e604785127258 [[],[]] .smaller = true := by decide
def e604785127274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e604785127274 : Closed e604785127274 ∧ code e604785127274 = 2803808382826 := by decide
theorem cert_e604785127274 : check e604785127274 [[],[]] .smaller = true := by decide
def e604785128302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e604785128302 : Closed e604785128302 ∧ code e604785128302 = 2803808383854 := by decide
theorem cert_e604785128302 : check e604785128302 [[],[]] .smaller = true := by decide
def e604785128310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e604785128310 : Closed e604785128310 ∧ code e604785128310 = 2803808383862 := by decide
theorem cert_e604785128310 : check e604785128310 [[],[]] .smaller = true := by decide
def e604785128366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e604785128366 : Closed e604785128366 ∧ code e604785128366 = 2803808383918 := by decide
theorem cert_e604785128366 : check e604785128366 [[],[]] .smaller = true := by decide
def e604785128378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e604785128378 : Closed e604785128378 ∧ code e604785128378 = 2803808383930 := by decide
theorem cert_e604785128378 : check e604785128378 [[],[]] .smaller = true := by decide
def e604785128406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e604785128406 : Closed e604785128406 ∧ code e604785128406 = 2803808383958 := by decide
theorem cert_e604785128406 : check e604785128406 [[],[]] .smaller = true := by decide
def e604785128410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e604785128410 : Closed e604785128410 ∧ code e604785128410 = 2803808383962 := by decide
theorem cert_e604785128410 : check e604785128410 [[],[]] .smaller = true := by decide
def e604785128686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e604785128686 : Closed e604785128686 ∧ code e604785128686 = 2803808384238 := by decide
theorem cert_e604785128686 : check e604785128686 [[],[]] .smaller = true := by decide
def e604785128694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e604785128694 : Closed e604785128694 ∧ code e604785128694 = 2803808384246 := by decide
theorem cert_e604785128694 : check e604785128694 [[],[]] .smaller = true := by decide
def e604785129070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e604785129070 : Closed e604785129070 ∧ code e604785129070 = 2803808384622 := by decide
theorem cert_e604785129070 : check e604785129070 [[],[]] .smaller = true := by decide
def e604785129082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e604785129082 : Closed e604785129082 ∧ code e604785129082 = 2803808384634 := by decide
theorem cert_e604785129082 : check e604785129082 [[],[]] .smaller = true := by decide
def e604785129270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e604785129270 : Closed e604785129270 ∧ code e604785129270 = 2803808384822 := by decide
theorem cert_e604785129270 : check e604785129270 [[],[]] .smaller = true := by decide
def e604785129274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e604785129274 : Closed e604785129274 ∧ code e604785129274 = 2803808384826 := by decide
theorem cert_e604785129274 : check e604785129274 [[],[]] .smaller = true := by decide
def e604785129902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e604785129902 : Closed e604785129902 ∧ code e604785129902 = 2803808385454 := by decide
theorem cert_e604785129902 : check e604785129902 [[],[]] .smaller = true := by decide
def e604785129914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e604785129914 : Closed e604785129914 ∧ code e604785129914 = 2803808385466 := by decide
theorem cert_e604785129914 : check e604785129914 [[],[]] .smaller = true := by decide
def e604785129962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e604785129962 : Closed e604785129962 ∧ code e604785129962 = 2803808385514 := by decide
theorem cert_e604785129962 : check e604785129962 [[],[]] .smaller = true := by decide
def e604785130094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e604785130094 : Closed e604785130094 ∧ code e604785130094 = 2803808385646 := by decide
theorem cert_e604785130094 : check e604785130094 [[],[]] .smaller = true := by decide
end Blc.Floor41
