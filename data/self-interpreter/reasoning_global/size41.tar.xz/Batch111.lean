import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605602738922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e605602738922 : Closed e605602738922 ∧ code e605602738922 = 2804625994474 := by decide
theorem cert_e605602738922 : check e605602738922 [[],[]] .chain = true := by decide
def e605602738974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e605602738974 : Closed e605602738974 ∧ code e605602738974 = 2804625994526 := by decide
theorem cert_e605602738974 : check e605602738974 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602738998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e605602738998 : Closed e605602738998 ∧ code e605602738998 = 2804625994550 := by decide
theorem cert_e605602738998 : check e605602738998 [[],[]] .chain = true := by decide
def e605602739002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e605602739002 : Closed e605602739002 ∧ code e605602739002 = 2804625994554 := by decide
theorem cert_e605602739002 : check e605602739002 [[],[]] .chain = true := by decide
def e605602739098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e605602739098 : Closed e605602739098 ∧ code e605602739098 = 2804625994650 := by decide
theorem cert_e605602739098 : check e605602739098 [[],[]] .chain = true := by decide
def e605602739142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e605602739142 : Closed e605602739142 ∧ code e605602739142 = 2804625994694 := by decide
theorem cert_e605602739142 : check e605602739142 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602740622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e605602740622 : Closed e605602740622 ∧ code e605602740622 = 2804625996174 := by decide
theorem cert_e605602740622 : check e605602740622 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602740678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e605602740678 : Closed e605602740678 ∧ code e605602740678 = 2804625996230 := by decide
theorem cert_e605602740678 : check e605602740678 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602753878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e605602753878 : Closed e605602753878 ∧ code e605602753878 = 2804626009430 := by decide
theorem cert_e605602753878 : check e605602753878 [[],[]] .chain = true := by decide
def e605602753882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e605602753882 : Closed e605602753882 ∧ code e605602753882 = 2804626009434 := by decide
theorem cert_e605602753882 : check e605602753882 [[],[]] .chain = true := by decide
def e605602753898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e605602753898 : Closed e605602753898 ∧ code e605602753898 = 2804626009450 := by decide
theorem cert_e605602753898 : check e605602753898 [[],[]] .chain = true := by decide
def e605602753962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e605602753962 : Closed e605602753962 ∧ code e605602753962 = 2804626009514 := by decide
theorem cert_e605602753962 : check e605602753962 [[],[]] .chain = true := by decide
def e605602754218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e605602754218 : Closed e605602754218 ∧ code e605602754218 = 2804626009770 := by decide
theorem cert_e605602754218 : check e605602754218 [[],[]] .chain = true := by decide
def e605602754646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.var 1))))))
theorem wire_e605602754646 : Closed e605602754646 ∧ code e605602754646 = 2804626010198 := by decide
theorem cert_e605602754646 : check e605602754646 [[],[]] .chain = true := by decide
def e605602754650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))) (.var 0))))))
theorem wire_e605602754650 : Closed e605602754650 ∧ code e605602754650 = 2804626010202 := by decide
theorem cert_e605602754650 : check e605602754650 [[],[]] .chain = true := by decide
def e605602754926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e605602754926 : Closed e605602754926 ∧ code e605602754926 = 2804626010478 := by decide
theorem cert_e605602754926 : check e605602754926 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602754934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e605602754934 : Closed e605602754934 ∧ code e605602754934 = 2804626010486 := by decide
theorem cert_e605602754934 : check e605602754934 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602754998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.var 1))))))
theorem wire_e605602754998 : Closed e605602754998 ∧ code e605602754998 = 2804626010550 := by decide
theorem cert_e605602754998 : check e605602754998 [[],[]] .chain = true := by decide
def e605602755030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.var 1))))))
theorem wire_e605602755030 : Closed e605602755030 ∧ code e605602755030 = 2804626010582 := by decide
theorem cert_e605602755030 : check e605602755030 [[],[]] .chain = true := by decide
def e605602755034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))) (.var 0))))))
theorem wire_e605602755034 : Closed e605602755034 ∧ code e605602755034 = 2804626010586 := by decide
theorem cert_e605602755034 : check e605602755034 [[],[]] .chain = true := by decide
def e605602755414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e605602755414 : Closed e605602755414 ∧ code e605602755414 = 2804626010966 := by decide
theorem cert_e605602755414 : check e605602755414 [[],[]] .chain = true := by decide
def e605602755418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e605602755418 : Closed e605602755418 ∧ code e605602755418 = 2804626010970 := by decide
theorem cert_e605602755418 : check e605602755418 [[],[]] .chain = true := by decide
def e605602755434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e605602755434 : Closed e605602755434 ∧ code e605602755434 = 2804626010986 := by decide
theorem cert_e605602755434 : check e605602755434 [[],[]] .chain = true := by decide
def e605602755498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e605602755498 : Closed e605602755498 ∧ code e605602755498 = 2804626011050 := by decide
theorem cert_e605602755498 : check e605602755498 [[],[]] .chain = true := by decide
def e605602755606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e605602755606 : Closed e605602755606 ∧ code e605602755606 = 2804626011158 := by decide
theorem cert_e605602755606 : check e605602755606 [[],[]] .chain = true := by decide
def e605602755702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.var 1))))))
theorem wire_e605602755702 : Closed e605602755702 ∧ code e605602755702 = 2804626011254 := by decide
theorem cert_e605602755702 : check e605602755702 [[],[]] .chain = true := by decide
def e605602755798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e605602755798 : Closed e605602755798 ∧ code e605602755798 = 2804626011350 := by decide
theorem cert_e605602755798 : check e605602755798 [[],[]] .chain = true := by decide
def e605602755802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e605602755802 : Closed e605602755802 ∧ code e605602755802 = 2804626011354 := by decide
theorem cert_e605602755802 : check e605602755802 [[],[]] .chain = true := by decide
def e605602755818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e605602755818 : Closed e605602755818 ∧ code e605602755818 = 2804626011370 := by decide
theorem cert_e605602755818 : check e605602755818 [[],[]] .chain = true := by decide
def e605602755894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602755894 : Closed e605602755894 ∧ code e605602755894 = 2804626011446 := by decide
theorem cert_e605602755894 : check e605602755894 [[],[]] .chain = true := by decide
def e605602755898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602755898 : Closed e605602755898 ∧ code e605602755898 = 2804626011450 := by decide
theorem cert_e605602755898 : check e605602755898 [[],[]] .chain = true := by decide
def e605602755970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e605602755970 : Closed e605602755970 ∧ code e605602755970 = 2804626011522 := by decide
theorem cert_e605602755970 : check e605602755970 [[],[]] .chain = true := by decide
def e605602755982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 2)))))))
theorem wire_e605602755982 : Closed e605602755982 ∧ code e605602755982 = 2804626011534 := by decide
theorem cert_e605602755982 : check e605602755982 [[],[]] .chain = true := by decide
def e605602755994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602755994 : Closed e605602755994 ∧ code e605602755994 = 2804626011546 := by decide
theorem cert_e605602755994 : check e605602755994 [[],[]] .chain = true := by decide
def e605602756106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e605602756106 : Closed e605602756106 ∧ code e605602756106 = 2804626011658 := by decide
theorem cert_e605602756106 : check e605602756106 [[],[]] .chain = true := by decide
def e605602756142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e605602756142 : Closed e605602756142 ∧ code e605602756142 = 2804626011694 := by decide
theorem cert_e605602756142 : check e605602756142 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602756150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e605602756150 : Closed e605602756150 ∧ code e605602756150 = 2804626011702 := by decide
theorem cert_e605602756150 : check e605602756150 [[],[]] .chain = true := by decide
def e605602756154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e605602756154 : Closed e605602756154 ∧ code e605602756154 = 2804626011706 := by decide
theorem cert_e605602756154 : check e605602756154 [[],[]] .chain = true := by decide
def e605602756202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e605602756202 : Closed e605602756202 ∧ code e605602756202 = 2804626011754 := by decide
theorem cert_e605602756202 : check e605602756202 [[],[]] .chain = true := by decide
def e605602756226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e605602756226 : Closed e605602756226 ∧ code e605602756226 = 2804626011778 := by decide
theorem cert_e605602756226 : check e605602756226 [[],[]] .chain = true := by decide
def e605602756238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e605602756238 : Closed e605602756238 ∧ code e605602756238 = 2804626011790 := by decide
theorem cert_e605602756238 : check e605602756238 [[],[]] .chain = true := by decide
def e605602756250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602756250 : Closed e605602756250 ∧ code e605602756250 = 2804626011802 := by decide
theorem cert_e605602756250 : check e605602756250 [[],[]] .chain = true := by decide
def e605602756294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e605602756294 : Closed e605602756294 ∧ code e605602756294 = 2804626011846 := by decide
theorem cert_e605602756294 : check e605602756294 [[],[]] .chain = true := by decide
def e605602756322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e605602756322 : Closed e605602756322 ∧ code e605602756322 = 2804626011874 := by decide
theorem cert_e605602756322 : check e605602756322 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602756334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2))))))
theorem wire_e605602756334 : Closed e605602756334 ∧ code e605602756334 = 2804626011886 := by decide
theorem cert_e605602756334 : check e605602756334 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602756374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e605602756374 : Closed e605602756374 ∧ code e605602756374 = 2804626011926 := by decide
theorem cert_e605602756374 : check e605602756374 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602756450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e605602756450 : Closed e605602756450 ∧ code e605602756450 = 2804626012002 := by decide
theorem cert_e605602756450 : check e605602756450 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602756462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2))))))
theorem wire_e605602756462 : Closed e605602756462 ∧ code e605602756462 = 2804626012014 := by decide
theorem cert_e605602756462 : check e605602756462 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602756470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1))))))
theorem wire_e605602756470 : Closed e605602756470 ∧ code e605602756470 = 2804626012022 := by decide
theorem cert_e605602756470 : check e605602756470 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602756650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))) (.var 0))))))
theorem wire_e605602756650 : Closed e605602756650 ∧ code e605602756650 = 2804626012202 := by decide
theorem cert_e605602756650 : check e605602756650 [[],[]] .chain = true := by decide
def e605602756782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e605602756782 : Closed e605602756782 ∧ code e605602756782 = 2804626012334 := by decide
theorem cert_e605602756782 : check e605602756782 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602756794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e605602756794 : Closed e605602756794 ∧ code e605602756794 = 2804626012346 := by decide
theorem cert_e605602756794 : check e605602756794 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602756822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.var 1))))))
theorem wire_e605602756822 : Closed e605602756822 ∧ code e605602756822 = 2804626012374 := by decide
theorem cert_e605602756822 : check e605602756822 [[],[]] .chain = true := by decide
def e605602756826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))) (.var 0))))))
theorem wire_e605602756826 : Closed e605602756826 ∧ code e605602756826 = 2804626012378 := by decide
theorem cert_e605602756826 : check e605602756826 [[],[]] .chain = true := by decide
def e605602756842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e605602756842 : Closed e605602756842 ∧ code e605602756842 = 2804626012394 := by decide
theorem cert_e605602756842 : check e605602756842 [[],[]] .chain = true := by decide
def e605602757034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e605602757034 : Closed e605602757034 ∧ code e605602757034 = 2804626012586 := by decide
theorem cert_e605602757034 : check e605602757034 [[],[]] .chain = true := by decide
def e605602757130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e605602757130 : Closed e605602757130 ∧ code e605602757130 = 2804626012682 := by decide
theorem cert_e605602757130 : check e605602757130 [[],[]] .chain = true := by decide
def e605602757166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e605602757166 : Closed e605602757166 ∧ code e605602757166 = 2804626012718 := by decide
theorem cert_e605602757166 : check e605602757166 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602757174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e605602757174 : Closed e605602757174 ∧ code e605602757174 = 2804626012726 := by decide
theorem cert_e605602757174 : check e605602757174 [[],[]] .chain = true := by decide
def e605602757178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e605602757178 : Closed e605602757178 ∧ code e605602757178 = 2804626012730 := by decide
theorem cert_e605602757178 : check e605602757178 [[],[]] .chain = true := by decide
def e605602757226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e605602757226 : Closed e605602757226 ∧ code e605602757226 = 2804626012778 := by decide
theorem cert_e605602757226 : check e605602757226 [[],[]] .chain = true := by decide
def e605602757250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e605602757250 : Closed e605602757250 ∧ code e605602757250 = 2804626012802 := by decide
theorem cert_e605602757250 : check e605602757250 [[],[]] .chain = true := by decide
def e605602757262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e605602757262 : Closed e605602757262 ∧ code e605602757262 = 2804626012814 := by decide
theorem cert_e605602757262 : check e605602757262 [[],[]] .chain = true := by decide
def e605602757274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602757274 : Closed e605602757274 ∧ code e605602757274 = 2804626012826 := by decide
theorem cert_e605602757274 : check e605602757274 [[],[]] .chain = true := by decide
def e605602757318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e605602757318 : Closed e605602757318 ∧ code e605602757318 = 2804626012870 := by decide
theorem cert_e605602757318 : check e605602757318 [[],[]] .chain = true := by decide
def e605602757346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e605602757346 : Closed e605602757346 ∧ code e605602757346 = 2804626012898 := by decide
theorem cert_e605602757346 : check e605602757346 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602757358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e605602757358 : Closed e605602757358 ∧ code e605602757358 = 2804626012910 := by decide
theorem cert_e605602757358 : check e605602757358 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602757402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e605602757402 : Closed e605602757402 ∧ code e605602757402 = 2804626012954 := by decide
theorem cert_e605602757402 : check e605602757402 [[],[]] .chain = true := by decide
def e605602757446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e605602757446 : Closed e605602757446 ∧ code e605602757446 = 2804626012998 := by decide
theorem cert_e605602757446 : check e605602757446 [[],[]] .chain = true := by decide
def e605602757514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e605602757514 : Closed e605602757514 ∧ code e605602757514 = 2804626013066 := by decide
theorem cert_e605602757514 : check e605602757514 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602757538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e605602757538 : Closed e605602757538 ∧ code e605602757538 = 2804626013090 := by decide
theorem cert_e605602757538 : check e605602757538 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602757550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e605602757550 : Closed e605602757550 ∧ code e605602757550 = 2804626013102 := by decide
theorem cert_e605602757550 : check e605602757550 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602757562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e605602757562 : Closed e605602757562 ∧ code e605602757562 = 2804626013114 := by decide
theorem cert_e605602757562 : check e605602757562 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602757718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e605602757718 : Closed e605602757718 ∧ code e605602757718 = 2804626013270 := by decide
theorem cert_e605602757718 : check e605602757718 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602757722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e605602757722 : Closed e605602757722 ∧ code e605602757722 = 2804626013274 := by decide
theorem cert_e605602757722 : check e605602757722 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602757910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e605602757910 : Closed e605602757910 ∧ code e605602757910 = 2804626013462 := by decide
theorem cert_e605602757910 : check e605602757910 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602757986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e605602757986 : Closed e605602757986 ∧ code e605602757986 = 2804626013538 := by decide
theorem cert_e605602757986 : check e605602757986 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602757998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e605602757998 : Closed e605602757998 ∧ code e605602757998 = 2804626013550 := by decide
theorem cert_e605602757998 : check e605602757998 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602758006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e605602758006 : Closed e605602758006 ∧ code e605602758006 = 2804626013558 := by decide
theorem cert_e605602758006 : check e605602758006 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602758026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e605602758026 : Closed e605602758026 ∧ code e605602758026 = 2804626013578 := by decide
theorem cert_e605602758026 : check e605602758026 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602758050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e605602758050 : Closed e605602758050 ∧ code e605602758050 = 2804626013602 := by decide
theorem cert_e605602758050 : check e605602758050 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602758062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e605602758062 : Closed e605602758062 ∧ code e605602758062 = 2804626013614 := by decide
theorem cert_e605602758062 : check e605602758062 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602758074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e605602758074 : Closed e605602758074 ∧ code e605602758074 = 2804626013626 := by decide
theorem cert_e605602758074 : check e605602758074 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602758102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e605602758102 : Closed e605602758102 ∧ code e605602758102 = 2804626013654 := by decide
private def t_e605602758102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1))))))
theorem cert_e605602758102 : ¬ IsSelfInterpreter e605602758102 :=
  wSource (t := t_e605602758102) (replay_sound (ps := []) (t := e605602758102) (by decide)) (by decide)
def e605602758106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e605602758106 : Closed e605602758106 ∧ code e605602758106 = 2804626013658 := by decide
private def t_e605602758106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))))
theorem cert_e605602758106 : ¬ IsSelfInterpreter e605602758106 :=
  wSource (t := t_e605602758106) (replay_sound (ps := []) (t := e605602758106) (by decide)) (by decide)
def e605602758870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 1))))))
theorem wire_e605602758870 : Closed e605602758870 ∧ code e605602758870 = 2804626014422 := by decide
theorem cert_e605602758870 : check e605602758870 [[],[],[.under,.under,.left]] .width = true := by decide
def e605602758966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602758966 : Closed e605602758966 ∧ code e605602758966 = 2804626014518 := by decide
theorem cert_e605602758966 : check e605602758966 [[],[]] .chain = true := by decide
def e605602758970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602758970 : Closed e605602758970 ∧ code e605602758970 = 2804626014522 := by decide
theorem cert_e605602758970 : check e605602758970 [[],[]] .chain = true := by decide
def e605602759150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e605602759150 : Closed e605602759150 ∧ code e605602759150 = 2804626014702 := by decide
theorem cert_e605602759150 : check e605602759150 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602759158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e605602759158 : Closed e605602759158 ∧ code e605602759158 = 2804626014710 := by decide
theorem cert_e605602759158 : check e605602759158 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602759542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e605602759542 : Closed e605602759542 ∧ code e605602759542 = 2804626015094 := by decide
theorem cert_e605602759542 : check e605602759542 [[],[]] .chain = true := by decide
def e605602759606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 1))))))
theorem wire_e605602759606 : Closed e605602759606 ∧ code e605602759606 = 2804626015158 := by decide
theorem cert_e605602759606 : check e605602759606 [[],[]] .chain = true := by decide
def e605602759610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e605602759610 : Closed e605602759610 ∧ code e605602759610 = 2804626015162 := by decide
theorem cert_e605602759610 : check e605602759610 [[],[]] .chain = true := by decide
def e605602759638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e605602759638 : Closed e605602759638 ∧ code e605602759638 = 2804626015190 := by decide
theorem cert_e605602759638 : check e605602759638 [[],[]] .chain = true := by decide
def e605602759642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e605602759642 : Closed e605602759642 ∧ code e605602759642 = 2804626015194 := by decide
theorem cert_e605602759642 : check e605602759642 [[],[]] .chain = true := by decide
def e605602759918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602759918 : Closed e605602759918 ∧ code e605602759918 = 2804626015470 := by decide
theorem cert_e605602759918 : check e605602759918 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602759926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602759926 : Closed e605602759926 ∧ code e605602759926 = 2804626015478 := by decide
theorem cert_e605602759926 : check e605602759926 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602760310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 1)))))))
theorem wire_e605602760310 : Closed e605602760310 ∧ code e605602760310 = 2804626015862 := by decide
theorem cert_e605602760310 : check e605602760310 [[],[]] .chain = true := by decide
def e605602760478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e605602760478 : Closed e605602760478 ∧ code e605602760478 = 2804626016030 := by decide
theorem cert_e605602760478 : check e605602760478 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602760502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602760502 : Closed e605602760502 ∧ code e605602760502 = 2804626016054 := by decide
theorem cert_e605602760502 : check e605602760502 [[],[]] .chain = true := by decide
def e605602760506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602760506 : Closed e605602760506 ∧ code e605602760506 = 2804626016058 := by decide
theorem cert_e605602760506 : check e605602760506 [[],[]] .chain = true := by decide
def e605602760590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e605602760590 : Closed e605602760590 ∧ code e605602760590 = 2804626016142 := by decide
theorem cert_e605602760590 : check e605602760590 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602761558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e605602761558 : Closed e605602761558 ∧ code e605602761558 = 2804626017110 := by decide
theorem cert_e605602761558 : check e605602761558 [[],[]] .chain = true := by decide
def e605602761562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e605602761562 : Closed e605602761562 ∧ code e605602761562 = 2804626017114 := by decide
theorem cert_e605602761562 : check e605602761562 [[],[]] .chain = true := by decide
def e605602761578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e605602761578 : Closed e605602761578 ∧ code e605602761578 = 2804626017130 := by decide
theorem cert_e605602761578 : check e605602761578 [[],[]] .chain = true := by decide
def e605602761642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e605602761642 : Closed e605602761642 ∧ code e605602761642 = 2804626017194 := by decide
theorem cert_e605602761642 : check e605602761642 [[],[]] .chain = true := by decide
def e605602761750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e605602761750 : Closed e605602761750 ∧ code e605602761750 = 2804626017302 := by decide
theorem cert_e605602761750 : check e605602761750 [[],[]] .chain = true := by decide
def e605602761846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.var 1))))))
theorem wire_e605602761846 : Closed e605602761846 ∧ code e605602761846 = 2804626017398 := by decide
theorem cert_e605602761846 : check e605602761846 [[],[]] .chain = true := by decide
def e605602761942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e605602761942 : Closed e605602761942 ∧ code e605602761942 = 2804626017494 := by decide
theorem cert_e605602761942 : check e605602761942 [[],[]] .chain = true := by decide
def e605602761946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e605602761946 : Closed e605602761946 ∧ code e605602761946 = 2804626017498 := by decide
theorem cert_e605602761946 : check e605602761946 [[],[]] .chain = true := by decide
def e605602761962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e605602761962 : Closed e605602761962 ∧ code e605602761962 = 2804626017514 := by decide
theorem cert_e605602761962 : check e605602761962 [[],[]] .chain = true := by decide
def e605602762038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602762038 : Closed e605602762038 ∧ code e605602762038 = 2804626017590 := by decide
theorem cert_e605602762038 : check e605602762038 [[],[]] .chain = true := by decide
def e605602762042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602762042 : Closed e605602762042 ∧ code e605602762042 = 2804626017594 := by decide
theorem cert_e605602762042 : check e605602762042 [[],[]] .chain = true := by decide
def e605602762114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.var 0))))))))
theorem wire_e605602762114 : Closed e605602762114 ∧ code e605602762114 = 2804626017666 := by decide
theorem cert_e605602762114 : check e605602762114 [[],[]] .chain = true := by decide
def e605602762126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e605602762126 : Closed e605602762126 ∧ code e605602762126 = 2804626017678 := by decide
theorem cert_e605602762126 : check e605602762126 [[],[]] .chain = true := by decide
def e605602762138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602762138 : Closed e605602762138 ∧ code e605602762138 = 2804626017690 := by decide
theorem cert_e605602762138 : check e605602762138 [[],[]] .chain = true := by decide
def e605602762250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e605602762250 : Closed e605602762250 ∧ code e605602762250 = 2804626017802 := by decide
theorem cert_e605602762250 : check e605602762250 [[],[]] .chain = true := by decide
def e605602762286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e605602762286 : Closed e605602762286 ∧ code e605602762286 = 2804626017838 := by decide
theorem cert_e605602762286 : check e605602762286 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602762294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.var 1))))))
theorem wire_e605602762294 : Closed e605602762294 ∧ code e605602762294 = 2804626017846 := by decide
theorem cert_e605602762294 : check e605602762294 [[],[]] .chain = true := by decide
def e605602762298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))) (.var 0))))))
theorem wire_e605602762298 : Closed e605602762298 ∧ code e605602762298 = 2804626017850 := by decide
theorem cert_e605602762298 : check e605602762298 [[],[]] .chain = true := by decide
def e605602762346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e605602762346 : Closed e605602762346 ∧ code e605602762346 = 2804626017898 := by decide
theorem cert_e605602762346 : check e605602762346 [[],[]] .chain = true := by decide
def e605602762370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.var 0))))))))
theorem wire_e605602762370 : Closed e605602762370 ∧ code e605602762370 = 2804626017922 := by decide
theorem cert_e605602762370 : check e605602762370 [[],[]] .chain = true := by decide
def e605602762382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e605602762382 : Closed e605602762382 ∧ code e605602762382 = 2804626017934 := by decide
theorem cert_e605602762382 : check e605602762382 [[],[]] .chain = true := by decide
def e605602762394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602762394 : Closed e605602762394 ∧ code e605602762394 = 2804626017946 := by decide
theorem cert_e605602762394 : check e605602762394 [[],[]] .chain = true := by decide
def e605602762438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e605602762438 : Closed e605602762438 ∧ code e605602762438 = 2804626017990 := by decide
theorem cert_e605602762438 : check e605602762438 [[],[]] .chain = true := by decide
def e605602762466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e605602762466 : Closed e605602762466 ∧ code e605602762466 = 2804626018018 := by decide
theorem cert_e605602762466 : check e605602762466 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602762478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e605602762478 : Closed e605602762478 ∧ code e605602762478 = 2804626018030 := by decide
theorem cert_e605602762478 : check e605602762478 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602762518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e605602762518 : Closed e605602762518 ∧ code e605602762518 = 2804626018070 := by decide
theorem cert_e605602762518 : check e605602762518 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602762594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e605602762594 : Closed e605602762594 ∧ code e605602762594 = 2804626018146 := by decide
theorem cert_e605602762594 : check e605602762594 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602762606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e605602762606 : Closed e605602762606 ∧ code e605602762606 = 2804626018158 := by decide
theorem cert_e605602762606 : check e605602762606 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602762614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e605602762614 : Closed e605602762614 ∧ code e605602762614 = 2804626018166 := by decide
theorem cert_e605602762614 : check e605602762614 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602762990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e605602762990 : Closed e605602762990 ∧ code e605602762990 = 2804626018542 := by decide
theorem cert_e605602762990 : check e605602762990 [[],[]] .chain = true := by decide
def e605602762998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e605602762998 : Closed e605602762998 ∧ code e605602762998 = 2804626018550 := by decide
theorem cert_e605602762998 : check e605602762998 [[],[]] .chain = true := by decide
def e605602763478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e605602763478 : Closed e605602763478 ∧ code e605602763478 = 2804626019030 := by decide
theorem cert_e605602763478 : check e605602763478 [[],[]] .chain = true := by decide
def e605602763482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e605602763482 : Closed e605602763482 ∧ code e605602763482 = 2804626019034 := by decide
theorem cert_e605602763482 : check e605602763482 [[],[]] .chain = true := by decide
def e605602763498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e605602763498 : Closed e605602763498 ∧ code e605602763498 = 2804626019050 := by decide
theorem cert_e605602763498 : check e605602763498 [[],[]] .chain = true := by decide
def e605602763574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e605602763574 : Closed e605602763574 ∧ code e605602763574 = 2804626019126 := by decide
theorem cert_e605602763574 : check e605602763574 [[],[]] .chain = true := by decide
def e605602763578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e605602763578 : Closed e605602763578 ∧ code e605602763578 = 2804626019130 := by decide
theorem cert_e605602763578 : check e605602763578 [[],[]] .chain = true := by decide
def e605602763650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e605602763650 : Closed e605602763650 ∧ code e605602763650 = 2804626019202 := by decide
theorem cert_e605602763650 : check e605602763650 [[],[]] .chain = true := by decide
def e605602763662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e605602763662 : Closed e605602763662 ∧ code e605602763662 = 2804626019214 := by decide
theorem cert_e605602763662 : check e605602763662 [[],[]] .chain = true := by decide
def e605602763674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e605602763674 : Closed e605602763674 ∧ code e605602763674 = 2804626019226 := by decide
theorem cert_e605602763674 : check e605602763674 [[],[]] .chain = true := by decide
def e605602764826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605602764826 : Closed e605602764826 ∧ code e605602764826 = 2804626020378 := by decide
theorem cert_e605602764826 : check e605602764826 [[],[],[.under,.under,.left]] .width = true := by decide
def e605602764862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e605602764862 : Closed e605602764862 ∧ code e605602764862 = 2804626020414 := by decide
theorem cert_e605602764862 : check e605602764862 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602764910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e605602764910 : Closed e605602764910 ∧ code e605602764910 = 2804626020462 := by decide
theorem cert_e605602764910 : check e605602764910 [[],[]] .chain = true := by decide
def e605602764918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e605602764918 : Closed e605602764918 ∧ code e605602764918 = 2804626020470 := by decide
theorem cert_e605602764918 : check e605602764918 [[],[]] .chain = true := by decide
def e605602764922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e605602764922 : Closed e605602764922 ∧ code e605602764922 = 2804626020474 := by decide
theorem cert_e605602764922 : check e605602764922 [[],[]] .chain = true := by decide
def e605602765162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e605602765162 : Closed e605602765162 ∧ code e605602765162 = 2804626020714 := by decide
theorem cert_e605602765162 : check e605602765162 [[],[]] .chain = true := by decide
def e605602765186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e605602765186 : Closed e605602765186 ∧ code e605602765186 = 2804626020738 := by decide
theorem cert_e605602765186 : check e605602765186 [[],[]] .chain = true := by decide
def e605602765198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e605602765198 : Closed e605602765198 ∧ code e605602765198 = 2804626020750 := by decide
theorem cert_e605602765198 : check e605602765198 [[],[]] .chain = true := by decide
def e605602765210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e605602765210 : Closed e605602765210 ∧ code e605602765210 = 2804626020762 := by decide
theorem cert_e605602765210 : check e605602765210 [[],[]] .chain = true := by decide
def e605602765254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e605602765254 : Closed e605602765254 ∧ code e605602765254 = 2804626020806 := by decide
theorem cert_e605602765254 : check e605602765254 [[],[]] .chain = true := by decide
def e605602765282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e605602765282 : Closed e605602765282 ∧ code e605602765282 = 2804626020834 := by decide
theorem cert_e605602765282 : check e605602765282 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602765294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e605602765294 : Closed e605602765294 ∧ code e605602765294 = 2804626020846 := by decide
theorem cert_e605602765294 : check e605602765294 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602765854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e605602765854 : Closed e605602765854 ∧ code e605602765854 = 2804626021406 := by decide
theorem cert_e605602765854 : check e605602765854 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602766050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e605602766050 : Closed e605602766050 ∧ code e605602766050 = 2804626021602 := by decide
theorem cert_e605602766050 : check e605602766050 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602766062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602766062 : Closed e605602766062 ∧ code e605602766062 = 2804626021614 := by decide
theorem cert_e605602766062 : check e605602766062 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602766070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602766070 : Closed e605602766070 ∧ code e605602766070 = 2804626021622 := by decide
theorem cert_e605602766070 : check e605602766070 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602766954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0))))))
theorem wire_e605602766954 : Closed e605602766954 ∧ code e605602766954 = 2804626022506 := by decide
theorem cert_e605602766954 : check e605602766954 [[],[],[.under,.under,.left]] .width = true := by decide
def e605602767002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602767002 : Closed e605602767002 ∧ code e605602767002 = 2804626022554 := by decide
theorem cert_e605602767002 : check e605602767002 [[],[]] .chain = true := by decide
def e605602767086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e605602767086 : Closed e605602767086 ∧ code e605602767086 = 2804626022638 := by decide
theorem cert_e605602767086 : check e605602767086 [[],[],[.under,.under,.left]] .chain = true := by decide
end Blc.Floor41
