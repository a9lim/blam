import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e604785130106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e604785130106 : Closed e604785130106 ∧ code e604785130106 = 2803808385658 := by decide
theorem cert_e604785130106 : check e604785130106 [[],[]] .smaller = true := by decide
def e604785130394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e604785130394 : Closed e604785130394 ∧ code e604785130394 = 2803808385946 := by decide
theorem cert_e604785130394 : check e604785130394 [[],[]] .smaller = true := by decide
def e604785130710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e604785130710 : Closed e604785130710 ∧ code e604785130710 = 2803808386262 := by decide
theorem cert_e604785130710 : check e604785130710 [[],[]] .smaller = true := by decide
def e604785130714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e604785130714 : Closed e604785130714 ∧ code e604785130714 = 2803808386266 := by decide
theorem cert_e604785130714 : check e604785130714 [[],[]] .smaller = true := by decide
def e604785130730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e604785130730 : Closed e604785130730 ∧ code e604785130730 = 2803808386282 := by decide
theorem cert_e604785130730 : check e604785130730 [[],[]] .smaller = true := by decide
def e604785130806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e604785130806 : Closed e604785130806 ∧ code e604785130806 = 2803808386358 := by decide
theorem cert_e604785130806 : check e604785130806 [[],[]] .smaller = true := by decide
def e604785130810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e604785130810 : Closed e604785130810 ∧ code e604785130810 = 2803808386362 := by decide
theorem cert_e604785130810 : check e604785130810 [[],[]] .smaller = true := by decide
def e604785130906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e604785130906 : Closed e604785130906 ∧ code e604785130906 = 2803808386458 := by decide
theorem cert_e604785130906 : check e604785130906 [[],[]] .smaller = true := by decide
def e604785134446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e604785134446 : Closed e604785134446 ∧ code e604785134446 = 2803808389998 := by decide
theorem cert_e604785134446 : check e604785134446 [[],[]] .smaller = true := by decide
def e604785134454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e604785134454 : Closed e604785134454 ∧ code e604785134454 = 2803808390006 := by decide
theorem cert_e604785134454 : check e604785134454 [[],[]] .smaller = true := by decide
def e604785134510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e604785134510 : Closed e604785134510 ∧ code e604785134510 = 2803808390062 := by decide
theorem cert_e604785134510 : check e604785134510 [[],[]] .smaller = true := by decide
def e604785134522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e604785134522 : Closed e604785134522 ∧ code e604785134522 = 2803808390074 := by decide
theorem cert_e604785134522 : check e604785134522 [[],[]] .smaller = true := by decide
def e604785134550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e604785134550 : Closed e604785134550 ∧ code e604785134550 = 2803808390102 := by decide
theorem cert_e604785134550 : check e604785134550 [[],[]] .smaller = true := by decide
def e604785134554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e604785134554 : Closed e604785134554 ∧ code e604785134554 = 2803808390106 := by decide
theorem cert_e604785134554 : check e604785134554 [[],[]] .smaller = true := by decide
def e604785134830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e604785134830 : Closed e604785134830 ∧ code e604785134830 = 2803808390382 := by decide
theorem cert_e604785134830 : check e604785134830 [[],[]] .smaller = true := by decide
def e604785134838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e604785134838 : Closed e604785134838 ∧ code e604785134838 = 2803808390390 := by decide
theorem cert_e604785134838 : check e604785134838 [[],[]] .smaller = true := by decide
def e604785135214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e604785135214 : Closed e604785135214 ∧ code e604785135214 = 2803808390766 := by decide
theorem cert_e604785135214 : check e604785135214 [[],[]] .smaller = true := by decide
def e604785135226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e604785135226 : Closed e604785135226 ∧ code e604785135226 = 2803808390778 := by decide
theorem cert_e604785135226 : check e604785135226 [[],[]] .smaller = true := by decide
def e604785135414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e604785135414 : Closed e604785135414 ∧ code e604785135414 = 2803808390966 := by decide
theorem cert_e604785135414 : check e604785135414 [[],[]] .smaller = true := by decide
def e604785135418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e604785135418 : Closed e604785135418 ∧ code e604785135418 = 2803808390970 := by decide
theorem cert_e604785135418 : check e604785135418 [[],[]] .smaller = true := by decide
def e604785141166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e604785141166 : Closed e604785141166 ∧ code e604785141166 = 2803808396718 := by decide
theorem cert_e604785141166 : check e604785141166 [[],[]] .smaller = true := by decide
def e604785141178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e604785141178 : Closed e604785141178 ∧ code e604785141178 = 2803808396730 := by decide
theorem cert_e604785141178 : check e604785141178 [[],[]] .smaller = true := by decide
def e604785141226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e604785141226 : Closed e604785141226 ∧ code e604785141226 = 2803808396778 := by decide
theorem cert_e604785141226 : check e604785141226 [[],[]] .smaller = true := by decide
def e604785141358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e604785141358 : Closed e604785141358 ∧ code e604785141358 = 2803808396910 := by decide
theorem cert_e604785141358 : check e604785141358 [[],[]] .smaller = true := by decide
def e604785141370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e604785141370 : Closed e604785141370 ∧ code e604785141370 = 2803808396922 := by decide
theorem cert_e604785141370 : check e604785141370 [[],[]] .smaller = true := by decide
def e604785141658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e604785141658 : Closed e604785141658 ∧ code e604785141658 = 2803808397210 := by decide
theorem cert_e604785141658 : check e604785141658 [[],[]] .smaller = true := by decide
def e604785144534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e604785144534 : Closed e604785144534 ∧ code e604785144534 = 2803808400086 := by decide
theorem cert_e604785144534 : check e604785144534 [[],[]] .smaller = true := by decide
def e604785144538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e604785144538 : Closed e604785144538 ∧ code e604785144538 = 2803808400090 := by decide
theorem cert_e604785144538 : check e604785144538 [[],[]] .smaller = true := by decide
def e604785144554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e604785144554 : Closed e604785144554 ∧ code e604785144554 = 2803808400106 := by decide
theorem cert_e604785144554 : check e604785144554 [[],[]] .smaller = true := by decide
def e604785144630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e604785144630 : Closed e604785144630 ∧ code e604785144630 = 2803808400182 := by decide
theorem cert_e604785144630 : check e604785144630 [[],[]] .smaller = true := by decide
def e604785144634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e604785144634 : Closed e604785144634 ∧ code e604785144634 = 2803808400186 := by decide
theorem cert_e604785144634 : check e604785144634 [[],[]] .smaller = true := by decide
def e604785144730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e604785144730 : Closed e604785144730 ∧ code e604785144730 = 2803808400282 := by decide
theorem cert_e604785144730 : check e604785144730 [[],[]] .smaller = true := by decide
def e604785259998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e604785259998 : Closed e604785259998 ∧ code e604785259998 = 2803808515550 := by decide
theorem cert_e604785259998 : check e604785259998 [[],[]] .three = true := by decide
def e604785260014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e604785260014 : Closed e604785260014 ∧ code e604785260014 = 2803808515566 := by decide
theorem cert_e604785260014 : check e604785260014 [[],[]] .three = true := by decide
def e604785260254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e604785260254 : Closed e604785260254 ∧ code e604785260254 = 2803808515806 := by decide
theorem cert_e604785260254 : check e604785260254 [[],[]] .three = true := by decide
def e604785260270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e604785260270 : Closed e604785260270 ∧ code e604785260270 = 2803808515822 := by decide
theorem cert_e604785260270 : check e604785260270 [[],[]] .smaller = true := by decide
def e604785260278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e604785260278 : Closed e604785260278 ∧ code e604785260278 = 2803808515830 := by decide
theorem cert_e604785260278 : check e604785260278 [[],[]] .three = true := by decide
def e604785260382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e604785260382 : Closed e604785260382 ∧ code e604785260382 = 2803808515934 := by decide
theorem cert_e604785260382 : check e604785260382 [[],[]] .three = true := by decide
def e604785260398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e604785260398 : Closed e604785260398 ∧ code e604785260398 = 2803808515950 := by decide
theorem cert_e604785260398 : check e604785260398 [[],[]] .smaller = true := by decide
def e604785260406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e604785260406 : Closed e604785260406 ∧ code e604785260406 = 2803808515958 := by decide
theorem cert_e604785260406 : check e604785260406 [[],[]] .smaller = true := by decide
def e604785260410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e604785260410 : Closed e604785260410 ∧ code e604785260410 = 2803808515962 := by decide
theorem cert_e604785260410 : check e604785260410 [[],[]] .three = true := by decide
def e604785260462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e604785260462 : Closed e604785260462 ∧ code e604785260462 = 2803808516014 := by decide
theorem cert_e604785260462 : check e604785260462 [[],[]] .three = true := by decide
def e604785260470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e604785260470 : Closed e604785260470 ∧ code e604785260470 = 2803808516022 := by decide
theorem cert_e604785260470 : check e604785260470 [[],[]] .three = true := by decide
def e604785260474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e604785260474 : Closed e604785260474 ∧ code e604785260474 = 2803808516026 := by decide
theorem cert_e604785260474 : check e604785260474 [[],[]] .three = true := by decide
def e604785261278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e604785261278 : Closed e604785261278 ∧ code e604785261278 = 2803808516830 := by decide
theorem cert_e604785261278 : check e604785261278 [[],[]] .three = true := by decide
def e604785261294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e604785261294 : Closed e604785261294 ∧ code e604785261294 = 2803808516846 := by decide
theorem cert_e604785261294 : check e604785261294 [[],[]] .smaller = true := by decide
def e604785261302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e604785261302 : Closed e604785261302 ∧ code e604785261302 = 2803808516854 := by decide
theorem cert_e604785261302 : check e604785261302 [[],[]] .three = true := by decide
def e604785261406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e604785261406 : Closed e604785261406 ∧ code e604785261406 = 2803808516958 := by decide
theorem cert_e604785261406 : check e604785261406 [[],[]] .three = true := by decide
def e604785261434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e604785261434 : Closed e604785261434 ∧ code e604785261434 = 2803808516986 := by decide
theorem cert_e604785261434 : check e604785261434 [[],[]] .three = true := by decide
def e604785261486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e604785261486 : Closed e604785261486 ∧ code e604785261486 = 2803808517038 := by decide
theorem cert_e604785261486 : check e604785261486 [[],[]] .smaller = true := by decide
def e604785261498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e604785261498 : Closed e604785261498 ∧ code e604785261498 = 2803808517050 := by decide
theorem cert_e604785261498 : check e604785261498 [[],[]] .smaller = true := by decide
def e604785261526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e604785261526 : Closed e604785261526 ∧ code e604785261526 = 2803808517078 := by decide
theorem cert_e604785261526 : check e604785261526 [[],[]] .three = true := by decide
def e604785261530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e604785261530 : Closed e604785261530 ∧ code e604785261530 = 2803808517082 := by decide
theorem cert_e604785261530 : check e604785261530 [[],[]] .three = true := by decide
def e604785261918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e604785261918 : Closed e604785261918 ∧ code e604785261918 = 2803808517470 := by decide
theorem cert_e604785261918 : check e604785261918 [[],[]] .three = true := by decide
def e604785261934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e604785261934 : Closed e604785261934 ∧ code e604785261934 = 2803808517486 := by decide
theorem cert_e604785261934 : check e604785261934 [[],[]] .smaller = true := by decide
def e604785261942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e604785261942 : Closed e604785261942 ∧ code e604785261942 = 2803808517494 := by decide
theorem cert_e604785261942 : check e604785261942 [[],[]] .smaller = true := by decide
def e604785261946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e604785261946 : Closed e604785261946 ∧ code e604785261946 = 2803808517498 := by decide
theorem cert_e604785261946 : check e604785261946 [[],[]] .three = true := by decide
def e604785261998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e604785261998 : Closed e604785261998 ∧ code e604785261998 = 2803808517550 := by decide
theorem cert_e604785261998 : check e604785261998 [[],[]] .smaller = true := by decide
def e604785262010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e604785262010 : Closed e604785262010 ∧ code e604785262010 = 2803808517562 := by decide
theorem cert_e604785262010 : check e604785262010 [[],[]] .smaller = true := by decide
def e604785262038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e604785262038 : Closed e604785262038 ∧ code e604785262038 = 2803808517590 := by decide
theorem cert_e604785262038 : check e604785262038 [[],[]] .smaller = true := by decide
def e604785262042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e604785262042 : Closed e604785262042 ∧ code e604785262042 = 2803808517594 := by decide
theorem cert_e604785262042 : check e604785262042 [[],[]] .smaller = true := by decide
def e604785262058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e604785262058 : Closed e604785262058 ∧ code e604785262058 = 2803808517610 := by decide
theorem cert_e604785262058 : check e604785262058 [[],[]] .three = true := by decide
def e604785262254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e604785262254 : Closed e604785262254 ∧ code e604785262254 = 2803808517806 := by decide
theorem cert_e604785262254 : check e604785262254 [[],[]] .three = true := by decide
def e604785262262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e604785262262 : Closed e604785262262 ∧ code e604785262262 = 2803808517814 := by decide
theorem cert_e604785262262 : check e604785262262 [[],[]] .three = true := by decide
def e604785262266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e604785262266 : Closed e604785262266 ∧ code e604785262266 = 2803808517818 := by decide
theorem cert_e604785262266 : check e604785262266 [[],[]] .three = true := by decide
def e604785262294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e604785262294 : Closed e604785262294 ∧ code e604785262294 = 2803808517846 := by decide
theorem cert_e604785262294 : check e604785262294 [[],[]] .three = true := by decide
def e604785262298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e604785262298 : Closed e604785262298 ∧ code e604785262298 = 2803808517850 := by decide
theorem cert_e604785262298 : check e604785262298 [[],[]] .three = true := by decide
def e604785262314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e604785262314 : Closed e604785262314 ∧ code e604785262314 = 2803808517866 := by decide
theorem cert_e604785262314 : check e604785262314 [[],[]] .three = true := by decide
def e604785266142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e604785266142 : Closed e604785266142 ∧ code e604785266142 = 2803808521694 := by decide
theorem cert_e604785266142 : check e604785266142 [[],[]] .three = true := by decide
def e604785266158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e604785266158 : Closed e604785266158 ∧ code e604785266158 = 2803808521710 := by decide
theorem cert_e604785266158 : check e604785266158 [[],[]] .three = true := by decide
def e604785266398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e604785266398 : Closed e604785266398 ∧ code e604785266398 = 2803808521950 := by decide
theorem cert_e604785266398 : check e604785266398 [[],[]] .three = true := by decide
def e604785266414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e604785266414 : Closed e604785266414 ∧ code e604785266414 = 2803808521966 := by decide
theorem cert_e604785266414 : check e604785266414 [[],[]] .smaller = true := by decide
def e604785266422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e604785266422 : Closed e604785266422 ∧ code e604785266422 = 2803808521974 := by decide
theorem cert_e604785266422 : check e604785266422 [[],[]] .three = true := by decide
def e604785266526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e604785266526 : Closed e604785266526 ∧ code e604785266526 = 2803808522078 := by decide
theorem cert_e604785266526 : check e604785266526 [[],[]] .three = true := by decide
def e604785266542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e604785266542 : Closed e604785266542 ∧ code e604785266542 = 2803808522094 := by decide
theorem cert_e604785266542 : check e604785266542 [[],[]] .smaller = true := by decide
def e604785266550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e604785266550 : Closed e604785266550 ∧ code e604785266550 = 2803808522102 := by decide
theorem cert_e604785266550 : check e604785266550 [[],[]] .smaller = true := by decide
def e604785266554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e604785266554 : Closed e604785266554 ∧ code e604785266554 = 2803808522106 := by decide
theorem cert_e604785266554 : check e604785266554 [[],[]] .three = true := by decide
def e604785266606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e604785266606 : Closed e604785266606 ∧ code e604785266606 = 2803808522158 := by decide
theorem cert_e604785266606 : check e604785266606 [[],[]] .three = true := by decide
def e604785266614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e604785266614 : Closed e604785266614 ∧ code e604785266614 = 2803808522166 := by decide
theorem cert_e604785266614 : check e604785266614 [[],[]] .three = true := by decide
def e604785266618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e604785266618 : Closed e604785266618 ∧ code e604785266618 = 2803808522170 := by decide
theorem cert_e604785266618 : check e604785266618 [[],[]] .three = true := by decide
def e604785267678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e604785267678 : Closed e604785267678 ∧ code e604785267678 = 2803808523230 := by decide
theorem cert_e604785267678 : check e604785267678 [[],[]] .three = true := by decide
def e604785267694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e604785267694 : Closed e604785267694 ∧ code e604785267694 = 2803808523246 := by decide
theorem cert_e604785267694 : check e604785267694 [[],[]] .three = true := by decide
def e604785269214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e604785269214 : Closed e604785269214 ∧ code e604785269214 = 2803808524766 := by decide
theorem cert_e604785269214 : check e604785269214 [[],[]] .three = true := by decide
def e604785269230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e604785269230 : Closed e604785269230 ∧ code e604785269230 = 2803808524782 := by decide
theorem cert_e604785269230 : check e604785269230 [[],[]] .smaller = true := by decide
def e604785269238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e604785269238 : Closed e604785269238 ∧ code e604785269238 = 2803808524790 := by decide
theorem cert_e604785269238 : check e604785269238 [[],[]] .three = true := by decide
def e604785269982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e604785269982 : Closed e604785269982 ∧ code e604785269982 = 2803808525534 := by decide
theorem cert_e604785269982 : check e604785269982 [[],[]] .three = true := by decide
def e604785269998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e604785269998 : Closed e604785269998 ∧ code e604785269998 = 2803808525550 := by decide
theorem cert_e604785269998 : check e604785269998 [[],[]] .smaller = true := by decide
def e604785270006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e604785270006 : Closed e604785270006 ∧ code e604785270006 = 2803808525558 := by decide
theorem cert_e604785270006 : check e604785270006 [[],[]] .smaller = true := by decide
def e604785270010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e604785270010 : Closed e604785270010 ∧ code e604785270010 = 2803808525562 := by decide
theorem cert_e604785270010 : check e604785270010 [[],[]] .three = true := by decide
def e604785270382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e604785270382 : Closed e604785270382 ∧ code e604785270382 = 2803808525934 := by decide
theorem cert_e604785270382 : check e604785270382 [[],[]] .three = true := by decide
def e604785270390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e604785270390 : Closed e604785270390 ∧ code e604785270390 = 2803808525942 := by decide
theorem cert_e604785270390 : check e604785270390 [[],[]] .three = true := by decide
def e604785270394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e604785270394 : Closed e604785270394 ∧ code e604785270394 = 2803808525946 := by decide
theorem cert_e604785270394 : check e604785270394 [[],[]] .three = true := by decide
def e604785272542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e604785272542 : Closed e604785272542 ∧ code e604785272542 = 2803808528094 := by decide
theorem cert_e604785272542 : check e604785272542 [[],[]] .three = true := by decide
def e604785272558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e604785272558 : Closed e604785272558 ∧ code e604785272558 = 2803808528110 := by decide
theorem cert_e604785272558 : check e604785272558 [[],[]] .smaller = true := by decide
def e604785272566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e604785272566 : Closed e604785272566 ∧ code e604785272566 = 2803808528118 := by decide
theorem cert_e604785272566 : check e604785272566 [[],[]] .three = true := by decide
def e604785272670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e604785272670 : Closed e604785272670 ∧ code e604785272670 = 2803808528222 := by decide
theorem cert_e604785272670 : check e604785272670 [[],[]] .three = true := by decide
def e604785272698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e604785272698 : Closed e604785272698 ∧ code e604785272698 = 2803808528250 := by decide
theorem cert_e604785272698 : check e604785272698 [[],[]] .three = true := by decide
def e604785272750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e604785272750 : Closed e604785272750 ∧ code e604785272750 = 2803808528302 := by decide
theorem cert_e604785272750 : check e604785272750 [[],[]] .smaller = true := by decide
def e604785272762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e604785272762 : Closed e604785272762 ∧ code e604785272762 = 2803808528314 := by decide
theorem cert_e604785272762 : check e604785272762 [[],[]] .smaller = true := by decide
def e604785272790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e604785272790 : Closed e604785272790 ∧ code e604785272790 = 2803808528342 := by decide
theorem cert_e604785272790 : check e604785272790 [[],[]] .three = true := by decide
def e604785272794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e604785272794 : Closed e604785272794 ∧ code e604785272794 = 2803808528346 := by decide
theorem cert_e604785272794 : check e604785272794 [[],[]] .three = true := by decide
def e604785273310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e604785273310 : Closed e604785273310 ∧ code e604785273310 = 2803808528862 := by decide
theorem cert_e604785273310 : check e604785273310 [[],[]] .three = true := by decide
def e604785273326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e604785273326 : Closed e604785273326 ∧ code e604785273326 = 2803808528878 := by decide
theorem cert_e604785273326 : check e604785273326 [[],[]] .smaller = true := by decide
def e604785273334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e604785273334 : Closed e604785273334 ∧ code e604785273334 = 2803808528886 := by decide
theorem cert_e604785273334 : check e604785273334 [[],[]] .three = true := by decide
def e604785274078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e604785274078 : Closed e604785274078 ∧ code e604785274078 = 2803808529630 := by decide
theorem cert_e604785274078 : check e604785274078 [[],[]] .three = true := by decide
def e604785274106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e604785274106 : Closed e604785274106 ∧ code e604785274106 = 2803808529658 := by decide
theorem cert_e604785274106 : check e604785274106 [[],[]] .three = true := by decide
def e604785274478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e604785274478 : Closed e604785274478 ∧ code e604785274478 = 2803808530030 := by decide
theorem cert_e604785274478 : check e604785274478 [[],[]] .smaller = true := by decide
def e604785274490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e604785274490 : Closed e604785274490 ∧ code e604785274490 = 2803808530042 := by decide
theorem cert_e604785274490 : check e604785274490 [[],[]] .smaller = true := by decide
def e604785274678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e604785274678 : Closed e604785274678 ∧ code e604785274678 = 2803808530230 := by decide
theorem cert_e604785274678 : check e604785274678 [[],[]] .three = true := by decide
def e604785274682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e604785274682 : Closed e604785274682 ∧ code e604785274682 = 2803808530234 := by decide
theorem cert_e604785274682 : check e604785274682 [[],[]] .three = true := by decide
def e604785275742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e604785275742 : Closed e604785275742 ∧ code e604785275742 = 2803808531294 := by decide
theorem cert_e604785275742 : check e604785275742 [[],[]] .three = true := by decide
def e604785275758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e604785275758 : Closed e604785275758 ∧ code e604785275758 = 2803808531310 := by decide
theorem cert_e604785275758 : check e604785275758 [[],[]] .smaller = true := by decide
def e604785275766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e604785275766 : Closed e604785275766 ∧ code e604785275766 = 2803808531318 := by decide
theorem cert_e604785275766 : check e604785275766 [[],[]] .smaller = true := by decide
def e604785275770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e604785275770 : Closed e604785275770 ∧ code e604785275770 = 2803808531322 := by decide
theorem cert_e604785275770 : check e604785275770 [[],[]] .three = true := by decide
def e604785275822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e604785275822 : Closed e604785275822 ∧ code e604785275822 = 2803808531374 := by decide
theorem cert_e604785275822 : check e604785275822 [[],[]] .smaller = true := by decide
def e604785275834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e604785275834 : Closed e604785275834 ∧ code e604785275834 = 2803808531386 := by decide
theorem cert_e604785275834 : check e604785275834 [[],[]] .smaller = true := by decide
def e604785275862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e604785275862 : Closed e604785275862 ∧ code e604785275862 = 2803808531414 := by decide
theorem cert_e604785275862 : check e604785275862 [[],[]] .smaller = true := by decide
def e604785275866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e604785275866 : Closed e604785275866 ∧ code e604785275866 = 2803808531418 := by decide
theorem cert_e604785275866 : check e604785275866 [[],[]] .smaller = true := by decide
def e604785275882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e604785275882 : Closed e604785275882 ∧ code e604785275882 = 2803808531434 := by decide
theorem cert_e604785275882 : check e604785275882 [[],[]] .three = true := by decide
def e604785276126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e604785276126 : Closed e604785276126 ∧ code e604785276126 = 2803808531678 := by decide
theorem cert_e604785276126 : check e604785276126 [[],[]] .three = true := by decide
def e604785276142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e604785276142 : Closed e604785276142 ∧ code e604785276142 = 2803808531694 := by decide
theorem cert_e604785276142 : check e604785276142 [[],[]] .smaller = true := by decide
def e604785276150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e604785276150 : Closed e604785276150 ∧ code e604785276150 = 2803808531702 := by decide
theorem cert_e604785276150 : check e604785276150 [[],[]] .smaller = true := by decide
def e604785276154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e604785276154 : Closed e604785276154 ∧ code e604785276154 = 2803808531706 := by decide
theorem cert_e604785276154 : check e604785276154 [[],[]] .three = true := by decide
def e604785276526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e604785276526 : Closed e604785276526 ∧ code e604785276526 = 2803808532078 := by decide
theorem cert_e604785276526 : check e604785276526 [[],[]] .smaller = true := by decide
def e604785276538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e604785276538 : Closed e604785276538 ∧ code e604785276538 = 2803808532090 := by decide
theorem cert_e604785276538 : check e604785276538 [[],[]] .smaller = true := by decide
def e604785276726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e604785276726 : Closed e604785276726 ∧ code e604785276726 = 2803808532278 := by decide
theorem cert_e604785276726 : check e604785276726 [[],[]] .smaller = true := by decide
def e604785276730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e604785276730 : Closed e604785276730 ∧ code e604785276730 = 2803808532282 := by decide
theorem cert_e604785276730 : check e604785276730 [[],[]] .smaller = true := by decide
def e604785276826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e604785276826 : Closed e604785276826 ∧ code e604785276826 = 2803808532378 := by decide
theorem cert_e604785276826 : check e604785276826 [[],[]] .three = true := by decide
def e604785277358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e604785277358 : Closed e604785277358 ∧ code e604785277358 = 2803808532910 := by decide
theorem cert_e604785277358 : check e604785277358 [[],[]] .three = true := by decide
def e604785277366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e604785277366 : Closed e604785277366 ∧ code e604785277366 = 2803808532918 := by decide
theorem cert_e604785277366 : check e604785277366 [[],[]] .three = true := by decide
def e604785277370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e604785277370 : Closed e604785277370 ∧ code e604785277370 = 2803808532922 := by decide
theorem cert_e604785277370 : check e604785277370 [[],[]] .three = true := by decide
def e604785277398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e604785277398 : Closed e604785277398 ∧ code e604785277398 = 2803808532950 := by decide
theorem cert_e604785277398 : check e604785277398 [[],[]] .three = true := by decide
def e604785277402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e604785277402 : Closed e604785277402 ∧ code e604785277402 = 2803808532954 := by decide
theorem cert_e604785277402 : check e604785277402 [[],[]] .three = true := by decide
def e604785277418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e604785277418 : Closed e604785277418 ∧ code e604785277418 = 2803808532970 := by decide
theorem cert_e604785277418 : check e604785277418 [[],[]] .three = true := by decide
def e604785277550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e604785277550 : Closed e604785277550 ∧ code e604785277550 = 2803808533102 := by decide
theorem cert_e604785277550 : check e604785277550 [[],[]] .three = true := by decide
def e604785277558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e604785277558 : Closed e604785277558 ∧ code e604785277558 = 2803808533110 := by decide
theorem cert_e604785277558 : check e604785277558 [[],[]] .three = true := by decide
def e604785277562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e604785277562 : Closed e604785277562 ∧ code e604785277562 = 2803808533114 := by decide
theorem cert_e604785277562 : check e604785277562 [[],[]] .three = true := by decide
def e604785277750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e604785277750 : Closed e604785277750 ∧ code e604785277750 = 2803808533302 := by decide
theorem cert_e604785277750 : check e604785277750 [[],[]] .three = true := by decide
def e604785277754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e604785277754 : Closed e604785277754 ∧ code e604785277754 = 2803808533306 := by decide
theorem cert_e604785277754 : check e604785277754 [[],[]] .three = true := by decide
def e604785277850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e604785277850 : Closed e604785277850 ∧ code e604785277850 = 2803808533402 := by decide
theorem cert_e604785277850 : check e604785277850 [[],[]] .three = true := by decide
def e604785281902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e604785281902 : Closed e604785281902 ∧ code e604785281902 = 2803808537454 := by decide
theorem cert_e604785281902 : check e604785281902 [[],[]] .smaller = true := by decide
def e604785281910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e604785281910 : Closed e604785281910 ∧ code e604785281910 = 2803808537462 := by decide
theorem cert_e604785281910 : check e604785281910 [[],[]] .smaller = true := by decide
def e604785281966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e604785281966 : Closed e604785281966 ∧ code e604785281966 = 2803808537518 := by decide
theorem cert_e604785281966 : check e604785281966 [[],[]] .smaller = true := by decide
def e604785281978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e604785281978 : Closed e604785281978 ∧ code e604785281978 = 2803808537530 := by decide
theorem cert_e604785281978 : check e604785281978 [[],[]] .smaller = true := by decide
def e604785282006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e604785282006 : Closed e604785282006 ∧ code e604785282006 = 2803808537558 := by decide
theorem cert_e604785282006 : check e604785282006 [[],[]] .smaller = true := by decide
def e604785282010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e604785282010 : Closed e604785282010 ∧ code e604785282010 = 2803808537562 := by decide
theorem cert_e604785282010 : check e604785282010 [[],[]] .smaller = true := by decide
def e604785282286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e604785282286 : Closed e604785282286 ∧ code e604785282286 = 2803808537838 := by decide
theorem cert_e604785282286 : check e604785282286 [[],[]] .smaller = true := by decide
def e604785282294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e604785282294 : Closed e604785282294 ∧ code e604785282294 = 2803808537846 := by decide
theorem cert_e604785282294 : check e604785282294 [[],[]] .smaller = true := by decide
def e604785282670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e604785282670 : Closed e604785282670 ∧ code e604785282670 = 2803808538222 := by decide
theorem cert_e604785282670 : check e604785282670 [[],[]] .smaller = true := by decide
def e604785282682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e604785282682 : Closed e604785282682 ∧ code e604785282682 = 2803808538234 := by decide
theorem cert_e604785282682 : check e604785282682 [[],[]] .smaller = true := by decide
def e604785282870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e604785282870 : Closed e604785282870 ∧ code e604785282870 = 2803808538422 := by decide
theorem cert_e604785282870 : check e604785282870 [[],[]] .smaller = true := by decide
def e604785282874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e604785282874 : Closed e604785282874 ∧ code e604785282874 = 2803808538426 := by decide
theorem cert_e604785282874 : check e604785282874 [[],[]] .smaller = true := by decide
def e604785290718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e604785290718 : Closed e604785290718 ∧ code e604785290718 = 2803808546270 := by decide
theorem cert_e604785290718 : check e604785290718 [[],[]] .three = true := by decide
def e604785290734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e604785290734 : Closed e604785290734 ∧ code e604785290734 = 2803808546286 := by decide
theorem cert_e604785290734 : check e604785290734 [[],[]] .three = true := by decide
def e604785290974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e604785290974 : Closed e604785290974 ∧ code e604785290974 = 2803808546526 := by decide
theorem cert_e604785290974 : check e604785290974 [[],[]] .three = true := by decide
def e604785290990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e604785290990 : Closed e604785290990 ∧ code e604785290990 = 2803808546542 := by decide
theorem cert_e604785290990 : check e604785290990 [[],[]] .smaller = true := by decide
def e604785290998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e604785290998 : Closed e604785290998 ∧ code e604785290998 = 2803808546550 := by decide
theorem cert_e604785290998 : check e604785290998 [[],[]] .three = true := by decide
def e604785291102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e604785291102 : Closed e604785291102 ∧ code e604785291102 = 2803808546654 := by decide
theorem cert_e604785291102 : check e604785291102 [[],[]] .three = true := by decide
def e604785291118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e604785291118 : Closed e604785291118 ∧ code e604785291118 = 2803808546670 := by decide
theorem cert_e604785291118 : check e604785291118 [[],[]] .smaller = true := by decide
def e604785291126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e604785291126 : Closed e604785291126 ∧ code e604785291126 = 2803808546678 := by decide
theorem cert_e604785291126 : check e604785291126 [[],[]] .smaller = true := by decide
end Blc.Floor41
