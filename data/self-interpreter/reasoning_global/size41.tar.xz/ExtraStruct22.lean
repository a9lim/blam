import Extra41
import Batch139
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness605775149498
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.app u0 u4
private def u6 := Term.app u3 u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775149498 : ¬ IsSelfInterpreter e605775149498 := by
  intro he
  have h : replay [] e605775149498 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775149498
end Witness605775149498
namespace Witness605775149546
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.app u4 u0
private def u6 := Term.app u3 u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775149546 : ¬ IsSelfInterpreter e605775149546 := by
  intro he
  have h : replay [] e605775149546 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775149546
end Witness605775149546
namespace Witness605775149978
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.app u0 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u1
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u13 := Term.app u0 u3
private theorem sou3 : SO u3 := SO.var 1
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.app sou3 sou4
private theorem sou6 : SO u6 := SO.app sou0 sou5
private theorem sou13 : SO u13 := SO.app sou0 sou3
private theorem sou7 : SO u7 := SO.lam (r := u13) (g := u13) sou6 sou13 (by decide) (by decide)
private theorem sou8 : SO u8 := SO.lam (r := u0) (g := u7) sou7 sou0 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou10 : SO u10 := SO.app sou9 sou1
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
private theorem sou12 : SO u12 := SO.app sou2 sou11
theorem nege605775149978 : ¬ IsSelfInterpreter e605775149978 := by
  exact rawSO [] (t := u12) (by decide) sou12
#print axioms nege605775149978
end Witness605775149978
namespace Witness605775150298
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u0 u4
private def u6 := Term.app u3 u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775150298 : ¬ IsSelfInterpreter e605775150298 := by
  intro he
  have h : replay [] e605775150298 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775150298
end Witness605775150298
namespace Witness605775150314
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u4 u0
private def u6 := Term.app u3 u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605775150314 : ¬ IsSelfInterpreter e605775150314 := by
  intro he
  have h : replay [] e605775150314 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605775150314
end Witness605775150314
namespace Witness605775150490
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u3 u4
private def u6 := Term.app u0 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u1
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u13 := Term.app u4 u0
private def u14 := Term.app u0 u4
private theorem sou3 : SO u3 := SO.var 2
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.app sou3 sou4
private theorem sou6 : SO u6 := SO.app sou0 sou5
private theorem sou13 : SO u13 := SO.app sou4 sou0
private theorem sou7 : SO u7 := SO.lam (r := u13) (g := u14) sou6 sou13 (by decide) (by decide)
private theorem sou8 : SO u8 := SO.lam (r := u0) (g := u7) sou7 sou0 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou10 : SO u10 := SO.app sou9 sou1
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
private theorem sou12 : SO u12 := SO.app sou2 sou11
theorem nege605775150490 : ¬ IsSelfInterpreter e605775150490 := by
  exact rawSO [] (t := u12) (by decide) sou12
#print axioms nege605775150490
end Witness605775150490
namespace Witness605775184826
private def u0 := Term.var 0
private def u1 := Term.var 2
private def u2 := Term.var 1
private def u3 := Term.app u2 u1
private def u4 := Term.lam u3
private def u5 := Term.app u1 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u0 u7
private def u9 := Term.app u8 u0
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
theorem nege605775184826 : ¬ IsSelfInterpreter e605775184826 := by
  intro he
  have h : replay [[]] e605775184826 = some u11 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 2 (by decide : Closed u11) (by decide) (by decide) hj
#print axioms nege605775184826
end Witness605775184826
namespace Witness605775186778
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.var 1
private def u5 := Term.app u1 u4
private def u6 := Term.app u3 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
theorem nege605775186778 : ¬ IsSelfInterpreter e605775186778 := by
  intro he
  have h : replay [] e605775186778 = some u12 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u12) (by decide) (by decide) hj
#print axioms nege605775186778
end Witness605775186778
end Blc.Floor41
