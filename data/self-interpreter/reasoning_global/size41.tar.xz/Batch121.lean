import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605605425594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e605605425594 : Closed e605605425594 ∧ code e605605425594 = 2804628681146 := by decide
theorem cert_e605605425594 : check e605605425594 [[],[]] .chain = true := by decide
def e605605425642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e605605425642 : Closed e605605425642 ∧ code e605605425642 = 2804628681194 := by decide
theorem cert_e605605425642 : check e605605425642 [[],[]] .chain = true := by decide
def e605605426286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605605426286 : Closed e605605426286 ∧ code e605605426286 = 2804628681838 := by decide
theorem cert_e605605426286 : check e605605426286 [[],[]] .chain = true := by decide
def e605605426298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605605426298 : Closed e605605426298 ∧ code e605605426298 = 2804628681850 := by decide
theorem cert_e605605426298 : check e605605426298 [[],[]] .chain = true := by decide
def e605605426462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605605426462 : Closed e605605426462 ∧ code e605605426462 = 2804628682014 := by decide
theorem cert_e605605426462 : check e605605426462 [[],[]] .chain = true := by decide
def e605605426630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605605426630 : Closed e605605426630 ∧ code e605605426630 = 2804628682182 := by decide
theorem cert_e605605426630 : check e605605426630 [[],[]] .chain = true := by decide
def e605605426970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e605605426970 : Closed e605605426970 ∧ code e605605426970 = 2804628682522 := by decide
theorem cert_e605605426970 : check e605605426970 [[],[]] .chain = true := by decide
def e605605427014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e605605427014 : Closed e605605427014 ∧ code e605605427014 = 2804628682566 := by decide
theorem cert_e605605427014 : check e605605427014 [[],[]] .chain = true := by decide
def e605605427242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e605605427242 : Closed e605605427242 ∧ code e605605427242 = 2804628682794 := by decide
theorem cert_e605605427242 : check e605605427242 [[],[]] .chain = true := by decide
def e605605427374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605605427374 : Closed e605605427374 ∧ code e605605427374 = 2804628682926 := by decide
theorem cert_e605605427374 : check e605605427374 [[],[]] .sourceHead = true := by decide
def e605605427386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605605427386 : Closed e605605427386 ∧ code e605605427386 = 2804628682938 := by decide
theorem cert_e605605427386 : check e605605427386 [[],[]] .sourceHead = true := by decide
def e605605427414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e605605427414 : Closed e605605427414 ∧ code e605605427414 = 2804628682966 := by decide
theorem cert_e605605427414 : check e605605427414 [[],[]] .chain = true := by decide
def e605605427418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e605605427418 : Closed e605605427418 ∧ code e605605427418 = 2804628682970 := by decide
theorem cert_e605605427418 : check e605605427418 [[],[]] .chain = true := by decide
def e605605427434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605605427434 : Closed e605605427434 ∧ code e605605427434 = 2804628682986 := by decide
theorem cert_e605605427434 : check e605605427434 [[],[]] .chain = true := by decide
def e605605427626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605605427626 : Closed e605605427626 ∧ code e605605427626 = 2804628683178 := by decide
theorem cert_e605605427626 : check e605605427626 [[],[]] .chain = true := by decide
def e605605427722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605605427722 : Closed e605605427722 ∧ code e605605427722 = 2804628683274 := by decide
theorem cert_e605605427722 : check e605605427722 [[],[]] .chain = true := by decide
def e605605427758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605605427758 : Closed e605605427758 ∧ code e605605427758 = 2804628683310 := by decide
theorem cert_e605605427758 : check e605605427758 [[],[]] .sourceHead = true := by decide
def e605605427766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605605427766 : Closed e605605427766 ∧ code e605605427766 = 2804628683318 := by decide
theorem cert_e605605427766 : check e605605427766 [[],[]] .chain = true := by decide
def e605605427770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605605427770 : Closed e605605427770 ∧ code e605605427770 = 2804628683322 := by decide
theorem cert_e605605427770 : check e605605427770 [[],[]] .chain = true := by decide
def e605605427818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605605427818 : Closed e605605427818 ∧ code e605605427818 = 2804628683370 := by decide
theorem cert_e605605427818 : check e605605427818 [[],[]] .chain = true := by decide
def e605605427842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605605427842 : Closed e605605427842 ∧ code e605605427842 = 2804628683394 := by decide
theorem cert_e605605427842 : check e605605427842 [[],[]] .chain = true := by decide
def e605605427854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605605427854 : Closed e605605427854 ∧ code e605605427854 = 2804628683406 := by decide
theorem cert_e605605427854 : check e605605427854 [[],[]] .chain = true := by decide
def e605605427866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605605427866 : Closed e605605427866 ∧ code e605605427866 = 2804628683418 := by decide
theorem cert_e605605427866 : check e605605427866 [[],[]] .chain = true := by decide
def e605605427910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605605427910 : Closed e605605427910 ∧ code e605605427910 = 2804628683462 := by decide
theorem cert_e605605427910 : check e605605427910 [[],[]] .chain = true := by decide
def e605605427938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605605427938 : Closed e605605427938 ∧ code e605605427938 = 2804628683490 := by decide
theorem cert_e605605427938 : check e605605427938 [[],[]] .sourceHead = true := by decide
def e605605427950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e605605427950 : Closed e605605427950 ∧ code e605605427950 = 2804628683502 := by decide
theorem cert_e605605427950 : check e605605427950 [[],[]] .sourceHead = true := by decide
def e605605427994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e605605427994 : Closed e605605427994 ∧ code e605605427994 = 2804628683546 := by decide
theorem cert_e605605427994 : check e605605427994 [[],[]] .chain = true := by decide
def e605605428038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e605605428038 : Closed e605605428038 ∧ code e605605428038 = 2804628683590 := by decide
theorem cert_e605605428038 : check e605605428038 [[],[]] .chain = true := by decide
def e605605428106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605605428106 : Closed e605605428106 ∧ code e605605428106 = 2804628683658 := by decide
theorem cert_e605605428106 : check e605605428106 [[],[]] .sourceHead = true := by decide
def e605605428130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605605428130 : Closed e605605428130 ∧ code e605605428130 = 2804628683682 := by decide
theorem cert_e605605428130 : check e605605428130 [[],[]] .sourceHead = true := by decide
def e605605428142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e605605428142 : Closed e605605428142 ∧ code e605605428142 = 2804628683694 := by decide
theorem cert_e605605428142 : check e605605428142 [[],[]] .sourceHead = true := by decide
def e605605428154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e605605428154 : Closed e605605428154 ∧ code e605605428154 = 2804628683706 := by decide
theorem cert_e605605428154 : check e605605428154 [[],[]] .sourceHead = true := by decide
def e605605429678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 2)))))))
theorem wire_e605605429678 : Closed e605605429678 ∧ code e605605429678 = 2804628685230 := by decide
theorem cert_e605605429678 : check e605605429678 [[],[]] .sourceHead = true := by decide
def e605605429870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e605605429870 : Closed e605605429870 ∧ code e605605429870 = 2804628685422 := by decide
theorem cert_e605605429870 : check e605605429870 [[],[]] .chain = true := by decide
def e605605429882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e605605429882 : Closed e605605429882 ∧ code e605605429882 = 2804628685434 := by decide
theorem cert_e605605429882 : check e605605429882 [[],[]] .chain = true := by decide
def e605605430254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 2)))))))
theorem wire_e605605430254 : Closed e605605430254 ∧ code e605605430254 = 2804628685806 := by decide
theorem cert_e605605430254 : check e605605430254 [[],[]] .sourceHead = true := by decide
def e605605431022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e605605431022 : Closed e605605431022 ∧ code e605605431022 = 2804628686574 := by decide
theorem cert_e605605431022 : check e605605431022 [[],[]] .chain = true := by decide
def e605605431030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e605605431030 : Closed e605605431030 ∧ code e605605431030 = 2804628686582 := by decide
theorem cert_e605605431030 : check e605605431030 [[],[]] .chain = true := by decide
def e605605431150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e605605431150 : Closed e605605431150 ∧ code e605605431150 = 2804628686702 := by decide
theorem cert_e605605431150 : check e605605431150 [[],[]] .chain = true := by decide
def e605605431162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e605605431162 : Closed e605605431162 ∧ code e605605431162 = 2804628686714 := by decide
theorem cert_e605605431162 : check e605605431162 [[],[]] .chain = true := by decide
def e605605431214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e605605431214 : Closed e605605431214 ∧ code e605605431214 = 2804628686766 := by decide
theorem cert_e605605431214 : check e605605431214 [[],[]] .chain = true := by decide
def e605605431254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e605605431254 : Closed e605605431254 ∧ code e605605431254 = 2804628686806 := by decide
theorem cert_e605605431254 : check e605605431254 [[],[]] .chain = true := by decide
def e605605431258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e605605431258 : Closed e605605431258 ∧ code e605605431258 = 2804628686810 := by decide
theorem cert_e605605431258 : check e605605431258 [[],[]] .chain = true := by decide
def e605605431790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 2))))))))
theorem wire_e605605431790 : Closed e605605431790 ∧ code e605605431790 = 2804628687342 := by decide
theorem cert_e605605431790 : check e605605431790 [[],[]] .sourceHead = true := by decide
def e605605432558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e605605432558 : Closed e605605432558 ∧ code e605605432558 = 2804628688110 := by decide
theorem cert_e605605432558 : check e605605432558 [[],[]] .chain = true := by decide
def e605605432566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e605605432566 : Closed e605605432566 ∧ code e605605432566 = 2804628688118 := by decide
theorem cert_e605605432566 : check e605605432566 [[],[]] .chain = true := by decide
def e605605432942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e605605432942 : Closed e605605432942 ∧ code e605605432942 = 2804628688494 := by decide
theorem cert_e605605432942 : check e605605432942 [[],[]] .chain = true := by decide
def e605605432954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e605605432954 : Closed e605605432954 ∧ code e605605432954 = 2804628688506 := by decide
theorem cert_e605605432954 : check e605605432954 [[],[]] .chain = true := by decide
def e605605433118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 3))))))))
theorem wire_e605605433118 : Closed e605605433118 ∧ code e605605433118 = 2804628688670 := by decide
theorem cert_e605605433118 : check e605605433118 [[],[]] .sourceHead = true := by decide
def e605605433142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e605605433142 : Closed e605605433142 ∧ code e605605433142 = 2804628688694 := by decide
theorem cert_e605605433142 : check e605605433142 [[],[]] .chain = true := by decide
def e605605433146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e605605433146 : Closed e605605433146 ∧ code e605605433146 = 2804628688698 := by decide
theorem cert_e605605433146 : check e605605433146 [[],[]] .chain = true := by decide
def e605605435054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e605605435054 : Closed e605605435054 ∧ code e605605435054 = 2804628690606 := by decide
theorem cert_e605605435054 : check e605605435054 [[],[]] .chain = true := by decide
def e605605435066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e605605435066 : Closed e605605435066 ∧ code e605605435066 = 2804628690618 := by decide
theorem cert_e605605435066 : check e605605435066 [[],[]] .chain = true := by decide
def e605605435114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e605605435114 : Closed e605605435114 ∧ code e605605435114 = 2804628690666 := by decide
theorem cert_e605605435114 : check e605605435114 [[],[]] .chain = true := by decide
def e605605435306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e605605435306 : Closed e605605435306 ∧ code e605605435306 = 2804628690858 := by decide
theorem cert_e605605435306 : check e605605435306 [[],[]] .chain = true := by decide
def e605605435438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e605605435438 : Closed e605605435438 ∧ code e605605435438 = 2804628690990 := by decide
theorem cert_e605605435438 : check e605605435438 [[],[]] .chain = true := by decide
def e605605435630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e605605435630 : Closed e605605435630 ∧ code e605605435630 = 2804628691182 := by decide
theorem cert_e605605435630 : check e605605435630 [[],[]] .chain = true := by decide
def e605605435638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e605605435638 : Closed e605605435638 ∧ code e605605435638 = 2804628691190 := by decide
theorem cert_e605605435638 : check e605605435638 [[],[]] .chain = true := by decide
def e605605435822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e605605435822 : Closed e605605435822 ∧ code e605605435822 = 2804628691374 := by decide
theorem cert_e605605435822 : check e605605435822 [[],[]] .chain = true := by decide
def e605605435834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605605435834 : Closed e605605435834 ∧ code e605605435834 = 2804628691386 := by decide
theorem cert_e605605435834 : check e605605435834 [[],[]] .chain = true := by decide
def e605605435882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605605435882 : Closed e605605435882 ∧ code e605605435882 = 2804628691434 := by decide
theorem cert_e605605435882 : check e605605435882 [[],[]] .chain = true := by decide
def e605605436014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605605436014 : Closed e605605436014 ∧ code e605605436014 = 2804628691566 := by decide
theorem cert_e605605436014 : check e605605436014 [[],[]] .chain = true := by decide
def e605605436026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605605436026 : Closed e605605436026 ∧ code e605605436026 = 2804628691578 := by decide
theorem cert_e605605436026 : check e605605436026 [[],[]] .chain = true := by decide
def e605605436190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e605605436190 : Closed e605605436190 ∧ code e605605436190 = 2804628691742 := by decide
theorem cert_e605605436190 : check e605605436190 [[],[]] .chain = true := by decide
def e605605436290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e605605436290 : Closed e605605436290 ∧ code e605605436290 = 2804628691842 := by decide
theorem cert_e605605436290 : check e605605436290 [[],[]] .chain = true := by decide
def e605605436302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e605605436302 : Closed e605605436302 ∧ code e605605436302 = 2804628691854 := by decide
theorem cert_e605605436302 : check e605605436302 [[],[]] .chain = true := by decide
def e605605436314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605605436314 : Closed e605605436314 ∧ code e605605436314 = 2804628691866 := by decide
theorem cert_e605605436314 : check e605605436314 [[],[]] .chain = true := by decide
def e605605436526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e605605436526 : Closed e605605436526 ∧ code e605605436526 = 2804628692078 := by decide
theorem cert_e605605436526 : check e605605436526 [[],[]] .chain = true := by decide
def e605605436538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e605605436538 : Closed e605605436538 ∧ code e605605436538 = 2804628692090 := by decide
theorem cert_e605605436538 : check e605605436538 [[],[]] .chain = true := by decide
def e605605436702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e605605436702 : Closed e605605436702 ∧ code e605605436702 = 2804628692254 := by decide
theorem cert_e605605436702 : check e605605436702 [[],[]] .chain = true := by decide
def e605605436870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e605605436870 : Closed e605605436870 ∧ code e605605436870 = 2804628692422 := by decide
theorem cert_e605605436870 : check e605605436870 [[],[]] .chain = true := by decide
def e605605436938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605605436938 : Closed e605605436938 ∧ code e605605436938 = 2804628692490 := by decide
theorem cert_e605605436938 : check e605605436938 [[],[]] .chain = true := by decide
def e605605436974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605605436974 : Closed e605605436974 ∧ code e605605436974 = 2804628692526 := by decide
theorem cert_e605605436974 : check e605605436974 [[],[]] .sourceHead = true := by decide
def e605605436982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605605436982 : Closed e605605436982 ∧ code e605605436982 = 2804628692534 := by decide
theorem cert_e605605436982 : check e605605436982 [[],[]] .chain = true := by decide
def e605605436986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605605436986 : Closed e605605436986 ∧ code e605605436986 = 2804628692538 := by decide
theorem cert_e605605436986 : check e605605436986 [[],[]] .chain = true := by decide
def e605605437034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605605437034 : Closed e605605437034 ∧ code e605605437034 = 2804628692586 := by decide
theorem cert_e605605437034 : check e605605437034 [[],[]] .chain = true := by decide
def e605605437058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e605605437058 : Closed e605605437058 ∧ code e605605437058 = 2804628692610 := by decide
theorem cert_e605605437058 : check e605605437058 [[],[]] .chain = true := by decide
def e605605437070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605605437070 : Closed e605605437070 ∧ code e605605437070 = 2804628692622 := by decide
theorem cert_e605605437070 : check e605605437070 [[],[]] .chain = true := by decide
def e605605437082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605605437082 : Closed e605605437082 ∧ code e605605437082 = 2804628692634 := by decide
theorem cert_e605605437082 : check e605605437082 [[],[]] .chain = true := by decide
def e605605437126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605605437126 : Closed e605605437126 ∧ code e605605437126 = 2804628692678 := by decide
theorem cert_e605605437126 : check e605605437126 [[],[]] .chain = true := by decide
def e605605437154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 0))))))))
theorem wire_e605605437154 : Closed e605605437154 ∧ code e605605437154 = 2804628692706 := by decide
theorem cert_e605605437154 : check e605605437154 [[],[]] .sourceHead = true := by decide
def e605605437166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 2)))))))
theorem wire_e605605437166 : Closed e605605437166 ∧ code e605605437166 = 2804628692718 := by decide
theorem cert_e605605437166 : check e605605437166 [[],[]] .sourceHead = true := by decide
def e605605437918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605605437918 : Closed e605605437918 ∧ code e605605437918 = 2804628693470 := by decide
theorem cert_e605605437918 : check e605605437918 [[],[]] .chain = true := by decide
def e605605437942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605605437942 : Closed e605605437942 ∧ code e605605437942 = 2804628693494 := by decide
theorem cert_e605605437942 : check e605605437942 [[],[]] .chain = true := by decide
def e605605438894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605605438894 : Closed e605605438894 ∧ code e605605438894 = 2804628694446 := by decide
theorem cert_e605605438894 : check e605605438894 [[],[]] .chain = true := by decide
def e605605438906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605605438906 : Closed e605605438906 ∧ code e605605438906 = 2804628694458 := by decide
theorem cert_e605605438906 : check e605605438906 [[],[]] .chain = true := by decide
def e605605438954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605605438954 : Closed e605605438954 ∧ code e605605438954 = 2804628694506 := by decide
theorem cert_e605605438954 : check e605605438954 [[],[]] .chain = true := by decide
def e605605439086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605605439086 : Closed e605605439086 ∧ code e605605439086 = 2804628694638 := by decide
theorem cert_e605605439086 : check e605605439086 [[],[]] .chain = true := by decide
def e605605439098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605605439098 : Closed e605605439098 ∧ code e605605439098 = 2804628694650 := by decide
theorem cert_e605605439098 : check e605605439098 [[],[]] .chain = true := by decide
def e605605439262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605605439262 : Closed e605605439262 ∧ code e605605439262 = 2804628694814 := by decide
theorem cert_e605605439262 : check e605605439262 [[],[]] .chain = true := by decide
def e605605439362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e605605439362 : Closed e605605439362 ∧ code e605605439362 = 2804628694914 := by decide
theorem cert_e605605439362 : check e605605439362 [[],[]] .chain = true := by decide
def e605605439374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605605439374 : Closed e605605439374 ∧ code e605605439374 = 2804628694926 := by decide
theorem cert_e605605439374 : check e605605439374 [[],[]] .chain = true := by decide
def e605605439386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605605439386 : Closed e605605439386 ∧ code e605605439386 = 2804628694938 := by decide
theorem cert_e605605439386 : check e605605439386 [[],[]] .chain = true := by decide
def e605605441758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e605605441758 : Closed e605605441758 ∧ code e605605441758 = 2804628697310 := by decide
theorem cert_e605605441758 : check e605605441758 [[],[]] .chain = true := by decide
def e605605441786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e605605441786 : Closed e605605441786 ∧ code e605605441786 = 2804628697338 := by decide
theorem cert_e605605441786 : check e605605441786 [[],[]] .chain = true := by decide
def e605605442334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605605442334 : Closed e605605442334 ∧ code e605605442334 = 2804628697886 := by decide
theorem cert_e605605442334 : check e605605442334 [[],[]] .chain = true := by decide
def e605605442502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605605442502 : Closed e605605442502 ∧ code e605605442502 = 2804628698054 := by decide
theorem cert_e605605442502 : check e605605442502 [[],[]] .chain = true := by decide
def e605605443610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605605443610 : Closed e605605443610 ∧ code e605605443610 = 2804628699162 := by decide
theorem cert_e605605443610 : check e605605443610 [[],[]] .sourceHead = true := by decide
def e605605443646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 4)))))))))
theorem wire_e605605443646 : Closed e605605443646 ∧ code e605605443646 = 2804628699198 := by decide
theorem cert_e605605443646 : check e605605443646 [[],[]] .sourceHead = true := by decide
def e605605443694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605605443694 : Closed e605605443694 ∧ code e605605443694 = 2804628699246 := by decide
theorem cert_e605605443694 : check e605605443694 [[],[]] .chain = true := by decide
def e605605443702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605605443702 : Closed e605605443702 ∧ code e605605443702 = 2804628699254 := by decide
theorem cert_e605605443702 : check e605605443702 [[],[]] .chain = true := by decide
def e605605443706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605605443706 : Closed e605605443706 ∧ code e605605443706 = 2804628699258 := by decide
theorem cert_e605605443706 : check e605605443706 [[],[]] .chain = true := by decide
def e605605443946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605605443946 : Closed e605605443946 ∧ code e605605443946 = 2804628699498 := by decide
theorem cert_e605605443946 : check e605605443946 [[],[]] .chain = true := by decide
def e605605443970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605605443970 : Closed e605605443970 ∧ code e605605443970 = 2804628699522 := by decide
theorem cert_e605605443970 : check e605605443970 [[],[]] .chain = true := by decide
def e605605443982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605605443982 : Closed e605605443982 ∧ code e605605443982 = 2804628699534 := by decide
theorem cert_e605605443982 : check e605605443982 [[],[]] .chain = true := by decide
def e605605443994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605605443994 : Closed e605605443994 ∧ code e605605443994 = 2804628699546 := by decide
theorem cert_e605605443994 : check e605605443994 [[],[]] .chain = true := by decide
def e605605444038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605605444038 : Closed e605605444038 ∧ code e605605444038 = 2804628699590 := by decide
theorem cert_e605605444038 : check e605605444038 [[],[]] .chain = true := by decide
def e605605444066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605605444066 : Closed e605605444066 ∧ code e605605444066 = 2804628699618 := by decide
theorem cert_e605605444066 : check e605605444066 [[],[]] .sourceHead = true := by decide
def e605605444078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 2))))))))
theorem wire_e605605444078 : Closed e605605444078 ∧ code e605605444078 = 2804628699630 := by decide
theorem cert_e605605444078 : check e605605444078 [[],[]] .sourceHead = true := by decide
def e605605446510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e605605446510 : Closed e605605446510 ∧ code e605605446510 = 2804628702062 := by decide
theorem cert_e605605446510 : check e605605446510 [[],[]] .chain = true := by decide
def e605605446522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e605605446522 : Closed e605605446522 ∧ code e605605446522 = 2804628702074 := by decide
theorem cert_e605605446522 : check e605605446522 [[],[]] .chain = true := by decide
def e605605446574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e605605446574 : Closed e605605446574 ∧ code e605605446574 = 2804628702126 := by decide
theorem cert_e605605446574 : check e605605446574 [[],[]] .chain = true := by decide
def e605605446634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e605605446634 : Closed e605605446634 ∧ code e605605446634 = 2804628702186 := by decide
theorem cert_e605605446634 : check e605605446634 [[],[]] .chain = true := by decide
def e605605447278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e605605447278 : Closed e605605447278 ∧ code e605605447278 = 2804628702830 := by decide
theorem cert_e605605447278 : check e605605447278 [[],[]] .chain = true := by decide
def e605605447290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e605605447290 : Closed e605605447290 ∧ code e605605447290 = 2804628702842 := by decide
theorem cert_e605605447290 : check e605605447290 [[],[]] .chain = true := by decide
def e605605447578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e605605447578 : Closed e605605447578 ∧ code e605605447578 = 2804628703130 := by decide
theorem cert_e605605447578 : check e605605447578 [[],[]] .chain = true := by decide
def e605605448814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e605605448814 : Closed e605605448814 ∧ code e605605448814 = 2804628704366 := by decide
theorem cert_e605605448814 : check e605605448814 [[],[]] .chain = true := by decide
def e605605448826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e605605448826 : Closed e605605448826 ∧ code e605605448826 = 2804628704378 := by decide
theorem cert_e605605448826 : check e605605448826 [[],[]] .chain = true := by decide
def e605605448990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e605605448990 : Closed e605605448990 ∧ code e605605448990 = 2804628704542 := by decide
theorem cert_e605605448990 : check e605605448990 [[],[]] .chain = true := by decide
def e605605449158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e605605449158 : Closed e605605449158 ∧ code e605605449158 = 2804628704710 := by decide
theorem cert_e605605449158 : check e605605449158 [[],[]] .chain = true := by decide
def e605605449498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e605605449498 : Closed e605605449498 ∧ code e605605449498 = 2804628705050 := by decide
theorem cert_e605605449498 : check e605605449498 [[],[]] .chain = true := by decide
def e605605449542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e605605449542 : Closed e605605449542 ∧ code e605605449542 = 2804628705094 := by decide
theorem cert_e605605449542 : check e605605449542 [[],[]] .chain = true := by decide
def e605605449950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e605605449950 : Closed e605605449950 ∧ code e605605449950 = 2804628705502 := by decide
theorem cert_e605605449950 : check e605605449950 [[],[]] .chain = true := by decide
def e605605449978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e605605449978 : Closed e605605449978 ∧ code e605605449978 = 2804628705530 := by decide
theorem cert_e605605449978 : check e605605449978 [[],[]] .chain = true := by decide
def e605605450526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605605450526 : Closed e605605450526 ∧ code e605605450526 = 2804628706078 := by decide
theorem cert_e605605450526 : check e605605450526 [[],[]] .chain = true := by decide
def e605605450694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605605450694 : Closed e605605450694 ∧ code e605605450694 = 2804628706246 := by decide
theorem cert_e605605450694 : check e605605450694 [[],[]] .chain = true := by decide
def e605605452854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e605605452854 : Closed e605605452854 ∧ code e605605452854 = 2804628708406 := by decide
theorem cert_e605605452854 : check e605605452854 [[],[]] .chain = true := by decide
def e605605452858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e605605452858 : Closed e605605452858 ∧ code e605605452858 = 2804628708410 := by decide
theorem cert_e605605452858 : check e605605452858 [[],[]] .chain = true := by decide
def e605605452998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e605605452998 : Closed e605605452998 ∧ code e605605452998 = 2804628708550 := by decide
theorem cert_e605605452998 : check e605605452998 [[],[]] .chain = true := by decide
def e605605453930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e605605453930 : Closed e605605453930 ∧ code e605605453930 = 2804628709482 := by decide
theorem cert_e605605453930 : check e605605453930 [[],[]] .sourceHead = true := by decide
def e605605453978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e605605453978 : Closed e605605453978 ∧ code e605605453978 = 2804628709530 := by decide
theorem cert_e605605453978 : check e605605453978 [[],[]] .chain = true := by decide
def e605605454062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e605605454062 : Closed e605605454062 ∧ code e605605454062 = 2804628709614 := by decide
theorem cert_e605605454062 : check e605605454062 [[],[]] .sourceHead = true := by decide
def e605605454074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e605605454074 : Closed e605605454074 ∧ code e605605454074 = 2804628709626 := by decide
theorem cert_e605605454074 : check e605605454074 [[],[]] .sourceHead = true := by decide
def e605605454262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e605605454262 : Closed e605605454262 ∧ code e605605454262 = 2804628709814 := by decide
theorem cert_e605605454262 : check e605605454262 [[],[]] .chain = true := by decide
def e605605454266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605605454266 : Closed e605605454266 ∧ code e605605454266 = 2804628709818 := by decide
theorem cert_e605605454266 : check e605605454266 [[],[]] .chain = true := by decide
def e605605454294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e605605454294 : Closed e605605454294 ∧ code e605605454294 = 2804628709846 := by decide
theorem cert_e605605454294 : check e605605454294 [[],[]] .chain = true := by decide
def e605605454298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e605605454298 : Closed e605605454298 ∧ code e605605454298 = 2804628709850 := by decide
theorem cert_e605605454298 : check e605605454298 [[],[]] .chain = true := by decide
def e605605454314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605605454314 : Closed e605605454314 ∧ code e605605454314 = 2804628709866 := by decide
theorem cert_e605605454314 : check e605605454314 [[],[]] .chain = true := by decide
def e605605454446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605605454446 : Closed e605605454446 ∧ code e605605454446 = 2804628709998 := by decide
theorem cert_e605605454446 : check e605605454446 [[],[]] .sourceHead = true := by decide
def e605605454458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605605454458 : Closed e605605454458 ∧ code e605605454458 = 2804628710010 := by decide
theorem cert_e605605454458 : check e605605454458 [[],[]] .sourceHead = true := by decide
def e605605454622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e605605454622 : Closed e605605454622 ∧ code e605605454622 = 2804628710174 := by decide
theorem cert_e605605454622 : check e605605454622 [[],[]] .sourceHead = true := by decide
def e605605454646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e605605454646 : Closed e605605454646 ∧ code e605605454646 = 2804628710198 := by decide
theorem cert_e605605454646 : check e605605454646 [[],[]] .chain = true := by decide
def e605605454650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e605605454650 : Closed e605605454650 ∧ code e605605454650 = 2804628710202 := by decide
theorem cert_e605605454650 : check e605605454650 [[],[]] .chain = true := by decide
def e605605454746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605605454746 : Closed e605605454746 ∧ code e605605454746 = 2804628710298 := by decide
theorem cert_e605605454746 : check e605605454746 [[],[]] .chain = true := by decide
def e605605454790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e605605454790 : Closed e605605454790 ∧ code e605605454790 = 2804628710342 := by decide
theorem cert_e605605454790 : check e605605454790 [[],[]] .sourceHead = true := by decide
def e605605455274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e605605455274 : Closed e605605455274 ∧ code e605605455274 = 2804628710826 := by decide
theorem cert_e605605455274 : check e605605455274 [[],[]] .chain = true := by decide
def e605605455370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605605455370 : Closed e605605455370 ∧ code e605605455370 = 2804628710922 := by decide
theorem cert_e605605455370 : check e605605455370 [[],[]] .chain = true := by decide
def e605605455406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605605455406 : Closed e605605455406 ∧ code e605605455406 = 2804628710958 := by decide
theorem cert_e605605455406 : check e605605455406 [[],[]] .sourceHead = true := by decide
def e605605455414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605605455414 : Closed e605605455414 ∧ code e605605455414 = 2804628710966 := by decide
theorem cert_e605605455414 : check e605605455414 [[],[]] .chain = true := by decide
def e605605455418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605605455418 : Closed e605605455418 ∧ code e605605455418 = 2804628710970 := by decide
theorem cert_e605605455418 : check e605605455418 [[],[]] .chain = true := by decide
def e605605455466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605605455466 : Closed e605605455466 ∧ code e605605455466 = 2804628711018 := by decide
theorem cert_e605605455466 : check e605605455466 [[],[]] .chain = true := by decide
def e605605455490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e605605455490 : Closed e605605455490 ∧ code e605605455490 = 2804628711042 := by decide
theorem cert_e605605455490 : check e605605455490 [[],[]] .chain = true := by decide
def e605605455502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605605455502 : Closed e605605455502 ∧ code e605605455502 = 2804628711054 := by decide
theorem cert_e605605455502 : check e605605455502 [[],[]] .chain = true := by decide
def e605605455514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605605455514 : Closed e605605455514 ∧ code e605605455514 = 2804628711066 := by decide
theorem cert_e605605455514 : check e605605455514 [[],[]] .chain = true := by decide
def e605605455558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605605455558 : Closed e605605455558 ∧ code e605605455558 = 2804628711110 := by decide
theorem cert_e605605455558 : check e605605455558 [[],[]] .chain = true := by decide
def e605605455586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e605605455586 : Closed e605605455586 ∧ code e605605455586 = 2804628711138 := by decide
theorem cert_e605605455586 : check e605605455586 [[],[]] .sourceHead = true := by decide
def e605605455598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e605605455598 : Closed e605605455598 ∧ code e605605455598 = 2804628711150 := by decide
theorem cert_e605605455598 : check e605605455598 [[],[]] .sourceHead = true := by decide
def e605605455642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e605605455642 : Closed e605605455642 ∧ code e605605455642 = 2804628711194 := by decide
theorem cert_e605605455642 : check e605605455642 [[],[]] .chain = true := by decide
def e605605455686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e605605455686 : Closed e605605455686 ∧ code e605605455686 = 2804628711238 := by decide
theorem cert_e605605455686 : check e605605455686 [[],[]] .chain = true := by decide
def e605605455754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605605455754 : Closed e605605455754 ∧ code e605605455754 = 2804628711306 := by decide
theorem cert_e605605455754 : check e605605455754 [[],[]] .sourceHead = true := by decide
end Blc.Floor41
