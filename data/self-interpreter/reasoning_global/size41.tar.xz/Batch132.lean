import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605641431278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605641431278 : Closed e605641431278 ∧ code e605641431278 = 2804664686830 := by decide
theorem cert_e605641431278 : check e605641431278 [[],[]] .chain = true := by decide
def e605641431286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605641431286 : Closed e605641431286 ∧ code e605641431286 = 2804664686838 := by decide
theorem cert_e605641431286 : check e605641431286 [[],[]] .chain = true := by decide
def e605641431470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605641431470 : Closed e605641431470 ∧ code e605641431470 = 2804664687022 := by decide
theorem cert_e605641431470 : check e605641431470 [[],[]] .chain = true := by decide
def e605641431482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605641431482 : Closed e605641431482 ∧ code e605641431482 = 2804664687034 := by decide
theorem cert_e605641431482 : check e605641431482 [[],[]] .chain = true := by decide
def e605641431530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605641431530 : Closed e605641431530 ∧ code e605641431530 = 2804664687082 := by decide
theorem cert_e605641431530 : check e605641431530 [[],[]] .chain = true := by decide
def e605641431662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605641431662 : Closed e605641431662 ∧ code e605641431662 = 2804664687214 := by decide
theorem cert_e605641431662 : check e605641431662 [[],[]] .chain = true := by decide
def e605641431674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605641431674 : Closed e605641431674 ∧ code e605641431674 = 2804664687226 := by decide
theorem cert_e605641431674 : check e605641431674 [[],[]] .chain = true := by decide
def e605641431838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605641431838 : Closed e605641431838 ∧ code e605641431838 = 2804664687390 := by decide
theorem cert_e605641431838 : check e605641431838 [[],[]] .chain = true := by decide
def e605641431938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e605641431938 : Closed e605641431938 ∧ code e605641431938 = 2804664687490 := by decide
theorem cert_e605641431938 : check e605641431938 [[],[]] .chain = true := by decide
def e605641431950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605641431950 : Closed e605641431950 ∧ code e605641431950 = 2804664687502 := by decide
theorem cert_e605641431950 : check e605641431950 [[],[]] .chain = true := by decide
def e605641431962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605641431962 : Closed e605641431962 ∧ code e605641431962 = 2804664687514 := by decide
theorem cert_e605641431962 : check e605641431962 [[],[]] .chain = true := by decide
def e605641432086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605641432086 : Closed e605641432086 ∧ code e605641432086 = 2804664687638 := by decide
theorem cert_e605641432086 : check e605641432086 [[],[]] .chain = true := by decide
def e605641432182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e605641432182 : Closed e605641432182 ∧ code e605641432182 = 2804664687734 := by decide
theorem cert_e605641432182 : check e605641432182 [[],[]] .chain = true := by decide
def e605641432278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605641432278 : Closed e605641432278 ∧ code e605641432278 = 2804664687830 := by decide
theorem cert_e605641432278 : check e605641432278 [[],[]] .chain = true := by decide
def e605641432282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605641432282 : Closed e605641432282 ∧ code e605641432282 = 2804664687834 := by decide
theorem cert_e605641432282 : check e605641432282 [[],[]] .chain = true := by decide
def e605641432298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605641432298 : Closed e605641432298 ∧ code e605641432298 = 2804664687850 := by decide
theorem cert_e605641432298 : check e605641432298 [[],[]] .chain = true := by decide
def e605641432374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605641432374 : Closed e605641432374 ∧ code e605641432374 = 2804664687926 := by decide
theorem cert_e605641432374 : check e605641432374 [[],[]] .chain = true := by decide
def e605641432378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605641432378 : Closed e605641432378 ∧ code e605641432378 = 2804664687930 := by decide
theorem cert_e605641432378 : check e605641432378 [[],[]] .chain = true := by decide
def e605641432450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e605641432450 : Closed e605641432450 ∧ code e605641432450 = 2804664688002 := by decide
theorem cert_e605641432450 : check e605641432450 [[],[]] .chain = true := by decide
def e605641432462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e605641432462 : Closed e605641432462 ∧ code e605641432462 = 2804664688014 := by decide
theorem cert_e605641432462 : check e605641432462 [[],[]] .chain = true := by decide
def e605641432474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605641432474 : Closed e605641432474 ∧ code e605641432474 = 2804664688026 := by decide
theorem cert_e605641432474 : check e605641432474 [[],[]] .chain = true := by decide
def e605641433262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e605641433262 : Closed e605641433262 ∧ code e605641433262 = 2804664688814 := by decide
theorem cert_e605641433262 : check e605641433262 [[],[]] .chain = true := by decide
def e605641433274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e605641433274 : Closed e605641433274 ∧ code e605641433274 = 2804664688826 := by decide
theorem cert_e605641433274 : check e605641433274 [[],[]] .chain = true := by decide
def e605641433966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e605641433966 : Closed e605641433966 ∧ code e605641433966 = 2804664689518 := by decide
theorem cert_e605641433966 : check e605641433966 [[],[]] .chain = true := by decide
def e605641433974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e605641433974 : Closed e605641433974 ∧ code e605641433974 = 2804664689526 := by decide
theorem cert_e605641433974 : check e605641433974 [[],[]] .chain = true := by decide
def e605641434030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e605641434030 : Closed e605641434030 ∧ code e605641434030 = 2804664689582 := by decide
theorem cert_e605641434030 : check e605641434030 [[],[]] .chain = true := by decide
def e605641434042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e605641434042 : Closed e605641434042 ∧ code e605641434042 = 2804664689594 := by decide
theorem cert_e605641434042 : check e605641434042 [[],[]] .chain = true := by decide
def e605641434070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e605641434070 : Closed e605641434070 ∧ code e605641434070 = 2804664689622 := by decide
theorem cert_e605641434070 : check e605641434070 [[],[]] .chain = true := by decide
def e605641434074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e605641434074 : Closed e605641434074 ∧ code e605641434074 = 2804664689626 := by decide
theorem cert_e605641434074 : check e605641434074 [[],[]] .chain = true := by decide
def e605641434798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605641434798 : Closed e605641434798 ∧ code e605641434798 = 2804664690350 := by decide
theorem cert_e605641434798 : check e605641434798 [[],[]] .chain = true := by decide
def e605641434810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605641434810 : Closed e605641434810 ∧ code e605641434810 = 2804664690362 := by decide
theorem cert_e605641434810 : check e605641434810 [[],[]] .chain = true := by decide
def e605641434858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605641434858 : Closed e605641434858 ∧ code e605641434858 = 2804664690410 := by decide
theorem cert_e605641434858 : check e605641434858 [[],[]] .chain = true := by decide
def e605641435050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605641435050 : Closed e605641435050 ∧ code e605641435050 = 2804664690602 := by decide
theorem cert_e605641435050 : check e605641435050 [[],[]] .chain = true := by decide
def e605641435182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605641435182 : Closed e605641435182 ∧ code e605641435182 = 2804664690734 := by decide
theorem cert_e605641435182 : check e605641435182 [[],[]] .chain = true := by decide
def e605641435374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605641435374 : Closed e605641435374 ∧ code e605641435374 = 2804664690926 := by decide
theorem cert_e605641435374 : check e605641435374 [[],[]] .chain = true := by decide
def e605641435382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605641435382 : Closed e605641435382 ∧ code e605641435382 = 2804664690934 := by decide
theorem cert_e605641435382 : check e605641435382 [[],[]] .chain = true := by decide
def e605641435566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605641435566 : Closed e605641435566 ∧ code e605641435566 = 2804664691118 := by decide
theorem cert_e605641435566 : check e605641435566 [[],[]] .chain = true := by decide
def e605641435578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605641435578 : Closed e605641435578 ∧ code e605641435578 = 2804664691130 := by decide
theorem cert_e605641435578 : check e605641435578 [[],[]] .chain = true := by decide
def e605641435626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605641435626 : Closed e605641435626 ∧ code e605641435626 = 2804664691178 := by decide
theorem cert_e605641435626 : check e605641435626 [[],[]] .chain = true := by decide
def e605641435758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605641435758 : Closed e605641435758 ∧ code e605641435758 = 2804664691310 := by decide
theorem cert_e605641435758 : check e605641435758 [[],[]] .chain = true := by decide
def e605641435770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605641435770 : Closed e605641435770 ∧ code e605641435770 = 2804664691322 := by decide
theorem cert_e605641435770 : check e605641435770 [[],[]] .chain = true := by decide
def e605641435934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605641435934 : Closed e605641435934 ∧ code e605641435934 = 2804664691486 := by decide
theorem cert_e605641435934 : check e605641435934 [[],[]] .chain = true := by decide
def e605641436034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e605641436034 : Closed e605641436034 ∧ code e605641436034 = 2804664691586 := by decide
theorem cert_e605641436034 : check e605641436034 [[],[]] .chain = true := by decide
def e605641436046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605641436046 : Closed e605641436046 ∧ code e605641436046 = 2804664691598 := by decide
theorem cert_e605641436046 : check e605641436046 [[],[]] .chain = true := by decide
def e605641436058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605641436058 : Closed e605641436058 ∧ code e605641436058 = 2804664691610 := by decide
theorem cert_e605641436058 : check e605641436058 [[],[]] .chain = true := by decide
def e605641436270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605641436270 : Closed e605641436270 ∧ code e605641436270 = 2804664691822 := by decide
theorem cert_e605641436270 : check e605641436270 [[],[]] .chain = true := by decide
def e605641436282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605641436282 : Closed e605641436282 ∧ code e605641436282 = 2804664691834 := by decide
theorem cert_e605641436282 : check e605641436282 [[],[]] .chain = true := by decide
def e605641436446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605641436446 : Closed e605641436446 ∧ code e605641436446 = 2804664691998 := by decide
theorem cert_e605641436446 : check e605641436446 [[],[]] .chain = true := by decide
def e605641436614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605641436614 : Closed e605641436614 ∧ code e605641436614 = 2804664692166 := by decide
theorem cert_e605641436614 : check e605641436614 [[],[]] .chain = true := by decide
def e605641436682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605641436682 : Closed e605641436682 ∧ code e605641436682 = 2804664692234 := by decide
theorem cert_e605641436682 : check e605641436682 [[],[]] .chain = true := by decide
def e605641436726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605641436726 : Closed e605641436726 ∧ code e605641436726 = 2804664692278 := by decide
theorem cert_e605641436726 : check e605641436726 [[],[]] .chain = true := by decide
def e605641436730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605641436730 : Closed e605641436730 ∧ code e605641436730 = 2804664692282 := by decide
theorem cert_e605641436730 : check e605641436730 [[],[]] .chain = true := by decide
def e605641436778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605641436778 : Closed e605641436778 ∧ code e605641436778 = 2804664692330 := by decide
theorem cert_e605641436778 : check e605641436778 [[],[]] .chain = true := by decide
def e605641436802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605641436802 : Closed e605641436802 ∧ code e605641436802 = 2804664692354 := by decide
theorem cert_e605641436802 : check e605641436802 [[],[]] .chain = true := by decide
def e605641436814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605641436814 : Closed e605641436814 ∧ code e605641436814 = 2804664692366 := by decide
theorem cert_e605641436814 : check e605641436814 [[],[]] .chain = true := by decide
def e605641436826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605641436826 : Closed e605641436826 ∧ code e605641436826 = 2804664692378 := by decide
theorem cert_e605641436826 : check e605641436826 [[],[]] .chain = true := by decide
def e605641436870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605641436870 : Closed e605641436870 ∧ code e605641436870 = 2804664692422 := by decide
theorem cert_e605641436870 : check e605641436870 [[],[]] .chain = true := by decide
def e605641437270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e605641437270 : Closed e605641437270 ∧ code e605641437270 = 2804664692822 := by decide
theorem cert_e605641437270 : check e605641437270 [[],[]] .chain = true := by decide
def e605641437274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e605641437274 : Closed e605641437274 ∧ code e605641437274 = 2804664692826 := by decide
theorem cert_e605641437274 : check e605641437274 [[],[]] .chain = true := by decide
def e605641437622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e605641437622 : Closed e605641437622 ∧ code e605641437622 = 2804664693174 := by decide
theorem cert_e605641437622 : check e605641437622 [[],[]] .chain = true := by decide
def e605641437654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e605641437654 : Closed e605641437654 ∧ code e605641437654 = 2804664693206 := by decide
theorem cert_e605641437654 : check e605641437654 [[],[]] .chain = true := by decide
def e605641437658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e605641437658 : Closed e605641437658 ∧ code e605641437658 = 2804664693210 := by decide
theorem cert_e605641437658 : check e605641437658 [[],[]] .chain = true := by decide
def e605641438038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e605641438038 : Closed e605641438038 ∧ code e605641438038 = 2804664693590 := by decide
theorem cert_e605641438038 : check e605641438038 [[],[]] .chain = true := by decide
def e605641438042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e605641438042 : Closed e605641438042 ∧ code e605641438042 = 2804664693594 := by decide
theorem cert_e605641438042 : check e605641438042 [[],[]] .chain = true := by decide
def e605641438058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e605641438058 : Closed e605641438058 ∧ code e605641438058 = 2804664693610 := by decide
theorem cert_e605641438058 : check e605641438058 [[],[]] .chain = true := by decide
def e605641438122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605641438122 : Closed e605641438122 ∧ code e605641438122 = 2804664693674 := by decide
theorem cert_e605641438122 : check e605641438122 [[],[]] .chain = true := by decide
def e605641438230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605641438230 : Closed e605641438230 ∧ code e605641438230 = 2804664693782 := by decide
theorem cert_e605641438230 : check e605641438230 [[],[]] .chain = true := by decide
def e605641438326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e605641438326 : Closed e605641438326 ∧ code e605641438326 = 2804664693878 := by decide
theorem cert_e605641438326 : check e605641438326 [[],[]] .chain = true := by decide
def e605641438422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605641438422 : Closed e605641438422 ∧ code e605641438422 = 2804664693974 := by decide
theorem cert_e605641438422 : check e605641438422 [[],[]] .chain = true := by decide
def e605641438426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605641438426 : Closed e605641438426 ∧ code e605641438426 = 2804664693978 := by decide
theorem cert_e605641438426 : check e605641438426 [[],[]] .chain = true := by decide
def e605641438442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605641438442 : Closed e605641438442 ∧ code e605641438442 = 2804664693994 := by decide
theorem cert_e605641438442 : check e605641438442 [[],[]] .chain = true := by decide
def e605641438518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605641438518 : Closed e605641438518 ∧ code e605641438518 = 2804664694070 := by decide
theorem cert_e605641438518 : check e605641438518 [[],[]] .chain = true := by decide
def e605641438522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605641438522 : Closed e605641438522 ∧ code e605641438522 = 2804664694074 := by decide
theorem cert_e605641438522 : check e605641438522 [[],[]] .chain = true := by decide
def e605641438594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e605641438594 : Closed e605641438594 ∧ code e605641438594 = 2804664694146 := by decide
theorem cert_e605641438594 : check e605641438594 [[],[]] .chain = true := by decide
def e605641438606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e605641438606 : Closed e605641438606 ∧ code e605641438606 = 2804664694158 := by decide
theorem cert_e605641438606 : check e605641438606 [[],[]] .chain = true := by decide
def e605641438618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605641438618 : Closed e605641438618 ∧ code e605641438618 = 2804664694170 := by decide
theorem cert_e605641438618 : check e605641438618 [[],[]] .chain = true := by decide
def e605641438730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605641438730 : Closed e605641438730 ∧ code e605641438730 = 2804664694282 := by decide
theorem cert_e605641438730 : check e605641438730 [[],[]] .chain = true := by decide
def e605641438774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605641438774 : Closed e605641438774 ∧ code e605641438774 = 2804664694326 := by decide
theorem cert_e605641438774 : check e605641438774 [[],[]] .chain = true := by decide
def e605641438778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605641438778 : Closed e605641438778 ∧ code e605641438778 = 2804664694330 := by decide
theorem cert_e605641438778 : check e605641438778 [[],[]] .chain = true := by decide
def e605641438826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605641438826 : Closed e605641438826 ∧ code e605641438826 = 2804664694378 := by decide
theorem cert_e605641438826 : check e605641438826 [[],[]] .chain = true := by decide
def e605641438850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605641438850 : Closed e605641438850 ∧ code e605641438850 = 2804664694402 := by decide
theorem cert_e605641438850 : check e605641438850 [[],[]] .chain = true := by decide
def e605641438862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605641438862 : Closed e605641438862 ∧ code e605641438862 = 2804664694414 := by decide
theorem cert_e605641438862 : check e605641438862 [[],[]] .chain = true := by decide
def e605641438874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605641438874 : Closed e605641438874 ∧ code e605641438874 = 2804664694426 := by decide
theorem cert_e605641438874 : check e605641438874 [[],[]] .chain = true := by decide
def e605641438918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605641438918 : Closed e605641438918 ∧ code e605641438918 = 2804664694470 := by decide
theorem cert_e605641438918 : check e605641438918 [[],[]] .chain = true := by decide
def e605641442542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e605641442542 : Closed e605641442542 ∧ code e605641442542 = 2804664698094 := by decide
theorem cert_e605641442542 : check e605641442542 [[],[]] .chain = true := by decide
def e605641442550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e605641442550 : Closed e605641442550 ∧ code e605641442550 = 2804664698102 := by decide
theorem cert_e605641442550 : check e605641442550 [[],[]] .chain = true := by decide
def e605641445102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e605641445102 : Closed e605641445102 ∧ code e605641445102 = 2804664700654 := by decide
theorem cert_e605641445102 : check e605641445102 [[],[]] .chain = true := by decide
def e605641445110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e605641445110 : Closed e605641445110 ∧ code e605641445110 = 2804664700662 := by decide
theorem cert_e605641445110 : check e605641445110 [[],[]] .chain = true := by decide
def e605641445230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e605641445230 : Closed e605641445230 ∧ code e605641445230 = 2804664700782 := by decide
theorem cert_e605641445230 : check e605641445230 [[],[]] .chain = true := by decide
def e605641445242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e605641445242 : Closed e605641445242 ∧ code e605641445242 = 2804664700794 := by decide
theorem cert_e605641445242 : check e605641445242 [[],[]] .chain = true := by decide
def e605641445302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e605641445302 : Closed e605641445302 ∧ code e605641445302 = 2804664700854 := by decide
theorem cert_e605641445302 : check e605641445302 [[],[]] .chain = true := by decide
def e605641445306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e605641445306 : Closed e605641445306 ∧ code e605641445306 = 2804664700858 := by decide
theorem cert_e605641445306 : check e605641445306 [[],[]] .chain = true := by decide
def e605641448686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e605641448686 : Closed e605641448686 ∧ code e605641448686 = 2804664704238 := by decide
theorem cert_e605641448686 : check e605641448686 [[],[]] .chain = true := by decide
def e605641448694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e605641448694 : Closed e605641448694 ∧ code e605641448694 = 2804664704246 := by decide
theorem cert_e605641448694 : check e605641448694 [[],[]] .chain = true := by decide
def e605641449078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e605641449078 : Closed e605641449078 ∧ code e605641449078 = 2804664704630 := by decide
theorem cert_e605641449078 : check e605641449078 [[],[]] .chain = true := by decide
def e605641452910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e605641452910 : Closed e605641452910 ∧ code e605641452910 = 2804664708462 := by decide
theorem cert_e605641452910 : check e605641452910 [[],[]] .chain = true := by decide
def e605641452918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e605641452918 : Closed e605641452918 ∧ code e605641452918 = 2804664708470 := by decide
theorem cert_e605641452918 : check e605641452918 [[],[]] .chain = true := by decide
def e605641452974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e605641452974 : Closed e605641452974 ∧ code e605641452974 = 2804664708526 := by decide
theorem cert_e605641452974 : check e605641452974 [[],[]] .chain = true := by decide
def e605641452986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e605641452986 : Closed e605641452986 ∧ code e605641452986 = 2804664708538 := by decide
theorem cert_e605641452986 : check e605641452986 [[],[]] .chain = true := by decide
def e605641453014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e605641453014 : Closed e605641453014 ∧ code e605641453014 = 2804664708566 := by decide
theorem cert_e605641453014 : check e605641453014 [[],[]] .chain = true := by decide
def e605641453018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e605641453018 : Closed e605641453018 ∧ code e605641453018 = 2804664708570 := by decide
theorem cert_e605641453018 : check e605641453018 [[],[]] .chain = true := by decide
def e605641453230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e605641453230 : Closed e605641453230 ∧ code e605641453230 = 2804664708782 := by decide
theorem cert_e605641453230 : check e605641453230 [[],[]] .chain = true := by decide
def e605641453242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e605641453242 : Closed e605641453242 ∧ code e605641453242 = 2804664708794 := by decide
theorem cert_e605641453242 : check e605641453242 [[],[]] .chain = true := by decide
def e605641453290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e605641453290 : Closed e605641453290 ∧ code e605641453290 = 2804664708842 := by decide
theorem cert_e605641453290 : check e605641453290 [[],[]] .chain = true := by decide
def e605641453398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e605641453398 : Closed e605641453398 ∧ code e605641453398 = 2804664708950 := by decide
theorem cert_e605641453398 : check e605641453398 [[],[]] .chain = true := by decide
def e605641453402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e605641453402 : Closed e605641453402 ∧ code e605641453402 = 2804664708954 := by decide
theorem cert_e605641453402 : check e605641453402 [[],[]] .chain = true := by decide
def e605641453418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e605641453418 : Closed e605641453418 ∧ code e605641453418 = 2804664708970 := by decide
theorem cert_e605641453418 : check e605641453418 [[],[]] .chain = true := by decide
def e605641454446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e605641454446 : Closed e605641454446 ∧ code e605641454446 = 2804664709998 := by decide
theorem cert_e605641454446 : check e605641454446 [[],[]] .chain = true := by decide
def e605641454454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e605641454454 : Closed e605641454454 ∧ code e605641454454 = 2804664710006 := by decide
theorem cert_e605641454454 : check e605641454454 [[],[]] .chain = true := by decide
def e605641454510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e605641454510 : Closed e605641454510 ∧ code e605641454510 = 2804664710062 := by decide
theorem cert_e605641454510 : check e605641454510 [[],[]] .chain = true := by decide
def e605641454522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e605641454522 : Closed e605641454522 ∧ code e605641454522 = 2804664710074 := by decide
theorem cert_e605641454522 : check e605641454522 [[],[]] .chain = true := by decide
def e605641454550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e605641454550 : Closed e605641454550 ∧ code e605641454550 = 2804664710102 := by decide
theorem cert_e605641454550 : check e605641454550 [[],[]] .chain = true := by decide
def e605641454554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e605641454554 : Closed e605641454554 ∧ code e605641454554 = 2804664710106 := by decide
theorem cert_e605641454554 : check e605641454554 [[],[]] .chain = true := by decide
def e605641454830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e605641454830 : Closed e605641454830 ∧ code e605641454830 = 2804664710382 := by decide
theorem cert_e605641454830 : check e605641454830 [[],[]] .chain = true := by decide
def e605641454838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e605641454838 : Closed e605641454838 ∧ code e605641454838 = 2804664710390 := by decide
theorem cert_e605641454838 : check e605641454838 [[],[]] .chain = true := by decide
def e605641455214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e605641455214 : Closed e605641455214 ∧ code e605641455214 = 2804664710766 := by decide
theorem cert_e605641455214 : check e605641455214 [[],[]] .chain = true := by decide
def e605641455226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e605641455226 : Closed e605641455226 ∧ code e605641455226 = 2804664710778 := by decide
theorem cert_e605641455226 : check e605641455226 [[],[]] .chain = true := by decide
def e605641455414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e605641455414 : Closed e605641455414 ∧ code e605641455414 = 2804664710966 := by decide
theorem cert_e605641455414 : check e605641455414 [[],[]] .chain = true := by decide
def e605641455418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e605641455418 : Closed e605641455418 ∧ code e605641455418 = 2804664710970 := by decide
theorem cert_e605641455418 : check e605641455418 [[],[]] .chain = true := by decide
def e605641455662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e605641455662 : Closed e605641455662 ∧ code e605641455662 = 2804664711214 := by decide
theorem cert_e605641455662 : check e605641455662 [[],[]] .chain = true := by decide
def e605641455854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e605641455854 : Closed e605641455854 ∧ code e605641455854 = 2804664711406 := by decide
theorem cert_e605641455854 : check e605641455854 [[],[]] .chain = true := by decide
def e605641455862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e605641455862 : Closed e605641455862 ∧ code e605641455862 = 2804664711414 := by decide
theorem cert_e605641455862 : check e605641455862 [[],[]] .chain = true := by decide
def e605641456046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e605641456046 : Closed e605641456046 ∧ code e605641456046 = 2804664711598 := by decide
theorem cert_e605641456046 : check e605641456046 [[],[]] .chain = true := by decide
def e605641456058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605641456058 : Closed e605641456058 ∧ code e605641456058 = 2804664711610 := by decide
theorem cert_e605641456058 : check e605641456058 [[],[]] .chain = true := by decide
def e605641456106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605641456106 : Closed e605641456106 ∧ code e605641456106 = 2804664711658 := by decide
theorem cert_e605641456106 : check e605641456106 [[],[]] .chain = true := by decide
def e605641456238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605641456238 : Closed e605641456238 ∧ code e605641456238 = 2804664711790 := by decide
theorem cert_e605641456238 : check e605641456238 [[],[]] .chain = true := by decide
def e605641456250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605641456250 : Closed e605641456250 ∧ code e605641456250 = 2804664711802 := by decide
theorem cert_e605641456250 : check e605641456250 [[],[]] .chain = true := by decide
def e605641456414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))
theorem wire_e605641456414 : Closed e605641456414 ∧ code e605641456414 = 2804664711966 := by decide
theorem cert_e605641456414 : check e605641456414 [[],[]] .chain = true := by decide
def e605641456514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e605641456514 : Closed e605641456514 ∧ code e605641456514 = 2804664712066 := by decide
theorem cert_e605641456514 : check e605641456514 [[],[]] .chain = true := by decide
def e605641456526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))
theorem wire_e605641456526 : Closed e605641456526 ∧ code e605641456526 = 2804664712078 := by decide
theorem cert_e605641456526 : check e605641456526 [[],[]] .chain = true := by decide
def e605641456538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605641456538 : Closed e605641456538 ∧ code e605641456538 = 2804664712090 := by decide
theorem cert_e605641456538 : check e605641456538 [[],[]] .chain = true := by decide
def e605641456662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e605641456662 : Closed e605641456662 ∧ code e605641456662 = 2804664712214 := by decide
theorem cert_e605641456662 : check e605641456662 [[],[]] .chain = true := by decide
def e605641456758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e605641456758 : Closed e605641456758 ∧ code e605641456758 = 2804664712310 := by decide
theorem cert_e605641456758 : check e605641456758 [[],[]] .chain = true := by decide
def e605641456854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e605641456854 : Closed e605641456854 ∧ code e605641456854 = 2804664712406 := by decide
theorem cert_e605641456854 : check e605641456854 [[],[]] .chain = true := by decide
def e605641456858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e605641456858 : Closed e605641456858 ∧ code e605641456858 = 2804664712410 := by decide
theorem cert_e605641456858 : check e605641456858 [[],[]] .chain = true := by decide
def e605641456874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e605641456874 : Closed e605641456874 ∧ code e605641456874 = 2804664712426 := by decide
theorem cert_e605641456874 : check e605641456874 [[],[]] .chain = true := by decide
def e605641456950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e605641456950 : Closed e605641456950 ∧ code e605641456950 = 2804664712502 := by decide
theorem cert_e605641456950 : check e605641456950 [[],[]] .chain = true := by decide
def e605641456954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e605641456954 : Closed e605641456954 ∧ code e605641456954 = 2804664712506 := by decide
theorem cert_e605641456954 : check e605641456954 [[],[]] .chain = true := by decide
def e605641457026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e605641457026 : Closed e605641457026 ∧ code e605641457026 = 2804664712578 := by decide
theorem cert_e605641457026 : check e605641457026 [[],[]] .chain = true := by decide
def e605641457038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))
theorem wire_e605641457038 : Closed e605641457038 ∧ code e605641457038 = 2804664712590 := by decide
theorem cert_e605641457038 : check e605641457038 [[],[]] .chain = true := by decide
def e605641457050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e605641457050 : Closed e605641457050 ∧ code e605641457050 = 2804664712602 := by decide
theorem cert_e605641457050 : check e605641457050 [[],[]] .chain = true := by decide
def e605641458654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e605641458654 : Closed e605641458654 ∧ code e605641458654 = 2804664714206 := by decide
theorem cert_e605641458654 : check e605641458654 [[],[]] .chain = true := by decide
def e605641458670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e605641458670 : Closed e605641458670 ∧ code e605641458670 = 2804664714222 := by decide
theorem cert_e605641458670 : check e605641458670 [[],[]] .chain = true := by decide
def e605641460590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605641460590 : Closed e605641460590 ∧ code e605641460590 = 2804664716142 := by decide
theorem cert_e605641460590 : check e605641460590 [[],[]] .chain = true := by decide
def e605641460598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605641460598 : Closed e605641460598 ∧ code e605641460598 = 2804664716150 := by decide
theorem cert_e605641460598 : check e605641460598 [[],[]] .chain = true := by decide
def e605641460654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605641460654 : Closed e605641460654 ∧ code e605641460654 = 2804664716206 := by decide
theorem cert_e605641460654 : check e605641460654 [[],[]] .chain = true := by decide
def e605641460666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605641460666 : Closed e605641460666 ∧ code e605641460666 = 2804664716218 := by decide
theorem cert_e605641460666 : check e605641460666 [[],[]] .chain = true := by decide
def e605641460694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605641460694 : Closed e605641460694 ∧ code e605641460694 = 2804664716246 := by decide
theorem cert_e605641460694 : check e605641460694 [[],[]] .chain = true := by decide
def e605641460698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605641460698 : Closed e605641460698 ∧ code e605641460698 = 2804664716250 := by decide
theorem cert_e605641460698 : check e605641460698 [[],[]] .chain = true := by decide
def e605641460974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605641460974 : Closed e605641460974 ∧ code e605641460974 = 2804664716526 := by decide
theorem cert_e605641460974 : check e605641460974 [[],[]] .chain = true := by decide
def e605641460982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605641460982 : Closed e605641460982 ∧ code e605641460982 = 2804664716534 := by decide
theorem cert_e605641460982 : check e605641460982 [[],[]] .chain = true := by decide
def e605641461358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605641461358 : Closed e605641461358 ∧ code e605641461358 = 2804664716910 := by decide
theorem cert_e605641461358 : check e605641461358 [[],[]] .chain = true := by decide
def e605641461370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605641461370 : Closed e605641461370 ∧ code e605641461370 = 2804664716922 := by decide
theorem cert_e605641461370 : check e605641461370 [[],[]] .chain = true := by decide
def e605641461558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605641461558 : Closed e605641461558 ∧ code e605641461558 = 2804664717110 := by decide
theorem cert_e605641461558 : check e605641461558 [[],[]] .chain = true := by decide
def e605641461562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605641461562 : Closed e605641461562 ∧ code e605641461562 = 2804664717114 := by decide
theorem cert_e605641461562 : check e605641461562 [[],[]] .chain = true := by decide
def e605641466334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605641466334 : Closed e605641466334 ∧ code e605641466334 = 2804664721886 := by decide
theorem cert_e605641466334 : check e605641466334 [[],[]] .chain = true := by decide
def e605641466358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605641466358 : Closed e605641466358 ∧ code e605641466358 = 2804664721910 := by decide
theorem cert_e605641466358 : check e605641466358 [[],[]] .chain = true := by decide
def e605641467310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605641467310 : Closed e605641467310 ∧ code e605641467310 = 2804664722862 := by decide
theorem cert_e605641467310 : check e605641467310 [[],[]] .chain = true := by decide
def e605641467322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605641467322 : Closed e605641467322 ∧ code e605641467322 = 2804664722874 := by decide
theorem cert_e605641467322 : check e605641467322 [[],[]] .chain = true := by decide
def e605641467370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605641467370 : Closed e605641467370 ∧ code e605641467370 = 2804664722922 := by decide
theorem cert_e605641467370 : check e605641467370 [[],[]] .chain = true := by decide
end Blc.Floor41
