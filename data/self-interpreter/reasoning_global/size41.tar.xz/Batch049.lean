import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e601537513274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e601537513274 : Closed e601537513274 ∧ code e601537513274 = 2800560768826 := by decide
theorem cert_e601537513274 : check e601537513274 [[]] .width = true := by decide
def e601537516970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e601537516970 : Closed e601537516970 ∧ code e601537516970 = 2800560772522 := by decide
theorem cert_e601537516970 : check e601537516970 [[]] .width = true := by decide
def e601537517066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e601537517066 : Closed e601537517066 ∧ code e601537517066 = 2800560772618 := by decide
theorem cert_e601537517066 : check e601537517066 [[]] .width = true := by decide
def e601537517162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e601537517162 : Closed e601537517162 ∧ code e601537517162 = 2800560772714 := by decide
theorem cert_e601537517162 : check e601537517162 [[]] .width = true := by decide
def e601537517186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e601537517186 : Closed e601537517186 ∧ code e601537517186 = 2800560772738 := by decide
theorem cert_e601537517186 : check e601537517186 [[]] .width = true := by decide
def e601537517210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e601537517210 : Closed e601537517210 ∧ code e601537517210 = 2800560772762 := by decide
theorem cert_e601537517210 : check e601537517210 [[]] .width = true := by decide
def e601537517594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601537517594 : Closed e601537517594 ∧ code e601537517594 = 2800560773146 := by decide
theorem cert_e601537517594 : check e601537517594 [[]] .width = true := by decide
def e601537517686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e601537517686 : Closed e601537517686 ∧ code e601537517686 = 2800560773238 := by decide
theorem cert_e601537517686 : check e601537517686 [[]] .width = true := by decide
def e601537517930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e601537517930 : Closed e601537517930 ∧ code e601537517930 = 2800560773482 := by decide
theorem cert_e601537517930 : check e601537517930 [[]] .width = true := by decide
def e601537517954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e601537517954 : Closed e601537517954 ∧ code e601537517954 = 2800560773506 := by decide
theorem cert_e601537517954 : check e601537517954 [[]] .width = true := by decide
def e601537517978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e601537517978 : Closed e601537517978 ∧ code e601537517978 = 2800560773530 := by decide
theorem cert_e601537517978 : check e601537517978 [[]] .width = true := by decide
def e601537867974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601537867974 : Closed e601537867974 ∧ code e601537867974 = 2800561123526 := by decide
theorem cert_e601537867974 : check e601537867974 [[]] .width = true := by decide
def e601537892550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601537892550 : Closed e601537892550 ∧ code e601537892550 = 2800561148102 := by decide
theorem cert_e601537892550 : check e601537892550 [[]] .width = true := by decide
def e601538181146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601538181146 : Closed e601538181146 ∧ code e601538181146 = 2800561436698 := by decide
theorem cert_e601538181146 : check e601538181146 [[]] .width = true := by decide
def e601538216134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601538216134 : Closed e601538216134 ∧ code e601538216134 = 2800561471686 := by decide
theorem cert_e601538216134 : check e601538216134 [[]] .width = true := by decide
def e601538267162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601538267162 : Closed e601538267162 ∧ code e601538267162 = 2800561522714 := by decide
theorem cert_e601538267162 : check e601538267162 [[]] .width = true := by decide
def e601538273306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601538273306 : Closed e601538273306 ∧ code e601538273306 = 2800561528858 := by decide
theorem cert_e601538273306 : check e601538273306 [[]] .width = true := by decide
def e601538273398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601538273398 : Closed e601538273398 ∧ code e601538273398 = 2800561528950 := by decide
theorem cert_e601538273398 : check e601538273398 [[]] .width = true := by decide
def e601538273642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601538273642 : Closed e601538273642 ∧ code e601538273642 = 2800561529194 := by decide
theorem cert_e601538273642 : check e601538273642 [[]] .width = true := by decide
def e601538273690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601538273690 : Closed e601538273690 ∧ code e601538273690 = 2800561529242 := by decide
theorem cert_e601538273690 : check e601538273690 [[]] .width = true := by decide
def e601538277574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601538277574 : Closed e601538277574 ∧ code e601538277574 = 2800561533126 := by decide
theorem cert_e601538277574 : check e601538277574 [[]] .width = true := by decide
def e601538279450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601538279450 : Closed e601538279450 ∧ code e601538279450 = 2800561535002 := by decide
theorem cert_e601538279450 : check e601538279450 [[]] .width = true := by decide
def e601538285766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601538285766 : Closed e601538285766 ∧ code e601538285766 = 2800561541318 := by decide
theorem cert_e601538285766 : check e601538285766 [[]] .width = true := by decide
def e601538291738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601538291738 : Closed e601538291738 ∧ code e601538291738 = 2800561547290 := by decide
theorem cert_e601538291738 : check e601538291738 [[]] .width = true := by decide
def e601538297882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601538297882 : Closed e601538297882 ∧ code e601538297882 = 2800561553434 := by decide
theorem cert_e601538297882 : check e601538297882 [[]] .width = true := by decide
def e601538297974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601538297974 : Closed e601538297974 ∧ code e601538297974 = 2800561553526 := by decide
theorem cert_e601538297974 : check e601538297974 [[]] .width = true := by decide
def e601538298218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601538298218 : Closed e601538298218 ∧ code e601538298218 = 2800561553770 := by decide
theorem cert_e601538298218 : check e601538298218 [[]] .width = true := by decide
def e601538298266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601538298266 : Closed e601538298266 ∧ code e601538298266 = 2800561553818 := by decide
theorem cert_e601538298266 : check e601538298266 [[]] .width = true := by decide
def e601538298350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e601538298350 : Closed e601538298350 ∧ code e601538298350 = 2800561553902 := by decide
theorem cert_e601538298350 : check e601538298350 [[]] .width = true := by decide
def e601538299274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e601538299274 : Closed e601538299274 ∧ code e601538299274 = 2800561554826 := by decide
theorem cert_e601538299274 : check e601538299274 [[]] .width = true := by decide
def e601538299298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e601538299298 : Closed e601538299298 ∧ code e601538299298 = 2800561554850 := by decide
theorem cert_e601538299298 : check e601538299298 [[]] .width = true := by decide
def e601538299318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e601538299318 : Closed e601538299318 ∧ code e601538299318 = 2800561554870 := by decide
theorem cert_e601538299318 : check e601538299318 [[]] .width = true := by decide
def e601538299350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e601538299350 : Closed e601538299350 ∧ code e601538299350 = 2800561554902 := by decide
theorem cert_e601538299350 : check e601538299350 [[]] .width = true := by decide
def e601538299354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e601538299354 : Closed e601538299354 ∧ code e601538299354 = 2800561554906 := by decide
theorem cert_e601538299354 : check e601538299354 [[]] .width = true := by decide
def e601538299406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e601538299406 : Closed e601538299406 ∧ code e601538299406 = 2800561554958 := by decide
theorem cert_e601538299406 : check e601538299406 [[]] .width = true := by decide
def e601538299418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601538299418 : Closed e601538299418 ∧ code e601538299418 = 2800561554970 := by decide
theorem cert_e601538299418 : check e601538299418 [[]] .width = true := by decide
def e601538299490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e601538299490 : Closed e601538299490 ∧ code e601538299490 = 2800561555042 := by decide
theorem cert_e601538299490 : check e601538299490 [[]] .width = true := by decide
def e601538299510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e601538299510 : Closed e601538299510 ∧ code e601538299510 = 2800561555062 := by decide
theorem cert_e601538299510 : check e601538299510 [[]] .width = true := by decide
def e601538299702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e601538299702 : Closed e601538299702 ∧ code e601538299702 = 2800561555254 := by decide
theorem cert_e601538299702 : check e601538299702 [[]] .width = true := by decide
def e601538299706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e601538299706 : Closed e601538299706 ∧ code e601538299706 = 2800561555258 := by decide
theorem cert_e601538299706 : check e601538299706 [[]] .width = true := by decide
def e601538303402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e601538303402 : Closed e601538303402 ∧ code e601538303402 = 2800561558954 := by decide
theorem cert_e601538303402 : check e601538303402 [[]] .width = true := by decide
def e601538303498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e601538303498 : Closed e601538303498 ∧ code e601538303498 = 2800561559050 := by decide
theorem cert_e601538303498 : check e601538303498 [[]] .width = true := by decide
def e601538303594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e601538303594 : Closed e601538303594 ∧ code e601538303594 = 2800561559146 := by decide
theorem cert_e601538303594 : check e601538303594 [[]] .width = true := by decide
def e601538303618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e601538303618 : Closed e601538303618 ∧ code e601538303618 = 2800561559170 := by decide
theorem cert_e601538303618 : check e601538303618 [[]] .width = true := by decide
def e601538303642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e601538303642 : Closed e601538303642 ∧ code e601538303642 = 2800561559194 := by decide
theorem cert_e601538303642 : check e601538303642 [[]] .width = true := by decide
def e601538304026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601538304026 : Closed e601538304026 ∧ code e601538304026 = 2800561559578 := by decide
theorem cert_e601538304026 : check e601538304026 [[]] .width = true := by decide
def e601538304118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e601538304118 : Closed e601538304118 ∧ code e601538304118 = 2800561559670 := by decide
theorem cert_e601538304118 : check e601538304118 [[]] .width = true := by decide
def e601538304362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e601538304362 : Closed e601538304362 ∧ code e601538304362 = 2800561559914 := by decide
theorem cert_e601538304362 : check e601538304362 [[]] .width = true := by decide
def e601538304386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e601538304386 : Closed e601538304386 ∧ code e601538304386 = 2800561559938 := by decide
theorem cert_e601538304386 : check e601538304386 [[]] .width = true := by decide
def e601538304410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e601538304410 : Closed e601538304410 ∧ code e601538304410 = 2800561559962 := by decide
theorem cert_e601538304410 : check e601538304410 [[]] .width = true := by decide
def e601548054554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601548054554 : Closed e601548054554 ∧ code e601548054554 = 2800571310106 := by decide
theorem cert_e601548054554 : check e601548054554 [[]] .width = true := by decide
def e601548054646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601548054646 : Closed e601548054646 ∧ code e601548054646 = 2800571310198 := by decide
theorem cert_e601548054646 : check e601548054646 [[]] .width = true := by decide
def e601548054890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601548054890 : Closed e601548054890 ∧ code e601548054890 = 2800571310442 := by decide
theorem cert_e601548054890 : check e601548054890 [[]] .width = true := by decide
def e601548054938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601548054938 : Closed e601548054938 ∧ code e601548054938 = 2800571310490 := by decide
theorem cert_e601548054938 : check e601548054938 [[]] .width = true := by decide
def e601548087322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601548087322 : Closed e601548087322 ∧ code e601548087322 = 2800571342874 := by decide
theorem cert_e601548087322 : check e601548087322 [[]] .width = true := by decide
def e601548087414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601548087414 : Closed e601548087414 ∧ code e601548087414 = 2800571342966 := by decide
theorem cert_e601548087414 : check e601548087414 [[]] .width = true := by decide
def e601548087658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601548087658 : Closed e601548087658 ∧ code e601548087658 = 2800571343210 := by decide
theorem cert_e601548087658 : check e601548087658 [[]] .width = true := by decide
def e601548087706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601548087706 : Closed e601548087706 ∧ code e601548087706 = 2800571343258 := by decide
theorem cert_e601548087706 : check e601548087706 [[]] .width = true := by decide
def e601549985818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601549985818 : Closed e601549985818 ∧ code e601549985818 = 2800573241370 := by decide
theorem cert_e601549985818 : check e601549985818 [[]] .width = true := by decide
def e601550053402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550053402 : Closed e601550053402 ∧ code e601550053402 = 2800573308954 := by decide
theorem cert_e601550053402 : check e601550053402 [[]] .width = true := by decide
def e601550053494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601550053494 : Closed e601550053494 ∧ code e601550053494 = 2800573309046 := by decide
theorem cert_e601550053494 : check e601550053494 [[]] .width = true := by decide
def e601550053738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601550053738 : Closed e601550053738 ∧ code e601550053738 = 2800573309290 := by decide
theorem cert_e601550053738 : check e601550053738 [[]] .width = true := by decide
def e601550053786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601550053786 : Closed e601550053786 ∧ code e601550053786 = 2800573309338 := by decide
theorem cert_e601550053786 : check e601550053786 [[]] .width = true := by decide
def e601550063642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550063642 : Closed e601550063642 ∧ code e601550063642 = 2800573319194 := by decide
theorem cert_e601550063642 : check e601550063642 [[]] .width = true := by decide
def e601550069786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550069786 : Closed e601550069786 ∧ code e601550069786 = 2800573325338 := by decide
theorem cert_e601550069786 : check e601550069786 [[]] .width = true := by decide
def e601550069878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601550069878 : Closed e601550069878 ∧ code e601550069878 = 2800573325430 := by decide
theorem cert_e601550069878 : check e601550069878 [[]] .width = true := by decide
def e601550070122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601550070122 : Closed e601550070122 ∧ code e601550070122 = 2800573325674 := by decide
theorem cert_e601550070122 : check e601550070122 [[]] .width = true := by decide
def e601550070170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601550070170 : Closed e601550070170 ∧ code e601550070170 = 2800573325722 := by decide
theorem cert_e601550070170 : check e601550070170 [[]] .width = true := by decide
def e601550074054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601550074054 : Closed e601550074054 ∧ code e601550074054 = 2800573329606 := by decide
theorem cert_e601550074054 : check e601550074054 [[]] .width = true := by decide
def e601550075930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550075930 : Closed e601550075930 ∧ code e601550075930 = 2800573331482 := by decide
theorem cert_e601550075930 : check e601550075930 [[]] .width = true := by decide
def e601550084122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550084122 : Closed e601550084122 ∧ code e601550084122 = 2800573339674 := by decide
theorem cert_e601550084122 : check e601550084122 [[]] .width = true := by decide
def e601550104602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550104602 : Closed e601550104602 ∧ code e601550104602 = 2800573360154 := by decide
theorem cert_e601550104602 : check e601550104602 [[]] .width = true := by decide
def e601550129178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550129178 : Closed e601550129178 ∧ code e601550129178 = 2800573384730 := by decide
theorem cert_e601550129178 : check e601550129178 [[]] .width = true := by decide
def e601550135322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550135322 : Closed e601550135322 ∧ code e601550135322 = 2800573390874 := by decide
theorem cert_e601550135322 : check e601550135322 [[]] .width = true := by decide
def e601550135414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601550135414 : Closed e601550135414 ∧ code e601550135414 = 2800573390966 := by decide
theorem cert_e601550135414 : check e601550135414 [[]] .width = true := by decide
def e601550135658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601550135658 : Closed e601550135658 ∧ code e601550135658 = 2800573391210 := by decide
theorem cert_e601550135658 : check e601550135658 [[]] .width = true := by decide
def e601550135706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601550135706 : Closed e601550135706 ∧ code e601550135706 = 2800573391258 := by decide
theorem cert_e601550135706 : check e601550135706 [[]] .width = true := by decide
def e601550139590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601550139590 : Closed e601550139590 ∧ code e601550139590 = 2800573395142 := by decide
theorem cert_e601550139590 : check e601550139590 [[]] .width = true := by decide
def e601550141466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550141466 : Closed e601550141466 ∧ code e601550141466 = 2800573397018 := by decide
theorem cert_e601550141466 : check e601550141466 [[]] .width = true := by decide
def e601550147782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601550147782 : Closed e601550147782 ∧ code e601550147782 = 2800573403334 := by decide
theorem cert_e601550147782 : check e601550147782 [[]] .width = true := by decide
def e601550153754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550153754 : Closed e601550153754 ∧ code e601550153754 = 2800573409306 := by decide
theorem cert_e601550153754 : check e601550153754 [[]] .width = true := by decide
def e601550182426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550182426 : Closed e601550182426 ∧ code e601550182426 = 2800573437978 := by decide
theorem cert_e601550182426 : check e601550182426 [[]] .width = true := by decide
def e601550186522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550186522 : Closed e601550186522 ∧ code e601550186522 = 2800573442074 := by decide
theorem cert_e601550186522 : check e601550186522 [[]] .width = true := by decide
def e601550256154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550256154 : Closed e601550256154 ∧ code e601550256154 = 2800573511706 := by decide
theorem cert_e601550256154 : check e601550256154 [[]] .width = true := by decide
def e601550340294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601550340294 : Closed e601550340294 ∧ code e601550340294 = 2800573595846 := by decide
theorem cert_e601550340294 : check e601550340294 [[]] .width = true := by decide
def e601550446618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550446618 : Closed e601550446618 ∧ code e601550446618 = 2800573702170 := by decide
theorem cert_e601550446618 : check e601550446618 [[]] .width = true := by decide
def e601550446710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601550446710 : Closed e601550446710 ∧ code e601550446710 = 2800573702262 := by decide
theorem cert_e601550446710 : check e601550446710 [[]] .width = true := by decide
def e601550446954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601550446954 : Closed e601550446954 ∧ code e601550446954 = 2800573702506 := by decide
theorem cert_e601550446954 : check e601550446954 [[]] .width = true := by decide
def e601550447002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601550447002 : Closed e601550447002 ∧ code e601550447002 = 2800573702554 := by decide
theorem cert_e601550447002 : check e601550447002 [[]] .width = true := by decide
def e601550456858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550456858 : Closed e601550456858 ∧ code e601550456858 = 2800573712410 := by decide
theorem cert_e601550456858 : check e601550456858 [[]] .width = true := by decide
def e601550463002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550463002 : Closed e601550463002 ∧ code e601550463002 = 2800573718554 := by decide
theorem cert_e601550463002 : check e601550463002 [[]] .width = true := by decide
def e601550463094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601550463094 : Closed e601550463094 ∧ code e601550463094 = 2800573718646 := by decide
theorem cert_e601550463094 : check e601550463094 [[]] .width = true := by decide
def e601550463338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601550463338 : Closed e601550463338 ∧ code e601550463338 = 2800573718890 := by decide
theorem cert_e601550463338 : check e601550463338 [[]] .width = true := by decide
def e601550463386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601550463386 : Closed e601550463386 ∧ code e601550463386 = 2800573718938 := by decide
theorem cert_e601550463386 : check e601550463386 [[]] .width = true := by decide
def e601550467270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601550467270 : Closed e601550467270 ∧ code e601550467270 = 2800573722822 := by decide
theorem cert_e601550467270 : check e601550467270 [[]] .width = true := by decide
def e601550469146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550469146 : Closed e601550469146 ∧ code e601550469146 = 2800573724698 := by decide
theorem cert_e601550469146 : check e601550469146 [[]] .width = true := by decide
def e601550477338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550477338 : Closed e601550477338 ∧ code e601550477338 = 2800573732890 := by decide
theorem cert_e601550477338 : check e601550477338 [[]] .width = true := by decide
def e601550618650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601550618650 : Closed e601550618650 ∧ code e601550618650 = 2800573874202 := by decide
theorem cert_e601550618650 : check e601550618650 [[]] .width = true := by decide
def e601550618742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601550618742 : Closed e601550618742 ∧ code e601550618742 = 2800573874294 := by decide
theorem cert_e601550618742 : check e601550618742 [[]] .width = true := by decide
def e601550618986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601550618986 : Closed e601550618986 ∧ code e601550618986 = 2800573874538 := by decide
theorem cert_e601550618986 : check e601550618986 [[]] .width = true := by decide
def e601550619034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601550619034 : Closed e601550619034 ∧ code e601550619034 = 2800573874586 := by decide
theorem cert_e601550619034 : check e601550619034 [[]] .width = true := by decide
def e601550619118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e601550619118 : Closed e601550619118 ∧ code e601550619118 = 2800573874670 := by decide
theorem cert_e601550619118 : check e601550619118 [[]] .width = true := by decide
def e601550620042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e601550620042 : Closed e601550620042 ∧ code e601550620042 = 2800573875594 := by decide
theorem cert_e601550620042 : check e601550620042 [[]] .width = true := by decide
def e601550620066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e601550620066 : Closed e601550620066 ∧ code e601550620066 = 2800573875618 := by decide
theorem cert_e601550620066 : check e601550620066 [[]] .width = true := by decide
def e601550620086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e601550620086 : Closed e601550620086 ∧ code e601550620086 = 2800573875638 := by decide
theorem cert_e601550620086 : check e601550620086 [[]] .width = true := by decide
def e601550620118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e601550620118 : Closed e601550620118 ∧ code e601550620118 = 2800573875670 := by decide
theorem cert_e601550620118 : check e601550620118 [[]] .width = true := by decide
def e601550620122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e601550620122 : Closed e601550620122 ∧ code e601550620122 = 2800573875674 := by decide
theorem cert_e601550620122 : check e601550620122 [[]] .width = true := by decide
def e601550620174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e601550620174 : Closed e601550620174 ∧ code e601550620174 = 2800573875726 := by decide
theorem cert_e601550620174 : check e601550620174 [[]] .width = true := by decide
def e601550620186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601550620186 : Closed e601550620186 ∧ code e601550620186 = 2800573875738 := by decide
theorem cert_e601550620186 : check e601550620186 [[]] .width = true := by decide
def e601550620258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e601550620258 : Closed e601550620258 ∧ code e601550620258 = 2800573875810 := by decide
theorem cert_e601550620258 : check e601550620258 [[]] .width = true := by decide
def e601550620278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e601550620278 : Closed e601550620278 ∧ code e601550620278 = 2800573875830 := by decide
theorem cert_e601550620278 : check e601550620278 [[]] .width = true := by decide
def e601550620470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e601550620470 : Closed e601550620470 ∧ code e601550620470 = 2800573876022 := by decide
theorem cert_e601550620470 : check e601550620470 [[]] .width = true := by decide
def e601550620474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e601550620474 : Closed e601550620474 ∧ code e601550620474 = 2800573876026 := by decide
theorem cert_e601550620474 : check e601550620474 [[]] .width = true := by decide
def e601550624170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e601550624170 : Closed e601550624170 ∧ code e601550624170 = 2800573879722 := by decide
theorem cert_e601550624170 : check e601550624170 [[]] .width = true := by decide
def e601550624266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e601550624266 : Closed e601550624266 ∧ code e601550624266 = 2800573879818 := by decide
theorem cert_e601550624266 : check e601550624266 [[]] .width = true := by decide
def e601550624362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e601550624362 : Closed e601550624362 ∧ code e601550624362 = 2800573879914 := by decide
theorem cert_e601550624362 : check e601550624362 [[]] .width = true := by decide
def e601550624386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e601550624386 : Closed e601550624386 ∧ code e601550624386 = 2800573879938 := by decide
theorem cert_e601550624386 : check e601550624386 [[]] .width = true := by decide
def e601550624410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e601550624410 : Closed e601550624410 ∧ code e601550624410 = 2800573879962 := by decide
theorem cert_e601550624410 : check e601550624410 [[]] .width = true := by decide
def e601550624794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601550624794 : Closed e601550624794 ∧ code e601550624794 = 2800573880346 := by decide
theorem cert_e601550624794 : check e601550624794 [[]] .width = true := by decide
def e601550624886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e601550624886 : Closed e601550624886 ∧ code e601550624886 = 2800573880438 := by decide
theorem cert_e601550624886 : check e601550624886 [[]] .width = true := by decide
def e601550625130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e601550625130 : Closed e601550625130 ∧ code e601550625130 = 2800573880682 := by decide
theorem cert_e601550625130 : check e601550625130 [[]] .width = true := by decide
def e601550625154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e601550625154 : Closed e601550625154 ∧ code e601550625154 = 2800573880706 := by decide
theorem cert_e601550625154 : check e601550625154 [[]] .width = true := by decide
def e601550625178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e601550625178 : Closed e601550625178 ∧ code e601550625178 = 2800573880730 := by decide
theorem cert_e601550625178 : check e601550625178 [[]] .width = true := by decide
def e601550764058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550764058 : Closed e601550764058 ∧ code e601550764058 = 2800574019610 := by decide
theorem cert_e601550764058 : check e601550764058 [[]] .width = true := by decide
def e601550799046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601550799046 : Closed e601550799046 ∧ code e601550799046 = 2800574054598 := by decide
theorem cert_e601550799046 : check e601550799046 [[]] .width = true := by decide
def e601550850074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550850074 : Closed e601550850074 ∧ code e601550850074 = 2800574105626 := by decide
theorem cert_e601550850074 : check e601550850074 [[]] .width = true := by decide
def e601550856218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550856218 : Closed e601550856218 ∧ code e601550856218 = 2800574111770 := by decide
theorem cert_e601550856218 : check e601550856218 [[]] .width = true := by decide
def e601550856310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601550856310 : Closed e601550856310 ∧ code e601550856310 = 2800574111862 := by decide
theorem cert_e601550856310 : check e601550856310 [[]] .width = true := by decide
def e601550856554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601550856554 : Closed e601550856554 ∧ code e601550856554 = 2800574112106 := by decide
theorem cert_e601550856554 : check e601550856554 [[]] .width = true := by decide
def e601550856602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601550856602 : Closed e601550856602 ∧ code e601550856602 = 2800574112154 := by decide
theorem cert_e601550856602 : check e601550856602 [[]] .width = true := by decide
def e601550860486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601550860486 : Closed e601550860486 ∧ code e601550860486 = 2800574116038 := by decide
theorem cert_e601550860486 : check e601550860486 [[]] .width = true := by decide
def e601550862362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550862362 : Closed e601550862362 ∧ code e601550862362 = 2800574117914 := by decide
theorem cert_e601550862362 : check e601550862362 [[]] .width = true := by decide
def e601550868678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601550868678 : Closed e601550868678 ∧ code e601550868678 = 2800574124230 := by decide
theorem cert_e601550868678 : check e601550868678 [[]] .width = true := by decide
def e601550874650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601550874650 : Closed e601550874650 ∧ code e601550874650 = 2800574130202 := by decide
theorem cert_e601550874650 : check e601550874650 [[]] .width = true := by decide
def e601550880794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601550880794 : Closed e601550880794 ∧ code e601550880794 = 2800574136346 := by decide
theorem cert_e601550880794 : check e601550880794 [[]] .width = true := by decide
def e601550880886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601550880886 : Closed e601550880886 ∧ code e601550880886 = 2800574136438 := by decide
theorem cert_e601550880886 : check e601550880886 [[]] .width = true := by decide
def e601550881130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601550881130 : Closed e601550881130 ∧ code e601550881130 = 2800574136682 := by decide
theorem cert_e601550881130 : check e601550881130 [[]] .width = true := by decide
def e601550881178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601550881178 : Closed e601550881178 ∧ code e601550881178 = 2800574136730 := by decide
theorem cert_e601550881178 : check e601550881178 [[]] .width = true := by decide
def e601550881262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e601550881262 : Closed e601550881262 ∧ code e601550881262 = 2800574136814 := by decide
theorem cert_e601550881262 : check e601550881262 [[]] .width = true := by decide
def e601550882186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e601550882186 : Closed e601550882186 ∧ code e601550882186 = 2800574137738 := by decide
theorem cert_e601550882186 : check e601550882186 [[]] .width = true := by decide
def e601550882210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e601550882210 : Closed e601550882210 ∧ code e601550882210 = 2800574137762 := by decide
theorem cert_e601550882210 : check e601550882210 [[]] .width = true := by decide
def e601550882230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e601550882230 : Closed e601550882230 ∧ code e601550882230 = 2800574137782 := by decide
theorem cert_e601550882230 : check e601550882230 [[]] .width = true := by decide
def e601550882262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e601550882262 : Closed e601550882262 ∧ code e601550882262 = 2800574137814 := by decide
theorem cert_e601550882262 : check e601550882262 [[]] .width = true := by decide
def e601550882266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e601550882266 : Closed e601550882266 ∧ code e601550882266 = 2800574137818 := by decide
theorem cert_e601550882266 : check e601550882266 [[]] .width = true := by decide
def e601550882318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e601550882318 : Closed e601550882318 ∧ code e601550882318 = 2800574137870 := by decide
theorem cert_e601550882318 : check e601550882318 [[]] .width = true := by decide
def e601550882330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601550882330 : Closed e601550882330 ∧ code e601550882330 = 2800574137882 := by decide
theorem cert_e601550882330 : check e601550882330 [[]] .width = true := by decide
def e601550882402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e601550882402 : Closed e601550882402 ∧ code e601550882402 = 2800574137954 := by decide
theorem cert_e601550882402 : check e601550882402 [[]] .width = true := by decide
def e601550882422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e601550882422 : Closed e601550882422 ∧ code e601550882422 = 2800574137974 := by decide
theorem cert_e601550882422 : check e601550882422 [[]] .width = true := by decide
def e601550882614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e601550882614 : Closed e601550882614 ∧ code e601550882614 = 2800574138166 := by decide
theorem cert_e601550882614 : check e601550882614 [[]] .width = true := by decide
def e601550882618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e601550882618 : Closed e601550882618 ∧ code e601550882618 = 2800574138170 := by decide
theorem cert_e601550882618 : check e601550882618 [[]] .width = true := by decide
def e601550886314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e601550886314 : Closed e601550886314 ∧ code e601550886314 = 2800574141866 := by decide
theorem cert_e601550886314 : check e601550886314 [[]] .width = true := by decide
def e601550886410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e601550886410 : Closed e601550886410 ∧ code e601550886410 = 2800574141962 := by decide
theorem cert_e601550886410 : check e601550886410 [[]] .width = true := by decide
def e601550886506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e601550886506 : Closed e601550886506 ∧ code e601550886506 = 2800574142058 := by decide
theorem cert_e601550886506 : check e601550886506 [[]] .width = true := by decide
def e601550886530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e601550886530 : Closed e601550886530 ∧ code e601550886530 = 2800574142082 := by decide
theorem cert_e601550886530 : check e601550886530 [[]] .width = true := by decide
def e601550886554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e601550886554 : Closed e601550886554 ∧ code e601550886554 = 2800574142106 := by decide
theorem cert_e601550886554 : check e601550886554 [[]] .width = true := by decide
def e601550886938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601550886938 : Closed e601550886938 ∧ code e601550886938 = 2800574142490 := by decide
theorem cert_e601550886938 : check e601550886938 [[]] .width = true := by decide
def e601550887030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e601550887030 : Closed e601550887030 ∧ code e601550887030 = 2800574142582 := by decide
theorem cert_e601550887030 : check e601550887030 [[]] .width = true := by decide
def e601550887274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e601550887274 : Closed e601550887274 ∧ code e601550887274 = 2800574142826 := by decide
theorem cert_e601550887274 : check e601550887274 [[]] .width = true := by decide
def e601550887298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e601550887298 : Closed e601550887298 ∧ code e601550887298 = 2800574142850 := by decide
theorem cert_e601550887298 : check e601550887298 [[]] .width = true := by decide
def e601550887322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e601550887322 : Closed e601550887322 ∧ code e601550887322 = 2800574142874 := by decide
theorem cert_e601550887322 : check e601550887322 [[]] .width = true := by decide
end Blc.Floor41
