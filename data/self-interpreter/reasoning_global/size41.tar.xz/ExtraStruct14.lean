import Extra41
import Batch070
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness604797711606
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u0 u1
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u1 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.lam u10
private def u12 := Term.app u3 u11
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou0 sou1
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u13 := Term.app u5 u0
private def u14 := Term.app u1 u5
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou1 sou6
private theorem sou13 : SO u13 := SO.app sou5 sou0
private theorem sou8 : SO u8 := SO.lam (r := u13) (g := u14) sou7 sou13 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.lam (r := u0) (g := u8) sou8 sou0 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
private theorem sou12 : SO u12 := SO.app sou3 sou11
theorem nege604797711606 : ¬ IsSelfInterpreter e604797711606 := by
  exact rawSO [] (t := u12) (by decide) sou12
#print axioms nege604797711606
end Witness604797711606
namespace Witness604797711982
private def u0 := Term.var 0
private def u1 := Term.var 1
private def u2 := Term.app u0 u1
private def u3 := Term.var 2
private def u4 := Term.app u0 u3
private def u5 := Term.app u2 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u0 u10
private def u12 := Term.app u2 u11
private def u13 := Term.lam u12
private def u14 := Term.lam u13
private def u15 := Term.app u0 u9
private def u16 := Term.app u2 u15
private def u17 := Term.lam u16
private def u18 := Term.lam u17
private def u19 := Term.app u0 u18
private def u20 := Term.app u2 u19
private def u21 := Term.lam u20
private def u22 := Term.lam u21
private def u23 := Term.app u14 u22
private def u24 := Term.app u14 u9
private def u25 := Term.app u23 u24
theorem nege604797711982 : ¬ IsSelfInterpreter e604797711982 := by
  intro he
  have h : replay [[],[],[.left],[.left],[.left],[]] e604797711982 = some u25 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u25) (by decide) (by decide) hj
#print axioms nege604797711982
end Witness604797711982
namespace Witness604797711994
private def u0 := Term.var 0
private def u1 := Term.var 1
private def u2 := Term.app u0 u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u0
private def u5 := Term.app u2 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u10 u0
private def u12 := Term.app u2 u11
private def u13 := Term.lam u12
private def u14 := Term.lam u13
private def u15 := Term.app u9 u0
private def u16 := Term.app u2 u15
private def u17 := Term.lam u16
private def u18 := Term.lam u17
private def u19 := Term.app u18 u0
private def u20 := Term.app u2 u19
private def u21 := Term.lam u20
private def u22 := Term.lam u21
private def u23 := Term.app u14 u22
private def u24 := Term.app u9 u14
private def u25 := Term.app u23 u24
theorem nege604797711994 : ¬ IsSelfInterpreter e604797711994 := by
  intro he
  have h : replay [[],[],[.left],[.left],[.left],[]] e604797711994 = some u25 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u25) (by decide) (by decide) hj
#print axioms nege604797711994
end Witness604797711994
namespace Witness604797712182
private def u0 := Term.var 0
private def u1 := Term.var 2
private def u2 := Term.app u0 u1
private def u3 := Term.var 1
private def u4 := Term.app u0 u3
private def u5 := Term.app u2 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u0 u10
private def u12 := Term.app u11 u4
private def u13 := Term.lam u12
private def u14 := Term.lam u13
private def u15 := Term.app u14 u9
private def u16 := Term.app u0 u9
private def u17 := Term.app u16 u4
private def u18 := Term.lam u17
private def u19 := Term.lam u18
private def u20 := Term.app u0 u19
private def u21 := Term.app u20 u4
private def u22 := Term.lam u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.app u15 u24
theorem nege604797712182 : ¬ IsSelfInterpreter e604797712182 := by
  intro he
  have h : replay [[],[],[.left],[.left],[.left],[]] e604797712182 = some u25 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u25) (by decide) (by decide) hj
#print axioms nege604797712182
end Witness604797712182
namespace Witness604797712186
private def u0 := Term.var 0
private def u1 := Term.var 2
private def u2 := Term.app u0 u1
private def u3 := Term.var 1
private def u4 := Term.app u3 u0
private def u5 := Term.app u2 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.app u0 u10
private def u12 := Term.app u11 u4
private def u13 := Term.lam u12
private def u14 := Term.lam u13
private def u15 := Term.app u14 u9
private def u16 := Term.app u0 u9
private def u17 := Term.app u16 u4
private def u18 := Term.lam u17
private def u19 := Term.lam u18
private def u20 := Term.app u0 u19
private def u21 := Term.app u20 u4
private def u22 := Term.lam u21
private def u23 := Term.lam u22
private def u24 := Term.app u23 u14
private def u25 := Term.app u15 u24
theorem nege604797712186 : ¬ IsSelfInterpreter e604797712186 := by
  intro he
  have h : replay [[],[],[.left],[.left],[.left],[]] e604797712186 = some u25 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u25) (by decide) (by decide) hj
#print axioms nege604797712186
end Witness604797712186
namespace Witness604797712826
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u0 u1
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.var 2
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private def u14 := Term.lam u1
private def u15 := Term.app u13 u14
theorem nege604797712826 : ¬ IsSelfInterpreter e604797712826 := by
  intro he
  have h : replay [] (.app e604797712826 diag) = some u15 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u15) (by decide) (by decide) hj
#print axioms nege604797712826
end Witness604797712826
namespace Witness604797712874
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u0 u1
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.var 2
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.app u7 u0
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private def u14 := Term.lam u1
private def u15 := Term.app u13 u14
theorem nege604797712874 : ¬ IsSelfInterpreter e604797712874 := by
  intro he
  have h : replay [] (.app e604797712874 diag) = some u15 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u15) (by decide) (by decide) hj
#print axioms nege604797712874
end Witness604797712874
namespace Witness604797713006
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.app u0 u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u2 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u1 u9
private def u11 := Term.app u2 u10
private def u12 := Term.lam u11
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.app u2 u14
private def u16 := Term.lam u15
private def u17 := Term.lam u16
private def u18 := Term.app u9 u9
private def u19 := Term.app u1 u18
private def u20 := Term.app u2 u19
private def u21 := Term.lam u20
private def u22 := Term.lam u21
private def u23 := Term.app u17 u22
private def u24 := Term.app u22 u9
private def u25 := Term.app u23 u24
theorem nege604797713006 : ¬ IsSelfInterpreter e604797713006 := by
  intro he
  have h : replay [[],[],[.left],[.left],[.left],[]] e604797713006 = some u25 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u25) (by decide) (by decide) hj
#print axioms nege604797713006
end Witness604797713006
end Blc.Floor41
