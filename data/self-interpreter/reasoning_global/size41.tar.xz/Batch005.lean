import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e151599114170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e151599114170 : Closed e151599114170 ∧ code e151599114170 = 2350622369722 := by decide
theorem cert_e151599114170 : check e151599114170 [[.under]] .sourceHead = true := by decide
def e151599114734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e151599114734 : Closed e151599114734 ∧ code e151599114734 = 2350622370286 := by decide
theorem cert_e151599114734 : check e151599114734 [[.under]] .sourceHead = true := by decide
def e151599115886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e151599115886 : Closed e151599115886 ∧ code e151599115886 = 2350622371438 := by decide
theorem cert_e151599115886 : check e151599115886 [[.under]] .sourceHead = true := by decide
def e151599115898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e151599115898 : Closed e151599115898 ∧ code e151599115898 = 2350622371450 := by decide
theorem cert_e151599115898 : check e151599115898 [[.under]] .sourceHead = true := by decide
def e151599117166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e151599117166 : Closed e151599117166 ∧ code e151599117166 = 2350622372718 := by decide
theorem cert_e151599117166 : check e151599117166 [[.under]] .sourceHead = true := by decide
def e151599117174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e151599117174 : Closed e151599117174 ∧ code e151599117174 = 2350622372726 := by decide
theorem cert_e151599117174 : check e151599117174 [[.under]] .sourceHead = true := by decide
def e151599117230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e151599117230 : Closed e151599117230 ∧ code e151599117230 = 2350622372782 := by decide
theorem cert_e151599117230 : check e151599117230 [[.under]] .sourceHead = true := by decide
def e151599117242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e151599117242 : Closed e151599117242 ∧ code e151599117242 = 2350622372794 := by decide
theorem cert_e151599117242 : check e151599117242 [[.under]] .sourceHead = true := by decide
def e151599117270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e151599117270 : Closed e151599117270 ∧ code e151599117270 = 2350622372822 := by decide
theorem cert_e151599117270 : check e151599117270 [[.under]] .sourceHead = true := by decide
def e151599117274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e151599117274 : Closed e151599117274 ∧ code e151599117274 = 2350622372826 := by decide
theorem cert_e151599117274 : check e151599117274 [[.under]] .sourceHead = true := by decide
def e151599117550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e151599117550 : Closed e151599117550 ∧ code e151599117550 = 2350622373102 := by decide
theorem cert_e151599117550 : check e151599117550 [[.under]] .sourceHead = true := by decide
def e151599117558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e151599117558 : Closed e151599117558 ∧ code e151599117558 = 2350622373110 := by decide
theorem cert_e151599117558 : check e151599117558 [[.under]] .sourceHead = true := by decide
def e151599117934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e151599117934 : Closed e151599117934 ∧ code e151599117934 = 2350622373486 := by decide
theorem cert_e151599117934 : check e151599117934 [[.under]] .sourceHead = true := by decide
def e151599117946 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e151599117946 : Closed e151599117946 ∧ code e151599117946 = 2350622373498 := by decide
theorem cert_e151599117946 : check e151599117946 [[.under]] .sourceHead = true := by decide
def e151599118134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e151599118134 : Closed e151599118134 ∧ code e151599118134 = 2350622373686 := by decide
theorem cert_e151599118134 : check e151599118134 [[.under]] .sourceHead = true := by decide
def e151599118138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e151599118138 : Closed e151599118138 ∧ code e151599118138 = 2350622373690 := by decide
theorem cert_e151599118138 : check e151599118138 [[.under]] .sourceHead = true := by decide
def e151599123310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e151599123310 : Closed e151599123310 ∧ code e151599123310 = 2350622378862 := by decide
theorem cert_e151599123310 : check e151599123310 [[.under]] .sourceHead = true := by decide
def e151599123318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e151599123318 : Closed e151599123318 ∧ code e151599123318 = 2350622378870 := by decide
theorem cert_e151599123318 : check e151599123318 [[.under]] .sourceHead = true := by decide
def e151599123374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e151599123374 : Closed e151599123374 ∧ code e151599123374 = 2350622378926 := by decide
theorem cert_e151599123374 : check e151599123374 [[.under]] .sourceHead = true := by decide
def e151599123386 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e151599123386 : Closed e151599123386 ∧ code e151599123386 = 2350622378938 := by decide
theorem cert_e151599123386 : check e151599123386 [[.under]] .sourceHead = true := by decide
def e151599123414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e151599123414 : Closed e151599123414 ∧ code e151599123414 = 2350622378966 := by decide
theorem cert_e151599123414 : check e151599123414 [[.under]] .sourceHead = true := by decide
def e151599123418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e151599123418 : Closed e151599123418 ∧ code e151599123418 = 2350622378970 := by decide
theorem cert_e151599123418 : check e151599123418 [[.under]] .sourceHead = true := by decide
def e151599123694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e151599123694 : Closed e151599123694 ∧ code e151599123694 = 2350622379246 := by decide
theorem cert_e151599123694 : check e151599123694 [[.under]] .sourceHead = true := by decide
def e151599123702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e151599123702 : Closed e151599123702 ∧ code e151599123702 = 2350622379254 := by decide
theorem cert_e151599123702 : check e151599123702 [[.under]] .sourceHead = true := by decide
def e151599124078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e151599124078 : Closed e151599124078 ∧ code e151599124078 = 2350622379630 := by decide
theorem cert_e151599124078 : check e151599124078 [[.under]] .sourceHead = true := by decide
def e151599124090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e151599124090 : Closed e151599124090 ∧ code e151599124090 = 2350622379642 := by decide
theorem cert_e151599124090 : check e151599124090 [[.under]] .sourceHead = true := by decide
def e151599124278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e151599124278 : Closed e151599124278 ∧ code e151599124278 = 2350622379830 := by decide
theorem cert_e151599124278 : check e151599124278 [[.under]] .sourceHead = true := by decide
def e151599124282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e151599124282 : Closed e151599124282 ∧ code e151599124282 = 2350622379834 := by decide
theorem cert_e151599124282 : check e151599124282 [[.under]] .sourceHead = true := by decide
def e151599132398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e151599132398 : Closed e151599132398 ∧ code e151599132398 = 2350622387950 := by decide
theorem cert_e151599132398 : check e151599132398 [[.under]] .sourceHead = true := by decide
def e151599132526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e151599132526 : Closed e151599132526 ∧ code e151599132526 = 2350622388078 := by decide
theorem cert_e151599132526 : check e151599132526 [[.under]] .sourceHead = true := by decide
def e151599132534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e151599132534 : Closed e151599132534 ∧ code e151599132534 = 2350622388086 := by decide
theorem cert_e151599132534 : check e151599132534 [[.under]] .sourceHead = true := by decide
def e151599135214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e151599135214 : Closed e151599135214 ∧ code e151599135214 = 2350622390766 := by decide
theorem cert_e151599135214 : check e151599135214 [[.under]] .sourceHead = true := by decide
def e151599135982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e151599135982 : Closed e151599135982 ∧ code e151599135982 = 2350622391534 := by decide
theorem cert_e151599135982 : check e151599135982 [[.under]] .sourceHead = true := by decide
def e151599135990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e151599135990 : Closed e151599135990 ∧ code e151599135990 = 2350622391542 := by decide
theorem cert_e151599135990 : check e151599135990 [[.under]] .sourceHead = true := by decide
def e151599159022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e151599159022 : Closed e151599159022 ∧ code e151599159022 = 2350622414574 := by decide
theorem cert_e151599159022 : check e151599159022 [[.under]] .sourceHead = true := by decide
def e151599159214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e151599159214 : Closed e151599159214 ∧ code e151599159214 = 2350622414766 := by decide
theorem cert_e151599159214 : check e151599159214 [[.under]] .sourceHead = true := by decide
def e151599159226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e151599159226 : Closed e151599159226 ∧ code e151599159226 = 2350622414778 := by decide
theorem cert_e151599159226 : check e151599159226 [[.under]] .sourceHead = true := by decide
def e151599159790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e151599159790 : Closed e151599159790 ∧ code e151599159790 = 2350622415342 := by decide
theorem cert_e151599159790 : check e151599159790 [[.under]] .sourceHead = true := by decide
def e151599160942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e151599160942 : Closed e151599160942 ∧ code e151599160942 = 2350622416494 := by decide
theorem cert_e151599160942 : check e151599160942 [[.under]] .sourceHead = true := by decide
def e151599160954 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e151599160954 : Closed e151599160954 ∧ code e151599160954 = 2350622416506 := by decide
theorem cert_e151599160954 : check e151599160954 [[.under]] .sourceHead = true := by decide
def e151599172462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e151599172462 : Closed e151599172462 ∧ code e151599172462 = 2350622428014 := by decide
theorem cert_e151599172462 : check e151599172462 [[.under]] .sourceHead = true := by decide
def e151599172470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e151599172470 : Closed e151599172470 ∧ code e151599172470 = 2350622428022 := by decide
theorem cert_e151599172470 : check e151599172470 [[.under]] .sourceHead = true := by decide
def e151599172526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e151599172526 : Closed e151599172526 ∧ code e151599172526 = 2350622428078 := by decide
theorem cert_e151599172526 : check e151599172526 [[.under]] .sourceHead = true := by decide
def e151599172538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e151599172538 : Closed e151599172538 ∧ code e151599172538 = 2350622428090 := by decide
theorem cert_e151599172538 : check e151599172538 [[.under]] .sourceHead = true := by decide
def e151599172566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e151599172566 : Closed e151599172566 ∧ code e151599172566 = 2350622428118 := by decide
theorem cert_e151599172566 : check e151599172566 [[.under]] .sourceHead = true := by decide
def e151599172570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e151599172570 : Closed e151599172570 ∧ code e151599172570 = 2350622428122 := by decide
theorem cert_e151599172570 : check e151599172570 [[.under]] .sourceHead = true := by decide
def e151599172846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e151599172846 : Closed e151599172846 ∧ code e151599172846 = 2350622428398 := by decide
theorem cert_e151599172846 : check e151599172846 [[.under]] .sourceHead = true := by decide
def e151599172854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e151599172854 : Closed e151599172854 ∧ code e151599172854 = 2350622428406 := by decide
theorem cert_e151599172854 : check e151599172854 [[.under]] .sourceHead = true := by decide
def e151599173230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e151599173230 : Closed e151599173230 ∧ code e151599173230 = 2350622428782 := by decide
theorem cert_e151599173230 : check e151599173230 [[.under]] .sourceHead = true := by decide
def e151599173242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e151599173242 : Closed e151599173242 ∧ code e151599173242 = 2350622428794 := by decide
theorem cert_e151599173242 : check e151599173242 [[.under]] .sourceHead = true := by decide
def e151599173430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e151599173430 : Closed e151599173430 ∧ code e151599173430 = 2350622428982 := by decide
theorem cert_e151599173430 : check e151599173430 [[.under]] .sourceHead = true := by decide
def e151599173434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e151599173434 : Closed e151599173434 ∧ code e151599173434 = 2350622428986 := by decide
theorem cert_e151599173434 : check e151599173434 [[.under]] .sourceHead = true := by decide
def e151599713134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e151599713134 : Closed e151599713134 ∧ code e151599713134 = 2350622968686 := by decide
theorem cert_e151599713134 : check e151599713134 [[.under]] .sourceHead = true := by decide
def e151599713142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e151599713142 : Closed e151599713142 ∧ code e151599713142 = 2350622968694 := by decide
theorem cert_e151599713142 : check e151599713142 [[.under]] .sourceHead = true := by decide
def e151599713198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e151599713198 : Closed e151599713198 ∧ code e151599713198 = 2350622968750 := by decide
theorem cert_e151599713198 : check e151599713198 [[.under]] .sourceHead = true := by decide
def e151599713210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e151599713210 : Closed e151599713210 ∧ code e151599713210 = 2350622968762 := by decide
theorem cert_e151599713210 : check e151599713210 [[.under]] .sourceHead = true := by decide
def e151599713238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e151599713238 : Closed e151599713238 ∧ code e151599713238 = 2350622968790 := by decide
theorem cert_e151599713238 : check e151599713238 [[.under]] .sourceHead = true := by decide
def e151599713242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e151599713242 : Closed e151599713242 ∧ code e151599713242 = 2350622968794 := by decide
theorem cert_e151599713242 : check e151599713242 [[.under]] .sourceHead = true := by decide
def e151599713518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e151599713518 : Closed e151599713518 ∧ code e151599713518 = 2350622969070 := by decide
theorem cert_e151599713518 : check e151599713518 [[.under]] .sourceHead = true := by decide
def e151599713526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e151599713526 : Closed e151599713526 ∧ code e151599713526 = 2350622969078 := by decide
theorem cert_e151599713526 : check e151599713526 [[.under]] .sourceHead = true := by decide
def e151599713902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e151599713902 : Closed e151599713902 ∧ code e151599713902 = 2350622969454 := by decide
theorem cert_e151599713902 : check e151599713902 [[.under]] .sourceHead = true := by decide
def e151599713914 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e151599713914 : Closed e151599713914 ∧ code e151599713914 = 2350622969466 := by decide
theorem cert_e151599713914 : check e151599713914 [[.under]] .sourceHead = true := by decide
def e151599714102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e151599714102 : Closed e151599714102 ∧ code e151599714102 = 2350622969654 := by decide
theorem cert_e151599714102 : check e151599714102 [[.under]] .sourceHead = true := by decide
def e151599714106 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e151599714106 : Closed e151599714106 ∧ code e151599714106 = 2350622969658 := by decide
theorem cert_e151599714106 : check e151599714106 [[.under]] .sourceHead = true := by decide
def e152907635566 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e152907635566 : Closed e152907635566 ∧ code e152907635566 = 2351930891118 := by decide
theorem cert_e152907635566 : check e152907635566 [[.under]] .sourceHead = true := by decide
def e152907635574 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e152907635574 : Closed e152907635574 ∧ code e152907635574 = 2351930891126 := by decide
theorem cert_e152907635574 : check e152907635574 [[.under]] .sourceHead = true := by decide
def e152907635638 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e152907635638 : Closed e152907635638 ∧ code e152907635638 = 2351930891190 := by decide
theorem cert_e152907635638 : check e152907635638 [[.under]] .sourceHead = true := by decide
def e152907636078 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e152907636078 : Closed e152907636078 ∧ code e152907636078 = 2351930891630 := by decide
theorem cert_e152907636078 : check e152907636078 [[.under]] .sourceHead = true := by decide
def e152907636086 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e152907636086 : Closed e152907636086 ∧ code e152907636086 = 2351930891638 := by decide
theorem cert_e152907636086 : check e152907636086 [[.under]] .sourceHead = true := by decide
def e152907636142 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e152907636142 : Closed e152907636142 ∧ code e152907636142 = 2351930891694 := by decide
theorem cert_e152907636142 : check e152907636142 [[.under]] .sourceHead = true := by decide
def e152907636154 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e152907636154 : Closed e152907636154 ∧ code e152907636154 = 2351930891706 := by decide
theorem cert_e152907636154 : check e152907636154 [[.under]] .sourceHead = true := by decide
def e152907636182 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e152907636182 : Closed e152907636182 ∧ code e152907636182 = 2351930891734 := by decide
theorem cert_e152907636182 : check e152907636182 [[.under]] .sourceHead = true := by decide
def e152907636186 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e152907636186 : Closed e152907636186 ∧ code e152907636186 = 2351930891738 := by decide
theorem cert_e152907636186 : check e152907636186 [[.under]] .sourceHead = true := by decide
def e152907636406 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e152907636406 : Closed e152907636406 ∧ code e152907636406 = 2351930891958 := by decide
theorem cert_e152907636406 : check e152907636406 [[.under]] .sourceHead = true := by decide
def e152907636438 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e152907636438 : Closed e152907636438 ∧ code e152907636438 = 2351930891990 := by decide
theorem cert_e152907636438 : check e152907636438 [[.under]] .sourceHead = true := by decide
def e152907636442 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e152907636442 : Closed e152907636442 ∧ code e152907636442 = 2351930891994 := by decide
theorem cert_e152907636442 : check e152907636442 [[.under]] .sourceHead = true := by decide
def e152907638638 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e152907638638 : Closed e152907638638 ∧ code e152907638638 = 2351930894190 := by decide
theorem cert_e152907638638 : check e152907638638 [[.under]] .sourceHead = true := by decide
def e152907638646 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e152907638646 : Closed e152907638646 ∧ code e152907638646 = 2351930894198 := by decide
theorem cert_e152907638646 : check e152907638646 [[.under]] .sourceHead = true := by decide
def e152907638710 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e152907638710 : Closed e152907638710 ∧ code e152907638710 = 2351930894262 := by decide
theorem cert_e152907638710 : check e152907638710 [[.under]] .sourceHead = true := by decide
def e152907640046 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e152907640046 : Closed e152907640046 ∧ code e152907640046 = 2351930895598 := by decide
theorem cert_e152907640046 : check e152907640046 [[.under]] .sourceHead = true := by decide
def e152907640054 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e152907640054 : Closed e152907640054 ∧ code e152907640054 = 2351930895606 := by decide
theorem cert_e152907640054 : check e152907640054 [[.under]] .sourceHead = true := by decide
def e152907640438 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e152907640438 : Closed e152907640438 ∧ code e152907640438 = 2351930895990 := by decide
theorem cert_e152907640438 : check e152907640438 [[.under]] .sourceHead = true := by decide
def e152907641710 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e152907641710 : Closed e152907641710 ∧ code e152907641710 = 2351930897262 := by decide
theorem cert_e152907641710 : check e152907641710 [[.under]] .sourceHead = true := by decide
def e152907641718 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e152907641718 : Closed e152907641718 ∧ code e152907641718 = 2351930897270 := by decide
theorem cert_e152907641718 : check e152907641718 [[.under]] .sourceHead = true := by decide
def e152907641774 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e152907641774 : Closed e152907641774 ∧ code e152907641774 = 2351930897326 := by decide
theorem cert_e152907641774 : check e152907641774 [[.under]] .sourceHead = true := by decide
def e152907641786 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e152907641786 : Closed e152907641786 ∧ code e152907641786 = 2351930897338 := by decide
theorem cert_e152907641786 : check e152907641786 [[.under]] .sourceHead = true := by decide
def e152907641814 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e152907641814 : Closed e152907641814 ∧ code e152907641814 = 2351930897366 := by decide
theorem cert_e152907641814 : check e152907641814 [[.under]] .sourceHead = true := by decide
def e152907641818 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e152907641818 : Closed e152907641818 ∧ code e152907641818 = 2351930897370 := by decide
theorem cert_e152907641818 : check e152907641818 [[.under]] .sourceHead = true := by decide
def e152907642094 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e152907642094 : Closed e152907642094 ∧ code e152907642094 = 2351930897646 := by decide
theorem cert_e152907642094 : check e152907642094 [[.under]] .sourceHead = true := by decide
def e152907642102 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e152907642102 : Closed e152907642102 ∧ code e152907642102 = 2351930897654 := by decide
theorem cert_e152907642102 : check e152907642102 [[.under]] .sourceHead = true := by decide
def e152907642478 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e152907642478 : Closed e152907642478 ∧ code e152907642478 = 2351930898030 := by decide
theorem cert_e152907642478 : check e152907642478 [[.under]] .sourceHead = true := by decide
def e152907642490 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e152907642490 : Closed e152907642490 ∧ code e152907642490 = 2351930898042 := by decide
theorem cert_e152907642490 : check e152907642490 [[.under]] .sourceHead = true := by decide
def e152907642678 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e152907642678 : Closed e152907642678 ∧ code e152907642678 = 2351930898230 := by decide
theorem cert_e152907642678 : check e152907642678 [[.under]] .sourceHead = true := by decide
def e152907642682 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e152907642682 : Closed e152907642682 ∧ code e152907642682 = 2351930898234 := by decide
theorem cert_e152907642682 : check e152907642682 [[.under]] .sourceHead = true := by decide
def e152907643318 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e152907643318 : Closed e152907643318 ∧ code e152907643318 = 2351930898870 := by decide
theorem cert_e152907643318 : check e152907643318 [[.under]] .sourceHead = true := by decide
def e152907643350 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e152907643350 : Closed e152907643350 ∧ code e152907643350 = 2351930898902 := by decide
theorem cert_e152907643350 : check e152907643350 [[.under]] .sourceHead = true := by decide
def e152907643354 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e152907643354 : Closed e152907643354 ∧ code e152907643354 = 2351930898906 := by decide
theorem cert_e152907643354 : check e152907643354 [[.under]] .sourceHead = true := by decide
def e152907643510 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e152907643510 : Closed e152907643510 ∧ code e152907643510 = 2351930899062 := by decide
theorem cert_e152907643510 : check e152907643510 [[.under]] .sourceHead = true := by decide
def e152907643702 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e152907643702 : Closed e152907643702 ∧ code e152907643702 = 2351930899254 := by decide
theorem cert_e152907643702 : check e152907643702 [[.under]] .sourceHead = true := by decide
def e152907643706 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e152907643706 : Closed e152907643706 ∧ code e152907643706 = 2351930899258 := by decide
theorem cert_e152907643706 : check e152907643706 [[.under]] .sourceHead = true := by decide
def e152907650926 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e152907650926 : Closed e152907650926 ∧ code e152907650926 = 2351930906478 := by decide
theorem cert_e152907650926 : check e152907650926 [[.under]] .sourceHead = true := by decide
def e152907650934 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e152907650934 : Closed e152907650934 ∧ code e152907650934 = 2351930906486 := by decide
theorem cert_e152907650934 : check e152907650934 [[.under]] .sourceHead = true := by decide
def e152907650998 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e152907650998 : Closed e152907650998 ∧ code e152907650998 = 2351930906550 := by decide
theorem cert_e152907650998 : check e152907650998 [[.under]] .sourceHead = true := by decide
def e152907652334 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e152907652334 : Closed e152907652334 ∧ code e152907652334 = 2351930907886 := by decide
theorem cert_e152907652334 : check e152907652334 [[.under]] .sourceHead = true := by decide
def e152907652342 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e152907652342 : Closed e152907652342 ∧ code e152907652342 = 2351930907894 := by decide
theorem cert_e152907652342 : check e152907652342 [[.under]] .sourceHead = true := by decide
def e152907652726 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e152907652726 : Closed e152907652726 ∧ code e152907652726 = 2351930908278 := by decide
theorem cert_e152907652726 : check e152907652726 [[.under]] .sourceHead = true := by decide
def e152907664238 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e152907664238 : Closed e152907664238 ∧ code e152907664238 = 2351930919790 := by decide
theorem cert_e152907664238 : check e152907664238 [[.under]] .sourceHead = true := by decide
def e152907664246 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e152907664246 : Closed e152907664246 ∧ code e152907664246 = 2351930919798 := by decide
theorem cert_e152907664246 : check e152907664246 [[.under]] .sourceHead = true := by decide
def e152907664302 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e152907664302 : Closed e152907664302 ∧ code e152907664302 = 2351930919854 := by decide
theorem cert_e152907664302 : check e152907664302 [[.under]] .sourceHead = true := by decide
def e152907664314 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e152907664314 : Closed e152907664314 ∧ code e152907664314 = 2351930919866 := by decide
theorem cert_e152907664314 : check e152907664314 [[.under]] .sourceHead = true := by decide
def e152907664342 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e152907664342 : Closed e152907664342 ∧ code e152907664342 = 2351930919894 := by decide
theorem cert_e152907664342 : check e152907664342 [[.under]] .sourceHead = true := by decide
def e152907664346 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e152907664346 : Closed e152907664346 ∧ code e152907664346 = 2351930919898 := by decide
theorem cert_e152907664346 : check e152907664346 [[.under]] .sourceHead = true := by decide
def e152907664622 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e152907664622 : Closed e152907664622 ∧ code e152907664622 = 2351930920174 := by decide
theorem cert_e152907664622 : check e152907664622 [[.under]] .sourceHead = true := by decide
def e152907664630 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e152907664630 : Closed e152907664630 ∧ code e152907664630 = 2351930920182 := by decide
theorem cert_e152907664630 : check e152907664630 [[.under]] .sourceHead = true := by decide
def e152907665006 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e152907665006 : Closed e152907665006 ∧ code e152907665006 = 2351930920558 := by decide
theorem cert_e152907665006 : check e152907665006 [[.under]] .sourceHead = true := by decide
def e152907665018 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e152907665018 : Closed e152907665018 ∧ code e152907665018 = 2351930920570 := by decide
theorem cert_e152907665018 : check e152907665018 [[.under]] .sourceHead = true := by decide
def e152907665206 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e152907665206 : Closed e152907665206 ∧ code e152907665206 = 2351930920758 := by decide
theorem cert_e152907665206 : check e152907665206 [[.under]] .sourceHead = true := by decide
def e152907665210 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e152907665210 : Closed e152907665210 ∧ code e152907665210 = 2351930920762 := by decide
theorem cert_e152907665210 : check e152907665210 [[.under]] .sourceHead = true := by decide
def e152907670966 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e152907670966 : Closed e152907670966 ∧ code e152907670966 = 2351930926518 := by decide
theorem cert_e152907670966 : check e152907670966 [[.under]] .sourceHead = true := by decide
def e152907670998 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e152907670998 : Closed e152907670998 ∧ code e152907670998 = 2351930926550 := by decide
theorem cert_e152907670998 : check e152907670998 [[.under]] .sourceHead = true := by decide
def e152907671002 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e152907671002 : Closed e152907671002 ∧ code e152907671002 = 2351930926554 := by decide
theorem cert_e152907671002 : check e152907671002 [[.under]] .sourceHead = true := by decide
def e152907671158 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e152907671158 : Closed e152907671158 ∧ code e152907671158 = 2351930926710 := by decide
theorem cert_e152907671158 : check e152907671158 [[.under]] .sourceHead = true := by decide
def e152907671350 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e152907671350 : Closed e152907671350 ∧ code e152907671350 = 2351930926902 := by decide
theorem cert_e152907671350 : check e152907671350 [[.under]] .sourceHead = true := by decide
def e152907671354 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e152907671354 : Closed e152907671354 ∧ code e152907671354 = 2351930926906 := by decide
theorem cert_e152907671354 : check e152907671354 [[.under]] .sourceHead = true := by decide
def e152908008302 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e152908008302 : Closed e152908008302 ∧ code e152908008302 = 2351931263854 := by decide
theorem cert_e152908008302 : check e152908008302 [[.under]] .sourceHead = true := by decide
def e152908008310 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e152908008310 : Closed e152908008310 ∧ code e152908008310 = 2351931263862 := by decide
theorem cert_e152908008310 : check e152908008310 [[.under]] .sourceHead = true := by decide
def e152908008366 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e152908008366 : Closed e152908008366 ∧ code e152908008366 = 2351931263918 := by decide
theorem cert_e152908008366 : check e152908008366 [[.under]] .sourceHead = true := by decide
def e152908008378 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e152908008378 : Closed e152908008378 ∧ code e152908008378 = 2351931263930 := by decide
theorem cert_e152908008378 : check e152908008378 [[.under]] .sourceHead = true := by decide
def e152908008406 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e152908008406 : Closed e152908008406 ∧ code e152908008406 = 2351931263958 := by decide
theorem cert_e152908008406 : check e152908008406 [[.under]] .sourceHead = true := by decide
def e152908008410 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e152908008410 : Closed e152908008410 ∧ code e152908008410 = 2351931263962 := by decide
theorem cert_e152908008410 : check e152908008410 [[.under]] .sourceHead = true := by decide
def e152908008686 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e152908008686 : Closed e152908008686 ∧ code e152908008686 = 2351931264238 := by decide
theorem cert_e152908008686 : check e152908008686 [[.under]] .sourceHead = true := by decide
def e152908008694 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e152908008694 : Closed e152908008694 ∧ code e152908008694 = 2351931264246 := by decide
theorem cert_e152908008694 : check e152908008694 [[.under]] .sourceHead = true := by decide
def e152908009070 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e152908009070 : Closed e152908009070 ∧ code e152908009070 = 2351931264622 := by decide
theorem cert_e152908009070 : check e152908009070 [[.under]] .sourceHead = true := by decide
def e152908009082 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e152908009082 : Closed e152908009082 ∧ code e152908009082 = 2351931264634 := by decide
theorem cert_e152908009082 : check e152908009082 [[.under]] .sourceHead = true := by decide
def e152908009270 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e152908009270 : Closed e152908009270 ∧ code e152908009270 = 2351931264822 := by decide
theorem cert_e152908009270 : check e152908009270 [[.under]] .sourceHead = true := by decide
def e152908009274 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e152908009274 : Closed e152908009274 ∧ code e152908009274 = 2351931264826 := by decide
theorem cert_e152908009274 : check e152908009274 [[.under]] .sourceHead = true := by decide
def e175031902314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e175031902314 : Closed e175031902314 ∧ code e175031902314 = 2374055157866 := by decide
theorem cert_e175031902314 : check e175031902314 [[.under,.left]] .width = true := by decide
def e175031935082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e175031935082 : Closed e175031935082 ∧ code e175031935082 = 2374055190634 := by decide
theorem cert_e175031935082 : check e175031935082 [[.under,.left]] .width = true := by decide
def e175032164458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e175032164458 : Closed e175032164458 ∧ code e175032164458 = 2374055420010 := by decide
theorem cert_e175032164458 : check e175032164458 [[.under,.left]] .width = true := by decide
def e175032213610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e175032213610 : Closed e175032213610 ∧ code e175032213610 = 2374055469162 := by decide
theorem cert_e175032213610 : check e175032213610 [[.under,.left]] .width = true := by decide
def e175032328298 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e175032328298 : Closed e175032328298 ∧ code e175032328298 = 2374055583850 := by decide
theorem cert_e175032328298 : check e175032328298 [[.under,.left]] .width = true := by decide
def e175032344682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e175032344682 : Closed e175032344682 ∧ code e175032344682 = 2374055600234 := by decide
theorem cert_e175032344682 : check e175032344682 [[.under,.left]] .width = true := by decide
def e175033475178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e175033475178 : Closed e175033475178 ∧ code e175033475178 = 2374056730730 := by decide
theorem cert_e175033475178 : check e175033475178 [[.under,.left]] .width = true := by decide
def e175033507946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e175033507946 : Closed e175033507946 ∧ code e175033507946 = 2374056763498 := by decide
theorem cert_e175033507946 : check e175033507946 [[.under,.left]] .width = true := by decide
def e175035048042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e175035048042 : Closed e175035048042 ∧ code e175035048042 = 2374058303594 := by decide
theorem cert_e175035048042 : check e175035048042 [[.under,.left]] .width = true := by decide
def e175035097194 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e175035097194 : Closed e175035097194 ∧ code e175035097194 = 2374058352746 := by decide
theorem cert_e175035097194 : check e175035097194 [[.under,.left]] .width = true := by decide
def e175035867242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e175035867242 : Closed e175035867242 ∧ code e175035867242 = 2374059122794 := by decide
theorem cert_e175035867242 : check e175035867242 [[.under,.left]] .width = true := by decide
def e175035883626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e175035883626 : Closed e175035883626 ∧ code e175035883626 = 2374059139178 := by decide
theorem cert_e175035883626 : check e175035883626 [[.under,.left]] .width = true := by decide
def e175288530362 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e175288530362 : Closed e175288530362 ∧ code e175288530362 = 2374311785914 := by decide
theorem cert_e175288530362 : check e175288530362 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288530394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e175288530394 : Closed e175288530394 ∧ code e175288530394 = 2374311785946 := by decide
theorem cert_e175288530394 : check e175288530394 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288530618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e175288530618 : Closed e175288530618 ∧ code e175288530618 = 2374311786170 := by decide
theorem cert_e175288530618 : check e175288530618 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288530666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e175288530666 : Closed e175288530666 ∧ code e175288530666 = 2374311786218 := by decide
theorem cert_e175288530666 : check e175288530666 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288530778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e175288530778 : Closed e175288530778 ∧ code e175288530778 = 2374311786330 := by decide
theorem cert_e175288530778 : check e175288530778 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288530794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e175288530794 : Closed e175288530794 ∧ code e175288530794 = 2374311786346 := by decide
theorem cert_e175288530794 : check e175288530794 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288531642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e175288531642 : Closed e175288531642 ∧ code e175288531642 = 2374311787194 := by decide
theorem cert_e175288531642 : check e175288531642 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288531690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e175288531690 : Closed e175288531690 ∧ code e175288531690 = 2374311787242 := by decide
theorem cert_e175288531690 : check e175288531690 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288531882 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e175288531882 : Closed e175288531882 ∧ code e175288531882 = 2374311787434 := by decide
theorem cert_e175288531882 : check e175288531882 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288532314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e175288532314 : Closed e175288532314 ∧ code e175288532314 = 2374311787866 := by decide
theorem cert_e175288532314 : check e175288532314 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288532330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e175288532330 : Closed e175288532330 ∧ code e175288532330 = 2374311787882 := by decide
theorem cert_e175288532330 : check e175288532330 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e175288532394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e175288532394 : Closed e175288532394 ∧ code e175288532394 = 2374311787946 := by decide
theorem cert_e175288532394 : check e175288532394 [[.under,.left],[.under,.left]] .smaller = true := by decide
end Blc.Floor41
