import Extra41
import Batch035
import Batch037
import Batch038
import Batch043
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness597890436014
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u0 u1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u3 u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u9 u12
private def u14 := Term.app u13 u9
private def u15 := Term.app u14 u12
private def u16 := Term.app u15 u9
private def u17 := Term.app u16 u0
private def u18 := Term.lam u0
private def u19 := Term.lam u18
private def u20 := Term.app u1 u19
private def u21 := Term.lam u2
private def u22 := Term.app u1 u21
private def u23 := Term.var 4
private def u24 := Term.app u20 u23
private def u25 := Term.lam u24
private def u26 := Term.app u22 u25
private def u27 := Term.lam u26
private def u28 := Term.app u20 u27
private def u29 := Term.lam u28
private def u30 := Term.app u20 u29
private def u31 := Term.lam u30
private def u32 := Term.app u17 u31
private def u33 := Term.app u0 u21
private def u34 := Term.app u33 u1
private def u35 := Term.app u3 u12
private def u36 := Term.lam u35
private def u37 := Term.lam u36
private def u38 := Term.app u12 u37
private def u39 := Term.app u38 u9
private def u40 := Term.app u39 u12
private def u41 := Term.app u40 u9
private def u42 := Term.app u41 u0
private def u43 := Term.app u42 u31
theorem nege597890436014 : ¬ IsSelfInterpreter e597890436014 := by
  intro he
  have hv : NFt u34 := by decide
  have reach : Betas (Floor40.call e597890436014 u0 u2 u1 []) u34 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left]] (Floor40.call e597890436014 u0 u2 u1 []) = some u32 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u32) (u := u43) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]]) (by decide)) j hj
#print axioms nege597890436014
end Witness597890436014
namespace Witness597890436054
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.app u8 u0
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u11 u1
private def u13 := Term.app u12 u0
private def u14 := Term.lam u13
private def u15 := Term.lam u14
private def u16 := Term.app u11 u15
private def u17 := Term.var 3
private def u18 := Term.app u17 u1
private def u19 := Term.app u18 u0
private def u20 := Term.lam u19
private def u21 := Term.lam u20
private def u22 := Term.app u0 u21
private def u23 := Term.app u22 u1
private def u24 := Term.lam u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u8
private def u28 := Term.app u27 u27
private def u29 := Term.app u28 u0
private def u30 := Term.app u29 u1
private def u31 := Term.lam u30
private def u32 := Term.lam u31
private def u33 := Term.app u26 u32
private def u34 := Term.app u33 u27
private def u35 := Term.app u34 u0
private def u36 := Term.lam u0
private def u37 := Term.lam u36
private def u38 := Term.app u1 u37
private def u39 := Term.lam u2
private def u40 := Term.app u1 u39
private def u41 := Term.var 4
private def u42 := Term.app u38 u41
private def u43 := Term.lam u42
private def u44 := Term.app u40 u43
private def u45 := Term.lam u44
private def u46 := Term.app u38 u45
private def u47 := Term.lam u46
private def u48 := Term.app u38 u47
private def u49 := Term.lam u48
private def u50 := Term.app u35 u49
private def u51 := Term.app u0 u39
private def u52 := Term.app u51 u1
private def u53 := Term.app u8 u15
private def u54 := Term.lam u53
private def u55 := Term.app u54 u25
private def u56 := Term.app u55 u32
private def u57 := Term.app u56 u27
private def u58 := Term.app u57 u0
private def u59 := Term.app u58 u49
theorem nege597890436054 : ¬ IsSelfInterpreter e597890436054 := by
  intro he
  have hv : NFt u52 := by decide
  have reach : Betas (Floor40.call e597890436054 u0 u2 u1 []) u52 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.under,.right,.under,.under,.left],[.left,.left,.left,.left,.under,.right,.under,.under],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.right,.under,.under],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left,.left]] (Floor40.call e597890436054 u0 u2 u1 []) = some u50 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u50) (u := u59) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left,.left,.under,.right,.under,.under,.left],[.left,.left,.left,.left,.left,.under,.right,.under,.under],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left,.left,.right,.under,.under],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]]) (by decide)) j hj
#print axioms nege597890436054
end Witness597890436054
namespace Witness598174948718
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u0 u1
private def u4 := Term.app u3 u0
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u9 u10
private def u12 := Term.app u11 u9
private def u13 := Term.lam u0
private def u14 := Term.lam u13
private def u15 := Term.app u1 u14
private def u16 := Term.lam u2
private def u17 := Term.app u1 u16
private def u18 := Term.var 4
private def u19 := Term.app u15 u18
private def u20 := Term.lam u19
private def u21 := Term.app u17 u20
private def u22 := Term.lam u21
private def u23 := Term.app u15 u22
private def u24 := Term.lam u23
private def u25 := Term.app u15 u24
private def u26 := Term.lam u25
private def u27 := Term.app u12 u26
private def u28 := Term.app u0 u16
private def u29 := Term.app u28 u1
theorem nege598174948718 : ¬ IsSelfInterpreter e598174948718 := by
  intro he
  have hv : NFt u29 := by decide
  have reach : Betas (Floor40.call e598174948718 u0 u2 u1 []) u29 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] (Floor40.call e598174948718 u0 u2 u1 []) = some u27 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege598174948718
end Witness598174948718
namespace Witness598175320942
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u1 u0
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.lam u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u1 u10
private def u12 := Term.app u11 u9
private def u13 := Term.lam u12
private def u14 := Term.app u9 u13
private def u15 := Term.app u14 u9
private def u16 := Term.lam u0
private def u17 := Term.lam u16
private def u18 := Term.app u1 u17
private def u19 := Term.lam u2
private def u20 := Term.app u1 u19
private def u21 := Term.var 4
private def u22 := Term.app u18 u21
private def u23 := Term.lam u22
private def u24 := Term.app u20 u23
private def u25 := Term.lam u24
private def u26 := Term.app u18 u25
private def u27 := Term.lam u26
private def u28 := Term.app u18 u27
private def u29 := Term.lam u28
private def u30 := Term.app u15 u29
private def u31 := Term.app u0 u19
private def u32 := Term.app u31 u1
theorem nege598175320942 : ¬ IsSelfInterpreter e598175320942 := by
  intro he
  have hv : NFt u32 := by decide
  have reach : Betas (Floor40.call e598175320942 u0 u2 u1 []) u32 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left]] (Floor40.call e598175320942 u0 u2 u1 []) = some u30 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege598175320942
end Witness598175320942
namespace Witness598293089142
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u1 u9
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.lam u12
private def u14 := Term.app u9 u13
private def u15 := Term.app u14 u9
private def u16 := Term.app u1 u13
private def u17 := Term.app u16 u0
private def u18 := Term.lam u17
private def u19 := Term.lam u18
private def u20 := Term.app u15 u19
private def u21 := Term.app u20 u0
private def u22 := Term.lam u0
private def u23 := Term.lam u22
private def u24 := Term.app u1 u23
private def u25 := Term.lam u2
private def u26 := Term.app u1 u25
private def u27 := Term.var 4
private def u28 := Term.app u24 u27
private def u29 := Term.lam u28
private def u30 := Term.app u26 u29
private def u31 := Term.lam u30
private def u32 := Term.app u24 u31
private def u33 := Term.lam u32
private def u34 := Term.app u24 u33
private def u35 := Term.lam u34
private def u36 := Term.app u21 u35
private def u37 := Term.app u0 u25
private def u38 := Term.app u37 u1
private def u39 := Term.app u13 u19
private def u40 := Term.app u39 u9
private def u41 := Term.app u40 u19
private def u42 := Term.app u41 u0
private def u43 := Term.app u42 u35
theorem nege598293089142 : ¬ IsSelfInterpreter e598293089142 := by
  intro he
  have hv : NFt u38 := by decide
  have reach : Betas (Floor40.call e598293089142 u0 u2 u1 []) u38 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] (Floor40.call e598293089142 u0 u2 u1 []) = some u36 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u36) (u := u43) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]]) (by decide)) j hj
#print axioms nege598293089142
end Witness598293089142
namespace Witness598293089198
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u0 u1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.lam u8
private def u10 := Term.app u3 u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u9 u12
private def u14 := Term.app u13 u9
private def u15 := Term.app u14 u12
private def u16 := Term.app u15 u0
private def u17 := Term.lam u0
private def u18 := Term.lam u17
private def u19 := Term.app u1 u18
private def u20 := Term.lam u2
private def u21 := Term.app u1 u20
private def u22 := Term.var 4
private def u23 := Term.app u19 u22
private def u24 := Term.lam u23
private def u25 := Term.app u21 u24
private def u26 := Term.lam u25
private def u27 := Term.app u19 u26
private def u28 := Term.lam u27
private def u29 := Term.app u19 u28
private def u30 := Term.lam u29
private def u31 := Term.app u16 u30
private def u32 := Term.app u0 u20
private def u33 := Term.app u32 u1
private def u34 := Term.app u3 u12
private def u35 := Term.lam u34
private def u36 := Term.lam u35
private def u37 := Term.app u12 u36
private def u38 := Term.app u37 u9
private def u39 := Term.app u38 u12
private def u40 := Term.app u39 u0
private def u41 := Term.app u40 u30
theorem nege598293089198 : ¬ IsSelfInterpreter e598293089198 := by
  intro he
  have hv : NFt u33 := by decide
  have reach : Betas (Floor40.call e598293089198 u0 u2 u1 []) u33 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] (Floor40.call e598293089198 u0 u2 u1 []) = some u31 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u31) (u := u41) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]]) (by decide)) j hj
#print axioms nege598293089198
end Witness598293089198
namespace Witness598293089238
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.app u8 u0
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u11 u1
private def u13 := Term.app u12 u0
private def u14 := Term.lam u13
private def u15 := Term.lam u14
private def u16 := Term.app u11 u15
private def u17 := Term.var 3
private def u18 := Term.app u17 u1
private def u19 := Term.app u18 u0
private def u20 := Term.lam u19
private def u21 := Term.lam u20
private def u22 := Term.app u0 u21
private def u23 := Term.app u22 u1
private def u24 := Term.lam u23
private def u25 := Term.lam u24
private def u26 := Term.app u16 u25
private def u27 := Term.lam u8
private def u28 := Term.app u27 u27
private def u29 := Term.app u28 u0
private def u30 := Term.app u29 u1
private def u31 := Term.lam u30
private def u32 := Term.lam u31
private def u33 := Term.app u26 u32
private def u34 := Term.app u33 u25
private def u35 := Term.app u34 u0
private def u36 := Term.lam u0
private def u37 := Term.lam u36
private def u38 := Term.app u1 u37
private def u39 := Term.lam u2
private def u40 := Term.app u1 u39
private def u41 := Term.var 4
private def u42 := Term.app u38 u41
private def u43 := Term.lam u42
private def u44 := Term.app u40 u43
private def u45 := Term.lam u44
private def u46 := Term.app u38 u45
private def u47 := Term.lam u46
private def u48 := Term.app u38 u47
private def u49 := Term.lam u48
private def u50 := Term.app u35 u49
private def u51 := Term.app u0 u39
private def u52 := Term.app u51 u1
private def u53 := Term.app u8 u15
private def u54 := Term.lam u53
private def u55 := Term.app u54 u25
private def u56 := Term.app u55 u32
private def u57 := Term.app u56 u25
private def u58 := Term.app u57 u0
private def u59 := Term.app u58 u49
theorem nege598293089238 : ¬ IsSelfInterpreter e598293089238 := by
  intro he
  have hv : NFt u52 := by decide
  have reach : Betas (Floor40.call e598293089238 u0 u2 u1 []) u52 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left],[.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.under,.right,.under,.under,.left],[.left,.left,.left,.under,.right,.under,.under],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.under,.right,.under,.under,.left],[.left,.left,.left,.left,.under,.right,.under,.under],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.right,.under,.under],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left,.left]] (Floor40.call e598293089238 u0 u2 u1 []) = some u50 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (clockNF reach hv) hr
  exact pump_no_count (t := u50) (u := u59) [] (by decide) (replay_sound (ps := [[.left,.left,.left,.left,.left,.under,.right,.under,.under,.left],[.left,.left,.left,.left,.left,.under,.right,.under,.under],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.right,.under,.under,.left],[.left,.left,.left,.left,.left,.right,.under,.under],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]]) (by decide)) j hj
#print axioms nege598293089238
end Witness598293089238
namespace Witness598346324206
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.lam u3
private def u5 := Term.app u1 u4
private def u6 := Term.app u5 u3
private def u7 := Term.lam u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u1 u11
private def u13 := Term.app u12 u10
private def u14 := Term.lam u13
private def u15 := Term.app u10 u14
private def u16 := Term.app u15 u10
private def u17 := Term.lam u0
private def u18 := Term.lam u17
private def u19 := Term.app u1 u18
private def u20 := Term.lam u2
private def u21 := Term.app u1 u20
private def u22 := Term.var 4
private def u23 := Term.app u19 u22
private def u24 := Term.lam u23
private def u25 := Term.app u21 u24
private def u26 := Term.lam u25
private def u27 := Term.app u19 u26
private def u28 := Term.lam u27
private def u29 := Term.app u19 u28
private def u30 := Term.lam u29
private def u31 := Term.app u16 u30
private def u32 := Term.app u0 u20
private def u33 := Term.app u32 u1
theorem nege598346324206 : ¬ IsSelfInterpreter e598346324206 := by
  intro he
  have hv : NFt u33 := by decide
  have reach : Betas (Floor40.call e598346324206 u0 u2 u1 []) u33 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left]] (Floor40.call e598346324206 u0 u2 u1 []) = some u31 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege598346324206
end Witness598346324206
end Blc.Floor41
