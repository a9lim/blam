import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e552690678298 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552690678298 : Closed e552690678298 ∧ code e552690678298 = 2751713933850 := by decide
theorem cert_e552690678298 : check e552690678298 [[]] .width = true := by decide
def e552690679834 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552690679834 : Closed e552690679834 ∧ code e552690679834 = 2751713935386 := by decide
theorem cert_e552690679834 : check e552690679834 [[]] .width = true := by decide
def e552690679926 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552690679926 : Closed e552690679926 ∧ code e552690679926 = 2751713935478 := by decide
theorem cert_e552690679926 : check e552690679926 [[]] .width = true := by decide
def e552690680170 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552690680170 : Closed e552690680170 ∧ code e552690680170 = 2751713935722 := by decide
theorem cert_e552690680170 : check e552690680170 [[]] .width = true := by decide
def e552690680218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552690680218 : Closed e552690680218 ∧ code e552690680218 = 2751713935770 := by decide
theorem cert_e552690680218 : check e552690680218 [[]] .width = true := by decide
def e552690681226 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552690681226 : Closed e552690681226 ∧ code e552690681226 = 2751713936778 := by decide
theorem cert_e552690681226 : check e552690681226 [[]] .width = true := by decide
def e552690681250 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552690681250 : Closed e552690681250 ∧ code e552690681250 = 2751713936802 := by decide
theorem cert_e552690681250 : check e552690681250 [[]] .width = true := by decide
def e552690681358 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552690681358 : Closed e552690681358 ∧ code e552690681358 = 2751713936910 := by decide
theorem cert_e552690681358 : check e552690681358 [[]] .width = true := by decide
def e552690681370 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552690681370 : Closed e552690681370 ∧ code e552690681370 = 2751713936922 := by decide
theorem cert_e552690681370 : check e552690681370 [[]] .width = true := by decide
def e552690681442 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552690681442 : Closed e552690681442 ∧ code e552690681442 = 2751713936994 := by decide
theorem cert_e552690681442 : check e552690681442 [[]] .width = true := by decide
def e552695426586 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552695426586 : Closed e552695426586 ∧ code e552695426586 = 2751718682138 := by decide
theorem cert_e552695426586 : check e552695426586 [[]] .width = true := by decide
def e552695459354 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552695459354 : Closed e552695459354 ∧ code e552695459354 = 2751718714906 := by decide
theorem cert_e552695459354 : check e552695459354 [[]] .width = true := by decide
def e552695461402 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552695461402 : Closed e552695461402 ∧ code e552695461402 = 2751718716954 := by decide
theorem cert_e552695461402 : check e552695461402 [[]] .width = true := by decide
def e552695688730 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552695688730 : Closed e552695688730 ∧ code e552695688730 = 2751718944282 := by decide
theorem cert_e552695688730 : check e552695688730 [[]] .width = true := by decide
def e552695737882 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552695737882 : Closed e552695737882 ∧ code e552695737882 = 2751718993434 := by decide
theorem cert_e552695737882 : check e552695737882 [[]] .width = true := by decide
def e552695740954 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552695740954 : Closed e552695740954 ∧ code e552695740954 = 2751718996506 := by decide
theorem cert_e552695740954 : check e552695740954 [[]] .width = true := by decide
def e552695852570 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552695852570 : Closed e552695852570 ∧ code e552695852570 = 2751719108122 := by decide
theorem cert_e552695852570 : check e552695852570 [[]] .width = true := by decide
def e552695854618 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552695854618 : Closed e552695854618 ∧ code e552695854618 = 2751719110170 := by decide
theorem cert_e552695854618 : check e552695854618 [[]] .width = true := by decide
def e552695868954 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552695868954 : Closed e552695868954 ∧ code e552695868954 = 2751719124506 := by decide
theorem cert_e552695868954 : check e552695868954 [[]] .width = true := by decide
def e552695872026 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552695872026 : Closed e552695872026 ∧ code e552695872026 = 2751719127578 := by decide
theorem cert_e552695872026 : check e552695872026 [[]] .width = true := by decide
def e552695879194 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552695879194 : Closed e552695879194 ∧ code e552695879194 = 2751719134746 := by decide
private def t_e552695879194 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552695879194 : ¬ IsSelfInterpreter e552695879194 :=
  wSource (t := t_e552695879194) (replay_sound (ps := []) (t := e552695879194) (by decide)) (by decide)
def e552695880218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552695880218 : Closed e552695880218 ∧ code e552695880218 = 2751719135770 := by decide
private def t_e552695880218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552695880218 : ¬ IsSelfInterpreter e552695880218 :=
  wSource (t := t_e552695880218) (replay_sound (ps := []) (t := e552695880218) (by decide)) (by decide)
def e552696999450 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552696999450 : Closed e552696999450 ∧ code e552696999450 = 2751720255002 := by decide
theorem cert_e552696999450 : check e552696999450 [[]] .width = true := by decide
def e552697032218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552697032218 : Closed e552697032218 ∧ code e552697032218 = 2751720287770 := by decide
theorem cert_e552697032218 : check e552697032218 [[]] .width = true := by decide
def e552697034266 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552697034266 : Closed e552697034266 ∧ code e552697034266 = 2751720289818 := by decide
theorem cert_e552697034266 : check e552697034266 [[]] .width = true := by decide
def e552697720346 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552697720346 : Closed e552697720346 ∧ code e552697720346 = 2751720975898 := by decide
theorem cert_e552697720346 : check e552697720346 [[]] .width = true := by decide
def e552697823258 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552697823258 : Closed e552697823258 ∧ code e552697823258 = 2751721078810 := by decide
theorem cert_e552697823258 : check e552697823258 [[]] .width = true := by decide
def e552697823350 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552697823350 : Closed e552697823350 ∧ code e552697823350 = 2751721078902 := by decide
theorem cert_e552697823350 : check e552697823350 [[]] .width = true := by decide
def e552697823594 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552697823594 : Closed e552697823594 ∧ code e552697823594 = 2751721079146 := by decide
theorem cert_e552697823594 : check e552697823594 [[]] .width = true := by decide
def e552697823642 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552697823642 : Closed e552697823642 ∧ code e552697823642 = 2751721079194 := by decide
theorem cert_e552697823642 : check e552697823642 [[]] .width = true := by decide
def e552697824650 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552697824650 : Closed e552697824650 ∧ code e552697824650 = 2751721080202 := by decide
theorem cert_e552697824650 : check e552697824650 [[]] .width = true := by decide
def e552697824674 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552697824674 : Closed e552697824674 ∧ code e552697824674 = 2751721080226 := by decide
theorem cert_e552697824674 : check e552697824674 [[]] .width = true := by decide
def e552697824782 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552697824782 : Closed e552697824782 ∧ code e552697824782 = 2751721080334 := by decide
theorem cert_e552697824782 : check e552697824782 [[]] .width = true := by decide
def e552697824794 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552697824794 : Closed e552697824794 ∧ code e552697824794 = 2751721080346 := by decide
theorem cert_e552697824794 : check e552697824794 [[]] .width = true := by decide
def e552697824866 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552697824866 : Closed e552697824866 ∧ code e552697824866 = 2751721080418 := by decide
theorem cert_e552697824866 : check e552697824866 [[]] .width = true := by decide
def e552697916954 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552697916954 : Closed e552697916954 ∧ code e552697916954 = 2751721172506 := by decide
theorem cert_e552697916954 : check e552697916954 [[]] .width = true := by decide
def e552697919002 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552697919002 : Closed e552697919002 ∧ code e552697919002 = 2751721174554 := by decide
theorem cert_e552697919002 : check e552697919002 [[]] .width = true := by decide
def e552697954330 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552697954330 : Closed e552697954330 ∧ code e552697954330 = 2751721209882 := by decide
theorem cert_e552697954330 : check e552697954330 [[]] .width = true := by decide
def e552697954422 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552697954422 : Closed e552697954422 ∧ code e552697954422 = 2751721209974 := by decide
theorem cert_e552697954422 : check e552697954422 [[]] .width = true := by decide
def e552697954666 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552697954666 : Closed e552697954666 ∧ code e552697954666 = 2751721210218 := by decide
theorem cert_e552697954666 : check e552697954666 [[]] .width = true := by decide
def e552697954714 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552697954714 : Closed e552697954714 ∧ code e552697954714 = 2751721210266 := by decide
theorem cert_e552697954714 : check e552697954714 [[]] .width = true := by decide
def e552697955722 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552697955722 : Closed e552697955722 ∧ code e552697955722 = 2751721211274 := by decide
theorem cert_e552697955722 : check e552697955722 [[]] .width = true := by decide
def e552697955746 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552697955746 : Closed e552697955746 ∧ code e552697955746 = 2751721211298 := by decide
theorem cert_e552697955746 : check e552697955746 [[]] .width = true := by decide
def e552697955854 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552697955854 : Closed e552697955854 ∧ code e552697955854 = 2751721211406 := by decide
theorem cert_e552697955854 : check e552697955854 [[]] .width = true := by decide
def e552697955866 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552697955866 : Closed e552697955866 ∧ code e552697955866 = 2751721211418 := by decide
theorem cert_e552697955866 : check e552697955866 [[]] .width = true := by decide
def e552697955938 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552697955938 : Closed e552697955938 ∧ code e552697955938 = 2751721211490 := by decide
theorem cert_e552697955938 : check e552697955938 [[]] .width = true := by decide
def e552698572314 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552698572314 : Closed e552698572314 ∧ code e552698572314 = 2751721827866 := by decide
theorem cert_e552698572314 : check e552698572314 [[]] .width = true := by decide
def e552698621466 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552698621466 : Closed e552698621466 ∧ code e552698621466 = 2751721877018 := by decide
theorem cert_e552698621466 : check e552698621466 [[]] .width = true := by decide
def e552698624538 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552698624538 : Closed e552698624538 ∧ code e552698624538 = 2751721880090 := by decide
theorem cert_e552698624538 : check e552698624538 [[]] .width = true := by decide
def e552698768922 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552698768922 : Closed e552698768922 ∧ code e552698768922 = 2751722024474 := by decide
theorem cert_e552698768922 : check e552698768922 [[]] .width = true := by decide
def e552698871834 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552698871834 : Closed e552698871834 ∧ code e552698871834 = 2751722127386 := by decide
theorem cert_e552698871834 : check e552698871834 [[]] .width = true := by decide
def e552698871926 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552698871926 : Closed e552698871926 ∧ code e552698871926 = 2751722127478 := by decide
theorem cert_e552698871926 : check e552698871926 [[]] .width = true := by decide
def e552698872170 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552698872170 : Closed e552698872170 ∧ code e552698872170 = 2751722127722 := by decide
theorem cert_e552698872170 : check e552698872170 [[]] .width = true := by decide
def e552698872218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552698872218 : Closed e552698872218 ∧ code e552698872218 = 2751722127770 := by decide
theorem cert_e552698872218 : check e552698872218 [[]] .width = true := by decide
def e552698873226 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552698873226 : Closed e552698873226 ∧ code e552698873226 = 2751722128778 := by decide
theorem cert_e552698873226 : check e552698873226 [[]] .width = true := by decide
def e552698873250 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552698873250 : Closed e552698873250 ∧ code e552698873250 = 2751722128802 := by decide
theorem cert_e552698873250 : check e552698873250 [[]] .width = true := by decide
def e552698873358 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552698873358 : Closed e552698873358 ∧ code e552698873358 = 2751722128910 := by decide
theorem cert_e552698873358 : check e552698873358 [[]] .width = true := by decide
def e552698873370 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552698873370 : Closed e552698873370 ∧ code e552698873370 = 2751722128922 := by decide
theorem cert_e552698873370 : check e552698873370 [[]] .width = true := by decide
def e552698873442 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552698873442 : Closed e552698873442 ∧ code e552698873442 = 2751722128994 := by decide
theorem cert_e552698873442 : check e552698873442 [[]] .width = true := by decide
def e552699063834 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699063834 : Closed e552699063834 ∧ code e552699063834 = 2751722319386 := by decide
theorem cert_e552699063834 : check e552699063834 [[]] .width = true := by decide
def e552699066906 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699066906 : Closed e552699066906 ∧ code e552699066906 = 2751722322458 := by decide
theorem cert_e552699066906 : check e552699066906 [[]] .width = true := by decide
def e552699068442 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552699068442 : Closed e552699068442 ∧ code e552699068442 = 2751722323994 := by decide
theorem cert_e552699068442 : check e552699068442 [[]] .width = true := by decide
def e552699068534 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552699068534 : Closed e552699068534 ∧ code e552699068534 = 2751722324086 := by decide
theorem cert_e552699068534 : check e552699068534 [[]] .width = true := by decide
def e552699068778 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552699068778 : Closed e552699068778 ∧ code e552699068778 = 2751722324330 := by decide
theorem cert_e552699068778 : check e552699068778 [[]] .width = true := by decide
def e552699068826 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552699068826 : Closed e552699068826 ∧ code e552699068826 = 2751722324378 := by decide
theorem cert_e552699068826 : check e552699068826 [[]] .width = true := by decide
def e552699069834 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552699069834 : Closed e552699069834 ∧ code e552699069834 = 2751722325386 := by decide
theorem cert_e552699069834 : check e552699069834 [[]] .width = true := by decide
def e552699069858 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552699069858 : Closed e552699069858 ∧ code e552699069858 = 2751722325410 := by decide
theorem cert_e552699069858 : check e552699069858 [[]] .width = true := by decide
def e552699069966 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552699069966 : Closed e552699069966 ∧ code e552699069966 = 2751722325518 := by decide
theorem cert_e552699069966 : check e552699069966 [[]] .width = true := by decide
def e552699069978 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552699069978 : Closed e552699069978 ∧ code e552699069978 = 2751722325530 := by decide
theorem cert_e552699069978 : check e552699069978 [[]] .width = true := by decide
def e552699070050 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552699070050 : Closed e552699070050 ∧ code e552699070050 = 2751722325602 := by decide
theorem cert_e552699070050 : check e552699070050 [[]] .width = true := by decide
def e552699391514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699391514 : Closed e552699391514 ∧ code e552699391514 = 2751722647066 := by decide
private def t_e552699391514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552699391514 : ¬ IsSelfInterpreter e552699391514 :=
  wSource (t := t_e552699391514) (replay_sound (ps := []) (t := e552699391514) (by decide)) (by decide)
def e552699393562 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699393562 : Closed e552699393562 ∧ code e552699393562 = 2751722649114 := by decide
private def t_e552699393562 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552699393562 : ¬ IsSelfInterpreter e552699393562 :=
  wSource (t := t_e552699393562) (replay_sound (ps := []) (t := e552699393562) (by decide)) (by decide)
def e552699407898 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699407898 : Closed e552699407898 ∧ code e552699407898 = 2751722663450 := by decide
private def t_e552699407898 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552699407898 : ¬ IsSelfInterpreter e552699407898 :=
  wSource (t := t_e552699407898) (replay_sound (ps := []) (t := e552699407898) (by decide)) (by decide)
def e552699410970 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699410970 : Closed e552699410970 ∧ code e552699410970 = 2751722666522 := by decide
private def t_e552699410970 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552699410970 : ¬ IsSelfInterpreter e552699410970 :=
  wSource (t := t_e552699410970) (replay_sound (ps := []) (t := e552699410970) (by decide)) (by decide)
def e552699418138 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699418138 : Closed e552699418138 ∧ code e552699418138 = 2751722673690 := by decide
private def t_e552699418138 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552699418138 : ¬ IsSelfInterpreter e552699418138 :=
  wSource (t := t_e552699418138) (replay_sound (ps := []) (t := e552699418138) (by decide)) (by decide)
def e552699419162 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699419162 : Closed e552699419162 ∧ code e552699419162 = 2751722674714 := by decide
private def t_e552699419162 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552699419162 : ¬ IsSelfInterpreter e552699419162 :=
  wSource (t := t_e552699419162) (replay_sound (ps := []) (t := e552699419162) (by decide)) (by decide)
def e552699489818 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699489818 : Closed e552699489818 ∧ code e552699489818 = 2751722745370 := by decide
private def t_e552699489818 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552699489818 : ¬ IsSelfInterpreter e552699489818 :=
  wSource (t := t_e552699489818) (replay_sound (ps := []) (t := e552699489818) (by decide)) (by decide)
def e552699491866 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699491866 : Closed e552699491866 ∧ code e552699491866 = 2751722747418 := by decide
private def t_e552699491866 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552699491866 : ¬ IsSelfInterpreter e552699491866 :=
  wSource (t := t_e552699491866) (replay_sound (ps := []) (t := e552699491866) (by decide)) (by decide)
def e552699527194 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552699527194 : Closed e552699527194 ∧ code e552699527194 = 2751722782746 := by decide
theorem cert_e552699527194 : check e552699527194 [[]] .width = true := by decide
def e552699527286 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552699527286 : Closed e552699527286 ∧ code e552699527286 = 2751722782838 := by decide
theorem cert_e552699527286 : check e552699527286 [[]] .width = true := by decide
def e552699527530 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552699527530 : Closed e552699527530 ∧ code e552699527530 = 2751722783082 := by decide
theorem cert_e552699527530 : check e552699527530 [[]] .width = true := by decide
def e552699527578 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552699527578 : Closed e552699527578 ∧ code e552699527578 = 2751722783130 := by decide
theorem cert_e552699527578 : check e552699527578 [[]] .width = true := by decide
def e552699528586 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552699528586 : Closed e552699528586 ∧ code e552699528586 = 2751722784138 := by decide
theorem cert_e552699528586 : check e552699528586 [[]] .width = true := by decide
def e552699528610 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552699528610 : Closed e552699528610 ∧ code e552699528610 = 2751722784162 := by decide
private def t_e552699528610 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e552699528610 : ¬ IsSelfInterpreter e552699528610 :=
  wSource (t := t_e552699528610) (replay_sound (ps := []) (t := e552699528610) (by decide)) (by decide)
def e552699528718 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552699528718 : Closed e552699528718 ∧ code e552699528718 = 2751722784270 := by decide
theorem cert_e552699528718 : check e552699528718 [[]] .width = true := by decide
def e552699528730 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552699528730 : Closed e552699528730 ∧ code e552699528730 = 2751722784282 := by decide
private def t_e552699528730 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e552699528730 : ¬ IsSelfInterpreter e552699528730 :=
  wSource (t := t_e552699528730) (replay_sound (ps := []) (t := e552699528730) (by decide)) (by decide)
def e552699528802 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552699528802 : Closed e552699528802 ∧ code e552699528802 = 2751722784354 := by decide
theorem cert_e552699528802 : check e552699528802 [[]] .width = true := by decide
def e552699588122 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699588122 : Closed e552699588122 ∧ code e552699588122 = 2751722843674 := by decide
private def t_e552699588122 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552699588122 : ¬ IsSelfInterpreter e552699588122 :=
  wSource (t := t_e552699588122) (replay_sound (ps := []) (t := e552699588122) (by decide)) (by decide)
def e552699591194 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699591194 : Closed e552699591194 ∧ code e552699591194 = 2751722846746 := by decide
private def t_e552699591194 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552699591194 : ¬ IsSelfInterpreter e552699591194 :=
  wSource (t := t_e552699591194) (replay_sound (ps := []) (t := e552699591194) (by decide)) (by decide)
def e552699592730 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552699592730 : Closed e552699592730 ∧ code e552699592730 = 2751722848282 := by decide
theorem cert_e552699592730 : check e552699592730 [[]] .width = true := by decide
def e552699592822 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552699592822 : Closed e552699592822 ∧ code e552699592822 = 2751722848374 := by decide
theorem cert_e552699592822 : check e552699592822 [[]] .width = true := by decide
def e552699593066 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552699593066 : Closed e552699593066 ∧ code e552699593066 = 2751722848618 := by decide
theorem cert_e552699593066 : check e552699593066 [[]] .width = true := by decide
def e552699593114 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552699593114 : Closed e552699593114 ∧ code e552699593114 = 2751722848666 := by decide
theorem cert_e552699593114 : check e552699593114 [[]] .width = true := by decide
def e552699594122 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552699594122 : Closed e552699594122 ∧ code e552699594122 = 2751722849674 := by decide
theorem cert_e552699594122 : check e552699594122 [[]] .width = true := by decide
def e552699594146 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552699594146 : Closed e552699594146 ∧ code e552699594146 = 2751722849698 := by decide
private def t_e552699594146 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e552699594146 : ¬ IsSelfInterpreter e552699594146 :=
  wSource (t := t_e552699594146) (replay_sound (ps := []) (t := e552699594146) (by decide)) (by decide)
def e552699594254 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552699594254 : Closed e552699594254 ∧ code e552699594254 = 2751722849806 := by decide
theorem cert_e552699594254 : check e552699594254 [[]] .width = true := by decide
def e552699594266 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552699594266 : Closed e552699594266 ∧ code e552699594266 = 2751722849818 := by decide
private def t_e552699594266 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e552699594266 : ¬ IsSelfInterpreter e552699594266 :=
  wSource (t := t_e552699594266) (replay_sound (ps := []) (t := e552699594266) (by decide)) (by decide)
def e552699594338 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552699594338 : Closed e552699594338 ∧ code e552699594338 = 2751722849890 := by decide
theorem cert_e552699594338 : check e552699594338 [[]] .width = true := by decide
def e552699639322 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699639322 : Closed e552699639322 ∧ code e552699639322 = 2751722894874 := by decide
private def t_e552699639322 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552699639322 : ¬ IsSelfInterpreter e552699639322 :=
  wSource (t := t_e552699639322) (replay_sound (ps := []) (t := e552699639322) (by decide)) (by decide)
def e552699640346 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552699640346 : Closed e552699640346 ∧ code e552699640346 = 2751722895898 := by decide
private def t_e552699640346 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e552699640346 : ¬ IsSelfInterpreter e552699640346 :=
  wSource (t := t_e552699640346) (replay_sound (ps := []) (t := e552699640346) (by decide)) (by decide)
def e552757816858 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552757816858 : Closed e552757816858 ∧ code e552757816858 = 2751781072410 := by decide
theorem cert_e552757816858 : check e552757816858 [[]] .width = true := by decide
def e552758341146 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552758341146 : Closed e552758341146 ∧ code e552758341146 = 2751781596698 := by decide
theorem cert_e552758341146 : check e552758341146 [[]] .width = true := by decide
def e552758373914 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552758373914 : Closed e552758373914 ∧ code e552758373914 = 2751781629466 := by decide
theorem cert_e552758373914 : check e552758373914 [[]] .width = true := by decide
def e552758375962 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552758375962 : Closed e552758375962 ∧ code e552758375962 = 2751781631514 := by decide
theorem cert_e552758375962 : check e552758375962 [[]] .width = true := by decide
def e552769351194 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552769351194 : Closed e552769351194 ∧ code e552769351194 = 2751792606746 := by decide
theorem cert_e552769351194 : check e552769351194 [[]] .width = true := by decide
def e552771120666 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552771120666 : Closed e552771120666 ∧ code e552771120666 = 2751794376218 := by decide
theorem cert_e552771120666 : check e552771120666 [[]] .width = true := by decide
def e552771223578 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552771223578 : Closed e552771223578 ∧ code e552771223578 = 2751794479130 := by decide
theorem cert_e552771223578 : check e552771223578 [[]] .width = true := by decide
def e552771223670 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552771223670 : Closed e552771223670 ∧ code e552771223670 = 2751794479222 := by decide
theorem cert_e552771223670 : check e552771223670 [[]] .width = true := by decide
def e552771223914 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552771223914 : Closed e552771223914 ∧ code e552771223914 = 2751794479466 := by decide
theorem cert_e552771223914 : check e552771223914 [[]] .width = true := by decide
def e552771223962 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552771223962 : Closed e552771223962 ∧ code e552771223962 = 2751794479514 := by decide
theorem cert_e552771223962 : check e552771223962 [[]] .width = true := by decide
def e552771224970 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552771224970 : Closed e552771224970 ∧ code e552771224970 = 2751794480522 := by decide
theorem cert_e552771224970 : check e552771224970 [[]] .width = true := by decide
def e552771224994 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552771224994 : Closed e552771224994 ∧ code e552771224994 = 2751794480546 := by decide
theorem cert_e552771224994 : check e552771224994 [[]] .width = true := by decide
def e552771225102 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552771225102 : Closed e552771225102 ∧ code e552771225102 = 2751794480654 := by decide
theorem cert_e552771225102 : check e552771225102 [[]] .width = true := by decide
def e552771225114 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552771225114 : Closed e552771225114 ∧ code e552771225114 = 2751794480666 := by decide
theorem cert_e552771225114 : check e552771225114 [[]] .width = true := by decide
def e552771225186 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552771225186 : Closed e552771225186 ∧ code e552771225186 = 2751794480738 := by decide
theorem cert_e552771225186 : check e552771225186 [[]] .width = true := by decide
def e552772496922 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552772496922 : Closed e552772496922 ∧ code e552772496922 = 2751795752474 := by decide
theorem cert_e552772496922 : check e552772496922 [[]] .width = true := by decide
def e552772529690 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552772529690 : Closed e552772529690 ∧ code e552772529690 = 2751795785242 := by decide
theorem cert_e552772529690 : check e552772529690 [[]] .width = true := by decide
def e552772531738 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 2)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552772531738 : Closed e552772531738 ∧ code e552772531738 = 2751795787290 := by decide
theorem cert_e552772531738 : check e552772531738 [[]] .width = true := by decide
def e552773217818 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552773217818 : Closed e552773217818 ∧ code e552773217818 = 2751796473370 := by decide
theorem cert_e552773217818 : check e552773217818 [[]] .width = true := by decide
def e552773320730 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552773320730 : Closed e552773320730 ∧ code e552773320730 = 2751796576282 := by decide
theorem cert_e552773320730 : check e552773320730 [[]] .width = true := by decide
def e552773320822 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552773320822 : Closed e552773320822 ∧ code e552773320822 = 2751796576374 := by decide
theorem cert_e552773320822 : check e552773320822 [[]] .width = true := by decide
def e552773321066 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552773321066 : Closed e552773321066 ∧ code e552773321066 = 2751796576618 := by decide
theorem cert_e552773321066 : check e552773321066 [[]] .width = true := by decide
def e552773321114 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552773321114 : Closed e552773321114 ∧ code e552773321114 = 2751796576666 := by decide
theorem cert_e552773321114 : check e552773321114 [[]] .width = true := by decide
def e552773322122 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552773322122 : Closed e552773322122 ∧ code e552773322122 = 2751796577674 := by decide
theorem cert_e552773322122 : check e552773322122 [[]] .width = true := by decide
def e552773322146 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552773322146 : Closed e552773322146 ∧ code e552773322146 = 2751796577698 := by decide
theorem cert_e552773322146 : check e552773322146 [[]] .width = true := by decide
def e552773322254 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552773322254 : Closed e552773322254 ∧ code e552773322254 = 2751796577806 := by decide
theorem cert_e552773322254 : check e552773322254 [[]] .width = true := by decide
def e552773322266 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552773322266 : Closed e552773322266 ∧ code e552773322266 = 2751796577818 := by decide
theorem cert_e552773322266 : check e552773322266 [[]] .width = true := by decide
def e552773322338 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552773322338 : Closed e552773322338 ∧ code e552773322338 = 2751796577890 := by decide
theorem cert_e552773322338 : check e552773322338 [[]] .width = true := by decide
def e552773414426 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552773414426 : Closed e552773414426 ∧ code e552773414426 = 2751796669978 := by decide
theorem cert_e552773414426 : check e552773414426 [[]] .width = true := by decide
def e552773416474 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552773416474 : Closed e552773416474 ∧ code e552773416474 = 2751796672026 := by decide
theorem cert_e552773416474 : check e552773416474 [[]] .width = true := by decide
def e552773451802 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552773451802 : Closed e552773451802 ∧ code e552773451802 = 2751796707354 := by decide
theorem cert_e552773451802 : check e552773451802 [[]] .width = true := by decide
def e552773451894 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552773451894 : Closed e552773451894 ∧ code e552773451894 = 2751796707446 := by decide
theorem cert_e552773451894 : check e552773451894 [[]] .width = true := by decide
def e552773452138 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552773452138 : Closed e552773452138 ∧ code e552773452138 = 2751796707690 := by decide
theorem cert_e552773452138 : check e552773452138 [[]] .width = true := by decide
def e552773452186 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552773452186 : Closed e552773452186 ∧ code e552773452186 = 2751796707738 := by decide
theorem cert_e552773452186 : check e552773452186 [[]] .width = true := by decide
def e552773453194 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552773453194 : Closed e552773453194 ∧ code e552773453194 = 2751796708746 := by decide
theorem cert_e552773453194 : check e552773453194 [[]] .width = true := by decide
def e552773453218 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552773453218 : Closed e552773453218 ∧ code e552773453218 = 2751796708770 := by decide
theorem cert_e552773453218 : check e552773453218 [[]] .width = true := by decide
def e552773453326 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552773453326 : Closed e552773453326 ∧ code e552773453326 = 2751796708878 := by decide
theorem cert_e552773453326 : check e552773453326 [[]] .width = true := by decide
def e552773453338 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552773453338 : Closed e552773453338 ∧ code e552773453338 = 2751796708890 := by decide
theorem cert_e552773453338 : check e552773453338 [[]] .width = true := by decide
def e552773453410 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552773453410 : Closed e552773453410 ∧ code e552773453410 = 2751796708962 := by decide
theorem cert_e552773453410 : check e552773453410 [[]] .width = true := by decide
def e552815488538 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552815488538 : Closed e552815488538 ∧ code e552815488538 = 2751838744090 := by decide
theorem cert_e552815488538 : check e552815488538 [[]] .width = true := by decide
def e552817258010 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552817258010 : Closed e552817258010 ∧ code e552817258010 = 2751840513562 := by decide
theorem cert_e552817258010 : check e552817258010 [[]] .width = true := by decide
def e552817360922 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552817360922 : Closed e552817360922 ∧ code e552817360922 = 2751840616474 := by decide
theorem cert_e552817360922 : check e552817360922 [[]] .width = true := by decide
def e552817361014 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552817361014 : Closed e552817361014 ∧ code e552817361014 = 2751840616566 := by decide
theorem cert_e552817361014 : check e552817361014 [[]] .width = true := by decide
def e552817361258 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552817361258 : Closed e552817361258 ∧ code e552817361258 = 2751840616810 := by decide
theorem cert_e552817361258 : check e552817361258 [[]] .width = true := by decide
def e552817361306 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552817361306 : Closed e552817361306 ∧ code e552817361306 = 2751840616858 := by decide
theorem cert_e552817361306 : check e552817361306 [[]] .width = true := by decide
def e552817362314 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552817362314 : Closed e552817362314 ∧ code e552817362314 = 2751840617866 := by decide
theorem cert_e552817362314 : check e552817362314 [[]] .width = true := by decide
def e552817362338 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552817362338 : Closed e552817362338 ∧ code e552817362338 = 2751840617890 := by decide
theorem cert_e552817362338 : check e552817362338 [[]] .width = true := by decide
def e552817362446 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e552817362446 : Closed e552817362446 ∧ code e552817362446 = 2751840617998 := by decide
theorem cert_e552817362446 : check e552817362446 [[]] .width = true := by decide
def e552817362458 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e552817362458 : Closed e552817362458 ∧ code e552817362458 = 2751840618010 := by decide
theorem cert_e552817362458 : check e552817362458 [[]] .width = true := by decide
def e552817362530 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e552817362530 : Closed e552817362530 ∧ code e552817362530 = 2751840618082 := by decide
theorem cert_e552817362530 : check e552817362530 [[]] .width = true := by decide
def e552829120026 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552829120026 : Closed e552829120026 ∧ code e552829120026 = 2751852375578 := by decide
theorem cert_e552829120026 : check e552829120026 [[]] .width = true := by decide
def e552829152794 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552829152794 : Closed e552829152794 ∧ code e552829152794 = 2751852408346 := by decide
theorem cert_e552829152794 : check e552829152794 [[]] .width = true := by decide
def e552829154842 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552829154842 : Closed e552829154842 ∧ code e552829154842 = 2751852410394 := by decide
theorem cert_e552829154842 : check e552829154842 [[]] .width = true := by decide
def e552829840922 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e552829840922 : Closed e552829840922 ∧ code e552829840922 = 2751853096474 := by decide
theorem cert_e552829840922 : check e552829840922 [[]] .width = true := by decide
def e552829943834 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e552829943834 : Closed e552829943834 ∧ code e552829943834 = 2751853199386 := by decide
theorem cert_e552829943834 : check e552829943834 [[]] .width = true := by decide
def e552829943926 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e552829943926 : Closed e552829943926 ∧ code e552829943926 = 2751853199478 := by decide
theorem cert_e552829943926 : check e552829943926 [[]] .width = true := by decide
def e552829944170 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e552829944170 : Closed e552829944170 ∧ code e552829944170 = 2751853199722 := by decide
theorem cert_e552829944170 : check e552829944170 [[]] .width = true := by decide
def e552829944218 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e552829944218 : Closed e552829944218 ∧ code e552829944218 = 2751853199770 := by decide
theorem cert_e552829944218 : check e552829944218 [[]] .width = true := by decide
def e552829945226 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e552829945226 : Closed e552829945226 ∧ code e552829945226 = 2751853200778 := by decide
theorem cert_e552829945226 : check e552829945226 [[]] .width = true := by decide
def e552829945250 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e552829945250 : Closed e552829945250 ∧ code e552829945250 = 2751853200802 := by decide
theorem cert_e552829945250 : check e552829945250 [[]] .width = true := by decide
end Blc.Floor41
