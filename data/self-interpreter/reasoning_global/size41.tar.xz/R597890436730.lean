import CodeBridge
import R597890436730Blk0
import R597890436730Blk6
import R597890436730Blk12
import R597890436730Blk18
import R597890436730Blk24
import R597890436730Blk30
import R597890436730Blk36
import R597890436730Blk42
import R597890436730Blk48
namespace Certgen.R597890436730
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Floor41 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit73 : Term := .var 0
def lit53 : Term := .var 1
def lit21 : Term := .var 2
def lit72 : Term := .lam lit73
def lit52 : Term := .lam lit53
def lit69 : Term := .app lit73 lit73
def lit44 : Term := .lam lit72
def lit51 : Term := .lam lit52
def lit20 : Term := .app lit21 lit73
def lit68 : Term := .lam lit69
def lit7 : Term := .app lit73 lit69
def lit42 : Term := .app lit73 lit44
def lit49 : Term := .app lit73 lit51
def lit18 : Term := .app lit53 lit20
def lit6 : Term := .app lit7 lit73
def lit17 : Term := .lam lit18
def lit5 : Term := .lam lit6
def lit16 : Term := .lam lit17
def lit63 : Term := .app lit68 lit68
def lit14 : Term := .app lit73 lit16
def lit13 : Term := .lam lit14
def lit48 : Term := .app lit49 lit63
def lit47 : Term := .lam lit48
def lit4 : Term := .app lit5 lit13
def lit41 : Term := .app lit42 lit47
def lit40 : Term := .lam lit41
def lit3 : Term := .app lit4 lit51
def lit34 : Term := .app lit49 lit40
def lit33 : Term := .lam lit34
def lit27 : Term := .app lit49 lit33
def lit26 : Term := .lam lit27
def lit2 : Term := .app lit3 lit26
def lit1 : Term := .app lit2 lit63
def lit0 : Term := .app lit1 lit72
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub73 : model.term 73 = lit73 := model.var_eq 73 0 (by rfl)
theorem sub72 : model.term 72 = lit72 := by rw [model.lam_eq 72 73 (by rfl), sub73]; rfl
theorem sub71 : model.term 71 = lit73 := model.var_eq 71 0 (by rfl)
theorem sub70 : model.term 70 = lit73 := model.var_eq 70 0 (by rfl)
theorem sub69 : model.term 69 = lit69 := by rw [model.app_eq 69 70 71 (by rfl), sub70, sub71]; rfl
theorem sub68 : model.term 68 = lit68 := by rw [model.lam_eq 68 69 (by rfl), sub69]; rfl
theorem sub67 : model.term 67 = lit73 := model.var_eq 67 0 (by rfl)
theorem sub66 : model.term 66 = lit73 := model.var_eq 66 0 (by rfl)
theorem sub65 : model.term 65 = lit69 := by rw [model.app_eq 65 66 67 (by rfl), sub66, sub67]; rfl
theorem sub64 : model.term 64 = lit68 := by rw [model.lam_eq 64 65 (by rfl), sub65]; rfl
theorem sub63 : model.term 63 = lit63 := by rw [model.app_eq 63 64 68 (by rfl), sub64, sub68]; rfl
theorem sub62 : model.term 62 = lit73 := model.var_eq 62 0 (by rfl)
theorem sub61 : model.term 61 = lit73 := model.var_eq 61 0 (by rfl)
theorem sub60 : model.term 60 = lit69 := by rw [model.app_eq 60 61 62 (by rfl), sub61, sub62]; rfl
theorem sub59 : model.term 59 = lit68 := by rw [model.lam_eq 59 60 (by rfl), sub60]; rfl
theorem sub58 : model.term 58 = lit73 := model.var_eq 58 0 (by rfl)
theorem sub57 : model.term 57 = lit73 := model.var_eq 57 0 (by rfl)
theorem sub56 : model.term 56 = lit69 := by rw [model.app_eq 56 57 58 (by rfl), sub57, sub58]; rfl
theorem sub55 : model.term 55 = lit68 := by rw [model.lam_eq 55 56 (by rfl), sub56]; rfl
theorem sub54 : model.term 54 = lit63 := by rw [model.app_eq 54 55 59 (by rfl), sub55, sub59]; rfl
theorem sub53 : model.term 53 = lit53 := model.var_eq 53 1 (by rfl)
theorem sub52 : model.term 52 = lit52 := by rw [model.lam_eq 52 53 (by rfl), sub53]; rfl
theorem sub51 : model.term 51 = lit51 := by rw [model.lam_eq 51 52 (by rfl), sub52]; rfl
theorem sub50 : model.term 50 = lit73 := model.var_eq 50 0 (by rfl)
theorem sub49 : model.term 49 = lit49 := by rw [model.app_eq 49 50 51 (by rfl), sub50, sub51]; rfl
theorem sub48 : model.term 48 = lit48 := by rw [model.app_eq 48 49 54 (by rfl), sub49, sub54]; rfl
theorem sub47 : model.term 47 = lit47 := by rw [model.lam_eq 47 48 (by rfl), sub48]; rfl
theorem sub46 : model.term 46 = lit73 := model.var_eq 46 0 (by rfl)
theorem sub45 : model.term 45 = lit72 := by rw [model.lam_eq 45 46 (by rfl), sub46]; rfl
theorem sub44 : model.term 44 = lit44 := by rw [model.lam_eq 44 45 (by rfl), sub45]; rfl
theorem sub43 : model.term 43 = lit73 := model.var_eq 43 0 (by rfl)
theorem sub42 : model.term 42 = lit42 := by rw [model.app_eq 42 43 44 (by rfl), sub43, sub44]; rfl
theorem sub41 : model.term 41 = lit41 := by rw [model.app_eq 41 42 47 (by rfl), sub42, sub47]; rfl
theorem sub40 : model.term 40 = lit40 := by rw [model.lam_eq 40 41 (by rfl), sub41]; rfl
theorem sub39 : model.term 39 = lit53 := model.var_eq 39 1 (by rfl)
theorem sub38 : model.term 38 = lit52 := by rw [model.lam_eq 38 39 (by rfl), sub39]; rfl
theorem sub37 : model.term 37 = lit51 := by rw [model.lam_eq 37 38 (by rfl), sub38]; rfl
theorem sub36 : model.term 36 = lit73 := model.var_eq 36 0 (by rfl)
theorem sub35 : model.term 35 = lit49 := by rw [model.app_eq 35 36 37 (by rfl), sub36, sub37]; rfl
theorem sub34 : model.term 34 = lit34 := by rw [model.app_eq 34 35 40 (by rfl), sub35, sub40]; rfl
theorem sub33 : model.term 33 = lit33 := by rw [model.lam_eq 33 34 (by rfl), sub34]; rfl
theorem sub32 : model.term 32 = lit53 := model.var_eq 32 1 (by rfl)
theorem sub31 : model.term 31 = lit52 := by rw [model.lam_eq 31 32 (by rfl), sub32]; rfl
theorem sub30 : model.term 30 = lit51 := by rw [model.lam_eq 30 31 (by rfl), sub31]; rfl
theorem sub29 : model.term 29 = lit73 := model.var_eq 29 0 (by rfl)
theorem sub28 : model.term 28 = lit49 := by rw [model.app_eq 28 29 30 (by rfl), sub29, sub30]; rfl
theorem sub27 : model.term 27 = lit27 := by rw [model.app_eq 27 28 33 (by rfl), sub28, sub33]; rfl
theorem sub26 : model.term 26 = lit26 := by rw [model.lam_eq 26 27 (by rfl), sub27]; rfl
theorem sub25 : model.term 25 = lit53 := model.var_eq 25 1 (by rfl)
theorem sub24 : model.term 24 = lit52 := by rw [model.lam_eq 24 25 (by rfl), sub25]; rfl
theorem sub23 : model.term 23 = lit51 := by rw [model.lam_eq 23 24 (by rfl), sub24]; rfl
theorem sub22 : model.term 22 = lit73 := model.var_eq 22 0 (by rfl)
theorem sub21 : model.term 21 = lit21 := model.var_eq 21 2 (by rfl)
theorem sub20 : model.term 20 = lit20 := by rw [model.app_eq 20 21 22 (by rfl), sub21, sub22]; rfl
theorem sub19 : model.term 19 = lit53 := model.var_eq 19 1 (by rfl)
theorem sub18 : model.term 18 = lit18 := by rw [model.app_eq 18 19 20 (by rfl), sub19, sub20]; rfl
theorem sub17 : model.term 17 = lit17 := by rw [model.lam_eq 17 18 (by rfl), sub18]; rfl
theorem sub16 : model.term 16 = lit16 := by rw [model.lam_eq 16 17 (by rfl), sub17]; rfl
theorem sub15 : model.term 15 = lit73 := model.var_eq 15 0 (by rfl)
theorem sub14 : model.term 14 = lit14 := by rw [model.app_eq 14 15 16 (by rfl), sub15, sub16]; rfl
theorem sub13 : model.term 13 = lit13 := by rw [model.lam_eq 13 14 (by rfl), sub14]; rfl
theorem sub12 : model.term 12 = lit73 := model.var_eq 12 0 (by rfl)
theorem sub11 : model.term 11 = lit73 := model.var_eq 11 0 (by rfl)
theorem sub10 : model.term 10 = lit73 := model.var_eq 10 0 (by rfl)
theorem sub9 : model.term 9 = lit69 := by rw [model.app_eq 9 10 11 (by rfl), sub10, sub11]; rfl
theorem sub8 : model.term 8 = lit73 := model.var_eq 8 0 (by rfl)
theorem sub7 : model.term 7 = lit7 := by rw [model.app_eq 7 8 9 (by rfl), sub8, sub9]; rfl
theorem sub6 : model.term 6 = lit6 := by rw [model.app_eq 6 7 12 (by rfl), sub7, sub12]; rfl
theorem sub5 : model.term 5 = lit5 := by rw [model.lam_eq 5 6 (by rfl), sub6]; rfl
theorem sub4 : model.term 4 = lit4 := by rw [model.app_eq 4 5 13 (by rfl), sub5, sub13]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 23 (by rfl), sub4, sub23]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 26 (by rfl), sub3, sub26]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 63 (by rfl), sub2, sub63]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 72 (by rfl), sub1, sub72]; rfl
theorem allValid (i : Nat) (h : i < 615) : validState i = true := by
 by_cases h312 : i < 312
 · by_cases h156 : i < 156
   · by_cases h72 : i < 72
     · by_cases h36 : i < 36
       · by_cases h12 : i < 12
         · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
         · by_cases h24 : i < 24
           · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
       · by_cases h48 : i < 48
         · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
         · by_cases h60 : i < 60
           · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
     · by_cases h108 : i < 108
       · by_cases h84 : i < 84
         · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
         · by_cases h96 : i < 96
           · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
       · by_cases h132 : i < 132
         · by_cases h120 : i < 120
           · exact FloorIndex.rangeOK_at bl108 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl120 (by omega) (by omega)
         · by_cases h144 : i < 144
           · exact FloorIndex.rangeOK_at bl132 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl144 (by omega) (by omega)
   · by_cases h228 : i < 228
     · by_cases h192 : i < 192
       · by_cases h168 : i < 168
         · exact FloorIndex.rangeOK_at bl156 (by omega) (by omega)
         · by_cases h180 : i < 180
           · exact FloorIndex.rangeOK_at bl168 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl180 (by omega) (by omega)
       · by_cases h204 : i < 204
         · exact FloorIndex.rangeOK_at bl192 (by omega) (by omega)
         · by_cases h216 : i < 216
           · exact FloorIndex.rangeOK_at bl204 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl216 (by omega) (by omega)
     · by_cases h264 : i < 264
       · by_cases h240 : i < 240
         · exact FloorIndex.rangeOK_at bl228 (by omega) (by omega)
         · by_cases h252 : i < 252
           · exact FloorIndex.rangeOK_at bl240 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl252 (by omega) (by omega)
       · by_cases h288 : i < 288
         · by_cases h276 : i < 276
           · exact FloorIndex.rangeOK_at bl264 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl276 (by omega) (by omega)
         · by_cases h300 : i < 300
           · exact FloorIndex.rangeOK_at bl288 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl300 (by omega) (by omega)
 · by_cases h468 : i < 468
   · by_cases h384 : i < 384
     · by_cases h348 : i < 348
       · by_cases h324 : i < 324
         · exact FloorIndex.rangeOK_at bl312 (by omega) (by omega)
         · by_cases h336 : i < 336
           · exact FloorIndex.rangeOK_at bl324 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl336 (by omega) (by omega)
       · by_cases h360 : i < 360
         · exact FloorIndex.rangeOK_at bl348 (by omega) (by omega)
         · by_cases h372 : i < 372
           · exact FloorIndex.rangeOK_at bl360 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl372 (by omega) (by omega)
     · by_cases h420 : i < 420
       · by_cases h396 : i < 396
         · exact FloorIndex.rangeOK_at bl384 (by omega) (by omega)
         · by_cases h408 : i < 408
           · exact FloorIndex.rangeOK_at bl396 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl408 (by omega) (by omega)
       · by_cases h444 : i < 444
         · by_cases h432 : i < 432
           · exact FloorIndex.rangeOK_at bl420 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl432 (by omega) (by omega)
         · by_cases h456 : i < 456
           · exact FloorIndex.rangeOK_at bl444 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl456 (by omega) (by omega)
   · by_cases h540 : i < 540
     · by_cases h504 : i < 504
       · by_cases h480 : i < 480
         · exact FloorIndex.rangeOK_at bl468 (by omega) (by omega)
         · by_cases h492 : i < 492
           · exact FloorIndex.rangeOK_at bl480 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl492 (by omega) (by omega)
       · by_cases h516 : i < 516
         · exact FloorIndex.rangeOK_at bl504 (by omega) (by omega)
         · by_cases h528 : i < 528
           · exact FloorIndex.rangeOK_at bl516 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl528 (by omega) (by omega)
     · by_cases h576 : i < 576
       · by_cases h552 : i < 552
         · exact FloorIndex.rangeOK_at bl540 (by omega) (by omega)
         · by_cases h564 : i < 564
           · exact FloorIndex.rangeOK_at bl552 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl564 (by omega) (by omega)
       · by_cases h600 : i < 600
         · by_cases h588 : i < 588
           · exact FloorIndex.rangeOK_at bl576 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl588 (by omega) (by omega)
         · by_cases h612 : i < 612
           · exact FloorIndex.rangeOK_at bl600 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl612 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 615
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e597890436730 := by
 intro he
 have hp : replay [] (call e597890436730 (.lam (.lam (.var 1))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.lam (.var 0))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 4) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R597890436730
