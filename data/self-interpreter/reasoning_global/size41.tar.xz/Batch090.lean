import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605593783178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e605593783178 : Closed e605593783178 ∧ code e605593783178 = 2804617038730 := by decide
theorem cert_e605593783178 : check e605593783178 [[],[]] .smaller = true := by decide
def e605593783202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e605593783202 : Closed e605593783202 ∧ code e605593783202 = 2804617038754 := by decide
theorem cert_e605593783202 : check e605593783202 [[],[]] .smaller = true := by decide
def e605593783214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605593783214 : Closed e605593783214 ∧ code e605593783214 = 2804617038766 := by decide
theorem cert_e605593783214 : check e605593783214 [[],[]] .smaller = true := by decide
def e605593783222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1)))))))))
theorem wire_e605593783222 : Closed e605593783222 ∧ code e605593783222 = 2804617038774 := by decide
theorem cert_e605593783222 : check e605593783222 [[],[]] .smaller = true := by decide
def e605593783226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605593783226 : Closed e605593783226 ∧ code e605593783226 = 2804617038778 := by decide
theorem cert_e605593783226 : check e605593783226 [[],[]] .smaller = true := by decide
def e605593783254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605593783254 : Closed e605593783254 ∧ code e605593783254 = 2804617038806 := by decide
theorem cert_e605593783254 : check e605593783254 [[],[]] .smaller = true := by decide
def e605593783258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605593783258 : Closed e605593783258 ∧ code e605593783258 = 2804617038810 := by decide
theorem cert_e605593783258 : check e605593783258 [[],[]] .smaller = true := by decide
def e605593783274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e605593783274 : Closed e605593783274 ∧ code e605593783274 = 2804617038826 := by decide
theorem cert_e605593783274 : check e605593783274 [[],[]] .three = true := by decide
def e605593783326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e605593783326 : Closed e605593783326 ∧ code e605593783326 = 2804617038878 := by decide
theorem cert_e605593783326 : check e605593783326 [[],[]] .smaller = true := by decide
def e605593783518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e605593783518 : Closed e605593783518 ∧ code e605593783518 = 2804617039070 := by decide
theorem cert_e605593783518 : check e605593783518 [[],[]] .three = true := by decide
def e605593783522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e605593783522 : Closed e605593783522 ∧ code e605593783522 = 2804617039074 := by decide
theorem cert_e605593783522 : check e605593783522 [[],[]] .smaller = true := by decide
def e605593783534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605593783534 : Closed e605593783534 ∧ code e605593783534 = 2804617039086 := by decide
theorem cert_e605593783534 : check e605593783534 [[],[]] .smaller = true := by decide
def e605593783542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605593783542 : Closed e605593783542 ∧ code e605593783542 = 2804617039094 := by decide
theorem cert_e605593783542 : check e605593783542 [[],[]] .smaller = true := by decide
def e605593783546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e605593783546 : Closed e605593783546 ∧ code e605593783546 = 2804617039098 := by decide
theorem cert_e605593783546 : check e605593783546 [[],[]] .three = true := by decide
def e605593783822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e605593783822 : Closed e605593783822 ∧ code e605593783822 = 2804617039374 := by decide
theorem cert_e605593783822 : check e605593783822 [[],[]] .smaller = true := by decide
def e605593783834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e605593783834 : Closed e605593783834 ∧ code e605593783834 = 2804617039386 := by decide
theorem cert_e605593783834 : check e605593783834 [[],[]] .smaller = true := by decide
def e605593783906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e605593783906 : Closed e605593783906 ∧ code e605593783906 = 2804617039458 := by decide
theorem cert_e605593783906 : check e605593783906 [[],[]] .smaller = true := by decide
def e605593783918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605593783918 : Closed e605593783918 ∧ code e605593783918 = 2804617039470 := by decide
theorem cert_e605593783918 : check e605593783918 [[],[]] .smaller = true := by decide
def e605593783926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1))))))))))
theorem wire_e605593783926 : Closed e605593783926 ∧ code e605593783926 = 2804617039478 := by decide
theorem cert_e605593783926 : check e605593783926 [[],[]] .smaller = true := by decide
def e605593783930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605593783930 : Closed e605593783930 ∧ code e605593783930 = 2804617039482 := by decide
theorem cert_e605593783930 : check e605593783930 [[],[]] .smaller = true := by decide
def e605593784118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605593784118 : Closed e605593784118 ∧ code e605593784118 = 2804617039670 := by decide
theorem cert_e605593784118 : check e605593784118 [[],[]] .smaller = true := by decide
def e605593784122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605593784122 : Closed e605593784122 ∧ code e605593784122 = 2804617039674 := by decide
theorem cert_e605593784122 : check e605593784122 [[],[]] .smaller = true := by decide
def e605593784218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e605593784218 : Closed e605593784218 ∧ code e605593784218 = 2804617039770 := by decide
theorem cert_e605593784218 : check e605593784218 [[],[]] .three = true := by decide
def e605593788894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605593788894 : Closed e605593788894 ∧ code e605593788894 = 2804617044446 := by decide
theorem cert_e605593788894 : check e605593788894 [[],[]] .three = true := by decide
def e605593788910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e605593788910 : Closed e605593788910 ∧ code e605593788910 = 2804617044462 := by decide
theorem cert_e605593788910 : check e605593788910 [[],[]] .three = true := by decide
def e605593788918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605593788918 : Closed e605593788918 ∧ code e605593788918 = 2804617044470 := by decide
theorem cert_e605593788918 : check e605593788918 [[],[]] .three = true := by decide
def e605593789870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605593789870 : Closed e605593789870 ∧ code e605593789870 = 2804617045422 := by decide
theorem cert_e605593789870 : check e605593789870 [[],[]] .three = true := by decide
def e605593789878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605593789878 : Closed e605593789878 ∧ code e605593789878 = 2804617045430 := by decide
theorem cert_e605593789878 : check e605593789878 [[],[]] .three = true := by decide
def e605593789882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605593789882 : Closed e605593789882 ∧ code e605593789882 = 2804617045434 := by decide
theorem cert_e605593789882 : check e605593789882 [[],[]] .three = true := by decide
def e605593789910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605593789910 : Closed e605593789910 ∧ code e605593789910 = 2804617045462 := by decide
theorem cert_e605593789910 : check e605593789910 [[],[]] .three = true := by decide
def e605593789914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605593789914 : Closed e605593789914 ∧ code e605593789914 = 2804617045466 := by decide
theorem cert_e605593789914 : check e605593789914 [[],[]] .three = true := by decide
def e605593789930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605593789930 : Closed e605593789930 ∧ code e605593789930 = 2804617045482 := by decide
theorem cert_e605593789930 : check e605593789930 [[],[]] .three = true := by decide
def e605593790062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605593790062 : Closed e605593790062 ∧ code e605593790062 = 2804617045614 := by decide
theorem cert_e605593790062 : check e605593790062 [[],[]] .three = true := by decide
def e605593790070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605593790070 : Closed e605593790070 ∧ code e605593790070 = 2804617045622 := by decide
theorem cert_e605593790070 : check e605593790070 [[],[]] .three = true := by decide
def e605593790074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605593790074 : Closed e605593790074 ∧ code e605593790074 = 2804617045626 := by decide
theorem cert_e605593790074 : check e605593790074 [[],[]] .three = true := by decide
def e605593790262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605593790262 : Closed e605593790262 ∧ code e605593790262 = 2804617045814 := by decide
theorem cert_e605593790262 : check e605593790262 [[],[]] .three = true := by decide
def e605593790266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605593790266 : Closed e605593790266 ∧ code e605593790266 = 2804617045818 := by decide
theorem cert_e605593790266 : check e605593790266 [[],[]] .three = true := by decide
def e605593790362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605593790362 : Closed e605593790362 ∧ code e605593790362 = 2804617045914 := by decide
theorem cert_e605593790362 : check e605593790362 [[],[]] .three = true := by decide
def e605594064606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e605594064606 : Closed e605594064606 ∧ code e605594064606 = 2804617320158 := by decide
theorem cert_e605594064606 : check e605594064606 [[],[]] .smaller = true := by decide
def e605594064630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e605594064630 : Closed e605594064630 ∧ code e605594064630 = 2804617320182 := by decide
theorem cert_e605594064630 : check e605594064630 [[],[]] .smaller = true := by decide
def e605594064734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e605594064734 : Closed e605594064734 ∧ code e605594064734 = 2804617320286 := by decide
theorem cert_e605594064734 : check e605594064734 [[],[]] .smaller = true := by decide
def e605594064762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e605594064762 : Closed e605594064762 ∧ code e605594064762 = 2804617320314 := by decide
theorem cert_e605594064762 : check e605594064762 [[],[]] .smaller = true := by decide
def e605594064854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e605594064854 : Closed e605594064854 ∧ code e605594064854 = 2804617320406 := by decide
theorem cert_e605594064854 : check e605594064854 [[],[]] .smaller = true := by decide
def e605594064858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e605594064858 : Closed e605594064858 ∧ code e605594064858 = 2804617320410 := by decide
theorem cert_e605594064858 : check e605594064858 [[],[]] .smaller = true := by decide
def e605594065374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e605594065374 : Closed e605594065374 ∧ code e605594065374 = 2804617320926 := by decide
theorem cert_e605594065374 : check e605594065374 [[],[]] .smaller = true := by decide
def e605594065398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e605594065398 : Closed e605594065398 ∧ code e605594065398 = 2804617320950 := by decide
theorem cert_e605594065398 : check e605594065398 [[],[]] .smaller = true := by decide
def e605594066142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e605594066142 : Closed e605594066142 ∧ code e605594066142 = 2804617321694 := by decide
theorem cert_e605594066142 : check e605594066142 [[],[]] .smaller = true := by decide
def e605594066170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e605594066170 : Closed e605594066170 ∧ code e605594066170 = 2804617321722 := by decide
theorem cert_e605594066170 : check e605594066170 [[],[]] .smaller = true := by decide
def e605594066742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605594066742 : Closed e605594066742 ∧ code e605594066742 = 2804617322294 := by decide
theorem cert_e605594066742 : check e605594066742 [[],[]] .smaller = true := by decide
def e605594066746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605594066746 : Closed e605594066746 ∧ code e605594066746 = 2804617322298 := by decide
theorem cert_e605594066746 : check e605594066746 [[],[]] .smaller = true := by decide
def e605594081518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e605594081518 : Closed e605594081518 ∧ code e605594081518 = 2804617337070 := by decide
theorem cert_e605594081518 : check e605594081518 [[],[]] .smaller = true := by decide
def e605594081526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e605594081526 : Closed e605594081526 ∧ code e605594081526 = 2804617337078 := by decide
theorem cert_e605594081526 : check e605594081526 [[],[]] .smaller = true := by decide
def e605594082078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e605594082078 : Closed e605594082078 ∧ code e605594082078 = 2804617337630 := by decide
theorem cert_e605594082078 : check e605594082078 [[],[]] .smaller = true := by decide
def e605594082190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e605594082190 : Closed e605594082190 ∧ code e605594082190 = 2804617337742 := by decide
theorem cert_e605594082190 : check e605594082190 [[],[]] .smaller = true := by decide
def e605594082238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 4)))))))))
theorem wire_e605594082238 : Closed e605594082238 ∧ code e605594082238 = 2804617337790 := by decide
theorem cert_e605594082238 : check e605594082238 [[],[]] .three = true := by decide
def e605594082286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 4)) (.var 2)))))))))
theorem wire_e605594082286 : Closed e605594082286 ∧ code e605594082286 = 2804617337838 := by decide
theorem cert_e605594082286 : check e605594082286 [[],[]] .three = true := by decide
def e605594082414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e605594082414 : Closed e605594082414 ∧ code e605594082414 = 2804617337966 := by decide
theorem cert_e605594082414 : check e605594082414 [[],[]] .smaller = true := by decide
def e605594082426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e605594082426 : Closed e605594082426 ∧ code e605594082426 = 2804617337978 := by decide
theorem cert_e605594082426 : check e605594082426 [[],[]] .smaller = true := by decide
def e605594082590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e605594082590 : Closed e605594082590 ∧ code e605594082590 = 2804617338142 := by decide
theorem cert_e605594082590 : check e605594082590 [[],[]] .smaller = true := by decide
def e605594082750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 4)))))))))
theorem wire_e605594082750 : Closed e605594082750 ∧ code e605594082750 = 2804617338302 := by decide
theorem cert_e605594082750 : check e605594082750 [[],[]] .three = true := by decide
def e605594082758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e605594082758 : Closed e605594082758 ∧ code e605594082758 = 2804617338310 := by decide
theorem cert_e605594082758 : check e605594082758 [[],[]] .smaller = true := by decide
def e605594082782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e605594082782 : Closed e605594082782 ∧ code e605594082782 = 2804617338334 := by decide
theorem cert_e605594082782 : check e605594082782 [[],[]] .smaller = true := by decide
def e605594082798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e605594082798 : Closed e605594082798 ∧ code e605594082798 = 2804617338350 := by decide
theorem cert_e605594082798 : check e605594082798 [[],[]] .smaller = true := by decide
def e605594082806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 4)) (.var 1)))))))))
theorem wire_e605594082806 : Closed e605594082806 ∧ code e605594082806 = 2804617338358 := by decide
theorem cert_e605594082806 : check e605594082806 [[],[]] .three = true := by decide
def e605594082870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e605594082870 : Closed e605594082870 ∧ code e605594082870 = 2804617338422 := by decide
theorem cert_e605594082870 : check e605594082870 [[],[]] .smaller = true := by decide
def e605594082874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e605594082874 : Closed e605594082874 ∧ code e605594082874 = 2804617338426 := by decide
theorem cert_e605594082874 : check e605594082874 [[],[]] .smaller = true := by decide
def e605594082958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e605594082958 : Closed e605594082958 ∧ code e605594082958 = 2804617338510 := by decide
theorem cert_e605594082958 : check e605594082958 [[],[]] .smaller = true := by decide
def e605594083006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 4)))))))))
theorem wire_e605594083006 : Closed e605594083006 ∧ code e605594083006 = 2804617338558 := by decide
theorem cert_e605594083006 : check e605594083006 [[],[]] .three = true := by decide
def e605594083014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e605594083014 : Closed e605594083014 ∧ code e605594083014 = 2804617338566 := by decide
theorem cert_e605594083014 : check e605594083014 [[],[]] .smaller = true := by decide
def e605594083038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e605594083038 : Closed e605594083038 ∧ code e605594083038 = 2804617338590 := by decide
theorem cert_e605594083038 : check e605594083038 [[],[]] .smaller = true := by decide
def e605594083062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e605594083062 : Closed e605594083062 ∧ code e605594083062 = 2804617338614 := by decide
theorem cert_e605594083062 : check e605594083062 [[],[]] .smaller = true := by decide
def e605594083066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 4)) (.var 0)))))))))
theorem wire_e605594083066 : Closed e605594083066 ∧ code e605594083066 = 2804617338618 := by decide
theorem cert_e605594083066 : check e605594083066 [[],[]] .three = true := by decide
def e605594083182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e605594083182 : Closed e605594083182 ∧ code e605594083182 = 2804617338734 := by decide
theorem cert_e605594083182 : check e605594083182 [[],[]] .smaller = true := by decide
def e605594083190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e605594083190 : Closed e605594083190 ∧ code e605594083190 = 2804617338742 := by decide
theorem cert_e605594083190 : check e605594083190 [[],[]] .smaller = true := by decide
def e605594083246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 4) (.var 0)) (.var 2)))))))))
theorem wire_e605594083246 : Closed e605594083246 ∧ code e605594083246 = 2804617338798 := by decide
theorem cert_e605594083246 : check e605594083246 [[],[]] .three = true := by decide
def e605594083254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 4) (.var 1)) (.var 1)))))))))
theorem wire_e605594083254 : Closed e605594083254 ∧ code e605594083254 = 2804617338806 := by decide
theorem cert_e605594083254 : check e605594083254 [[],[]] .three = true := by decide
def e605594083258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 4) (.var 2)) (.var 0)))))))))
theorem wire_e605594083258 : Closed e605594083258 ∧ code e605594083258 = 2804617338810 := by decide
theorem cert_e605594083258 : check e605594083258 [[],[]] .three = true := by decide
def e605594085150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e605594085150 : Closed e605594085150 ∧ code e605594085150 = 2804617340702 := by decide
theorem cert_e605594085150 : check e605594085150 [[],[]] .smaller = true := by decide
def e605594085262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e605594085262 : Closed e605594085262 ∧ code e605594085262 = 2804617340814 := by decide
theorem cert_e605594085262 : check e605594085262 [[],[]] .smaller = true := by decide
def e605594085310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 4))))))))))
theorem wire_e605594085310 : Closed e605594085310 ∧ code e605594085310 = 2804617340862 := by decide
theorem cert_e605594085310 : check e605594085310 [[],[]] .three = true := by decide
def e605594085358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 4) (.var 2))))))))))
theorem wire_e605594085358 : Closed e605594085358 ∧ code e605594085358 = 2804617340910 := by decide
theorem cert_e605594085358 : check e605594085358 [[],[]] .three = true := by decide
def e605594088222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e605594088222 : Closed e605594088222 ∧ code e605594088222 = 2804617343774 := by decide
theorem cert_e605594088222 : check e605594088222 [[],[]] .smaller = true := by decide
def e605594088382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 4))))))))))
theorem wire_e605594088382 : Closed e605594088382 ∧ code e605594088382 = 2804617343934 := by decide
theorem cert_e605594088382 : check e605594088382 [[],[]] .three = true := by decide
def e605594088390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e605594088390 : Closed e605594088390 ∧ code e605594088390 = 2804617343942 := by decide
theorem cert_e605594088390 : check e605594088390 [[],[]] .smaller = true := by decide
def e605594088414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e605594088414 : Closed e605594088414 ∧ code e605594088414 = 2804617343966 := by decide
theorem cert_e605594088414 : check e605594088414 [[],[]] .smaller = true := by decide
def e605594088430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e605594088430 : Closed e605594088430 ∧ code e605594088430 = 2804617343982 := by decide
theorem cert_e605594088430 : check e605594088430 [[],[]] .smaller = true := by decide
def e605594088438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 4) (.var 1))))))))))
theorem wire_e605594088438 : Closed e605594088438 ∧ code e605594088438 = 2804617343990 := by decide
theorem cert_e605594088438 : check e605594088438 [[],[]] .three = true := by decide
def e605594089870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e605594089870 : Closed e605594089870 ∧ code e605594089870 = 2804617345422 := by decide
theorem cert_e605594089870 : check e605594089870 [[],[]] .smaller = true := by decide
def e605594089918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 4))))))))))
theorem wire_e605594089918 : Closed e605594089918 ∧ code e605594089918 = 2804617345470 := by decide
theorem cert_e605594089918 : check e605594089918 [[],[]] .three = true := by decide
def e605594089926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e605594089926 : Closed e605594089926 ∧ code e605594089926 = 2804617345478 := by decide
theorem cert_e605594089926 : check e605594089926 [[],[]] .smaller = true := by decide
def e605594089950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e605594089950 : Closed e605594089950 ∧ code e605594089950 = 2804617345502 := by decide
theorem cert_e605594089950 : check e605594089950 [[],[]] .smaller = true := by decide
def e605594089974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e605594089974 : Closed e605594089974 ∧ code e605594089974 = 2804617345526 := by decide
theorem cert_e605594089974 : check e605594089974 [[],[]] .smaller = true := by decide
def e605594089978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 4) (.var 0))))))))))
theorem wire_e605594089978 : Closed e605594089978 ∧ code e605594089978 = 2804617345530 := by decide
theorem cert_e605594089978 : check e605594089978 [[],[]] .three = true := by decide
def e605594090734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e605594090734 : Closed e605594090734 ∧ code e605594090734 = 2804617346286 := by decide
theorem cert_e605594090734 : check e605594090734 [[],[]] .smaller = true := by decide
def e605594090742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e605594090742 : Closed e605594090742 ∧ code e605594090742 = 2804617346294 := by decide
theorem cert_e605594090742 : check e605594090742 [[],[]] .smaller = true := by decide
def e605594091118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.app (.var 0) (.var 2))))))))))
theorem wire_e605594091118 : Closed e605594091118 ∧ code e605594091118 = 2804617346670 := by decide
theorem cert_e605594091118 : check e605594091118 [[],[]] .three = true := by decide
def e605594091126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.app (.var 1) (.var 1))))))))))
theorem wire_e605594091126 : Closed e605594091126 ∧ code e605594091126 = 2804617346678 := by decide
theorem cert_e605594091126 : check e605594091126 [[],[]] .three = true := by decide
def e605594091130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.app (.var 2) (.var 0))))))))))
theorem wire_e605594091130 : Closed e605594091130 ∧ code e605594091130 = 2804617346682 := by decide
theorem cert_e605594091130 : check e605594091130 [[],[]] .three = true := by decide
def e605594131054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e605594131054 : Closed e605594131054 ∧ code e605594131054 = 2804617386606 := by decide
theorem cert_e605594131054 : check e605594131054 [[],[]] .smaller = true := by decide
def e605594131066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e605594131066 : Closed e605594131066 ∧ code e605594131066 = 2804617386618 := by decide
theorem cert_e605594131066 : check e605594131066 [[],[]] .smaller = true := by decide
def e605594146990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e605594146990 : Closed e605594146990 ∧ code e605594146990 = 2804617402542 := by decide
theorem cert_e605594146990 : check e605594146990 [[],[]] .smaller = true := by decide
def e605594147002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e605594147002 : Closed e605594147002 ∧ code e605594147002 = 2804617402554 := by decide
theorem cert_e605594147002 : check e605594147002 [[],[]] .smaller = true := by decide
def e605594147374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605594147374 : Closed e605594147374 ∧ code e605594147374 = 2804617402926 := by decide
theorem cert_e605594147374 : check e605594147374 [[],[]] .smaller = true := by decide
def e605594147550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e605594147550 : Closed e605594147550 ∧ code e605594147550 = 2804617403102 := by decide
theorem cert_e605594147550 : check e605594147550 [[],[]] .three = true := by decide
def e605594147554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605594147554 : Closed e605594147554 ∧ code e605594147554 = 2804617403106 := by decide
theorem cert_e605594147554 : check e605594147554 [[],[]] .smaller = true := by decide
def e605594147566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e605594147566 : Closed e605594147566 ∧ code e605594147566 = 2804617403118 := by decide
theorem cert_e605594147566 : check e605594147566 [[],[]] .smaller = true := by decide
def e605594147574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e605594147574 : Closed e605594147574 ∧ code e605594147574 = 2804617403126 := by decide
theorem cert_e605594147574 : check e605594147574 [[],[]] .three = true := by decide
def e605594147678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e605594147678 : Closed e605594147678 ∧ code e605594147678 = 2804617403230 := by decide
theorem cert_e605594147678 : check e605594147678 [[],[]] .three = true := by decide
def e605594147694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e605594147694 : Closed e605594147694 ∧ code e605594147694 = 2804617403246 := by decide
theorem cert_e605594147694 : check e605594147694 [[],[]] .smaller = true := by decide
def e605594147702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e605594147702 : Closed e605594147702 ∧ code e605594147702 = 2804617403254 := by decide
theorem cert_e605594147702 : check e605594147702 [[],[]] .smaller = true := by decide
def e605594147706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e605594147706 : Closed e605594147706 ∧ code e605594147706 = 2804617403258 := by decide
theorem cert_e605594147706 : check e605594147706 [[],[]] .three = true := by decide
def e605594147722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605594147722 : Closed e605594147722 ∧ code e605594147722 = 2804617403274 := by decide
theorem cert_e605594147722 : check e605594147722 [[],[]] .smaller = true := by decide
def e605594147746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605594147746 : Closed e605594147746 ∧ code e605594147746 = 2804617403298 := by decide
theorem cert_e605594147746 : check e605594147746 [[],[]] .smaller = true := by decide
def e605594147758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e605594147758 : Closed e605594147758 ∧ code e605594147758 = 2804617403310 := by decide
theorem cert_e605594147758 : check e605594147758 [[],[]] .smaller = true := by decide
def e605594147766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e605594147766 : Closed e605594147766 ∧ code e605594147766 = 2804617403318 := by decide
theorem cert_e605594147766 : check e605594147766 [[],[]] .smaller = true := by decide
def e605594147770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e605594147770 : Closed e605594147770 ∧ code e605594147770 = 2804617403322 := by decide
theorem cert_e605594147770 : check e605594147770 [[],[]] .smaller = true := by decide
def e605594147798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e605594147798 : Closed e605594147798 ∧ code e605594147798 = 2804617403350 := by decide
theorem cert_e605594147798 : check e605594147798 [[],[]] .three = true := by decide
def e605594147802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e605594147802 : Closed e605594147802 ∧ code e605594147802 = 2804617403354 := by decide
theorem cert_e605594147802 : check e605594147802 [[],[]] .three = true := by decide
def e605594148190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e605594148190 : Closed e605594148190 ∧ code e605594148190 = 2804617403742 := by decide
theorem cert_e605594148190 : check e605594148190 [[],[]] .three = true := by decide
def e605594148206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605594148206 : Closed e605594148206 ∧ code e605594148206 = 2804617403758 := by decide
theorem cert_e605594148206 : check e605594148206 [[],[]] .smaller = true := by decide
def e605594148214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605594148214 : Closed e605594148214 ∧ code e605594148214 = 2804617403766 := by decide
theorem cert_e605594148214 : check e605594148214 [[],[]] .smaller = true := by decide
def e605594148218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e605594148218 : Closed e605594148218 ∧ code e605594148218 = 2804617403770 := by decide
theorem cert_e605594148218 : check e605594148218 [[],[]] .three = true := by decide
def e605594148270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605594148270 : Closed e605594148270 ∧ code e605594148270 = 2804617403822 := by decide
theorem cert_e605594148270 : check e605594148270 [[],[]] .smaller = true := by decide
def e605594148282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605594148282 : Closed e605594148282 ∧ code e605594148282 = 2804617403834 := by decide
theorem cert_e605594148282 : check e605594148282 [[],[]] .smaller = true := by decide
def e605594148310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605594148310 : Closed e605594148310 ∧ code e605594148310 = 2804617403862 := by decide
theorem cert_e605594148310 : check e605594148310 [[],[]] .smaller = true := by decide
def e605594148314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605594148314 : Closed e605594148314 ∧ code e605594148314 = 2804617403866 := by decide
theorem cert_e605594148314 : check e605594148314 [[],[]] .smaller = true := by decide
def e605594148330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e605594148330 : Closed e605594148330 ∧ code e605594148330 = 2804617403882 := by decide
theorem cert_e605594148330 : check e605594148330 [[],[]] .three = true := by decide
def e605594148394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e605594148394 : Closed e605594148394 ∧ code e605594148394 = 2804617403946 := by decide
theorem cert_e605594148394 : check e605594148394 [[],[]] .smaller = true := by decide
def e605594148490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605594148490 : Closed e605594148490 ∧ code e605594148490 = 2804617404042 := by decide
theorem cert_e605594148490 : check e605594148490 [[],[]] .smaller = true := by decide
def e605594148514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605594148514 : Closed e605594148514 ∧ code e605594148514 = 2804617404066 := by decide
theorem cert_e605594148514 : check e605594148514 [[],[]] .smaller = true := by decide
def e605594148526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605594148526 : Closed e605594148526 ∧ code e605594148526 = 2804617404078 := by decide
theorem cert_e605594148526 : check e605594148526 [[],[]] .smaller = true := by decide
def e605594148534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e605594148534 : Closed e605594148534 ∧ code e605594148534 = 2804617404086 := by decide
theorem cert_e605594148534 : check e605594148534 [[],[]] .smaller = true := by decide
def e605594148538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605594148538 : Closed e605594148538 ∧ code e605594148538 = 2804617404090 := by decide
theorem cert_e605594148538 : check e605594148538 [[],[]] .smaller = true := by decide
def e605594148566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e605594148566 : Closed e605594148566 ∧ code e605594148566 = 2804617404118 := by decide
theorem cert_e605594148566 : check e605594148566 [[],[]] .smaller = true := by decide
def e605594148570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e605594148570 : Closed e605594148570 ∧ code e605594148570 = 2804617404122 := by decide
theorem cert_e605594148570 : check e605594148570 [[],[]] .smaller = true := by decide
def e605594148586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605594148586 : Closed e605594148586 ∧ code e605594148586 = 2804617404138 := by decide
theorem cert_e605594148586 : check e605594148586 [[],[]] .smaller = true := by decide
def e605594148694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605594148694 : Closed e605594148694 ∧ code e605594148694 = 2804617404246 := by decide
theorem cert_e605594148694 : check e605594148694 [[],[]] .three = true := by decide
def e605594148698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605594148698 : Closed e605594148698 ∧ code e605594148698 = 2804617404250 := by decide
theorem cert_e605594148698 : check e605594148698 [[],[]] .three = true := by decide
def e605594148714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605594148714 : Closed e605594148714 ∧ code e605594148714 = 2804617404266 := by decide
theorem cert_e605594148714 : check e605594148714 [[],[]] .three = true := by decide
def e605594149102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2))))))))
theorem wire_e605594149102 : Closed e605594149102 ∧ code e605594149102 = 2804617404654 := by decide
theorem cert_e605594149102 : check e605594149102 [[],[]] .smaller = true := by decide
def e605594149114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0))))))))
theorem wire_e605594149114 : Closed e605594149114 ∧ code e605594149114 = 2804617404666 := by decide
theorem cert_e605594149114 : check e605594149114 [[],[]] .smaller = true := by decide
def e605594149294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e605594149294 : Closed e605594149294 ∧ code e605594149294 = 2804617404846 := by decide
theorem cert_e605594149294 : check e605594149294 [[],[]] .smaller = true := by decide
def e605594149486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e605594149486 : Closed e605594149486 ∧ code e605594149486 = 2804617405038 := by decide
theorem cert_e605594149486 : check e605594149486 [[],[]] .smaller = true := by decide
def e605594149498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e605594149498 : Closed e605594149498 ∧ code e605594149498 = 2804617405050 := by decide
theorem cert_e605594149498 : check e605594149498 [[],[]] .smaller = true := by decide
def e605594149662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3)))))))))
theorem wire_e605594149662 : Closed e605594149662 ∧ code e605594149662 = 2804617405214 := by decide
theorem cert_e605594149662 : check e605594149662 [[],[]] .smaller = true := by decide
def e605594149830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1)))))))))
theorem wire_e605594149830 : Closed e605594149830 ∧ code e605594149830 = 2804617405382 := by decide
theorem cert_e605594149830 : check e605594149830 [[],[]] .smaller = true := by decide
def e605594150446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605594150446 : Closed e605594150446 ∧ code e605594150446 = 2804617405998 := by decide
theorem cert_e605594150446 : check e605594150446 [[],[]] .smaller = true := by decide
def e605594150622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e605594150622 : Closed e605594150622 ∧ code e605594150622 = 2804617406174 := by decide
theorem cert_e605594150622 : check e605594150622 [[],[]] .three = true := by decide
def e605594150626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e605594150626 : Closed e605594150626 ∧ code e605594150626 = 2804617406178 := by decide
theorem cert_e605594150626 : check e605594150626 [[],[]] .smaller = true := by decide
def e605594150638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e605594150638 : Closed e605594150638 ∧ code e605594150638 = 2804617406190 := by decide
theorem cert_e605594150638 : check e605594150638 [[],[]] .smaller = true := by decide
def e605594150646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e605594150646 : Closed e605594150646 ∧ code e605594150646 = 2804617406198 := by decide
theorem cert_e605594150646 : check e605594150646 [[],[]] .three = true := by decide
def e605594150750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e605594150750 : Closed e605594150750 ∧ code e605594150750 = 2804617406302 := by decide
theorem cert_e605594150750 : check e605594150750 [[],[]] .three = true := by decide
def e605594150766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e605594150766 : Closed e605594150766 ∧ code e605594150766 = 2804617406318 := by decide
theorem cert_e605594150766 : check e605594150766 [[],[]] .smaller = true := by decide
def e605594150774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e605594150774 : Closed e605594150774 ∧ code e605594150774 = 2804617406326 := by decide
theorem cert_e605594150774 : check e605594150774 [[],[]] .smaller = true := by decide
def e605594150778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e605594150778 : Closed e605594150778 ∧ code e605594150778 = 2804617406330 := by decide
theorem cert_e605594150778 : check e605594150778 [[],[]] .three = true := by decide
def e605594150794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605594150794 : Closed e605594150794 ∧ code e605594150794 = 2804617406346 := by decide
theorem cert_e605594150794 : check e605594150794 [[],[]] .smaller = true := by decide
def e605594150818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e605594150818 : Closed e605594150818 ∧ code e605594150818 = 2804617406370 := by decide
theorem cert_e605594150818 : check e605594150818 [[],[]] .smaller = true := by decide
def e605594150830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e605594150830 : Closed e605594150830 ∧ code e605594150830 = 2804617406382 := by decide
theorem cert_e605594150830 : check e605594150830 [[],[]] .smaller = true := by decide
def e605594150838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e605594150838 : Closed e605594150838 ∧ code e605594150838 = 2804617406390 := by decide
theorem cert_e605594150838 : check e605594150838 [[],[]] .smaller = true := by decide
def e605594150842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e605594150842 : Closed e605594150842 ∧ code e605594150842 = 2804617406394 := by decide
theorem cert_e605594150842 : check e605594150842 [[],[]] .smaller = true := by decide
end Blc.Floor41
