import R598355273326Data
namespace Certgen.R598355273326
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl504 : FloorIndex.rangeOK validState 504 9 = true := by decide +kernel
end Certgen.R598355273326
