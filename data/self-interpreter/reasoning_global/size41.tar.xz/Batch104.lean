import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605602113210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e605602113210 : Closed e605602113210 ∧ code e605602113210 = 2804625368762 := by decide
theorem cert_e605602113210 : check e605602113210 [[],[]] .chain = true := by decide
def e605602113258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e605602113258 : Closed e605602113258 ∧ code e605602113258 = 2804625368810 := by decide
theorem cert_e605602113258 : check e605602113258 [[],[]] .chain = true := by decide
def e605602113450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e605602113450 : Closed e605602113450 ∧ code e605602113450 = 2804625369002 := by decide
theorem cert_e605602113450 : check e605602113450 [[],[]] .chain = true := by decide
def e605602113582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e605602113582 : Closed e605602113582 ∧ code e605602113582 = 2804625369134 := by decide
theorem cert_e605602113582 : check e605602113582 [[],[]] .chain = true := by decide
def e605602113774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))) (.var 2))))))
theorem wire_e605602113774 : Closed e605602113774 ∧ code e605602113774 = 2804625369326 := by decide
theorem cert_e605602113774 : check e605602113774 [[],[]] .chain = true := by decide
def e605602113782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))) (.var 1))))))
theorem wire_e605602113782 : Closed e605602113782 ∧ code e605602113782 = 2804625369334 := by decide
theorem cert_e605602113782 : check e605602113782 [[],[]] .chain = true := by decide
def e605602113966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e605602113966 : Closed e605602113966 ∧ code e605602113966 = 2804625369518 := by decide
theorem cert_e605602113966 : check e605602113966 [[],[]] .chain = true := by decide
def e605602113978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e605602113978 : Closed e605602113978 ∧ code e605602113978 = 2804625369530 := by decide
theorem cert_e605602113978 : check e605602113978 [[],[]] .chain = true := by decide
def e605602114026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e605602114026 : Closed e605602114026 ∧ code e605602114026 = 2804625369578 := by decide
theorem cert_e605602114026 : check e605602114026 [[],[]] .chain = true := by decide
def e605602114158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602114158 : Closed e605602114158 ∧ code e605602114158 = 2804625369710 := by decide
theorem cert_e605602114158 : check e605602114158 [[],[]] .chain = true := by decide
def e605602114170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602114170 : Closed e605602114170 ∧ code e605602114170 = 2804625369722 := by decide
theorem cert_e605602114170 : check e605602114170 [[],[]] .chain = true := by decide
def e605602114334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.lam (.var 3)))))))
theorem wire_e605602114334 : Closed e605602114334 ∧ code e605602114334 = 2804625369886 := by decide
theorem cert_e605602114334 : check e605602114334 [[],[]] .chain = true := by decide
def e605602114434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e605602114434 : Closed e605602114434 ∧ code e605602114434 = 2804625369986 := by decide
theorem cert_e605602114434 : check e605602114434 [[],[]] .chain = true := by decide
def e605602114446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 2)))))))
theorem wire_e605602114446 : Closed e605602114446 ∧ code e605602114446 = 2804625369998 := by decide
theorem cert_e605602114446 : check e605602114446 [[],[]] .chain = true := by decide
def e605602114458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602114458 : Closed e605602114458 ∧ code e605602114458 = 2804625370010 := by decide
theorem cert_e605602114458 : check e605602114458 [[],[]] .chain = true := by decide
def e605602114670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e605602114670 : Closed e605602114670 ∧ code e605602114670 = 2804625370222 := by decide
theorem cert_e605602114670 : check e605602114670 [[],[]] .chain = true := by decide
def e605602114682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e605602114682 : Closed e605602114682 ∧ code e605602114682 = 2804625370234 := by decide
theorem cert_e605602114682 : check e605602114682 [[],[]] .chain = true := by decide
def e605602114846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e605602114846 : Closed e605602114846 ∧ code e605602114846 = 2804625370398 := by decide
theorem cert_e605602114846 : check e605602114846 [[],[]] .chain = true := by decide
def e605602115014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e605602115014 : Closed e605602115014 ∧ code e605602115014 = 2804625370566 := by decide
theorem cert_e605602115014 : check e605602115014 [[],[]] .chain = true := by decide
def e605602115082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e605602115082 : Closed e605602115082 ∧ code e605602115082 = 2804625370634 := by decide
theorem cert_e605602115082 : check e605602115082 [[],[]] .chain = true := by decide
def e605602115118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e605602115118 : Closed e605602115118 ∧ code e605602115118 = 2804625370670 := by decide
theorem cert_e605602115118 : check e605602115118 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602115126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e605602115126 : Closed e605602115126 ∧ code e605602115126 = 2804625370678 := by decide
theorem cert_e605602115126 : check e605602115126 [[],[]] .chain = true := by decide
def e605602115130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e605602115130 : Closed e605602115130 ∧ code e605602115130 = 2804625370682 := by decide
theorem cert_e605602115130 : check e605602115130 [[],[]] .chain = true := by decide
def e605602115178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e605602115178 : Closed e605602115178 ∧ code e605602115178 = 2804625370730 := by decide
theorem cert_e605602115178 : check e605602115178 [[],[]] .chain = true := by decide
def e605602115202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e605602115202 : Closed e605602115202 ∧ code e605602115202 = 2804625370754 := by decide
theorem cert_e605602115202 : check e605602115202 [[],[]] .chain = true := by decide
def e605602115214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e605602115214 : Closed e605602115214 ∧ code e605602115214 = 2804625370766 := by decide
theorem cert_e605602115214 : check e605602115214 [[],[]] .chain = true := by decide
def e605602115226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602115226 : Closed e605602115226 ∧ code e605602115226 = 2804625370778 := by decide
theorem cert_e605602115226 : check e605602115226 [[],[]] .chain = true := by decide
def e605602115270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e605602115270 : Closed e605602115270 ∧ code e605602115270 = 2804625370822 := by decide
theorem cert_e605602115270 : check e605602115270 [[],[]] .chain = true := by decide
def e605602115298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e605602115298 : Closed e605602115298 ∧ code e605602115298 = 2804625370850 := by decide
theorem cert_e605602115298 : check e605602115298 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602115310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 2))))))
theorem wire_e605602115310 : Closed e605602115310 ∧ code e605602115310 = 2804625370862 := by decide
theorem cert_e605602115310 : check e605602115310 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602115670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))) (.var 1))))))
theorem wire_e605602115670 : Closed e605602115670 ∧ code e605602115670 = 2804625371222 := by decide
theorem cert_e605602115670 : check e605602115670 [[],[]] .chain = true := by decide
def e605602115674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1))) (.var 0))))))
theorem wire_e605602115674 : Closed e605602115674 ∧ code e605602115674 = 2804625371226 := by decide
theorem cert_e605602115674 : check e605602115674 [[],[]] .chain = true := by decide
def e605602115950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e605602115950 : Closed e605602115950 ∧ code e605602115950 = 2804625371502 := by decide
theorem cert_e605602115950 : checkPay e605602115950 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e605602115958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e605602115958 : Closed e605602115958 ∧ code e605602115958 = 2804625371510 := by decide
theorem cert_e605602115958 : checkPay e605602115958 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602116022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))) (.var 1))))))
theorem wire_e605602116022 : Closed e605602116022 ∧ code e605602116022 = 2804625371574 := by decide
theorem cert_e605602116022 : check e605602116022 [[],[]] .chain = true := by decide
def e605602116054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))) (.var 1))))))
theorem wire_e605602116054 : Closed e605602116054 ∧ code e605602116054 = 2804625371606 := by decide
theorem cert_e605602116054 : check e605602116054 [[],[]] .chain = true := by decide
def e605602116058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))) (.var 0))))))
theorem wire_e605602116058 : Closed e605602116058 ∧ code e605602116058 = 2804625371610 := by decide
theorem cert_e605602116058 : check e605602116058 [[],[]] .chain = true := by decide
def e605602116438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e605602116438 : Closed e605602116438 ∧ code e605602116438 = 2804625371990 := by decide
theorem cert_e605602116438 : check e605602116438 [[],[]] .chain = true := by decide
def e605602116442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e605602116442 : Closed e605602116442 ∧ code e605602116442 = 2804625371994 := by decide
theorem cert_e605602116442 : check e605602116442 [[],[]] .chain = true := by decide
def e605602116458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e605602116458 : Closed e605602116458 ∧ code e605602116458 = 2804625372010 := by decide
theorem cert_e605602116458 : check e605602116458 [[],[]] .chain = true := by decide
def e605602116522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e605602116522 : Closed e605602116522 ∧ code e605602116522 = 2804625372074 := by decide
theorem cert_e605602116522 : check e605602116522 [[],[]] .chain = true := by decide
def e605602116630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e605602116630 : Closed e605602116630 ∧ code e605602116630 = 2804625372182 := by decide
theorem cert_e605602116630 : check e605602116630 [[],[]] .chain = true := by decide
def e605602116726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))) (.var 1))))))
theorem wire_e605602116726 : Closed e605602116726 ∧ code e605602116726 = 2804625372278 := by decide
theorem cert_e605602116726 : check e605602116726 [[],[]] .chain = true := by decide
def e605602116822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e605602116822 : Closed e605602116822 ∧ code e605602116822 = 2804625372374 := by decide
theorem cert_e605602116822 : check e605602116822 [[],[]] .chain = true := by decide
def e605602116826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e605602116826 : Closed e605602116826 ∧ code e605602116826 = 2804625372378 := by decide
theorem cert_e605602116826 : check e605602116826 [[],[]] .chain = true := by decide
def e605602116842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e605602116842 : Closed e605602116842 ∧ code e605602116842 = 2804625372394 := by decide
theorem cert_e605602116842 : check e605602116842 [[],[]] .chain = true := by decide
def e605602116918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602116918 : Closed e605602116918 ∧ code e605602116918 = 2804625372470 := by decide
theorem cert_e605602116918 : check e605602116918 [[],[]] .chain = true := by decide
def e605602116922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602116922 : Closed e605602116922 ∧ code e605602116922 = 2804625372474 := by decide
theorem cert_e605602116922 : check e605602116922 [[],[]] .chain = true := by decide
def e605602116994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e605602116994 : Closed e605602116994 ∧ code e605602116994 = 2804625372546 := by decide
theorem cert_e605602116994 : check e605602116994 [[],[]] .chain = true := by decide
def e605602117006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 2)))))))
theorem wire_e605602117006 : Closed e605602117006 ∧ code e605602117006 = 2804625372558 := by decide
theorem cert_e605602117006 : check e605602117006 [[],[]] .chain = true := by decide
def e605602117018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602117018 : Closed e605602117018 ∧ code e605602117018 = 2804625372570 := by decide
theorem cert_e605602117018 : check e605602117018 [[],[]] .chain = true := by decide
def e605602117130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e605602117130 : Closed e605602117130 ∧ code e605602117130 = 2804625372682 := by decide
theorem cert_e605602117130 : check e605602117130 [[],[]] .chain = true := by decide
def e605602117166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e605602117166 : Closed e605602117166 ∧ code e605602117166 = 2804625372718 := by decide
theorem cert_e605602117166 : check e605602117166 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e605602117174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e605602117174 : Closed e605602117174 ∧ code e605602117174 = 2804625372726 := by decide
theorem cert_e605602117174 : check e605602117174 [[],[]] .chain = true := by decide
def e605602117178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e605602117178 : Closed e605602117178 ∧ code e605602117178 = 2804625372730 := by decide
theorem cert_e605602117178 : check e605602117178 [[],[]] .chain = true := by decide
def e605602117226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e605602117226 : Closed e605602117226 ∧ code e605602117226 = 2804625372778 := by decide
theorem cert_e605602117226 : check e605602117226 [[],[]] .chain = true := by decide
def e605602117250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e605602117250 : Closed e605602117250 ∧ code e605602117250 = 2804625372802 := by decide
theorem cert_e605602117250 : check e605602117250 [[],[]] .chain = true := by decide
def e605602117262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e605602117262 : Closed e605602117262 ∧ code e605602117262 = 2804625372814 := by decide
theorem cert_e605602117262 : check e605602117262 [[],[]] .chain = true := by decide
def e605602117274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602117274 : Closed e605602117274 ∧ code e605602117274 = 2804625372826 := by decide
theorem cert_e605602117274 : check e605602117274 [[],[]] .chain = true := by decide
def e605602117318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e605602117318 : Closed e605602117318 ∧ code e605602117318 = 2804625372870 := by decide
theorem cert_e605602117318 : check e605602117318 [[],[]] .chain = true := by decide
def e605602117346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e605602117346 : Closed e605602117346 ∧ code e605602117346 = 2804625372898 := by decide
theorem cert_e605602117346 : check e605602117346 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e605602117358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 2))))))
theorem wire_e605602117358 : Closed e605602117358 ∧ code e605602117358 = 2804625372910 := by decide
theorem cert_e605602117358 : check e605602117358 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e605602117398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e605602117398 : Closed e605602117398 ∧ code e605602117398 = 2804625372950 := by decide
theorem cert_e605602117398 : check e605602117398 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605602117474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e605602117474 : Closed e605602117474 ∧ code e605602117474 = 2804625373026 := by decide
theorem cert_e605602117474 : check e605602117474 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605602117486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 2))))))
theorem wire_e605602117486 : Closed e605602117486 ∧ code e605602117486 = 2804625373038 := by decide
def e605602117494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 2))) (.var 1))))))
theorem wire_e605602117494 : Closed e605602117494 ∧ code e605602117494 = 2804625373046 := by decide
theorem cert_e605602117494 : checkPay e605602117494 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.right,.left],[.left,.right,.left,.left],[.left,.right,.left,.left,.left],[.left,.right,.left,.left],[.left,.right,.left],[.left,.right],[.right,.left],[.right,.left,.left],[.right,.left,.left,.left],[.right,.left,.left],[.right,.left],[.right]] = true := by decide
def e605602120942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602120942 : Closed e605602120942 ∧ code e605602120942 = 2804625376494 := by decide
theorem cert_e605602120942 : check e605602120942 [[],[]] .chain = true := by decide
def e605602120950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602120950 : Closed e605602120950 ∧ code e605602120950 = 2804625376502 := by decide
theorem cert_e605602120950 : check e605602120950 [[],[]] .chain = true := by decide
def e605602123502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))) (.var 2))))))
theorem wire_e605602123502 : Closed e605602123502 ∧ code e605602123502 = 2804625379054 := by decide
theorem cert_e605602123502 : check e605602123502 [[],[]] .chain = true := by decide
def e605602123510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))) (.var 1))))))
theorem wire_e605602123510 : Closed e605602123510 ∧ code e605602123510 = 2804625379062 := by decide
theorem cert_e605602123510 : check e605602123510 [[],[]] .chain = true := by decide
def e605602123630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))) (.var 2))))))
theorem wire_e605602123630 : Closed e605602123630 ∧ code e605602123630 = 2804625379182 := by decide
theorem cert_e605602123630 : check e605602123630 [[],[]] .chain = true := by decide
def e605602123642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))) (.var 0))))))
theorem wire_e605602123642 : Closed e605602123642 ∧ code e605602123642 = 2804625379194 := by decide
theorem cert_e605602123642 : check e605602123642 [[],[]] .chain = true := by decide
def e605602123702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))) (.var 1))))))
theorem wire_e605602123702 : Closed e605602123702 ∧ code e605602123702 = 2804625379254 := by decide
theorem cert_e605602123702 : check e605602123702 [[],[]] .chain = true := by decide
def e605602123706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))) (.var 0))))))
theorem wire_e605602123706 : Closed e605602123706 ∧ code e605602123706 = 2804625379258 := by decide
theorem cert_e605602123706 : check e605602123706 [[],[]] .chain = true := by decide
def e605602127086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602127086 : Closed e605602127086 ∧ code e605602127086 = 2804625382638 := by decide
theorem cert_e605602127086 : check e605602127086 [[],[]] .chain = true := by decide
def e605602127094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602127094 : Closed e605602127094 ∧ code e605602127094 = 2804625382646 := by decide
theorem cert_e605602127094 : check e605602127094 [[],[]] .chain = true := by decide
def e605602127478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.app (.var 1) (.var 1)))))))
theorem wire_e605602127478 : Closed e605602127478 ∧ code e605602127478 = 2804625383030 := by decide
theorem cert_e605602127478 : check e605602127478 [[],[]] .chain = true := by decide
def e605602131310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e605602131310 : Closed e605602131310 ∧ code e605602131310 = 2804625386862 := by decide
theorem cert_e605602131310 : check e605602131310 [[],[]] .chain = true := by decide
def e605602131318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e605602131318 : Closed e605602131318 ∧ code e605602131318 = 2804625386870 := by decide
theorem cert_e605602131318 : check e605602131318 [[],[]] .chain = true := by decide
def e605602131374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e605602131374 : Closed e605602131374 ∧ code e605602131374 = 2804625386926 := by decide
theorem cert_e605602131374 : check e605602131374 [[],[]] .chain = true := by decide
def e605602131386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e605602131386 : Closed e605602131386 ∧ code e605602131386 = 2804625386938 := by decide
theorem cert_e605602131386 : check e605602131386 [[],[]] .chain = true := by decide
def e605602131414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e605602131414 : Closed e605602131414 ∧ code e605602131414 = 2804625386966 := by decide
theorem cert_e605602131414 : check e605602131414 [[],[]] .chain = true := by decide
def e605602131418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e605602131418 : Closed e605602131418 ∧ code e605602131418 = 2804625386970 := by decide
theorem cert_e605602131418 : check e605602131418 [[],[]] .chain = true := by decide
def e605602131630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e605602131630 : Closed e605602131630 ∧ code e605602131630 = 2804625387182 := by decide
theorem cert_e605602131630 : check e605602131630 [[],[]] .chain = true := by decide
def e605602131642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e605602131642 : Closed e605602131642 ∧ code e605602131642 = 2804625387194 := by decide
theorem cert_e605602131642 : check e605602131642 [[],[]] .chain = true := by decide
def e605602131690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e605602131690 : Closed e605602131690 ∧ code e605602131690 = 2804625387242 := by decide
theorem cert_e605602131690 : check e605602131690 [[],[]] .chain = true := by decide
def e605602131798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e605602131798 : Closed e605602131798 ∧ code e605602131798 = 2804625387350 := by decide
theorem cert_e605602131798 : check e605602131798 [[],[]] .chain = true := by decide
def e605602131802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e605602131802 : Closed e605602131802 ∧ code e605602131802 = 2804625387354 := by decide
theorem cert_e605602131802 : check e605602131802 [[],[]] .chain = true := by decide
def e605602131818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e605602131818 : Closed e605602131818 ∧ code e605602131818 = 2804625387370 := by decide
theorem cert_e605602131818 : check e605602131818 [[],[]] .chain = true := by decide
def e605602132846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e605602132846 : Closed e605602132846 ∧ code e605602132846 = 2804625388398 := by decide
theorem cert_e605602132846 : check e605602132846 [[],[]] .chain = true := by decide
def e605602132854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e605602132854 : Closed e605602132854 ∧ code e605602132854 = 2804625388406 := by decide
theorem cert_e605602132854 : check e605602132854 [[],[]] .chain = true := by decide
def e605602132910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e605602132910 : Closed e605602132910 ∧ code e605602132910 = 2804625388462 := by decide
theorem cert_e605602132910 : check e605602132910 [[],[]] .chain = true := by decide
def e605602132922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e605602132922 : Closed e605602132922 ∧ code e605602132922 = 2804625388474 := by decide
theorem cert_e605602132922 : check e605602132922 [[],[]] .chain = true := by decide
def e605602132950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e605602132950 : Closed e605602132950 ∧ code e605602132950 = 2804625388502 := by decide
theorem cert_e605602132950 : check e605602132950 [[],[]] .chain = true := by decide
def e605602132954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e605602132954 : Closed e605602132954 ∧ code e605602132954 = 2804625388506 := by decide
theorem cert_e605602132954 : check e605602132954 [[],[]] .chain = true := by decide
def e605602133230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602133230 : Closed e605602133230 ∧ code e605602133230 = 2804625388782 := by decide
theorem cert_e605602133230 : check e605602133230 [[],[]] .chain = true := by decide
def e605602133238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602133238 : Closed e605602133238 ∧ code e605602133238 = 2804625388790 := by decide
theorem cert_e605602133238 : check e605602133238 [[],[]] .chain = true := by decide
def e605602133614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602133614 : Closed e605602133614 ∧ code e605602133614 = 2804625389166 := by decide
theorem cert_e605602133614 : check e605602133614 [[],[]] .chain = true := by decide
def e605602133626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602133626 : Closed e605602133626 ∧ code e605602133626 = 2804625389178 := by decide
theorem cert_e605602133626 : check e605602133626 [[],[]] .chain = true := by decide
def e605602133814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602133814 : Closed e605602133814 ∧ code e605602133814 = 2804625389366 := by decide
theorem cert_e605602133814 : check e605602133814 [[],[]] .chain = true := by decide
def e605602133818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602133818 : Closed e605602133818 ∧ code e605602133818 = 2804625389370 := by decide
theorem cert_e605602133818 : check e605602133818 [[],[]] .chain = true := by decide
def e605602134062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 2))))))
theorem wire_e605602134062 : Closed e605602134062 ∧ code e605602134062 = 2804625389614 := by decide
theorem cert_e605602134062 : check e605602134062 [[],[]] .chain = true := by decide
def e605602134254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))) (.var 2))))))
theorem wire_e605602134254 : Closed e605602134254 ∧ code e605602134254 = 2804625389806 := by decide
theorem cert_e605602134254 : check e605602134254 [[],[]] .chain = true := by decide
def e605602134262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))) (.var 1))))))
theorem wire_e605602134262 : Closed e605602134262 ∧ code e605602134262 = 2804625389814 := by decide
theorem cert_e605602134262 : check e605602134262 [[],[]] .chain = true := by decide
def e605602134446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e605602134446 : Closed e605602134446 ∧ code e605602134446 = 2804625389998 := by decide
theorem cert_e605602134446 : check e605602134446 [[],[]] .chain = true := by decide
def e605602134458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e605602134458 : Closed e605602134458 ∧ code e605602134458 = 2804625390010 := by decide
theorem cert_e605602134458 : check e605602134458 [[],[]] .chain = true := by decide
def e605602134506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e605602134506 : Closed e605602134506 ∧ code e605602134506 = 2804625390058 := by decide
theorem cert_e605602134506 : check e605602134506 [[],[]] .chain = true := by decide
def e605602134638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602134638 : Closed e605602134638 ∧ code e605602134638 = 2804625390190 := by decide
theorem cert_e605602134638 : check e605602134638 [[],[]] .chain = true := by decide
def e605602134650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602134650 : Closed e605602134650 ∧ code e605602134650 = 2804625390202 := by decide
theorem cert_e605602134650 : check e605602134650 [[],[]] .chain = true := by decide
def e605602134814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e605602134814 : Closed e605602134814 ∧ code e605602134814 = 2804625390366 := by decide
theorem cert_e605602134814 : check e605602134814 [[],[]] .chain = true := by decide
def e605602134914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.lam (.var 0))))))))
theorem wire_e605602134914 : Closed e605602134914 ∧ code e605602134914 = 2804625390466 := by decide
theorem cert_e605602134914 : check e605602134914 [[],[]] .chain = true := by decide
def e605602134926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e605602134926 : Closed e605602134926 ∧ code e605602134926 = 2804625390478 := by decide
theorem cert_e605602134926 : check e605602134926 [[],[]] .chain = true := by decide
def e605602134938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602134938 : Closed e605602134938 ∧ code e605602134938 = 2804625390490 := by decide
theorem cert_e605602134938 : check e605602134938 [[],[]] .chain = true := by decide
def e605602135062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e605602135062 : Closed e605602135062 ∧ code e605602135062 = 2804625390614 := by decide
theorem cert_e605602135062 : check e605602135062 [[],[]] .chain = true := by decide
def e605602135158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))) (.var 1))))))
theorem wire_e605602135158 : Closed e605602135158 ∧ code e605602135158 = 2804625390710 := by decide
theorem cert_e605602135158 : check e605602135158 [[],[]] .chain = true := by decide
def e605602135254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e605602135254 : Closed e605602135254 ∧ code e605602135254 = 2804625390806 := by decide
theorem cert_e605602135254 : check e605602135254 [[],[]] .chain = true := by decide
def e605602135258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e605602135258 : Closed e605602135258 ∧ code e605602135258 = 2804625390810 := by decide
theorem cert_e605602135258 : check e605602135258 [[],[]] .chain = true := by decide
def e605602135274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e605602135274 : Closed e605602135274 ∧ code e605602135274 = 2804625390826 := by decide
theorem cert_e605602135274 : check e605602135274 [[],[]] .chain = true := by decide
def e605602135350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602135350 : Closed e605602135350 ∧ code e605602135350 = 2804625390902 := by decide
theorem cert_e605602135350 : check e605602135350 [[],[]] .chain = true := by decide
def e605602135354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602135354 : Closed e605602135354 ∧ code e605602135354 = 2804625390906 := by decide
theorem cert_e605602135354 : check e605602135354 [[],[]] .chain = true := by decide
def e605602135426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.lam (.var 0))))))))
theorem wire_e605602135426 : Closed e605602135426 ∧ code e605602135426 = 2804625390978 := by decide
theorem cert_e605602135426 : check e605602135426 [[],[]] .chain = true := by decide
def e605602135438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e605602135438 : Closed e605602135438 ∧ code e605602135438 = 2804625390990 := by decide
theorem cert_e605602135438 : check e605602135438 [[],[]] .chain = true := by decide
def e605602135450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602135450 : Closed e605602135450 ∧ code e605602135450 = 2804625391002 := by decide
theorem cert_e605602135450 : check e605602135450 [[],[]] .chain = true := by decide
def e605602137054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e605602137054 : Closed e605602137054 ∧ code e605602137054 = 2804625392606 := by decide
theorem cert_e605602137054 : check e605602137054 [[],[]] .chain = true := by decide
def e605602137070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e605602137070 : Closed e605602137070 ∧ code e605602137070 = 2804625392622 := by decide
theorem cert_e605602137070 : check e605602137070 [[],[]] .chain = true := by decide
def e605602138990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605602138990 : Closed e605602138990 ∧ code e605602138990 = 2804625394542 := by decide
theorem cert_e605602138990 : check e605602138990 [[],[]] .chain = true := by decide
def e605602138998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605602138998 : Closed e605602138998 ∧ code e605602138998 = 2804625394550 := by decide
theorem cert_e605602138998 : check e605602138998 [[],[]] .chain = true := by decide
def e605602139054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605602139054 : Closed e605602139054 ∧ code e605602139054 = 2804625394606 := by decide
theorem cert_e605602139054 : check e605602139054 [[],[]] .chain = true := by decide
def e605602139066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605602139066 : Closed e605602139066 ∧ code e605602139066 = 2804625394618 := by decide
theorem cert_e605602139066 : check e605602139066 [[],[]] .chain = true := by decide
def e605602139094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605602139094 : Closed e605602139094 ∧ code e605602139094 = 2804625394646 := by decide
theorem cert_e605602139094 : check e605602139094 [[],[]] .chain = true := by decide
def e605602139098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605602139098 : Closed e605602139098 ∧ code e605602139098 = 2804625394650 := by decide
theorem cert_e605602139098 : check e605602139098 [[],[]] .chain = true := by decide
def e605602139374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605602139374 : Closed e605602139374 ∧ code e605602139374 = 2804625394926 := by decide
theorem cert_e605602139374 : check e605602139374 [[],[]] .chain = true := by decide
def e605602139382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605602139382 : Closed e605602139382 ∧ code e605602139382 = 2804625394934 := by decide
theorem cert_e605602139382 : check e605602139382 [[],[]] .chain = true := by decide
def e605602139758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605602139758 : Closed e605602139758 ∧ code e605602139758 = 2804625395310 := by decide
theorem cert_e605602139758 : check e605602139758 [[],[]] .chain = true := by decide
def e605602139770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605602139770 : Closed e605602139770 ∧ code e605602139770 = 2804625395322 := by decide
theorem cert_e605602139770 : check e605602139770 [[],[]] .chain = true := by decide
def e605602139958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605602139958 : Closed e605602139958 ∧ code e605602139958 = 2804625395510 := by decide
theorem cert_e605602139958 : check e605602139958 [[],[]] .chain = true := by decide
def e605602139962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605602139962 : Closed e605602139962 ∧ code e605602139962 = 2804625395514 := by decide
theorem cert_e605602139962 : check e605602139962 [[],[]] .chain = true := by decide
def e605602144734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e605602144734 : Closed e605602144734 ∧ code e605602144734 = 2804625400286 := by decide
theorem cert_e605602144734 : check e605602144734 [[],[]] .chain = true := by decide
def e605602144758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e605602144758 : Closed e605602144758 ∧ code e605602144758 = 2804625400310 := by decide
theorem cert_e605602144758 : check e605602144758 [[],[]] .chain = true := by decide
def e605602145710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e605602145710 : Closed e605602145710 ∧ code e605602145710 = 2804625401262 := by decide
theorem cert_e605602145710 : check e605602145710 [[],[]] .chain = true := by decide
def e605602145722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e605602145722 : Closed e605602145722 ∧ code e605602145722 = 2804625401274 := by decide
theorem cert_e605602145722 : check e605602145722 [[],[]] .chain = true := by decide
def e605602145770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e605602145770 : Closed e605602145770 ∧ code e605602145770 = 2804625401322 := by decide
theorem cert_e605602145770 : check e605602145770 [[],[]] .chain = true := by decide
def e605602145902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e605602145902 : Closed e605602145902 ∧ code e605602145902 = 2804625401454 := by decide
theorem cert_e605602145902 : check e605602145902 [[],[]] .chain = true := by decide
def e605602145914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e605602145914 : Closed e605602145914 ∧ code e605602145914 = 2804625401466 := by decide
theorem cert_e605602145914 : check e605602145914 [[],[]] .chain = true := by decide
def e605602146078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e605602146078 : Closed e605602146078 ∧ code e605602146078 = 2804625401630 := by decide
theorem cert_e605602146078 : check e605602146078 [[],[]] .chain = true := by decide
def e605602146178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e605602146178 : Closed e605602146178 ∧ code e605602146178 = 2804625401730 := by decide
theorem cert_e605602146178 : check e605602146178 [[],[]] .chain = true := by decide
def e605602146190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e605602146190 : Closed e605602146190 ∧ code e605602146190 = 2804625401742 := by decide
theorem cert_e605602146190 : check e605602146190 [[],[]] .chain = true := by decide
def e605602146202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e605602146202 : Closed e605602146202 ∧ code e605602146202 = 2804625401754 := by decide
theorem cert_e605602146202 : check e605602146202 [[],[]] .chain = true := by decide
def e605602148590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e605602148590 : Closed e605602148590 ∧ code e605602148590 = 2804625404142 := by decide
theorem cert_e605602148590 : check e605602148590 [[],[]] .chain = true := by decide
def e605602148598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e605602148598 : Closed e605602148598 ∧ code e605602148598 = 2804625404150 := by decide
theorem cert_e605602148598 : check e605602148598 [[],[]] .chain = true := by decide
def e605602149078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e605602149078 : Closed e605602149078 ∧ code e605602149078 = 2804625404630 := by decide
theorem cert_e605602149078 : check e605602149078 [[],[]] .chain = true := by decide
def e605602149082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e605602149082 : Closed e605602149082 ∧ code e605602149082 = 2804625404634 := by decide
theorem cert_e605602149082 : check e605602149082 [[],[]] .chain = true := by decide
def e605602149098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e605602149098 : Closed e605602149098 ∧ code e605602149098 = 2804625404650 := by decide
theorem cert_e605602149098 : check e605602149098 [[],[]] .chain = true := by decide
def e605602149174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e605602149174 : Closed e605602149174 ∧ code e605602149174 = 2804625404726 := by decide
theorem cert_e605602149174 : check e605602149174 [[],[]] .chain = true := by decide
def e605602149178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e605602149178 : Closed e605602149178 ∧ code e605602149178 = 2804625404730 := by decide
theorem cert_e605602149178 : check e605602149178 [[],[]] .chain = true := by decide
def e605602149250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e605602149250 : Closed e605602149250 ∧ code e605602149250 = 2804625404802 := by decide
theorem cert_e605602149250 : check e605602149250 [[],[]] .chain = true := by decide
def e605602149262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e605602149262 : Closed e605602149262 ∧ code e605602149262 = 2804625404814 := by decide
theorem cert_e605602149262 : check e605602149262 [[],[]] .chain = true := by decide
def e605602149274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e605602149274 : Closed e605602149274 ∧ code e605602149274 = 2804625404826 := by decide
theorem cert_e605602149274 : check e605602149274 [[],[]] .chain = true := by decide
def e605602152878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 2))))))
theorem wire_e605602152878 : Closed e605602152878 ∧ code e605602152878 = 2804625408430 := by decide
theorem cert_e605602152878 : check e605602152878 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602153070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602153070 : Closed e605602153070 ∧ code e605602153070 = 2804625408622 := by decide
theorem cert_e605602153070 : check e605602153070 [[],[]] .chain = true := by decide
end Blc.Floor41
