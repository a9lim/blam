import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605601720234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e605601720234 : Closed e605601720234 ∧ code e605601720234 = 2804624975786 := by decide
theorem cert_e605601720234 : check e605601720234 [[],[]] .chain = true := by decide
def e605601720366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e605601720366 : Closed e605601720366 ∧ code e605601720366 = 2804624975918 := by decide
theorem cert_e605601720366 : check e605601720366 [[],[]] .chain = true := by decide
def e605601720558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 2))) (.var 2))))))
theorem wire_e605601720558 : Closed e605601720558 ∧ code e605601720558 = 2804624976110 := by decide
theorem cert_e605601720558 : check e605601720558 [[],[]] .chain = true := by decide
def e605601720566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.var 1))))))
theorem wire_e605601720566 : Closed e605601720566 ∧ code e605601720566 = 2804624976118 := by decide
theorem cert_e605601720566 : check e605601720566 [[],[]] .chain = true := by decide
def e605601720750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e605601720750 : Closed e605601720750 ∧ code e605601720750 = 2804624976302 := by decide
theorem cert_e605601720750 : check e605601720750 [[],[]] .chain = true := by decide
def e605601720762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e605601720762 : Closed e605601720762 ∧ code e605601720762 = 2804624976314 := by decide
theorem cert_e605601720762 : check e605601720762 [[],[]] .chain = true := by decide
def e605601720810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e605601720810 : Closed e605601720810 ∧ code e605601720810 = 2804624976362 := by decide
theorem cert_e605601720810 : check e605601720810 [[],[]] .chain = true := by decide
def e605601720942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601720942 : Closed e605601720942 ∧ code e605601720942 = 2804624976494 := by decide
theorem cert_e605601720942 : check e605601720942 [[],[]] .chain = true := by decide
def e605601720954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601720954 : Closed e605601720954 ∧ code e605601720954 = 2804624976506 := by decide
theorem cert_e605601720954 : check e605601720954 [[],[]] .chain = true := by decide
def e605601721118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e605601721118 : Closed e605601721118 ∧ code e605601721118 = 2804624976670 := by decide
theorem cert_e605601721118 : check e605601721118 [[],[]] .chain = true := by decide
def e605601721218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e605601721218 : Closed e605601721218 ∧ code e605601721218 = 2804624976770 := by decide
theorem cert_e605601721218 : check e605601721218 [[],[]] .chain = true := by decide
def e605601721230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e605601721230 : Closed e605601721230 ∧ code e605601721230 = 2804624976782 := by decide
theorem cert_e605601721230 : check e605601721230 [[],[]] .chain = true := by decide
def e605601721242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601721242 : Closed e605601721242 ∧ code e605601721242 = 2804624976794 := by decide
theorem cert_e605601721242 : check e605601721242 [[],[]] .chain = true := by decide
def e605601721454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e605601721454 : Closed e605601721454 ∧ code e605601721454 = 2804624977006 := by decide
theorem cert_e605601721454 : check e605601721454 [[],[]] .chain = true := by decide
def e605601721466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e605601721466 : Closed e605601721466 ∧ code e605601721466 = 2804624977018 := by decide
theorem cert_e605601721466 : check e605601721466 [[],[]] .chain = true := by decide
def e605601721630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e605601721630 : Closed e605601721630 ∧ code e605601721630 = 2804624977182 := by decide
theorem cert_e605601721630 : check e605601721630 [[],[]] .chain = true := by decide
def e605601721798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e605601721798 : Closed e605601721798 ∧ code e605601721798 = 2804624977350 := by decide
theorem cert_e605601721798 : check e605601721798 [[],[]] .chain = true := by decide
def e605601721866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601721866 : Closed e605601721866 ∧ code e605601721866 = 2804624977418 := by decide
theorem cert_e605601721866 : check e605601721866 [[],[]] .chain = true := by decide
def e605601721902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 2))))))
theorem wire_e605601721902 : Closed e605601721902 ∧ code e605601721902 = 2804624977454 := by decide
theorem cert_e605601721902 : check e605601721902 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601721910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.var 1))))))
theorem wire_e605601721910 : Closed e605601721910 ∧ code e605601721910 = 2804624977462 := by decide
theorem cert_e605601721910 : check e605601721910 [[],[]] .chain = true := by decide
def e605601721914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))) (.var 0))))))
theorem wire_e605601721914 : Closed e605601721914 ∧ code e605601721914 = 2804624977466 := by decide
theorem cert_e605601721914 : check e605601721914 [[],[]] .chain = true := by decide
def e605601721962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e605601721962 : Closed e605601721962 ∧ code e605601721962 = 2804624977514 := by decide
theorem cert_e605601721962 : check e605601721962 [[],[]] .chain = true := by decide
def e605601721986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e605601721986 : Closed e605601721986 ∧ code e605601721986 = 2804624977538 := by decide
theorem cert_e605601721986 : check e605601721986 [[],[]] .chain = true := by decide
def e605601721998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e605601721998 : Closed e605601721998 ∧ code e605601721998 = 2804624977550 := by decide
theorem cert_e605601721998 : check e605601721998 [[],[]] .chain = true := by decide
def e605601722010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601722010 : Closed e605601722010 ∧ code e605601722010 = 2804624977562 := by decide
theorem cert_e605601722010 : check e605601722010 [[],[]] .chain = true := by decide
def e605601722054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e605601722054 : Closed e605601722054 ∧ code e605601722054 = 2804624977606 := by decide
theorem cert_e605601722054 : check e605601722054 [[],[]] .chain = true := by decide
def e605601722082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e605601722082 : Closed e605601722082 ∧ code e605601722082 = 2804624977634 := by decide
theorem cert_e605601722082 : check e605601722082 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601722094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 2))))))
theorem wire_e605601722094 : Closed e605601722094 ∧ code e605601722094 = 2804624977646 := by decide
theorem cert_e605601722094 : check e605601722094 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601722454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e605601722454 : Closed e605601722454 ∧ code e605601722454 = 2804624978006 := by decide
theorem cert_e605601722454 : check e605601722454 [[],[]] .chain = true := by decide
def e605601722458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e605601722458 : Closed e605601722458 ∧ code e605601722458 = 2804624978010 := by decide
theorem cert_e605601722458 : check e605601722458 [[],[]] .chain = true := by decide
def e605601722734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e605601722734 : Closed e605601722734 ∧ code e605601722734 = 2804624978286 := by decide
theorem cert_e605601722734 : check e605601722734 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605601722742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e605601722742 : Closed e605601722742 ∧ code e605601722742 = 2804624978294 := by decide
theorem cert_e605601722742 : check e605601722742 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601722806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e605601722806 : Closed e605601722806 ∧ code e605601722806 = 2804624978358 := by decide
theorem cert_e605601722806 : check e605601722806 [[],[]] .chain = true := by decide
def e605601722838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e605601722838 : Closed e605601722838 ∧ code e605601722838 = 2804624978390 := by decide
theorem cert_e605601722838 : check e605601722838 [[],[]] .chain = true := by decide
def e605601722842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e605601722842 : Closed e605601722842 ∧ code e605601722842 = 2804624978394 := by decide
theorem cert_e605601722842 : check e605601722842 [[],[]] .chain = true := by decide
def e605601723222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e605601723222 : Closed e605601723222 ∧ code e605601723222 = 2804624978774 := by decide
theorem cert_e605601723222 : check e605601723222 [[],[]] .chain = true := by decide
def e605601723226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e605601723226 : Closed e605601723226 ∧ code e605601723226 = 2804624978778 := by decide
theorem cert_e605601723226 : check e605601723226 [[],[]] .chain = true := by decide
def e605601723242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e605601723242 : Closed e605601723242 ∧ code e605601723242 = 2804624978794 := by decide
theorem cert_e605601723242 : check e605601723242 [[],[]] .chain = true := by decide
def e605601723306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e605601723306 : Closed e605601723306 ∧ code e605601723306 = 2804624978858 := by decide
theorem cert_e605601723306 : check e605601723306 [[],[]] .chain = true := by decide
def e605601723414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e605601723414 : Closed e605601723414 ∧ code e605601723414 = 2804624978966 := by decide
theorem cert_e605601723414 : check e605601723414 [[],[]] .chain = true := by decide
def e605601723510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.var 1))))))
theorem wire_e605601723510 : Closed e605601723510 ∧ code e605601723510 = 2804624979062 := by decide
theorem cert_e605601723510 : check e605601723510 [[],[]] .chain = true := by decide
def e605601723606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e605601723606 : Closed e605601723606 ∧ code e605601723606 = 2804624979158 := by decide
theorem cert_e605601723606 : check e605601723606 [[],[]] .chain = true := by decide
def e605601723610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e605601723610 : Closed e605601723610 ∧ code e605601723610 = 2804624979162 := by decide
theorem cert_e605601723610 : check e605601723610 [[],[]] .chain = true := by decide
def e605601723626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e605601723626 : Closed e605601723626 ∧ code e605601723626 = 2804624979178 := by decide
theorem cert_e605601723626 : check e605601723626 [[],[]] .chain = true := by decide
def e605601723702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601723702 : Closed e605601723702 ∧ code e605601723702 = 2804624979254 := by decide
theorem cert_e605601723702 : check e605601723702 [[],[]] .chain = true := by decide
def e605601723706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601723706 : Closed e605601723706 ∧ code e605601723706 = 2804624979258 := by decide
theorem cert_e605601723706 : check e605601723706 [[],[]] .chain = true := by decide
def e605601723778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e605601723778 : Closed e605601723778 ∧ code e605601723778 = 2804624979330 := by decide
theorem cert_e605601723778 : check e605601723778 [[],[]] .chain = true := by decide
def e605601723790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e605601723790 : Closed e605601723790 ∧ code e605601723790 = 2804624979342 := by decide
theorem cert_e605601723790 : check e605601723790 [[],[]] .chain = true := by decide
def e605601723802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601723802 : Closed e605601723802 ∧ code e605601723802 = 2804624979354 := by decide
theorem cert_e605601723802 : check e605601723802 [[],[]] .chain = true := by decide
def e605601723914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601723914 : Closed e605601723914 ∧ code e605601723914 = 2804624979466 := by decide
theorem cert_e605601723914 : check e605601723914 [[],[]] .chain = true := by decide
def e605601723950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e605601723950 : Closed e605601723950 ∧ code e605601723950 = 2804624979502 := by decide
theorem cert_e605601723950 : check e605601723950 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e605601723958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.var 1))))))
theorem wire_e605601723958 : Closed e605601723958 ∧ code e605601723958 = 2804624979510 := by decide
theorem cert_e605601723958 : check e605601723958 [[],[]] .chain = true := by decide
def e605601723962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))) (.var 0))))))
theorem wire_e605601723962 : Closed e605601723962 ∧ code e605601723962 = 2804624979514 := by decide
theorem cert_e605601723962 : check e605601723962 [[],[]] .chain = true := by decide
def e605601724010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e605601724010 : Closed e605601724010 ∧ code e605601724010 = 2804624979562 := by decide
theorem cert_e605601724010 : check e605601724010 [[],[]] .chain = true := by decide
def e605601724034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e605601724034 : Closed e605601724034 ∧ code e605601724034 = 2804624979586 := by decide
theorem cert_e605601724034 : check e605601724034 [[],[]] .chain = true := by decide
def e605601724046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e605601724046 : Closed e605601724046 ∧ code e605601724046 = 2804624979598 := by decide
theorem cert_e605601724046 : check e605601724046 [[],[]] .chain = true := by decide
def e605601724058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601724058 : Closed e605601724058 ∧ code e605601724058 = 2804624979610 := by decide
theorem cert_e605601724058 : check e605601724058 [[],[]] .chain = true := by decide
def e605601724102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e605601724102 : Closed e605601724102 ∧ code e605601724102 = 2804624979654 := by decide
theorem cert_e605601724102 : check e605601724102 [[],[]] .chain = true := by decide
def e605601724130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e605601724130 : Closed e605601724130 ∧ code e605601724130 = 2804624979682 := by decide
theorem cert_e605601724130 : check e605601724130 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e605601724142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e605601724142 : Closed e605601724142 ∧ code e605601724142 = 2804624979694 := by decide
theorem cert_e605601724142 : check e605601724142 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e605601724182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 0))) (.var 1))))))
theorem wire_e605601724182 : Closed e605601724182 ∧ code e605601724182 = 2804624979734 := by decide
theorem cert_e605601724182 : check e605601724182 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e605601724258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e605601724258 : Closed e605601724258 ∧ code e605601724258 = 2804624979810 := by decide
theorem cert_e605601724258 : check e605601724258 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e605601724270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e605601724270 : Closed e605601724270 ∧ code e605601724270 = 2804624979822 := by decide
theorem cert_e605601724270 : check e605601724270 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e605601724278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e605601724278 : Closed e605601724278 ∧ code e605601724278 = 2804624979830 := by decide
theorem cert_e605601724278 : check e605601724278 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e605601727726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605601727726 : Closed e605601727726 ∧ code e605601727726 = 2804624983278 := by decide
theorem cert_e605601727726 : check e605601727726 [[],[]] .chain = true := by decide
def e605601727734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605601727734 : Closed e605601727734 ∧ code e605601727734 = 2804624983286 := by decide
theorem cert_e605601727734 : check e605601727734 [[],[]] .chain = true := by decide
def e605601730286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e605601730286 : Closed e605601730286 ∧ code e605601730286 = 2804624985838 := by decide
theorem cert_e605601730286 : check e605601730286 [[],[]] .chain = true := by decide
def e605601730294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e605601730294 : Closed e605601730294 ∧ code e605601730294 = 2804624985846 := by decide
theorem cert_e605601730294 : check e605601730294 [[],[]] .chain = true := by decide
def e605601730414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e605601730414 : Closed e605601730414 ∧ code e605601730414 = 2804624985966 := by decide
theorem cert_e605601730414 : check e605601730414 [[],[]] .chain = true := by decide
def e605601730426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e605601730426 : Closed e605601730426 ∧ code e605601730426 = 2804624985978 := by decide
theorem cert_e605601730426 : check e605601730426 [[],[]] .chain = true := by decide
def e605601730486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e605601730486 : Closed e605601730486 ∧ code e605601730486 = 2804624986038 := by decide
theorem cert_e605601730486 : check e605601730486 [[],[]] .chain = true := by decide
def e605601730490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e605601730490 : Closed e605601730490 ∧ code e605601730490 = 2804624986042 := by decide
theorem cert_e605601730490 : check e605601730490 [[],[]] .chain = true := by decide
def e605601733870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e605601733870 : Closed e605601733870 ∧ code e605601733870 = 2804624989422 := by decide
theorem cert_e605601733870 : check e605601733870 [[],[]] .chain = true := by decide
def e605601733878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e605601733878 : Closed e605601733878 ∧ code e605601733878 = 2804624989430 := by decide
theorem cert_e605601733878 : check e605601733878 [[],[]] .chain = true := by decide
def e605601734262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e605601734262 : Closed e605601734262 ∧ code e605601734262 = 2804624989814 := by decide
theorem cert_e605601734262 : check e605601734262 [[],[]] .chain = true := by decide
def e605601738094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e605601738094 : Closed e605601738094 ∧ code e605601738094 = 2804624993646 := by decide
theorem cert_e605601738094 : check e605601738094 [[],[]] .chain = true := by decide
def e605601738102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e605601738102 : Closed e605601738102 ∧ code e605601738102 = 2804624993654 := by decide
theorem cert_e605601738102 : check e605601738102 [[],[]] .chain = true := by decide
def e605601738158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e605601738158 : Closed e605601738158 ∧ code e605601738158 = 2804624993710 := by decide
theorem cert_e605601738158 : check e605601738158 [[],[]] .chain = true := by decide
def e605601738170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e605601738170 : Closed e605601738170 ∧ code e605601738170 = 2804624993722 := by decide
theorem cert_e605601738170 : check e605601738170 [[],[]] .chain = true := by decide
def e605601738198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e605601738198 : Closed e605601738198 ∧ code e605601738198 = 2804624993750 := by decide
theorem cert_e605601738198 : check e605601738198 [[],[]] .chain = true := by decide
def e605601738202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e605601738202 : Closed e605601738202 ∧ code e605601738202 = 2804624993754 := by decide
theorem cert_e605601738202 : check e605601738202 [[],[]] .chain = true := by decide
def e605601738414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e605601738414 : Closed e605601738414 ∧ code e605601738414 = 2804624993966 := by decide
theorem cert_e605601738414 : check e605601738414 [[],[]] .chain = true := by decide
def e605601738426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e605601738426 : Closed e605601738426 ∧ code e605601738426 = 2804624993978 := by decide
theorem cert_e605601738426 : check e605601738426 [[],[]] .chain = true := by decide
def e605601738474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e605601738474 : Closed e605601738474 ∧ code e605601738474 = 2804624994026 := by decide
theorem cert_e605601738474 : check e605601738474 [[],[]] .chain = true := by decide
def e605601738582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e605601738582 : Closed e605601738582 ∧ code e605601738582 = 2804624994134 := by decide
theorem cert_e605601738582 : check e605601738582 [[],[]] .chain = true := by decide
def e605601738586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e605601738586 : Closed e605601738586 ∧ code e605601738586 = 2804624994138 := by decide
theorem cert_e605601738586 : check e605601738586 [[],[]] .chain = true := by decide
def e605601738602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e605601738602 : Closed e605601738602 ∧ code e605601738602 = 2804624994154 := by decide
theorem cert_e605601738602 : check e605601738602 [[],[]] .chain = true := by decide
def e605601739630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e605601739630 : Closed e605601739630 ∧ code e605601739630 = 2804624995182 := by decide
theorem cert_e605601739630 : check e605601739630 [[],[]] .chain = true := by decide
def e605601739638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e605601739638 : Closed e605601739638 ∧ code e605601739638 = 2804624995190 := by decide
theorem cert_e605601739638 : check e605601739638 [[],[]] .chain = true := by decide
def e605601739694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e605601739694 : Closed e605601739694 ∧ code e605601739694 = 2804624995246 := by decide
theorem cert_e605601739694 : check e605601739694 [[],[]] .chain = true := by decide
def e605601739706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e605601739706 : Closed e605601739706 ∧ code e605601739706 = 2804624995258 := by decide
theorem cert_e605601739706 : check e605601739706 [[],[]] .chain = true := by decide
def e605601739734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e605601739734 : Closed e605601739734 ∧ code e605601739734 = 2804624995286 := by decide
theorem cert_e605601739734 : check e605601739734 [[],[]] .chain = true := by decide
def e605601739738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e605601739738 : Closed e605601739738 ∧ code e605601739738 = 2804624995290 := by decide
theorem cert_e605601739738 : check e605601739738 [[],[]] .chain = true := by decide
def e605601740014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e605601740014 : Closed e605601740014 ∧ code e605601740014 = 2804624995566 := by decide
theorem cert_e605601740014 : check e605601740014 [[],[]] .chain = true := by decide
def e605601740022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e605601740022 : Closed e605601740022 ∧ code e605601740022 = 2804624995574 := by decide
theorem cert_e605601740022 : check e605601740022 [[],[]] .chain = true := by decide
def e605601740398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e605601740398 : Closed e605601740398 ∧ code e605601740398 = 2804624995950 := by decide
theorem cert_e605601740398 : check e605601740398 [[],[]] .chain = true := by decide
def e605601740410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e605601740410 : Closed e605601740410 ∧ code e605601740410 = 2804624995962 := by decide
theorem cert_e605601740410 : check e605601740410 [[],[]] .chain = true := by decide
def e605601740598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601740598 : Closed e605601740598 ∧ code e605601740598 = 2804624996150 := by decide
theorem cert_e605601740598 : check e605601740598 [[],[]] .chain = true := by decide
def e605601740602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601740602 : Closed e605601740602 ∧ code e605601740602 = 2804624996154 := by decide
theorem cert_e605601740602 : check e605601740602 [[],[]] .chain = true := by decide
def e605601740846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e605601740846 : Closed e605601740846 ∧ code e605601740846 = 2804624996398 := by decide
theorem cert_e605601740846 : check e605601740846 [[],[]] .chain = true := by decide
def e605601741038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e605601741038 : Closed e605601741038 ∧ code e605601741038 = 2804624996590 := by decide
theorem cert_e605601741038 : check e605601741038 [[],[]] .chain = true := by decide
def e605601741046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e605601741046 : Closed e605601741046 ∧ code e605601741046 = 2804624996598 := by decide
theorem cert_e605601741046 : check e605601741046 [[],[]] .chain = true := by decide
def e605601741230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e605601741230 : Closed e605601741230 ∧ code e605601741230 = 2804624996782 := by decide
theorem cert_e605601741230 : check e605601741230 [[],[]] .chain = true := by decide
def e605601741242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e605601741242 : Closed e605601741242 ∧ code e605601741242 = 2804624996794 := by decide
theorem cert_e605601741242 : check e605601741242 [[],[]] .chain = true := by decide
def e605601741290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e605601741290 : Closed e605601741290 ∧ code e605601741290 = 2804624996842 := by decide
theorem cert_e605601741290 : check e605601741290 [[],[]] .chain = true := by decide
def e605601741422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e605601741422 : Closed e605601741422 ∧ code e605601741422 = 2804624996974 := by decide
theorem cert_e605601741422 : check e605601741422 [[],[]] .chain = true := by decide
def e605601741434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e605601741434 : Closed e605601741434 ∧ code e605601741434 = 2804624996986 := by decide
theorem cert_e605601741434 : check e605601741434 [[],[]] .chain = true := by decide
def e605601741598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e605601741598 : Closed e605601741598 ∧ code e605601741598 = 2804624997150 := by decide
theorem cert_e605601741598 : check e605601741598 [[],[]] .chain = true := by decide
def e605601741698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e605601741698 : Closed e605601741698 ∧ code e605601741698 = 2804624997250 := by decide
theorem cert_e605601741698 : check e605601741698 [[],[]] .chain = true := by decide
def e605601741710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e605601741710 : Closed e605601741710 ∧ code e605601741710 = 2804624997262 := by decide
theorem cert_e605601741710 : check e605601741710 [[],[]] .chain = true := by decide
def e605601741722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601741722 : Closed e605601741722 ∧ code e605601741722 = 2804624997274 := by decide
theorem cert_e605601741722 : check e605601741722 [[],[]] .chain = true := by decide
def e605601741846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e605601741846 : Closed e605601741846 ∧ code e605601741846 = 2804624997398 := by decide
theorem cert_e605601741846 : check e605601741846 [[],[]] .chain = true := by decide
def e605601741942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e605601741942 : Closed e605601741942 ∧ code e605601741942 = 2804624997494 := by decide
theorem cert_e605601741942 : check e605601741942 [[],[]] .chain = true := by decide
def e605601742038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e605601742038 : Closed e605601742038 ∧ code e605601742038 = 2804624997590 := by decide
theorem cert_e605601742038 : check e605601742038 [[],[]] .chain = true := by decide
def e605601742042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e605601742042 : Closed e605601742042 ∧ code e605601742042 = 2804624997594 := by decide
theorem cert_e605601742042 : check e605601742042 [[],[]] .chain = true := by decide
def e605601742058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e605601742058 : Closed e605601742058 ∧ code e605601742058 = 2804624997610 := by decide
theorem cert_e605601742058 : check e605601742058 [[],[]] .chain = true := by decide
def e605601742134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601742134 : Closed e605601742134 ∧ code e605601742134 = 2804624997686 := by decide
theorem cert_e605601742134 : check e605601742134 [[],[]] .chain = true := by decide
def e605601742138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601742138 : Closed e605601742138 ∧ code e605601742138 = 2804624997690 := by decide
theorem cert_e605601742138 : check e605601742138 [[],[]] .chain = true := by decide
def e605601742210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e605601742210 : Closed e605601742210 ∧ code e605601742210 = 2804624997762 := by decide
theorem cert_e605601742210 : check e605601742210 [[],[]] .chain = true := by decide
def e605601742222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e605601742222 : Closed e605601742222 ∧ code e605601742222 = 2804624997774 := by decide
theorem cert_e605601742222 : check e605601742222 [[],[]] .chain = true := by decide
def e605601742234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601742234 : Closed e605601742234 ∧ code e605601742234 = 2804624997786 := by decide
theorem cert_e605601742234 : check e605601742234 [[],[]] .chain = true := by decide
def e605601743838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e605601743838 : Closed e605601743838 ∧ code e605601743838 = 2804624999390 := by decide
theorem cert_e605601743838 : check e605601743838 [[],[]] .chain = true := by decide
def e605601743854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e605601743854 : Closed e605601743854 ∧ code e605601743854 = 2804624999406 := by decide
theorem cert_e605601743854 : check e605601743854 [[],[]] .chain = true := by decide
def e605601745774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605601745774 : Closed e605601745774 ∧ code e605601745774 = 2804625001326 := by decide
theorem cert_e605601745774 : check e605601745774 [[],[]] .chain = true := by decide
def e605601745782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605601745782 : Closed e605601745782 ∧ code e605601745782 = 2804625001334 := by decide
theorem cert_e605601745782 : check e605601745782 [[],[]] .chain = true := by decide
def e605601745838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605601745838 : Closed e605601745838 ∧ code e605601745838 = 2804625001390 := by decide
theorem cert_e605601745838 : check e605601745838 [[],[]] .chain = true := by decide
def e605601745850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605601745850 : Closed e605601745850 ∧ code e605601745850 = 2804625001402 := by decide
theorem cert_e605601745850 : check e605601745850 [[],[]] .chain = true := by decide
def e605601745878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605601745878 : Closed e605601745878 ∧ code e605601745878 = 2804625001430 := by decide
theorem cert_e605601745878 : check e605601745878 [[],[]] .chain = true := by decide
def e605601745882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605601745882 : Closed e605601745882 ∧ code e605601745882 = 2804625001434 := by decide
theorem cert_e605601745882 : check e605601745882 [[],[]] .chain = true := by decide
def e605601746158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605601746158 : Closed e605601746158 ∧ code e605601746158 = 2804625001710 := by decide
theorem cert_e605601746158 : check e605601746158 [[],[]] .chain = true := by decide
def e605601746166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605601746166 : Closed e605601746166 ∧ code e605601746166 = 2804625001718 := by decide
theorem cert_e605601746166 : check e605601746166 [[],[]] .chain = true := by decide
def e605601746542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605601746542 : Closed e605601746542 ∧ code e605601746542 = 2804625002094 := by decide
theorem cert_e605601746542 : check e605601746542 [[],[]] .chain = true := by decide
def e605601746554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605601746554 : Closed e605601746554 ∧ code e605601746554 = 2804625002106 := by decide
theorem cert_e605601746554 : check e605601746554 [[],[]] .chain = true := by decide
def e605601746742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605601746742 : Closed e605601746742 ∧ code e605601746742 = 2804625002294 := by decide
theorem cert_e605601746742 : check e605601746742 [[],[]] .chain = true := by decide
def e605601746746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605601746746 : Closed e605601746746 ∧ code e605601746746 = 2804625002298 := by decide
theorem cert_e605601746746 : check e605601746746 [[],[]] .chain = true := by decide
def e605601751518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e605601751518 : Closed e605601751518 ∧ code e605601751518 = 2804625007070 := by decide
theorem cert_e605601751518 : check e605601751518 [[],[]] .chain = true := by decide
def e605601751542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e605601751542 : Closed e605601751542 ∧ code e605601751542 = 2804625007094 := by decide
theorem cert_e605601751542 : check e605601751542 [[],[]] .chain = true := by decide
def e605601752494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e605601752494 : Closed e605601752494 ∧ code e605601752494 = 2804625008046 := by decide
theorem cert_e605601752494 : check e605601752494 [[],[]] .chain = true := by decide
def e605601752506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e605601752506 : Closed e605601752506 ∧ code e605601752506 = 2804625008058 := by decide
theorem cert_e605601752506 : check e605601752506 [[],[]] .chain = true := by decide
def e605601752554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e605601752554 : Closed e605601752554 ∧ code e605601752554 = 2804625008106 := by decide
theorem cert_e605601752554 : check e605601752554 [[],[]] .chain = true := by decide
def e605601752686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e605601752686 : Closed e605601752686 ∧ code e605601752686 = 2804625008238 := by decide
theorem cert_e605601752686 : check e605601752686 [[],[]] .chain = true := by decide
def e605601752698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e605601752698 : Closed e605601752698 ∧ code e605601752698 = 2804625008250 := by decide
theorem cert_e605601752698 : check e605601752698 [[],[]] .chain = true := by decide
def e605601752862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e605601752862 : Closed e605601752862 ∧ code e605601752862 = 2804625008414 := by decide
theorem cert_e605601752862 : check e605601752862 [[],[]] .chain = true := by decide
def e605601752962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e605601752962 : Closed e605601752962 ∧ code e605601752962 = 2804625008514 := by decide
theorem cert_e605601752962 : check e605601752962 [[],[]] .chain = true := by decide
def e605601752974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e605601752974 : Closed e605601752974 ∧ code e605601752974 = 2804625008526 := by decide
theorem cert_e605601752974 : check e605601752974 [[],[]] .chain = true := by decide
def e605601752986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e605601752986 : Closed e605601752986 ∧ code e605601752986 = 2804625008538 := by decide
theorem cert_e605601752986 : check e605601752986 [[],[]] .chain = true := by decide
def e605601755374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e605601755374 : Closed e605601755374 ∧ code e605601755374 = 2804625010926 := by decide
theorem cert_e605601755374 : check e605601755374 [[],[]] .chain = true := by decide
def e605601755382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e605601755382 : Closed e605601755382 ∧ code e605601755382 = 2804625010934 := by decide
theorem cert_e605601755382 : check e605601755382 [[],[]] .chain = true := by decide
def e605601755862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e605601755862 : Closed e605601755862 ∧ code e605601755862 = 2804625011414 := by decide
theorem cert_e605601755862 : check e605601755862 [[],[]] .chain = true := by decide
def e605601755866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e605601755866 : Closed e605601755866 ∧ code e605601755866 = 2804625011418 := by decide
theorem cert_e605601755866 : check e605601755866 [[],[]] .chain = true := by decide
def e605601755882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e605601755882 : Closed e605601755882 ∧ code e605601755882 = 2804625011434 := by decide
theorem cert_e605601755882 : check e605601755882 [[],[]] .chain = true := by decide
def e605601755958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e605601755958 : Closed e605601755958 ∧ code e605601755958 = 2804625011510 := by decide
theorem cert_e605601755958 : check e605601755958 [[],[]] .chain = true := by decide
def e605601755962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e605601755962 : Closed e605601755962 ∧ code e605601755962 = 2804625011514 := by decide
theorem cert_e605601755962 : check e605601755962 [[],[]] .chain = true := by decide
def e605601756034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e605601756034 : Closed e605601756034 ∧ code e605601756034 = 2804625011586 := by decide
theorem cert_e605601756034 : check e605601756034 [[],[]] .chain = true := by decide
def e605601756046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e605601756046 : Closed e605601756046 ∧ code e605601756046 = 2804625011598 := by decide
theorem cert_e605601756046 : check e605601756046 [[],[]] .chain = true := by decide
def e605601756058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e605601756058 : Closed e605601756058 ∧ code e605601756058 = 2804625011610 := by decide
theorem cert_e605601756058 : check e605601756058 [[],[]] .chain = true := by decide
def e605601759662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e605601759662 : Closed e605601759662 ∧ code e605601759662 = 2804625015214 := by decide
theorem cert_e605601759662 : check e605601759662 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e605601759854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605601759854 : Closed e605601759854 ∧ code e605601759854 = 2804625015406 := by decide
theorem cert_e605601759854 : check e605601759854 [[],[]] .chain = true := by decide
def e605601759866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605601759866 : Closed e605601759866 ∧ code e605601759866 = 2804625015418 := by decide
theorem cert_e605601759866 : check e605601759866 [[],[]] .chain = true := by decide
def e605601760238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.var 2))))))
theorem wire_e605601760238 : Closed e605601760238 ∧ code e605601760238 = 2804625015790 := by decide
theorem cert_e605601760238 : check e605601760238 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
end Blc.Floor41
