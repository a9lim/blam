import R598354180538Data
namespace Certgen.R598354180538
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl72 : FloorIndex.rangeOK validState 72 12 = true := by decide +kernel
theorem bl84 : FloorIndex.rangeOK validState 84 9 = true := by decide +kernel
end Certgen.R598354180538
