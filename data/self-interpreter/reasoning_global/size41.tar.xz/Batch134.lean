import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605641552814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605641552814 : Closed e605641552814 ∧ code e605641552814 = 2804664808366 := by decide
theorem cert_e605641552814 : check e605641552814 [[],[]] .chain = true := by decide
def e605641552826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605641552826 : Closed e605641552826 ∧ code e605641552826 = 2804664808378 := by decide
theorem cert_e605641552826 : check e605641552826 [[],[]] .chain = true := by decide
def e605641552854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605641552854 : Closed e605641552854 ∧ code e605641552854 = 2804664808406 := by decide
theorem cert_e605641552854 : check e605641552854 [[],[]] .chain = true := by decide
def e605641552858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605641552858 : Closed e605641552858 ∧ code e605641552858 = 2804664808410 := by decide
theorem cert_e605641552858 : check e605641552858 [[],[]] .chain = true := by decide
def e605641553134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605641553134 : Closed e605641553134 ∧ code e605641553134 = 2804664808686 := by decide
theorem cert_e605641553134 : check e605641553134 [[],[]] .chain = true := by decide
def e605641553142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605641553142 : Closed e605641553142 ∧ code e605641553142 = 2804664808694 := by decide
theorem cert_e605641553142 : check e605641553142 [[],[]] .chain = true := by decide
def e605641553518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605641553518 : Closed e605641553518 ∧ code e605641553518 = 2804664809070 := by decide
theorem cert_e605641553518 : check e605641553518 [[],[]] .chain = true := by decide
def e605641553530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605641553530 : Closed e605641553530 ∧ code e605641553530 = 2804664809082 := by decide
theorem cert_e605641553530 : check e605641553530 [[],[]] .chain = true := by decide
def e605641553718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605641553718 : Closed e605641553718 ∧ code e605641553718 = 2804664809270 := by decide
theorem cert_e605641553718 : check e605641553718 [[],[]] .chain = true := by decide
def e605641553722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605641553722 : Closed e605641553722 ∧ code e605641553722 = 2804664809274 := by decide
theorem cert_e605641553722 : check e605641553722 [[],[]] .chain = true := by decide
def e605641553966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605641553966 : Closed e605641553966 ∧ code e605641553966 = 2804664809518 := by decide
theorem cert_e605641553966 : check e605641553966 [[],[]] .chain = true := by decide
def e605641554158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605641554158 : Closed e605641554158 ∧ code e605641554158 = 2804664809710 := by decide
theorem cert_e605641554158 : check e605641554158 [[],[]] .chain = true := by decide
def e605641554166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605641554166 : Closed e605641554166 ∧ code e605641554166 = 2804664809718 := by decide
theorem cert_e605641554166 : check e605641554166 [[],[]] .chain = true := by decide
def e605641554350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605641554350 : Closed e605641554350 ∧ code e605641554350 = 2804664809902 := by decide
theorem cert_e605641554350 : check e605641554350 [[],[]] .chain = true := by decide
def e605641554362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605641554362 : Closed e605641554362 ∧ code e605641554362 = 2804664809914 := by decide
theorem cert_e605641554362 : check e605641554362 [[],[]] .chain = true := by decide
def e605641554410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605641554410 : Closed e605641554410 ∧ code e605641554410 = 2804664809962 := by decide
theorem cert_e605641554410 : check e605641554410 [[],[]] .chain = true := by decide
def e605641554542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605641554542 : Closed e605641554542 ∧ code e605641554542 = 2804664810094 := by decide
theorem cert_e605641554542 : check e605641554542 [[],[]] .chain = true := by decide
def e605641554554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605641554554 : Closed e605641554554 ∧ code e605641554554 = 2804664810106 := by decide
theorem cert_e605641554554 : check e605641554554 [[],[]] .chain = true := by decide
def e605641554718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605641554718 : Closed e605641554718 ∧ code e605641554718 = 2804664810270 := by decide
theorem cert_e605641554718 : check e605641554718 [[],[]] .chain = true := by decide
def e605641554818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e605641554818 : Closed e605641554818 ∧ code e605641554818 = 2804664810370 := by decide
theorem cert_e605641554818 : check e605641554818 [[],[]] .chain = true := by decide
def e605641554830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605641554830 : Closed e605641554830 ∧ code e605641554830 = 2804664810382 := by decide
theorem cert_e605641554830 : check e605641554830 [[],[]] .chain = true := by decide
def e605641554842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605641554842 : Closed e605641554842 ∧ code e605641554842 = 2804664810394 := by decide
theorem cert_e605641554842 : check e605641554842 [[],[]] .chain = true := by decide
def e605641554966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605641554966 : Closed e605641554966 ∧ code e605641554966 = 2804664810518 := by decide
theorem cert_e605641554966 : check e605641554966 [[],[]] .chain = true := by decide
def e605641555062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e605641555062 : Closed e605641555062 ∧ code e605641555062 = 2804664810614 := by decide
theorem cert_e605641555062 : check e605641555062 [[],[]] .chain = true := by decide
def e605641555158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605641555158 : Closed e605641555158 ∧ code e605641555158 = 2804664810710 := by decide
theorem cert_e605641555158 : check e605641555158 [[],[]] .chain = true := by decide
def e605641555162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605641555162 : Closed e605641555162 ∧ code e605641555162 = 2804664810714 := by decide
theorem cert_e605641555162 : check e605641555162 [[],[]] .chain = true := by decide
def e605641555178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605641555178 : Closed e605641555178 ∧ code e605641555178 = 2804664810730 := by decide
theorem cert_e605641555178 : check e605641555178 [[],[]] .chain = true := by decide
def e605641555254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605641555254 : Closed e605641555254 ∧ code e605641555254 = 2804664810806 := by decide
theorem cert_e605641555254 : check e605641555254 [[],[]] .chain = true := by decide
def e605641555258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605641555258 : Closed e605641555258 ∧ code e605641555258 = 2804664810810 := by decide
theorem cert_e605641555258 : check e605641555258 [[],[]] .chain = true := by decide
def e605641555330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e605641555330 : Closed e605641555330 ∧ code e605641555330 = 2804664810882 := by decide
theorem cert_e605641555330 : check e605641555330 [[],[]] .chain = true := by decide
def e605641555342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e605641555342 : Closed e605641555342 ∧ code e605641555342 = 2804664810894 := by decide
theorem cert_e605641555342 : check e605641555342 [[],[]] .chain = true := by decide
def e605641555354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605641555354 : Closed e605641555354 ∧ code e605641555354 = 2804664810906 := by decide
theorem cert_e605641555354 : check e605641555354 [[],[]] .chain = true := by decide
def e605641556958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e605641556958 : Closed e605641556958 ∧ code e605641556958 = 2804664812510 := by decide
theorem cert_e605641556958 : check e605641556958 [[],[]] .chain = true := by decide
def e605641556974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e605641556974 : Closed e605641556974 ∧ code e605641556974 = 2804664812526 := by decide
theorem cert_e605641556974 : check e605641556974 [[],[]] .chain = true := by decide
def e605641558894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605641558894 : Closed e605641558894 ∧ code e605641558894 = 2804664814446 := by decide
theorem cert_e605641558894 : check e605641558894 [[],[]] .chain = true := by decide
def e605641558902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605641558902 : Closed e605641558902 ∧ code e605641558902 = 2804664814454 := by decide
theorem cert_e605641558902 : check e605641558902 [[],[]] .chain = true := by decide
def e605641558958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605641558958 : Closed e605641558958 ∧ code e605641558958 = 2804664814510 := by decide
theorem cert_e605641558958 : check e605641558958 [[],[]] .chain = true := by decide
def e605641558970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605641558970 : Closed e605641558970 ∧ code e605641558970 = 2804664814522 := by decide
theorem cert_e605641558970 : check e605641558970 [[],[]] .chain = true := by decide
def e605641558998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605641558998 : Closed e605641558998 ∧ code e605641558998 = 2804664814550 := by decide
theorem cert_e605641558998 : check e605641558998 [[],[]] .chain = true := by decide
def e605641559002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605641559002 : Closed e605641559002 ∧ code e605641559002 = 2804664814554 := by decide
theorem cert_e605641559002 : check e605641559002 [[],[]] .chain = true := by decide
def e605641559278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605641559278 : Closed e605641559278 ∧ code e605641559278 = 2804664814830 := by decide
theorem cert_e605641559278 : check e605641559278 [[],[]] .chain = true := by decide
def e605641559286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605641559286 : Closed e605641559286 ∧ code e605641559286 = 2804664814838 := by decide
theorem cert_e605641559286 : check e605641559286 [[],[]] .chain = true := by decide
def e605641559662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605641559662 : Closed e605641559662 ∧ code e605641559662 = 2804664815214 := by decide
theorem cert_e605641559662 : check e605641559662 [[],[]] .chain = true := by decide
def e605641559674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605641559674 : Closed e605641559674 ∧ code e605641559674 = 2804664815226 := by decide
theorem cert_e605641559674 : check e605641559674 [[],[]] .chain = true := by decide
def e605641559862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605641559862 : Closed e605641559862 ∧ code e605641559862 = 2804664815414 := by decide
theorem cert_e605641559862 : check e605641559862 [[],[]] .chain = true := by decide
def e605641559866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605641559866 : Closed e605641559866 ∧ code e605641559866 = 2804664815418 := by decide
theorem cert_e605641559866 : check e605641559866 [[],[]] .chain = true := by decide
def e605641564638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605641564638 : Closed e605641564638 ∧ code e605641564638 = 2804664820190 := by decide
theorem cert_e605641564638 : check e605641564638 [[],[]] .chain = true := by decide
def e605641564662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605641564662 : Closed e605641564662 ∧ code e605641564662 = 2804664820214 := by decide
theorem cert_e605641564662 : check e605641564662 [[],[]] .chain = true := by decide
def e605641565614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605641565614 : Closed e605641565614 ∧ code e605641565614 = 2804664821166 := by decide
theorem cert_e605641565614 : check e605641565614 [[],[]] .chain = true := by decide
def e605641565626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605641565626 : Closed e605641565626 ∧ code e605641565626 = 2804664821178 := by decide
theorem cert_e605641565626 : check e605641565626 [[],[]] .chain = true := by decide
def e605641565674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605641565674 : Closed e605641565674 ∧ code e605641565674 = 2804664821226 := by decide
theorem cert_e605641565674 : check e605641565674 [[],[]] .chain = true := by decide
def e605641565806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605641565806 : Closed e605641565806 ∧ code e605641565806 = 2804664821358 := by decide
theorem cert_e605641565806 : check e605641565806 [[],[]] .chain = true := by decide
def e605641565818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605641565818 : Closed e605641565818 ∧ code e605641565818 = 2804664821370 := by decide
theorem cert_e605641565818 : check e605641565818 [[],[]] .chain = true := by decide
def e605641565982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605641565982 : Closed e605641565982 ∧ code e605641565982 = 2804664821534 := by decide
theorem cert_e605641565982 : check e605641565982 [[],[]] .chain = true := by decide
def e605641566082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e605641566082 : Closed e605641566082 ∧ code e605641566082 = 2804664821634 := by decide
theorem cert_e605641566082 : check e605641566082 [[],[]] .chain = true := by decide
def e605641566094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605641566094 : Closed e605641566094 ∧ code e605641566094 = 2804664821646 := by decide
theorem cert_e605641566094 : check e605641566094 [[],[]] .chain = true := by decide
def e605641566106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605641566106 : Closed e605641566106 ∧ code e605641566106 = 2804664821658 := by decide
theorem cert_e605641566106 : check e605641566106 [[],[]] .chain = true := by decide
def e605641568494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605641568494 : Closed e605641568494 ∧ code e605641568494 = 2804664824046 := by decide
theorem cert_e605641568494 : check e605641568494 [[],[]] .chain = true := by decide
def e605641568502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605641568502 : Closed e605641568502 ∧ code e605641568502 = 2804664824054 := by decide
theorem cert_e605641568502 : check e605641568502 [[],[]] .chain = true := by decide
def e605641568982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605641568982 : Closed e605641568982 ∧ code e605641568982 = 2804664824534 := by decide
theorem cert_e605641568982 : check e605641568982 [[],[]] .chain = true := by decide
def e605641568986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605641568986 : Closed e605641568986 ∧ code e605641568986 = 2804664824538 := by decide
theorem cert_e605641568986 : check e605641568986 [[],[]] .chain = true := by decide
def e605641569002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605641569002 : Closed e605641569002 ∧ code e605641569002 = 2804664824554 := by decide
theorem cert_e605641569002 : check e605641569002 [[],[]] .chain = true := by decide
def e605641569078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605641569078 : Closed e605641569078 ∧ code e605641569078 = 2804664824630 := by decide
theorem cert_e605641569078 : check e605641569078 [[],[]] .chain = true := by decide
def e605641569082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605641569082 : Closed e605641569082 ∧ code e605641569082 = 2804664824634 := by decide
theorem cert_e605641569082 : check e605641569082 [[],[]] .chain = true := by decide
def e605641569154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e605641569154 : Closed e605641569154 ∧ code e605641569154 = 2804664824706 := by decide
theorem cert_e605641569154 : check e605641569154 [[],[]] .chain = true := by decide
def e605641569166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e605641569166 : Closed e605641569166 ∧ code e605641569166 = 2804664824718 := by decide
theorem cert_e605641569166 : check e605641569166 [[],[]] .chain = true := by decide
def e605641569178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605641569178 : Closed e605641569178 ∧ code e605641569178 = 2804664824730 := by decide
theorem cert_e605641569178 : check e605641569178 [[],[]] .chain = true := by decide
def e605641639870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e605641639870 : Closed e605641639870 ∧ code e605641639870 = 2804664895422 := by decide
theorem cert_e605641639870 : check e605641639870 [[],[]] .chain = true := by decide
def e605641639918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e605641639918 : Closed e605641639918 ∧ code e605641639918 = 2804664895470 := by decide
theorem cert_e605641639918 : check e605641639918 [[],[]] .chain = true := by decide
def e605641643742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605641643742 : Closed e605641643742 ∧ code e605641643742 = 2804664899294 := by decide
theorem cert_e605641643742 : check e605641643742 [[],[]] .chain = true := by decide
def e605641643766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605641643766 : Closed e605641643766 ∧ code e605641643766 = 2804664899318 := by decide
theorem cert_e605641643766 : check e605641643766 [[],[]] .chain = true := by decide
def e605641643870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605641643870 : Closed e605641643870 ∧ code e605641643870 = 2804664899422 := by decide
theorem cert_e605641643870 : check e605641643870 [[],[]] .chain = true := by decide
def e605641643898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605641643898 : Closed e605641643898 ∧ code e605641643898 = 2804664899450 := by decide
theorem cert_e605641643898 : check e605641643898 [[],[]] .chain = true := by decide
def e605641643990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605641643990 : Closed e605641643990 ∧ code e605641643990 = 2804664899542 := by decide
theorem cert_e605641643990 : check e605641643990 [[],[]] .chain = true := by decide
def e605641643994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605641643994 : Closed e605641643994 ∧ code e605641643994 = 2804664899546 := by decide
theorem cert_e605641643994 : check e605641643994 [[],[]] .chain = true := by decide
def e605641644510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605641644510 : Closed e605641644510 ∧ code e605641644510 = 2804664900062 := by decide
theorem cert_e605641644510 : check e605641644510 [[],[]] .chain = true := by decide
def e605641644534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605641644534 : Closed e605641644534 ∧ code e605641644534 = 2804664900086 := by decide
theorem cert_e605641644534 : check e605641644534 [[],[]] .chain = true := by decide
def e605641645278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605641645278 : Closed e605641645278 ∧ code e605641645278 = 2804664900830 := by decide
theorem cert_e605641645278 : check e605641645278 [[],[]] .chain = true := by decide
def e605641645306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605641645306 : Closed e605641645306 ∧ code e605641645306 = 2804664900858 := by decide
theorem cert_e605641645306 : check e605641645306 [[],[]] .chain = true := by decide
def e605641645878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605641645878 : Closed e605641645878 ∧ code e605641645878 = 2804664901430 := by decide
theorem cert_e605641645878 : check e605641645878 [[],[]] .chain = true := by decide
def e605641645882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605641645882 : Closed e605641645882 ∧ code e605641645882 = 2804664901434 := by decide
theorem cert_e605641645882 : check e605641645882 [[],[]] .chain = true := by decide
def e605641660078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605641660078 : Closed e605641660078 ∧ code e605641660078 = 2804664915630 := by decide
theorem cert_e605641660078 : check e605641660078 [[],[]] .chain = true := by decide
def e605641660090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605641660090 : Closed e605641660090 ∧ code e605641660090 = 2804664915642 := by decide
theorem cert_e605641660090 : check e605641660090 [[],[]] .chain = true := by decide
def e605641660138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605641660138 : Closed e605641660138 ∧ code e605641660138 = 2804664915690 := by decide
theorem cert_e605641660138 : check e605641660138 [[],[]] .chain = true := by decide
def e605641660330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605641660330 : Closed e605641660330 ∧ code e605641660330 = 2804664915882 := by decide
theorem cert_e605641660330 : check e605641660330 [[],[]] .chain = true := by decide
def e605641660462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605641660462 : Closed e605641660462 ∧ code e605641660462 = 2804664916014 := by decide
theorem cert_e605641660462 : check e605641660462 [[],[]] .chain = true := by decide
def e605641660654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605641660654 : Closed e605641660654 ∧ code e605641660654 = 2804664916206 := by decide
theorem cert_e605641660654 : check e605641660654 [[],[]] .chain = true := by decide
def e605641660662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605641660662 : Closed e605641660662 ∧ code e605641660662 = 2804664916214 := by decide
theorem cert_e605641660662 : check e605641660662 [[],[]] .chain = true := by decide
def e605641660846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605641660846 : Closed e605641660846 ∧ code e605641660846 = 2804664916398 := by decide
theorem cert_e605641660846 : check e605641660846 [[],[]] .chain = true := by decide
def e605641660858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605641660858 : Closed e605641660858 ∧ code e605641660858 = 2804664916410 := by decide
theorem cert_e605641660858 : check e605641660858 [[],[]] .chain = true := by decide
def e605641660906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605641660906 : Closed e605641660906 ∧ code e605641660906 = 2804664916458 := by decide
theorem cert_e605641660906 : check e605641660906 [[],[]] .chain = true := by decide
def e605641661038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605641661038 : Closed e605641661038 ∧ code e605641661038 = 2804664916590 := by decide
theorem cert_e605641661038 : check e605641661038 [[],[]] .chain = true := by decide
def e605641661050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605641661050 : Closed e605641661050 ∧ code e605641661050 = 2804664916602 := by decide
theorem cert_e605641661050 : check e605641661050 [[],[]] .chain = true := by decide
def e605641661214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605641661214 : Closed e605641661214 ∧ code e605641661214 = 2804664916766 := by decide
theorem cert_e605641661214 : check e605641661214 [[],[]] .chain = true := by decide
def e605641661314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e605641661314 : Closed e605641661314 ∧ code e605641661314 = 2804664916866 := by decide
theorem cert_e605641661314 : check e605641661314 [[],[]] .chain = true := by decide
def e605641661326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605641661326 : Closed e605641661326 ∧ code e605641661326 = 2804664916878 := by decide
theorem cert_e605641661326 : check e605641661326 [[],[]] .chain = true := by decide
def e605641661338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605641661338 : Closed e605641661338 ∧ code e605641661338 = 2804664916890 := by decide
theorem cert_e605641661338 : check e605641661338 [[],[]] .chain = true := by decide
def e605641661550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605641661550 : Closed e605641661550 ∧ code e605641661550 = 2804664917102 := by decide
theorem cert_e605641661550 : check e605641661550 [[],[]] .chain = true := by decide
def e605641661562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605641661562 : Closed e605641661562 ∧ code e605641661562 = 2804664917114 := by decide
theorem cert_e605641661562 : check e605641661562 [[],[]] .chain = true := by decide
def e605641661726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605641661726 : Closed e605641661726 ∧ code e605641661726 = 2804664917278 := by decide
theorem cert_e605641661726 : check e605641661726 [[],[]] .chain = true := by decide
def e605641661894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605641661894 : Closed e605641661894 ∧ code e605641661894 = 2804664917446 := by decide
theorem cert_e605641661894 : check e605641661894 [[],[]] .chain = true := by decide
def e605641661962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605641661962 : Closed e605641661962 ∧ code e605641661962 = 2804664917514 := by decide
theorem cert_e605641661962 : check e605641661962 [[],[]] .chain = true := by decide
def e605641662006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605641662006 : Closed e605641662006 ∧ code e605641662006 = 2804664917558 := by decide
theorem cert_e605641662006 : check e605641662006 [[],[]] .chain = true := by decide
def e605641662010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605641662010 : Closed e605641662010 ∧ code e605641662010 = 2804664917562 := by decide
theorem cert_e605641662010 : check e605641662010 [[],[]] .chain = true := by decide
def e605641662058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605641662058 : Closed e605641662058 ∧ code e605641662058 = 2804664917610 := by decide
theorem cert_e605641662058 : check e605641662058 [[],[]] .chain = true := by decide
def e605641662082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e605641662082 : Closed e605641662082 ∧ code e605641662082 = 2804664917634 := by decide
theorem cert_e605641662082 : check e605641662082 [[],[]] .chain = true := by decide
def e605641662094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605641662094 : Closed e605641662094 ∧ code e605641662094 = 2804664917646 := by decide
theorem cert_e605641662094 : check e605641662094 [[],[]] .chain = true := by decide
def e605641662106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605641662106 : Closed e605641662106 ∧ code e605641662106 = 2804664917658 := by decide
theorem cert_e605641662106 : check e605641662106 [[],[]] .chain = true := by decide
def e605641662150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605641662150 : Closed e605641662150 ∧ code e605641662150 = 2804664917702 := by decide
theorem cert_e605641662150 : check e605641662150 [[],[]] .chain = true := by decide
def e605641662942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605641662942 : Closed e605641662942 ∧ code e605641662942 = 2804664918494 := by decide
theorem cert_e605641662942 : check e605641662942 [[],[]] .chain = true := by decide
def e605641662966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605641662966 : Closed e605641662966 ∧ code e605641662966 = 2804664918518 := by decide
theorem cert_e605641662966 : check e605641662966 [[],[]] .chain = true := by decide
def e605641663918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605641663918 : Closed e605641663918 ∧ code e605641663918 = 2804664919470 := by decide
theorem cert_e605641663918 : check e605641663918 [[],[]] .chain = true := by decide
def e605641663930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605641663930 : Closed e605641663930 ∧ code e605641663930 = 2804664919482 := by decide
theorem cert_e605641663930 : check e605641663930 [[],[]] .chain = true := by decide
def e605641663978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605641663978 : Closed e605641663978 ∧ code e605641663978 = 2804664919530 := by decide
theorem cert_e605641663978 : check e605641663978 [[],[]] .chain = true := by decide
def e605641664110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605641664110 : Closed e605641664110 ∧ code e605641664110 = 2804664919662 := by decide
theorem cert_e605641664110 : check e605641664110 [[],[]] .chain = true := by decide
def e605641664122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605641664122 : Closed e605641664122 ∧ code e605641664122 = 2804664919674 := by decide
theorem cert_e605641664122 : check e605641664122 [[],[]] .chain = true := by decide
def e605641664286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605641664286 : Closed e605641664286 ∧ code e605641664286 = 2804664919838 := by decide
theorem cert_e605641664286 : check e605641664286 [[],[]] .chain = true := by decide
def e605641664386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e605641664386 : Closed e605641664386 ∧ code e605641664386 = 2804664919938 := by decide
theorem cert_e605641664386 : check e605641664386 [[],[]] .chain = true := by decide
def e605641664398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605641664398 : Closed e605641664398 ∧ code e605641664398 = 2804664919950 := by decide
theorem cert_e605641664398 : check e605641664398 [[],[]] .chain = true := by decide
def e605641664410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605641664410 : Closed e605641664410 ∧ code e605641664410 = 2804664919962 := by decide
theorem cert_e605641664410 : check e605641664410 [[],[]] .chain = true := by decide
def e605641667358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605641667358 : Closed e605641667358 ∧ code e605641667358 = 2804664922910 := by decide
theorem cert_e605641667358 : check e605641667358 [[],[]] .chain = true := by decide
def e605641667526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605641667526 : Closed e605641667526 ∧ code e605641667526 = 2804664923078 := by decide
theorem cert_e605641667526 : check e605641667526 [[],[]] .chain = true := by decide
def e605641668726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605641668726 : Closed e605641668726 ∧ code e605641668726 = 2804664924278 := by decide
theorem cert_e605641668726 : check e605641668726 [[],[]] .chain = true := by decide
def e605641668970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605641668970 : Closed e605641668970 ∧ code e605641668970 = 2804664924522 := by decide
theorem cert_e605641668970 : check e605641668970 [[],[]] .chain = true := by decide
def e605641668994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e605641668994 : Closed e605641668994 ∧ code e605641668994 = 2804664924546 := by decide
theorem cert_e605641668994 : check e605641668994 [[],[]] .chain = true := by decide
def e605641669006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605641669006 : Closed e605641669006 ∧ code e605641669006 = 2804664924558 := by decide
theorem cert_e605641669006 : check e605641669006 [[],[]] .chain = true := by decide
def e605641669018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605641669018 : Closed e605641669018 ∧ code e605641669018 = 2804664924570 := by decide
theorem cert_e605641669018 : check e605641669018 [[],[]] .chain = true := by decide
def e605641669062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605641669062 : Closed e605641669062 ∧ code e605641669062 = 2804664924614 := by decide
theorem cert_e605641669062 : check e605641669062 [[],[]] .chain = true := by decide
def e605641704414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e605641704414 : Closed e605641704414 ∧ code e605641704414 = 2804664959966 := by decide
theorem cert_e605641704414 : check e605641704414 [[],[]] .chain = true := by decide
def e605641704430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e605641704430 : Closed e605641704430 ∧ code e605641704430 = 2804664959982 := by decide
theorem cert_e605641704430 : check e605641704430 [[],[]] .chain = true := by decide
def e605641706350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605641706350 : Closed e605641706350 ∧ code e605641706350 = 2804664961902 := by decide
theorem cert_e605641706350 : check e605641706350 [[],[]] .chain = true := by decide
def e605641706358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605641706358 : Closed e605641706358 ∧ code e605641706358 = 2804664961910 := by decide
theorem cert_e605641706358 : check e605641706358 [[],[]] .chain = true := by decide
def e605641706414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605641706414 : Closed e605641706414 ∧ code e605641706414 = 2804664961966 := by decide
theorem cert_e605641706414 : check e605641706414 [[],[]] .chain = true := by decide
def e605641706426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605641706426 : Closed e605641706426 ∧ code e605641706426 = 2804664961978 := by decide
theorem cert_e605641706426 : check e605641706426 [[],[]] .chain = true := by decide
def e605641706454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605641706454 : Closed e605641706454 ∧ code e605641706454 = 2804664962006 := by decide
theorem cert_e605641706454 : check e605641706454 [[],[]] .chain = true := by decide
def e605641706458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605641706458 : Closed e605641706458 ∧ code e605641706458 = 2804664962010 := by decide
theorem cert_e605641706458 : check e605641706458 [[],[]] .chain = true := by decide
def e605641706734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605641706734 : Closed e605641706734 ∧ code e605641706734 = 2804664962286 := by decide
theorem cert_e605641706734 : check e605641706734 [[],[]] .chain = true := by decide
def e605641706742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605641706742 : Closed e605641706742 ∧ code e605641706742 = 2804664962294 := by decide
theorem cert_e605641706742 : check e605641706742 [[],[]] .chain = true := by decide
def e605641707118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605641707118 : Closed e605641707118 ∧ code e605641707118 = 2804664962670 := by decide
theorem cert_e605641707118 : check e605641707118 [[],[]] .chain = true := by decide
def e605641707130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605641707130 : Closed e605641707130 ∧ code e605641707130 = 2804664962682 := by decide
theorem cert_e605641707130 : check e605641707130 [[],[]] .chain = true := by decide
def e605641707318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605641707318 : Closed e605641707318 ∧ code e605641707318 = 2804664962870 := by decide
theorem cert_e605641707318 : check e605641707318 [[],[]] .chain = true := by decide
def e605641707322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605641707322 : Closed e605641707322 ∧ code e605641707322 = 2804664962874 := by decide
theorem cert_e605641707322 : check e605641707322 [[],[]] .chain = true := by decide
def e605641714518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605641714518 : Closed e605641714518 ∧ code e605641714518 = 2804664970070 := by decide
theorem cert_e605641714518 : check e605641714518 [[],[]] .chain = true := by decide
def e605641714522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605641714522 : Closed e605641714522 ∧ code e605641714522 = 2804664970074 := by decide
theorem cert_e605641714522 : check e605641714522 [[],[]] .chain = true := by decide
def e605641714538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605641714538 : Closed e605641714538 ∧ code e605641714538 = 2804664970090 := by decide
theorem cert_e605641714538 : check e605641714538 [[],[]] .chain = true := by decide
def e605641714602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605641714602 : Closed e605641714602 ∧ code e605641714602 = 2804664970154 := by decide
theorem cert_e605641714602 : check e605641714602 [[],[]] .chain = true := by decide
def e605641714710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605641714710 : Closed e605641714710 ∧ code e605641714710 = 2804664970262 := by decide
theorem cert_e605641714710 : check e605641714710 [[],[]] .chain = true := by decide
def e605641714806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e605641714806 : Closed e605641714806 ∧ code e605641714806 = 2804664970358 := by decide
theorem cert_e605641714806 : check e605641714806 [[],[]] .chain = true := by decide
def e605641714902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605641714902 : Closed e605641714902 ∧ code e605641714902 = 2804664970454 := by decide
theorem cert_e605641714902 : check e605641714902 [[],[]] .chain = true := by decide
def e605641714906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605641714906 : Closed e605641714906 ∧ code e605641714906 = 2804664970458 := by decide
theorem cert_e605641714906 : check e605641714906 [[],[]] .chain = true := by decide
def e605641714922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605641714922 : Closed e605641714922 ∧ code e605641714922 = 2804664970474 := by decide
theorem cert_e605641714922 : check e605641714922 [[],[]] .chain = true := by decide
def e605641714998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605641714998 : Closed e605641714998 ∧ code e605641714998 = 2804664970550 := by decide
theorem cert_e605641714998 : check e605641714998 [[],[]] .chain = true := by decide
def e605641715002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605641715002 : Closed e605641715002 ∧ code e605641715002 = 2804664970554 := by decide
theorem cert_e605641715002 : check e605641715002 [[],[]] .chain = true := by decide
def e605641715074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e605641715074 : Closed e605641715074 ∧ code e605641715074 = 2804664970626 := by decide
theorem cert_e605641715074 : check e605641715074 [[],[]] .chain = true := by decide
def e605641715086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e605641715086 : Closed e605641715086 ∧ code e605641715086 = 2804664970638 := by decide
theorem cert_e605641715086 : check e605641715086 [[],[]] .chain = true := by decide
def e605641715098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605641715098 : Closed e605641715098 ∧ code e605641715098 = 2804664970650 := by decide
theorem cert_e605641715098 : check e605641715098 [[],[]] .chain = true := by decide
def e605641715210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605641715210 : Closed e605641715210 ∧ code e605641715210 = 2804664970762 := by decide
theorem cert_e605641715210 : check e605641715210 [[],[]] .chain = true := by decide
def e605641715254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605641715254 : Closed e605641715254 ∧ code e605641715254 = 2804664970806 := by decide
theorem cert_e605641715254 : check e605641715254 [[],[]] .chain = true := by decide
def e605641715258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605641715258 : Closed e605641715258 ∧ code e605641715258 = 2804664970810 := by decide
theorem cert_e605641715258 : check e605641715258 [[],[]] .chain = true := by decide
def e605641715306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605641715306 : Closed e605641715306 ∧ code e605641715306 = 2804664970858 := by decide
theorem cert_e605641715306 : check e605641715306 [[],[]] .chain = true := by decide
end Blc.Floor41
