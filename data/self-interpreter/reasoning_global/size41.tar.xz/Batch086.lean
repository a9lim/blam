import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605593472954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e605593472954 : Closed e605593472954 ∧ code e605593472954 = 2804616728506 := by decide
theorem cert_e605593472954 : check e605593472954 [[],[]] .smaller = true := by decide
def e605593472986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 4) (.var 1)))) (.var 0)))))))
theorem wire_e605593472986 : Closed e605593472986 ∧ code e605593472986 = 2804616728538 := by decide
theorem cert_e605593472986 : check e605593472986 [[],[]] .three = true := by decide
def e605593473750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605593473750 : Closed e605593473750 ∧ code e605593473750 = 2804616729302 := by decide
theorem cert_e605593473750 : check e605593473750 [[],[]] .smaller = true := by decide
def e605593473754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605593473754 : Closed e605593473754 ∧ code e605593473754 = 2804616729306 := by decide
theorem cert_e605593473754 : check e605593473754 [[],[]] .smaller = true := by decide
def e605593473770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605593473770 : Closed e605593473770 ∧ code e605593473770 = 2804616729322 := by decide
theorem cert_e605593473770 : check e605593473770 [[],[]] .smaller = true := by decide
def e605593473846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593473846 : Closed e605593473846 ∧ code e605593473846 = 2804616729398 := by decide
theorem cert_e605593473846 : check e605593473846 [[],[]] .smaller = true := by decide
def e605593473850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593473850 : Closed e605593473850 ∧ code e605593473850 = 2804616729402 := by decide
theorem cert_e605593473850 : check e605593473850 [[],[]] .smaller = true := by decide
def e605593473946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593473946 : Closed e605593473946 ∧ code e605593473946 = 2804616729498 := by decide
theorem cert_e605593473946 : check e605593473946 [[],[]] .smaller = true := by decide
def e605593475470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605593475470 : Closed e605593475470 ∧ code e605593475470 = 2804616731022 := by decide
theorem cert_e605593475470 : check e605593475470 [[],[]] .smaller = true := by decide
def e605593475526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605593475526 : Closed e605593475526 ∧ code e605593475526 = 2804616731078 := by decide
theorem cert_e605593475526 : check e605593475526 [[],[]] .smaller = true := by decide
def e605593476294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e605593476294 : Closed e605593476294 ∧ code e605593476294 = 2804616731846 := by decide
theorem cert_e605593476294 : check e605593476294 [[],[]] .smaller = true := by decide
def e605593480278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 1)))))))
theorem wire_e605593480278 : Closed e605593480278 ∧ code e605593480278 = 2804616735830 := by decide
theorem cert_e605593480278 : check e605593480278 [[],[]] .smaller = true := by decide
def e605593480282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 0)))))))
theorem wire_e605593480282 : Closed e605593480282 ∧ code e605593480282 = 2804616735834 := by decide
theorem cert_e605593480282 : check e605593480282 [[],[]] .smaller = true := by decide
def e605593480470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605593480470 : Closed e605593480470 ∧ code e605593480470 = 2804616736022 := by decide
theorem cert_e605593480470 : check e605593480470 [[],[]] .smaller = true := by decide
def e605593480542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e605593480542 : Closed e605593480542 ∧ code e605593480542 = 2804616736094 := by decide
theorem cert_e605593480542 : check e605593480542 [[],[]] .three = true := by decide
def e605593480546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e605593480546 : Closed e605593480546 ∧ code e605593480546 = 2804616736098 := by decide
theorem cert_e605593480546 : check e605593480546 [[],[]] .smaller = true := by decide
def e605593480558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e605593480558 : Closed e605593480558 ∧ code e605593480558 = 2804616736110 := by decide
theorem cert_e605593480558 : check e605593480558 [[],[]] .smaller = true := by decide
def e605593480566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e605593480566 : Closed e605593480566 ∧ code e605593480566 = 2804616736118 := by decide
theorem cert_e605593480566 : check e605593480566 [[],[]] .smaller = true := by decide
def e605593480570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e605593480570 : Closed e605593480570 ∧ code e605593480570 = 2804616736122 := by decide
theorem cert_e605593480570 : check e605593480570 [[],[]] .three = true := by decide
def e605593480586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605593480586 : Closed e605593480586 ∧ code e605593480586 = 2804616736138 := by decide
theorem cert_e605593480586 : check e605593480586 [[],[]] .smaller = true := by decide
def e605593480610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605593480610 : Closed e605593480610 ∧ code e605593480610 = 2804616736162 := by decide
theorem cert_e605593480610 : check e605593480610 [[],[]] .smaller = true := by decide
def e605593480622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e605593480622 : Closed e605593480622 ∧ code e605593480622 = 2804616736174 := by decide
theorem cert_e605593480622 : check e605593480622 [[],[]] .smaller = true := by decide
def e605593480630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 1)))))))
theorem wire_e605593480630 : Closed e605593480630 ∧ code e605593480630 = 2804616736182 := by decide
theorem cert_e605593480630 : check e605593480630 [[],[]] .smaller = true := by decide
def e605593480634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e605593480634 : Closed e605593480634 ∧ code e605593480634 = 2804616736186 := by decide
theorem cert_e605593480634 : check e605593480634 [[],[]] .smaller = true := by decide
def e605593480662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e605593480662 : Closed e605593480662 ∧ code e605593480662 = 2804616736214 := by decide
theorem cert_e605593480662 : check e605593480662 [[],[]] .smaller = true := by decide
def e605593480666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e605593480666 : Closed e605593480666 ∧ code e605593480666 = 2804616736218 := by decide
theorem cert_e605593480666 : check e605593480666 [[],[]] .smaller = true := by decide
def e605593480682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e605593480682 : Closed e605593480682 ∧ code e605593480682 = 2804616736234 := by decide
theorem cert_e605593480682 : check e605593480682 [[],[]] .three = true := by decide
def e605593480746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 0)))))))
theorem wire_e605593480746 : Closed e605593480746 ∧ code e605593480746 = 2804616736298 := by decide
theorem cert_e605593480746 : check e605593480746 [[],[]] .smaller = true := by decide
def e605593480842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605593480842 : Closed e605593480842 ∧ code e605593480842 = 2804616736394 := by decide
theorem cert_e605593480842 : check e605593480842 [[],[]] .smaller = true := by decide
def e605593480866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605593480866 : Closed e605593480866 ∧ code e605593480866 = 2804616736418 := by decide
theorem cert_e605593480866 : check e605593480866 [[],[]] .smaller = true := by decide
def e605593480878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e605593480878 : Closed e605593480878 ∧ code e605593480878 = 2804616736430 := by decide
theorem cert_e605593480878 : check e605593480878 [[],[]] .smaller = true := by decide
def e605593480886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e605593480886 : Closed e605593480886 ∧ code e605593480886 = 2804616736438 := by decide
theorem cert_e605593480886 : check e605593480886 [[],[]] .smaller = true := by decide
def e605593480890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e605593480890 : Closed e605593480890 ∧ code e605593480890 = 2804616736442 := by decide
theorem cert_e605593480890 : check e605593480890 [[],[]] .smaller = true := by decide
def e605593480918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e605593480918 : Closed e605593480918 ∧ code e605593480918 = 2804616736470 := by decide
theorem cert_e605593480918 : check e605593480918 [[],[]] .smaller = true := by decide
def e605593480922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e605593480922 : Closed e605593480922 ∧ code e605593480922 = 2804616736474 := by decide
theorem cert_e605593480922 : check e605593480922 [[],[]] .smaller = true := by decide
def e605593480938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e605593480938 : Closed e605593480938 ∧ code e605593480938 = 2804616736490 := by decide
theorem cert_e605593480938 : check e605593480938 [[],[]] .smaller = true := by decide
def e605593481046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e605593481046 : Closed e605593481046 ∧ code e605593481046 = 2804616736598 := by decide
theorem cert_e605593481046 : check e605593481046 [[],[]] .smaller = true := by decide
def e605593481050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e605593481050 : Closed e605593481050 ∧ code e605593481050 = 2804616736602 := by decide
theorem cert_e605593481050 : check e605593481050 [[],[]] .smaller = true := by decide
def e605593481066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e605593481066 : Closed e605593481066 ∧ code e605593481066 = 2804616736618 := by decide
theorem cert_e605593481066 : check e605593481066 [[],[]] .smaller = true := by decide
def e605593481130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e605593481130 : Closed e605593481130 ∧ code e605593481130 = 2804616736682 := by decide
theorem cert_e605593481130 : check e605593481130 [[],[]] .three = true := by decide
def e605593481334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 1)))))))
theorem wire_e605593481334 : Closed e605593481334 ∧ code e605593481334 = 2804616736886 := by decide
theorem cert_e605593481334 : check e605593481334 [[],[]] .smaller = true := by decide
def e605593481338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 0)))))))
theorem wire_e605593481338 : Closed e605593481338 ∧ code e605593481338 = 2804616736890 := by decide
theorem cert_e605593481338 : check e605593481338 [[],[]] .smaller = true := by decide
def e605593481430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e605593481430 : Closed e605593481430 ∧ code e605593481430 = 2804616736982 := by decide
theorem cert_e605593481430 : check e605593481430 [[],[]] .smaller = true := by decide
def e605593481526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593481526 : Closed e605593481526 ∧ code e605593481526 = 2804616737078 := by decide
theorem cert_e605593481526 : check e605593481526 [[],[]] .smaller = true := by decide
def e605593481530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593481530 : Closed e605593481530 ∧ code e605593481530 = 2804616737082 := by decide
theorem cert_e605593481530 : check e605593481530 [[],[]] .smaller = true := by decide
def e605593481614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 2))))))))
theorem wire_e605593481614 : Closed e605593481614 ∧ code e605593481614 = 2804616737166 := by decide
theorem cert_e605593481614 : check e605593481614 [[],[]] .smaller = true := by decide
def e605593481670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 1))))))))
theorem wire_e605593481670 : Closed e605593481670 ∧ code e605593481670 = 2804616737222 := by decide
theorem cert_e605593481670 : check e605593481670 [[],[]] .smaller = true := by decide
def e605593482006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e605593482006 : Closed e605593482006 ∧ code e605593482006 = 2804616737558 := by decide
theorem cert_e605593482006 : check e605593482006 [[],[]] .smaller = true := by decide
def e605593482078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e605593482078 : Closed e605593482078 ∧ code e605593482078 = 2804616737630 := by decide
theorem cert_e605593482078 : check e605593482078 [[],[]] .three = true := by decide
def e605593482082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e605593482082 : Closed e605593482082 ∧ code e605593482082 = 2804616737634 := by decide
theorem cert_e605593482082 : check e605593482082 [[],[]] .smaller = true := by decide
def e605593482094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e605593482094 : Closed e605593482094 ∧ code e605593482094 = 2804616737646 := by decide
theorem cert_e605593482094 : check e605593482094 [[],[]] .smaller = true := by decide
def e605593482102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e605593482102 : Closed e605593482102 ∧ code e605593482102 = 2804616737654 := by decide
theorem cert_e605593482102 : check e605593482102 [[],[]] .smaller = true := by decide
def e605593482106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e605593482106 : Closed e605593482106 ∧ code e605593482106 = 2804616737658 := by decide
theorem cert_e605593482106 : check e605593482106 [[],[]] .three = true := by decide
def e605593482122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605593482122 : Closed e605593482122 ∧ code e605593482122 = 2804616737674 := by decide
theorem cert_e605593482122 : check e605593482122 [[],[]] .smaller = true := by decide
def e605593482146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e605593482146 : Closed e605593482146 ∧ code e605593482146 = 2804616737698 := by decide
theorem cert_e605593482146 : check e605593482146 [[],[]] .smaller = true := by decide
def e605593482158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e605593482158 : Closed e605593482158 ∧ code e605593482158 = 2804616737710 := by decide
theorem cert_e605593482158 : check e605593482158 [[],[]] .smaller = true := by decide
def e605593482166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e605593482166 : Closed e605593482166 ∧ code e605593482166 = 2804616737718 := by decide
theorem cert_e605593482166 : check e605593482166 [[],[]] .smaller = true := by decide
def e605593482170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e605593482170 : Closed e605593482170 ∧ code e605593482170 = 2804616737722 := by decide
theorem cert_e605593482170 : check e605593482170 [[],[]] .smaller = true := by decide
def e605593482198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e605593482198 : Closed e605593482198 ∧ code e605593482198 = 2804616737750 := by decide
theorem cert_e605593482198 : check e605593482198 [[],[]] .smaller = true := by decide
def e605593482202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e605593482202 : Closed e605593482202 ∧ code e605593482202 = 2804616737754 := by decide
theorem cert_e605593482202 : check e605593482202 [[],[]] .smaller = true := by decide
def e605593482218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e605593482218 : Closed e605593482218 ∧ code e605593482218 = 2804616737770 := by decide
theorem cert_e605593482218 : check e605593482218 [[],[]] .three = true := by decide
def e605593482270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 3)))))))))
theorem wire_e605593482270 : Closed e605593482270 ∧ code e605593482270 = 2804616737822 := by decide
theorem cert_e605593482270 : check e605593482270 [[],[]] .smaller = true := by decide
def e605593482462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e605593482462 : Closed e605593482462 ∧ code e605593482462 = 2804616738014 := by decide
theorem cert_e605593482462 : check e605593482462 [[],[]] .three = true := by decide
def e605593482466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e605593482466 : Closed e605593482466 ∧ code e605593482466 = 2804616738018 := by decide
theorem cert_e605593482466 : check e605593482466 [[],[]] .smaller = true := by decide
def e605593482478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e605593482478 : Closed e605593482478 ∧ code e605593482478 = 2804616738030 := by decide
theorem cert_e605593482478 : check e605593482478 [[],[]] .smaller = true := by decide
def e605593482486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e605593482486 : Closed e605593482486 ∧ code e605593482486 = 2804616738038 := by decide
theorem cert_e605593482486 : check e605593482486 [[],[]] .smaller = true := by decide
def e605593482490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e605593482490 : Closed e605593482490 ∧ code e605593482490 = 2804616738042 := by decide
theorem cert_e605593482490 : check e605593482490 [[],[]] .three = true := by decide
def e605593482766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 2)))))))))
theorem wire_e605593482766 : Closed e605593482766 ∧ code e605593482766 = 2804616738318 := by decide
theorem cert_e605593482766 : check e605593482766 [[],[]] .smaller = true := by decide
def e605593482778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605593482778 : Closed e605593482778 ∧ code e605593482778 = 2804616738330 := by decide
theorem cert_e605593482778 : check e605593482778 [[],[]] .smaller = true := by decide
def e605593482850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605593482850 : Closed e605593482850 ∧ code e605593482850 = 2804616738402 := by decide
theorem cert_e605593482850 : check e605593482850 [[],[]] .smaller = true := by decide
def e605593482862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593482862 : Closed e605593482862 ∧ code e605593482862 = 2804616738414 := by decide
theorem cert_e605593482862 : check e605593482862 [[],[]] .smaller = true := by decide
def e605593482870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e605593482870 : Closed e605593482870 ∧ code e605593482870 = 2804616738422 := by decide
theorem cert_e605593482870 : check e605593482870 [[],[]] .smaller = true := by decide
def e605593482874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593482874 : Closed e605593482874 ∧ code e605593482874 = 2804616738426 := by decide
theorem cert_e605593482874 : check e605593482874 [[],[]] .smaller = true := by decide
def e605593483062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593483062 : Closed e605593483062 ∧ code e605593483062 = 2804616738614 := by decide
theorem cert_e605593483062 : check e605593483062 [[],[]] .smaller = true := by decide
def e605593483066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593483066 : Closed e605593483066 ∧ code e605593483066 = 2804616738618 := by decide
theorem cert_e605593483066 : check e605593483066 [[],[]] .smaller = true := by decide
def e605593483162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593483162 : Closed e605593483162 ∧ code e605593483162 = 2804616738714 := by decide
theorem cert_e605593483162 : check e605593483162 [[],[]] .three = true := by decide
def e605593483322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 0)))))))
theorem wire_e605593483322 : Closed e605593483322 ∧ code e605593483322 = 2804616738874 := by decide
theorem cert_e605593483322 : check e605593483322 [[],[]] .smaller = true := by decide
def e605593483370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e605593483370 : Closed e605593483370 ∧ code e605593483370 = 2804616738922 := by decide
theorem cert_e605593483370 : check e605593483370 [[],[]] .smaller = true := by decide
def e605593483418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593483418 : Closed e605593483418 ∧ code e605593483418 = 2804616738970 := by decide
theorem cert_e605593483418 : check e605593483418 [[],[]] .smaller = true := by decide
def e605593483462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 1))))))))
theorem wire_e605593483462 : Closed e605593483462 ∧ code e605593483462 = 2804616739014 := by decide
theorem cert_e605593483462 : check e605593483462 [[],[]] .smaller = true := by decide
def e605593483658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605593483658 : Closed e605593483658 ∧ code e605593483658 = 2804616739210 := by decide
theorem cert_e605593483658 : check e605593483658 [[],[]] .smaller = true := by decide
def e605593483682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e605593483682 : Closed e605593483682 ∧ code e605593483682 = 2804616739234 := by decide
theorem cert_e605593483682 : check e605593483682 [[],[]] .smaller = true := by decide
def e605593483694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e605593483694 : Closed e605593483694 ∧ code e605593483694 = 2804616739246 := by decide
theorem cert_e605593483694 : check e605593483694 [[],[]] .smaller = true := by decide
def e605593483702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e605593483702 : Closed e605593483702 ∧ code e605593483702 = 2804616739254 := by decide
theorem cert_e605593483702 : check e605593483702 [[],[]] .smaller = true := by decide
def e605593483706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605593483706 : Closed e605593483706 ∧ code e605593483706 = 2804616739258 := by decide
theorem cert_e605593483706 : check e605593483706 [[],[]] .smaller = true := by decide
def e605593483734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e605593483734 : Closed e605593483734 ∧ code e605593483734 = 2804616739286 := by decide
theorem cert_e605593483734 : check e605593483734 [[],[]] .smaller = true := by decide
def e605593483738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e605593483738 : Closed e605593483738 ∧ code e605593483738 = 2804616739290 := by decide
theorem cert_e605593483738 : check e605593483738 [[],[]] .smaller = true := by decide
def e605593483754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605593483754 : Closed e605593483754 ∧ code e605593483754 = 2804616739306 := by decide
theorem cert_e605593483754 : check e605593483754 [[],[]] .smaller = true := by decide
def e605593483790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 2)))))))))
theorem wire_e605593483790 : Closed e605593483790 ∧ code e605593483790 = 2804616739342 := by decide
theorem cert_e605593483790 : check e605593483790 [[],[]] .smaller = true := by decide
def e605593483802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605593483802 : Closed e605593483802 ∧ code e605593483802 = 2804616739354 := by decide
theorem cert_e605593483802 : check e605593483802 [[],[]] .smaller = true := by decide
def e605593483874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605593483874 : Closed e605593483874 ∧ code e605593483874 = 2804616739426 := by decide
theorem cert_e605593483874 : check e605593483874 [[],[]] .smaller = true := by decide
def e605593483886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593483886 : Closed e605593483886 ∧ code e605593483886 = 2804616739438 := by decide
theorem cert_e605593483886 : check e605593483886 [[],[]] .smaller = true := by decide
def e605593483894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e605593483894 : Closed e605593483894 ∧ code e605593483894 = 2804616739446 := by decide
theorem cert_e605593483894 : check e605593483894 [[],[]] .smaller = true := by decide
def e605593483898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593483898 : Closed e605593483898 ∧ code e605593483898 = 2804616739450 := by decide
theorem cert_e605593483898 : check e605593483898 [[],[]] .smaller = true := by decide
def e605593484086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593484086 : Closed e605593484086 ∧ code e605593484086 = 2804616739638 := by decide
theorem cert_e605593484086 : check e605593484086 [[],[]] .smaller = true := by decide
def e605593484090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593484090 : Closed e605593484090 ∧ code e605593484090 = 2804616739642 := by decide
theorem cert_e605593484090 : check e605593484090 [[],[]] .smaller = true := by decide
def e605593484186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593484186 : Closed e605593484186 ∧ code e605593484186 = 2804616739738 := by decide
theorem cert_e605593484186 : check e605593484186 [[],[]] .smaller = true := by decide
def e605593484254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 3)))))))
theorem wire_e605593484254 : Closed e605593484254 ∧ code e605593484254 = 2804616739806 := by decide
theorem cert_e605593484254 : check e605593484254 [[],[]] .three = true := by decide
def e605593484502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e605593484502 : Closed e605593484502 ∧ code e605593484502 = 2804616740054 := by decide
theorem cert_e605593484502 : check e605593484502 [[],[]] .smaller = true := by decide
def e605593484506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e605593484506 : Closed e605593484506 ∧ code e605593484506 = 2804616740058 := by decide
theorem cert_e605593484506 : check e605593484506 [[],[]] .smaller = true := by decide
def e605593484522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e605593484522 : Closed e605593484522 ∧ code e605593484522 = 2804616740074 := by decide
theorem cert_e605593484522 : check e605593484522 [[],[]] .smaller = true := by decide
def e605593484598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593484598 : Closed e605593484598 ∧ code e605593484598 = 2804616740150 := by decide
theorem cert_e605593484598 : check e605593484598 [[],[]] .smaller = true := by decide
def e605593484602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593484602 : Closed e605593484602 ∧ code e605593484602 = 2804616740154 := by decide
theorem cert_e605593484602 : check e605593484602 [[],[]] .smaller = true := by decide
def e605593484698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593484698 : Closed e605593484698 ∧ code e605593484698 = 2804616740250 := by decide
theorem cert_e605593484698 : check e605593484698 [[],[]] .smaller = true := by decide
def e605593484906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e605593484906 : Closed e605593484906 ∧ code e605593484906 = 2804616740458 := by decide
theorem cert_e605593484906 : check e605593484906 [[],[]] .three = true := by decide
def e605593484954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593484954 : Closed e605593484954 ∧ code e605593484954 = 2804616740506 := by decide
theorem cert_e605593484954 : check e605593484954 [[],[]] .three = true := by decide
def e605593485022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 3)))))))
theorem wire_e605593485022 : Closed e605593485022 ∧ code e605593485022 = 2804616740574 := by decide
theorem cert_e605593485022 : check e605593485022 [[],[]] .three = true := by decide
def e605593485046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 3))) (.var 1)))))))
theorem wire_e605593485046 : Closed e605593485046 ∧ code e605593485046 = 2804616740598 := by decide
theorem cert_e605593485046 : check e605593485046 [[],[]] .three = true := by decide
def e605593486270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 4)))))))))
theorem wire_e605593486270 : Closed e605593486270 ∧ code e605593486270 = 2804616741822 := by decide
theorem cert_e605593486270 : check e605593486270 [[],[]] .three = true := by decide
def e605593486302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e605593486302 : Closed e605593486302 ∧ code e605593486302 = 2804616741854 := by decide
theorem cert_e605593486302 : check e605593486302 [[],[]] .smaller = true := by decide
def e605593486318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e605593486318 : Closed e605593486318 ∧ code e605593486318 = 2804616741870 := by decide
theorem cert_e605593486318 : check e605593486318 [[],[]] .smaller = true := by decide
def e605593486326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 4) (.var 1)))))))))
theorem wire_e605593486326 : Closed e605593486326 ∧ code e605593486326 = 2804616741878 := by decide
theorem cert_e605593486326 : check e605593486326 [[],[]] .three = true := by decide
def e605593488150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e605593488150 : Closed e605593488150 ∧ code e605593488150 = 2804616743702 := by decide
theorem cert_e605593488150 : check e605593488150 [[],[]] .smaller = true := by decide
def e605593488222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e605593488222 : Closed e605593488222 ∧ code e605593488222 = 2804616743774 := by decide
theorem cert_e605593488222 : check e605593488222 [[],[]] .three = true := by decide
def e605593488226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e605593488226 : Closed e605593488226 ∧ code e605593488226 = 2804616743778 := by decide
theorem cert_e605593488226 : check e605593488226 [[],[]] .smaller = true := by decide
def e605593488238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605593488238 : Closed e605593488238 ∧ code e605593488238 = 2804616743790 := by decide
theorem cert_e605593488238 : check e605593488238 [[],[]] .smaller = true := by decide
def e605593488246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605593488246 : Closed e605593488246 ∧ code e605593488246 = 2804616743798 := by decide
theorem cert_e605593488246 : check e605593488246 [[],[]] .smaller = true := by decide
def e605593488250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e605593488250 : Closed e605593488250 ∧ code e605593488250 = 2804616743802 := by decide
theorem cert_e605593488250 : check e605593488250 [[],[]] .three = true := by decide
def e605593488266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605593488266 : Closed e605593488266 ∧ code e605593488266 = 2804616743818 := by decide
theorem cert_e605593488266 : check e605593488266 [[],[]] .smaller = true := by decide
def e605593488290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605593488290 : Closed e605593488290 ∧ code e605593488290 = 2804616743842 := by decide
theorem cert_e605593488290 : check e605593488290 [[],[]] .smaller = true := by decide
def e605593488302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605593488302 : Closed e605593488302 ∧ code e605593488302 = 2804616743854 := by decide
theorem cert_e605593488302 : check e605593488302 [[],[]] .smaller = true := by decide
def e605593488310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e605593488310 : Closed e605593488310 ∧ code e605593488310 = 2804616743862 := by decide
theorem cert_e605593488310 : check e605593488310 [[],[]] .smaller = true := by decide
def e605593488314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605593488314 : Closed e605593488314 ∧ code e605593488314 = 2804616743866 := by decide
theorem cert_e605593488314 : check e605593488314 [[],[]] .smaller = true := by decide
def e605593488342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605593488342 : Closed e605593488342 ∧ code e605593488342 = 2804616743894 := by decide
theorem cert_e605593488342 : check e605593488342 [[],[]] .smaller = true := by decide
def e605593488346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605593488346 : Closed e605593488346 ∧ code e605593488346 = 2804616743898 := by decide
theorem cert_e605593488346 : check e605593488346 [[],[]] .smaller = true := by decide
def e605593488362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e605593488362 : Closed e605593488362 ∧ code e605593488362 = 2804616743914 := by decide
theorem cert_e605593488362 : check e605593488362 [[],[]] .three = true := by decide
def e605593488414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e605593488414 : Closed e605593488414 ∧ code e605593488414 = 2804616743966 := by decide
theorem cert_e605593488414 : check e605593488414 [[],[]] .smaller = true := by decide
def e605593488606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e605593488606 : Closed e605593488606 ∧ code e605593488606 = 2804616744158 := by decide
theorem cert_e605593488606 : check e605593488606 [[],[]] .three = true := by decide
def e605593488610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e605593488610 : Closed e605593488610 ∧ code e605593488610 = 2804616744162 := by decide
theorem cert_e605593488610 : check e605593488610 [[],[]] .smaller = true := by decide
def e605593488622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605593488622 : Closed e605593488622 ∧ code e605593488622 = 2804616744174 := by decide
theorem cert_e605593488622 : check e605593488622 [[],[]] .smaller = true := by decide
def e605593488630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605593488630 : Closed e605593488630 ∧ code e605593488630 = 2804616744182 := by decide
theorem cert_e605593488630 : check e605593488630 [[],[]] .smaller = true := by decide
def e605593488634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e605593488634 : Closed e605593488634 ∧ code e605593488634 = 2804616744186 := by decide
theorem cert_e605593488634 : check e605593488634 [[],[]] .three = true := by decide
def e605593488910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e605593488910 : Closed e605593488910 ∧ code e605593488910 = 2804616744462 := by decide
theorem cert_e605593488910 : check e605593488910 [[],[]] .smaller = true := by decide
def e605593488922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605593488922 : Closed e605593488922 ∧ code e605593488922 = 2804616744474 := by decide
theorem cert_e605593488922 : check e605593488922 [[],[]] .smaller = true := by decide
def e605593488994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605593488994 : Closed e605593488994 ∧ code e605593488994 = 2804616744546 := by decide
theorem cert_e605593488994 : check e605593488994 [[],[]] .smaller = true := by decide
def e605593489006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593489006 : Closed e605593489006 ∧ code e605593489006 = 2804616744558 := by decide
theorem cert_e605593489006 : check e605593489006 [[],[]] .smaller = true := by decide
def e605593489014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e605593489014 : Closed e605593489014 ∧ code e605593489014 = 2804616744566 := by decide
theorem cert_e605593489014 : check e605593489014 [[],[]] .smaller = true := by decide
def e605593489018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593489018 : Closed e605593489018 ∧ code e605593489018 = 2804616744570 := by decide
theorem cert_e605593489018 : check e605593489018 [[],[]] .smaller = true := by decide
def e605593489206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593489206 : Closed e605593489206 ∧ code e605593489206 = 2804616744758 := by decide
theorem cert_e605593489206 : check e605593489206 [[],[]] .smaller = true := by decide
def e605593489210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593489210 : Closed e605593489210 ∧ code e605593489210 = 2804616744762 := by decide
theorem cert_e605593489210 : check e605593489210 [[],[]] .smaller = true := by decide
def e605593489306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593489306 : Closed e605593489306 ∧ code e605593489306 = 2804616744858 := by decide
theorem cert_e605593489306 : check e605593489306 [[],[]] .three = true := by decide
def e605593493982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605593493982 : Closed e605593493982 ∧ code e605593493982 = 2804616749534 := by decide
theorem cert_e605593493982 : check e605593493982 [[],[]] .smaller = true := by decide
def e605593494006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605593494006 : Closed e605593494006 ∧ code e605593494006 = 2804616749558 := by decide
theorem cert_e605593494006 : check e605593494006 [[],[]] .smaller = true := by decide
def e605593494922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605593494922 : Closed e605593494922 ∧ code e605593494922 = 2804616750474 := by decide
theorem cert_e605593494922 : check e605593494922 [[],[]] .smaller = true := by decide
def e605593494946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605593494946 : Closed e605593494946 ∧ code e605593494946 = 2804616750498 := by decide
theorem cert_e605593494946 : check e605593494946 [[],[]] .smaller = true := by decide
def e605593494958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605593494958 : Closed e605593494958 ∧ code e605593494958 = 2804616750510 := by decide
theorem cert_e605593494958 : check e605593494958 [[],[]] .smaller = true := by decide
def e605593494966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e605593494966 : Closed e605593494966 ∧ code e605593494966 = 2804616750518 := by decide
theorem cert_e605593494966 : check e605593494966 [[],[]] .smaller = true := by decide
def e605593494970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605593494970 : Closed e605593494970 ∧ code e605593494970 = 2804616750522 := by decide
theorem cert_e605593494970 : check e605593494970 [[],[]] .smaller = true := by decide
def e605593494998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e605593494998 : Closed e605593494998 ∧ code e605593494998 = 2804616750550 := by decide
theorem cert_e605593494998 : check e605593494998 [[],[]] .smaller = true := by decide
def e605593495002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e605593495002 : Closed e605593495002 ∧ code e605593495002 = 2804616750554 := by decide
theorem cert_e605593495002 : check e605593495002 [[],[]] .smaller = true := by decide
def e605593495018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605593495018 : Closed e605593495018 ∧ code e605593495018 = 2804616750570 := by decide
theorem cert_e605593495018 : check e605593495018 [[],[]] .smaller = true := by decide
def e605593495054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e605593495054 : Closed e605593495054 ∧ code e605593495054 = 2804616750606 := by decide
theorem cert_e605593495054 : check e605593495054 [[],[]] .smaller = true := by decide
def e605593495066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605593495066 : Closed e605593495066 ∧ code e605593495066 = 2804616750618 := by decide
theorem cert_e605593495066 : check e605593495066 [[],[]] .smaller = true := by decide
def e605593495138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605593495138 : Closed e605593495138 ∧ code e605593495138 = 2804616750690 := by decide
theorem cert_e605593495138 : check e605593495138 [[],[]] .smaller = true := by decide
def e605593495150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593495150 : Closed e605593495150 ∧ code e605593495150 = 2804616750702 := by decide
theorem cert_e605593495150 : check e605593495150 [[],[]] .smaller = true := by decide
def e605593495158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e605593495158 : Closed e605593495158 ∧ code e605593495158 = 2804616750710 := by decide
theorem cert_e605593495158 : check e605593495158 [[],[]] .smaller = true := by decide
def e605593495162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593495162 : Closed e605593495162 ∧ code e605593495162 = 2804616750714 := by decide
theorem cert_e605593495162 : check e605593495162 [[],[]] .smaller = true := by decide
def e605593495350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593495350 : Closed e605593495350 ∧ code e605593495350 = 2804616750902 := by decide
theorem cert_e605593495350 : check e605593495350 [[],[]] .smaller = true := by decide
def e605593495354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593495354 : Closed e605593495354 ∧ code e605593495354 = 2804616750906 := by decide
theorem cert_e605593495354 : check e605593495354 [[],[]] .smaller = true := by decide
def e605593495450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593495450 : Closed e605593495450 ∧ code e605593495450 = 2804616751002 := by decide
theorem cert_e605593495450 : check e605593495450 [[],[]] .smaller = true := by decide
end Blc.Floor41
