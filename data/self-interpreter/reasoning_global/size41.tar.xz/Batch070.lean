import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e604788775710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e604788775710 : Closed e604788775710 ∧ code e604788775710 = 2803812031262 := by decide
theorem cert_e604788775710 : check e604788775710 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604788775822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e604788775822 : Closed e604788775822 ∧ code e604788775822 = 2803812031374 := by decide
private def t_e604788775822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem cert_e604788775822 : ¬ IsSelfInterpreter e604788775822 :=
  wSource (t := t_e604788775822) (replay_sound (ps := []) (t := e604788775822) (by decide)) (by decide)
def e604788776046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e604788776046 : Closed e604788776046 ∧ code e604788776046 = 2803812031598 := by decide
theorem cert_e604788776046 : check e604788776046 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e604788776058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e604788776058 : Closed e604788776058 ∧ code e604788776058 = 2803812031610 := by decide
theorem cert_e604788776058 : check e604788776058 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e604788776222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e604788776222 : Closed e604788776222 ∧ code e604788776222 = 2803812031774 := by decide
theorem cert_e604788776222 : check e604788776222 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e604788776390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e604788776390 : Closed e604788776390 ∧ code e604788776390 = 2803812031942 := by decide
theorem cert_e604788776390 : check e604788776390 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e604788776502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e604788776502 : Closed e604788776502 ∧ code e604788776502 = 2803812032054 := by decide
theorem cert_e604788776502 : check e604788776502 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e604788776506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e604788776506 : Closed e604788776506 ∧ code e604788776506 = 2803812032058 := by decide
theorem cert_e604788776506 : check e604788776506 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e604788776590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e604788776590 : Closed e604788776590 ∧ code e604788776590 = 2803812032142 := by decide
private def t_e604788776590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem cert_e604788776590 : ¬ IsSelfInterpreter e604788776590 :=
  wSource (t := t_e604788776590) (replay_sound (ps := []) (t := e604788776590) (by decide)) (by decide)
def e604788776646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e604788776646 : Closed e604788776646 ∧ code e604788776646 = 2803812032198 := by decide
theorem cert_e604788776646 : check e604788776646 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e604788778782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e604788778782 : Closed e604788778782 ∧ code e604788778782 = 2803812034334 := by decide
theorem cert_e604788778782 : check e604788778782 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e604788778894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e604788778894 : Closed e604788778894 ∧ code e604788778894 = 2803812034446 := by decide
theorem cert_e604788778894 : check e604788778894 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e604788781854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e604788781854 : Closed e604788781854 ∧ code e604788781854 = 2803812037406 := by decide
theorem cert_e604788781854 : check e604788781854 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e604788782022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e604788782022 : Closed e604788782022 ∧ code e604788782022 = 2803812037574 := by decide
theorem cert_e604788782022 : check e604788782022 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e604788783502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e604788783502 : Closed e604788783502 ∧ code e604788783502 = 2803812039054 := by decide
theorem cert_e604788783502 : check e604788783502 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e604788783558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e604788783558 : Closed e604788783558 ∧ code e604788783558 = 2803812039110 := by decide
theorem cert_e604788783558 : check e604788783558 [[],[],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e604796628410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))
theorem wire_e604796628410 : Closed e604796628410 ∧ code e604796628410 = 2803819883962 := by decide
def e604796628442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))
theorem wire_e604796628442 : Closed e604796628442 ∧ code e604796628442 = 2803819883994 := by decide
def e604796628666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))
theorem wire_e604796628666 : Closed e604796628666 ∧ code e604796628666 = 2803819884218 := by decide
def e604796628714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem wire_e604796628714 : Closed e604796628714 ∧ code e604796628714 = 2803819884266 := by decide
private def t_e604796628714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem cert_e604796628714 : ¬ IsSelfInterpreter e604796628714 :=
  wSource (t := t_e604796628714) (replay_sound (ps := []) (t := e604796628714) (by decide)) (by decide)
def e604796628826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))
theorem wire_e604796628826 : Closed e604796628826 ∧ code e604796628826 = 2803819884378 := by decide
def e604796628842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem wire_e604796628842 : Closed e604796628842 ∧ code e604796628842 = 2803819884394 := by decide
private def t_e604796628842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem cert_e604796628842 : ¬ IsSelfInterpreter e604796628842 :=
  wSource (t := t_e604796628842) (replay_sound (ps := []) (t := e604796628842) (by decide)) (by decide)
def e604796629946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem wire_e604796629946 : Closed e604796629946 ∧ code e604796629946 = 2803819885498 := by decide
def e604796629978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem wire_e604796629978 : Closed e604796629978 ∧ code e604796629978 = 2803819885530 := by decide
def e604796631482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem wire_e604796631482 : Closed e604796631482 ∧ code e604796631482 = 2803819887034 := by decide
def e604796631530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem wire_e604796631530 : Closed e604796631530 ∧ code e604796631530 = 2803819887082 := by decide
def e604796632282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem wire_e604796632282 : Closed e604796632282 ∧ code e604796632282 = 2803819887834 := by decide
def e604796632298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem wire_e604796632298 : Closed e604796632298 ∧ code e604796632298 = 2803819887850 := by decide
def e604796881774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604796881774 : Closed e604796881774 ∧ code e604796881774 = 2803820137326 := by decide
private def t_e604796881774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem cert_e604796881774 : ¬ IsSelfInterpreter e604796881774 :=
  wSource (t := t_e604796881774) (replay_sound (ps := []) (t := e604796881774) (by decide)) (by decide)
def e604796881782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604796881782 : Closed e604796881782 ∧ code e604796881782 = 2803820137334 := by decide
private def t_e604796881782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e604796881782 : ¬ IsSelfInterpreter e604796881782 :=
  wSource (t := t_e604796881782) (replay_sound (ps := []) (t := e604796881782) (by decide)) (by decide)
def e604796881838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604796881838 : Closed e604796881838 ∧ code e604796881838 = 2803820137390 := by decide
private def t_e604796881838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem cert_e604796881838 : ¬ IsSelfInterpreter e604796881838 :=
  wSource (t := t_e604796881838) (replay_sound (ps := []) (t := e604796881838) (by decide)) (by decide)
def e604796881850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604796881850 : Closed e604796881850 ∧ code e604796881850 = 2803820137402 := by decide
private def t_e604796881850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e604796881850 : ¬ IsSelfInterpreter e604796881850 :=
  wSource (t := t_e604796881850) (replay_sound (ps := []) (t := e604796881850) (by decide)) (by decide)
def e604796881878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604796881878 : Closed e604796881878 ∧ code e604796881878 = 2803820137430 := by decide
private def t_e604796881878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e604796881878 : ¬ IsSelfInterpreter e604796881878 :=
  wSource (t := t_e604796881878) (replay_sound (ps := []) (t := e604796881878) (by decide)) (by decide)
def e604796881882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604796881882 : Closed e604796881882 ∧ code e604796881882 = 2803820137434 := by decide
private def t_e604796881882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e604796881882 : ¬ IsSelfInterpreter e604796881882 :=
  wSource (t := t_e604796881882) (replay_sound (ps := []) (t := e604796881882) (by decide)) (by decide)
def e604796882158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604796882158 : Closed e604796882158 ∧ code e604796882158 = 2803820137710 := by decide
private def t_e604796882158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem cert_e604796882158 : ¬ IsSelfInterpreter e604796882158 :=
  wSource (t := t_e604796882158) (replay_sound (ps := []) (t := e604796882158) (by decide)) (by decide)
def e604796882166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604796882166 : Closed e604796882166 ∧ code e604796882166 = 2803820137718 := by decide
private def t_e604796882166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem cert_e604796882166 : ¬ IsSelfInterpreter e604796882166 :=
  wSource (t := t_e604796882166) (replay_sound (ps := []) (t := e604796882166) (by decide)) (by decide)
def e604796882542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604796882542 : Closed e604796882542 ∧ code e604796882542 = 2803820138094 := by decide
private def t_e604796882542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem cert_e604796882542 : ¬ IsSelfInterpreter e604796882542 :=
  wSource (t := t_e604796882542) (replay_sound (ps := []) (t := e604796882542) (by decide)) (by decide)
def e604796882554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604796882554 : Closed e604796882554 ∧ code e604796882554 = 2803820138106 := by decide
private def t_e604796882554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem cert_e604796882554 : ¬ IsSelfInterpreter e604796882554 :=
  wSource (t := t_e604796882554) (replay_sound (ps := []) (t := e604796882554) (by decide)) (by decide)
def e604796882742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604796882742 : Closed e604796882742 ∧ code e604796882742 = 2803820138294 := by decide
private def t_e604796882742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem cert_e604796882742 : ¬ IsSelfInterpreter e604796882742 :=
  wSource (t := t_e604796882742) (replay_sound (ps := []) (t := e604796882742) (by decide)) (by decide)
def e604796882746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604796882746 : Closed e604796882746 ∧ code e604796882746 = 2803820138298 := by decide
private def t_e604796882746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem cert_e604796882746 : ¬ IsSelfInterpreter e604796882746 :=
  wSource (t := t_e604796882746) (replay_sound (ps := []) (t := e604796882746) (by decide)) (by decide)
def e604797677022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e604797677022 : Closed e604797677022 ∧ code e604797677022 = 2803820932574 := by decide
theorem cert_e604797677022 : check e604797677022 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e604797677038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e604797677038 : Closed e604797677038 ∧ code e604797677038 = 2803820932590 := by decide
theorem cert_e604797677038 : check e604797677038 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e604797677406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e604797677406 : Closed e604797677406 ∧ code e604797677406 = 2803820932958 := by decide
theorem cert_e604797677406 : check e604797677406 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e604797677434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e604797677434 : Closed e604797677434 ∧ code e604797677434 = 2803820932986 := by decide
private def t_e604797677434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem cert_e604797677434 : ¬ IsSelfInterpreter e604797677434 :=
  wSource (t := t_e604797677434) (replay_sound (ps := []) (t := e604797677434) (by decide)) (by decide)
def e604797677486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e604797677486 : Closed e604797677486 ∧ code e604797677486 = 2803820933038 := by decide
theorem cert_e604797677486 : check e604797677486 [[],[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e604797677498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e604797677498 : Closed e604797677498 ∧ code e604797677498 = 2803820933050 := by decide
private def t_e604797677498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem cert_e604797677498 : ¬ IsSelfInterpreter e604797677498 :=
  wSource (t := t_e604797677498) (replay_sound (ps := []) (t := e604797677498) (by decide)) (by decide)
def e604797678558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e604797678558 : Closed e604797678558 ∧ code e604797678558 = 2803820934110 := by decide
theorem cert_e604797678558 : check e604797678558 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e604797678574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e604797678574 : Closed e604797678574 ∧ code e604797678574 = 2803820934126 := by decide
theorem cert_e604797678574 : check e604797678574 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e604797680862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e604797680862 : Closed e604797680862 ∧ code e604797680862 = 2803820936414 := by decide
theorem cert_e604797680862 : check e604797680862 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e604797680890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e604797680890 : Closed e604797680890 ∧ code e604797680890 = 2803820936442 := by decide
theorem cert_e604797680890 : check e604797680890 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e604797681262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e604797681262 : Closed e604797681262 ∧ code e604797681262 = 2803820936814 := by decide
theorem cert_e604797681262 : check e604797681262 [[],[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e604797681274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e604797681274 : Closed e604797681274 ∧ code e604797681274 = 2803820936826 := by decide
theorem cert_e604797681274 : check e604797681274 [[],[],[.left],[.left],[.left],[],[.under],[.under,.left],[.under]] .chain = true := by decide
def e604797709678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e604797709678 : Closed e604797709678 ∧ code e604797709678 = 2803820965230 := by decide
def e604797709686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e604797709686 : Closed e604797709686 ∧ code e604797709686 = 2803820965238 := by decide
def e604797709742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e604797709742 : Closed e604797709742 ∧ code e604797709742 = 2803820965294 := by decide
def e604797709754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e604797709754 : Closed e604797709754 ∧ code e604797709754 = 2803820965306 := by decide
def e604797709782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e604797709782 : Closed e604797709782 ∧ code e604797709782 = 2803820965334 := by decide
def e604797709786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e604797709786 : Closed e604797709786 ∧ code e604797709786 = 2803820965338 := by decide
def e604797709998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e604797709998 : Closed e604797709998 ∧ code e604797709998 = 2803820965550 := by decide
def e604797710010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e604797710010 : Closed e604797710010 ∧ code e604797710010 = 2803820965562 := by decide
def e604797710058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e604797710058 : Closed e604797710058 ∧ code e604797710058 = 2803820965610 := by decide
private def t_e604797710058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem cert_e604797710058 : ¬ IsSelfInterpreter e604797710058 :=
  wSource (t := t_e604797710058) (replay_sound (ps := []) (t := e604797710058) (by decide)) (by decide)
def e604797710166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e604797710166 : Closed e604797710166 ∧ code e604797710166 = 2803820965718 := by decide
def e604797710170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e604797710170 : Closed e604797710170 ∧ code e604797710170 = 2803820965722 := by decide
def e604797710186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e604797710186 : Closed e604797710186 ∧ code e604797710186 = 2803820965738 := by decide
private def t_e604797710186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem cert_e604797710186 : ¬ IsSelfInterpreter e604797710186 :=
  wSource (t := t_e604797710186) (replay_sound (ps := []) (t := e604797710186) (by decide)) (by decide)
def e604797711214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e604797711214 : Closed e604797711214 ∧ code e604797711214 = 2803820966766 := by decide
def e604797711222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e604797711222 : Closed e604797711222 ∧ code e604797711222 = 2803820966774 := by decide
def e604797711278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e604797711278 : Closed e604797711278 ∧ code e604797711278 = 2803820966830 := by decide
def e604797711290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e604797711290 : Closed e604797711290 ∧ code e604797711290 = 2803820966842 := by decide
def e604797711318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e604797711318 : Closed e604797711318 ∧ code e604797711318 = 2803820966870 := by decide
def e604797711322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e604797711322 : Closed e604797711322 ∧ code e604797711322 = 2803820966874 := by decide
def e604797711598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e604797711598 : Closed e604797711598 ∧ code e604797711598 = 2803820967150 := by decide
def e604797711606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e604797711606 : Closed e604797711606 ∧ code e604797711606 = 2803820967158 := by decide
def e604797711982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e604797711982 : Closed e604797711982 ∧ code e604797711982 = 2803820967534 := by decide
def e604797711994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e604797711994 : Closed e604797711994 ∧ code e604797711994 = 2803820967546 := by decide
def e604797712182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e604797712182 : Closed e604797712182 ∧ code e604797712182 = 2803820967734 := by decide
def e604797712186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e604797712186 : Closed e604797712186 ∧ code e604797712186 = 2803820967738 := by decide
def e604797712814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e604797712814 : Closed e604797712814 ∧ code e604797712814 = 2803820968366 := by decide
def e604797712826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e604797712826 : Closed e604797712826 ∧ code e604797712826 = 2803820968378 := by decide
def e604797712874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e604797712874 : Closed e604797712874 ∧ code e604797712874 = 2803820968426 := by decide
def e604797713006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e604797713006 : Closed e604797713006 ∧ code e604797713006 = 2803820968558 := by decide
def e604797713018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e604797713018 : Closed e604797713018 ∧ code e604797713018 = 2803820968570 := by decide
def e604797713306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e604797713306 : Closed e604797713306 ∧ code e604797713306 = 2803820968858 := by decide
private def t_e604797713306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem cert_e604797713306 : ¬ IsSelfInterpreter e604797713306 :=
  wSource (t := t_e604797713306) (replay_sound (ps := []) (t := e604797713306) (by decide)) (by decide)
def e604797713622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e604797713622 : Closed e604797713622 ∧ code e604797713622 = 2803820969174 := by decide
def e604797713626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e604797713626 : Closed e604797713626 ∧ code e604797713626 = 2803820969178 := by decide
def e604797713642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e604797713642 : Closed e604797713642 ∧ code e604797713642 = 2803820969194 := by decide
def e604797713718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e604797713718 : Closed e604797713718 ∧ code e604797713718 = 2803820969270 := by decide
def e604797713722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e604797713722 : Closed e604797713722 ∧ code e604797713722 = 2803820969274 := by decide
def e604797713818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e604797713818 : Closed e604797713818 ∧ code e604797713818 = 2803820969370 := by decide
private def t_e604797713818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem cert_e604797713818 : ¬ IsSelfInterpreter e604797713818 :=
  wSource (t := t_e604797713818) (replay_sound (ps := []) (t := e604797713818) (by decide)) (by decide)
def e604797715422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e604797715422 : Closed e604797715422 ∧ code e604797715422 = 2803820970974 := by decide
theorem cert_e604797715422 : check e604797715422 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797715438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e604797715438 : Closed e604797715438 ∧ code e604797715438 = 2803820970990 := by decide
theorem cert_e604797715438 : check e604797715438 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797717358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e604797717358 : Closed e604797717358 ∧ code e604797717358 = 2803820972910 := by decide
theorem cert_e604797717358 : check e604797717358 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797717366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e604797717366 : Closed e604797717366 ∧ code e604797717366 = 2803820972918 := by decide
theorem cert_e604797717366 : check e604797717366 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797717422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e604797717422 : Closed e604797717422 ∧ code e604797717422 = 2803820972974 := by decide
theorem cert_e604797717422 : check e604797717422 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797717434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e604797717434 : Closed e604797717434 ∧ code e604797717434 = 2803820972986 := by decide
theorem cert_e604797717434 : check e604797717434 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797717462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e604797717462 : Closed e604797717462 ∧ code e604797717462 = 2803820973014 := by decide
theorem cert_e604797717462 : check e604797717462 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797717466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e604797717466 : Closed e604797717466 ∧ code e604797717466 = 2803820973018 := by decide
theorem cert_e604797717466 : check e604797717466 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797717742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e604797717742 : Closed e604797717742 ∧ code e604797717742 = 2803820973294 := by decide
theorem cert_e604797717742 : check e604797717742 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797717750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e604797717750 : Closed e604797717750 ∧ code e604797717750 = 2803820973302 := by decide
theorem cert_e604797717750 : check e604797717750 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797718126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e604797718126 : Closed e604797718126 ∧ code e604797718126 = 2803820973678 := by decide
theorem cert_e604797718126 : check e604797718126 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797718138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e604797718138 : Closed e604797718138 ∧ code e604797718138 = 2803820973690 := by decide
theorem cert_e604797718138 : check e604797718138 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797718326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e604797718326 : Closed e604797718326 ∧ code e604797718326 = 2803820973878 := by decide
theorem cert_e604797718326 : check e604797718326 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797718330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e604797718330 : Closed e604797718330 ∧ code e604797718330 = 2803820973882 := by decide
theorem cert_e604797718330 : check e604797718330 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604797723102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e604797723102 : Closed e604797723102 ∧ code e604797723102 = 2803820978654 := by decide
theorem cert_e604797723102 : check e604797723102 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[],[],[],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[]] .identityHead = true := by decide
def e604797723126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e604797723126 : Closed e604797723126 ∧ code e604797723126 = 2803820978678 := by decide
theorem cert_e604797723126 : check e604797723126 [[],[],[.left],[.left],[.left],[],[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e604797724078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e604797724078 : Closed e604797724078 ∧ code e604797724078 = 2803820979630 := by decide
def e604797724090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e604797724090 : Closed e604797724090 ∧ code e604797724090 = 2803820979642 := by decide
def e604797724138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e604797724138 : Closed e604797724138 ∧ code e604797724138 = 2803820979690 := by decide
def e604797724270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e604797724270 : Closed e604797724270 ∧ code e604797724270 = 2803820979822 := by decide
def e604797724282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e604797724282 : Closed e604797724282 ∧ code e604797724282 = 2803820979834 := by decide
theorem cert_e604797724282 : check e604797724282 [[],[],[.left],[.left],[.left],[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e604797724570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e604797724570 : Closed e604797724570 ∧ code e604797724570 = 2803820980122 := by decide
def e604797726958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e604797726958 : Closed e604797726958 ∧ code e604797726958 = 2803820982510 := by decide
theorem cert_e604797726958 : check e604797726958 [[],[],[.left],[.left],[.left],[],[],[],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under],[.under]] .chain = true := by decide
def e604797726966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e604797726966 : Closed e604797726966 ∧ code e604797726966 = 2803820982518 := by decide
theorem cert_e604797726966 : check e604797726966 [[],[],[.left],[.left],[.left],[],[],[],[],[.under],[.under,.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e604797727446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e604797727446 : Closed e604797727446 ∧ code e604797727446 = 2803820982998 := by decide
def e604797727450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e604797727450 : Closed e604797727450 ∧ code e604797727450 = 2803820983002 := by decide
def e604797727466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e604797727466 : Closed e604797727466 ∧ code e604797727466 = 2803820983018 := by decide
def e604797727542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e604797727542 : Closed e604797727542 ∧ code e604797727542 = 2803820983094 := by decide
def e604797727546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e604797727546 : Closed e604797727546 ∧ code e604797727546 = 2803820983098 := by decide
def e604797727642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e604797727642 : Closed e604797727642 ∧ code e604797727642 = 2803820983194 := by decide
def e604797864814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e604797864814 : Closed e604797864814 ∧ code e604797864814 = 2803821120366 := by decide
private def t_e604797864814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e604797864814 : ¬ IsSelfInterpreter e604797864814 :=
  wSource (t := t_e604797864814) (replay_sound (ps := []) (t := e604797864814) (by decide)) (by decide)
def e604797864822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e604797864822 : Closed e604797864822 ∧ code e604797864822 = 2803821120374 := by decide
private def t_e604797864822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e604797864822 : ¬ IsSelfInterpreter e604797864822 :=
  wSource (t := t_e604797864822) (replay_sound (ps := []) (t := e604797864822) (by decide)) (by decide)
def e604797864878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e604797864878 : Closed e604797864878 ∧ code e604797864878 = 2803821120430 := by decide
private def t_e604797864878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e604797864878 : ¬ IsSelfInterpreter e604797864878 :=
  wSource (t := t_e604797864878) (replay_sound (ps := []) (t := e604797864878) (by decide)) (by decide)
def e604797864890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e604797864890 : Closed e604797864890 ∧ code e604797864890 = 2803821120442 := by decide
private def t_e604797864890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e604797864890 : ¬ IsSelfInterpreter e604797864890 :=
  wSource (t := t_e604797864890) (replay_sound (ps := []) (t := e604797864890) (by decide)) (by decide)
def e604797864918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e604797864918 : Closed e604797864918 ∧ code e604797864918 = 2803821120470 := by decide
private def t_e604797864918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e604797864918 : ¬ IsSelfInterpreter e604797864918 :=
  wSource (t := t_e604797864918) (replay_sound (ps := []) (t := e604797864918) (by decide)) (by decide)
def e604797864922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e604797864922 : Closed e604797864922 ∧ code e604797864922 = 2803821120474 := by decide
private def t_e604797864922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e604797864922 : ¬ IsSelfInterpreter e604797864922 :=
  wSource (t := t_e604797864922) (replay_sound (ps := []) (t := e604797864922) (by decide)) (by decide)
def e604797865198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e604797865198 : Closed e604797865198 ∧ code e604797865198 = 2803821120750 := by decide
private def t_e604797865198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e604797865198 : ¬ IsSelfInterpreter e604797865198 :=
  wSource (t := t_e604797865198) (replay_sound (ps := []) (t := e604797865198) (by decide)) (by decide)
def e604797865206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e604797865206 : Closed e604797865206 ∧ code e604797865206 = 2803821120758 := by decide
private def t_e604797865206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e604797865206 : ¬ IsSelfInterpreter e604797865206 :=
  wSource (t := t_e604797865206) (replay_sound (ps := []) (t := e604797865206) (by decide)) (by decide)
def e604797865582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e604797865582 : Closed e604797865582 ∧ code e604797865582 = 2803821121134 := by decide
private def t_e604797865582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e604797865582 : ¬ IsSelfInterpreter e604797865582 :=
  wSource (t := t_e604797865582) (replay_sound (ps := []) (t := e604797865582) (by decide)) (by decide)
def e604797865594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e604797865594 : Closed e604797865594 ∧ code e604797865594 = 2803821121146 := by decide
private def t_e604797865594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e604797865594 : ¬ IsSelfInterpreter e604797865594 :=
  wSource (t := t_e604797865594) (replay_sound (ps := []) (t := e604797865594) (by decide)) (by decide)
def e604797865782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e604797865782 : Closed e604797865782 ∧ code e604797865782 = 2803821121334 := by decide
private def t_e604797865782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e604797865782 : ¬ IsSelfInterpreter e604797865782 :=
  wSource (t := t_e604797865782) (replay_sound (ps := []) (t := e604797865782) (by decide)) (by decide)
def e604797865786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e604797865786 : Closed e604797865786 ∧ code e604797865786 = 2803821121338 := by decide
private def t_e604797865786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e604797865786 : ¬ IsSelfInterpreter e604797865786 :=
  wSource (t := t_e604797865786) (replay_sound (ps := []) (t := e604797865786) (by decide)) (by decide)
def e604798454638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e604798454638 : Closed e604798454638 ∧ code e604798454638 = 2803821710190 := by decide
def e604798454646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e604798454646 : Closed e604798454646 ∧ code e604798454646 = 2803821710198 := by decide
def e604798454702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e604798454702 : Closed e604798454702 ∧ code e604798454702 = 2803821710254 := by decide
def e604798454714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e604798454714 : Closed e604798454714 ∧ code e604798454714 = 2803821710266 := by decide
private def t_e604798454714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e604798454714 : ¬ IsSelfInterpreter e604798454714 :=
  wSource (t := t_e604798454714) (replay_sound (ps := []) (t := e604798454714) (by decide)) (by decide)
def e604798454742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e604798454742 : Closed e604798454742 ∧ code e604798454742 = 2803821710294 := by decide
def e604798454746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e604798454746 : Closed e604798454746 ∧ code e604798454746 = 2803821710298 := by decide
private def t_e604798454746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e604798454746 : ¬ IsSelfInterpreter e604798454746 :=
  wSource (t := t_e604798454746) (replay_sound (ps := []) (t := e604798454746) (by decide)) (by decide)
def e604798455022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e604798455022 : Closed e604798455022 ∧ code e604798455022 = 2803821710574 := by decide
def e604798455030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e604798455030 : Closed e604798455030 ∧ code e604798455030 = 2803821710582 := by decide
def e604798455406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e604798455406 : Closed e604798455406 ∧ code e604798455406 = 2803821710958 := by decide
def e604798455418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e604798455418 : Closed e604798455418 ∧ code e604798455418 = 2803821710970 := by decide
def e604798455606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e604798455606 : Closed e604798455606 ∧ code e604798455606 = 2803821711158 := by decide
def e604798455610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e604798455610 : Closed e604798455610 ∧ code e604798455610 = 2803821711162 := by decide
def e605590433134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))))
theorem wire_e605590433134 : Closed e605590433134 ∧ code e605590433134 = 2804613688686 := by decide
theorem cert_e605590433134 : check e605590433134 [[],[]] .smaller = true := by decide
def e605590433142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))))
theorem wire_e605590433142 : Closed e605590433142 ∧ code e605590433142 = 2804613688694 := by decide
theorem cert_e605590433142 : check e605590433142 [[],[]] .smaller = true := by decide
def e605590433198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))))
theorem wire_e605590433198 : Closed e605590433198 ∧ code e605590433198 = 2804613688750 := by decide
theorem cert_e605590433198 : check e605590433198 [[],[]] .smaller = true := by decide
def e605590433210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))))
theorem wire_e605590433210 : Closed e605590433210 ∧ code e605590433210 = 2804613688762 := by decide
theorem cert_e605590433210 : check e605590433210 [[],[]] .smaller = true := by decide
def e605590433238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))))
theorem wire_e605590433238 : Closed e605590433238 ∧ code e605590433238 = 2804613688790 := by decide
theorem cert_e605590433238 : check e605590433238 [[],[]] .smaller = true := by decide
def e605590433242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))))
theorem wire_e605590433242 : Closed e605590433242 ∧ code e605590433242 = 2804613688794 := by decide
theorem cert_e605590433242 : check e605590433242 [[],[]] .smaller = true := by decide
def e605590433454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))))
theorem wire_e605590433454 : Closed e605590433454 ∧ code e605590433454 = 2804613689006 := by decide
theorem cert_e605590433454 : check e605590433454 [[],[]] .smaller = true := by decide
def e605590433466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))))
theorem wire_e605590433466 : Closed e605590433466 ∧ code e605590433466 = 2804613689018 := by decide
theorem cert_e605590433466 : check e605590433466 [[],[]] .smaller = true := by decide
def e605590433514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))))
theorem wire_e605590433514 : Closed e605590433514 ∧ code e605590433514 = 2804613689066 := by decide
theorem cert_e605590433514 : check e605590433514 [[],[]] .smaller = true := by decide
def e605590433622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))))
theorem wire_e605590433622 : Closed e605590433622 ∧ code e605590433622 = 2804613689174 := by decide
theorem cert_e605590433622 : check e605590433622 [[],[]] .smaller = true := by decide
def e605590433626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))))
theorem wire_e605590433626 : Closed e605590433626 ∧ code e605590433626 = 2804613689178 := by decide
theorem cert_e605590433626 : check e605590433626 [[],[]] .smaller = true := by decide
def e605590433642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))))
theorem wire_e605590433642 : Closed e605590433642 ∧ code e605590433642 = 2804613689194 := by decide
theorem cert_e605590433642 : check e605590433642 [[],[]] .smaller = true := by decide
def e605590434670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))))
theorem wire_e605590434670 : Closed e605590434670 ∧ code e605590434670 = 2804613690222 := by decide
theorem cert_e605590434670 : check e605590434670 [[],[]] .smaller = true := by decide
def e605590434678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))))
theorem wire_e605590434678 : Closed e605590434678 ∧ code e605590434678 = 2804613690230 := by decide
theorem cert_e605590434678 : check e605590434678 [[],[]] .smaller = true := by decide
def e605590434734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))))
theorem wire_e605590434734 : Closed e605590434734 ∧ code e605590434734 = 2804613690286 := by decide
theorem cert_e605590434734 : check e605590434734 [[],[]] .smaller = true := by decide
def e605590434746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))))
theorem wire_e605590434746 : Closed e605590434746 ∧ code e605590434746 = 2804613690298 := by decide
theorem cert_e605590434746 : check e605590434746 [[],[]] .smaller = true := by decide
def e605590434774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))))
theorem wire_e605590434774 : Closed e605590434774 ∧ code e605590434774 = 2804613690326 := by decide
theorem cert_e605590434774 : check e605590434774 [[],[]] .smaller = true := by decide
def e605590434778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))))
theorem wire_e605590434778 : Closed e605590434778 ∧ code e605590434778 = 2804613690330 := by decide
theorem cert_e605590434778 : check e605590434778 [[],[]] .smaller = true := by decide
end Blc.Floor41
