import CodeBridge
import Batch038
namespace Certgen.R598292499310
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 9,.lam 2,.app 3 6,.app 4 5,.var 0,.var 0,.app 7 8,.var 0,.var 0,.lam 10,.lam 11,.app 12 13,.var 0,.lam 14,.app 15 18,.app 16 17,.var 0,.var 1,.var 2]
def values : Array (List AClo) := #[[⟨9,[]⟩],[⟨6,[0]⟩,⟨13,[1,3]⟩,⟨17,[2,1,3]⟩],[⟨13,[1,3]⟩,⟨17,[2,1,3]⟩],[⟨5,[0]⟩,⟨8,[0]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨9,[]⟩,0⟩],[⟨⟨13,[1,3]⟩,0⟩,⟨⟨13,[1,3]⟩,3⟩],[⟨⟨18,[2,1,3]⟩,0⟩,⟨⟨18,[2,1,3]⟩,3⟩],[⟨⟨17,[2,1,3]⟩,3⟩],[⟨⟨6,[0]⟩,0⟩],[⟨⟨5,[0]⟩,5⟩],[⟨⟨8,[0]⟩,2⟩,⟨⟨8,[0]⟩,4⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[0]⟩,0⟩,⟨⟨3,[0]⟩,5⟩,⟨⟨4,[0]⟩,6⟩,⟨⟨6,[0]⟩,2⟩,⟨⟨6,[0]⟩,4⟩,⟨⟨7,[0]⟩,7⟩,⟨⟨9,[]⟩,6⟩,⟨⟨9,[]⟩,7⟩,⟨⟨10,[3]⟩,2⟩,⟨⟨10,[3]⟩,4⟩,⟨⟨10,[3]⟩,5⟩,⟨⟨11,[1,3]⟩,0⟩,⟨⟨11,[1,3]⟩,3⟩,⟨⟨12,[1,3]⟩,2⟩,⟨⟨13,[1,3]⟩,2⟩,⟨⟨13,[1,3]⟩,4⟩,⟨⟨14,[2,1,3]⟩,0⟩,⟨⟨14,[2,1,3]⟩,3⟩,⟨⟨15,[2,1,3]⟩,3⟩,⟨⟨16,[2,1,3]⟩,4⟩,⟨⟨17,[2,1,3]⟩,2⟩,⟨⟨17,[2,1,3]⟩,4⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[4],[8],[7],[7],[9],[12],[10,11],[13,14],[14],[13],[15],[15],[5,16,22],[18,19],[19],[20],[20],[21],[17,23],[5,16,22],[6,17,23]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<24 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 exact range_sound block12 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Floor41 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit16 : Term := .var 0
def lit17 : Term := .var 1
def lit18 : Term := .var 2
def lit6 : Term := .app lit16 lit16
def lit15 : Term := .app lit16 lit17
def lit14 : Term := .app lit15 lit18
def lit2 : Term := .app lit6 lit6
def lit13 : Term := .lam lit14
def lit1 : Term := .lam lit2
def lit11 : Term := .app lit16 lit13
def lit10 : Term := .lam lit11
def lit9 : Term := .lam lit10
def lit0 : Term := .app lit1 lit9
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub18 : model.term 18 = lit18 := model.var_eq 18 2 (by rfl)
theorem sub17 : model.term 17 = lit17 := model.var_eq 17 1 (by rfl)
theorem sub16 : model.term 16 = lit16 := model.var_eq 16 0 (by rfl)
theorem sub15 : model.term 15 = lit15 := by rw [model.app_eq 15 16 17 (by rfl), sub16, sub17]; rfl
theorem sub14 : model.term 14 = lit14 := by rw [model.app_eq 14 15 18 (by rfl), sub15, sub18]; rfl
theorem sub13 : model.term 13 = lit13 := by rw [model.lam_eq 13 14 (by rfl), sub14]; rfl
theorem sub12 : model.term 12 = lit16 := model.var_eq 12 0 (by rfl)
theorem sub11 : model.term 11 = lit11 := by rw [model.app_eq 11 12 13 (by rfl), sub12, sub13]; rfl
theorem sub10 : model.term 10 = lit10 := by rw [model.lam_eq 10 11 (by rfl), sub11]; rfl
theorem sub9 : model.term 9 = lit9 := by rw [model.lam_eq 9 10 (by rfl), sub10]; rfl
theorem sub8 : model.term 8 = lit16 := model.var_eq 8 0 (by rfl)
theorem sub7 : model.term 7 = lit16 := model.var_eq 7 0 (by rfl)
theorem sub6 : model.term 6 = lit6 := by rw [model.app_eq 6 7 8 (by rfl), sub7, sub8]; rfl
theorem sub5 : model.term 5 = lit16 := model.var_eq 5 0 (by rfl)
theorem sub4 : model.term 4 = lit16 := model.var_eq 4 0 (by rfl)
theorem sub3 : model.term 3 = lit6 := by rw [model.app_eq 3 4 5 (by rfl), sub4, sub5]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 6 (by rfl), sub3, sub6]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.lam_eq 1 2 (by rfl), sub2]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 9 (by rfl), sub1, sub9]; rfl
theorem excluded : ¬ IsSelfInterpreter e598292499310 := by
 intro he
 have hp : replay [] e598292499310 = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (rawCount he) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R598292499310
