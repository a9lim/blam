import R598355273326V0
import R598355273326K0
import R598355273326st0
import R598355273326st12
import R598355273326st24
import R598355273326hs0
import R598355273326hs12
import R598355273326hs24
import CodeBridge
import Batch044
namespace Certgen.R598355273326
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 72,.app 2 63,.app 3 26,.app 4 23,.app 5 11,.lam 6,.app 7 10,.app 8 9,.var 0,.var 0,.var 0,.lam 12,.app 13 14,.var 0,.lam 15,.lam 16,.app 17 18,.var 1,.app 19 20,.var 0,.app 21 22,.var 0,.var 2,.lam 24,.lam 25,.var 1,.lam 27,.app 28 33,.app 29 30,.var 0,.lam 31,.lam 32,.var 1,.lam 34,.app 35 40,.app 36 37,.var 0,.lam 38,.lam 39,.var 1,.lam 41,.app 42 47,.app 43 44,.var 0,.lam 45,.lam 46,.var 0,.lam 48,.app 49 54,.app 50 51,.var 0,.lam 52,.lam 53,.var 1,.app 55 59,.lam 56,.app 57 58,.var 0,.var 0,.lam 60,.app 61 62,.var 0,.var 0,.app 64 68,.lam 65,.app 66 67,.var 0,.var 0,.lam 69,.app 70 71,.var 0,.var 0,.lam 73,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (V20[i-20]?.getD []))
def K (i : Nat) : List Frame := (if i < 60 then (if i < 20 then (K0[i-0]?.getD []) else (if i < 40 then (K20[i-20]?.getD []) else (K40[i-40]?.getD []))) else (if i < 80 then (K60[i-60]?.getD []) else (if i < 100 then (K80[i-80]?.getD []) else (K100[i-100]?.getD []))))
def st (i : Nat) : AState := if i < 513 then (if i < 260 then (if i < 120 then (if i < 60 then (if i < 20 then (st0[i-0]?.getD entry) else (if i < 40 then (st20[i-20]?.getD entry) else (st40[i-40]?.getD entry))) else (if i < 80 then (st60[i-60]?.getD entry) else (if i < 100 then (st80[i-80]?.getD entry) else (st100[i-100]?.getD entry)))) else (if i < 180 then (if i < 140 then (st120[i-120]?.getD entry) else (if i < 160 then (st140[i-140]?.getD entry) else (st160[i-160]?.getD entry))) else (if i < 220 then (if i < 200 then (st180[i-180]?.getD entry) else (st200[i-200]?.getD entry)) else (if i < 240 then (st220[i-220]?.getD entry) else (st240[i-240]?.getD entry))))) else (if i < 380 then (if i < 320 then (if i < 280 then (st260[i-260]?.getD entry) else (if i < 300 then (st280[i-280]?.getD entry) else (st300[i-300]?.getD entry))) else (if i < 340 then (st320[i-320]?.getD entry) else (if i < 360 then (st340[i-340]?.getD entry) else (st360[i-360]?.getD entry)))) else (if i < 440 then (if i < 400 then (st380[i-380]?.getD entry) else (if i < 420 then (st400[i-400]?.getD entry) else (st420[i-420]?.getD entry))) else (if i < 480 then (if i < 460 then (st440[i-440]?.getD entry) else (st460[i-460]?.getD entry)) else (if i < 500 then (st480[i-480]?.getD entry) else (st500[i-500]?.getD entry)))))) else entry
def hs (i : Nat) : List Nat := (if i < 260 then (if i < 120 then (if i < 60 then (if i < 20 then (hs0[i-0]?.getD []) else (if i < 40 then (hs20[i-20]?.getD []) else (hs40[i-40]?.getD []))) else (if i < 80 then (hs60[i-60]?.getD []) else (if i < 100 then (hs80[i-80]?.getD []) else (hs100[i-100]?.getD [])))) else (if i < 180 then (if i < 140 then (hs120[i-120]?.getD []) else (if i < 160 then (hs140[i-140]?.getD []) else (hs160[i-160]?.getD []))) else (if i < 220 then (if i < 200 then (hs180[i-180]?.getD []) else (hs200[i-200]?.getD [])) else (if i < 240 then (hs220[i-220]?.getD []) else (hs240[i-240]?.getD []))))) else (if i < 380 then (if i < 320 then (if i < 280 then (hs260[i-260]?.getD []) else (if i < 300 then (hs280[i-280]?.getD []) else (hs300[i-300]?.getD []))) else (if i < 340 then (hs320[i-320]?.getD []) else (if i < 360 then (hs340[i-340]?.getD []) else (hs360[i-360]?.getD [])))) else (if i < 440 then (if i < 400 then (hs380[i-380]?.getD []) else (if i < 420 then (hs400[i-400]?.getD []) else (hs420[i-420]?.getD []))) else (if i < 480 then (if i < 460 then (hs440[i-440]?.getD []) else (hs460[i-460]?.getD [])) else (if i < 500 then (hs480[i-480]?.getD []) else (hs500[i-500]?.getD []))))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R598355273326
