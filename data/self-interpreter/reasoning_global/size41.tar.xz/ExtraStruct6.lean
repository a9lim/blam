import Extra41
import Batch043
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness598345530586
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege598345530586 : ¬ IsSelfInterpreter e598345530586 := by
  intro he
  have h : replay [] e598345530586 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 2 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege598345530586
end Witness598345530586
namespace Witness598345530602
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege598345530602 : ¬ IsSelfInterpreter e598345530602 := by
  intro he
  have h : replay [] e598345530602 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 2 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege598345530602
end Witness598345530602
namespace Witness598345583470
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.app u0 u4
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u3 u11
theorem nege598345583470 : ¬ IsSelfInterpreter e598345583470 := by
  intro he
  have h : replay [] e598345583470 = some u12 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 2 (by decide : Closed u12) (by decide) (by decide) hj
#print axioms nege598345583470
end Witness598345583470
namespace Witness598345583478
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.app u0 u4
private def u6 := Term.var 1
private def u7 := Term.app u5 u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u3 u11
theorem nege598345583478 : ¬ IsSelfInterpreter e598345583478 := by
  intro he
  have h : replay [] e598345583478 = some u12 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 2 (by decide : Closed u12) (by decide) (by decide) hj
#print axioms nege598345583478
end Witness598345583478
namespace Witness598345583534
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.app u4 u0
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u3 u11
theorem nege598345583534 : ¬ IsSelfInterpreter e598345583534 := by
  intro he
  have h : replay [] e598345583534 = some u12 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 2 (by decide : Closed u12) (by decide) (by decide) hj
#print axioms nege598345583534
end Witness598345583534
namespace Witness598345583546
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u3 u11
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u13 := Term.app u0 u4
private def u14 := Term.app u4 u0
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.var 2
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou6 sou0
private theorem sou13 : SO u13 := SO.app sou0 sou4
private theorem sou8 : SO u8 := SO.lam (r := u13) (g := u14) sou7 sou13 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou1 sou8
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
private theorem sou12 : SO u12 := SO.app sou3 sou11
theorem nege598345583546 : ¬ IsSelfInterpreter e598345583546 := by
  exact rawSO [] (t := u12) (by decide) sou12
#print axioms nege598345583546
end Witness598345583546
namespace Witness598345583574
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.app u4 u0
private def u6 := Term.var 1
private def u7 := Term.app u5 u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u3 u11
theorem nege598345583574 : ¬ IsSelfInterpreter e598345583574 := by
  intro he
  have h : replay [] e598345583574 = some u12 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 2 (by decide : Closed u12) (by decide) (by decide) hj
#print axioms nege598345583574
end Witness598345583574
namespace Witness598345583578
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u6 u0
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u3 u11
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u13 := Term.app u5 u0
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou6 sou0
private theorem sou13 : SO u13 := SO.app sou5 sou0
private theorem sou8 : SO u8 := SO.lam (r := u13) (g := u13) sou7 sou13 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.app sou1 sou8
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
private theorem sou12 : SO u12 := SO.app sou3 sou11
theorem nege598345583578 : ¬ IsSelfInterpreter e598345583578 := by
  exact rawSO [] (t := u12) (by decide) sou12
#print axioms nege598345583578
end Witness598345583578
end Blc.Floor41
