import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605591329210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e605591329210 : Closed e605591329210 ∧ code e605591329210 = 2804614584762 := by decide
theorem cert_e605591329210 : check e605591329210 [[],[]] .smaller = true := by decide
def e605591329258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e605591329258 : Closed e605591329258 ∧ code e605591329258 = 2804614584810 := by decide
theorem cert_e605591329258 : check e605591329258 [[],[]] .smaller = true := by decide
def e605591329342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e605591329342 : Closed e605591329342 ∧ code e605591329342 = 2804614584894 := by decide
theorem cert_e605591329342 : check e605591329342 [[],[]] .smaller = true := by decide
def e605591329390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605591329390 : Closed e605591329390 ∧ code e605591329390 = 2804614584942 := by decide
theorem cert_e605591329390 : check e605591329390 [[],[]] .smaller = true := by decide
def e605591329402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605591329402 : Closed e605591329402 ∧ code e605591329402 = 2804614584954 := by decide
theorem cert_e605591329402 : check e605591329402 [[],[]] .smaller = true := by decide
def e605591329566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e605591329566 : Closed e605591329566 ∧ code e605591329566 = 2804614585118 := by decide
theorem cert_e605591329566 : check e605591329566 [[],[]] .smaller = true := by decide
def e605591329678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e605591329678 : Closed e605591329678 ∧ code e605591329678 = 2804614585230 := by decide
theorem cert_e605591329678 : check e605591329678 [[],[]] .smaller = true := by decide
def e605591329690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591329690 : Closed e605591329690 ∧ code e605591329690 = 2804614585242 := by decide
theorem cert_e605591329690 : check e605591329690 [[],[]] .smaller = true := by decide
def e605591329734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e605591329734 : Closed e605591329734 ∧ code e605591329734 = 2804614585286 := by decide
theorem cert_e605591329734 : check e605591329734 [[],[]] .smaller = true := by decide
def e605591329758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 3)))))))))
theorem wire_e605591329758 : Closed e605591329758 ∧ code e605591329758 = 2804614585310 := by decide
theorem cert_e605591329758 : check e605591329758 [[],[]] .smaller = true := by decide
def e605591329902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e605591329902 : Closed e605591329902 ∧ code e605591329902 = 2804614585454 := by decide
theorem cert_e605591329902 : check e605591329902 [[],[]] .smaller = true := by decide
def e605591329914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e605591329914 : Closed e605591329914 ∧ code e605591329914 = 2804614585466 := by decide
theorem cert_e605591329914 : check e605591329914 [[],[]] .smaller = true := by decide
def e605591330078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e605591330078 : Closed e605591330078 ∧ code e605591330078 = 2804614585630 := by decide
theorem cert_e605591330078 : check e605591330078 [[],[]] .smaller = true := by decide
def e605591330246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e605591330246 : Closed e605591330246 ∧ code e605591330246 = 2804614585798 := by decide
theorem cert_e605591330246 : check e605591330246 [[],[]] .smaller = true := by decide
def e605591330270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e605591330270 : Closed e605591330270 ∧ code e605591330270 = 2804614585822 := by decide
theorem cert_e605591330270 : check e605591330270 [[],[]] .smaller = true := by decide
def e605591330286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e605591330286 : Closed e605591330286 ∧ code e605591330286 = 2804614585838 := by decide
theorem cert_e605591330286 : check e605591330286 [[],[]] .smaller = true := by decide
def e605591330358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e605591330358 : Closed e605591330358 ∧ code e605591330358 = 2804614585910 := by decide
theorem cert_e605591330358 : check e605591330358 [[],[]] .smaller = true := by decide
def e605591330362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e605591330362 : Closed e605591330362 ∧ code e605591330362 = 2804614585914 := by decide
theorem cert_e605591330362 : check e605591330362 [[],[]] .smaller = true := by decide
def e605591330410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e605591330410 : Closed e605591330410 ∧ code e605591330410 = 2804614585962 := by decide
theorem cert_e605591330410 : check e605591330410 [[],[]] .smaller = true := by decide
def e605591330446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e605591330446 : Closed e605591330446 ∧ code e605591330446 = 2804614585998 := by decide
theorem cert_e605591330446 : check e605591330446 [[],[]] .smaller = true := by decide
def e605591330458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591330458 : Closed e605591330458 ∧ code e605591330458 = 2804614586010 := by decide
theorem cert_e605591330458 : check e605591330458 [[],[]] .smaller = true := by decide
def e605591330502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e605591330502 : Closed e605591330502 ∧ code e605591330502 = 2804614586054 := by decide
theorem cert_e605591330502 : check e605591330502 [[],[]] .smaller = true := by decide
def e605591330526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e605591330526 : Closed e605591330526 ∧ code e605591330526 = 2804614586078 := by decide
theorem cert_e605591330526 : check e605591330526 [[],[]] .smaller = true := by decide
def e605591330550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e605591330550 : Closed e605591330550 ∧ code e605591330550 = 2804614586102 := by decide
theorem cert_e605591330550 : check e605591330550 [[],[]] .smaller = true := by decide
def e605591330586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e605591330586 : Closed e605591330586 ∧ code e605591330586 = 2804614586138 := by decide
theorem cert_e605591330586 : check e605591330586 [[],[]] .smaller = true := by decide
def e605591330630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e605591330630 : Closed e605591330630 ∧ code e605591330630 = 2804614586182 := by decide
theorem cert_e605591330630 : check e605591330630 [[],[]] .smaller = true := by decide
def e605591330654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 3)))))))))
theorem wire_e605591330654 : Closed e605591330654 ∧ code e605591330654 = 2804614586206 := by decide
theorem cert_e605591330654 : check e605591330654 [[],[]] .smaller = true := by decide
def e605591330670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e605591330670 : Closed e605591330670 ∧ code e605591330670 = 2804614586222 := by decide
theorem cert_e605591330670 : check e605591330670 [[],[]] .smaller = true := by decide
def e605591330678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e605591330678 : Closed e605591330678 ∧ code e605591330678 = 2804614586230 := by decide
theorem cert_e605591330678 : check e605591330678 [[],[]] .smaller = true := by decide
def e605591330682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 3)) (.var 0)))))))))
theorem wire_e605591330682 : Closed e605591330682 ∧ code e605591330682 = 2804614586234 := by decide
theorem cert_e605591330682 : check e605591330682 [[],[]] .smaller = true := by decide
def e605591331294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e605591331294 : Closed e605591331294 ∧ code e605591331294 = 2804614586846 := by decide
theorem cert_e605591331294 : check e605591331294 [[],[]] .smaller = true := by decide
def e605591331318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e605591331318 : Closed e605591331318 ∧ code e605591331318 = 2804614586870 := by decide
theorem cert_e605591331318 : check e605591331318 [[],[]] .smaller = true := by decide
def e605591332270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e605591332270 : Closed e605591332270 ∧ code e605591332270 = 2804614587822 := by decide
theorem cert_e605591332270 : check e605591332270 [[],[]] .smaller = true := by decide
def e605591332282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e605591332282 : Closed e605591332282 ∧ code e605591332282 = 2804614587834 := by decide
theorem cert_e605591332282 : check e605591332282 [[],[]] .smaller = true := by decide
def e605591332330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e605591332330 : Closed e605591332330 ∧ code e605591332330 = 2804614587882 := by decide
theorem cert_e605591332330 : check e605591332330 [[],[]] .smaller = true := by decide
def e605591332414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e605591332414 : Closed e605591332414 ∧ code e605591332414 = 2804614587966 := by decide
theorem cert_e605591332414 : check e605591332414 [[],[]] .smaller = true := by decide
def e605591332462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605591332462 : Closed e605591332462 ∧ code e605591332462 = 2804614588014 := by decide
theorem cert_e605591332462 : check e605591332462 [[],[]] .smaller = true := by decide
def e605591332474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605591332474 : Closed e605591332474 ∧ code e605591332474 = 2804614588026 := by decide
theorem cert_e605591332474 : check e605591332474 [[],[]] .smaller = true := by decide
def e605591332638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e605591332638 : Closed e605591332638 ∧ code e605591332638 = 2804614588190 := by decide
theorem cert_e605591332638 : check e605591332638 [[],[]] .smaller = true := by decide
def e605591332750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e605591332750 : Closed e605591332750 ∧ code e605591332750 = 2804614588302 := by decide
theorem cert_e605591332750 : check e605591332750 [[],[]] .smaller = true := by decide
def e605591332762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605591332762 : Closed e605591332762 ∧ code e605591332762 = 2804614588314 := by decide
theorem cert_e605591332762 : check e605591332762 [[],[]] .smaller = true := by decide
def e605591332806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e605591332806 : Closed e605591332806 ∧ code e605591332806 = 2804614588358 := by decide
theorem cert_e605591332806 : check e605591332806 [[],[]] .smaller = true := by decide
def e605591332830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 3))))))))))
theorem wire_e605591332830 : Closed e605591332830 ∧ code e605591332830 = 2804614588382 := by decide
theorem cert_e605591332830 : check e605591332830 [[],[]] .smaller = true := by decide
def e605591335710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e605591335710 : Closed e605591335710 ∧ code e605591335710 = 2804614591262 := by decide
theorem cert_e605591335710 : check e605591335710 [[],[]] .smaller = true := by decide
def e605591335878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e605591335878 : Closed e605591335878 ∧ code e605591335878 = 2804614591430 := by decide
theorem cert_e605591335878 : check e605591335878 [[],[]] .smaller = true := by decide
def e605591335902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e605591335902 : Closed e605591335902 ∧ code e605591335902 = 2804614591454 := by decide
theorem cert_e605591335902 : check e605591335902 [[],[]] .smaller = true := by decide
def e605591335918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e605591335918 : Closed e605591335918 ∧ code e605591335918 = 2804614591470 := by decide
theorem cert_e605591335918 : check e605591335918 [[],[]] .smaller = true := by decide
def e605591337078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e605591337078 : Closed e605591337078 ∧ code e605591337078 = 2804614592630 := by decide
theorem cert_e605591337078 : check e605591337078 [[],[]] .smaller = true := by decide
def e605591337322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e605591337322 : Closed e605591337322 ∧ code e605591337322 = 2804614592874 := by decide
theorem cert_e605591337322 : check e605591337322 [[],[]] .smaller = true := by decide
def e605591337358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e605591337358 : Closed e605591337358 ∧ code e605591337358 = 2804614592910 := by decide
theorem cert_e605591337358 : check e605591337358 [[],[]] .smaller = true := by decide
def e605591337370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605591337370 : Closed e605591337370 ∧ code e605591337370 = 2804614592922 := by decide
theorem cert_e605591337370 : check e605591337370 [[],[]] .smaller = true := by decide
def e605591337414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e605591337414 : Closed e605591337414 ∧ code e605591337414 = 2804614592966 := by decide
theorem cert_e605591337414 : check e605591337414 [[],[]] .smaller = true := by decide
def e605591337438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e605591337438 : Closed e605591337438 ∧ code e605591337438 = 2804614592990 := by decide
theorem cert_e605591337438 : check e605591337438 [[],[]] .smaller = true := by decide
def e605591337462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e605591337462 : Closed e605591337462 ∧ code e605591337462 = 2804614593014 := by decide
theorem cert_e605591337462 : check e605591337462 [[],[]] .smaller = true := by decide
def e605591338182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e605591338182 : Closed e605591338182 ∧ code e605591338182 = 2804614593734 := by decide
theorem cert_e605591338182 : check e605591338182 [[],[]] .smaller = true := by decide
def e605591338206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 3))))))))))
theorem wire_e605591338206 : Closed e605591338206 ∧ code e605591338206 = 2804614593758 := by decide
theorem cert_e605591338206 : check e605591338206 [[],[]] .smaller = true := by decide
def e605591338222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e605591338222 : Closed e605591338222 ∧ code e605591338222 = 2804614593774 := by decide
theorem cert_e605591338222 : check e605591338222 [[],[]] .smaller = true := by decide
def e605591338230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e605591338230 : Closed e605591338230 ∧ code e605591338230 = 2804614593782 := by decide
theorem cert_e605591338230 : check e605591338230 [[],[]] .smaller = true := by decide
def e605591338234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 3) (.var 0))))))))))
theorem wire_e605591338234 : Closed e605591338234 ∧ code e605591338234 = 2804614593786 := by decide
theorem cert_e605591338234 : check e605591338234 [[],[]] .smaller = true := by decide
def e605591382870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e605591382870 : Closed e605591382870 ∧ code e605591382870 = 2804614638422 := by decide
theorem cert_e605591382870 : check e605591382870 [[],[]] .smaller = true := by decide
def e605591382874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e605591382874 : Closed e605591382874 ∧ code e605591382874 = 2804614638426 := by decide
theorem cert_e605591382874 : check e605591382874 [[],[]] .smaller = true := by decide
def e605591382890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e605591382890 : Closed e605591382890 ∧ code e605591382890 = 2804614638442 := by decide
theorem cert_e605591382890 : check e605591382890 [[],[]] .smaller = true := by decide
def e605591382954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e605591382954 : Closed e605591382954 ∧ code e605591382954 = 2804614638506 := by decide
theorem cert_e605591382954 : check e605591382954 [[],[]] .smaller = true := by decide
def e605591383158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e605591383158 : Closed e605591383158 ∧ code e605591383158 = 2804614638710 := by decide
theorem cert_e605591383158 : check e605591383158 [[],[]] .smaller = true := by decide
def e605591383254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e605591383254 : Closed e605591383254 ∧ code e605591383254 = 2804614638806 := by decide
theorem cert_e605591383254 : check e605591383254 [[],[]] .smaller = true := by decide
def e605591383258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e605591383258 : Closed e605591383258 ∧ code e605591383258 = 2804614638810 := by decide
theorem cert_e605591383258 : check e605591383258 [[],[]] .smaller = true := by decide
def e605591383274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e605591383274 : Closed e605591383274 ∧ code e605591383274 = 2804614638826 := by decide
theorem cert_e605591383274 : check e605591383274 [[],[]] .smaller = true := by decide
def e605591383350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605591383350 : Closed e605591383350 ∧ code e605591383350 = 2804614638902 := by decide
theorem cert_e605591383350 : check e605591383350 [[],[]] .smaller = true := by decide
def e605591383354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605591383354 : Closed e605591383354 ∧ code e605591383354 = 2804614638906 := by decide
theorem cert_e605591383354 : check e605591383354 [[],[]] .smaller = true := by decide
def e605591383438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e605591383438 : Closed e605591383438 ∧ code e605591383438 = 2804614638990 := by decide
theorem cert_e605591383438 : check e605591383438 [[],[]] .smaller = true := by decide
def e605591383450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591383450 : Closed e605591383450 ∧ code e605591383450 = 2804614639002 := by decide
theorem cert_e605591383450 : check e605591383450 [[],[]] .smaller = true := by decide
def e605591383518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605591383518 : Closed e605591383518 ∧ code e605591383518 = 2804614639070 := by decide
theorem cert_e605591383518 : check e605591383518 [[],[]] .smaller = true := by decide
def e605591383534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605591383534 : Closed e605591383534 ∧ code e605591383534 = 2804614639086 := by decide
theorem cert_e605591383534 : check e605591383534 [[],[]] .smaller = true := by decide
def e605591383606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e605591383606 : Closed e605591383606 ∧ code e605591383606 = 2804614639158 := by decide
theorem cert_e605591383606 : check e605591383606 [[],[]] .smaller = true := by decide
def e605591383610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e605591383610 : Closed e605591383610 ∧ code e605591383610 = 2804614639162 := by decide
theorem cert_e605591383610 : check e605591383610 [[],[]] .smaller = true := by decide
def e605591383658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e605591383658 : Closed e605591383658 ∧ code e605591383658 = 2804614639210 := by decide
theorem cert_e605591383658 : check e605591383658 [[],[]] .smaller = true := by decide
def e605591383694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e605591383694 : Closed e605591383694 ∧ code e605591383694 = 2804614639246 := by decide
theorem cert_e605591383694 : check e605591383694 [[],[]] .smaller = true := by decide
def e605591383706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591383706 : Closed e605591383706 ∧ code e605591383706 = 2804614639258 := by decide
theorem cert_e605591383706 : check e605591383706 [[],[]] .smaller = true := by decide
def e605591383750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e605591383750 : Closed e605591383750 ∧ code e605591383750 = 2804614639302 := by decide
theorem cert_e605591383750 : check e605591383750 [[],[]] .smaller = true := by decide
def e605591383774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e605591383774 : Closed e605591383774 ∧ code e605591383774 = 2804614639326 := by decide
theorem cert_e605591383774 : check e605591383774 [[],[]] .smaller = true := by decide
def e605591383798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e605591383798 : Closed e605591383798 ∧ code e605591383798 = 2804614639350 := by decide
theorem cert_e605591383798 : check e605591383798 [[],[]] .smaller = true := by decide
def e605591383902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605591383902 : Closed e605591383902 ∧ code e605591383902 = 2804614639454 := by decide
theorem cert_e605591383902 : check e605591383902 [[],[]] .smaller = true := by decide
def e605591383930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605591383930 : Closed e605591383930 ∧ code e605591383930 = 2804614639482 := by decide
theorem cert_e605591383930 : check e605591383930 [[],[]] .smaller = true := by decide
def e605591383982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605591383982 : Closed e605591383982 ∧ code e605591383982 = 2804614639534 := by decide
theorem cert_e605591383982 : check e605591383982 [[],[]] .smaller = true := by decide
def e605591383990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e605591383990 : Closed e605591383990 ∧ code e605591383990 = 2804614639542 := by decide
theorem cert_e605591383990 : check e605591383990 [[],[]] .smaller = true := by decide
def e605591383994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605591383994 : Closed e605591383994 ∧ code e605591383994 = 2804614639546 := by decide
theorem cert_e605591383994 : check e605591383994 [[],[]] .smaller = true := by decide
def e605591384302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e605591384302 : Closed e605591384302 ∧ code e605591384302 = 2804614639854 := by decide
theorem cert_e605591384302 : check e605591384302 [[],[]] .smaller = true := by decide
def e605591384310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e605591384310 : Closed e605591384310 ∧ code e605591384310 = 2804614639862 := by decide
theorem cert_e605591384310 : check e605591384310 [[],[]] .smaller = true := by decide
def e605591384790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e605591384790 : Closed e605591384790 ∧ code e605591384790 = 2804614640342 := by decide
theorem cert_e605591384790 : check e605591384790 [[],[]] .smaller = true := by decide
def e605591384794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e605591384794 : Closed e605591384794 ∧ code e605591384794 = 2804614640346 := by decide
theorem cert_e605591384794 : check e605591384794 [[],[]] .smaller = true := by decide
def e605591384810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e605591384810 : Closed e605591384810 ∧ code e605591384810 = 2804614640362 := by decide
theorem cert_e605591384810 : check e605591384810 [[],[]] .smaller = true := by decide
def e605591384886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605591384886 : Closed e605591384886 ∧ code e605591384886 = 2804614640438 := by decide
theorem cert_e605591384886 : check e605591384886 [[],[]] .smaller = true := by decide
def e605591384890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605591384890 : Closed e605591384890 ∧ code e605591384890 = 2804614640442 := by decide
theorem cert_e605591384890 : check e605591384890 [[],[]] .smaller = true := by decide
def e605591384974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e605591384974 : Closed e605591384974 ∧ code e605591384974 = 2804614640526 := by decide
theorem cert_e605591384974 : check e605591384974 [[],[]] .smaller = true := by decide
def e605591384986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605591384986 : Closed e605591384986 ∧ code e605591384986 = 2804614640538 := by decide
theorem cert_e605591384986 : check e605591384986 [[],[]] .smaller = true := by decide
def e605591385054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605591385054 : Closed e605591385054 ∧ code e605591385054 = 2804614640606 := by decide
theorem cert_e605591385054 : check e605591385054 [[],[]] .smaller = true := by decide
def e605591385070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605591385070 : Closed e605591385070 ∧ code e605591385070 = 2804614640622 := by decide
theorem cert_e605591385070 : check e605591385070 [[],[]] .smaller = true := by decide
def e605591386230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e605591386230 : Closed e605591386230 ∧ code e605591386230 = 2804614641782 := by decide
theorem cert_e605591386230 : check e605591386230 [[],[]] .smaller = true := by decide
def e605591386474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e605591386474 : Closed e605591386474 ∧ code e605591386474 = 2804614642026 := by decide
theorem cert_e605591386474 : check e605591386474 [[],[]] .smaller = true := by decide
def e605591386510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e605591386510 : Closed e605591386510 ∧ code e605591386510 = 2804614642062 := by decide
theorem cert_e605591386510 : check e605591386510 [[],[]] .smaller = true := by decide
def e605591386522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605591386522 : Closed e605591386522 ∧ code e605591386522 = 2804614642074 := by decide
theorem cert_e605591386522 : check e605591386522 [[],[]] .smaller = true := by decide
def e605591386566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e605591386566 : Closed e605591386566 ∧ code e605591386566 = 2804614642118 := by decide
theorem cert_e605591386566 : check e605591386566 [[],[]] .smaller = true := by decide
def e605591386590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e605591386590 : Closed e605591386590 ∧ code e605591386590 = 2804614642142 := by decide
theorem cert_e605591386590 : check e605591386590 [[],[]] .smaller = true := by decide
def e605591386614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e605591386614 : Closed e605591386614 ∧ code e605591386614 = 2804614642166 := by decide
theorem cert_e605591386614 : check e605591386614 [[],[]] .smaller = true := by decide
def e605591387358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605591387358 : Closed e605591387358 ∧ code e605591387358 = 2804614642910 := by decide
theorem cert_e605591387358 : check e605591387358 [[],[]] .smaller = true := by decide
def e605591387386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605591387386 : Closed e605591387386 ∧ code e605591387386 = 2804614642938 := by decide
theorem cert_e605591387386 : check e605591387386 [[],[]] .smaller = true := by decide
def e605591387758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605591387758 : Closed e605591387758 ∧ code e605591387758 = 2804614643310 := by decide
theorem cert_e605591387758 : check e605591387758 [[],[]] .smaller = true := by decide
def e605591387766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e605591387766 : Closed e605591387766 ∧ code e605591387766 = 2804614643318 := by decide
theorem cert_e605591387766 : check e605591387766 [[],[]] .smaller = true := by decide
def e605591387770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605591387770 : Closed e605591387770 ∧ code e605591387770 = 2804614643322 := by decide
theorem cert_e605591387770 : check e605591387770 [[],[]] .smaller = true := by decide
def e605591410230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e605591410230 : Closed e605591410230 ∧ code e605591410230 = 2804614665782 := by decide
theorem cert_e605591410230 : check e605591410230 [[],[]] .smaller = true := by decide
def e605591410234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e605591410234 : Closed e605591410234 ∧ code e605591410234 = 2804614665786 := by decide
theorem cert_e605591410234 : check e605591410234 [[],[]] .smaller = true := by decide
def e605591410318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e605591410318 : Closed e605591410318 ∧ code e605591410318 = 2804614665870 := by decide
theorem cert_e605591410318 : check e605591410318 [[],[]] .smaller = true := by decide
def e605591410366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 4)))))))))
theorem wire_e605591410366 : Closed e605591410366 ∧ code e605591410366 = 2804614665918 := by decide
theorem cert_e605591410366 : check e605591410366 [[],[]] .three = true := by decide
def e605591410374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e605591410374 : Closed e605591410374 ∧ code e605591410374 = 2804614665926 := by decide
theorem cert_e605591410374 : check e605591410374 [[],[]] .smaller = true := by decide
def e605591410398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605591410398 : Closed e605591410398 ∧ code e605591410398 = 2804614665950 := by decide
theorem cert_e605591410398 : check e605591410398 [[],[]] .smaller = true := by decide
def e605591410414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e605591410414 : Closed e605591410414 ∧ code e605591410414 = 2804614665966 := by decide
theorem cert_e605591410414 : check e605591410414 [[],[]] .smaller = true := by decide
def e605591410422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605591410422 : Closed e605591410422 ∧ code e605591410422 = 2804614665974 := by decide
theorem cert_e605591410422 : check e605591410422 [[],[]] .smaller = true := by decide
def e605591410426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 4)) (.var 0)))))))))
theorem wire_e605591410426 : Closed e605591410426 ∧ code e605591410426 = 2804614665978 := by decide
theorem cert_e605591410426 : check e605591410426 [[],[]] .three = true := by decide
def e605591410458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e605591410458 : Closed e605591410458 ∧ code e605591410458 = 2804614666010 := by decide
theorem cert_e605591410458 : check e605591410458 [[],[]] .smaller = true := by decide
def e605591410502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e605591410502 : Closed e605591410502 ∧ code e605591410502 = 2804614666054 := by decide
theorem cert_e605591410502 : check e605591410502 [[],[]] .smaller = true := by decide
def e605591410526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605591410526 : Closed e605591410526 ∧ code e605591410526 = 2804614666078 := by decide
theorem cert_e605591410526 : check e605591410526 [[],[]] .smaller = true := by decide
def e605591410542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e605591410542 : Closed e605591410542 ∧ code e605591410542 = 2804614666094 := by decide
theorem cert_e605591410542 : check e605591410542 [[],[]] .smaller = true := by decide
def e605591410550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e605591410550 : Closed e605591410550 ∧ code e605591410550 = 2804614666102 := by decide
theorem cert_e605591410550 : check e605591410550 [[],[]] .smaller = true := by decide
def e605591410554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605591410554 : Closed e605591410554 ∧ code e605591410554 = 2804614666106 := by decide
theorem cert_e605591410554 : check e605591410554 [[],[]] .smaller = true := by decide
def e605591410606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e605591410606 : Closed e605591410606 ∧ code e605591410606 = 2804614666158 := by decide
theorem cert_e605591410606 : check e605591410606 [[],[]] .smaller = true := by decide
def e605591410614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e605591410614 : Closed e605591410614 ∧ code e605591410614 = 2804614666166 := by decide
theorem cert_e605591410614 : check e605591410614 [[],[]] .smaller = true := by decide
def e605591410618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e605591410618 : Closed e605591410618 ∧ code e605591410618 = 2804614666170 := by decide
theorem cert_e605591410618 : check e605591410618 [[],[]] .smaller = true := by decide
def e605591410646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605591410646 : Closed e605591410646 ∧ code e605591410646 = 2804614666198 := by decide
theorem cert_e605591410646 : check e605591410646 [[],[]] .smaller = true := by decide
def e605591410650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605591410650 : Closed e605591410650 ∧ code e605591410650 = 2804614666202 := by decide
theorem cert_e605591410650 : check e605591410650 [[],[]] .smaller = true := by decide
def e605591410666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 4) (.var 0)) (.var 0)))))))))
theorem wire_e605591410666 : Closed e605591410666 ∧ code e605591410666 = 2804614666218 := by decide
theorem cert_e605591410666 : check e605591410666 [[],[]] .three = true := by decide
def e605591411086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e605591411086 : Closed e605591411086 ∧ code e605591411086 = 2804614666638 := by decide
theorem cert_e605591411086 : check e605591411086 [[],[]] .smaller = true := by decide
def e605591411134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 4))))))))))
theorem wire_e605591411134 : Closed e605591411134 ∧ code e605591411134 = 2804614666686 := by decide
theorem cert_e605591411134 : check e605591411134 [[],[]] .three = true := by decide
def e605591411142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e605591411142 : Closed e605591411142 ∧ code e605591411142 = 2804614666694 := by decide
theorem cert_e605591411142 : check e605591411142 [[],[]] .smaller = true := by decide
def e605591411166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605591411166 : Closed e605591411166 ∧ code e605591411166 = 2804614666718 := by decide
theorem cert_e605591411166 : check e605591411166 [[],[]] .smaller = true := by decide
def e605591411182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e605591411182 : Closed e605591411182 ∧ code e605591411182 = 2804614666734 := by decide
theorem cert_e605591411182 : check e605591411182 [[],[]] .smaller = true := by decide
def e605591411190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605591411190 : Closed e605591411190 ∧ code e605591411190 = 2804614666742 := by decide
theorem cert_e605591411190 : check e605591411190 [[],[]] .smaller = true := by decide
def e605591411194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 4) (.var 0))))))))))
theorem wire_e605591411194 : Closed e605591411194 ∧ code e605591411194 = 2804614666746 := by decide
theorem cert_e605591411194 : check e605591411194 [[],[]] .three = true := by decide
def e605591411910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e605591411910 : Closed e605591411910 ∧ code e605591411910 = 2804614667462 := by decide
theorem cert_e605591411910 : check e605591411910 [[],[]] .smaller = true := by decide
def e605591411934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605591411934 : Closed e605591411934 ∧ code e605591411934 = 2804614667486 := by decide
theorem cert_e605591411934 : check e605591411934 [[],[]] .smaller = true := by decide
def e605591411950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e605591411950 : Closed e605591411950 ∧ code e605591411950 = 2804614667502 := by decide
theorem cert_e605591411950 : check e605591411950 [[],[]] .smaller = true := by decide
def e605591411958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e605591411958 : Closed e605591411958 ∧ code e605591411958 = 2804614667510 := by decide
theorem cert_e605591411958 : check e605591411958 [[],[]] .smaller = true := by decide
def e605591411962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605591411962 : Closed e605591411962 ∧ code e605591411962 = 2804614667514 := by decide
theorem cert_e605591411962 : check e605591411962 [[],[]] .smaller = true := by decide
def e605591412334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e605591412334 : Closed e605591412334 ∧ code e605591412334 = 2804614667886 := by decide
theorem cert_e605591412334 : check e605591412334 [[],[]] .smaller = true := by decide
def e605591412342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e605591412342 : Closed e605591412342 ∧ code e605591412342 = 2804614667894 := by decide
theorem cert_e605591412342 : check e605591412342 [[],[]] .smaller = true := by decide
def e605591412346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e605591412346 : Closed e605591412346 ∧ code e605591412346 = 2804614667898 := by decide
theorem cert_e605591412346 : check e605591412346 [[],[]] .smaller = true := by decide
def e605591412534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605591412534 : Closed e605591412534 ∧ code e605591412534 = 2804614668086 := by decide
theorem cert_e605591412534 : check e605591412534 [[],[]] .smaller = true := by decide
def e605591412538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605591412538 : Closed e605591412538 ∧ code e605591412538 = 2804614668090 := by decide
theorem cert_e605591412538 : check e605591412538 [[],[]] .smaller = true := by decide
def e605591412634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 4) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591412634 : Closed e605591412634 ∧ code e605591412634 = 2804614668186 := by decide
theorem cert_e605591412634 : check e605591412634 [[],[]] .three = true := by decide
def e605591423838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e605591423838 : Closed e605591423838 ∧ code e605591423838 = 2804614679390 := by decide
theorem cert_e605591423838 : check e605591423838 [[],[]] .three = true := by decide
def e605591423866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e605591423866 : Closed e605591423866 ∧ code e605591423866 = 2804614679418 := by decide
theorem cert_e605591423866 : check e605591423866 [[],[]] .three = true := by decide
def e605591423978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e605591423978 : Closed e605591423978 ∧ code e605591423978 = 2804614679530 := by decide
theorem cert_e605591423978 : check e605591423978 [[],[]] .three = true := by decide
def e605591424222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e605591424222 : Closed e605591424222 ∧ code e605591424222 = 2804614679774 := by decide
theorem cert_e605591424222 : check e605591424222 [[],[]] .three = true := by decide
def e605591424250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e605591424250 : Closed e605591424250 ∧ code e605591424250 = 2804614679802 := by decide
theorem cert_e605591424250 : check e605591424250 [[],[]] .three = true := by decide
def e605591424922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591424922 : Closed e605591424922 ∧ code e605591424922 = 2804614680474 := by decide
theorem cert_e605591424922 : check e605591424922 [[],[]] .three = true := by decide
def e605592701806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605592701806 : Closed e605592701806 ∧ code e605592701806 = 2804615957358 := by decide
theorem cert_e605592701806 : check e605592701806 [[],[]] .smaller = true := by decide
def e605592701814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605592701814 : Closed e605592701814 ∧ code e605592701814 = 2804615957366 := by decide
theorem cert_e605592701814 : check e605592701814 [[],[]] .smaller = true := by decide
def e605592701870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605592701870 : Closed e605592701870 ∧ code e605592701870 = 2804615957422 := by decide
theorem cert_e605592701870 : check e605592701870 [[],[]] .smaller = true := by decide
def e605592701882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605592701882 : Closed e605592701882 ∧ code e605592701882 = 2804615957434 := by decide
theorem cert_e605592701882 : check e605592701882 [[],[]] .smaller = true := by decide
def e605592701910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605592701910 : Closed e605592701910 ∧ code e605592701910 = 2804615957462 := by decide
theorem cert_e605592701910 : check e605592701910 [[],[]] .smaller = true := by decide
def e605592701914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605592701914 : Closed e605592701914 ∧ code e605592701914 = 2804615957466 := by decide
theorem cert_e605592701914 : check e605592701914 [[],[]] .smaller = true := by decide
end Blc.Floor41
