import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605594380254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 3)))))))))
theorem wire_e605594380254 : Closed e605594380254 ∧ code e605594380254 = 2804617635806 := by decide
theorem cert_e605594380254 : check e605594380254 [[],[]] .three = true := by decide
def e605594382574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605594382574 : Closed e605594382574 ∧ code e605594382574 = 2804617638126 := by decide
theorem cert_e605594382574 : check e605594382574 [[],[]] .smaller = true := by decide
def e605594382582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605594382582 : Closed e605594382582 ∧ code e605594382582 = 2804617638134 := by decide
theorem cert_e605594382582 : check e605594382582 [[],[]] .smaller = true := by decide
def e605594383062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605594383062 : Closed e605594383062 ∧ code e605594383062 = 2804617638614 := by decide
theorem cert_e605594383062 : check e605594383062 [[],[]] .smaller = true := by decide
def e605594383066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605594383066 : Closed e605594383066 ∧ code e605594383066 = 2804617638618 := by decide
theorem cert_e605594383066 : check e605594383066 [[],[]] .smaller = true := by decide
def e605594383082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605594383082 : Closed e605594383082 ∧ code e605594383082 = 2804617638634 := by decide
theorem cert_e605594383082 : check e605594383082 [[],[]] .smaller = true := by decide
def e605594383158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605594383158 : Closed e605594383158 ∧ code e605594383158 = 2804617638710 := by decide
theorem cert_e605594383158 : check e605594383158 [[],[]] .smaller = true := by decide
def e605594383162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605594383162 : Closed e605594383162 ∧ code e605594383162 = 2804617638714 := by decide
theorem cert_e605594383162 : check e605594383162 [[],[]] .smaller = true := by decide
def e605594383258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605594383258 : Closed e605594383258 ∧ code e605594383258 = 2804617638810 := by decide
theorem cert_e605594383258 : check e605594383258 [[],[]] .smaller = true := by decide
def e605594384502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605594384502 : Closed e605594384502 ∧ code e605594384502 = 2804617640054 := by decide
theorem cert_e605594384502 : check e605594384502 [[],[]] .three = true := by decide
def e605594384746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605594384746 : Closed e605594384746 ∧ code e605594384746 = 2804617640298 := by decide
theorem cert_e605594384746 : check e605594384746 [[],[]] .three = true := by decide
def e605594384794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605594384794 : Closed e605594384794 ∧ code e605594384794 = 2804617640346 := by decide
theorem cert_e605594384794 : check e605594384794 [[],[]] .three = true := by decide
def e605594384862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 3)))))))))
theorem wire_e605594384862 : Closed e605594384862 ∧ code e605594384862 = 2804617640414 := by decide
theorem cert_e605594384862 : check e605594384862 [[],[]] .three = true := by decide
def e605594384886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 3) (.var 1)))))))))
theorem wire_e605594384886 : Closed e605594384886 ∧ code e605594384886 = 2804617640438 := by decide
theorem cert_e605594384886 : check e605594384886 [[],[]] .three = true := by decide
def e605594457966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e605594457966 : Closed e605594457966 ∧ code e605594457966 = 2804617713518 := by decide
theorem cert_e605594457966 : check e605594457966 [[],[]] .three = true := by decide
def e605594457974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e605594457974 : Closed e605594457974 ∧ code e605594457974 = 2804617713526 := by decide
theorem cert_e605594457974 : check e605594457974 [[],[]] .three = true := by decide
def e605594458038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e605594458038 : Closed e605594458038 ∧ code e605594458038 = 2804617713590 := by decide
theorem cert_e605594458038 : check e605594458038 [[],[]] .three = true := by decide
def e605594459374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e605594459374 : Closed e605594459374 ∧ code e605594459374 = 2804617714926 := by decide
theorem cert_e605594459374 : check e605594459374 [[],[]] .three = true := by decide
def e605594459382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e605594459382 : Closed e605594459382 ∧ code e605594459382 = 2804617714934 := by decide
theorem cert_e605594459382 : check e605594459382 [[],[]] .three = true := by decide
def e605594459766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e605594459766 : Closed e605594459766 ∧ code e605594459766 = 2804617715318 := by decide
theorem cert_e605594459766 : check e605594459766 [[],[]] .three = true := by decide
def e605594474158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605594474158 : Closed e605594474158 ∧ code e605594474158 = 2804617729710 := by decide
theorem cert_e605594474158 : check e605594474158 [[],[]] .three = true := by decide
def e605594474166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e605594474166 : Closed e605594474166 ∧ code e605594474166 = 2804617729718 := by decide
theorem cert_e605594474166 : check e605594474166 [[],[]] .three = true := by decide
def e605594474170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605594474170 : Closed e605594474170 ∧ code e605594474170 = 2804617729722 := by decide
theorem cert_e605594474170 : check e605594474170 [[],[]] .three = true := by decide
def e605594474198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e605594474198 : Closed e605594474198 ∧ code e605594474198 = 2804617729750 := by decide
theorem cert_e605594474198 : check e605594474198 [[],[]] .three = true := by decide
def e605594474202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e605594474202 : Closed e605594474202 ∧ code e605594474202 = 2804617729754 := by decide
theorem cert_e605594474202 : check e605594474202 [[],[]] .three = true := by decide
def e605594474218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605594474218 : Closed e605594474218 ∧ code e605594474218 = 2804617729770 := by decide
theorem cert_e605594474218 : check e605594474218 [[],[]] .three = true := by decide
def e605594474326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605594474326 : Closed e605594474326 ∧ code e605594474326 = 2804617729878 := by decide
theorem cert_e605594474326 : check e605594474326 [[],[]] .three = true := by decide
def e605594474330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605594474330 : Closed e605594474330 ∧ code e605594474330 = 2804617729882 := by decide
theorem cert_e605594474330 : check e605594474330 [[],[]] .three = true := by decide
def e605594474346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605594474346 : Closed e605594474346 ∧ code e605594474346 = 2804617729898 := by decide
theorem cert_e605594474346 : check e605594474346 [[],[]] .three = true := by decide
def e605594474410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605594474410 : Closed e605594474410 ∧ code e605594474410 = 2804617729962 := by decide
theorem cert_e605594474410 : check e605594474410 [[],[]] .three = true := by decide
def e605594474926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605594474926 : Closed e605594474926 ∧ code e605594474926 = 2804617730478 := by decide
theorem cert_e605594474926 : check e605594474926 [[],[]] .three = true := by decide
def e605594474934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e605594474934 : Closed e605594474934 ∧ code e605594474934 = 2804617730486 := by decide
theorem cert_e605594474934 : check e605594474934 [[],[]] .three = true := by decide
def e605594474938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605594474938 : Closed e605594474938 ∧ code e605594474938 = 2804617730490 := by decide
theorem cert_e605594474938 : check e605594474938 [[],[]] .three = true := by decide
def e605594474966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e605594474966 : Closed e605594474966 ∧ code e605594474966 = 2804617730518 := by decide
theorem cert_e605594474966 : check e605594474966 [[],[]] .three = true := by decide
def e605594474970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e605594474970 : Closed e605594474970 ∧ code e605594474970 = 2804617730522 := by decide
theorem cert_e605594474970 : check e605594474970 [[],[]] .three = true := by decide
def e605594474986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605594474986 : Closed e605594474986 ∧ code e605594474986 = 2804617730538 := by decide
theorem cert_e605594474986 : check e605594474986 [[],[]] .three = true := by decide
def e605594475118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605594475118 : Closed e605594475118 ∧ code e605594475118 = 2804617730670 := by decide
theorem cert_e605594475118 : check e605594475118 [[],[]] .three = true := by decide
def e605594475126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605594475126 : Closed e605594475126 ∧ code e605594475126 = 2804617730678 := by decide
theorem cert_e605594475126 : check e605594475126 [[],[]] .three = true := by decide
def e605594475130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605594475130 : Closed e605594475130 ∧ code e605594475130 = 2804617730682 := by decide
theorem cert_e605594475130 : check e605594475130 [[],[]] .three = true := by decide
def e605594475318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605594475318 : Closed e605594475318 ∧ code e605594475318 = 2804617730870 := by decide
theorem cert_e605594475318 : check e605594475318 [[],[]] .three = true := by decide
def e605594475322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605594475322 : Closed e605594475322 ∧ code e605594475322 = 2804617730874 := by decide
theorem cert_e605594475322 : check e605594475322 [[],[]] .three = true := by decide
def e605594475418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605594475418 : Closed e605594475418 ∧ code e605594475418 = 2804617730970 := by decide
theorem cert_e605594475418 : check e605594475418 [[],[]] .three = true := by decide
def e605594475734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605594475734 : Closed e605594475734 ∧ code e605594475734 = 2804617731286 := by decide
theorem cert_e605594475734 : check e605594475734 [[],[]] .three = true := by decide
def e605594475738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605594475738 : Closed e605594475738 ∧ code e605594475738 = 2804617731290 := by decide
theorem cert_e605594475738 : check e605594475738 [[],[]] .three = true := by decide
def e605594475754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605594475754 : Closed e605594475754 ∧ code e605594475754 = 2804617731306 := by decide
theorem cert_e605594475754 : check e605594475754 [[],[]] .three = true := by decide
def e605594475830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605594475830 : Closed e605594475830 ∧ code e605594475830 = 2804617731382 := by decide
theorem cert_e605594475830 : check e605594475830 [[],[]] .three = true := by decide
def e605594475834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605594475834 : Closed e605594475834 ∧ code e605594475834 = 2804617731386 := by decide
theorem cert_e605594475834 : check e605594475834 [[],[]] .three = true := by decide
def e605594475930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605594475930 : Closed e605594475930 ∧ code e605594475930 = 2804617731482 := by decide
theorem cert_e605594475930 : check e605594475930 [[],[]] .three = true := by decide
def e605594475998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e605594475998 : Closed e605594475998 ∧ code e605594475998 = 2804617731550 := by decide
theorem cert_e605594475998 : check e605594475998 [[],[]] .three = true := by decide
def e605594476014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e605594476014 : Closed e605594476014 ∧ code e605594476014 = 2804617731566 := by decide
theorem cert_e605594476014 : check e605594476014 [[],[]] .three = true := by decide
def e605594476138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605594476138 : Closed e605594476138 ∧ code e605594476138 = 2804617731690 := by decide
theorem cert_e605594476138 : check e605594476138 [[],[]] .three = true := by decide
def e605594476186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605594476186 : Closed e605594476186 ∧ code e605594476186 = 2804617731738 := by decide
theorem cert_e605594476186 : check e605594476186 [[],[]] .three = true := by decide
def e605594476254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e605594476254 : Closed e605594476254 ∧ code e605594476254 = 2804617731806 := by decide
theorem cert_e605594476254 : check e605594476254 [[],[]] .three = true := by decide
def e605594476278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e605594476278 : Closed e605594476278 ∧ code e605594476278 = 2804617731830 := by decide
theorem cert_e605594476278 : check e605594476278 [[],[]] .three = true := by decide
def e605594476398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e605594476398 : Closed e605594476398 ∧ code e605594476398 = 2804617731950 := by decide
theorem cert_e605594476398 : check e605594476398 [[],[]] .three = true := by decide
def e605594476406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e605594476406 : Closed e605594476406 ∧ code e605594476406 = 2804617731958 := by decide
theorem cert_e605594476406 : check e605594476406 [[],[]] .three = true := by decide
def e605594477022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605594477022 : Closed e605594477022 ∧ code e605594477022 = 2804617732574 := by decide
theorem cert_e605594477022 : check e605594477022 [[],[]] .three = true := by decide
def e605594477038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e605594477038 : Closed e605594477038 ∧ code e605594477038 = 2804617732590 := by decide
theorem cert_e605594477038 : check e605594477038 [[],[]] .three = true := by decide
def e605594477046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605594477046 : Closed e605594477046 ∧ code e605594477046 = 2804617732598 := by decide
theorem cert_e605594477046 : check e605594477046 [[],[]] .three = true := by decide
def e605594477998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605594477998 : Closed e605594477998 ∧ code e605594477998 = 2804617733550 := by decide
theorem cert_e605594477998 : check e605594477998 [[],[]] .three = true := by decide
def e605594478006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605594478006 : Closed e605594478006 ∧ code e605594478006 = 2804617733558 := by decide
theorem cert_e605594478006 : check e605594478006 [[],[]] .three = true := by decide
def e605594478010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605594478010 : Closed e605594478010 ∧ code e605594478010 = 2804617733562 := by decide
theorem cert_e605594478010 : check e605594478010 [[],[]] .three = true := by decide
def e605594478038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605594478038 : Closed e605594478038 ∧ code e605594478038 = 2804617733590 := by decide
theorem cert_e605594478038 : check e605594478038 [[],[]] .three = true := by decide
def e605594478042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605594478042 : Closed e605594478042 ∧ code e605594478042 = 2804617733594 := by decide
theorem cert_e605594478042 : check e605594478042 [[],[]] .three = true := by decide
def e605594478058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605594478058 : Closed e605594478058 ∧ code e605594478058 = 2804617733610 := by decide
theorem cert_e605594478058 : check e605594478058 [[],[]] .three = true := by decide
def e605594478190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605594478190 : Closed e605594478190 ∧ code e605594478190 = 2804617733742 := by decide
theorem cert_e605594478190 : check e605594478190 [[],[]] .three = true := by decide
def e605594478198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605594478198 : Closed e605594478198 ∧ code e605594478198 = 2804617733750 := by decide
theorem cert_e605594478198 : check e605594478198 [[],[]] .three = true := by decide
def e605594478202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605594478202 : Closed e605594478202 ∧ code e605594478202 = 2804617733754 := by decide
theorem cert_e605594478202 : check e605594478202 [[],[]] .three = true := by decide
def e605594478390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605594478390 : Closed e605594478390 ∧ code e605594478390 = 2804617733942 := by decide
theorem cert_e605594478390 : check e605594478390 [[],[]] .three = true := by decide
def e605594478394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605594478394 : Closed e605594478394 ∧ code e605594478394 = 2804617733946 := by decide
theorem cert_e605594478394 : check e605594478394 [[],[]] .three = true := by decide
def e605594478490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605594478490 : Closed e605594478490 ∧ code e605594478490 = 2804617734042 := by decide
theorem cert_e605594478490 : check e605594478490 [[],[]] .three = true := by decide
def e605594480878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605594480878 : Closed e605594480878 ∧ code e605594480878 = 2804617736430 := by decide
theorem cert_e605594480878 : check e605594480878 [[],[]] .three = true := by decide
def e605594480886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605594480886 : Closed e605594480886 ∧ code e605594480886 = 2804617736438 := by decide
theorem cert_e605594480886 : check e605594480886 [[],[]] .three = true := by decide
def e605594481366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605594481366 : Closed e605594481366 ∧ code e605594481366 = 2804617736918 := by decide
theorem cert_e605594481366 : check e605594481366 [[],[]] .three = true := by decide
def e605594481370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605594481370 : Closed e605594481370 ∧ code e605594481370 = 2804617736922 := by decide
theorem cert_e605594481370 : check e605594481370 [[],[]] .three = true := by decide
def e605594481386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605594481386 : Closed e605594481386 ∧ code e605594481386 = 2804617736938 := by decide
theorem cert_e605594481386 : check e605594481386 [[],[]] .three = true := by decide
def e605594481462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605594481462 : Closed e605594481462 ∧ code e605594481462 = 2804617737014 := by decide
theorem cert_e605594481462 : check e605594481462 [[],[]] .three = true := by decide
def e605594481466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605594481466 : Closed e605594481466 ∧ code e605594481466 = 2804617737018 := by decide
theorem cert_e605594481466 : check e605594481466 [[],[]] .three = true := by decide
def e605594481562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605594481562 : Closed e605594481562 ∧ code e605594481562 = 2804617737114 := by decide
theorem cert_e605594481562 : check e605594481562 [[],[]] .three = true := by decide
def e605594481630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e605594481630 : Closed e605594481630 ∧ code e605594481630 = 2804617737182 := by decide
theorem cert_e605594481630 : check e605594481630 [[],[]] .three = true := by decide
def e605594481646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e605594481646 : Closed e605594481646 ∧ code e605594481646 = 2804617737198 := by decide
theorem cert_e605594481646 : check e605594481646 [[],[]] .three = true := by decide
def e605594482806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605594482806 : Closed e605594482806 ∧ code e605594482806 = 2804617738358 := by decide
theorem cert_e605594482806 : check e605594482806 [[],[]] .three = true := by decide
def e605594483050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605594483050 : Closed e605594483050 ∧ code e605594483050 = 2804617738602 := by decide
theorem cert_e605594483050 : check e605594483050 [[],[]] .three = true := by decide
def e605594483098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605594483098 : Closed e605594483098 ∧ code e605594483098 = 2804617738650 := by decide
theorem cert_e605594483098 : check e605594483098 [[],[]] .three = true := by decide
def e605594483166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e605594483166 : Closed e605594483166 ∧ code e605594483166 = 2804617738718 := by decide
theorem cert_e605594483166 : check e605594483166 [[],[]] .three = true := by decide
def e605594483190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e605594483190 : Closed e605594483190 ∧ code e605594483190 = 2804617738742 := by decide
theorem cert_e605594483190 : check e605594483190 [[],[]] .three = true := by decide
def e605594483950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e605594483950 : Closed e605594483950 ∧ code e605594483950 = 2804617739502 := by decide
theorem cert_e605594483950 : check e605594483950 [[],[]] .three = true := by decide
def e605594483958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e605594483958 : Closed e605594483958 ∧ code e605594483958 = 2804617739510 := by decide
theorem cert_e605594483958 : check e605594483958 [[],[]] .three = true := by decide
def e605599632238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605599632238 : Closed e605599632238 ∧ code e605599632238 = 2804622887790 := by decide
theorem cert_e605599632238 : check e605599632238 [[],[]] .smaller = true := by decide
def e605599632246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605599632246 : Closed e605599632246 ∧ code e605599632246 = 2804622887798 := by decide
theorem cert_e605599632246 : check e605599632246 [[],[]] .smaller = true := by decide
def e605599632302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605599632302 : Closed e605599632302 ∧ code e605599632302 = 2804622887854 := by decide
theorem cert_e605599632302 : check e605599632302 [[],[]] .smaller = true := by decide
def e605599632314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605599632314 : Closed e605599632314 ∧ code e605599632314 = 2804622887866 := by decide
theorem cert_e605599632314 : check e605599632314 [[],[]] .smaller = true := by decide
def e605599632342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605599632342 : Closed e605599632342 ∧ code e605599632342 = 2804622887894 := by decide
theorem cert_e605599632342 : check e605599632342 [[],[]] .smaller = true := by decide
def e605599632346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605599632346 : Closed e605599632346 ∧ code e605599632346 = 2804622887898 := by decide
theorem cert_e605599632346 : check e605599632346 [[],[]] .smaller = true := by decide
def e605599632622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605599632622 : Closed e605599632622 ∧ code e605599632622 = 2804622888174 := by decide
theorem cert_e605599632622 : check e605599632622 [[],[]] .smaller = true := by decide
def e605599632630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605599632630 : Closed e605599632630 ∧ code e605599632630 = 2804622888182 := by decide
theorem cert_e605599632630 : check e605599632630 [[],[]] .smaller = true := by decide
def e605599633006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605599633006 : Closed e605599633006 ∧ code e605599633006 = 2804622888558 := by decide
theorem cert_e605599633006 : check e605599633006 [[],[]] .smaller = true := by decide
def e605599633018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605599633018 : Closed e605599633018 ∧ code e605599633018 = 2804622888570 := by decide
theorem cert_e605599633018 : check e605599633018 [[],[]] .smaller = true := by decide
def e605599633206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605599633206 : Closed e605599633206 ∧ code e605599633206 = 2804622888758 := by decide
theorem cert_e605599633206 : check e605599633206 [[],[]] .smaller = true := by decide
def e605599633210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605599633210 : Closed e605599633210 ∧ code e605599633210 = 2804622888762 := by decide
theorem cert_e605599633210 : check e605599633210 [[],[]] .smaller = true := by decide
def e605601584494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e605601584494 : Closed e605601584494 ∧ code e605601584494 = 2804624840046 := by decide
theorem cert_e605601584494 : check e605601584494 [[],[]] .chain = true := by decide
def e605601584502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e605601584502 : Closed e605601584502 ∧ code e605601584502 = 2804624840054 := by decide
theorem cert_e605601584502 : check e605601584502 [[],[]] .chain = true := by decide
def e605601584558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e605601584558 : Closed e605601584558 ∧ code e605601584558 = 2804624840110 := by decide
theorem cert_e605601584558 : check e605601584558 [[],[]] .chain = true := by decide
def e605601584570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e605601584570 : Closed e605601584570 ∧ code e605601584570 = 2804624840122 := by decide
theorem cert_e605601584570 : check e605601584570 [[],[]] .chain = true := by decide
def e605601584598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e605601584598 : Closed e605601584598 ∧ code e605601584598 = 2804624840150 := by decide
theorem cert_e605601584598 : check e605601584598 [[],[]] .chain = true := by decide
def e605601584602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e605601584602 : Closed e605601584602 ∧ code e605601584602 = 2804624840154 := by decide
theorem cert_e605601584602 : check e605601584602 [[],[]] .chain = true := by decide
def e605601584814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e605601584814 : Closed e605601584814 ∧ code e605601584814 = 2804624840366 := by decide
theorem cert_e605601584814 : check e605601584814 [[],[]] .chain = true := by decide
def e605601584826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e605601584826 : Closed e605601584826 ∧ code e605601584826 = 2804624840378 := by decide
theorem cert_e605601584826 : check e605601584826 [[],[]] .chain = true := by decide
def e605601584874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e605601584874 : Closed e605601584874 ∧ code e605601584874 = 2804624840426 := by decide
theorem cert_e605601584874 : check e605601584874 [[],[]] .chain = true := by decide
def e605601584982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e605601584982 : Closed e605601584982 ∧ code e605601584982 = 2804624840534 := by decide
theorem cert_e605601584982 : check e605601584982 [[],[]] .chain = true := by decide
def e605601584986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e605601584986 : Closed e605601584986 ∧ code e605601584986 = 2804624840538 := by decide
theorem cert_e605601584986 : check e605601584986 [[],[]] .chain = true := by decide
def e605601585002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e605601585002 : Closed e605601585002 ∧ code e605601585002 = 2804624840554 := by decide
theorem cert_e605601585002 : check e605601585002 [[],[]] .chain = true := by decide
def e605601585838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e605601585838 : Closed e605601585838 ∧ code e605601585838 = 2804624841390 := by decide
theorem cert_e605601585838 : check e605601585838 [[],[]] .chain = true := by decide
def e605601585850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e605601585850 : Closed e605601585850 ∧ code e605601585850 = 2804624841402 := by decide
theorem cert_e605601585850 : check e605601585850 [[],[]] .chain = true := by decide
def e605601585898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e605601585898 : Closed e605601585898 ∧ code e605601585898 = 2804624841450 := by decide
theorem cert_e605601585898 : check e605601585898 [[],[]] .chain = true := by decide
def e605601586090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e605601586090 : Closed e605601586090 ∧ code e605601586090 = 2804624841642 := by decide
theorem cert_e605601586090 : check e605601586090 [[],[]] .chain = true := by decide
def e605601586518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e605601586518 : Closed e605601586518 ∧ code e605601586518 = 2804624842070 := by decide
theorem cert_e605601586518 : check e605601586518 [[],[]] .chain = true := by decide
def e605601586522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e605601586522 : Closed e605601586522 ∧ code e605601586522 = 2804624842074 := by decide
theorem cert_e605601586522 : check e605601586522 [[],[]] .chain = true := by decide
def e605601586538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e605601586538 : Closed e605601586538 ∧ code e605601586538 = 2804624842090 := by decide
theorem cert_e605601586538 : check e605601586538 [[],[]] .chain = true := by decide
def e605601586602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e605601586602 : Closed e605601586602 ∧ code e605601586602 = 2804624842154 := by decide
theorem cert_e605601586602 : check e605601586602 [[],[]] .chain = true := by decide
def e605601589934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e605601589934 : Closed e605601589934 ∧ code e605601589934 = 2804624845486 := by decide
theorem cert_e605601589934 : check e605601589934 [[],[]] .chain = true := by decide
def e605601589946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e605601589946 : Closed e605601589946 ∧ code e605601589946 = 2804624845498 := by decide
theorem cert_e605601589946 : check e605601589946 [[],[]] .chain = true := by decide
def e605601589994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e605601589994 : Closed e605601589994 ∧ code e605601589994 = 2804624845546 := by decide
theorem cert_e605601589994 : check e605601589994 [[],[]] .chain = true := by decide
def e605601590186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e605601590186 : Closed e605601590186 ∧ code e605601590186 = 2804624845738 := by decide
theorem cert_e605601590186 : check e605601590186 [[],[]] .chain = true := by decide
def e605601590954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e605601590954 : Closed e605601590954 ∧ code e605601590954 = 2804624846506 := by decide
theorem cert_e605601590954 : check e605601590954 [[],[]] .chain = true := by decide
def e605601592662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e605601592662 : Closed e605601592662 ∧ code e605601592662 = 2804624848214 := by decide
theorem cert_e605601592662 : check e605601592662 [[],[]] .chain = true := by decide
def e605601592666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e605601592666 : Closed e605601592666 ∧ code e605601592666 = 2804624848218 := by decide
theorem cert_e605601592666 : check e605601592666 [[],[]] .chain = true := by decide
def e605601592682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e605601592682 : Closed e605601592682 ∧ code e605601592682 = 2804624848234 := by decide
theorem cert_e605601592682 : check e605601592682 [[],[]] .chain = true := by decide
def e605601592746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e605601592746 : Closed e605601592746 ∧ code e605601592746 = 2804624848298 := by decide
theorem cert_e605601592746 : check e605601592746 [[],[]] .chain = true := by decide
def e605601593002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e605601593002 : Closed e605601593002 ∧ code e605601593002 = 2804624848554 := by decide
theorem cert_e605601593002 : check e605601593002 [[],[]] .chain = true := by decide
def e605601596782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e605601596782 : Closed e605601596782 ∧ code e605601596782 = 2804624852334 := by decide
theorem cert_e605601596782 : check e605601596782 [[],[]] .chain = true := by decide
def e605601596790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e605601596790 : Closed e605601596790 ∧ code e605601596790 = 2804624852342 := by decide
theorem cert_e605601596790 : check e605601596790 [[],[]] .chain = true := by decide
def e605601596846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e605601596846 : Closed e605601596846 ∧ code e605601596846 = 2804624852398 := by decide
theorem cert_e605601596846 : check e605601596846 [[],[]] .chain = true := by decide
def e605601596858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e605601596858 : Closed e605601596858 ∧ code e605601596858 = 2804624852410 := by decide
theorem cert_e605601596858 : check e605601596858 [[],[]] .chain = true := by decide
def e605601596886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e605601596886 : Closed e605601596886 ∧ code e605601596886 = 2804624852438 := by decide
theorem cert_e605601596886 : check e605601596886 [[],[]] .chain = true := by decide
def e605601596890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e605601596890 : Closed e605601596890 ∧ code e605601596890 = 2804624852442 := by decide
theorem cert_e605601596890 : check e605601596890 [[],[]] .chain = true := by decide
def e605601601262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e605601601262 : Closed e605601601262 ∧ code e605601601262 = 2804624856814 := by decide
theorem cert_e605601601262 : check e605601601262 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601601390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e605601601390 : Closed e605601601390 ∧ code e605601601390 = 2804624856942 := by decide
theorem cert_e605601601390 : check e605601601390 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e605601601398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e605601601398 : Closed e605601601398 ∧ code e605601601398 = 2804624856950 := by decide
theorem cert_e605601601398 : check e605601601398 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605601602414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e605601602414 : Closed e605601602414 ∧ code e605601602414 = 2804624857966 := by decide
theorem cert_e605601602414 : check e605601602414 [[],[]] .chain = true := by decide
def e605601602422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e605601602422 : Closed e605601602422 ∧ code e605601602422 = 2804624857974 := by decide
theorem cert_e605601602422 : check e605601602422 [[],[]] .chain = true := by decide
def e605601602486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e605601602486 : Closed e605601602486 ∧ code e605601602486 = 2804624858038 := by decide
theorem cert_e605601602486 : check e605601602486 [[],[]] .chain = true := by decide
def e605601602926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e605601602926 : Closed e605601602926 ∧ code e605601602926 = 2804624858478 := by decide
theorem cert_e605601602926 : check e605601602926 [[],[]] .chain = true := by decide
def e605601602934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e605601602934 : Closed e605601602934 ∧ code e605601602934 = 2804624858486 := by decide
theorem cert_e605601602934 : check e605601602934 [[],[]] .chain = true := by decide
def e605601602990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e605601602990 : Closed e605601602990 ∧ code e605601602990 = 2804624858542 := by decide
theorem cert_e605601602990 : check e605601602990 [[],[]] .chain = true := by decide
def e605601603002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e605601603002 : Closed e605601603002 ∧ code e605601603002 = 2804624858554 := by decide
theorem cert_e605601603002 : check e605601603002 [[],[]] .chain = true := by decide
def e605601603030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e605601603030 : Closed e605601603030 ∧ code e605601603030 = 2804624858582 := by decide
theorem cert_e605601603030 : check e605601603030 [[],[]] .chain = true := by decide
def e605601603034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e605601603034 : Closed e605601603034 ∧ code e605601603034 = 2804624858586 := by decide
theorem cert_e605601603034 : check e605601603034 [[],[]] .chain = true := by decide
def e605601603254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e605601603254 : Closed e605601603254 ∧ code e605601603254 = 2804624858806 := by decide
theorem cert_e605601603254 : check e605601603254 [[],[]] .chain = true := by decide
def e605601603286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e605601603286 : Closed e605601603286 ∧ code e605601603286 = 2804624858838 := by decide
theorem cert_e605601603286 : check e605601603286 [[],[]] .chain = true := by decide
def e605601603290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e605601603290 : Closed e605601603290 ∧ code e605601603290 = 2804624858842 := by decide
theorem cert_e605601603290 : check e605601603290 [[],[]] .chain = true := by decide
def e605601609070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e605601609070 : Closed e605601609070 ∧ code e605601609070 = 2804624864622 := by decide
theorem cert_e605601609070 : check e605601609070 [[],[]] .chain = true := by decide
def e605601609078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e605601609078 : Closed e605601609078 ∧ code e605601609078 = 2804624864630 := by decide
theorem cert_e605601609078 : check e605601609078 [[],[]] .chain = true := by decide
def e605601609134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e605601609134 : Closed e605601609134 ∧ code e605601609134 = 2804624864686 := by decide
theorem cert_e605601609134 : check e605601609134 [[],[]] .chain = true := by decide
def e605601609146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e605601609146 : Closed e605601609146 ∧ code e605601609146 = 2804624864698 := by decide
theorem cert_e605601609146 : check e605601609146 [[],[]] .chain = true := by decide
def e605601609174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e605601609174 : Closed e605601609174 ∧ code e605601609174 = 2804624864726 := by decide
theorem cert_e605601609174 : check e605601609174 [[],[]] .chain = true := by decide
def e605601609178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e605601609178 : Closed e605601609178 ∧ code e605601609178 = 2804624864730 := by decide
theorem cert_e605601609178 : check e605601609178 [[],[]] .chain = true := by decide
def e605601609390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e605601609390 : Closed e605601609390 ∧ code e605601609390 = 2804624864942 := by decide
theorem cert_e605601609390 : check e605601609390 [[],[]] .chain = true := by decide
def e605601609402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e605601609402 : Closed e605601609402 ∧ code e605601609402 = 2804624864954 := by decide
theorem cert_e605601609402 : check e605601609402 [[],[]] .chain = true := by decide
def e605601609450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e605601609450 : Closed e605601609450 ∧ code e605601609450 = 2804624865002 := by decide
theorem cert_e605601609450 : check e605601609450 [[],[]] .chain = true := by decide
end Blc.Floor41
