import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e601486762346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601486762346 : Closed e601486762346 ∧ code e601486762346 = 2800510017898 := by decide
theorem cert_e601486762346 : check e601486762346 [[]] .width = true := by decide
def e601486762394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601486762394 : Closed e601486762394 ∧ code e601486762394 = 2800510017946 := by decide
theorem cert_e601486762394 : check e601486762394 [[]] .width = true := by decide
def e601486766278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601486766278 : Closed e601486766278 ∧ code e601486766278 = 2800510021830 := by decide
theorem cert_e601486766278 : check e601486766278 [[]] .width = true := by decide
def e601486768154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601486768154 : Closed e601486768154 ∧ code e601486768154 = 2800510023706 := by decide
theorem cert_e601486768154 : check e601486768154 [[]] .width = true := by decide
def e601487179802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601487179802 : Closed e601487179802 ∧ code e601487179802 = 2800510435354 := by decide
theorem cert_e601487179802 : check e601487179802 [[]] .width = true := by decide
def e601487179894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601487179894 : Closed e601487179894 ∧ code e601487179894 = 2800510435446 := by decide
theorem cert_e601487179894 : check e601487179894 [[]] .width = true := by decide
def e601487180138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601487180138 : Closed e601487180138 ∧ code e601487180138 = 2800510435690 := by decide
theorem cert_e601487180138 : check e601487180138 [[]] .width = true := by decide
def e601487180186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601487180186 : Closed e601487180186 ∧ code e601487180186 = 2800510435738 := by decide
theorem cert_e601487180186 : check e601487180186 [[]] .width = true := by decide
def e601487180270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e601487180270 : Closed e601487180270 ∧ code e601487180270 = 2800510435822 := by decide
theorem cert_e601487180270 : check e601487180270 [[]] .width = true := by decide
def e601487181194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e601487181194 : Closed e601487181194 ∧ code e601487181194 = 2800510436746 := by decide
theorem cert_e601487181194 : check e601487181194 [[]] .width = true := by decide
def e601487181218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e601487181218 : Closed e601487181218 ∧ code e601487181218 = 2800510436770 := by decide
theorem cert_e601487181218 : check e601487181218 [[]] .width = true := by decide
def e601487181238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e601487181238 : Closed e601487181238 ∧ code e601487181238 = 2800510436790 := by decide
theorem cert_e601487181238 : check e601487181238 [[]] .width = true := by decide
def e601487181270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e601487181270 : Closed e601487181270 ∧ code e601487181270 = 2800510436822 := by decide
theorem cert_e601487181270 : check e601487181270 [[]] .width = true := by decide
def e601487181274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e601487181274 : Closed e601487181274 ∧ code e601487181274 = 2800510436826 := by decide
theorem cert_e601487181274 : check e601487181274 [[]] .width = true := by decide
def e601487181326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e601487181326 : Closed e601487181326 ∧ code e601487181326 = 2800510436878 := by decide
theorem cert_e601487181326 : check e601487181326 [[]] .width = true := by decide
def e601487181338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601487181338 : Closed e601487181338 ∧ code e601487181338 = 2800510436890 := by decide
theorem cert_e601487181338 : check e601487181338 [[]] .width = true := by decide
def e601487181410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e601487181410 : Closed e601487181410 ∧ code e601487181410 = 2800510436962 := by decide
theorem cert_e601487181410 : check e601487181410 [[]] .width = true := by decide
def e601487181430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e601487181430 : Closed e601487181430 ∧ code e601487181430 = 2800510436982 := by decide
theorem cert_e601487181430 : check e601487181430 [[]] .width = true := by decide
def e601487181622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e601487181622 : Closed e601487181622 ∧ code e601487181622 = 2800510437174 := by decide
theorem cert_e601487181622 : check e601487181622 [[]] .width = true := by decide
def e601487181626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e601487181626 : Closed e601487181626 ∧ code e601487181626 = 2800510437178 := by decide
theorem cert_e601487181626 : check e601487181626 [[]] .width = true := by decide
def e601487185322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e601487185322 : Closed e601487185322 ∧ code e601487185322 = 2800510440874 := by decide
theorem cert_e601487185322 : check e601487185322 [[]] .width = true := by decide
def e601487185418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e601487185418 : Closed e601487185418 ∧ code e601487185418 = 2800510440970 := by decide
theorem cert_e601487185418 : check e601487185418 [[]] .width = true := by decide
def e601487185514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e601487185514 : Closed e601487185514 ∧ code e601487185514 = 2800510441066 := by decide
theorem cert_e601487185514 : check e601487185514 [[]] .width = true := by decide
def e601487185538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e601487185538 : Closed e601487185538 ∧ code e601487185538 = 2800510441090 := by decide
theorem cert_e601487185538 : check e601487185538 [[]] .width = true := by decide
def e601487185562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e601487185562 : Closed e601487185562 ∧ code e601487185562 = 2800510441114 := by decide
theorem cert_e601487185562 : check e601487185562 [[]] .width = true := by decide
def e601487185946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601487185946 : Closed e601487185946 ∧ code e601487185946 = 2800510441498 := by decide
theorem cert_e601487185946 : check e601487185946 [[]] .width = true := by decide
def e601487186038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e601487186038 : Closed e601487186038 ∧ code e601487186038 = 2800510441590 := by decide
theorem cert_e601487186038 : check e601487186038 [[]] .width = true := by decide
def e601487186282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e601487186282 : Closed e601487186282 ∧ code e601487186282 = 2800510441834 := by decide
theorem cert_e601487186282 : check e601487186282 [[]] .width = true := by decide
def e601487186306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e601487186306 : Closed e601487186306 ∧ code e601487186306 = 2800510441858 := by decide
theorem cert_e601487186306 : check e601487186306 [[]] .width = true := by decide
def e601487186330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e601487186330 : Closed e601487186330 ∧ code e601487186330 = 2800510441882 := by decide
theorem cert_e601487186330 : check e601487186330 [[]] .width = true := by decide
def e601487341594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601487341594 : Closed e601487341594 ∧ code e601487341594 = 2800510597146 := by decide
theorem cert_e601487341594 : check e601487341594 [[]] .width = true := by decide
def e601487425734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601487425734 : Closed e601487425734 ∧ code e601487425734 = 2800510681286 := by decide
theorem cert_e601487425734 : check e601487425734 [[]] .width = true := by decide
def e601487532058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601487532058 : Closed e601487532058 ∧ code e601487532058 = 2800510787610 := by decide
theorem cert_e601487532058 : check e601487532058 [[]] .width = true := by decide
def e601487532150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601487532150 : Closed e601487532150 ∧ code e601487532150 = 2800510787702 := by decide
theorem cert_e601487532150 : check e601487532150 [[]] .width = true := by decide
def e601487532394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601487532394 : Closed e601487532394 ∧ code e601487532394 = 2800510787946 := by decide
theorem cert_e601487532394 : check e601487532394 [[]] .width = true := by decide
def e601487532442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601487532442 : Closed e601487532442 ∧ code e601487532442 = 2800510787994 := by decide
theorem cert_e601487532442 : check e601487532442 [[]] .width = true := by decide
def e601487542298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601487542298 : Closed e601487542298 ∧ code e601487542298 = 2800510797850 := by decide
theorem cert_e601487542298 : check e601487542298 [[]] .width = true := by decide
def e601487548442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601487548442 : Closed e601487548442 ∧ code e601487548442 = 2800510803994 := by decide
theorem cert_e601487548442 : check e601487548442 [[]] .width = true := by decide
def e601487548534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601487548534 : Closed e601487548534 ∧ code e601487548534 = 2800510804086 := by decide
theorem cert_e601487548534 : check e601487548534 [[]] .width = true := by decide
def e601487548778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601487548778 : Closed e601487548778 ∧ code e601487548778 = 2800510804330 := by decide
theorem cert_e601487548778 : check e601487548778 [[]] .width = true := by decide
def e601487548826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601487548826 : Closed e601487548826 ∧ code e601487548826 = 2800510804378 := by decide
theorem cert_e601487548826 : check e601487548826 [[]] .width = true := by decide
def e601487552710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601487552710 : Closed e601487552710 ∧ code e601487552710 = 2800510808262 := by decide
theorem cert_e601487552710 : check e601487552710 [[]] .width = true := by decide
def e601487554586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601487554586 : Closed e601487554586 ∧ code e601487554586 = 2800510810138 := by decide
theorem cert_e601487554586 : check e601487554586 [[]] .width = true := by decide
def e601487562778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601487562778 : Closed e601487562778 ∧ code e601487562778 = 2800510818330 := by decide
theorem cert_e601487562778 : check e601487562778 [[]] .width = true := by decide
def e601487704090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601487704090 : Closed e601487704090 ∧ code e601487704090 = 2800510959642 := by decide
theorem cert_e601487704090 : check e601487704090 [[]] .width = true := by decide
def e601487704182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601487704182 : Closed e601487704182 ∧ code e601487704182 = 2800510959734 := by decide
theorem cert_e601487704182 : check e601487704182 [[]] .width = true := by decide
def e601487704426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601487704426 : Closed e601487704426 ∧ code e601487704426 = 2800510959978 := by decide
theorem cert_e601487704426 : check e601487704426 [[]] .width = true := by decide
def e601487704474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601487704474 : Closed e601487704474 ∧ code e601487704474 = 2800510960026 := by decide
theorem cert_e601487704474 : check e601487704474 [[]] .width = true := by decide
def e601487704558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e601487704558 : Closed e601487704558 ∧ code e601487704558 = 2800510960110 := by decide
theorem cert_e601487704558 : check e601487704558 [[]] .width = true := by decide
def e601487705482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e601487705482 : Closed e601487705482 ∧ code e601487705482 = 2800510961034 := by decide
theorem cert_e601487705482 : check e601487705482 [[]] .width = true := by decide
def e601487705506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e601487705506 : Closed e601487705506 ∧ code e601487705506 = 2800510961058 := by decide
theorem cert_e601487705506 : check e601487705506 [[]] .width = true := by decide
def e601487705526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e601487705526 : Closed e601487705526 ∧ code e601487705526 = 2800510961078 := by decide
theorem cert_e601487705526 : check e601487705526 [[]] .width = true := by decide
def e601487705558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e601487705558 : Closed e601487705558 ∧ code e601487705558 = 2800510961110 := by decide
theorem cert_e601487705558 : check e601487705558 [[]] .width = true := by decide
def e601487705562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e601487705562 : Closed e601487705562 ∧ code e601487705562 = 2800510961114 := by decide
theorem cert_e601487705562 : check e601487705562 [[]] .width = true := by decide
def e601487705614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e601487705614 : Closed e601487705614 ∧ code e601487705614 = 2800510961166 := by decide
theorem cert_e601487705614 : check e601487705614 [[]] .width = true := by decide
def e601487705626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601487705626 : Closed e601487705626 ∧ code e601487705626 = 2800510961178 := by decide
theorem cert_e601487705626 : check e601487705626 [[]] .width = true := by decide
def e601487705698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e601487705698 : Closed e601487705698 ∧ code e601487705698 = 2800510961250 := by decide
theorem cert_e601487705698 : check e601487705698 [[]] .width = true := by decide
def e601487705718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e601487705718 : Closed e601487705718 ∧ code e601487705718 = 2800510961270 := by decide
theorem cert_e601487705718 : check e601487705718 [[]] .width = true := by decide
def e601487705910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e601487705910 : Closed e601487705910 ∧ code e601487705910 = 2800510961462 := by decide
theorem cert_e601487705910 : check e601487705910 [[]] .width = true := by decide
def e601487705914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e601487705914 : Closed e601487705914 ∧ code e601487705914 = 2800510961466 := by decide
theorem cert_e601487705914 : check e601487705914 [[]] .width = true := by decide
def e601487709610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e601487709610 : Closed e601487709610 ∧ code e601487709610 = 2800510965162 := by decide
theorem cert_e601487709610 : check e601487709610 [[]] .width = true := by decide
def e601487709706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e601487709706 : Closed e601487709706 ∧ code e601487709706 = 2800510965258 := by decide
theorem cert_e601487709706 : check e601487709706 [[]] .width = true := by decide
def e601487709802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e601487709802 : Closed e601487709802 ∧ code e601487709802 = 2800510965354 := by decide
theorem cert_e601487709802 : check e601487709802 [[]] .width = true := by decide
def e601487709826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e601487709826 : Closed e601487709826 ∧ code e601487709826 = 2800510965378 := by decide
theorem cert_e601487709826 : check e601487709826 [[]] .width = true := by decide
def e601487709850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e601487709850 : Closed e601487709850 ∧ code e601487709850 = 2800510965402 := by decide
theorem cert_e601487709850 : check e601487709850 [[]] .width = true := by decide
def e601487710234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601487710234 : Closed e601487710234 ∧ code e601487710234 = 2800510965786 := by decide
theorem cert_e601487710234 : check e601487710234 [[]] .width = true := by decide
def e601487710326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e601487710326 : Closed e601487710326 ∧ code e601487710326 = 2800510965878 := by decide
theorem cert_e601487710326 : check e601487710326 [[]] .width = true := by decide
def e601487710570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e601487710570 : Closed e601487710570 ∧ code e601487710570 = 2800510966122 := by decide
theorem cert_e601487710570 : check e601487710570 [[]] .width = true := by decide
def e601487710594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e601487710594 : Closed e601487710594 ∧ code e601487710594 = 2800510966146 := by decide
theorem cert_e601487710594 : check e601487710594 [[]] .width = true := by decide
def e601487710618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e601487710618 : Closed e601487710618 ∧ code e601487710618 = 2800510966170 := by decide
theorem cert_e601487710618 : check e601487710618 [[]] .width = true := by decide
def e601488603162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601488603162 : Closed e601488603162 ∧ code e601488603162 = 2800511858714 := by decide
theorem cert_e601488603162 : check e601488603162 [[]] .width = true := by decide
def e601488996378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601488996378 : Closed e601488996378 ∧ code e601488996378 = 2800512251930 := by decide
theorem cert_e601488996378 : check e601488996378 [[]] .width = true := by decide
def e601489008666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601489008666 : Closed e601489008666 ∧ code e601489008666 = 2800512264218 := by decide
theorem cert_e601489008666 : check e601489008666 [[]] .width = true := by decide
def e601489260742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601489260742 : Closed e601489260742 ∧ code e601489260742 = 2800512516294 := by decide
theorem cert_e601489260742 : check e601489260742 [[]] .width = true := by decide
def e601489359046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601489359046 : Closed e601489359046 ∧ code e601489359046 = 2800512614598 := by decide
theorem cert_e601489359046 : check e601489359046 [[]] .width = true := by decide
def e601489979418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601489979418 : Closed e601489979418 ∧ code e601489979418 = 2800513234970 := by decide
theorem cert_e601489979418 : check e601489979418 [[]] .width = true := by decide
def e601490120730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601490120730 : Closed e601490120730 ∧ code e601490120730 = 2800513376282 := by decide
theorem cert_e601490120730 : check e601490120730 [[]] .width = true := by decide
def e601490120822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601490120822 : Closed e601490120822 ∧ code e601490120822 = 2800513376374 := by decide
theorem cert_e601490120822 : check e601490120822 [[]] .width = true := by decide
def e601490121066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601490121066 : Closed e601490121066 ∧ code e601490121066 = 2800513376618 := by decide
theorem cert_e601490121066 : check e601490121066 [[]] .width = true := by decide
def e601490121114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601490121114 : Closed e601490121114 ∧ code e601490121114 = 2800513376666 := by decide
theorem cert_e601490121114 : check e601490121114 [[]] .width = true := by decide
def e601490157766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601490157766 : Closed e601490157766 ∧ code e601490157766 = 2800513413318 := by decide
theorem cert_e601490157766 : check e601490157766 [[]] .width = true := by decide
def e601490163738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601490163738 : Closed e601490163738 ∧ code e601490163738 = 2800513419290 := by decide
theorem cert_e601490163738 : check e601490163738 [[]] .width = true := by decide
def e601490169882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601490169882 : Closed e601490169882 ∧ code e601490169882 = 2800513425434 := by decide
theorem cert_e601490169882 : check e601490169882 [[]] .width = true := by decide
def e601490169974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601490169974 : Closed e601490169974 ∧ code e601490169974 = 2800513425526 := by decide
theorem cert_e601490169974 : check e601490169974 [[]] .width = true := by decide
def e601490170218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601490170218 : Closed e601490170218 ∧ code e601490170218 = 2800513425770 := by decide
theorem cert_e601490170218 : check e601490170218 [[]] .width = true := by decide
def e601490170266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601490170266 : Closed e601490170266 ∧ code e601490170266 = 2800513425818 := by decide
theorem cert_e601490170266 : check e601490170266 [[]] .width = true := by decide
def e601490174150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601490174150 : Closed e601490174150 ∧ code e601490174150 = 2800513429702 := by decide
theorem cert_e601490174150 : check e601490174150 [[]] .width = true := by decide
def e601490176026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601490176026 : Closed e601490176026 ∧ code e601490176026 = 2800513431578 := by decide
theorem cert_e601490176026 : check e601490176026 [[]] .width = true := by decide
def e601490288838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601490288838 : Closed e601490288838 ∧ code e601490288838 = 2800513544390 := by decide
theorem cert_e601490288838 : check e601490288838 [[]] .width = true := by decide
def e601490313414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601490313414 : Closed e601490313414 ∧ code e601490313414 = 2800513568966 := by decide
theorem cert_e601490313414 : check e601490313414 [[]] .width = true := by decide
def e601490335770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601490335770 : Closed e601490335770 ∧ code e601490335770 = 2800513591322 := by decide
theorem cert_e601490335770 : check e601490335770 [[]] .width = true := by decide
def e601490360346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601490360346 : Closed e601490360346 ∧ code e601490360346 = 2800513615898 := by decide
theorem cert_e601490360346 : check e601490360346 [[]] .width = true := by decide
def e601490366490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601490366490 : Closed e601490366490 ∧ code e601490366490 = 2800513622042 := by decide
theorem cert_e601490366490 : check e601490366490 [[]] .width = true := by decide
def e601490366582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601490366582 : Closed e601490366582 ∧ code e601490366582 = 2800513622134 := by decide
theorem cert_e601490366582 : check e601490366582 [[]] .width = true := by decide
def e601490366826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601490366826 : Closed e601490366826 ∧ code e601490366826 = 2800513622378 := by decide
theorem cert_e601490366826 : check e601490366826 [[]] .width = true := by decide
def e601490366874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601490366874 : Closed e601490366874 ∧ code e601490366874 = 2800513622426 := by decide
theorem cert_e601490366874 : check e601490366874 [[]] .width = true := by decide
def e601490370758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601490370758 : Closed e601490370758 ∧ code e601490370758 = 2800513626310 := by decide
theorem cert_e601490370758 : check e601490370758 [[]] .width = true := by decide
def e601490372634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601490372634 : Closed e601490372634 ∧ code e601490372634 = 2800513628186 := by decide
theorem cert_e601490372634 : check e601490372634 [[]] .width = true := by decide
def e601490378950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601490378950 : Closed e601490378950 ∧ code e601490378950 = 2800513634502 := by decide
theorem cert_e601490378950 : check e601490378950 [[]] .width = true := by decide
def e601490384922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601490384922 : Closed e601490384922 ∧ code e601490384922 = 2800513640474 := by decide
theorem cert_e601490384922 : check e601490384922 [[]] .width = true := by decide
def e601490702534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601490702534 : Closed e601490702534 ∧ code e601490702534 = 2800513958086 := by decide
theorem cert_e601490702534 : check e601490702534 [[]] .width = true := by decide
def e601490907162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601490907162 : Closed e601490907162 ∧ code e601490907162 = 2800514162714 := by decide
theorem cert_e601490907162 : check e601490907162 [[]] .width = true := by decide
def e601490907254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601490907254 : Closed e601490907254 ∧ code e601490907254 = 2800514162806 := by decide
theorem cert_e601490907254 : check e601490907254 [[]] .width = true := by decide
def e601490907498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601490907498 : Closed e601490907498 ∧ code e601490907498 = 2800514163050 := by decide
theorem cert_e601490907498 : check e601490907498 [[]] .width = true := by decide
def e601490907546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601490907546 : Closed e601490907546 ∧ code e601490907546 = 2800514163098 := by decide
theorem cert_e601490907546 : check e601490907546 [[]] .width = true := by decide
def e601490944198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601490944198 : Closed e601490944198 ∧ code e601490944198 = 2800514199750 := by decide
theorem cert_e601490944198 : check e601490944198 [[]] .width = true := by decide
def e601490950170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601490950170 : Closed e601490950170 ∧ code e601490950170 = 2800514205722 := by decide
theorem cert_e601490950170 : check e601490950170 [[]] .width = true := by decide
def e601490956314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601490956314 : Closed e601490956314 ∧ code e601490956314 = 2800514211866 := by decide
theorem cert_e601490956314 : check e601490956314 [[]] .width = true := by decide
def e601490956406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601490956406 : Closed e601490956406 ∧ code e601490956406 = 2800514211958 := by decide
theorem cert_e601490956406 : check e601490956406 [[]] .width = true := by decide
def e601490956650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601490956650 : Closed e601490956650 ∧ code e601490956650 = 2800514212202 := by decide
theorem cert_e601490956650 : check e601490956650 [[]] .width = true := by decide
def e601490956698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601490956698 : Closed e601490956698 ∧ code e601490956698 = 2800514212250 := by decide
theorem cert_e601490956698 : check e601490956698 [[]] .width = true := by decide
def e601490960582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601490960582 : Closed e601490960582 ∧ code e601490960582 = 2800514216134 := by decide
theorem cert_e601490960582 : check e601490960582 [[]] .width = true := by decide
def e601490962458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601490962458 : Closed e601490962458 ∧ code e601490962458 = 2800514218010 := by decide
theorem cert_e601490962458 : check e601490962458 [[]] .width = true := by decide
def e601491374106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601491374106 : Closed e601491374106 ∧ code e601491374106 = 2800514629658 := by decide
theorem cert_e601491374106 : check e601491374106 [[]] .width = true := by decide
def e601491374198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601491374198 : Closed e601491374198 ∧ code e601491374198 = 2800514629750 := by decide
theorem cert_e601491374198 : check e601491374198 [[]] .width = true := by decide
def e601491374442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601491374442 : Closed e601491374442 ∧ code e601491374442 = 2800514629994 := by decide
theorem cert_e601491374442 : check e601491374442 [[]] .width = true := by decide
def e601491374490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601491374490 : Closed e601491374490 ∧ code e601491374490 = 2800514630042 := by decide
theorem cert_e601491374490 : check e601491374490 [[]] .width = true := by decide
def e601491374574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e601491374574 : Closed e601491374574 ∧ code e601491374574 = 2800514630126 := by decide
theorem cert_e601491374574 : check e601491374574 [[]] .width = true := by decide
def e601491375498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e601491375498 : Closed e601491375498 ∧ code e601491375498 = 2800514631050 := by decide
theorem cert_e601491375498 : check e601491375498 [[]] .width = true := by decide
def e601491375522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e601491375522 : Closed e601491375522 ∧ code e601491375522 = 2800514631074 := by decide
theorem cert_e601491375522 : check e601491375522 [[]] .width = true := by decide
def e601491375542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e601491375542 : Closed e601491375542 ∧ code e601491375542 = 2800514631094 := by decide
theorem cert_e601491375542 : check e601491375542 [[]] .width = true := by decide
def e601491375574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e601491375574 : Closed e601491375574 ∧ code e601491375574 = 2800514631126 := by decide
theorem cert_e601491375574 : check e601491375574 [[]] .width = true := by decide
def e601491375578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e601491375578 : Closed e601491375578 ∧ code e601491375578 = 2800514631130 := by decide
theorem cert_e601491375578 : check e601491375578 [[]] .width = true := by decide
def e601491375630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e601491375630 : Closed e601491375630 ∧ code e601491375630 = 2800514631182 := by decide
theorem cert_e601491375630 : check e601491375630 [[]] .width = true := by decide
def e601491375642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601491375642 : Closed e601491375642 ∧ code e601491375642 = 2800514631194 := by decide
theorem cert_e601491375642 : check e601491375642 [[]] .width = true := by decide
def e601491375714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e601491375714 : Closed e601491375714 ∧ code e601491375714 = 2800514631266 := by decide
theorem cert_e601491375714 : check e601491375714 [[]] .width = true := by decide
def e601491375734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e601491375734 : Closed e601491375734 ∧ code e601491375734 = 2800514631286 := by decide
theorem cert_e601491375734 : check e601491375734 [[]] .width = true := by decide
def e601491375926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e601491375926 : Closed e601491375926 ∧ code e601491375926 = 2800514631478 := by decide
theorem cert_e601491375926 : check e601491375926 [[]] .width = true := by decide
def e601491375930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e601491375930 : Closed e601491375930 ∧ code e601491375930 = 2800514631482 := by decide
theorem cert_e601491375930 : check e601491375930 [[]] .width = true := by decide
def e601491379626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e601491379626 : Closed e601491379626 ∧ code e601491379626 = 2800514635178 := by decide
theorem cert_e601491379626 : check e601491379626 [[]] .width = true := by decide
def e601491379722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e601491379722 : Closed e601491379722 ∧ code e601491379722 = 2800514635274 := by decide
theorem cert_e601491379722 : check e601491379722 [[]] .width = true := by decide
def e601491379818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e601491379818 : Closed e601491379818 ∧ code e601491379818 = 2800514635370 := by decide
theorem cert_e601491379818 : check e601491379818 [[]] .width = true := by decide
def e601491379842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e601491379842 : Closed e601491379842 ∧ code e601491379842 = 2800514635394 := by decide
theorem cert_e601491379842 : check e601491379842 [[]] .width = true := by decide
def e601491379866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e601491379866 : Closed e601491379866 ∧ code e601491379866 = 2800514635418 := by decide
theorem cert_e601491379866 : check e601491379866 [[]] .width = true := by decide
def e601491380250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601491380250 : Closed e601491380250 ∧ code e601491380250 = 2800514635802 := by decide
theorem cert_e601491380250 : check e601491380250 [[]] .width = true := by decide
def e601491380342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e601491380342 : Closed e601491380342 ∧ code e601491380342 = 2800514635894 := by decide
theorem cert_e601491380342 : check e601491380342 [[]] .width = true := by decide
def e601491380586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e601491380586 : Closed e601491380586 ∧ code e601491380586 = 2800514636138 := by decide
theorem cert_e601491380586 : check e601491380586 [[]] .width = true := by decide
def e601491380610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e601491380610 : Closed e601491380610 ∧ code e601491380610 = 2800514636162 := by decide
theorem cert_e601491380610 : check e601491380610 [[]] .width = true := by decide
def e601491380634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e601491380634 : Closed e601491380634 ∧ code e601491380634 = 2800514636186 := by decide
theorem cert_e601491380634 : check e601491380634 [[]] .width = true := by decide
def e601491730630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601491730630 : Closed e601491730630 ∧ code e601491730630 = 2800514986182 := by decide
theorem cert_e601491730630 : check e601491730630 [[]] .width = true := by decide
def e601491755206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601491755206 : Closed e601491755206 ∧ code e601491755206 = 2800515010758 := by decide
theorem cert_e601491755206 : check e601491755206 [[]] .width = true := by decide
def e601492043802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601492043802 : Closed e601492043802 ∧ code e601492043802 = 2800515299354 := by decide
theorem cert_e601492043802 : check e601492043802 [[]] .width = true := by decide
def e601492078790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601492078790 : Closed e601492078790 ∧ code e601492078790 = 2800515334342 := by decide
theorem cert_e601492078790 : check e601492078790 [[]] .width = true := by decide
def e601492129818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601492129818 : Closed e601492129818 ∧ code e601492129818 = 2800515385370 := by decide
theorem cert_e601492129818 : check e601492129818 [[]] .width = true := by decide
def e601492135962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601492135962 : Closed e601492135962 ∧ code e601492135962 = 2800515391514 := by decide
theorem cert_e601492135962 : check e601492135962 [[]] .width = true := by decide
def e601492136054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601492136054 : Closed e601492136054 ∧ code e601492136054 = 2800515391606 := by decide
private def t_e601492136054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e601492136054 : ¬ IsSelfInterpreter e601492136054 :=
  wSource (t := t_e601492136054) (replay_sound (ps := []) (t := e601492136054) (by decide)) (by decide)
def e601492136298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601492136298 : Closed e601492136298 ∧ code e601492136298 = 2800515391850 := by decide
private def t_e601492136298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e601492136298 : ¬ IsSelfInterpreter e601492136298 :=
  wSource (t := t_e601492136298) (replay_sound (ps := []) (t := e601492136298) (by decide)) (by decide)
def e601492136346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601492136346 : Closed e601492136346 ∧ code e601492136346 = 2800515391898 := by decide
private def t_e601492136346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e601492136346 : ¬ IsSelfInterpreter e601492136346 :=
  wSource (t := t_e601492136346) (replay_sound (ps := []) (t := e601492136346) (by decide)) (by decide)
def e601492140230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601492140230 : Closed e601492140230 ∧ code e601492140230 = 2800515395782 := by decide
theorem cert_e601492140230 : check e601492140230 [[]] .width = true := by decide
def e601492142106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601492142106 : Closed e601492142106 ∧ code e601492142106 = 2800515397658 := by decide
theorem cert_e601492142106 : check e601492142106 [[]] .width = true := by decide
def e601492148422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601492148422 : Closed e601492148422 ∧ code e601492148422 = 2800515403974 := by decide
theorem cert_e601492148422 : check e601492148422 [[]] .width = true := by decide
def e601492154394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601492154394 : Closed e601492154394 ∧ code e601492154394 = 2800515409946 := by decide
theorem cert_e601492154394 : check e601492154394 [[]] .width = true := by decide
def e601492160538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601492160538 : Closed e601492160538 ∧ code e601492160538 = 2800515416090 := by decide
theorem cert_e601492160538 : check e601492160538 [[]] .width = true := by decide
def e601492160630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601492160630 : Closed e601492160630 ∧ code e601492160630 = 2800515416182 := by decide
theorem cert_e601492160630 : check e601492160630 [[]] .width = true := by decide
def e601492160874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601492160874 : Closed e601492160874 ∧ code e601492160874 = 2800515416426 := by decide
theorem cert_e601492160874 : check e601492160874 [[]] .width = true := by decide
def e601492160922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601492160922 : Closed e601492160922 ∧ code e601492160922 = 2800515416474 := by decide
theorem cert_e601492160922 : check e601492160922 [[]] .width = true := by decide
def e601492161006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e601492161006 : Closed e601492161006 ∧ code e601492161006 = 2800515416558 := by decide
private def t_e601492161006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem cert_e601492161006 : ¬ IsSelfInterpreter e601492161006 :=
  wSource (t := t_e601492161006) (replay_sound (ps := []) (t := e601492161006) (by decide)) (by decide)
def e601492161930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e601492161930 : Closed e601492161930 ∧ code e601492161930 = 2800515417482 := by decide
theorem cert_e601492161930 : check e601492161930 [[]] .width = true := by decide
def e601492161954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e601492161954 : Closed e601492161954 ∧ code e601492161954 = 2800515417506 := by decide
theorem cert_e601492161954 : check e601492161954 [[]] .width = true := by decide
def e601492161974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e601492161974 : Closed e601492161974 ∧ code e601492161974 = 2800515417526 := by decide
theorem cert_e601492161974 : check e601492161974 [[]] .width = true := by decide
end Blc.Floor41
