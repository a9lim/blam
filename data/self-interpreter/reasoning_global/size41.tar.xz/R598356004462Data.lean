import R598356004462V0
import R598356004462K0
import R598356004462st0
import R598356004462st12
import R598356004462hs0
import R598356004462hs12
import CodeBridge
import Batch044
namespace Certgen.R598356004462
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 7,.lam 2,.app 3 6,.app 4 5,.var 0,.var 0,.var 0,.lam 8,.app 9 10,.var 0,.app 11 12,.var 0,.lam 13,.lam 14,.app 15 16,.var 1,.app 17 18,.var 0,.var 2]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (V0[i-0]?.getD [])
def K (i : Nat) : List Frame := (if i < 40 then (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD [])) else (if i < 60 then (K40[i-40]?.getD []) else (K60[i-60]?.getD [])))
def st (i : Nat) : AState := if i < 393 then (if i < 200 then (if i < 100 then (if i < 40 then (if i < 20 then (st0[i-0]?.getD entry) else (st20[i-20]?.getD entry)) else (if i < 60 then (st40[i-40]?.getD entry) else (if i < 80 then (st60[i-60]?.getD entry) else (st80[i-80]?.getD entry)))) else (if i < 140 then (if i < 120 then (st100[i-100]?.getD entry) else (st120[i-120]?.getD entry)) else (if i < 160 then (st140[i-140]?.getD entry) else (if i < 180 then (st160[i-160]?.getD entry) else (st180[i-180]?.getD entry))))) else (if i < 300 then (if i < 240 then (if i < 220 then (st200[i-200]?.getD entry) else (st220[i-220]?.getD entry)) else (if i < 260 then (st240[i-240]?.getD entry) else (if i < 280 then (st260[i-260]?.getD entry) else (st280[i-280]?.getD entry)))) else (if i < 340 then (if i < 320 then (st300[i-300]?.getD entry) else (st320[i-320]?.getD entry)) else (if i < 360 then (st340[i-340]?.getD entry) else (if i < 380 then (st360[i-360]?.getD entry) else (st380[i-380]?.getD entry)))))) else entry
def hs (i : Nat) : List Nat := (if i < 200 then (if i < 100 then (if i < 40 then (if i < 20 then (hs0[i-0]?.getD []) else (hs20[i-20]?.getD [])) else (if i < 60 then (hs40[i-40]?.getD []) else (if i < 80 then (hs60[i-60]?.getD []) else (hs80[i-80]?.getD [])))) else (if i < 140 then (if i < 120 then (hs100[i-100]?.getD []) else (hs120[i-120]?.getD [])) else (if i < 160 then (hs140[i-140]?.getD []) else (if i < 180 then (hs160[i-160]?.getD []) else (hs180[i-180]?.getD []))))) else (if i < 300 then (if i < 240 then (if i < 220 then (hs200[i-200]?.getD []) else (hs220[i-220]?.getD [])) else (if i < 260 then (hs240[i-240]?.getD []) else (if i < 280 then (hs260[i-260]?.getD []) else (hs280[i-280]?.getD [])))) else (if i < 340 then (if i < 320 then (hs300[i-300]?.getD []) else (hs320[i-320]?.getD [])) else (if i < 360 then (hs340[i-340]?.getD []) else (if i < 380 then (hs360[i-360]?.getD []) else (hs380[i-380]?.getD []))))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R598356004462
