import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605605455778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605605455778 : Closed e605605455778 ∧ code e605605455778 = 2804628711330 := by decide
theorem cert_e605605455778 : check e605605455778 [[],[]] .sourceHead = true := by decide
def e605605455790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e605605455790 : Closed e605605455790 ∧ code e605605455790 = 2804628711342 := by decide
theorem cert_e605605455790 : check e605605455790 [[],[]] .sourceHead = true := by decide
def e605605455802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e605605455802 : Closed e605605455802 ∧ code e605605455802 = 2804628711354 := by decide
theorem cert_e605605455802 : check e605605455802 [[],[]] .sourceHead = true := by decide
def e605605455898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605605455898 : Closed e605605455898 ∧ code e605605455898 = 2804628711450 := by decide
theorem cert_e605605455898 : check e605605455898 [[],[]] .sourceHead = true := by decide
def e605605455934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e605605455934 : Closed e605605455934 ∧ code e605605455934 = 2804628711486 := by decide
theorem cert_e605605455934 : check e605605455934 [[],[]] .sourceHead = true := by decide
def e605605455982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605605455982 : Closed e605605455982 ∧ code e605605455982 = 2804628711534 := by decide
theorem cert_e605605455982 : check e605605455982 [[],[]] .chain = true := by decide
def e605605455990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605605455990 : Closed e605605455990 ∧ code e605605455990 = 2804628711542 := by decide
theorem cert_e605605455990 : check e605605455990 [[],[]] .chain = true := by decide
def e605605455994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605605455994 : Closed e605605455994 ∧ code e605605455994 = 2804628711546 := by decide
theorem cert_e605605455994 : check e605605455994 [[],[]] .chain = true := by decide
def e605605456234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605605456234 : Closed e605605456234 ∧ code e605605456234 = 2804628711786 := by decide
theorem cert_e605605456234 : check e605605456234 [[],[]] .chain = true := by decide
def e605605456258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605605456258 : Closed e605605456258 ∧ code e605605456258 = 2804628711810 := by decide
theorem cert_e605605456258 : check e605605456258 [[],[]] .chain = true := by decide
def e605605456270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605605456270 : Closed e605605456270 ∧ code e605605456270 = 2804628711822 := by decide
theorem cert_e605605456270 : check e605605456270 [[],[]] .chain = true := by decide
def e605605456282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605605456282 : Closed e605605456282 ∧ code e605605456282 = 2804628711834 := by decide
theorem cert_e605605456282 : check e605605456282 [[],[]] .chain = true := by decide
def e605605456326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605605456326 : Closed e605605456326 ∧ code e605605456326 = 2804628711878 := by decide
theorem cert_e605605456326 : check e605605456326 [[],[]] .chain = true := by decide
def e605605456354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605605456354 : Closed e605605456354 ∧ code e605605456354 = 2804628711906 := by decide
theorem cert_e605605456354 : check e605605456354 [[],[]] .sourceHead = true := by decide
def e605605456366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e605605456366 : Closed e605605456366 ∧ code e605605456366 = 2804628711918 := by decide
theorem cert_e605605456366 : check e605605456366 [[],[]] .sourceHead = true := by decide
def e605605456950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e605605456950 : Closed e605605456950 ∧ code e605605456950 = 2804628712502 := by decide
theorem cert_e605605456950 : check e605605456950 [[],[]] .chain = true := by decide
def e605605456954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e605605456954 : Closed e605605456954 ∧ code e605605456954 = 2804628712506 := by decide
theorem cert_e605605456954 : check e605605456954 [[],[]] .chain = true := by decide
def e605605457094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e605605457094 : Closed e605605457094 ∧ code e605605457094 = 2804628712646 := by decide
theorem cert_e605605457094 : check e605605457094 [[],[]] .chain = true := by decide
def e605605457422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e605605457422 : Closed e605605457422 ∧ code e605605457422 = 2804628712974 := by decide
theorem cert_e605605457422 : check e605605457422 [[],[]] .sourceHead = true := by decide
def e605605457506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605605457506 : Closed e605605457506 ∧ code e605605457506 = 2804628713058 := by decide
theorem cert_e605605457506 : check e605605457506 [[],[]] .sourceHead = true := by decide
def e605605457518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e605605457518 : Closed e605605457518 ∧ code e605605457518 = 2804628713070 := by decide
theorem cert_e605605457518 : check e605605457518 [[],[]] .sourceHead = true := by decide
def e605605457530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e605605457530 : Closed e605605457530 ∧ code e605605457530 = 2804628713082 := by decide
theorem cert_e605605457530 : check e605605457530 [[],[]] .sourceHead = true := by decide
def e605605463998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e605605463998 : Closed e605605463998 ∧ code e605605463998 = 2804628719550 := by decide
theorem cert_e605605463998 : check e605605463998 [[],[]] .chain = true := by decide
def e605605464046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e605605464046 : Closed e605605464046 ∧ code e605605464046 = 2804628719598 := by decide
theorem cert_e605605464046 : check e605605464046 [[],[]] .chain = true := by decide
def e605605467870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605605467870 : Closed e605605467870 ∧ code e605605467870 = 2804628723422 := by decide
theorem cert_e605605467870 : check e605605467870 [[],[]] .chain = true := by decide
def e605605467894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605605467894 : Closed e605605467894 ∧ code e605605467894 = 2804628723446 := by decide
theorem cert_e605605467894 : check e605605467894 [[],[]] .chain = true := by decide
def e605605467998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605605467998 : Closed e605605467998 ∧ code e605605467998 = 2804628723550 := by decide
theorem cert_e605605467998 : check e605605467998 [[],[]] .chain = true := by decide
def e605605468026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605605468026 : Closed e605605468026 ∧ code e605605468026 = 2804628723578 := by decide
theorem cert_e605605468026 : check e605605468026 [[],[]] .chain = true := by decide
def e605605468118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605605468118 : Closed e605605468118 ∧ code e605605468118 = 2804628723670 := by decide
theorem cert_e605605468118 : check e605605468118 [[],[]] .chain = true := by decide
def e605605468122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605605468122 : Closed e605605468122 ∧ code e605605468122 = 2804628723674 := by decide
theorem cert_e605605468122 : check e605605468122 [[],[]] .chain = true := by decide
def e605605468638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605605468638 : Closed e605605468638 ∧ code e605605468638 = 2804628724190 := by decide
theorem cert_e605605468638 : check e605605468638 [[],[]] .chain = true := by decide
def e605605468662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605605468662 : Closed e605605468662 ∧ code e605605468662 = 2804628724214 := by decide
theorem cert_e605605468662 : check e605605468662 [[],[]] .chain = true := by decide
def e605605469406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605605469406 : Closed e605605469406 ∧ code e605605469406 = 2804628724958 := by decide
theorem cert_e605605469406 : check e605605469406 [[],[]] .chain = true := by decide
def e605605469434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605605469434 : Closed e605605469434 ∧ code e605605469434 = 2804628724986 := by decide
theorem cert_e605605469434 : check e605605469434 [[],[]] .chain = true := by decide
def e605605469758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e605605469758 : Closed e605605469758 ∧ code e605605469758 = 2804628725310 := by decide
theorem cert_e605605469758 : check e605605469758 [[],[]] .chain = true := by decide
def e605605469982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e605605469982 : Closed e605605469982 ∧ code e605605469982 = 2804628725534 := by decide
theorem cert_e605605469982 : check e605605469982 [[],[]] .chain = true := by decide
def e605605470006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605605470006 : Closed e605605470006 ∧ code e605605470006 = 2804628725558 := by decide
theorem cert_e605605470006 : check e605605470006 [[],[]] .chain = true := by decide
def e605605470010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605605470010 : Closed e605605470010 ∧ code e605605470010 = 2804628725562 := by decide
theorem cert_e605605470010 : check e605605470010 [[],[]] .chain = true := by decide
def e605605484206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605605484206 : Closed e605605484206 ∧ code e605605484206 = 2804628739758 := by decide
theorem cert_e605605484206 : check e605605484206 [[],[]] .chain = true := by decide
def e605605484218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605605484218 : Closed e605605484218 ∧ code e605605484218 = 2804628739770 := by decide
theorem cert_e605605484218 : check e605605484218 [[],[]] .chain = true := by decide
def e605605484266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605605484266 : Closed e605605484266 ∧ code e605605484266 = 2804628739818 := by decide
theorem cert_e605605484266 : check e605605484266 [[],[]] .chain = true := by decide
def e605605484458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605605484458 : Closed e605605484458 ∧ code e605605484458 = 2804628740010 := by decide
theorem cert_e605605484458 : check e605605484458 [[],[]] .chain = true := by decide
def e605605484590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605605484590 : Closed e605605484590 ∧ code e605605484590 = 2804628740142 := by decide
theorem cert_e605605484590 : check e605605484590 [[],[]] .chain = true := by decide
def e605605484782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605605484782 : Closed e605605484782 ∧ code e605605484782 = 2804628740334 := by decide
theorem cert_e605605484782 : check e605605484782 [[],[]] .chain = true := by decide
def e605605484790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605605484790 : Closed e605605484790 ∧ code e605605484790 = 2804628740342 := by decide
theorem cert_e605605484790 : check e605605484790 [[],[]] .chain = true := by decide
def e605605484974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605605484974 : Closed e605605484974 ∧ code e605605484974 = 2804628740526 := by decide
theorem cert_e605605484974 : check e605605484974 [[],[]] .chain = true := by decide
def e605605484986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605605484986 : Closed e605605484986 ∧ code e605605484986 = 2804628740538 := by decide
theorem cert_e605605484986 : check e605605484986 [[],[]] .chain = true := by decide
def e605605485034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605605485034 : Closed e605605485034 ∧ code e605605485034 = 2804628740586 := by decide
theorem cert_e605605485034 : check e605605485034 [[],[]] .chain = true := by decide
def e605605485166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605605485166 : Closed e605605485166 ∧ code e605605485166 = 2804628740718 := by decide
theorem cert_e605605485166 : check e605605485166 [[],[]] .chain = true := by decide
def e605605485178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605605485178 : Closed e605605485178 ∧ code e605605485178 = 2804628740730 := by decide
theorem cert_e605605485178 : check e605605485178 [[],[]] .chain = true := by decide
def e605605485342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605605485342 : Closed e605605485342 ∧ code e605605485342 = 2804628740894 := by decide
theorem cert_e605605485342 : check e605605485342 [[],[]] .chain = true := by decide
def e605605485442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e605605485442 : Closed e605605485442 ∧ code e605605485442 = 2804628740994 := by decide
theorem cert_e605605485442 : check e605605485442 [[],[]] .chain = true := by decide
def e605605485454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605605485454 : Closed e605605485454 ∧ code e605605485454 = 2804628741006 := by decide
theorem cert_e605605485454 : check e605605485454 [[],[]] .chain = true := by decide
def e605605485466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605605485466 : Closed e605605485466 ∧ code e605605485466 = 2804628741018 := by decide
theorem cert_e605605485466 : check e605605485466 [[],[]] .chain = true := by decide
def e605605485678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605605485678 : Closed e605605485678 ∧ code e605605485678 = 2804628741230 := by decide
theorem cert_e605605485678 : check e605605485678 [[],[]] .chain = true := by decide
def e605605485690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605605485690 : Closed e605605485690 ∧ code e605605485690 = 2804628741242 := by decide
theorem cert_e605605485690 : check e605605485690 [[],[]] .chain = true := by decide
def e605605485854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605605485854 : Closed e605605485854 ∧ code e605605485854 = 2804628741406 := by decide
theorem cert_e605605485854 : check e605605485854 [[],[]] .chain = true := by decide
def e605605486022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605605486022 : Closed e605605486022 ∧ code e605605486022 = 2804628741574 := by decide
theorem cert_e605605486022 : check e605605486022 [[],[]] .chain = true := by decide
def e605605486090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605605486090 : Closed e605605486090 ∧ code e605605486090 = 2804628741642 := by decide
theorem cert_e605605486090 : check e605605486090 [[],[]] .chain = true := by decide
def e605605486126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605605486126 : Closed e605605486126 ∧ code e605605486126 = 2804628741678 := by decide
theorem cert_e605605486126 : check e605605486126 [[],[]] .sourceHead = true := by decide
def e605605486134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605605486134 : Closed e605605486134 ∧ code e605605486134 = 2804628741686 := by decide
theorem cert_e605605486134 : check e605605486134 [[],[]] .chain = true := by decide
def e605605486138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605605486138 : Closed e605605486138 ∧ code e605605486138 = 2804628741690 := by decide
theorem cert_e605605486138 : check e605605486138 [[],[]] .chain = true := by decide
def e605605486186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605605486186 : Closed e605605486186 ∧ code e605605486186 = 2804628741738 := by decide
theorem cert_e605605486186 : check e605605486186 [[],[]] .chain = true := by decide
def e605605486210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e605605486210 : Closed e605605486210 ∧ code e605605486210 = 2804628741762 := by decide
theorem cert_e605605486210 : check e605605486210 [[],[]] .chain = true := by decide
def e605605486222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605605486222 : Closed e605605486222 ∧ code e605605486222 = 2804628741774 := by decide
theorem cert_e605605486222 : check e605605486222 [[],[]] .chain = true := by decide
def e605605486234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605605486234 : Closed e605605486234 ∧ code e605605486234 = 2804628741786 := by decide
theorem cert_e605605486234 : check e605605486234 [[],[]] .chain = true := by decide
def e605605486278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605605486278 : Closed e605605486278 ∧ code e605605486278 = 2804628741830 := by decide
theorem cert_e605605486278 : check e605605486278 [[],[]] .chain = true := by decide
def e605605486306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605605486306 : Closed e605605486306 ∧ code e605605486306 = 2804628741858 := by decide
theorem cert_e605605486306 : check e605605486306 [[],[]] .sourceHead = true := by decide
def e605605486318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 2))))))))
theorem wire_e605605486318 : Closed e605605486318 ∧ code e605605486318 = 2804628741870 := by decide
theorem cert_e605605486318 : check e605605486318 [[],[]] .sourceHead = true := by decide
def e605605487070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605605487070 : Closed e605605487070 ∧ code e605605487070 = 2804628742622 := by decide
theorem cert_e605605487070 : check e605605487070 [[],[]] .chain = true := by decide
def e605605487094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605605487094 : Closed e605605487094 ∧ code e605605487094 = 2804628742646 := by decide
theorem cert_e605605487094 : check e605605487094 [[],[]] .chain = true := by decide
def e605605488046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605605488046 : Closed e605605488046 ∧ code e605605488046 = 2804628743598 := by decide
theorem cert_e605605488046 : check e605605488046 [[],[]] .chain = true := by decide
def e605605488058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605605488058 : Closed e605605488058 ∧ code e605605488058 = 2804628743610 := by decide
theorem cert_e605605488058 : check e605605488058 [[],[]] .chain = true := by decide
def e605605488106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605605488106 : Closed e605605488106 ∧ code e605605488106 = 2804628743658 := by decide
theorem cert_e605605488106 : check e605605488106 [[],[]] .chain = true := by decide
def e605605488238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605605488238 : Closed e605605488238 ∧ code e605605488238 = 2804628743790 := by decide
theorem cert_e605605488238 : check e605605488238 [[],[]] .chain = true := by decide
def e605605488250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605605488250 : Closed e605605488250 ∧ code e605605488250 = 2804628743802 := by decide
theorem cert_e605605488250 : check e605605488250 [[],[]] .chain = true := by decide
def e605605488414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605605488414 : Closed e605605488414 ∧ code e605605488414 = 2804628743966 := by decide
theorem cert_e605605488414 : check e605605488414 [[],[]] .chain = true := by decide
def e605605488514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e605605488514 : Closed e605605488514 ∧ code e605605488514 = 2804628744066 := by decide
theorem cert_e605605488514 : check e605605488514 [[],[]] .chain = true := by decide
def e605605488526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605605488526 : Closed e605605488526 ∧ code e605605488526 = 2804628744078 := by decide
theorem cert_e605605488526 : check e605605488526 [[],[]] .chain = true := by decide
def e605605488538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605605488538 : Closed e605605488538 ∧ code e605605488538 = 2804628744090 := by decide
theorem cert_e605605488538 : check e605605488538 [[],[]] .chain = true := by decide
def e605605490910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e605605490910 : Closed e605605490910 ∧ code e605605490910 = 2804628746462 := by decide
theorem cert_e605605490910 : check e605605490910 [[],[]] .chain = true := by decide
def e605605490938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e605605490938 : Closed e605605490938 ∧ code e605605490938 = 2804628746490 := by decide
theorem cert_e605605490938 : check e605605490938 [[],[]] .chain = true := by decide
def e605605491486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605605491486 : Closed e605605491486 ∧ code e605605491486 = 2804628747038 := by decide
theorem cert_e605605491486 : check e605605491486 [[],[]] .chain = true := by decide
def e605605491654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605605491654 : Closed e605605491654 ∧ code e605605491654 = 2804628747206 := by decide
theorem cert_e605605491654 : check e605605491654 [[],[]] .chain = true := by decide
def e605605492762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e605605492762 : Closed e605605492762 ∧ code e605605492762 = 2804628748314 := by decide
theorem cert_e605605492762 : check e605605492762 [[],[]] .sourceHead = true := by decide
def e605605492798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 4))))))))))
theorem wire_e605605492798 : Closed e605605492798 ∧ code e605605492798 = 2804628748350 := by decide
theorem cert_e605605492798 : check e605605492798 [[],[]] .sourceHead = true := by decide
def e605605492846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e605605492846 : Closed e605605492846 ∧ code e605605492846 = 2804628748398 := by decide
theorem cert_e605605492846 : check e605605492846 [[],[]] .chain = true := by decide
def e605605492854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605605492854 : Closed e605605492854 ∧ code e605605492854 = 2804628748406 := by decide
theorem cert_e605605492854 : check e605605492854 [[],[]] .chain = true := by decide
def e605605492858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e605605492858 : Closed e605605492858 ∧ code e605605492858 = 2804628748410 := by decide
theorem cert_e605605492858 : check e605605492858 [[],[]] .chain = true := by decide
def e605605493098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605605493098 : Closed e605605493098 ∧ code e605605493098 = 2804628748650 := by decide
theorem cert_e605605493098 : check e605605493098 [[],[]] .chain = true := by decide
def e605605493122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e605605493122 : Closed e605605493122 ∧ code e605605493122 = 2804628748674 := by decide
theorem cert_e605605493122 : check e605605493122 [[],[]] .chain = true := by decide
def e605605493134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605605493134 : Closed e605605493134 ∧ code e605605493134 = 2804628748686 := by decide
theorem cert_e605605493134 : check e605605493134 [[],[]] .chain = true := by decide
def e605605493146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605605493146 : Closed e605605493146 ∧ code e605605493146 = 2804628748698 := by decide
theorem cert_e605605493146 : check e605605493146 [[],[]] .chain = true := by decide
def e605605493190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605605493190 : Closed e605605493190 ∧ code e605605493190 = 2804628748742 := by decide
theorem cert_e605605493190 : check e605605493190 [[],[]] .chain = true := by decide
def e605605493218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605605493218 : Closed e605605493218 ∧ code e605605493218 = 2804628748770 := by decide
theorem cert_e605605493218 : check e605605493218 [[],[]] .sourceHead = true := by decide
def e605605493230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 2)))))))))
theorem wire_e605605493230 : Closed e605605493230 ∧ code e605605493230 = 2804628748782 := by decide
theorem cert_e605605493230 : check e605605493230 [[],[]] .sourceHead = true := by decide
def e605605530478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605605530478 : Closed e605605530478 ∧ code e605605530478 = 2804628786030 := by decide
theorem cert_e605605530478 : check e605605530478 [[],[]] .smaller = true := by decide
def e605605530486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605605530486 : Closed e605605530486 ∧ code e605605530486 = 2804628786038 := by decide
theorem cert_e605605530486 : check e605605530486 [[],[]] .smaller = true := by decide
def e605605530542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605605530542 : Closed e605605530542 ∧ code e605605530542 = 2804628786094 := by decide
theorem cert_e605605530542 : check e605605530542 [[],[]] .smaller = true := by decide
def e605605530554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605605530554 : Closed e605605530554 ∧ code e605605530554 = 2804628786106 := by decide
theorem cert_e605605530554 : check e605605530554 [[],[]] .smaller = true := by decide
def e605605530582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605605530582 : Closed e605605530582 ∧ code e605605530582 = 2804628786134 := by decide
theorem cert_e605605530582 : check e605605530582 [[],[]] .smaller = true := by decide
def e605605530586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605605530586 : Closed e605605530586 ∧ code e605605530586 = 2804628786138 := by decide
theorem cert_e605605530586 : check e605605530586 [[],[]] .smaller = true := by decide
def e605605530862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605605530862 : Closed e605605530862 ∧ code e605605530862 = 2804628786414 := by decide
theorem cert_e605605530862 : check e605605530862 [[],[]] .smaller = true := by decide
def e605605530870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605605530870 : Closed e605605530870 ∧ code e605605530870 = 2804628786422 := by decide
theorem cert_e605605530870 : check e605605530870 [[],[]] .smaller = true := by decide
def e605605531198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e605605531198 : Closed e605605531198 ∧ code e605605531198 = 2804628786750 := by decide
theorem cert_e605605531198 : check e605605531198 [[],[]] .chain = true := by decide
def e605605531246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605605531246 : Closed e605605531246 ∧ code e605605531246 = 2804628786798 := by decide
theorem cert_e605605531246 : check e605605531246 [[],[]] .smaller = true := by decide
def e605605531258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605605531258 : Closed e605605531258 ∧ code e605605531258 = 2804628786810 := by decide
theorem cert_e605605531258 : check e605605531258 [[],[]] .smaller = true := by decide
def e605605531446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605605531446 : Closed e605605531446 ∧ code e605605531446 = 2804628786998 := by decide
theorem cert_e605605531446 : check e605605531446 [[],[]] .smaller = true := by decide
def e605605531450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605605531450 : Closed e605605531450 ∧ code e605605531450 = 2804628787002 := by decide
theorem cert_e605605531450 : check e605605531450 [[],[]] .smaller = true := by decide
def e605605531534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e605605531534 : Closed e605605531534 ∧ code e605605531534 = 2804628787086 := by decide
theorem cert_e605605531534 : check e605605531534 [[],[]] .chain = true := by decide
def e605605538926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605605538926 : Closed e605605538926 ∧ code e605605538926 = 2804628794478 := by decide
theorem cert_e605605538926 : check e605605538926 [[],[]] .chain = true := by decide
def e605605538938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605605538938 : Closed e605605538938 ∧ code e605605538938 = 2804628794490 := by decide
theorem cert_e605605538938 : check e605605538938 [[],[]] .chain = true := by decide
def e605605539102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605605539102 : Closed e605605539102 ∧ code e605605539102 = 2804628794654 := by decide
theorem cert_e605605539102 : check e605605539102 [[],[]] .chain = true := by decide
def e605605539270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605605539270 : Closed e605605539270 ∧ code e605605539270 = 2804628794822 := by decide
theorem cert_e605605539270 : check e605605539270 [[],[]] .chain = true := by decide
def e605605539610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e605605539610 : Closed e605605539610 ∧ code e605605539610 = 2804628795162 := by decide
theorem cert_e605605539610 : check e605605539610 [[],[]] .chain = true := by decide
def e605605539654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e605605539654 : Closed e605605539654 ∧ code e605605539654 = 2804628795206 := by decide
theorem cert_e605605539654 : check e605605539654 [[],[]] .chain = true := by decide
def e605605540062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e605605540062 : Closed e605605540062 ∧ code e605605540062 = 2804628795614 := by decide
theorem cert_e605605540062 : check e605605540062 [[],[]] .chain = true := by decide
def e605605540090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e605605540090 : Closed e605605540090 ∧ code e605605540090 = 2804628795642 := by decide
theorem cert_e605605540090 : check e605605540090 [[],[]] .chain = true := by decide
def e605605540638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605605540638 : Closed e605605540638 ∧ code e605605540638 = 2804628796190 := by decide
theorem cert_e605605540638 : check e605605540638 [[],[]] .chain = true := by decide
def e605605540806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605605540806 : Closed e605605540806 ∧ code e605605540806 = 2804628796358 := by decide
theorem cert_e605605540806 : check e605605540806 [[],[]] .chain = true := by decide
def e605605542966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e605605542966 : Closed e605605542966 ∧ code e605605542966 = 2804628798518 := by decide
theorem cert_e605605542966 : check e605605542966 [[],[]] .chain = true := by decide
def e605605542970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e605605542970 : Closed e605605542970 ∧ code e605605542970 = 2804628798522 := by decide
theorem cert_e605605542970 : check e605605542970 [[],[]] .chain = true := by decide
def e605605543110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e605605543110 : Closed e605605543110 ∧ code e605605543110 = 2804628798662 := by decide
theorem cert_e605605543110 : check e605605543110 [[],[]] .chain = true := by decide
def e605605560814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e605605560814 : Closed e605605560814 ∧ code e605605560814 = 2804628816366 := by decide
theorem cert_e605605560814 : check e605605560814 [[],[]] .chain = true := by decide
def e605605561782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605605561782 : Closed e605605561782 ∧ code e605605561782 = 2804628817334 := by decide
theorem cert_e605605561782 : check e605605561782 [[],[]] .chain = true := by decide
def e605605561814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605605561814 : Closed e605605561814 ∧ code e605605561814 = 2804628817366 := by decide
theorem cert_e605605561814 : check e605605561814 [[],[]] .chain = true := by decide
def e605605561818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605605561818 : Closed e605605561818 ∧ code e605605561818 = 2804628817370 := by decide
theorem cert_e605605561818 : check e605605561818 [[],[]] .chain = true := by decide
def e605605561974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605605561974 : Closed e605605561974 ∧ code e605605561974 = 2804628817526 := by decide
theorem cert_e605605561974 : check e605605561974 [[],[]] .chain = true := by decide
def e605605562142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605605562142 : Closed e605605562142 ∧ code e605605562142 = 2804628817694 := by decide
theorem cert_e605605562142 : check e605605562142 [[],[]] .chain = true := by decide
def e605605562166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605605562166 : Closed e605605562166 ∧ code e605605562166 = 2804628817718 := by decide
theorem cert_e605605562166 : check e605605562166 [[],[]] .chain = true := by decide
def e605605562170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605605562170 : Closed e605605562170 ∧ code e605605562170 = 2804628817722 := by decide
theorem cert_e605605562170 : check e605605562170 [[],[]] .chain = true := by decide
def e605605562254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605605562254 : Closed e605605562254 ∧ code e605605562254 = 2804628817806 := by decide
theorem cert_e605605562254 : check e605605562254 [[],[]] .chain = true := by decide
def e605605565866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605605565866 : Closed e605605565866 ∧ code e605605565866 = 2804628821418 := by decide
theorem cert_e605605565866 : check e605605565866 [[],[]] .chain = true := by decide
def e605605565962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605605565962 : Closed e605605565962 ∧ code e605605565962 = 2804628821514 := by decide
theorem cert_e605605565962 : check e605605565962 [[],[]] .chain = true := by decide
def e605605565998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605605565998 : Closed e605605565998 ∧ code e605605565998 = 2804628821550 := by decide
theorem cert_e605605565998 : check e605605565998 [[],[]] .sourceHead = true := by decide
def e605605566006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605605566006 : Closed e605605566006 ∧ code e605605566006 = 2804628821558 := by decide
theorem cert_e605605566006 : check e605605566006 [[],[]] .chain = true := by decide
def e605605566010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605605566010 : Closed e605605566010 ∧ code e605605566010 = 2804628821562 := by decide
theorem cert_e605605566010 : check e605605566010 [[],[]] .chain = true := by decide
def e605605566058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605605566058 : Closed e605605566058 ∧ code e605605566058 = 2804628821610 := by decide
theorem cert_e605605566058 : check e605605566058 [[],[]] .chain = true := by decide
def e605605566082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e605605566082 : Closed e605605566082 ∧ code e605605566082 = 2804628821634 := by decide
theorem cert_e605605566082 : check e605605566082 [[],[]] .chain = true := by decide
def e605605566094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605605566094 : Closed e605605566094 ∧ code e605605566094 = 2804628821646 := by decide
theorem cert_e605605566094 : check e605605566094 [[],[]] .chain = true := by decide
def e605605566106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605605566106 : Closed e605605566106 ∧ code e605605566106 = 2804628821658 := by decide
theorem cert_e605605566106 : check e605605566106 [[],[]] .chain = true := by decide
def e605605566150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605605566150 : Closed e605605566150 ∧ code e605605566150 = 2804628821702 := by decide
theorem cert_e605605566150 : check e605605566150 [[],[]] .chain = true := by decide
def e605605566178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605605566178 : Closed e605605566178 ∧ code e605605566178 = 2804628821730 := by decide
theorem cert_e605605566178 : check e605605566178 [[],[]] .sourceHead = true := by decide
def e605605566190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e605605566190 : Closed e605605566190 ∧ code e605605566190 = 2804628821742 := by decide
theorem cert_e605605566190 : check e605605566190 [[],[]] .sourceHead = true := by decide
def e605605566234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e605605566234 : Closed e605605566234 ∧ code e605605566234 = 2804628821786 := by decide
theorem cert_e605605566234 : check e605605566234 [[],[]] .chain = true := by decide
def e605605566278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e605605566278 : Closed e605605566278 ∧ code e605605566278 = 2804628821830 := by decide
theorem cert_e605605566278 : check e605605566278 [[],[]] .chain = true := by decide
def e605605566346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605605566346 : Closed e605605566346 ∧ code e605605566346 = 2804628821898 := by decide
theorem cert_e605605566346 : check e605605566346 [[],[]] .sourceHead = true := by decide
def e605605566370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605605566370 : Closed e605605566370 ∧ code e605605566370 = 2804628821922 := by decide
theorem cert_e605605566370 : check e605605566370 [[],[]] .sourceHead = true := by decide
def e605605566382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e605605566382 : Closed e605605566382 ∧ code e605605566382 = 2804628821934 := by decide
theorem cert_e605605566382 : check e605605566382 [[],[]] .sourceHead = true := by decide
def e605605566394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e605605566394 : Closed e605605566394 ∧ code e605605566394 = 2804628821946 := by decide
theorem cert_e605605566394 : check e605605566394 [[],[]] .sourceHead = true := by decide
def e605605566490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e605605566490 : Closed e605605566490 ∧ code e605605566490 = 2804628822042 := by decide
theorem cert_e605605566490 : check e605605566490 [[],[]] .sourceHead = true := by decide
def e605605566526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e605605566526 : Closed e605605566526 ∧ code e605605566526 = 2804628822078 := by decide
theorem cert_e605605566526 : check e605605566526 [[],[]] .sourceHead = true := by decide
def e605605566574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e605605566574 : Closed e605605566574 ∧ code e605605566574 = 2804628822126 := by decide
theorem cert_e605605566574 : check e605605566574 [[],[]] .chain = true := by decide
def e605605566582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605605566582 : Closed e605605566582 ∧ code e605605566582 = 2804628822134 := by decide
theorem cert_e605605566582 : check e605605566582 [[],[]] .chain = true := by decide
def e605605566586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e605605566586 : Closed e605605566586 ∧ code e605605566586 = 2804628822138 := by decide
theorem cert_e605605566586 : check e605605566586 [[],[]] .chain = true := by decide
def e605605566826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605605566826 : Closed e605605566826 ∧ code e605605566826 = 2804628822378 := by decide
theorem cert_e605605566826 : check e605605566826 [[],[]] .chain = true := by decide
def e605605566850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e605605566850 : Closed e605605566850 ∧ code e605605566850 = 2804628822402 := by decide
theorem cert_e605605566850 : check e605605566850 [[],[]] .chain = true := by decide
def e605605566862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605605566862 : Closed e605605566862 ∧ code e605605566862 = 2804628822414 := by decide
theorem cert_e605605566862 : check e605605566862 [[],[]] .chain = true := by decide
def e605605566874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605605566874 : Closed e605605566874 ∧ code e605605566874 = 2804628822426 := by decide
theorem cert_e605605566874 : check e605605566874 [[],[]] .chain = true := by decide
def e605605566918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605605566918 : Closed e605605566918 ∧ code e605605566918 = 2804628822470 := by decide
theorem cert_e605605566918 : check e605605566918 [[],[]] .chain = true := by decide
end Blc.Floor41
