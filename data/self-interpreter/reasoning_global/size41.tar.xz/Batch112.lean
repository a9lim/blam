import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605602767098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e605602767098 : Closed e605602767098 ∧ code e605602767098 = 2804626022650 := by decide
theorem cert_e605602767098 : check e605602767098 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602767286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e605602767286 : Closed e605602767286 ∧ code e605602767286 = 2804626022838 := by decide
theorem cert_e605602767286 : check e605602767286 [[],[]] .chain = true := by decide
def e605602767290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e605602767290 : Closed e605602767290 ∧ code e605602767290 = 2804626022842 := by decide
theorem cert_e605602767290 : check e605602767290 [[],[]] .chain = true := by decide
def e605602767318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e605602767318 : Closed e605602767318 ∧ code e605602767318 = 2804626022870 := by decide
theorem cert_e605602767318 : check e605602767318 [[],[]] .chain = true := by decide
def e605602767322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))) (.var 0))))))
theorem wire_e605602767322 : Closed e605602767322 ∧ code e605602767322 = 2804626022874 := by decide
theorem cert_e605602767322 : check e605602767322 [[],[]] .chain = true := by decide
def e605602767338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e605602767338 : Closed e605602767338 ∧ code e605602767338 = 2804626022890 := by decide
theorem cert_e605602767338 : check e605602767338 [[],[]] .chain = true := by decide
def e605602767470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602767470 : Closed e605602767470 ∧ code e605602767470 = 2804626023022 := by decide
theorem cert_e605602767470 : check e605602767470 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602767482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602767482 : Closed e605602767482 ∧ code e605602767482 = 2804626023034 := by decide
theorem cert_e605602767482 : check e605602767482 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602767646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e605602767646 : Closed e605602767646 ∧ code e605602767646 = 2804626023198 := by decide
theorem cert_e605602767646 : check e605602767646 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602767670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602767670 : Closed e605602767670 ∧ code e605602767670 = 2804626023222 := by decide
theorem cert_e605602767670 : check e605602767670 [[],[]] .chain = true := by decide
def e605602767674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602767674 : Closed e605602767674 ∧ code e605602767674 = 2804626023226 := by decide
theorem cert_e605602767674 : check e605602767674 [[],[]] .chain = true := by decide
def e605602767770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602767770 : Closed e605602767770 ∧ code e605602767770 = 2804626023322 := by decide
theorem cert_e605602767770 : check e605602767770 [[],[]] .chain = true := by decide
def e605602767814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e605602767814 : Closed e605602767814 ∧ code e605602767814 = 2804626023366 := by decide
theorem cert_e605602767814 : check e605602767814 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602768298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e605602768298 : Closed e605602768298 ∧ code e605602768298 = 2804626023850 := by decide
theorem cert_e605602768298 : check e605602768298 [[],[]] .chain = true := by decide
def e605602768394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e605602768394 : Closed e605602768394 ∧ code e605602768394 = 2804626023946 := by decide
theorem cert_e605602768394 : check e605602768394 [[],[]] .chain = true := by decide
def e605602768430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e605602768430 : Closed e605602768430 ∧ code e605602768430 = 2804626023982 := by decide
theorem cert_e605602768430 : check e605602768430 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602768438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.var 1))))))
theorem wire_e605602768438 : Closed e605602768438 ∧ code e605602768438 = 2804626023990 := by decide
theorem cert_e605602768438 : check e605602768438 [[],[]] .chain = true := by decide
def e605602768442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))) (.var 0))))))
theorem wire_e605602768442 : Closed e605602768442 ∧ code e605602768442 = 2804626023994 := by decide
theorem cert_e605602768442 : check e605602768442 [[],[]] .chain = true := by decide
def e605602768490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e605602768490 : Closed e605602768490 ∧ code e605602768490 = 2804626024042 := by decide
theorem cert_e605602768490 : check e605602768490 [[],[]] .chain = true := by decide
def e605602768514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.var 0))))))))
theorem wire_e605602768514 : Closed e605602768514 ∧ code e605602768514 = 2804626024066 := by decide
theorem cert_e605602768514 : check e605602768514 [[],[]] .chain = true := by decide
def e605602768526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e605602768526 : Closed e605602768526 ∧ code e605602768526 = 2804626024078 := by decide
theorem cert_e605602768526 : check e605602768526 [[],[]] .chain = true := by decide
def e605602768538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602768538 : Closed e605602768538 ∧ code e605602768538 = 2804626024090 := by decide
theorem cert_e605602768538 : check e605602768538 [[],[]] .chain = true := by decide
def e605602768582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e605602768582 : Closed e605602768582 ∧ code e605602768582 = 2804626024134 := by decide
theorem cert_e605602768582 : check e605602768582 [[],[]] .chain = true := by decide
def e605602768610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e605602768610 : Closed e605602768610 ∧ code e605602768610 = 2804626024162 := by decide
theorem cert_e605602768610 : check e605602768610 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602768622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e605602768622 : Closed e605602768622 ∧ code e605602768622 = 2804626024174 := by decide
theorem cert_e605602768622 : check e605602768622 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602768666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))) (.var 0))))))
theorem wire_e605602768666 : Closed e605602768666 ∧ code e605602768666 = 2804626024218 := by decide
theorem cert_e605602768666 : check e605602768666 [[],[]] .chain = true := by decide
def e605602768710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e605602768710 : Closed e605602768710 ∧ code e605602768710 = 2804626024262 := by decide
theorem cert_e605602768710 : check e605602768710 [[],[]] .chain = true := by decide
def e605602768778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e605602768778 : Closed e605602768778 ∧ code e605602768778 = 2804626024330 := by decide
theorem cert_e605602768778 : check e605602768778 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602768802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e605602768802 : Closed e605602768802 ∧ code e605602768802 = 2804626024354 := by decide
theorem cert_e605602768802 : check e605602768802 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602768814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e605602768814 : Closed e605602768814 ∧ code e605602768814 = 2804626024366 := by decide
theorem cert_e605602768814 : check e605602768814 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602768826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e605602768826 : Closed e605602768826 ∧ code e605602768826 = 2804626024378 := by decide
theorem cert_e605602768826 : check e605602768826 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602768922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605602768922 : Closed e605602768922 ∧ code e605602768922 = 2804626024474 := by decide
theorem cert_e605602768922 : check e605602768922 [[],[],[.under,.under,.left]] .width = true := by decide
def e605602768958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e605602768958 : Closed e605602768958 ∧ code e605602768958 = 2804626024510 := by decide
theorem cert_e605602768958 : check e605602768958 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602769006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e605602769006 : Closed e605602769006 ∧ code e605602769006 = 2804626024558 := by decide
theorem cert_e605602769006 : check e605602769006 [[],[]] .chain = true := by decide
def e605602769014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e605602769014 : Closed e605602769014 ∧ code e605602769014 = 2804626024566 := by decide
theorem cert_e605602769014 : check e605602769014 [[],[]] .chain = true := by decide
def e605602769018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e605602769018 : Closed e605602769018 ∧ code e605602769018 = 2804626024570 := by decide
theorem cert_e605602769018 : check e605602769018 [[],[]] .chain = true := by decide
def e605602769258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e605602769258 : Closed e605602769258 ∧ code e605602769258 = 2804626024810 := by decide
theorem cert_e605602769258 : check e605602769258 [[],[]] .chain = true := by decide
def e605602769282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e605602769282 : Closed e605602769282 ∧ code e605602769282 = 2804626024834 := by decide
theorem cert_e605602769282 : check e605602769282 [[],[]] .chain = true := by decide
def e605602769294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e605602769294 : Closed e605602769294 ∧ code e605602769294 = 2804626024846 := by decide
theorem cert_e605602769294 : check e605602769294 [[],[]] .chain = true := by decide
def e605602769306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e605602769306 : Closed e605602769306 ∧ code e605602769306 = 2804626024858 := by decide
theorem cert_e605602769306 : check e605602769306 [[],[]] .chain = true := by decide
def e605602769350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e605602769350 : Closed e605602769350 ∧ code e605602769350 = 2804626024902 := by decide
theorem cert_e605602769350 : check e605602769350 [[],[]] .chain = true := by decide
def e605602769378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e605602769378 : Closed e605602769378 ∧ code e605602769378 = 2804626024930 := by decide
theorem cert_e605602769378 : check e605602769378 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602769390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e605602769390 : Closed e605602769390 ∧ code e605602769390 = 2804626024942 := by decide
theorem cert_e605602769390 : check e605602769390 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602769974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e605602769974 : Closed e605602769974 ∧ code e605602769974 = 2804626025526 := by decide
theorem cert_e605602769974 : check e605602769974 [[],[]] .chain = true := by decide
def e605602769978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e605602769978 : Closed e605602769978 ∧ code e605602769978 = 2804626025530 := by decide
theorem cert_e605602769978 : check e605602769978 [[],[]] .chain = true := by decide
def e605602770118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e605602770118 : Closed e605602770118 ∧ code e605602770118 = 2804626025670 := by decide
theorem cert_e605602770118 : check e605602770118 [[],[]] .chain = true := by decide
def e605602770446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e605602770446 : Closed e605602770446 ∧ code e605602770446 = 2804626025998 := by decide
theorem cert_e605602770446 : check e605602770446 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602770530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e605602770530 : Closed e605602770530 ∧ code e605602770530 = 2804626026082 := by decide
theorem cert_e605602770530 : check e605602770530 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602770542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602770542 : Closed e605602770542 ∧ code e605602770542 = 2804626026094 := by decide
theorem cert_e605602770542 : check e605602770542 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602770554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602770554 : Closed e605602770554 ∧ code e605602770554 = 2804626026106 := by decide
theorem cert_e605602770554 : check e605602770554 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e605602771062 : Closed e605602771062 ∧ code e605602771062 = 2804626026614 := by decide
theorem cert_e605602771062 : check e605602771062 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e605602771066 : Closed e605602771066 ∧ code e605602771066 = 2804626026618 := by decide
theorem cert_e605602771066 : check e605602771066 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602771254 : Closed e605602771254 ∧ code e605602771254 = 2804626026806 := by decide
theorem cert_e605602771254 : check e605602771254 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602771258 : Closed e605602771258 ∧ code e605602771258 = 2804626026810 := by decide
theorem cert_e605602771258 : check e605602771258 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e605602771342 : Closed e605602771342 ∧ code e605602771342 = 2804626026894 := by decide
theorem cert_e605602771342 : check e605602771342 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e605602771398 : Closed e605602771398 ∧ code e605602771398 = 2804626026950 := by decide
theorem cert_e605602771398 : check e605602771398 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e605602771734 : Closed e605602771734 ∧ code e605602771734 = 2804626027286 := by decide
theorem cert_e605602771734 : check e605602771734 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e605602771810 : Closed e605602771810 ∧ code e605602771810 = 2804626027362 := by decide
theorem cert_e605602771810 : check e605602771810 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e605602771822 : Closed e605602771822 ∧ code e605602771822 = 2804626027374 := by decide
theorem cert_e605602771822 : check e605602771822 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e605602771830 : Closed e605602771830 ∧ code e605602771830 = 2804626027382 := by decide
theorem cert_e605602771830 : check e605602771830 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e605602771850 : Closed e605602771850 ∧ code e605602771850 = 2804626027402 := by decide
theorem cert_e605602771850 : check e605602771850 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e605602771874 : Closed e605602771874 ∧ code e605602771874 = 2804626027426 := by decide
theorem cert_e605602771874 : check e605602771874 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e605602771886 : Closed e605602771886 ∧ code e605602771886 = 2804626027438 := by decide
theorem cert_e605602771886 : check e605602771886 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e605602771898 : Closed e605602771898 ∧ code e605602771898 = 2804626027450 := by decide
theorem cert_e605602771898 : check e605602771898 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e605602771926 : Closed e605602771926 ∧ code e605602771926 = 2804626027478 := by decide
theorem cert_e605602771926 : check e605602771926 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e605602771930 : Closed e605602771930 ∧ code e605602771930 = 2804626027482 := by decide
theorem cert_e605602771930 : check e605602771930 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602771998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e605602771998 : Closed e605602771998 ∧ code e605602771998 = 2804626027550 := by decide
theorem cert_e605602771998 : check e605602771998 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602772194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e605602772194 : Closed e605602772194 ∧ code e605602772194 = 2804626027746 := by decide
theorem cert_e605602772194 : check e605602772194 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602772206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602772206 : Closed e605602772206 ∧ code e605602772206 = 2804626027758 := by decide
theorem cert_e605602772206 : check e605602772206 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602772214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602772214 : Closed e605602772214 ∧ code e605602772214 = 2804626027766 := by decide
theorem cert_e605602772214 : check e605602772214 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602772494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e605602772494 : Closed e605602772494 ∧ code e605602772494 = 2804626028046 := by decide
theorem cert_e605602772494 : check e605602772494 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602772578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e605602772578 : Closed e605602772578 ∧ code e605602772578 = 2804626028130 := by decide
theorem cert_e605602772578 : check e605602772578 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602772590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602772590 : Closed e605602772590 ∧ code e605602772590 = 2804626028142 := by decide
theorem cert_e605602772590 : check e605602772590 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602772602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602772602 : Closed e605602772602 ∧ code e605602772602 = 2804626028154 := by decide
theorem cert_e605602772602 : check e605602772602 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602772790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602772790 : Closed e605602772790 ∧ code e605602772790 = 2804626028342 := by decide
private def t_e605602772790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem cert_e605602772790 : ¬ IsSelfInterpreter e605602772790 :=
  wSource (t := t_e605602772790) (replay_sound (ps := []) (t := e605602772790) (by decide)) (by decide)
def e605602772794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602772794 : Closed e605602772794 ∧ code e605602772794 = 2804626028346 := by decide
private def t_e605602772794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem cert_e605602772794 : ¬ IsSelfInterpreter e605602772794 :=
  wSource (t := t_e605602772794) (replay_sound (ps := []) (t := e605602772794) (by decide)) (by decide)
def e605602776030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e605602776030 : Closed e605602776030 ∧ code e605602776030 = 2804626031582 := by decide
theorem cert_e605602776030 : check e605602776030 [[],[]] .chain = true := by decide
def e605602776046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e605602776046 : Closed e605602776046 ∧ code e605602776046 = 2804626031598 := by decide
theorem cert_e605602776046 : check e605602776046 [[],[]] .chain = true := by decide
def e605602777966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605602777966 : Closed e605602777966 ∧ code e605602777966 = 2804626033518 := by decide
theorem cert_e605602777966 : check e605602777966 [[],[]] .chain = true := by decide
def e605602777974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605602777974 : Closed e605602777974 ∧ code e605602777974 = 2804626033526 := by decide
theorem cert_e605602777974 : check e605602777974 [[],[]] .chain = true := by decide
def e605602778030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605602778030 : Closed e605602778030 ∧ code e605602778030 = 2804626033582 := by decide
theorem cert_e605602778030 : check e605602778030 [[],[]] .chain = true := by decide
def e605602778042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605602778042 : Closed e605602778042 ∧ code e605602778042 = 2804626033594 := by decide
theorem cert_e605602778042 : check e605602778042 [[],[]] .chain = true := by decide
def e605602778070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605602778070 : Closed e605602778070 ∧ code e605602778070 = 2804626033622 := by decide
theorem cert_e605602778070 : check e605602778070 [[],[]] .chain = true := by decide
def e605602778074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605602778074 : Closed e605602778074 ∧ code e605602778074 = 2804626033626 := by decide
theorem cert_e605602778074 : check e605602778074 [[],[]] .chain = true := by decide
def e605602778350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605602778350 : Closed e605602778350 ∧ code e605602778350 = 2804626033902 := by decide
theorem cert_e605602778350 : check e605602778350 [[],[]] .chain = true := by decide
def e605602778358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605602778358 : Closed e605602778358 ∧ code e605602778358 = 2804626033910 := by decide
theorem cert_e605602778358 : check e605602778358 [[],[]] .chain = true := by decide
def e605602778734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605602778734 : Closed e605602778734 ∧ code e605602778734 = 2804626034286 := by decide
theorem cert_e605602778734 : check e605602778734 [[],[]] .chain = true := by decide
def e605602778746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605602778746 : Closed e605602778746 ∧ code e605602778746 = 2804626034298 := by decide
theorem cert_e605602778746 : check e605602778746 [[],[]] .chain = true := by decide
def e605602778910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e605602778910 : Closed e605602778910 ∧ code e605602778910 = 2804626034462 := by decide
theorem cert_e605602778910 : check e605602778910 [[],[]] .chain = true := by decide
def e605602778934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602778934 : Closed e605602778934 ∧ code e605602778934 = 2804626034486 := by decide
theorem cert_e605602778934 : check e605602778934 [[],[]] .chain = true := by decide
def e605602778938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602778938 : Closed e605602778938 ∧ code e605602778938 = 2804626034490 := by decide
theorem cert_e605602778938 : check e605602778938 [[],[]] .chain = true := by decide
def e605602786134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e605602786134 : Closed e605602786134 ∧ code e605602786134 = 2804626041686 := by decide
theorem cert_e605602786134 : check e605602786134 [[],[]] .chain = true := by decide
def e605602786138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e605602786138 : Closed e605602786138 ∧ code e605602786138 = 2804626041690 := by decide
theorem cert_e605602786138 : check e605602786138 [[],[]] .chain = true := by decide
def e605602786154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e605602786154 : Closed e605602786154 ∧ code e605602786154 = 2804626041706 := by decide
theorem cert_e605602786154 : check e605602786154 [[],[]] .chain = true := by decide
def e605602786218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605602786218 : Closed e605602786218 ∧ code e605602786218 = 2804626041770 := by decide
theorem cert_e605602786218 : check e605602786218 [[],[]] .chain = true := by decide
def e605602786326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605602786326 : Closed e605602786326 ∧ code e605602786326 = 2804626041878 := by decide
theorem cert_e605602786326 : check e605602786326 [[],[]] .chain = true := by decide
def e605602786422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))
theorem wire_e605602786422 : Closed e605602786422 ∧ code e605602786422 = 2804626041974 := by decide
theorem cert_e605602786422 : check e605602786422 [[],[]] .chain = true := by decide
def e605602786518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605602786518 : Closed e605602786518 ∧ code e605602786518 = 2804626042070 := by decide
theorem cert_e605602786518 : check e605602786518 [[],[]] .chain = true := by decide
def e605602786522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605602786522 : Closed e605602786522 ∧ code e605602786522 = 2804626042074 := by decide
theorem cert_e605602786522 : check e605602786522 [[],[]] .chain = true := by decide
def e605602786538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605602786538 : Closed e605602786538 ∧ code e605602786538 = 2804626042090 := by decide
theorem cert_e605602786538 : check e605602786538 [[],[]] .chain = true := by decide
def e605602786614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605602786614 : Closed e605602786614 ∧ code e605602786614 = 2804626042166 := by decide
theorem cert_e605602786614 : check e605602786614 [[],[]] .chain = true := by decide
def e605602786618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605602786618 : Closed e605602786618 ∧ code e605602786618 = 2804626042170 := by decide
theorem cert_e605602786618 : check e605602786618 [[],[]] .chain = true := by decide
def e605602786690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e605602786690 : Closed e605602786690 ∧ code e605602786690 = 2804626042242 := by decide
theorem cert_e605602786690 : check e605602786690 [[],[]] .chain = true := by decide
def e605602786702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))
theorem wire_e605602786702 : Closed e605602786702 ∧ code e605602786702 = 2804626042254 := by decide
theorem cert_e605602786702 : check e605602786702 [[],[]] .chain = true := by decide
def e605602786714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605602786714 : Closed e605602786714 ∧ code e605602786714 = 2804626042266 := by decide
theorem cert_e605602786714 : check e605602786714 [[],[]] .chain = true := by decide
def e605602786826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605602786826 : Closed e605602786826 ∧ code e605602786826 = 2804626042378 := by decide
theorem cert_e605602786826 : check e605602786826 [[],[]] .chain = true := by decide
def e605602786862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605602786862 : Closed e605602786862 ∧ code e605602786862 = 2804626042414 := by decide
theorem cert_e605602786862 : check e605602786862 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602786870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605602786870 : Closed e605602786870 ∧ code e605602786870 = 2804626042422 := by decide
theorem cert_e605602786870 : check e605602786870 [[],[]] .chain = true := by decide
def e605602786874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605602786874 : Closed e605602786874 ∧ code e605602786874 = 2804626042426 := by decide
theorem cert_e605602786874 : check e605602786874 [[],[]] .chain = true := by decide
def e605602786922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605602786922 : Closed e605602786922 ∧ code e605602786922 = 2804626042474 := by decide
theorem cert_e605602786922 : check e605602786922 [[],[]] .chain = true := by decide
def e605602786946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605602786946 : Closed e605602786946 ∧ code e605602786946 = 2804626042498 := by decide
theorem cert_e605602786946 : check e605602786946 [[],[]] .chain = true := by decide
def e605602786958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605602786958 : Closed e605602786958 ∧ code e605602786958 = 2804626042510 := by decide
theorem cert_e605602786958 : check e605602786958 [[],[]] .chain = true := by decide
def e605602786970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605602786970 : Closed e605602786970 ∧ code e605602786970 = 2804626042522 := by decide
theorem cert_e605602786970 : check e605602786970 [[],[]] .chain = true := by decide
def e605602787014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605602787014 : Closed e605602787014 ∧ code e605602787014 = 2804626042566 := by decide
theorem cert_e605602787014 : check e605602787014 [[],[]] .chain = true := by decide
def e605602787042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605602787042 : Closed e605602787042 ∧ code e605602787042 = 2804626042594 := by decide
theorem cert_e605602787042 : check e605602787042 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602787054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e605602787054 : Closed e605602787054 ∧ code e605602787054 = 2804626042606 := by decide
theorem cert_e605602787054 : check e605602787054 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602787094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e605602787094 : Closed e605602787094 ∧ code e605602787094 = 2804626042646 := by decide
theorem cert_e605602787094 : check e605602787094 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602787170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e605602787170 : Closed e605602787170 ∧ code e605602787170 = 2804626042722 := by decide
theorem cert_e605602787170 : check e605602787170 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602787182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e605602787182 : Closed e605602787182 ∧ code e605602787182 = 2804626042734 := by decide
theorem cert_e605602787182 : check e605602787182 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602787190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e605602787190 : Closed e605602787190 ∧ code e605602787190 = 2804626042742 := by decide
theorem cert_e605602787190 : check e605602787190 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602787566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605602787566 : Closed e605602787566 ∧ code e605602787566 = 2804626043118 := by decide
theorem cert_e605602787566 : check e605602787566 [[],[]] .chain = true := by decide
def e605602787574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605602787574 : Closed e605602787574 ∧ code e605602787574 = 2804626043126 := by decide
theorem cert_e605602787574 : check e605602787574 [[],[]] .chain = true := by decide
def e605602788054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605602788054 : Closed e605602788054 ∧ code e605602788054 = 2804626043606 := by decide
theorem cert_e605602788054 : check e605602788054 [[],[]] .chain = true := by decide
def e605602788058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605602788058 : Closed e605602788058 ∧ code e605602788058 = 2804626043610 := by decide
theorem cert_e605602788058 : check e605602788058 [[],[]] .chain = true := by decide
def e605602788074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605602788074 : Closed e605602788074 ∧ code e605602788074 = 2804626043626 := by decide
theorem cert_e605602788074 : check e605602788074 [[],[]] .chain = true := by decide
def e605602788150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602788150 : Closed e605602788150 ∧ code e605602788150 = 2804626043702 := by decide
theorem cert_e605602788150 : check e605602788150 [[],[]] .chain = true := by decide
def e605602788154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602788154 : Closed e605602788154 ∧ code e605602788154 = 2804626043706 := by decide
theorem cert_e605602788154 : check e605602788154 [[],[]] .chain = true := by decide
def e605602788226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e605602788226 : Closed e605602788226 ∧ code e605602788226 = 2804626043778 := by decide
theorem cert_e605602788226 : check e605602788226 [[],[]] .chain = true := by decide
def e605602788238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e605602788238 : Closed e605602788238 ∧ code e605602788238 = 2804626043790 := by decide
theorem cert_e605602788238 : check e605602788238 [[],[]] .chain = true := by decide
def e605602788250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605602788250 : Closed e605602788250 ∧ code e605602788250 = 2804626043802 := by decide
theorem cert_e605602788250 : check e605602788250 [[],[]] .chain = true := by decide
def e605602789402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605602789402 : Closed e605602789402 ∧ code e605602789402 = 2804626044954 := by decide
theorem cert_e605602789402 : check e605602789402 [[],[],[.under,.under,.left]] .width = true := by decide
def e605602789438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e605602789438 : Closed e605602789438 ∧ code e605602789438 = 2804626044990 := by decide
theorem cert_e605602789438 : check e605602789438 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602789486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605602789486 : Closed e605602789486 ∧ code e605602789486 = 2804626045038 := by decide
theorem cert_e605602789486 : check e605602789486 [[],[]] .chain = true := by decide
def e605602789494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605602789494 : Closed e605602789494 ∧ code e605602789494 = 2804626045046 := by decide
theorem cert_e605602789494 : check e605602789494 [[],[]] .chain = true := by decide
def e605602789498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605602789498 : Closed e605602789498 ∧ code e605602789498 = 2804626045050 := by decide
theorem cert_e605602789498 : check e605602789498 [[],[]] .chain = true := by decide
def e605602789738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605602789738 : Closed e605602789738 ∧ code e605602789738 = 2804626045290 := by decide
theorem cert_e605602789738 : check e605602789738 [[],[]] .chain = true := by decide
def e605602789762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605602789762 : Closed e605602789762 ∧ code e605602789762 = 2804626045314 := by decide
theorem cert_e605602789762 : check e605602789762 [[],[]] .chain = true := by decide
def e605602789774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605602789774 : Closed e605602789774 ∧ code e605602789774 = 2804626045326 := by decide
theorem cert_e605602789774 : check e605602789774 [[],[]] .chain = true := by decide
def e605602789786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605602789786 : Closed e605602789786 ∧ code e605602789786 = 2804626045338 := by decide
theorem cert_e605602789786 : check e605602789786 [[],[]] .chain = true := by decide
def e605602789830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605602789830 : Closed e605602789830 ∧ code e605602789830 = 2804626045382 := by decide
theorem cert_e605602789830 : check e605602789830 [[],[]] .chain = true := by decide
def e605602789858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605602789858 : Closed e605602789858 ∧ code e605602789858 = 2804626045410 := by decide
theorem cert_e605602789858 : check e605602789858 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602789870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e605602789870 : Closed e605602789870 ∧ code e605602789870 = 2804626045422 := by decide
theorem cert_e605602789870 : check e605602789870 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602790430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e605602790430 : Closed e605602790430 ∧ code e605602790430 = 2804626045982 := by decide
theorem cert_e605602790430 : check e605602790430 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602790626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e605602790626 : Closed e605602790626 ∧ code e605602790626 = 2804626046178 := by decide
theorem cert_e605602790626 : check e605602790626 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602790638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e605602790638 : Closed e605602790638 ∧ code e605602790638 = 2804626046190 := by decide
theorem cert_e605602790638 : check e605602790638 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602790646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e605602790646 : Closed e605602790646 ∧ code e605602790646 = 2804626046198 := by decide
theorem cert_e605602790646 : check e605602790646 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602808302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e605602808302 : Closed e605602808302 ∧ code e605602808302 = 2804626063854 := by decide
theorem cert_e605602808302 : check e605602808302 [[],[]] .chain = true := by decide
def e605602809270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e605602809270 : Closed e605602809270 ∧ code e605602809270 = 2804626064822 := by decide
theorem cert_e605602809270 : check e605602809270 [[],[]] .chain = true := by decide
def e605602809302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e605602809302 : Closed e605602809302 ∧ code e605602809302 = 2804626064854 := by decide
theorem cert_e605602809302 : check e605602809302 [[],[]] .chain = true := by decide
def e605602809306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e605602809306 : Closed e605602809306 ∧ code e605602809306 = 2804626064858 := by decide
theorem cert_e605602809306 : check e605602809306 [[],[]] .chain = true := by decide
def e605602809462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e605602809462 : Closed e605602809462 ∧ code e605602809462 = 2804626065014 := by decide
theorem cert_e605602809462 : check e605602809462 [[],[]] .chain = true := by decide
def e605602809630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605602809630 : Closed e605602809630 ∧ code e605602809630 = 2804626065182 := by decide
theorem cert_e605602809630 : check e605602809630 [[],[]] .chain = true := by decide
def e605602809654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602809654 : Closed e605602809654 ∧ code e605602809654 = 2804626065206 := by decide
theorem cert_e605602809654 : check e605602809654 [[],[]] .chain = true := by decide
def e605602809658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602809658 : Closed e605602809658 ∧ code e605602809658 = 2804626065210 := by decide
theorem cert_e605602809658 : check e605602809658 [[],[]] .chain = true := by decide
def e605602809742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605602809742 : Closed e605602809742 ∧ code e605602809742 = 2804626065294 := by decide
theorem cert_e605602809742 : check e605602809742 [[],[]] .chain = true := by decide
def e605602813354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605602813354 : Closed e605602813354 ∧ code e605602813354 = 2804626068906 := by decide
theorem cert_e605602813354 : check e605602813354 [[],[]] .chain = true := by decide
def e605602813450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605602813450 : Closed e605602813450 ∧ code e605602813450 = 2804626069002 := by decide
theorem cert_e605602813450 : check e605602813450 [[],[]] .chain = true := by decide
def e605602813486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605602813486 : Closed e605602813486 ∧ code e605602813486 = 2804626069038 := by decide
theorem cert_e605602813486 : check e605602813486 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602813494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605602813494 : Closed e605602813494 ∧ code e605602813494 = 2804626069046 := by decide
theorem cert_e605602813494 : check e605602813494 [[],[]] .chain = true := by decide
def e605602813498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605602813498 : Closed e605602813498 ∧ code e605602813498 = 2804626069050 := by decide
theorem cert_e605602813498 : check e605602813498 [[],[]] .chain = true := by decide
end Blc.Floor41
