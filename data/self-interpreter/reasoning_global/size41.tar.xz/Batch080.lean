import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605593235042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605593235042 : Closed e605593235042 ∧ code e605593235042 = 2804616490594 := by decide
theorem cert_e605593235042 : check e605593235042 [[],[]] .smaller = true := by decide
def e605593235054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e605593235054 : Closed e605593235054 ∧ code e605593235054 = 2804616490606 := by decide
theorem cert_e605593235054 : check e605593235054 [[],[]] .smaller = true := by decide
def e605593235062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e605593235062 : Closed e605593235062 ∧ code e605593235062 = 2804616490614 := by decide
theorem cert_e605593235062 : check e605593235062 [[],[]] .smaller = true := by decide
def e605593235066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e605593235066 : Closed e605593235066 ∧ code e605593235066 = 2804616490618 := by decide
theorem cert_e605593235066 : check e605593235066 [[],[]] .smaller = true := by decide
def e605593235254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593235254 : Closed e605593235254 ∧ code e605593235254 = 2804616490806 := by decide
theorem cert_e605593235254 : check e605593235254 [[],[]] .three = true := by decide
def e605593235258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593235258 : Closed e605593235258 ∧ code e605593235258 = 2804616490810 := by decide
theorem cert_e605593235258 : check e605593235258 [[],[]] .three = true := by decide
def e605593235574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e605593235574 : Closed e605593235574 ∧ code e605593235574 = 2804616491126 := by decide
theorem cert_e605593235574 : check e605593235574 [[],[]] .smaller = true := by decide
def e605593235578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e605593235578 : Closed e605593235578 ∧ code e605593235578 = 2804616491130 := by decide
theorem cert_e605593235578 : check e605593235578 [[],[]] .smaller = true := by decide
def e605593235670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e605593235670 : Closed e605593235670 ∧ code e605593235670 = 2804616491222 := by decide
theorem cert_e605593235670 : check e605593235670 [[],[]] .smaller = true := by decide
def e605593235766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593235766 : Closed e605593235766 ∧ code e605593235766 = 2804616491318 := by decide
theorem cert_e605593235766 : check e605593235766 [[],[]] .smaller = true := by decide
def e605593235770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593235770 : Closed e605593235770 ∧ code e605593235770 = 2804616491322 := by decide
theorem cert_e605593235770 : check e605593235770 [[],[]] .smaller = true := by decide
def e605593235854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e605593235854 : Closed e605593235854 ∧ code e605593235854 = 2804616491406 := by decide
theorem cert_e605593235854 : check e605593235854 [[],[]] .smaller = true := by decide
def e605593235910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e605593235910 : Closed e605593235910 ∧ code e605593235910 = 2804616491462 := by decide
theorem cert_e605593235910 : check e605593235910 [[],[]] .smaller = true := by decide
def e605593236246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605593236246 : Closed e605593236246 ∧ code e605593236246 = 2804616491798 := by decide
theorem cert_e605593236246 : check e605593236246 [[],[]] .smaller = true := by decide
def e605593236318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e605593236318 : Closed e605593236318 ∧ code e605593236318 = 2804616491870 := by decide
theorem cert_e605593236318 : check e605593236318 [[],[]] .three = true := by decide
def e605593236322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e605593236322 : Closed e605593236322 ∧ code e605593236322 = 2804616491874 := by decide
theorem cert_e605593236322 : check e605593236322 [[],[]] .smaller = true := by decide
def e605593236334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605593236334 : Closed e605593236334 ∧ code e605593236334 = 2804616491886 := by decide
theorem cert_e605593236334 : check e605593236334 [[],[]] .smaller = true := by decide
def e605593236342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605593236342 : Closed e605593236342 ∧ code e605593236342 = 2804616491894 := by decide
theorem cert_e605593236342 : check e605593236342 [[],[]] .smaller = true := by decide
def e605593236346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e605593236346 : Closed e605593236346 ∧ code e605593236346 = 2804616491898 := by decide
theorem cert_e605593236346 : check e605593236346 [[],[]] .three = true := by decide
def e605593236362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605593236362 : Closed e605593236362 ∧ code e605593236362 = 2804616491914 := by decide
theorem cert_e605593236362 : check e605593236362 [[],[]] .smaller = true := by decide
def e605593236386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605593236386 : Closed e605593236386 ∧ code e605593236386 = 2804616491938 := by decide
theorem cert_e605593236386 : check e605593236386 [[],[]] .smaller = true := by decide
def e605593236398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605593236398 : Closed e605593236398 ∧ code e605593236398 = 2804616491950 := by decide
theorem cert_e605593236398 : check e605593236398 [[],[]] .smaller = true := by decide
def e605593236406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 1)))))))
theorem wire_e605593236406 : Closed e605593236406 ∧ code e605593236406 = 2804616491958 := by decide
theorem cert_e605593236406 : check e605593236406 [[],[]] .smaller = true := by decide
def e605593236410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605593236410 : Closed e605593236410 ∧ code e605593236410 = 2804616491962 := by decide
theorem cert_e605593236410 : check e605593236410 [[],[]] .smaller = true := by decide
def e605593236438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605593236438 : Closed e605593236438 ∧ code e605593236438 = 2804616491990 := by decide
theorem cert_e605593236438 : check e605593236438 [[],[]] .smaller = true := by decide
def e605593236442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605593236442 : Closed e605593236442 ∧ code e605593236442 = 2804616491994 := by decide
theorem cert_e605593236442 : check e605593236442 [[],[]] .smaller = true := by decide
def e605593236458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e605593236458 : Closed e605593236458 ∧ code e605593236458 = 2804616492010 := by decide
theorem cert_e605593236458 : check e605593236458 [[],[]] .three = true := by decide
def e605593236510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e605593236510 : Closed e605593236510 ∧ code e605593236510 = 2804616492062 := by decide
theorem cert_e605593236510 : check e605593236510 [[],[]] .smaller = true := by decide
def e605593236702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e605593236702 : Closed e605593236702 ∧ code e605593236702 = 2804616492254 := by decide
theorem cert_e605593236702 : check e605593236702 [[],[]] .three = true := by decide
def e605593236706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e605593236706 : Closed e605593236706 ∧ code e605593236706 = 2804616492258 := by decide
theorem cert_e605593236706 : check e605593236706 [[],[]] .smaller = true := by decide
def e605593236718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605593236718 : Closed e605593236718 ∧ code e605593236718 = 2804616492270 := by decide
theorem cert_e605593236718 : check e605593236718 [[],[]] .smaller = true := by decide
def e605593236726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605593236726 : Closed e605593236726 ∧ code e605593236726 = 2804616492278 := by decide
theorem cert_e605593236726 : check e605593236726 [[],[]] .smaller = true := by decide
def e605593236730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e605593236730 : Closed e605593236730 ∧ code e605593236730 = 2804616492282 := by decide
theorem cert_e605593236730 : check e605593236730 [[],[]] .three = true := by decide
def e605593237006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e605593237006 : Closed e605593237006 ∧ code e605593237006 = 2804616492558 := by decide
theorem cert_e605593237006 : check e605593237006 [[],[]] .smaller = true := by decide
def e605593237018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605593237018 : Closed e605593237018 ∧ code e605593237018 = 2804616492570 := by decide
theorem cert_e605593237018 : check e605593237018 [[],[]] .smaller = true := by decide
def e605593237090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605593237090 : Closed e605593237090 ∧ code e605593237090 = 2804616492642 := by decide
theorem cert_e605593237090 : check e605593237090 [[],[]] .smaller = true := by decide
def e605593237102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605593237102 : Closed e605593237102 ∧ code e605593237102 = 2804616492654 := by decide
theorem cert_e605593237102 : check e605593237102 [[],[]] .smaller = true := by decide
def e605593237110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 1))))))))
theorem wire_e605593237110 : Closed e605593237110 ∧ code e605593237110 = 2804616492662 := by decide
theorem cert_e605593237110 : check e605593237110 [[],[]] .smaller = true := by decide
def e605593237114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605593237114 : Closed e605593237114 ∧ code e605593237114 = 2804616492666 := by decide
theorem cert_e605593237114 : check e605593237114 [[],[]] .smaller = true := by decide
def e605593237302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593237302 : Closed e605593237302 ∧ code e605593237302 = 2804616492854 := by decide
theorem cert_e605593237302 : check e605593237302 [[],[]] .smaller = true := by decide
def e605593237306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593237306 : Closed e605593237306 ∧ code e605593237306 = 2804616492858 := by decide
theorem cert_e605593237306 : check e605593237306 [[],[]] .smaller = true := by decide
def e605593237402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593237402 : Closed e605593237402 ∧ code e605593237402 = 2804616492954 := by decide
theorem cert_e605593237402 : check e605593237402 [[],[]] .three = true := by decide
def e605593237934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605593237934 : Closed e605593237934 ∧ code e605593237934 = 2804616493486 := by decide
theorem cert_e605593237934 : check e605593237934 [[],[]] .three = true := by decide
def e605593237942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e605593237942 : Closed e605593237942 ∧ code e605593237942 = 2804616493494 := by decide
theorem cert_e605593237942 : check e605593237942 [[],[]] .three = true := by decide
def e605593237946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605593237946 : Closed e605593237946 ∧ code e605593237946 = 2804616493498 := by decide
theorem cert_e605593237946 : check e605593237946 [[],[]] .three = true := by decide
def e605593237974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e605593237974 : Closed e605593237974 ∧ code e605593237974 = 2804616493526 := by decide
theorem cert_e605593237974 : check e605593237974 [[],[]] .three = true := by decide
def e605593237978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e605593237978 : Closed e605593237978 ∧ code e605593237978 = 2804616493530 := by decide
theorem cert_e605593237978 : check e605593237978 [[],[]] .three = true := by decide
def e605593237994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605593237994 : Closed e605593237994 ∧ code e605593237994 = 2804616493546 := by decide
theorem cert_e605593237994 : check e605593237994 [[],[]] .three = true := by decide
def e605593238126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605593238126 : Closed e605593238126 ∧ code e605593238126 = 2804616493678 := by decide
theorem cert_e605593238126 : check e605593238126 [[],[]] .three = true := by decide
def e605593238134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e605593238134 : Closed e605593238134 ∧ code e605593238134 = 2804616493686 := by decide
theorem cert_e605593238134 : check e605593238134 [[],[]] .three = true := by decide
def e605593238138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605593238138 : Closed e605593238138 ∧ code e605593238138 = 2804616493690 := by decide
theorem cert_e605593238138 : check e605593238138 [[],[]] .three = true := by decide
def e605593238326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593238326 : Closed e605593238326 ∧ code e605593238326 = 2804616493878 := by decide
theorem cert_e605593238326 : check e605593238326 [[],[]] .three = true := by decide
def e605593238330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593238330 : Closed e605593238330 ∧ code e605593238330 = 2804616493882 := by decide
theorem cert_e605593238330 : check e605593238330 [[],[]] .three = true := by decide
def e605593238426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593238426 : Closed e605593238426 ∧ code e605593238426 = 2804616493978 := by decide
theorem cert_e605593238426 : check e605593238426 [[],[]] .three = true := by decide
def e605593240494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)) (.var 2)))))))
theorem wire_e605593240494 : Closed e605593240494 ∧ code e605593240494 = 2804616496046 := by decide
theorem cert_e605593240494 : check e605593240494 [[],[]] .smaller = true := by decide
def e605593240506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.var 0)))))))
theorem wire_e605593240506 : Closed e605593240506 ∧ code e605593240506 = 2804616496058 := by decide
theorem cert_e605593240506 : check e605593240506 [[],[]] .smaller = true := by decide
def e605593240554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.var 0)))))))
theorem wire_e605593240554 : Closed e605593240554 ∧ code e605593240554 = 2804616496106 := by decide
theorem cert_e605593240554 : check e605593240554 [[],[]] .smaller = true := by decide
def e605593241262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e605593241262 : Closed e605593241262 ∧ code e605593241262 = 2804616496814 := by decide
theorem cert_e605593241262 : check e605593241262 [[],[]] .smaller = true := by decide
def e605593241274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e605593241274 : Closed e605593241274 ∧ code e605593241274 = 2804616496826 := by decide
theorem cert_e605593241274 : check e605593241274 [[],[]] .smaller = true := by decide
def e605593242030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605593242030 : Closed e605593242030 ∧ code e605593242030 = 2804616497582 := by decide
theorem cert_e605593242030 : check e605593242030 [[],[]] .smaller = true := by decide
def e605593242042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605593242042 : Closed e605593242042 ∧ code e605593242042 = 2804616497594 := by decide
theorem cert_e605593242042 : check e605593242042 [[],[]] .smaller = true := by decide
def e605593242090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605593242090 : Closed e605593242090 ∧ code e605593242090 = 2804616497642 := by decide
theorem cert_e605593242090 : check e605593242090 [[],[]] .smaller = true := by decide
def e605593242222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605593242222 : Closed e605593242222 ∧ code e605593242222 = 2804616497774 := by decide
theorem cert_e605593242222 : check e605593242222 [[],[]] .smaller = true := by decide
def e605593242234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605593242234 : Closed e605593242234 ∧ code e605593242234 = 2804616497786 := by decide
theorem cert_e605593242234 : check e605593242234 [[],[]] .smaller = true := by decide
def e605593242522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593242522 : Closed e605593242522 ∧ code e605593242522 = 2804616498074 := by decide
theorem cert_e605593242522 : check e605593242522 [[],[]] .smaller = true := by decide
def e605593242734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605593242734 : Closed e605593242734 ∧ code e605593242734 = 2804616498286 := by decide
theorem cert_e605593242734 : check e605593242734 [[],[]] .smaller = true := by decide
def e605593242746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605593242746 : Closed e605593242746 ∧ code e605593242746 = 2804616498298 := by decide
theorem cert_e605593242746 : check e605593242746 [[],[]] .smaller = true := by decide
def e605593242910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605593242910 : Closed e605593242910 ∧ code e605593242910 = 2804616498462 := by decide
theorem cert_e605593242910 : check e605593242910 [[],[]] .smaller = true := by decide
def e605593243078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605593243078 : Closed e605593243078 ∧ code e605593243078 = 2804616498630 := by decide
theorem cert_e605593243078 : check e605593243078 [[],[]] .smaller = true := by decide
def e605593243418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e605593243418 : Closed e605593243418 ∧ code e605593243418 = 2804616498970 := by decide
theorem cert_e605593243418 : check e605593243418 [[],[]] .smaller = true := by decide
def e605593243462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e605593243462 : Closed e605593243462 ∧ code e605593243462 = 2804616499014 := by decide
theorem cert_e605593243462 : check e605593243462 [[],[]] .smaller = true := by decide
def e605593245870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e605593245870 : Closed e605593245870 ∧ code e605593245870 = 2804616501422 := by decide
theorem cert_e605593245870 : check e605593245870 [[],[]] .smaller = true := by decide
def e605593245882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e605593245882 : Closed e605593245882 ∧ code e605593245882 = 2804616501434 := by decide
theorem cert_e605593245882 : check e605593245882 [[],[]] .smaller = true := by decide
def e605593246254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605593246254 : Closed e605593246254 ∧ code e605593246254 = 2804616501806 := by decide
theorem cert_e605593246254 : check e605593246254 [[],[]] .smaller = true := by decide
def e605593246430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e605593246430 : Closed e605593246430 ∧ code e605593246430 = 2804616501982 := by decide
theorem cert_e605593246430 : check e605593246430 [[],[]] .three = true := by decide
def e605593246434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605593246434 : Closed e605593246434 ∧ code e605593246434 = 2804616501986 := by decide
theorem cert_e605593246434 : check e605593246434 [[],[]] .smaller = true := by decide
def e605593246446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 2)))))))
theorem wire_e605593246446 : Closed e605593246446 ∧ code e605593246446 = 2804616501998 := by decide
theorem cert_e605593246446 : check e605593246446 [[],[]] .smaller = true := by decide
def e605593246454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e605593246454 : Closed e605593246454 ∧ code e605593246454 = 2804616502006 := by decide
theorem cert_e605593246454 : check e605593246454 [[],[]] .three = true := by decide
def e605593246558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e605593246558 : Closed e605593246558 ∧ code e605593246558 = 2804616502110 := by decide
theorem cert_e605593246558 : check e605593246558 [[],[]] .three = true := by decide
def e605593246574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e605593246574 : Closed e605593246574 ∧ code e605593246574 = 2804616502126 := by decide
theorem cert_e605593246574 : check e605593246574 [[],[]] .smaller = true := by decide
def e605593246582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e605593246582 : Closed e605593246582 ∧ code e605593246582 = 2804616502134 := by decide
theorem cert_e605593246582 : check e605593246582 [[],[]] .smaller = true := by decide
def e605593246586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e605593246586 : Closed e605593246586 ∧ code e605593246586 = 2804616502138 := by decide
theorem cert_e605593246586 : check e605593246586 [[],[]] .three = true := by decide
def e605593246602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605593246602 : Closed e605593246602 ∧ code e605593246602 = 2804616502154 := by decide
theorem cert_e605593246602 : check e605593246602 [[],[]] .smaller = true := by decide
def e605593246626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605593246626 : Closed e605593246626 ∧ code e605593246626 = 2804616502178 := by decide
theorem cert_e605593246626 : check e605593246626 [[],[]] .smaller = true := by decide
def e605593246638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e605593246638 : Closed e605593246638 ∧ code e605593246638 = 2804616502190 := by decide
theorem cert_e605593246638 : check e605593246638 [[],[]] .smaller = true := by decide
def e605593246646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e605593246646 : Closed e605593246646 ∧ code e605593246646 = 2804616502198 := by decide
theorem cert_e605593246646 : check e605593246646 [[],[]] .smaller = true := by decide
def e605593246650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e605593246650 : Closed e605593246650 ∧ code e605593246650 = 2804616502202 := by decide
theorem cert_e605593246650 : check e605593246650 [[],[]] .smaller = true := by decide
def e605593246678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e605593246678 : Closed e605593246678 ∧ code e605593246678 = 2804616502230 := by decide
theorem cert_e605593246678 : check e605593246678 [[],[]] .three = true := by decide
def e605593246682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e605593246682 : Closed e605593246682 ∧ code e605593246682 = 2804616502234 := by decide
theorem cert_e605593246682 : check e605593246682 [[],[]] .three = true := by decide
def e605593247070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e605593247070 : Closed e605593247070 ∧ code e605593247070 = 2804616502622 := by decide
theorem cert_e605593247070 : check e605593247070 [[],[]] .three = true := by decide
def e605593247086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e605593247086 : Closed e605593247086 ∧ code e605593247086 = 2804616502638 := by decide
theorem cert_e605593247086 : check e605593247086 [[],[]] .smaller = true := by decide
def e605593247094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e605593247094 : Closed e605593247094 ∧ code e605593247094 = 2804616502646 := by decide
theorem cert_e605593247094 : check e605593247094 [[],[]] .smaller = true := by decide
def e605593247098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e605593247098 : Closed e605593247098 ∧ code e605593247098 = 2804616502650 := by decide
theorem cert_e605593247098 : check e605593247098 [[],[]] .three = true := by decide
def e605593247150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e605593247150 : Closed e605593247150 ∧ code e605593247150 = 2804616502702 := by decide
theorem cert_e605593247150 : check e605593247150 [[],[]] .smaller = true := by decide
def e605593247162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e605593247162 : Closed e605593247162 ∧ code e605593247162 = 2804616502714 := by decide
theorem cert_e605593247162 : check e605593247162 [[],[]] .smaller = true := by decide
def e605593247190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e605593247190 : Closed e605593247190 ∧ code e605593247190 = 2804616502742 := by decide
theorem cert_e605593247190 : check e605593247190 [[],[]] .smaller = true := by decide
def e605593247194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e605593247194 : Closed e605593247194 ∧ code e605593247194 = 2804616502746 := by decide
theorem cert_e605593247194 : check e605593247194 [[],[]] .smaller = true := by decide
def e605593247210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e605593247210 : Closed e605593247210 ∧ code e605593247210 = 2804616502762 := by decide
theorem cert_e605593247210 : check e605593247210 [[],[]] .three = true := by decide
def e605593247274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e605593247274 : Closed e605593247274 ∧ code e605593247274 = 2804616502826 := by decide
theorem cert_e605593247274 : check e605593247274 [[],[]] .smaller = true := by decide
def e605593247370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605593247370 : Closed e605593247370 ∧ code e605593247370 = 2804616502922 := by decide
theorem cert_e605593247370 : check e605593247370 [[],[]] .smaller = true := by decide
def e605593247394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605593247394 : Closed e605593247394 ∧ code e605593247394 = 2804616502946 := by decide
theorem cert_e605593247394 : check e605593247394 [[],[]] .smaller = true := by decide
def e605593247406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e605593247406 : Closed e605593247406 ∧ code e605593247406 = 2804616502958 := by decide
theorem cert_e605593247406 : check e605593247406 [[],[]] .smaller = true := by decide
def e605593247414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e605593247414 : Closed e605593247414 ∧ code e605593247414 = 2804616502966 := by decide
theorem cert_e605593247414 : check e605593247414 [[],[]] .smaller = true := by decide
def e605593247418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e605593247418 : Closed e605593247418 ∧ code e605593247418 = 2804616502970 := by decide
theorem cert_e605593247418 : check e605593247418 [[],[]] .smaller = true := by decide
def e605593247446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e605593247446 : Closed e605593247446 ∧ code e605593247446 = 2804616502998 := by decide
theorem cert_e605593247446 : check e605593247446 [[],[]] .smaller = true := by decide
def e605593247450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e605593247450 : Closed e605593247450 ∧ code e605593247450 = 2804616503002 := by decide
theorem cert_e605593247450 : check e605593247450 [[],[]] .smaller = true := by decide
def e605593247466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605593247466 : Closed e605593247466 ∧ code e605593247466 = 2804616503018 := by decide
theorem cert_e605593247466 : check e605593247466 [[],[]] .smaller = true := by decide
def e605593247574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e605593247574 : Closed e605593247574 ∧ code e605593247574 = 2804616503126 := by decide
theorem cert_e605593247574 : check e605593247574 [[],[]] .three = true := by decide
def e605593247578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e605593247578 : Closed e605593247578 ∧ code e605593247578 = 2804616503130 := by decide
theorem cert_e605593247578 : check e605593247578 [[],[]] .three = true := by decide
def e605593247594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e605593247594 : Closed e605593247594 ∧ code e605593247594 = 2804616503146 := by decide
theorem cert_e605593247594 : check e605593247594 [[],[]] .three = true := by decide
def e605593247982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e605593247982 : Closed e605593247982 ∧ code e605593247982 = 2804616503534 := by decide
theorem cert_e605593247982 : check e605593247982 [[],[]] .smaller = true := by decide
def e605593247994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e605593247994 : Closed e605593247994 ∧ code e605593247994 = 2804616503546 := by decide
theorem cert_e605593247994 : check e605593247994 [[],[]] .smaller = true := by decide
def e605593248174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e605593248174 : Closed e605593248174 ∧ code e605593248174 = 2804616503726 := by decide
theorem cert_e605593248174 : check e605593248174 [[],[]] .smaller = true := by decide
def e605593248366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593248366 : Closed e605593248366 ∧ code e605593248366 = 2804616503918 := by decide
theorem cert_e605593248366 : check e605593248366 [[],[]] .smaller = true := by decide
def e605593248378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593248378 : Closed e605593248378 ∧ code e605593248378 = 2804616503930 := by decide
theorem cert_e605593248378 : check e605593248378 [[],[]] .smaller = true := by decide
def e605593248542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e605593248542 : Closed e605593248542 ∧ code e605593248542 = 2804616504094 := by decide
theorem cert_e605593248542 : check e605593248542 [[],[]] .smaller = true := by decide
def e605593248710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e605593248710 : Closed e605593248710 ∧ code e605593248710 = 2804616504262 := by decide
theorem cert_e605593248710 : check e605593248710 [[],[]] .smaller = true := by decide
def e605593249326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605593249326 : Closed e605593249326 ∧ code e605593249326 = 2804616504878 := by decide
theorem cert_e605593249326 : check e605593249326 [[],[]] .smaller = true := by decide
def e605593249502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e605593249502 : Closed e605593249502 ∧ code e605593249502 = 2804616505054 := by decide
theorem cert_e605593249502 : check e605593249502 [[],[]] .three = true := by decide
def e605593249506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e605593249506 : Closed e605593249506 ∧ code e605593249506 = 2804616505058 := by decide
theorem cert_e605593249506 : check e605593249506 [[],[]] .smaller = true := by decide
def e605593249518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e605593249518 : Closed e605593249518 ∧ code e605593249518 = 2804616505070 := by decide
theorem cert_e605593249518 : check e605593249518 [[],[]] .smaller = true := by decide
def e605593249526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e605593249526 : Closed e605593249526 ∧ code e605593249526 = 2804616505078 := by decide
theorem cert_e605593249526 : check e605593249526 [[],[]] .three = true := by decide
def e605593249630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e605593249630 : Closed e605593249630 ∧ code e605593249630 = 2804616505182 := by decide
theorem cert_e605593249630 : check e605593249630 [[],[]] .three = true := by decide
def e605593249646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e605593249646 : Closed e605593249646 ∧ code e605593249646 = 2804616505198 := by decide
theorem cert_e605593249646 : check e605593249646 [[],[]] .smaller = true := by decide
def e605593249654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e605593249654 : Closed e605593249654 ∧ code e605593249654 = 2804616505206 := by decide
theorem cert_e605593249654 : check e605593249654 [[],[]] .smaller = true := by decide
def e605593249658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e605593249658 : Closed e605593249658 ∧ code e605593249658 = 2804616505210 := by decide
theorem cert_e605593249658 : check e605593249658 [[],[]] .three = true := by decide
def e605593249674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605593249674 : Closed e605593249674 ∧ code e605593249674 = 2804616505226 := by decide
theorem cert_e605593249674 : check e605593249674 [[],[]] .smaller = true := by decide
def e605593249698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605593249698 : Closed e605593249698 ∧ code e605593249698 = 2804616505250 := by decide
theorem cert_e605593249698 : check e605593249698 [[],[]] .smaller = true := by decide
def e605593249710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e605593249710 : Closed e605593249710 ∧ code e605593249710 = 2804616505262 := by decide
theorem cert_e605593249710 : check e605593249710 [[],[]] .smaller = true := by decide
def e605593249718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e605593249718 : Closed e605593249718 ∧ code e605593249718 = 2804616505270 := by decide
theorem cert_e605593249718 : check e605593249718 [[],[]] .smaller = true := by decide
def e605593249722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e605593249722 : Closed e605593249722 ∧ code e605593249722 = 2804616505274 := by decide
theorem cert_e605593249722 : check e605593249722 [[],[]] .smaller = true := by decide
def e605593249750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e605593249750 : Closed e605593249750 ∧ code e605593249750 = 2804616505302 := by decide
theorem cert_e605593249750 : check e605593249750 [[],[]] .three = true := by decide
def e605593249754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e605593249754 : Closed e605593249754 ∧ code e605593249754 = 2804616505306 := by decide
theorem cert_e605593249754 : check e605593249754 [[],[]] .three = true := by decide
def e605593249854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e605593249854 : Closed e605593249854 ∧ code e605593249854 = 2804616505406 := by decide
theorem cert_e605593249854 : check e605593249854 [[],[]] .smaller = true := by decide
def e605593250270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e605593250270 : Closed e605593250270 ∧ code e605593250270 = 2804616505822 := by decide
theorem cert_e605593250270 : check e605593250270 [[],[]] .three = true := by decide
def e605593250274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605593250274 : Closed e605593250274 ∧ code e605593250274 = 2804616505826 := by decide
theorem cert_e605593250274 : check e605593250274 [[],[]] .smaller = true := by decide
def e605593250286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e605593250286 : Closed e605593250286 ∧ code e605593250286 = 2804616505838 := by decide
theorem cert_e605593250286 : check e605593250286 [[],[]] .smaller = true := by decide
def e605593250294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e605593250294 : Closed e605593250294 ∧ code e605593250294 = 2804616505846 := by decide
theorem cert_e605593250294 : check e605593250294 [[],[]] .three = true := by decide
def e605593251038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e605593251038 : Closed e605593251038 ∧ code e605593251038 = 2804616506590 := by decide
theorem cert_e605593251038 : check e605593251038 [[],[]] .three = true := by decide
def e605593251054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e605593251054 : Closed e605593251054 ∧ code e605593251054 = 2804616506606 := by decide
theorem cert_e605593251054 : check e605593251054 [[],[]] .smaller = true := by decide
def e605593251062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e605593251062 : Closed e605593251062 ∧ code e605593251062 = 2804616506614 := by decide
theorem cert_e605593251062 : check e605593251062 [[],[]] .smaller = true := by decide
def e605593251066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e605593251066 : Closed e605593251066 ∧ code e605593251066 = 2804616506618 := by decide
theorem cert_e605593251066 : check e605593251066 [[],[]] .three = true := by decide
def e605593251342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e605593251342 : Closed e605593251342 ∧ code e605593251342 = 2804616506894 := by decide
theorem cert_e605593251342 : check e605593251342 [[],[]] .smaller = true := by decide
def e605593251354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605593251354 : Closed e605593251354 ∧ code e605593251354 = 2804616506906 := by decide
theorem cert_e605593251354 : check e605593251354 [[],[]] .smaller = true := by decide
def e605593251426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605593251426 : Closed e605593251426 ∧ code e605593251426 = 2804616506978 := by decide
theorem cert_e605593251426 : check e605593251426 [[],[]] .smaller = true := by decide
def e605593251438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e605593251438 : Closed e605593251438 ∧ code e605593251438 = 2804616506990 := by decide
theorem cert_e605593251438 : check e605593251438 [[],[]] .smaller = true := by decide
def e605593251446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e605593251446 : Closed e605593251446 ∧ code e605593251446 = 2804616506998 := by decide
theorem cert_e605593251446 : check e605593251446 [[],[]] .smaller = true := by decide
def e605593251450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e605593251450 : Closed e605593251450 ∧ code e605593251450 = 2804616507002 := by decide
theorem cert_e605593251450 : check e605593251450 [[],[]] .smaller = true := by decide
def e605593251638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593251638 : Closed e605593251638 ∧ code e605593251638 = 2804616507190 := by decide
theorem cert_e605593251638 : check e605593251638 [[],[]] .three = true := by decide
def e605593251642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593251642 : Closed e605593251642 ∧ code e605593251642 = 2804616507194 := by decide
theorem cert_e605593251642 : check e605593251642 [[],[]] .three = true := by decide
def e605593252702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e605593252702 : Closed e605593252702 ∧ code e605593252702 = 2804616508254 := by decide
theorem cert_e605593252702 : check e605593252702 [[],[]] .three = true := by decide
def e605593252718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605593252718 : Closed e605593252718 ∧ code e605593252718 = 2804616508270 := by decide
theorem cert_e605593252718 : check e605593252718 [[],[]] .smaller = true := by decide
def e605593252726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605593252726 : Closed e605593252726 ∧ code e605593252726 = 2804616508278 := by decide
theorem cert_e605593252726 : check e605593252726 [[],[]] .smaller = true := by decide
def e605593252730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e605593252730 : Closed e605593252730 ∧ code e605593252730 = 2804616508282 := by decide
theorem cert_e605593252730 : check e605593252730 [[],[]] .three = true := by decide
def e605593252782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605593252782 : Closed e605593252782 ∧ code e605593252782 = 2804616508334 := by decide
theorem cert_e605593252782 : check e605593252782 [[],[]] .smaller = true := by decide
def e605593252794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605593252794 : Closed e605593252794 ∧ code e605593252794 = 2804616508346 := by decide
theorem cert_e605593252794 : check e605593252794 [[],[]] .smaller = true := by decide
def e605593252822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605593252822 : Closed e605593252822 ∧ code e605593252822 = 2804616508374 := by decide
theorem cert_e605593252822 : check e605593252822 [[],[]] .smaller = true := by decide
def e605593252826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605593252826 : Closed e605593252826 ∧ code e605593252826 = 2804616508378 := by decide
theorem cert_e605593252826 : check e605593252826 [[],[]] .smaller = true := by decide
def e605593252842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e605593252842 : Closed e605593252842 ∧ code e605593252842 = 2804616508394 := by decide
theorem cert_e605593252842 : check e605593252842 [[],[]] .three = true := by decide
def e605593253086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e605593253086 : Closed e605593253086 ∧ code e605593253086 = 2804616508638 := by decide
theorem cert_e605593253086 : check e605593253086 [[],[]] .three = true := by decide
end Blc.Floor41
