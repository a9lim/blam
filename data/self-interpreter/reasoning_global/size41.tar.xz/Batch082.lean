import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605593266026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e605593266026 : Closed e605593266026 ∧ code e605593266026 = 2804616521578 := by decide
theorem cert_e605593266026 : check e605593266026 [[],[]] .three = true := by decide
def e605593266090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e605593266090 : Closed e605593266090 ∧ code e605593266090 = 2804616521642 := by decide
theorem cert_e605593266090 : check e605593266090 [[],[]] .three = true := by decide
def e605593266606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605593266606 : Closed e605593266606 ∧ code e605593266606 = 2804616522158 := by decide
theorem cert_e605593266606 : check e605593266606 [[],[]] .three = true := by decide
def e605593266614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e605593266614 : Closed e605593266614 ∧ code e605593266614 = 2804616522166 := by decide
theorem cert_e605593266614 : check e605593266614 [[],[]] .three = true := by decide
def e605593266618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605593266618 : Closed e605593266618 ∧ code e605593266618 = 2804616522170 := by decide
theorem cert_e605593266618 : check e605593266618 [[],[]] .three = true := by decide
def e605593266646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e605593266646 : Closed e605593266646 ∧ code e605593266646 = 2804616522198 := by decide
theorem cert_e605593266646 : check e605593266646 [[],[]] .three = true := by decide
def e605593266650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e605593266650 : Closed e605593266650 ∧ code e605593266650 = 2804616522202 := by decide
theorem cert_e605593266650 : check e605593266650 [[],[]] .three = true := by decide
def e605593266666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605593266666 : Closed e605593266666 ∧ code e605593266666 = 2804616522218 := by decide
theorem cert_e605593266666 : check e605593266666 [[],[]] .three = true := by decide
def e605593266798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605593266798 : Closed e605593266798 ∧ code e605593266798 = 2804616522350 := by decide
theorem cert_e605593266798 : check e605593266798 [[],[]] .three = true := by decide
def e605593266806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e605593266806 : Closed e605593266806 ∧ code e605593266806 = 2804616522358 := by decide
theorem cert_e605593266806 : check e605593266806 [[],[]] .three = true := by decide
def e605593266810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605593266810 : Closed e605593266810 ∧ code e605593266810 = 2804616522362 := by decide
theorem cert_e605593266810 : check e605593266810 [[],[]] .three = true := by decide
def e605593266998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593266998 : Closed e605593266998 ∧ code e605593266998 = 2804616522550 := by decide
theorem cert_e605593266998 : check e605593266998 [[],[]] .three = true := by decide
def e605593267002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593267002 : Closed e605593267002 ∧ code e605593267002 = 2804616522554 := by decide
theorem cert_e605593267002 : check e605593267002 [[],[]] .three = true := by decide
def e605593267098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593267098 : Closed e605593267098 ∧ code e605593267098 = 2804616522650 := by decide
theorem cert_e605593267098 : check e605593267098 [[],[]] .three = true := by decide
def e605593267414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605593267414 : Closed e605593267414 ∧ code e605593267414 = 2804616522966 := by decide
theorem cert_e605593267414 : check e605593267414 [[],[]] .three = true := by decide
def e605593267418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605593267418 : Closed e605593267418 ∧ code e605593267418 = 2804616522970 := by decide
theorem cert_e605593267418 : check e605593267418 [[],[]] .three = true := by decide
def e605593267434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605593267434 : Closed e605593267434 ∧ code e605593267434 = 2804616522986 := by decide
theorem cert_e605593267434 : check e605593267434 [[],[]] .three = true := by decide
def e605593267510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605593267510 : Closed e605593267510 ∧ code e605593267510 = 2804616523062 := by decide
theorem cert_e605593267510 : check e605593267510 [[],[]] .three = true := by decide
def e605593267514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605593267514 : Closed e605593267514 ∧ code e605593267514 = 2804616523066 := by decide
theorem cert_e605593267514 : check e605593267514 [[],[]] .three = true := by decide
def e605593267610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593267610 : Closed e605593267610 ∧ code e605593267610 = 2804616523162 := by decide
theorem cert_e605593267610 : check e605593267610 [[],[]] .three = true := by decide
def e605593267678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 3)))))))
theorem wire_e605593267678 : Closed e605593267678 ∧ code e605593267678 = 2804616523230 := by decide
theorem cert_e605593267678 : check e605593267678 [[],[]] .three = true := by decide
def e605593267694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 3)) (.var 2)))))))
theorem wire_e605593267694 : Closed e605593267694 ∧ code e605593267694 = 2804616523246 := by decide
theorem cert_e605593267694 : check e605593267694 [[],[]] .three = true := by decide
def e605593267818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605593267818 : Closed e605593267818 ∧ code e605593267818 = 2804616523370 := by decide
theorem cert_e605593267818 : check e605593267818 [[],[]] .three = true := by decide
def e605593267866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605593267866 : Closed e605593267866 ∧ code e605593267866 = 2804616523418 := by decide
theorem cert_e605593267866 : check e605593267866 [[],[]] .three = true := by decide
def e605593267934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 3)))))))
theorem wire_e605593267934 : Closed e605593267934 ∧ code e605593267934 = 2804616523486 := by decide
theorem cert_e605593267934 : check e605593267934 [[],[]] .three = true := by decide
def e605593267958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 3)) (.var 1)))))))
theorem wire_e605593267958 : Closed e605593267958 ∧ code e605593267958 = 2804616523510 := by decide
theorem cert_e605593267958 : check e605593267958 [[],[]] .three = true := by decide
def e605593268078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 2)))))))
theorem wire_e605593268078 : Closed e605593268078 ∧ code e605593268078 = 2804616523630 := by decide
private def t_e605593268078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 2)))))))
theorem cert_e605593268078 : ¬ IsSelfInterpreter e605593268078 :=
  wSource (t := t_e605593268078) (replay_sound (ps := []) (t := e605593268078) (by decide)) (by decide)
def e605593268086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 2)) (.var 1)))))))
theorem wire_e605593268086 : Closed e605593268086 ∧ code e605593268086 = 2804616523638 := by decide
private def t_e605593268086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 2)) (.var 1)))))))
theorem cert_e605593268086 : ¬ IsSelfInterpreter e605593268086 :=
  wSource (t := t_e605593268086) (replay_sound (ps := []) (t := e605593268086) (by decide)) (by decide)
def e605593279726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 2))))))))
theorem wire_e605593279726 : Closed e605593279726 ∧ code e605593279726 = 2804616535278 := by decide
theorem cert_e605593279726 : check e605593279726 [[],[]] .smaller = true := by decide
def e605593279734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 1))))))))
theorem wire_e605593279734 : Closed e605593279734 ∧ code e605593279734 = 2804616535286 := by decide
theorem cert_e605593279734 : check e605593279734 [[],[]] .smaller = true := by decide
def e605593280110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593280110 : Closed e605593280110 ∧ code e605593280110 = 2804616535662 := by decide
theorem cert_e605593280110 : check e605593280110 [[],[]] .smaller = true := by decide
def e605593280122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593280122 : Closed e605593280122 ∧ code e605593280122 = 2804616535674 := by decide
theorem cert_e605593280122 : check e605593280122 [[],[]] .smaller = true := by decide
def e605593280310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593280310 : Closed e605593280310 ∧ code e605593280310 = 2804616535862 := by decide
theorem cert_e605593280310 : check e605593280310 [[],[]] .smaller = true := by decide
def e605593280314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593280314 : Closed e605593280314 ∧ code e605593280314 = 2804616535866 := by decide
theorem cert_e605593280314 : check e605593280314 [[],[]] .smaller = true := by decide
def e605593284026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))))
theorem wire_e605593284026 : Closed e605593284026 ∧ code e605593284026 = 2804616539578 := by decide
theorem cert_e605593284026 : check e605593284026 [[],[]] .smaller = true := by decide
def e605593284058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))))
theorem wire_e605593284058 : Closed e605593284058 ∧ code e605593284058 = 2804616539610 := by decide
theorem cert_e605593284058 : check e605593284058 [[],[]] .smaller = true := by decide
def e605593284282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))))
theorem wire_e605593284282 : Closed e605593284282 ∧ code e605593284282 = 2804616539834 := by decide
theorem cert_e605593284282 : check e605593284282 [[],[]] .smaller = true := by decide
def e605593284330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))))
theorem wire_e605593284330 : Closed e605593284330 ∧ code e605593284330 = 2804616539882 := by decide
theorem cert_e605593284330 : check e605593284330 [[],[]] .smaller = true := by decide
def e605593284442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))))
theorem wire_e605593284442 : Closed e605593284442 ∧ code e605593284442 = 2804616539994 := by decide
theorem cert_e605593284442 : check e605593284442 [[],[]] .smaller = true := by decide
def e605593284458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))))
theorem wire_e605593284458 : Closed e605593284458 ∧ code e605593284458 = 2804616540010 := by decide
theorem cert_e605593284458 : check e605593284458 [[],[]] .smaller = true := by decide
def e605593285562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))))
theorem wire_e605593285562 : Closed e605593285562 ∧ code e605593285562 = 2804616541114 := by decide
theorem cert_e605593285562 : check e605593285562 [[],[]] .smaller = true := by decide
def e605593285594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))))
theorem wire_e605593285594 : Closed e605593285594 ∧ code e605593285594 = 2804616541146 := by decide
theorem cert_e605593285594 : check e605593285594 [[],[]] .smaller = true := by decide
def e605593285870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e605593285870 : Closed e605593285870 ∧ code e605593285870 = 2804616541422 := by decide
theorem cert_e605593285870 : check e605593285870 [[],[]] .smaller = true := by decide
def e605593285878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e605593285878 : Closed e605593285878 ∧ code e605593285878 = 2804616541430 := by decide
theorem cert_e605593285878 : check e605593285878 [[],[]] .smaller = true := by decide
def e605593287098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e605593287098 : Closed e605593287098 ∧ code e605593287098 = 2804616542650 := by decide
theorem cert_e605593287098 : check e605593287098 [[],[]] .smaller = true := by decide
def e605593287146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e605593287146 : Closed e605593287146 ∧ code e605593287146 = 2804616542698 := by decide
theorem cert_e605593287146 : check e605593287146 [[],[]] .smaller = true := by decide
def e605593287646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 3)))))))
theorem wire_e605593287646 : Closed e605593287646 ∧ code e605593287646 = 2804616543198 := by decide
theorem cert_e605593287646 : check e605593287646 [[],[]] .three = true := by decide
def e605593287662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 4)))) (.var 2)))))))
theorem wire_e605593287662 : Closed e605593287662 ∧ code e605593287662 = 2804616543214 := by decide
theorem cert_e605593287662 : check e605593287662 [[],[]] .three = true := by decide
def e605593287898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e605593287898 : Closed e605593287898 ∧ code e605593287898 = 2804616543450 := by decide
theorem cert_e605593287898 : check e605593287898 [[],[]] .smaller = true := by decide
def e605593287914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e605593287914 : Closed e605593287914 ∧ code e605593287914 = 2804616543466 := by decide
theorem cert_e605593287914 : check e605593287914 [[],[]] .smaller = true := by decide
def e605593288158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 3)))))))
theorem wire_e605593288158 : Closed e605593288158 ∧ code e605593288158 = 2804616543710 := by decide
theorem cert_e605593288158 : check e605593288158 [[],[]] .three = true := by decide
def e605593288174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 2)))))))
theorem wire_e605593288174 : Closed e605593288174 ∧ code e605593288174 = 2804616543726 := by decide
theorem cert_e605593288174 : check e605593288174 [[],[]] .smaller = true := by decide
def e605593288182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 4)))) (.var 1)))))))
theorem wire_e605593288182 : Closed e605593288182 ∧ code e605593288182 = 2804616543734 := by decide
theorem cert_e605593288182 : check e605593288182 [[],[]] .three = true := by decide
def e605593288414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 3)))))))
theorem wire_e605593288414 : Closed e605593288414 ∧ code e605593288414 = 2804616543966 := by decide
theorem cert_e605593288414 : check e605593288414 [[],[]] .three = true := by decide
def e605593288430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 2)))))))
theorem wire_e605593288430 : Closed e605593288430 ∧ code e605593288430 = 2804616543982 := by decide
theorem cert_e605593288430 : check e605593288430 [[],[]] .smaller = true := by decide
def e605593288438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 3)))) (.var 1)))))))
theorem wire_e605593288438 : Closed e605593288438 ∧ code e605593288438 = 2804616543990 := by decide
theorem cert_e605593288438 : check e605593288438 [[],[]] .smaller = true := by decide
def e605593288442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 4)))) (.var 0)))))))
theorem wire_e605593288442 : Closed e605593288442 ∧ code e605593288442 = 2804616543994 := by decide
theorem cert_e605593288442 : check e605593288442 [[],[]] .three = true := by decide
def e605593288558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 1)))) (.var 2)))))))
theorem wire_e605593288558 : Closed e605593288558 ∧ code e605593288558 = 2804616544110 := by decide
theorem cert_e605593288558 : check e605593288558 [[],[]] .three = true := by decide
def e605593288566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 2)))) (.var 1)))))))
theorem wire_e605593288566 : Closed e605593288566 ∧ code e605593288566 = 2804616544118 := by decide
theorem cert_e605593288566 : check e605593288566 [[],[]] .three = true := by decide
def e605593288570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 3)))) (.var 0)))))))
theorem wire_e605593288570 : Closed e605593288570 ∧ code e605593288570 = 2804616544122 := by decide
theorem cert_e605593288570 : check e605593288570 [[],[]] .three = true := by decide
def e605593291630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605593291630 : Closed e605593291630 ∧ code e605593291630 = 2804616547182 := by decide
theorem cert_e605593291630 : check e605593291630 [[],[]] .smaller = true := by decide
def e605593291638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605593291638 : Closed e605593291638 ∧ code e605593291638 = 2804616547190 := by decide
theorem cert_e605593291638 : check e605593291638 [[],[]] .smaller = true := by decide
def e605593291694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605593291694 : Closed e605593291694 ∧ code e605593291694 = 2804616547246 := by decide
theorem cert_e605593291694 : check e605593291694 [[],[]] .smaller = true := by decide
def e605593291706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605593291706 : Closed e605593291706 ∧ code e605593291706 = 2804616547258 := by decide
theorem cert_e605593291706 : check e605593291706 [[],[]] .smaller = true := by decide
def e605593291734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605593291734 : Closed e605593291734 ∧ code e605593291734 = 2804616547286 := by decide
theorem cert_e605593291734 : check e605593291734 [[],[]] .smaller = true := by decide
def e605593291738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605593291738 : Closed e605593291738 ∧ code e605593291738 = 2804616547290 := by decide
theorem cert_e605593291738 : check e605593291738 [[],[]] .smaller = true := by decide
def e605593292014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605593292014 : Closed e605593292014 ∧ code e605593292014 = 2804616547566 := by decide
theorem cert_e605593292014 : check e605593292014 [[],[]] .smaller = true := by decide
def e605593292022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605593292022 : Closed e605593292022 ∧ code e605593292022 = 2804616547574 := by decide
theorem cert_e605593292022 : check e605593292022 [[],[]] .smaller = true := by decide
def e605593292398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593292398 : Closed e605593292398 ∧ code e605593292398 = 2804616547950 := by decide
theorem cert_e605593292398 : check e605593292398 [[],[]] .smaller = true := by decide
def e605593292410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593292410 : Closed e605593292410 ∧ code e605593292410 = 2804616547962 := by decide
theorem cert_e605593292410 : check e605593292410 [[],[]] .smaller = true := by decide
def e605593292598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593292598 : Closed e605593292598 ∧ code e605593292598 = 2804616548150 := by decide
theorem cert_e605593292598 : check e605593292598 [[],[]] .smaller = true := by decide
def e605593292602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593292602 : Closed e605593292602 ∧ code e605593292602 = 2804616548154 := by decide
theorem cert_e605593292602 : check e605593292602 [[],[]] .smaller = true := by decide
def e605593298718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605593298718 : Closed e605593298718 ∧ code e605593298718 = 2804616554270 := by decide
theorem cert_e605593298718 : check e605593298718 [[],[]] .smaller = true := by decide
def e605593298830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605593298830 : Closed e605593298830 ∧ code e605593298830 = 2804616554382 := by decide
theorem cert_e605593298830 : check e605593298830 [[],[]] .smaller = true := by decide
def e605593301790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605593301790 : Closed e605593301790 ∧ code e605593301790 = 2804616557342 := by decide
theorem cert_e605593301790 : check e605593301790 [[],[]] .smaller = true := by decide
def e605593301958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605593301958 : Closed e605593301958 ∧ code e605593301958 = 2804616557510 := by decide
theorem cert_e605593301958 : check e605593301958 [[],[]] .smaller = true := by decide
def e605593303438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605593303438 : Closed e605593303438 ∧ code e605593303438 = 2804616558990 := by decide
theorem cert_e605593303438 : check e605593303438 [[],[]] .smaller = true := by decide
def e605593303494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605593303494 : Closed e605593303494 ∧ code e605593303494 = 2804616559046 := by decide
theorem cert_e605593303494 : check e605593303494 [[],[]] .smaller = true := by decide
def e605593317742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 2)))))))
theorem wire_e605593317742 : Closed e605593317742 ∧ code e605593317742 = 2804616573294 := by decide
theorem cert_e605593317742 : check e605593317742 [[],[]] .smaller = true := by decide
def e605593317750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 1)))))))
theorem wire_e605593317750 : Closed e605593317750 ∧ code e605593317750 = 2804616573302 := by decide
theorem cert_e605593317750 : check e605593317750 [[],[]] .smaller = true := by decide
def e605593318878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 3)))))))
theorem wire_e605593318878 : Closed e605593318878 ∧ code e605593318878 = 2804616574430 := by decide
theorem cert_e605593318878 : check e605593318878 [[],[]] .three = true := by decide
def e605593318894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 2)))))))
theorem wire_e605593318894 : Closed e605593318894 ∧ code e605593318894 = 2804616574446 := by decide
theorem cert_e605593318894 : check e605593318894 [[],[]] .three = true := by decide
def e605593318958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605593318958 : Closed e605593318958 ∧ code e605593318958 = 2804616574510 := by decide
theorem cert_e605593318958 : check e605593318958 [[],[]] .smaller = true := by decide
def e605593319134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 3)))))))
theorem wire_e605593319134 : Closed e605593319134 ∧ code e605593319134 = 2804616574686 := by decide
theorem cert_e605593319134 : check e605593319134 [[],[]] .three = true := by decide
def e605593319138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e605593319138 : Closed e605593319138 ∧ code e605593319138 = 2804616574690 := by decide
theorem cert_e605593319138 : check e605593319138 [[],[]] .smaller = true := by decide
def e605593319150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2)))))))
theorem wire_e605593319150 : Closed e605593319150 ∧ code e605593319150 = 2804616574702 := by decide
theorem cert_e605593319150 : check e605593319150 [[],[]] .smaller = true := by decide
def e605593319158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 1)))))))
theorem wire_e605593319158 : Closed e605593319158 ∧ code e605593319158 = 2804616574710 := by decide
theorem cert_e605593319158 : check e605593319158 [[],[]] .three = true := by decide
def e605593319190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605593319190 : Closed e605593319190 ∧ code e605593319190 = 2804616574742 := by decide
theorem cert_e605593319190 : check e605593319190 [[],[]] .smaller = true := by decide
def e605593319262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 3)))))))
theorem wire_e605593319262 : Closed e605593319262 ∧ code e605593319262 = 2804616574814 := by decide
theorem cert_e605593319262 : check e605593319262 [[],[]] .three = true := by decide
def e605593319266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e605593319266 : Closed e605593319266 ∧ code e605593319266 = 2804616574818 := by decide
theorem cert_e605593319266 : check e605593319266 [[],[]] .smaller = true := by decide
def e605593319278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2)))))))
theorem wire_e605593319278 : Closed e605593319278 ∧ code e605593319278 = 2804616574830 := by decide
theorem cert_e605593319278 : check e605593319278 [[],[]] .smaller = true := by decide
def e605593319286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1)))))))
theorem wire_e605593319286 : Closed e605593319286 ∧ code e605593319286 = 2804616574838 := by decide
theorem cert_e605593319286 : check e605593319286 [[],[]] .smaller = true := by decide
def e605593319290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))) (.var 0)))))))
theorem wire_e605593319290 : Closed e605593319290 ∧ code e605593319290 = 2804616574842 := by decide
theorem cert_e605593319290 : check e605593319290 [[],[]] .three = true := by decide
def e605593319342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 2)))))))
theorem wire_e605593319342 : Closed e605593319342 ∧ code e605593319342 = 2804616574894 := by decide
theorem cert_e605593319342 : check e605593319342 [[],[]] .three = true := by decide
def e605593319350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 1)))))))
theorem wire_e605593319350 : Closed e605593319350 ∧ code e605593319350 = 2804616574902 := by decide
theorem cert_e605593319350 : check e605593319350 [[],[]] .three = true := by decide
def e605593319354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))) (.var 0)))))))
theorem wire_e605593319354 : Closed e605593319354 ∧ code e605593319354 = 2804616574906 := by decide
theorem cert_e605593319354 : check e605593319354 [[],[]] .three = true := by decide
def e605593319598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 2)))))))
theorem wire_e605593319598 : Closed e605593319598 ∧ code e605593319598 = 2804616575150 := by decide
theorem cert_e605593319598 : check e605593319598 [[],[]] .smaller = true := by decide
def e605593319610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 0)))))))
theorem wire_e605593319610 : Closed e605593319610 ∧ code e605593319610 = 2804616575162 := by decide
theorem cert_e605593319610 : check e605593319610 [[],[]] .smaller = true := by decide
def e605593319982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605593319982 : Closed e605593319982 ∧ code e605593319982 = 2804616575534 := by decide
theorem cert_e605593319982 : check e605593319982 [[],[]] .smaller = true := by decide
def e605593320158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e605593320158 : Closed e605593320158 ∧ code e605593320158 = 2804616575710 := by decide
theorem cert_e605593320158 : check e605593320158 [[],[]] .three = true := by decide
def e605593320162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e605593320162 : Closed e605593320162 ∧ code e605593320162 = 2804616575714 := by decide
theorem cert_e605593320162 : check e605593320162 [[],[]] .smaller = true := by decide
def e605593320174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2)))))))
theorem wire_e605593320174 : Closed e605593320174 ∧ code e605593320174 = 2804616575726 := by decide
theorem cert_e605593320174 : check e605593320174 [[],[]] .smaller = true := by decide
def e605593320182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e605593320182 : Closed e605593320182 ∧ code e605593320182 = 2804616575734 := by decide
theorem cert_e605593320182 : check e605593320182 [[],[]] .three = true := by decide
def e605593320286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e605593320286 : Closed e605593320286 ∧ code e605593320286 = 2804616575838 := by decide
theorem cert_e605593320286 : check e605593320286 [[],[]] .three = true := by decide
def e605593320302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 2)))))))
theorem wire_e605593320302 : Closed e605593320302 ∧ code e605593320302 = 2804616575854 := by decide
theorem cert_e605593320302 : check e605593320302 [[],[]] .smaller = true := by decide
def e605593320310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 1)))))))
theorem wire_e605593320310 : Closed e605593320310 ∧ code e605593320310 = 2804616575862 := by decide
theorem cert_e605593320310 : check e605593320310 [[],[]] .smaller = true := by decide
def e605593320314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e605593320314 : Closed e605593320314 ∧ code e605593320314 = 2804616575866 := by decide
theorem cert_e605593320314 : check e605593320314 [[],[]] .three = true := by decide
def e605593320330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605593320330 : Closed e605593320330 ∧ code e605593320330 = 2804616575882 := by decide
theorem cert_e605593320330 : check e605593320330 [[],[]] .smaller = true := by decide
def e605593320354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605593320354 : Closed e605593320354 ∧ code e605593320354 = 2804616575906 := by decide
theorem cert_e605593320354 : check e605593320354 [[],[]] .smaller = true := by decide
def e605593320366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2)))))))
theorem wire_e605593320366 : Closed e605593320366 ∧ code e605593320366 = 2804616575918 := by decide
theorem cert_e605593320366 : check e605593320366 [[],[]] .smaller = true := by decide
def e605593320374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 1)))))))
theorem wire_e605593320374 : Closed e605593320374 ∧ code e605593320374 = 2804616575926 := by decide
theorem cert_e605593320374 : check e605593320374 [[],[]] .smaller = true := by decide
def e605593320378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0)))))))
theorem wire_e605593320378 : Closed e605593320378 ∧ code e605593320378 = 2804616575930 := by decide
theorem cert_e605593320378 : check e605593320378 [[],[]] .smaller = true := by decide
def e605593320406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e605593320406 : Closed e605593320406 ∧ code e605593320406 = 2804616575958 := by decide
theorem cert_e605593320406 : check e605593320406 [[],[]] .three = true := by decide
def e605593320410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e605593320410 : Closed e605593320410 ∧ code e605593320410 = 2804616575962 := by decide
theorem cert_e605593320410 : check e605593320410 [[],[]] .three = true := by decide
def e605593320534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 1)))))))
theorem wire_e605593320534 : Closed e605593320534 ∧ code e605593320534 = 2804616576086 := by decide
theorem cert_e605593320534 : check e605593320534 [[],[]] .smaller = true := by decide
def e605593320538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 0)))))))
theorem wire_e605593320538 : Closed e605593320538 ∧ code e605593320538 = 2804616576090 := by decide
theorem cert_e605593320538 : check e605593320538 [[],[]] .smaller = true := by decide
def e605593320726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e605593320726 : Closed e605593320726 ∧ code e605593320726 = 2804616576278 := by decide
theorem cert_e605593320726 : check e605593320726 [[],[]] .smaller = true := by decide
def e605593320798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e605593320798 : Closed e605593320798 ∧ code e605593320798 = 2804616576350 := by decide
theorem cert_e605593320798 : check e605593320798 [[],[]] .three = true := by decide
def e605593320802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e605593320802 : Closed e605593320802 ∧ code e605593320802 = 2804616576354 := by decide
theorem cert_e605593320802 : check e605593320802 [[],[]] .smaller = true := by decide
def e605593320814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e605593320814 : Closed e605593320814 ∧ code e605593320814 = 2804616576366 := by decide
theorem cert_e605593320814 : check e605593320814 [[],[]] .smaller = true := by decide
def e605593320822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e605593320822 : Closed e605593320822 ∧ code e605593320822 = 2804616576374 := by decide
theorem cert_e605593320822 : check e605593320822 [[],[]] .smaller = true := by decide
def e605593320826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e605593320826 : Closed e605593320826 ∧ code e605593320826 = 2804616576378 := by decide
theorem cert_e605593320826 : check e605593320826 [[],[]] .three = true := by decide
def e605593320842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605593320842 : Closed e605593320842 ∧ code e605593320842 = 2804616576394 := by decide
theorem cert_e605593320842 : check e605593320842 [[],[]] .smaller = true := by decide
def e605593320866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e605593320866 : Closed e605593320866 ∧ code e605593320866 = 2804616576418 := by decide
theorem cert_e605593320866 : check e605593320866 [[],[]] .smaller = true := by decide
def e605593320878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e605593320878 : Closed e605593320878 ∧ code e605593320878 = 2804616576430 := by decide
theorem cert_e605593320878 : check e605593320878 [[],[]] .smaller = true := by decide
def e605593320886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 1)))))))
theorem wire_e605593320886 : Closed e605593320886 ∧ code e605593320886 = 2804616576438 := by decide
theorem cert_e605593320886 : check e605593320886 [[],[]] .smaller = true := by decide
def e605593320890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e605593320890 : Closed e605593320890 ∧ code e605593320890 = 2804616576442 := by decide
theorem cert_e605593320890 : check e605593320890 [[],[]] .smaller = true := by decide
def e605593320918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e605593320918 : Closed e605593320918 ∧ code e605593320918 = 2804616576470 := by decide
theorem cert_e605593320918 : check e605593320918 [[],[]] .smaller = true := by decide
def e605593320922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e605593320922 : Closed e605593320922 ∧ code e605593320922 = 2804616576474 := by decide
theorem cert_e605593320922 : check e605593320922 [[],[]] .smaller = true := by decide
def e605593320938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e605593320938 : Closed e605593320938 ∧ code e605593320938 = 2804616576490 := by decide
theorem cert_e605593320938 : check e605593320938 [[],[]] .three = true := by decide
def e605593321134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e605593321134 : Closed e605593321134 ∧ code e605593321134 = 2804616576686 := by decide
theorem cert_e605593321134 : check e605593321134 [[],[]] .three = true := by decide
def e605593321142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e605593321142 : Closed e605593321142 ∧ code e605593321142 = 2804616576694 := by decide
theorem cert_e605593321142 : check e605593321142 [[],[]] .three = true := by decide
def e605593321146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e605593321146 : Closed e605593321146 ∧ code e605593321146 = 2804616576698 := by decide
theorem cert_e605593321146 : check e605593321146 [[],[]] .three = true := by decide
def e605593321174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e605593321174 : Closed e605593321174 ∧ code e605593321174 = 2804616576726 := by decide
theorem cert_e605593321174 : check e605593321174 [[],[]] .three = true := by decide
def e605593321178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e605593321178 : Closed e605593321178 ∧ code e605593321178 = 2804616576730 := by decide
theorem cert_e605593321178 : check e605593321178 [[],[]] .three = true := by decide
def e605593321194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e605593321194 : Closed e605593321194 ∧ code e605593321194 = 2804616576746 := by decide
theorem cert_e605593321194 : check e605593321194 [[],[]] .three = true := by decide
def e605593321966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 2)))))))
theorem wire_e605593321966 : Closed e605593321966 ∧ code e605593321966 = 2804616577518 := by decide
theorem cert_e605593321966 : check e605593321966 [[],[]] .smaller = true := by decide
def e605593321974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 1)))))))
theorem wire_e605593321974 : Closed e605593321974 ∧ code e605593321974 = 2804616577526 := by decide
theorem cert_e605593321974 : check e605593321974 [[],[]] .smaller = true := by decide
def e605593322734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e605593322734 : Closed e605593322734 ∧ code e605593322734 = 2804616578286 := by decide
theorem cert_e605593322734 : check e605593322734 [[],[]] .smaller = true := by decide
def e605593322742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e605593322742 : Closed e605593322742 ∧ code e605593322742 = 2804616578294 := by decide
theorem cert_e605593322742 : check e605593322742 [[],[]] .smaller = true := by decide
def e605593323294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 3))))))))
theorem wire_e605593323294 : Closed e605593323294 ∧ code e605593323294 = 2804616578846 := by decide
theorem cert_e605593323294 : check e605593323294 [[],[]] .smaller = true := by decide
def e605593323406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 2))))))))
theorem wire_e605593323406 : Closed e605593323406 ∧ code e605593323406 = 2804616578958 := by decide
theorem cert_e605593323406 : check e605593323406 [[],[]] .smaller = true := by decide
def e605593325022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 3)))))))
theorem wire_e605593325022 : Closed e605593325022 ∧ code e605593325022 = 2804616580574 := by decide
theorem cert_e605593325022 : check e605593325022 [[],[]] .three = true := by decide
def e605593325038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 2)))))))
theorem wire_e605593325038 : Closed e605593325038 ∧ code e605593325038 = 2804616580590 := by decide
theorem cert_e605593325038 : check e605593325038 [[],[]] .three = true := by decide
def e605593325102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e605593325102 : Closed e605593325102 ∧ code e605593325102 = 2804616580654 := by decide
theorem cert_e605593325102 : check e605593325102 [[],[]] .smaller = true := by decide
def e605593325278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 3)))))))
theorem wire_e605593325278 : Closed e605593325278 ∧ code e605593325278 = 2804616580830 := by decide
theorem cert_e605593325278 : check e605593325278 [[],[]] .three = true := by decide
def e605593325282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e605593325282 : Closed e605593325282 ∧ code e605593325282 = 2804616580834 := by decide
theorem cert_e605593325282 : check e605593325282 [[],[]] .smaller = true := by decide
def e605593325294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e605593325294 : Closed e605593325294 ∧ code e605593325294 = 2804616580846 := by decide
theorem cert_e605593325294 : check e605593325294 [[],[]] .smaller = true := by decide
def e605593325302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e605593325302 : Closed e605593325302 ∧ code e605593325302 = 2804616580854 := by decide
theorem cert_e605593325302 : check e605593325302 [[],[]] .three = true := by decide
def e605593325334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e605593325334 : Closed e605593325334 ∧ code e605593325334 = 2804616580886 := by decide
theorem cert_e605593325334 : check e605593325334 [[],[]] .smaller = true := by decide
def e605593325406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 3)))))))
theorem wire_e605593325406 : Closed e605593325406 ∧ code e605593325406 = 2804616580958 := by decide
theorem cert_e605593325406 : check e605593325406 [[],[]] .three = true := by decide
def e605593325410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e605593325410 : Closed e605593325410 ∧ code e605593325410 = 2804616580962 := by decide
theorem cert_e605593325410 : check e605593325410 [[],[]] .smaller = true := by decide
def e605593325422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e605593325422 : Closed e605593325422 ∧ code e605593325422 = 2804616580974 := by decide
theorem cert_e605593325422 : check e605593325422 [[],[]] .smaller = true := by decide
def e605593325430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1)))))))
theorem wire_e605593325430 : Closed e605593325430 ∧ code e605593325430 = 2804616580982 := by decide
theorem cert_e605593325430 : check e605593325430 [[],[]] .smaller = true := by decide
def e605593325434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e605593325434 : Closed e605593325434 ∧ code e605593325434 = 2804616580986 := by decide
theorem cert_e605593325434 : check e605593325434 [[],[]] .three = true := by decide
def e605593325486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 2)))))))
theorem wire_e605593325486 : Closed e605593325486 ∧ code e605593325486 = 2804616581038 := by decide
theorem cert_e605593325486 : check e605593325486 [[],[]] .three = true := by decide
def e605593325494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e605593325494 : Closed e605593325494 ∧ code e605593325494 = 2804616581046 := by decide
theorem cert_e605593325494 : check e605593325494 [[],[]] .three = true := by decide
def e605593325498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e605593325498 : Closed e605593325498 ∧ code e605593325498 = 2804616581050 := by decide
theorem cert_e605593325498 : check e605593325498 [[],[]] .three = true := by decide
def e605593326558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 3))))))))
theorem wire_e605593326558 : Closed e605593326558 ∧ code e605593326558 = 2804616582110 := by decide
theorem cert_e605593326558 : check e605593326558 [[],[]] .three = true := by decide
def e605593326574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 2))))))))
theorem wire_e605593326574 : Closed e605593326574 ∧ code e605593326574 = 2804616582126 := by decide
theorem cert_e605593326574 : check e605593326574 [[],[]] .three = true := by decide
end Blc.Floor41
