import Extra41
import Batch038
import Batch040
import Batch041
import Batch042
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness598293089526
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u1
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.lam u10
private def u12 := Term.app u3 u11
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou1
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u13 := Term.app u5 u0
private def u14 := Term.app u0 u5
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou0 sou6
private theorem sou13 : SO u13 := SO.app sou5 sou0
private theorem sou8 : SO u8 := SO.lam (r := u13) (g := u14) sou7 sou13 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.lam (r := u0) (g := u8) sou8 sou0 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
private theorem sou12 : SO u12 := SO.app sou3 sou11
theorem nege598293089526 : ¬ IsSelfInterpreter e598293089526 := by
  exact rawSO [] (t := u12) (by decide) sou12
#print axioms nege598293089526
end Witness598293089526
namespace Witness598343345114
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.var 3
private def u6 := Term.lam u5
private def u7 := Term.app u4 u6
private def u8 := Term.app u7 u4
private def u9 := Term.app u8 u0
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u14 := Term.lam u4
private def u15 := Term.var 2
private def u16 := Term.app u4 u15
private def u17 := Term.app u16 u4
private def u18 := Term.app u17 u0
private def u19 := Term.lam u18
private def u20 := Term.lam u15
private def u21 := Term.app u0 u20
private def u22 := Term.app u21 u0
private def u23 := Term.app u4 u0
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.var 3
private theorem sou6 : SO u6 := so_dead (by decide) sou5
private theorem sou7 : SO u7 := SO.app sou4 sou6
private theorem sou8 : SO u8 := SO.app sou7 sou4
private theorem sou9 : SO u9 := SO.app sou8 sou0
private theorem sou15 : SO u15 := SO.var 2
private theorem sou20 : SO u20 := so_dead (by decide) sou15
private theorem sou21 : SO u21 := SO.app sou0 sou20
private theorem sou22 : SO u22 := SO.app sou21 sou0
private theorem sou10 : SO u10 := SO.lam (r := u22) (g := u23) sou9 sou22 (by decide) (by decide)
private theorem sou14 : SO u14 := so_dead (by decide) sou4
private theorem sou11 : SO u11 := SO.lam (r := u14) (g := u19) sou10 sou14 (by decide) (by decide)
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege598343345114 : ¬ IsSelfInterpreter e598343345114 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege598343345114
end Witness598343345114
namespace Witness598343347654
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.app u4 u4
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.lam u4
private def u9 := Term.app u7 u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u14 := Term.app u1 u4
private def u15 := Term.app u4 u8
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.app sou4 sou4
private theorem sou6 : SO u6 := SO.var 2
private theorem sou7 : SO u7 := SO.app sou5 sou6
private theorem sou8 : SO u8 := so_dead (by decide) sou4
private theorem sou9 : SO u9 := SO.app sou7 sou8
private theorem sou14 : SO u14 := SO.app sou1 sou4
private theorem sou10 : SO u10 := SO.lam (r := u14) (g := u15) sou9 sou14 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.lam (r := u0) (g := u10) sou10 sou0 (by decide) (by decide)
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege598343347654 : ¬ IsSelfInterpreter e598343347654 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege598343347654
end Witness598343347654
namespace Witness598343347910
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.app u6 u4
private def u8 := Term.lam u4
private def u9 := Term.app u7 u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u14 := Term.app u0 u4
private def u15 := Term.app u14 u0
private def u16 := Term.app u4 u8
private theorem sou4 : SO u4 := SO.var 1
private theorem sou5 : SO u5 := SO.var 2
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou6 sou4
private theorem sou8 : SO u8 := so_dead (by decide) sou4
private theorem sou9 : SO u9 := SO.app sou7 sou8
private theorem sou14 : SO u14 := SO.app sou0 sou4
private theorem sou15 : SO u15 := SO.app sou14 sou0
private theorem sou10 : SO u10 := SO.lam (r := u15) (g := u16) sou9 sou15 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.lam (r := u0) (g := u10) sou10 sou0 (by decide) (by decide)
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege598343347910 : ¬ IsSelfInterpreter e598343347910 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege598343347910
end Witness598343347910
namespace Witness598343349958
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u6 u5
private def u8 := Term.lam u5
private def u9 := Term.app u7 u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou1 sou0
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u14 := Term.app u5 u0
private def u15 := Term.app u14 u0
private def u16 := Term.app u5 u8
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou6 sou5
private theorem sou8 : SO u8 := so_dead (by decide) sou5
private theorem sou9 : SO u9 := SO.app sou7 sou8
private theorem sou14 : SO u14 := SO.app sou5 sou0
private theorem sou15 : SO u15 := SO.app sou14 sou0
private theorem sou10 : SO u10 := SO.lam (r := u15) (g := u16) sou9 sou15 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.lam (r := u0) (g := u10) sou10 sou0 (by decide) (by decide)
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege598343349958 : ¬ IsSelfInterpreter e598343349958 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege598343349958
end Witness598343349958
namespace Witness598343398342
private def u0 := Term.var 1
private def u1 := Term.app u0 u0
private def u2 := Term.var 2
private def u3 := Term.app u1 u2
private def u4 := Term.lam u3
private def u5 := Term.lam u4
private def u6 := Term.app u1 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u8 u5
private def u10 := Term.lam u9
private def u11 := Term.var 0
private def u12 := Term.app u11 u11
private def u13 := Term.app u0 u5
private theorem sou0 : SO u0 := SO.var 1
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.var 2
private theorem sou3 : SO u3 := SO.app sou1 sou2
private theorem sou4 : SO u4 := so_dead (by decide) sou3
private theorem sou11 : SO u11 := SO.var 0
private theorem sou5 : SO u5 := SO.lam (r := u11) (g := u4) sou4 sou11 (by decide) (by decide)
private theorem sou6 : SO u6 := SO.app sou1 sou5
private theorem sou12 : SO u12 := SO.app sou11 sou11
private theorem sou7 : SO u7 := SO.lam (r := u12) (g := u13) sou6 sou12 (by decide) (by decide)
private theorem sou8 : SO u8 := so_closed_lam (by decide) sou7
private theorem sou9 : SO u9 := SO.app sou8 sou5
private theorem sou10 : SO u10 := so_closed_lam (by decide) sou9
theorem nege598343398342 : ¬ IsSelfInterpreter e598343398342 := by
  exact rawSO [[],[.left],[.left,.under,.under,.right],[.left,.under,.under,.right,.under,.under,.right],[],[.under,.left],[.under,.left,.under,.under,.right],[.under,.left,.under,.under,.right,.under,.under,.right]] (t := u10) (by decide) sou10
#print axioms nege598343398342
end Witness598343398342
namespace Witness598345526714
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 1
private def u5 := Term.app u0 u4
private def u6 := Term.var 2
private def u7 := Term.app u5 u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege598345526714 : ¬ IsSelfInterpreter e598345526714 := by
  intro he
  have h : replay [] e598345526714 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 2 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege598345526714
end Witness598345526714
namespace Witness598345526746
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.app u0 u4
private def u6 := Term.var 1
private def u7 := Term.app u5 u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege598345526746 : ¬ IsSelfInterpreter e598345526746 := by
  intro he
  have h : replay [] e598345526746 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 2 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege598345526746
end Witness598345526746
end Blc.Floor41
