import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e601492162006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e601492162006 : Closed e601492162006 ∧ code e601492162006 = 2800515417558 := by decide
theorem cert_e601492162006 : check e601492162006 [[]] .width = true := by decide
def e601492162010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e601492162010 : Closed e601492162010 ∧ code e601492162010 = 2800515417562 := by decide
private def t_e601492162010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem cert_e601492162010 : ¬ IsSelfInterpreter e601492162010 :=
  wSource (t := t_e601492162010) (replay_sound (ps := []) (t := e601492162010) (by decide)) (by decide)
def e601492162062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e601492162062 : Closed e601492162062 ∧ code e601492162062 = 2800515417614 := by decide
theorem cert_e601492162062 : check e601492162062 [[]] .width = true := by decide
def e601492162074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601492162074 : Closed e601492162074 ∧ code e601492162074 = 2800515417626 := by decide
theorem cert_e601492162074 : check e601492162074 [[]] .width = true := by decide
def e601492162146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e601492162146 : Closed e601492162146 ∧ code e601492162146 = 2800515417698 := by decide
theorem cert_e601492162146 : check e601492162146 [[]] .width = true := by decide
def e601492162166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e601492162166 : Closed e601492162166 ∧ code e601492162166 = 2800515417718 := by decide
theorem cert_e601492162166 : check e601492162166 [[]] .width = true := by decide
def e601492162358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e601492162358 : Closed e601492162358 ∧ code e601492162358 = 2800515417910 := by decide
theorem cert_e601492162358 : check e601492162358 [[]] .width = true := by decide
def e601492162362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e601492162362 : Closed e601492162362 ∧ code e601492162362 = 2800515417914 := by decide
theorem cert_e601492162362 : check e601492162362 [[]] .width = true := by decide
def e601492166058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e601492166058 : Closed e601492166058 ∧ code e601492166058 = 2800515421610 := by decide
private def t_e601492166058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem cert_e601492166058 : ¬ IsSelfInterpreter e601492166058 :=
  wSource (t := t_e601492166058) (replay_sound (ps := []) (t := e601492166058) (by decide)) (by decide)
def e601492166154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e601492166154 : Closed e601492166154 ∧ code e601492166154 = 2800515421706 := by decide
theorem cert_e601492166154 : check e601492166154 [[]] .width = true := by decide
def e601492166250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e601492166250 : Closed e601492166250 ∧ code e601492166250 = 2800515421802 := by decide
private def t_e601492166250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem cert_e601492166250 : ¬ IsSelfInterpreter e601492166250 :=
  wSource (t := t_e601492166250) (replay_sound (ps := []) (t := e601492166250) (by decide)) (by decide)
def e601492166274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e601492166274 : Closed e601492166274 ∧ code e601492166274 = 2800515421826 := by decide
private def t_e601492166274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem cert_e601492166274 : ¬ IsSelfInterpreter e601492166274 :=
  wSource (t := t_e601492166274) (replay_sound (ps := []) (t := e601492166274) (by decide)) (by decide)
def e601492166298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e601492166298 : Closed e601492166298 ∧ code e601492166298 = 2800515421850 := by decide
private def t_e601492166298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem cert_e601492166298 : ¬ IsSelfInterpreter e601492166298 :=
  wSource (t := t_e601492166298) (replay_sound (ps := []) (t := e601492166298) (by decide)) (by decide)
def e601492166682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601492166682 : Closed e601492166682 ∧ code e601492166682 = 2800515422234 := by decide
theorem cert_e601492166682 : check e601492166682 [[]] .width = true := by decide
def e601492166774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e601492166774 : Closed e601492166774 ∧ code e601492166774 = 2800515422326 := by decide
private def t_e601492166774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem cert_e601492166774 : ¬ IsSelfInterpreter e601492166774 :=
  wSource (t := t_e601492166774) (replay_sound (ps := []) (t := e601492166774) (by decide)) (by decide)
def e601492167018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e601492167018 : Closed e601492167018 ∧ code e601492167018 = 2800515422570 := by decide
private def t_e601492167018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem cert_e601492167018 : ¬ IsSelfInterpreter e601492167018 :=
  wSource (t := t_e601492167018) (replay_sound (ps := []) (t := e601492167018) (by decide)) (by decide)
def e601492167042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e601492167042 : Closed e601492167042 ∧ code e601492167042 = 2800515422594 := by decide
theorem cert_e601492167042 : check e601492167042 [[]] .width = true := by decide
def e601492167066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e601492167066 : Closed e601492167066 ∧ code e601492167066 = 2800515422618 := by decide
private def t_e601492167066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem cert_e601492167066 : ¬ IsSelfInterpreter e601492167066 :=
  wSource (t := t_e601492167066) (replay_sound (ps := []) (t := e601492167066) (by decide)) (by decide)
def e601492674586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601492674586 : Closed e601492674586 ∧ code e601492674586 = 2800515930138 := by decide
theorem cert_e601492674586 : check e601492674586 [[]] .width = true := by decide
def e601492678682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601492678682 : Closed e601492678682 ∧ code e601492678682 = 2800515934234 := by decide
theorem cert_e601492678682 : check e601492678682 [[]] .width = true := by decide
def e601492871194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601492871194 : Closed e601492871194 ∧ code e601492871194 = 2800516126746 := by decide
theorem cert_e601492871194 : check e601492871194 [[]] .width = true := by decide
def e601492875290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601492875290 : Closed e601492875290 ∧ code e601492875290 = 2800516130842 := by decide
theorem cert_e601492875290 : check e601492875290 [[]] .width = true := by decide
def e601492961306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601492961306 : Closed e601492961306 ∧ code e601492961306 = 2800516216858 := by decide
theorem cert_e601492961306 : check e601492961306 [[]] .width = true := by decide
def e601492996294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601492996294 : Closed e601492996294 ∧ code e601492996294 = 2800516251846 := by decide
theorem cert_e601492996294 : check e601492996294 [[]] .width = true := by decide
def e601493018650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493018650 : Closed e601493018650 ∧ code e601493018650 = 2800516274202 := by decide
theorem cert_e601493018650 : check e601493018650 [[]] .width = true := by decide
def e601493029062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601493029062 : Closed e601493029062 ∧ code e601493029062 = 2800516284614 := by decide
theorem cert_e601493029062 : check e601493029062 [[]] .width = true := by decide
def e601493362714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493362714 : Closed e601493362714 ∧ code e601493362714 = 2800516618266 := by decide
theorem cert_e601493362714 : check e601493362714 [[]] .width = true := by decide
def e601493430298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601493430298 : Closed e601493430298 ∧ code e601493430298 = 2800516685850 := by decide
theorem cert_e601493430298 : check e601493430298 [[]] .width = true := by decide
def e601493430390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601493430390 : Closed e601493430390 ∧ code e601493430390 = 2800516685942 := by decide
theorem cert_e601493430390 : check e601493430390 [[]] .width = true := by decide
def e601493430634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601493430634 : Closed e601493430634 ∧ code e601493430634 = 2800516686186 := by decide
theorem cert_e601493430634 : check e601493430634 [[]] .width = true := by decide
def e601493430682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601493430682 : Closed e601493430682 ∧ code e601493430682 = 2800516686234 := by decide
theorem cert_e601493430682 : check e601493430682 [[]] .width = true := by decide
def e601493440538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493440538 : Closed e601493440538 ∧ code e601493440538 = 2800516696090 := by decide
theorem cert_e601493440538 : check e601493440538 [[]] .width = true := by decide
def e601493446682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601493446682 : Closed e601493446682 ∧ code e601493446682 = 2800516702234 := by decide
theorem cert_e601493446682 : check e601493446682 [[]] .width = true := by decide
def e601493446774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601493446774 : Closed e601493446774 ∧ code e601493446774 = 2800516702326 := by decide
theorem cert_e601493446774 : check e601493446774 [[]] .width = true := by decide
def e601493447018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601493447018 : Closed e601493447018 ∧ code e601493447018 = 2800516702570 := by decide
theorem cert_e601493447018 : check e601493447018 [[]] .width = true := by decide
def e601493447066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601493447066 : Closed e601493447066 ∧ code e601493447066 = 2800516702618 := by decide
theorem cert_e601493447066 : check e601493447066 [[]] .width = true := by decide
def e601493450950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601493450950 : Closed e601493450950 ∧ code e601493450950 = 2800516706502 := by decide
theorem cert_e601493450950 : check e601493450950 [[]] .width = true := by decide
def e601493452826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493452826 : Closed e601493452826 ∧ code e601493452826 = 2800516708378 := by decide
theorem cert_e601493452826 : check e601493452826 [[]] .width = true := by decide
def e601493461018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493461018 : Closed e601493461018 ∧ code e601493461018 = 2800516716570 := by decide
theorem cert_e601493461018 : check e601493461018 [[]] .width = true := by decide
def e601493481498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493481498 : Closed e601493481498 ∧ code e601493481498 = 2800516737050 := by decide
theorem cert_e601493481498 : check e601493481498 [[]] .width = true := by decide
def e601493506074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493506074 : Closed e601493506074 ∧ code e601493506074 = 2800516761626 := by decide
theorem cert_e601493506074 : check e601493506074 [[]] .width = true := by decide
def e601493512218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601493512218 : Closed e601493512218 ∧ code e601493512218 = 2800516767770 := by decide
theorem cert_e601493512218 : check e601493512218 [[]] .width = true := by decide
def e601493512310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601493512310 : Closed e601493512310 ∧ code e601493512310 = 2800516767862 := by decide
theorem cert_e601493512310 : check e601493512310 [[]] .width = true := by decide
def e601493512554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601493512554 : Closed e601493512554 ∧ code e601493512554 = 2800516768106 := by decide
theorem cert_e601493512554 : check e601493512554 [[]] .width = true := by decide
def e601493512602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601493512602 : Closed e601493512602 ∧ code e601493512602 = 2800516768154 := by decide
theorem cert_e601493512602 : check e601493512602 [[]] .width = true := by decide
def e601493516486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601493516486 : Closed e601493516486 ∧ code e601493516486 = 2800516772038 := by decide
theorem cert_e601493516486 : check e601493516486 [[]] .width = true := by decide
def e601493518362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493518362 : Closed e601493518362 ∧ code e601493518362 = 2800516773914 := by decide
theorem cert_e601493518362 : check e601493518362 [[]] .width = true := by decide
def e601493524678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601493524678 : Closed e601493524678 ∧ code e601493524678 = 2800516780230 := by decide
theorem cert_e601493524678 : check e601493524678 [[]] .width = true := by decide
def e601493530650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493530650 : Closed e601493530650 ∧ code e601493530650 = 2800516786202 := by decide
theorem cert_e601493530650 : check e601493530650 [[]] .width = true := by decide
def e601493559322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493559322 : Closed e601493559322 ∧ code e601493559322 = 2800516814874 := by decide
theorem cert_e601493559322 : check e601493559322 [[]] .width = true := by decide
def e601493563418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493563418 : Closed e601493563418 ∧ code e601493563418 = 2800516818970 := by decide
theorem cert_e601493563418 : check e601493563418 [[]] .width = true := by decide
def e601493633050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493633050 : Closed e601493633050 ∧ code e601493633050 = 2800516888602 := by decide
theorem cert_e601493633050 : check e601493633050 [[]] .width = true := by decide
def e601493717190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601493717190 : Closed e601493717190 ∧ code e601493717190 = 2800516972742 := by decide
theorem cert_e601493717190 : check e601493717190 [[]] .width = true := by decide
def e601493823514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601493823514 : Closed e601493823514 ∧ code e601493823514 = 2800517079066 := by decide
theorem cert_e601493823514 : check e601493823514 [[]] .width = true := by decide
def e601493823606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601493823606 : Closed e601493823606 ∧ code e601493823606 = 2800517079158 := by decide
theorem cert_e601493823606 : check e601493823606 [[]] .width = true := by decide
def e601493823850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601493823850 : Closed e601493823850 ∧ code e601493823850 = 2800517079402 := by decide
theorem cert_e601493823850 : check e601493823850 [[]] .width = true := by decide
def e601493823898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601493823898 : Closed e601493823898 ∧ code e601493823898 = 2800517079450 := by decide
theorem cert_e601493823898 : check e601493823898 [[]] .width = true := by decide
def e601493833754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493833754 : Closed e601493833754 ∧ code e601493833754 = 2800517089306 := by decide
theorem cert_e601493833754 : check e601493833754 [[]] .width = true := by decide
def e601493839898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601493839898 : Closed e601493839898 ∧ code e601493839898 = 2800517095450 := by decide
theorem cert_e601493839898 : check e601493839898 [[]] .width = true := by decide
def e601493839990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601493839990 : Closed e601493839990 ∧ code e601493839990 = 2800517095542 := by decide
theorem cert_e601493839990 : check e601493839990 [[]] .width = true := by decide
def e601493840234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601493840234 : Closed e601493840234 ∧ code e601493840234 = 2800517095786 := by decide
theorem cert_e601493840234 : check e601493840234 [[]] .width = true := by decide
def e601493840282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601493840282 : Closed e601493840282 ∧ code e601493840282 = 2800517095834 := by decide
theorem cert_e601493840282 : check e601493840282 [[]] .width = true := by decide
def e601493844166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601493844166 : Closed e601493844166 ∧ code e601493844166 = 2800517099718 := by decide
theorem cert_e601493844166 : check e601493844166 [[]] .width = true := by decide
def e601493846042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493846042 : Closed e601493846042 ∧ code e601493846042 = 2800517101594 := by decide
theorem cert_e601493846042 : check e601493846042 [[]] .width = true := by decide
def e601493854234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601493854234 : Closed e601493854234 ∧ code e601493854234 = 2800517109786 := by decide
theorem cert_e601493854234 : check e601493854234 [[]] .width = true := by decide
def e601493995546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601493995546 : Closed e601493995546 ∧ code e601493995546 = 2800517251098 := by decide
theorem cert_e601493995546 : check e601493995546 [[]] .width = true := by decide
def e601493995638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601493995638 : Closed e601493995638 ∧ code e601493995638 = 2800517251190 := by decide
theorem cert_e601493995638 : check e601493995638 [[]] .width = true := by decide
def e601493995882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601493995882 : Closed e601493995882 ∧ code e601493995882 = 2800517251434 := by decide
theorem cert_e601493995882 : check e601493995882 [[]] .width = true := by decide
def e601493995930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601493995930 : Closed e601493995930 ∧ code e601493995930 = 2800517251482 := by decide
theorem cert_e601493995930 : check e601493995930 [[]] .width = true := by decide
def e601493996014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e601493996014 : Closed e601493996014 ∧ code e601493996014 = 2800517251566 := by decide
theorem cert_e601493996014 : check e601493996014 [[]] .width = true := by decide
def e601493996938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e601493996938 : Closed e601493996938 ∧ code e601493996938 = 2800517252490 := by decide
theorem cert_e601493996938 : check e601493996938 [[]] .width = true := by decide
def e601493996962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e601493996962 : Closed e601493996962 ∧ code e601493996962 = 2800517252514 := by decide
theorem cert_e601493996962 : check e601493996962 [[]] .width = true := by decide
def e601493996982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e601493996982 : Closed e601493996982 ∧ code e601493996982 = 2800517252534 := by decide
theorem cert_e601493996982 : check e601493996982 [[]] .width = true := by decide
def e601493997014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e601493997014 : Closed e601493997014 ∧ code e601493997014 = 2800517252566 := by decide
theorem cert_e601493997014 : check e601493997014 [[]] .width = true := by decide
def e601493997018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e601493997018 : Closed e601493997018 ∧ code e601493997018 = 2800517252570 := by decide
theorem cert_e601493997018 : check e601493997018 [[]] .width = true := by decide
def e601493997070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e601493997070 : Closed e601493997070 ∧ code e601493997070 = 2800517252622 := by decide
theorem cert_e601493997070 : check e601493997070 [[]] .width = true := by decide
def e601493997082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601493997082 : Closed e601493997082 ∧ code e601493997082 = 2800517252634 := by decide
theorem cert_e601493997082 : check e601493997082 [[]] .width = true := by decide
def e601493997154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e601493997154 : Closed e601493997154 ∧ code e601493997154 = 2800517252706 := by decide
theorem cert_e601493997154 : check e601493997154 [[]] .width = true := by decide
def e601493997174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e601493997174 : Closed e601493997174 ∧ code e601493997174 = 2800517252726 := by decide
theorem cert_e601493997174 : check e601493997174 [[]] .width = true := by decide
def e601493997366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e601493997366 : Closed e601493997366 ∧ code e601493997366 = 2800517252918 := by decide
theorem cert_e601493997366 : check e601493997366 [[]] .width = true := by decide
def e601493997370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e601493997370 : Closed e601493997370 ∧ code e601493997370 = 2800517252922 := by decide
theorem cert_e601493997370 : check e601493997370 [[]] .width = true := by decide
def e601494001066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e601494001066 : Closed e601494001066 ∧ code e601494001066 = 2800517256618 := by decide
theorem cert_e601494001066 : check e601494001066 [[]] .width = true := by decide
def e601494001162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e601494001162 : Closed e601494001162 ∧ code e601494001162 = 2800517256714 := by decide
theorem cert_e601494001162 : check e601494001162 [[]] .width = true := by decide
def e601494001258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e601494001258 : Closed e601494001258 ∧ code e601494001258 = 2800517256810 := by decide
theorem cert_e601494001258 : check e601494001258 [[]] .width = true := by decide
def e601494001282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e601494001282 : Closed e601494001282 ∧ code e601494001282 = 2800517256834 := by decide
theorem cert_e601494001282 : check e601494001282 [[]] .width = true := by decide
def e601494001306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e601494001306 : Closed e601494001306 ∧ code e601494001306 = 2800517256858 := by decide
theorem cert_e601494001306 : check e601494001306 [[]] .width = true := by decide
def e601494001690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601494001690 : Closed e601494001690 ∧ code e601494001690 = 2800517257242 := by decide
theorem cert_e601494001690 : check e601494001690 [[]] .width = true := by decide
def e601494001782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e601494001782 : Closed e601494001782 ∧ code e601494001782 = 2800517257334 := by decide
theorem cert_e601494001782 : check e601494001782 [[]] .width = true := by decide
def e601494002026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e601494002026 : Closed e601494002026 ∧ code e601494002026 = 2800517257578 := by decide
theorem cert_e601494002026 : check e601494002026 [[]] .width = true := by decide
def e601494002050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e601494002050 : Closed e601494002050 ∧ code e601494002050 = 2800517257602 := by decide
theorem cert_e601494002050 : check e601494002050 [[]] .width = true := by decide
def e601494002074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e601494002074 : Closed e601494002074 ∧ code e601494002074 = 2800517257626 := by decide
theorem cert_e601494002074 : check e601494002074 [[]] .width = true := by decide
def e601494140954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601494140954 : Closed e601494140954 ∧ code e601494140954 = 2800517396506 := by decide
theorem cert_e601494140954 : check e601494140954 [[]] .width = true := by decide
def e601494175942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601494175942 : Closed e601494175942 ∧ code e601494175942 = 2800517431494 := by decide
theorem cert_e601494175942 : check e601494175942 [[]] .width = true := by decide
def e601494226970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601494226970 : Closed e601494226970 ∧ code e601494226970 = 2800517482522 := by decide
theorem cert_e601494226970 : check e601494226970 [[]] .width = true := by decide
def e601494233114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601494233114 : Closed e601494233114 ∧ code e601494233114 = 2800517488666 := by decide
theorem cert_e601494233114 : check e601494233114 [[]] .width = true := by decide
def e601494233206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601494233206 : Closed e601494233206 ∧ code e601494233206 = 2800517488758 := by decide
private def t_e601494233206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e601494233206 : ¬ IsSelfInterpreter e601494233206 :=
  wSource (t := t_e601494233206) (replay_sound (ps := []) (t := e601494233206) (by decide)) (by decide)
def e601494233450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601494233450 : Closed e601494233450 ∧ code e601494233450 = 2800517489002 := by decide
private def t_e601494233450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e601494233450 : ¬ IsSelfInterpreter e601494233450 :=
  wSource (t := t_e601494233450) (replay_sound (ps := []) (t := e601494233450) (by decide)) (by decide)
def e601494233498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601494233498 : Closed e601494233498 ∧ code e601494233498 = 2800517489050 := by decide
private def t_e601494233498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e601494233498 : ¬ IsSelfInterpreter e601494233498 :=
  wSource (t := t_e601494233498) (replay_sound (ps := []) (t := e601494233498) (by decide)) (by decide)
def e601494237382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601494237382 : Closed e601494237382 ∧ code e601494237382 = 2800517492934 := by decide
theorem cert_e601494237382 : check e601494237382 [[]] .width = true := by decide
def e601494239258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601494239258 : Closed e601494239258 ∧ code e601494239258 = 2800517494810 := by decide
theorem cert_e601494239258 : check e601494239258 [[]] .width = true := by decide
def e601494245574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601494245574 : Closed e601494245574 ∧ code e601494245574 = 2800517501126 := by decide
theorem cert_e601494245574 : check e601494245574 [[]] .width = true := by decide
def e601494251546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601494251546 : Closed e601494251546 ∧ code e601494251546 = 2800517507098 := by decide
theorem cert_e601494251546 : check e601494251546 [[]] .width = true := by decide
def e601494257690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601494257690 : Closed e601494257690 ∧ code e601494257690 = 2800517513242 := by decide
theorem cert_e601494257690 : check e601494257690 [[]] .width = true := by decide
def e601494257782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601494257782 : Closed e601494257782 ∧ code e601494257782 = 2800517513334 := by decide
theorem cert_e601494257782 : check e601494257782 [[]] .width = true := by decide
def e601494258026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601494258026 : Closed e601494258026 ∧ code e601494258026 = 2800517513578 := by decide
theorem cert_e601494258026 : check e601494258026 [[]] .width = true := by decide
def e601494258074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601494258074 : Closed e601494258074 ∧ code e601494258074 = 2800517513626 := by decide
theorem cert_e601494258074 : check e601494258074 [[]] .width = true := by decide
def e601494258158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e601494258158 : Closed e601494258158 ∧ code e601494258158 = 2800517513710 := by decide
private def t_e601494258158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem cert_e601494258158 : ¬ IsSelfInterpreter e601494258158 :=
  wSource (t := t_e601494258158) (replay_sound (ps := []) (t := e601494258158) (by decide)) (by decide)
def e601494259082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e601494259082 : Closed e601494259082 ∧ code e601494259082 = 2800517514634 := by decide
theorem cert_e601494259082 : check e601494259082 [[]] .width = true := by decide
def e601494259106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e601494259106 : Closed e601494259106 ∧ code e601494259106 = 2800517514658 := by decide
theorem cert_e601494259106 : check e601494259106 [[]] .width = true := by decide
def e601494259126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e601494259126 : Closed e601494259126 ∧ code e601494259126 = 2800517514678 := by decide
theorem cert_e601494259126 : check e601494259126 [[]] .width = true := by decide
def e601494259158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e601494259158 : Closed e601494259158 ∧ code e601494259158 = 2800517514710 := by decide
theorem cert_e601494259158 : check e601494259158 [[]] .width = true := by decide
def e601494259162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e601494259162 : Closed e601494259162 ∧ code e601494259162 = 2800517514714 := by decide
private def t_e601494259162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem cert_e601494259162 : ¬ IsSelfInterpreter e601494259162 :=
  wSource (t := t_e601494259162) (replay_sound (ps := []) (t := e601494259162) (by decide)) (by decide)
def e601494259214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e601494259214 : Closed e601494259214 ∧ code e601494259214 = 2800517514766 := by decide
theorem cert_e601494259214 : check e601494259214 [[]] .width = true := by decide
def e601494259226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601494259226 : Closed e601494259226 ∧ code e601494259226 = 2800517514778 := by decide
theorem cert_e601494259226 : check e601494259226 [[]] .width = true := by decide
def e601494259298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e601494259298 : Closed e601494259298 ∧ code e601494259298 = 2800517514850 := by decide
theorem cert_e601494259298 : check e601494259298 [[]] .width = true := by decide
def e601494259318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e601494259318 : Closed e601494259318 ∧ code e601494259318 = 2800517514870 := by decide
theorem cert_e601494259318 : check e601494259318 [[]] .width = true := by decide
def e601494259510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e601494259510 : Closed e601494259510 ∧ code e601494259510 = 2800517515062 := by decide
theorem cert_e601494259510 : check e601494259510 [[]] .width = true := by decide
def e601494259514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e601494259514 : Closed e601494259514 ∧ code e601494259514 = 2800517515066 := by decide
theorem cert_e601494259514 : check e601494259514 [[]] .width = true := by decide
def e601494263210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e601494263210 : Closed e601494263210 ∧ code e601494263210 = 2800517518762 := by decide
private def t_e601494263210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem cert_e601494263210 : ¬ IsSelfInterpreter e601494263210 :=
  wSource (t := t_e601494263210) (replay_sound (ps := []) (t := e601494263210) (by decide)) (by decide)
def e601494263306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e601494263306 : Closed e601494263306 ∧ code e601494263306 = 2800517518858 := by decide
theorem cert_e601494263306 : check e601494263306 [[]] .width = true := by decide
def e601494263402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e601494263402 : Closed e601494263402 ∧ code e601494263402 = 2800517518954 := by decide
private def t_e601494263402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem cert_e601494263402 : ¬ IsSelfInterpreter e601494263402 :=
  wSource (t := t_e601494263402) (replay_sound (ps := []) (t := e601494263402) (by decide)) (by decide)
def e601494263426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e601494263426 : Closed e601494263426 ∧ code e601494263426 = 2800517518978 := by decide
private def t_e601494263426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem cert_e601494263426 : ¬ IsSelfInterpreter e601494263426 :=
  wSource (t := t_e601494263426) (replay_sound (ps := []) (t := e601494263426) (by decide)) (by decide)
def e601494263450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e601494263450 : Closed e601494263450 ∧ code e601494263450 = 2800517519002 := by decide
private def t_e601494263450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem cert_e601494263450 : ¬ IsSelfInterpreter e601494263450 :=
  wSource (t := t_e601494263450) (replay_sound (ps := []) (t := e601494263450) (by decide)) (by decide)
def e601494263834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601494263834 : Closed e601494263834 ∧ code e601494263834 = 2800517519386 := by decide
theorem cert_e601494263834 : check e601494263834 [[]] .width = true := by decide
def e601494263926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e601494263926 : Closed e601494263926 ∧ code e601494263926 = 2800517519478 := by decide
private def t_e601494263926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem cert_e601494263926 : ¬ IsSelfInterpreter e601494263926 :=
  wSource (t := t_e601494263926) (replay_sound (ps := []) (t := e601494263926) (by decide)) (by decide)
def e601494264170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e601494264170 : Closed e601494264170 ∧ code e601494264170 = 2800517519722 := by decide
private def t_e601494264170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem cert_e601494264170 : ¬ IsSelfInterpreter e601494264170 :=
  wSource (t := t_e601494264170) (replay_sound (ps := []) (t := e601494264170) (by decide)) (by decide)
def e601494264194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e601494264194 : Closed e601494264194 ∧ code e601494264194 = 2800517519746 := by decide
theorem cert_e601494264194 : check e601494264194 [[]] .width = true := by decide
def e601494264218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e601494264218 : Closed e601494264218 ∧ code e601494264218 = 2800517519770 := by decide
private def t_e601494264218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem cert_e601494264218 : ¬ IsSelfInterpreter e601494264218 :=
  wSource (t := t_e601494264218) (replay_sound (ps := []) (t := e601494264218) (by decide)) (by decide)
def e601494444058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601494444058 : Closed e601494444058 ∧ code e601494444058 = 2800517699610 := by decide
theorem cert_e601494444058 : check e601494444058 [[]] .width = true := by decide
def e601494448154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601494448154 : Closed e601494448154 ∧ code e601494448154 = 2800517703706 := by decide
theorem cert_e601494448154 : check e601494448154 [[]] .width = true := by decide
def e601500803098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601500803098 : Closed e601500803098 ∧ code e601500803098 = 2800524058650 := by decide
theorem cert_e601500803098 : check e601500803098 [[]] .width = true := by decide
def e601500803190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601500803190 : Closed e601500803190 ∧ code e601500803190 = 2800524058742 := by decide
theorem cert_e601500803190 : check e601500803190 [[]] .width = true := by decide
def e601500803434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601500803434 : Closed e601500803434 ∧ code e601500803434 = 2800524058986 := by decide
theorem cert_e601500803434 : check e601500803434 [[]] .width = true := by decide
def e601500803482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601500803482 : Closed e601500803482 ∧ code e601500803482 = 2800524059034 := by decide
theorem cert_e601500803482 : check e601500803482 [[]] .width = true := by decide
def e601500868634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601500868634 : Closed e601500868634 ∧ code e601500868634 = 2800524124186 := by decide
theorem cert_e601500868634 : check e601500868634 [[]] .width = true := by decide
def e601500868726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601500868726 : Closed e601500868726 ∧ code e601500868726 = 2800524124278 := by decide
theorem cert_e601500868726 : check e601500868726 [[]] .width = true := by decide
def e601500868970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601500868970 : Closed e601500868970 ∧ code e601500868970 = 2800524124522 := by decide
theorem cert_e601500868970 : check e601500868970 [[]] .width = true := by decide
def e601500869018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601500869018 : Closed e601500869018 ∧ code e601500869018 = 2800524124570 := by decide
theorem cert_e601500869018 : check e601500869018 [[]] .width = true := by decide
def e601508732954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601508732954 : Closed e601508732954 ∧ code e601508732954 = 2800531988506 := by decide
theorem cert_e601508732954 : check e601508732954 [[]] .width = true := by decide
def e601508733046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601508733046 : Closed e601508733046 ∧ code e601508733046 = 2800531988598 := by decide
theorem cert_e601508733046 : check e601508733046 [[]] .width = true := by decide
def e601508733290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601508733290 : Closed e601508733290 ∧ code e601508733290 = 2800531988842 := by decide
theorem cert_e601508733290 : check e601508733290 [[]] .width = true := by decide
def e601508733338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601508733338 : Closed e601508733338 ∧ code e601508733338 = 2800531988890 := by decide
theorem cert_e601508733338 : check e601508733338 [[]] .width = true := by decide
def e601508765722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601508765722 : Closed e601508765722 ∧ code e601508765722 = 2800532021274 := by decide
theorem cert_e601508765722 : check e601508765722 [[]] .width = true := by decide
def e601508765814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601508765814 : Closed e601508765814 ∧ code e601508765814 = 2800532021366 := by decide
theorem cert_e601508765814 : check e601508765814 [[]] .width = true := by decide
def e601508766058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601508766058 : Closed e601508766058 ∧ code e601508766058 = 2800532021610 := by decide
theorem cert_e601508766058 : check e601508766058 [[]] .width = true := by decide
def e601508766106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601508766106 : Closed e601508766106 ∧ code e601508766106 = 2800532021658 := by decide
theorem cert_e601508766106 : check e601508766106 [[]] .width = true := by decide
def e601508853786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601508853786 : Closed e601508853786 ∧ code e601508853786 = 2800532109338 := by decide
theorem cert_e601508853786 : check e601508853786 [[]] .width = true := by decide
def e601508995098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601508995098 : Closed e601508995098 ∧ code e601508995098 = 2800532250650 := by decide
theorem cert_e601508995098 : check e601508995098 [[]] .width = true := by decide
def e601508995190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601508995190 : Closed e601508995190 ∧ code e601508995190 = 2800532250742 := by decide
theorem cert_e601508995190 : check e601508995190 [[]] .width = true := by decide
def e601508995434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601508995434 : Closed e601508995434 ∧ code e601508995434 = 2800532250986 := by decide
theorem cert_e601508995434 : check e601508995434 [[]] .width = true := by decide
def e601508995482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601508995482 : Closed e601508995482 ∧ code e601508995482 = 2800532251034 := by decide
theorem cert_e601508995482 : check e601508995482 [[]] .width = true := by decide
def e601509032134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601509032134 : Closed e601509032134 ∧ code e601509032134 = 2800532287686 := by decide
theorem cert_e601509032134 : check e601509032134 [[]] .width = true := by decide
def e601509038106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601509038106 : Closed e601509038106 ∧ code e601509038106 = 2800532293658 := by decide
theorem cert_e601509038106 : check e601509038106 [[]] .width = true := by decide
def e601509044250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601509044250 : Closed e601509044250 ∧ code e601509044250 = 2800532299802 := by decide
theorem cert_e601509044250 : check e601509044250 [[]] .width = true := by decide
def e601509044342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601509044342 : Closed e601509044342 ∧ code e601509044342 = 2800532299894 := by decide
theorem cert_e601509044342 : check e601509044342 [[]] .width = true := by decide
def e601509044586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601509044586 : Closed e601509044586 ∧ code e601509044586 = 2800532300138 := by decide
theorem cert_e601509044586 : check e601509044586 [[]] .width = true := by decide
def e601509044634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601509044634 : Closed e601509044634 ∧ code e601509044634 = 2800532300186 := by decide
theorem cert_e601509044634 : check e601509044634 [[]] .width = true := by decide
def e601509048518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601509048518 : Closed e601509048518 ∧ code e601509048518 = 2800532304070 := by decide
theorem cert_e601509048518 : check e601509048518 [[]] .width = true := by decide
def e601509050394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601509050394 : Closed e601509050394 ∧ code e601509050394 = 2800532305946 := by decide
theorem cert_e601509050394 : check e601509050394 [[]] .width = true := by decide
def e601509091354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e601509091354 : Closed e601509091354 ∧ code e601509091354 = 2800532346906 := by decide
theorem cert_e601509091354 : check e601509091354 [[]] .width = true := by decide
end Blc.Floor41
