import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605602813546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605602813546 : Closed e605602813546 ∧ code e605602813546 = 2804626069098 := by decide
theorem cert_e605602813546 : check e605602813546 [[],[]] .chain = true := by decide
def e605602813570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605602813570 : Closed e605602813570 ∧ code e605602813570 = 2804626069122 := by decide
theorem cert_e605602813570 : check e605602813570 [[],[]] .chain = true := by decide
def e605602813582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605602813582 : Closed e605602813582 ∧ code e605602813582 = 2804626069134 := by decide
theorem cert_e605602813582 : check e605602813582 [[],[]] .chain = true := by decide
def e605602813594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605602813594 : Closed e605602813594 ∧ code e605602813594 = 2804626069146 := by decide
theorem cert_e605602813594 : check e605602813594 [[],[]] .chain = true := by decide
def e605602813638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605602813638 : Closed e605602813638 ∧ code e605602813638 = 2804626069190 := by decide
theorem cert_e605602813638 : check e605602813638 [[],[]] .chain = true := by decide
def e605602813666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605602813666 : Closed e605602813666 ∧ code e605602813666 = 2804626069218 := by decide
theorem cert_e605602813666 : check e605602813666 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602813678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e605602813678 : Closed e605602813678 ∧ code e605602813678 = 2804626069230 := by decide
theorem cert_e605602813678 : check e605602813678 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602813722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e605602813722 : Closed e605602813722 ∧ code e605602813722 = 2804626069274 := by decide
theorem cert_e605602813722 : check e605602813722 [[],[]] .chain = true := by decide
def e605602813766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e605602813766 : Closed e605602813766 ∧ code e605602813766 = 2804626069318 := by decide
theorem cert_e605602813766 : check e605602813766 [[],[]] .chain = true := by decide
def e605602813834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605602813834 : Closed e605602813834 ∧ code e605602813834 = 2804626069386 := by decide
theorem cert_e605602813834 : check e605602813834 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602813858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605602813858 : Closed e605602813858 ∧ code e605602813858 = 2804626069410 := by decide
theorem cert_e605602813858 : check e605602813858 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602813870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e605602813870 : Closed e605602813870 ∧ code e605602813870 = 2804626069422 := by decide
theorem cert_e605602813870 : check e605602813870 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602813882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e605602813882 : Closed e605602813882 ∧ code e605602813882 = 2804626069434 := by decide
theorem cert_e605602813882 : check e605602813882 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602813978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605602813978 : Closed e605602813978 ∧ code e605602813978 = 2804626069530 := by decide
theorem cert_e605602813978 : check e605602813978 [[],[],[.under,.under,.left]] .width = true := by decide
def e605602814014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e605602814014 : Closed e605602814014 ∧ code e605602814014 = 2804626069566 := by decide
theorem cert_e605602814014 : check e605602814014 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602814062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605602814062 : Closed e605602814062 ∧ code e605602814062 = 2804626069614 := by decide
theorem cert_e605602814062 : check e605602814062 [[],[]] .chain = true := by decide
def e605602814070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605602814070 : Closed e605602814070 ∧ code e605602814070 = 2804626069622 := by decide
theorem cert_e605602814070 : check e605602814070 [[],[]] .chain = true := by decide
def e605602814074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605602814074 : Closed e605602814074 ∧ code e605602814074 = 2804626069626 := by decide
theorem cert_e605602814074 : check e605602814074 [[],[]] .chain = true := by decide
def e605602814314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605602814314 : Closed e605602814314 ∧ code e605602814314 = 2804626069866 := by decide
theorem cert_e605602814314 : check e605602814314 [[],[]] .chain = true := by decide
def e605602814338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605602814338 : Closed e605602814338 ∧ code e605602814338 = 2804626069890 := by decide
theorem cert_e605602814338 : check e605602814338 [[],[]] .chain = true := by decide
def e605602814350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605602814350 : Closed e605602814350 ∧ code e605602814350 = 2804626069902 := by decide
theorem cert_e605602814350 : check e605602814350 [[],[]] .chain = true := by decide
def e605602814362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605602814362 : Closed e605602814362 ∧ code e605602814362 = 2804626069914 := by decide
theorem cert_e605602814362 : check e605602814362 [[],[]] .chain = true := by decide
def e605602814406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605602814406 : Closed e605602814406 ∧ code e605602814406 = 2804626069958 := by decide
theorem cert_e605602814406 : check e605602814406 [[],[]] .chain = true := by decide
def e605602814434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605602814434 : Closed e605602814434 ∧ code e605602814434 = 2804626069986 := by decide
theorem cert_e605602814434 : check e605602814434 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602814446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e605602814446 : Closed e605602814446 ∧ code e605602814446 = 2804626069998 := by decide
theorem cert_e605602814446 : check e605602814446 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602815030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e605602815030 : Closed e605602815030 ∧ code e605602815030 = 2804626070582 := by decide
theorem cert_e605602815030 : check e605602815030 [[],[]] .chain = true := by decide
def e605602815034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e605602815034 : Closed e605602815034 ∧ code e605602815034 = 2804626070586 := by decide
theorem cert_e605602815034 : check e605602815034 [[],[]] .chain = true := by decide
def e605602815174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e605602815174 : Closed e605602815174 ∧ code e605602815174 = 2804626070726 := by decide
theorem cert_e605602815174 : check e605602815174 [[],[]] .chain = true := by decide
def e605602815502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e605602815502 : Closed e605602815502 ∧ code e605602815502 = 2804626071054 := by decide
theorem cert_e605602815502 : check e605602815502 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602815586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605602815586 : Closed e605602815586 ∧ code e605602815586 = 2804626071138 := by decide
theorem cert_e605602815586 : check e605602815586 [[],[],[.under,.under,.left]] .chain = true := by decide
def e605602815598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e605602815598 : Closed e605602815598 ∧ code e605602815598 = 2804626071150 := by decide
theorem cert_e605602815598 : check e605602815598 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602815610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e605602815610 : Closed e605602815610 ∧ code e605602815610 = 2804626071162 := by decide
theorem cert_e605602815610 : check e605602815610 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e605602827030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e605602827030 : Closed e605602827030 ∧ code e605602827030 = 2804626082582 := by decide
private def t_e605602827030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem cert_e605602827030 : ¬ IsSelfInterpreter e605602827030 :=
  wSource (t := t_e605602827030) (replay_sound (ps := []) (t := e605602827030) (by decide)) (by decide)
def e605602827106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e605602827106 : Closed e605602827106 ∧ code e605602827106 = 2804626082658 := by decide
private def t_e605602827106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem cert_e605602827106 : ¬ IsSelfInterpreter e605602827106 :=
  wSource (t := t_e605602827106) (replay_sound (ps := []) (t := e605602827106) (by decide)) (by decide)
def e605602827118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605602827118 : Closed e605602827118 ∧ code e605602827118 = 2804626082670 := by decide
private def t_e605602827118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem cert_e605602827118 : ¬ IsSelfInterpreter e605602827118 :=
  wSource (t := t_e605602827118) (replay_sound (ps := []) (t := e605602827118) (by decide)) (by decide)
def e605602827126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605602827126 : Closed e605602827126 ∧ code e605602827126 = 2804626082678 := by decide
private def t_e605602827126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e605602827126 : ¬ IsSelfInterpreter e605602827126 :=
  wSource (t := t_e605602827126) (replay_sound (ps := []) (t := e605602827126) (by decide)) (by decide)
def e605602827146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e605602827146 : Closed e605602827146 ∧ code e605602827146 = 2804626082698 := by decide
private def t_e605602827146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem cert_e605602827146 : ¬ IsSelfInterpreter e605602827146 :=
  wSource (t := t_e605602827146) (replay_sound (ps := []) (t := e605602827146) (by decide)) (by decide)
def e605602827170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e605602827170 : Closed e605602827170 ∧ code e605602827170 = 2804626082722 := by decide
private def t_e605602827170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem cert_e605602827170 : ¬ IsSelfInterpreter e605602827170 :=
  wSource (t := t_e605602827170) (replay_sound (ps := []) (t := e605602827170) (by decide)) (by decide)
def e605602827182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605602827182 : Closed e605602827182 ∧ code e605602827182 = 2804626082734 := by decide
private def t_e605602827182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem cert_e605602827182 : ¬ IsSelfInterpreter e605602827182 :=
  wSource (t := t_e605602827182) (replay_sound (ps := []) (t := e605602827182) (by decide)) (by decide)
def e605602827194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605602827194 : Closed e605602827194 ∧ code e605602827194 = 2804626082746 := by decide
private def t_e605602827194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e605602827194 : ¬ IsSelfInterpreter e605602827194 :=
  wSource (t := t_e605602827194) (replay_sound (ps := []) (t := e605602827194) (by decide)) (by decide)
def e605602827222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605602827222 : Closed e605602827222 ∧ code e605602827222 = 2804626082774 := by decide
private def t_e605602827222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e605602827222 : ¬ IsSelfInterpreter e605602827222 :=
  wSource (t := t_e605602827222) (replay_sound (ps := []) (t := e605602827222) (by decide)) (by decide)
def e605602827226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605602827226 : Closed e605602827226 ∧ code e605602827226 = 2804626082778 := by decide
private def t_e605602827226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e605602827226 : ¬ IsSelfInterpreter e605602827226 :=
  wSource (t := t_e605602827226) (replay_sound (ps := []) (t := e605602827226) (by decide)) (by decide)
def e605602827294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e605602827294 : Closed e605602827294 ∧ code e605602827294 = 2804626082846 := by decide
private def t_e605602827294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem cert_e605602827294 : ¬ IsSelfInterpreter e605602827294 :=
  wSource (t := t_e605602827294) (replay_sound (ps := []) (t := e605602827294) (by decide)) (by decide)
def e605602827490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e605602827490 : Closed e605602827490 ∧ code e605602827490 = 2804626083042 := by decide
private def t_e605602827490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem cert_e605602827490 : ¬ IsSelfInterpreter e605602827490 :=
  wSource (t := t_e605602827490) (replay_sound (ps := []) (t := e605602827490) (by decide)) (by decide)
def e605602827502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605602827502 : Closed e605602827502 ∧ code e605602827502 = 2804626083054 := by decide
private def t_e605602827502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem cert_e605602827502 : ¬ IsSelfInterpreter e605602827502 :=
  wSource (t := t_e605602827502) (replay_sound (ps := []) (t := e605602827502) (by decide)) (by decide)
def e605602827510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605602827510 : Closed e605602827510 ∧ code e605602827510 = 2804626083062 := by decide
private def t_e605602827510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem cert_e605602827510 : ¬ IsSelfInterpreter e605602827510 :=
  wSource (t := t_e605602827510) (replay_sound (ps := []) (t := e605602827510) (by decide)) (by decide)
def e605602827790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e605602827790 : Closed e605602827790 ∧ code e605602827790 = 2804626083342 := by decide
private def t_e605602827790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem cert_e605602827790 : ¬ IsSelfInterpreter e605602827790 :=
  wSource (t := t_e605602827790) (replay_sound (ps := []) (t := e605602827790) (by decide)) (by decide)
def e605602827874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605602827874 : Closed e605602827874 ∧ code e605602827874 = 2804626083426 := by decide
private def t_e605602827874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem cert_e605602827874 : ¬ IsSelfInterpreter e605602827874 :=
  wSource (t := t_e605602827874) (replay_sound (ps := []) (t := e605602827874) (by decide)) (by decide)
def e605602827886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605602827886 : Closed e605602827886 ∧ code e605602827886 = 2804626083438 := by decide
private def t_e605602827886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem cert_e605602827886 : ¬ IsSelfInterpreter e605602827886 :=
  wSource (t := t_e605602827886) (replay_sound (ps := []) (t := e605602827886) (by decide)) (by decide)
def e605602827898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605602827898 : Closed e605602827898 ∧ code e605602827898 = 2804626083450 := by decide
private def t_e605602827898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem cert_e605602827898 : ¬ IsSelfInterpreter e605602827898 :=
  wSource (t := t_e605602827898) (replay_sound (ps := []) (t := e605602827898) (by decide)) (by decide)
def e605602828086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605602828086 : Closed e605602828086 ∧ code e605602828086 = 2804626083638 := by decide
private def t_e605602828086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem cert_e605602828086 : ¬ IsSelfInterpreter e605602828086 :=
  wSource (t := t_e605602828086) (replay_sound (ps := []) (t := e605602828086) (by decide)) (by decide)
def e605602828090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605602828090 : Closed e605602828090 ∧ code e605602828090 = 2804626083642 := by decide
private def t_e605602828090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem cert_e605602828090 : ¬ IsSelfInterpreter e605602828090 :=
  wSource (t := t_e605602828090) (replay_sound (ps := []) (t := e605602828090) (by decide)) (by decide)
def e605602983390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e605602983390 : Closed e605602983390 ∧ code e605602983390 = 2804626238942 := by decide
theorem cert_e605602983390 : check e605602983390 [[],[]] .smaller = true := by decide
def e605602983406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e605602983406 : Closed e605602983406 ∧ code e605602983406 = 2804626238958 := by decide
theorem cert_e605602983406 : check e605602983406 [[],[]] .smaller = true := by decide
def e605602983774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e605602983774 : Closed e605602983774 ∧ code e605602983774 = 2804626239326 := by decide
theorem cert_e605602983774 : check e605602983774 [[],[]] .smaller = true := by decide
def e605602983802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e605602983802 : Closed e605602983802 ∧ code e605602983802 = 2804626239354 := by decide
theorem cert_e605602983802 : check e605602983802 [[],[]] .smaller = true := by decide
def e605602983854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e605602983854 : Closed e605602983854 ∧ code e605602983854 = 2804626239406 := by decide
theorem cert_e605602983854 : check e605602983854 [[],[]] .smaller = true := by decide
def e605602983866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e605602983866 : Closed e605602983866 ∧ code e605602983866 = 2804626239418 := by decide
theorem cert_e605602983866 : check e605602983866 [[],[]] .smaller = true := by decide
def e605602984926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e605602984926 : Closed e605602984926 ∧ code e605602984926 = 2804626240478 := by decide
theorem cert_e605602984926 : check e605602984926 [[],[]] .smaller = true := by decide
def e605602984942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e605602984942 : Closed e605602984942 ∧ code e605602984942 = 2804626240494 := by decide
theorem cert_e605602984942 : check e605602984942 [[],[]] .smaller = true := by decide
def e605602987230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e605602987230 : Closed e605602987230 ∧ code e605602987230 = 2804626242782 := by decide
theorem cert_e605602987230 : check e605602987230 [[],[]] .smaller = true := by decide
def e605602987258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e605602987258 : Closed e605602987258 ∧ code e605602987258 = 2804626242810 := by decide
theorem cert_e605602987258 : check e605602987258 [[],[]] .smaller = true := by decide
def e605602987630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605602987630 : Closed e605602987630 ∧ code e605602987630 = 2804626243182 := by decide
theorem cert_e605602987630 : check e605602987630 [[],[]] .smaller = true := by decide
def e605602987642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605602987642 : Closed e605602987642 ∧ code e605602987642 = 2804626243194 := by decide
theorem cert_e605602987642 : check e605602987642 [[],[]] .smaller = true := by decide
def e605603016046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e605603016046 : Closed e605603016046 ∧ code e605603016046 = 2804626271598 := by decide
theorem cert_e605603016046 : check e605603016046 [[],[]] .smaller = true := by decide
def e605603016054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e605603016054 : Closed e605603016054 ∧ code e605603016054 = 2804626271606 := by decide
theorem cert_e605603016054 : check e605603016054 [[],[]] .smaller = true := by decide
def e605603016110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e605603016110 : Closed e605603016110 ∧ code e605603016110 = 2804626271662 := by decide
theorem cert_e605603016110 : check e605603016110 [[],[]] .smaller = true := by decide
def e605603016122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e605603016122 : Closed e605603016122 ∧ code e605603016122 = 2804626271674 := by decide
theorem cert_e605603016122 : check e605603016122 [[],[]] .smaller = true := by decide
def e605603016150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e605603016150 : Closed e605603016150 ∧ code e605603016150 = 2804626271702 := by decide
theorem cert_e605603016150 : check e605603016150 [[],[]] .smaller = true := by decide
def e605603016154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e605603016154 : Closed e605603016154 ∧ code e605603016154 = 2804626271706 := by decide
theorem cert_e605603016154 : check e605603016154 [[],[]] .smaller = true := by decide
def e605603016366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e605603016366 : Closed e605603016366 ∧ code e605603016366 = 2804626271918 := by decide
theorem cert_e605603016366 : check e605603016366 [[],[]] .smaller = true := by decide
def e605603016378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e605603016378 : Closed e605603016378 ∧ code e605603016378 = 2804626271930 := by decide
theorem cert_e605603016378 : check e605603016378 [[],[]] .smaller = true := by decide
def e605603016426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e605603016426 : Closed e605603016426 ∧ code e605603016426 = 2804626271978 := by decide
theorem cert_e605603016426 : check e605603016426 [[],[]] .smaller = true := by decide
def e605603016534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e605603016534 : Closed e605603016534 ∧ code e605603016534 = 2804626272086 := by decide
theorem cert_e605603016534 : check e605603016534 [[],[]] .smaller = true := by decide
def e605603016538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e605603016538 : Closed e605603016538 ∧ code e605603016538 = 2804626272090 := by decide
theorem cert_e605603016538 : check e605603016538 [[],[]] .smaller = true := by decide
def e605603016554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e605603016554 : Closed e605603016554 ∧ code e605603016554 = 2804626272106 := by decide
theorem cert_e605603016554 : check e605603016554 [[],[]] .smaller = true := by decide
def e605603017582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e605603017582 : Closed e605603017582 ∧ code e605603017582 = 2804626273134 := by decide
theorem cert_e605603017582 : check e605603017582 [[],[]] .smaller = true := by decide
def e605603017590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e605603017590 : Closed e605603017590 ∧ code e605603017590 = 2804626273142 := by decide
theorem cert_e605603017590 : check e605603017590 [[],[]] .smaller = true := by decide
def e605603017646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e605603017646 : Closed e605603017646 ∧ code e605603017646 = 2804626273198 := by decide
theorem cert_e605603017646 : check e605603017646 [[],[]] .smaller = true := by decide
def e605603017658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e605603017658 : Closed e605603017658 ∧ code e605603017658 = 2804626273210 := by decide
theorem cert_e605603017658 : check e605603017658 [[],[]] .smaller = true := by decide
def e605603017686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e605603017686 : Closed e605603017686 ∧ code e605603017686 = 2804626273238 := by decide
theorem cert_e605603017686 : check e605603017686 [[],[]] .smaller = true := by decide
def e605603017690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e605603017690 : Closed e605603017690 ∧ code e605603017690 = 2804626273242 := by decide
theorem cert_e605603017690 : check e605603017690 [[],[]] .smaller = true := by decide
def e605603017966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e605603017966 : Closed e605603017966 ∧ code e605603017966 = 2804626273518 := by decide
theorem cert_e605603017966 : check e605603017966 [[],[]] .smaller = true := by decide
def e605603017974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e605603017974 : Closed e605603017974 ∧ code e605603017974 = 2804626273526 := by decide
theorem cert_e605603017974 : check e605603017974 [[],[]] .smaller = true := by decide
def e605603018350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605603018350 : Closed e605603018350 ∧ code e605603018350 = 2804626273902 := by decide
theorem cert_e605603018350 : check e605603018350 [[],[]] .smaller = true := by decide
def e605603018362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605603018362 : Closed e605603018362 ∧ code e605603018362 = 2804626273914 := by decide
theorem cert_e605603018362 : check e605603018362 [[],[]] .smaller = true := by decide
def e605603018550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605603018550 : Closed e605603018550 ∧ code e605603018550 = 2804626274102 := by decide
theorem cert_e605603018550 : check e605603018550 [[],[]] .smaller = true := by decide
def e605603018554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605603018554 : Closed e605603018554 ∧ code e605603018554 = 2804626274106 := by decide
theorem cert_e605603018554 : check e605603018554 [[],[]] .smaller = true := by decide
def e605603019182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e605603019182 : Closed e605603019182 ∧ code e605603019182 = 2804626274734 := by decide
theorem cert_e605603019182 : check e605603019182 [[],[]] .smaller = true := by decide
def e605603019194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e605603019194 : Closed e605603019194 ∧ code e605603019194 = 2804626274746 := by decide
theorem cert_e605603019194 : check e605603019194 [[],[]] .smaller = true := by decide
def e605603019242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e605603019242 : Closed e605603019242 ∧ code e605603019242 = 2804626274794 := by decide
theorem cert_e605603019242 : check e605603019242 [[],[]] .smaller = true := by decide
def e605603019374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605603019374 : Closed e605603019374 ∧ code e605603019374 = 2804626274926 := by decide
theorem cert_e605603019374 : check e605603019374 [[],[]] .smaller = true := by decide
def e605603019386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605603019386 : Closed e605603019386 ∧ code e605603019386 = 2804626274938 := by decide
theorem cert_e605603019386 : check e605603019386 [[],[]] .smaller = true := by decide
def e605603019674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605603019674 : Closed e605603019674 ∧ code e605603019674 = 2804626275226 := by decide
theorem cert_e605603019674 : check e605603019674 [[],[]] .smaller = true := by decide
def e605603019710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 4)))))))))
theorem wire_e605603019710 : Closed e605603019710 ∧ code e605603019710 = 2804626275262 := by decide
theorem cert_e605603019710 : check e605603019710 [[],[]] .chain = true := by decide
def e605603019758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 2)))))))))
theorem wire_e605603019758 : Closed e605603019758 ∧ code e605603019758 = 2804626275310 := by decide
theorem cert_e605603019758 : check e605603019758 [[],[]] .chain = true := by decide
def e605603019990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e605603019990 : Closed e605603019990 ∧ code e605603019990 = 2804626275542 := by decide
theorem cert_e605603019990 : check e605603019990 [[],[]] .smaller = true := by decide
def e605603019994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e605603019994 : Closed e605603019994 ∧ code e605603019994 = 2804626275546 := by decide
theorem cert_e605603019994 : check e605603019994 [[],[]] .smaller = true := by decide
def e605603020010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e605603020010 : Closed e605603020010 ∧ code e605603020010 = 2804626275562 := by decide
theorem cert_e605603020010 : check e605603020010 [[],[]] .smaller = true := by decide
def e605603020086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605603020086 : Closed e605603020086 ∧ code e605603020086 = 2804626275638 := by decide
theorem cert_e605603020086 : check e605603020086 [[],[]] .smaller = true := by decide
def e605603020090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605603020090 : Closed e605603020090 ∧ code e605603020090 = 2804626275642 := by decide
theorem cert_e605603020090 : check e605603020090 [[],[]] .smaller = true := by decide
def e605603020186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605603020186 : Closed e605603020186 ∧ code e605603020186 = 2804626275738 := by decide
theorem cert_e605603020186 : check e605603020186 [[],[]] .smaller = true := by decide
def e605603020222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 4)))))))))
theorem wire_e605603020222 : Closed e605603020222 ∧ code e605603020222 = 2804626275774 := by decide
theorem cert_e605603020222 : check e605603020222 [[],[]] .chain = true := by decide
def e605603020278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 1)))))))))
theorem wire_e605603020278 : Closed e605603020278 ∧ code e605603020278 = 2804626275830 := by decide
theorem cert_e605603020278 : check e605603020278 [[],[]] .chain = true := by decide
def e605603020654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2)))))))))
theorem wire_e605603020654 : Closed e605603020654 ∧ code e605603020654 = 2804626276206 := by decide
theorem cert_e605603020654 : check e605603020654 [[],[]] .chain = true := by decide
def e605603020662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 1)))))))))
theorem wire_e605603020662 : Closed e605603020662 ∧ code e605603020662 = 2804626276214 := by decide
theorem cert_e605603020662 : check e605603020662 [[],[]] .chain = true := by decide
def e605603021790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e605603021790 : Closed e605603021790 ∧ code e605603021790 = 2804626277342 := by decide
theorem cert_e605603021790 : check e605603021790 [[],[]] .smaller = true := by decide
def e605603021806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e605603021806 : Closed e605603021806 ∧ code e605603021806 = 2804626277358 := by decide
theorem cert_e605603021806 : check e605603021806 [[],[]] .smaller = true := by decide
def e605603023726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605603023726 : Closed e605603023726 ∧ code e605603023726 = 2804626279278 := by decide
theorem cert_e605603023726 : check e605603023726 [[],[]] .smaller = true := by decide
def e605603023734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605603023734 : Closed e605603023734 ∧ code e605603023734 = 2804626279286 := by decide
theorem cert_e605603023734 : check e605603023734 [[],[]] .smaller = true := by decide
def e605603023790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605603023790 : Closed e605603023790 ∧ code e605603023790 = 2804626279342 := by decide
theorem cert_e605603023790 : check e605603023790 [[],[]] .smaller = true := by decide
def e605603023802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605603023802 : Closed e605603023802 ∧ code e605603023802 = 2804626279354 := by decide
theorem cert_e605603023802 : check e605603023802 [[],[]] .smaller = true := by decide
def e605603023830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605603023830 : Closed e605603023830 ∧ code e605603023830 = 2804626279382 := by decide
theorem cert_e605603023830 : check e605603023830 [[],[]] .smaller = true := by decide
def e605603023834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605603023834 : Closed e605603023834 ∧ code e605603023834 = 2804626279386 := by decide
theorem cert_e605603023834 : check e605603023834 [[],[]] .smaller = true := by decide
def e605603024110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605603024110 : Closed e605603024110 ∧ code e605603024110 = 2804626279662 := by decide
theorem cert_e605603024110 : check e605603024110 [[],[]] .smaller = true := by decide
def e605603024118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605603024118 : Closed e605603024118 ∧ code e605603024118 = 2804626279670 := by decide
theorem cert_e605603024118 : check e605603024118 [[],[]] .smaller = true := by decide
def e605603024494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605603024494 : Closed e605603024494 ∧ code e605603024494 = 2804626280046 := by decide
theorem cert_e605603024494 : check e605603024494 [[],[]] .smaller = true := by decide
def e605603024506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605603024506 : Closed e605603024506 ∧ code e605603024506 = 2804626280058 := by decide
theorem cert_e605603024506 : check e605603024506 [[],[]] .smaller = true := by decide
def e605603024694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605603024694 : Closed e605603024694 ∧ code e605603024694 = 2804626280246 := by decide
theorem cert_e605603024694 : check e605603024694 [[],[]] .smaller = true := by decide
def e605603024698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605603024698 : Closed e605603024698 ∧ code e605603024698 = 2804626280250 := by decide
theorem cert_e605603024698 : check e605603024698 [[],[]] .smaller = true := by decide
def e605603029470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e605603029470 : Closed e605603029470 ∧ code e605603029470 = 2804626285022 := by decide
theorem cert_e605603029470 : check e605603029470 [[],[]] .smaller = true := by decide
def e605603029494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e605603029494 : Closed e605603029494 ∧ code e605603029494 = 2804626285046 := by decide
theorem cert_e605603029494 : check e605603029494 [[],[]] .smaller = true := by decide
def e605603030446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e605603030446 : Closed e605603030446 ∧ code e605603030446 = 2804626285998 := by decide
theorem cert_e605603030446 : check e605603030446 [[],[]] .smaller = true := by decide
def e605603030458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e605603030458 : Closed e605603030458 ∧ code e605603030458 = 2804626286010 := by decide
theorem cert_e605603030458 : check e605603030458 [[],[]] .smaller = true := by decide
def e605603030506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e605603030506 : Closed e605603030506 ∧ code e605603030506 = 2804626286058 := by decide
theorem cert_e605603030506 : check e605603030506 [[],[]] .smaller = true := by decide
def e605603030638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605603030638 : Closed e605603030638 ∧ code e605603030638 = 2804626286190 := by decide
theorem cert_e605603030638 : check e605603030638 [[],[]] .smaller = true := by decide
def e605603030650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605603030650 : Closed e605603030650 ∧ code e605603030650 = 2804626286202 := by decide
theorem cert_e605603030650 : check e605603030650 [[],[]] .smaller = true := by decide
def e605603030938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605603030938 : Closed e605603030938 ∧ code e605603030938 = 2804626286490 := by decide
theorem cert_e605603030938 : check e605603030938 [[],[]] .smaller = true := by decide
def e605603030974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 4))))))))))
theorem wire_e605603030974 : Closed e605603030974 ∧ code e605603030974 = 2804626286526 := by decide
theorem cert_e605603030974 : check e605603030974 [[],[]] .chain = true := by decide
def e605603031022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 2))))))))))
theorem wire_e605603031022 : Closed e605603031022 ∧ code e605603031022 = 2804626286574 := by decide
theorem cert_e605603031022 : check e605603031022 [[],[]] .chain = true := by decide
def e605603033326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e605603033326 : Closed e605603033326 ∧ code e605603033326 = 2804626288878 := by decide
theorem cert_e605603033326 : check e605603033326 [[],[]] .smaller = true := by decide
def e605603033334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e605603033334 : Closed e605603033334 ∧ code e605603033334 = 2804626288886 := by decide
theorem cert_e605603033334 : check e605603033334 [[],[]] .smaller = true := by decide
def e605603033814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e605603033814 : Closed e605603033814 ∧ code e605603033814 = 2804626289366 := by decide
theorem cert_e605603033814 : check e605603033814 [[],[]] .smaller = true := by decide
def e605603033818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e605603033818 : Closed e605603033818 ∧ code e605603033818 = 2804626289370 := by decide
theorem cert_e605603033818 : check e605603033818 [[],[]] .smaller = true := by decide
def e605603033834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e605603033834 : Closed e605603033834 ∧ code e605603033834 = 2804626289386 := by decide
theorem cert_e605603033834 : check e605603033834 [[],[]] .smaller = true := by decide
def e605603033910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605603033910 : Closed e605603033910 ∧ code e605603033910 = 2804626289462 := by decide
theorem cert_e605603033910 : check e605603033910 [[],[]] .smaller = true := by decide
def e605603033914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605603033914 : Closed e605603033914 ∧ code e605603033914 = 2804626289466 := by decide
theorem cert_e605603033914 : check e605603033914 [[],[]] .smaller = true := by decide
def e605603034010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605603034010 : Closed e605603034010 ∧ code e605603034010 = 2804626289562 := by decide
theorem cert_e605603034010 : check e605603034010 [[],[]] .smaller = true := by decide
def e605603034046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 4))))))))))
theorem wire_e605603034046 : Closed e605603034046 ∧ code e605603034046 = 2804626289598 := by decide
theorem cert_e605603034046 : check e605603034046 [[],[]] .chain = true := by decide
def e605603034102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 4) (.var 1))))))))))
theorem wire_e605603034102 : Closed e605603034102 ∧ code e605603034102 = 2804626289654 := by decide
theorem cert_e605603034102 : check e605603034102 [[],[]] .chain = true := by decide
def e605603036398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 2))))))))))
theorem wire_e605603036398 : Closed e605603036398 ∧ code e605603036398 = 2804626291950 := by decide
theorem cert_e605603036398 : check e605603036398 [[],[]] .chain = true := by decide
def e605603036406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 2) (.var 1))))))))))
theorem wire_e605603036406 : Closed e605603036406 ∧ code e605603036406 = 2804626291958 := by decide
theorem cert_e605603036406 : check e605603036406 [[],[]] .chain = true := by decide
def e605603148142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e605603148142 : Closed e605603148142 ∧ code e605603148142 = 2804626403694 := by decide
theorem cert_e605603148142 : check e605603148142 [[],[]] .smaller = true := by decide
def e605603148150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e605603148150 : Closed e605603148150 ∧ code e605603148150 = 2804626403702 := by decide
theorem cert_e605603148150 : check e605603148150 [[],[]] .smaller = true := by decide
def e605603149278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e605603149278 : Closed e605603149278 ∧ code e605603149278 = 2804626404830 := by decide
theorem cert_e605603149278 : check e605603149278 [[],[]] .chain = true := by decide
def e605603149294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e605603149294 : Closed e605603149294 ∧ code e605603149294 = 2804626404846 := by decide
theorem cert_e605603149294 : check e605603149294 [[],[]] .chain = true := by decide
def e605603149358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605603149358 : Closed e605603149358 ∧ code e605603149358 = 2804626404910 := by decide
theorem cert_e605603149358 : check e605603149358 [[],[]] .smaller = true := by decide
def e605603149534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e605603149534 : Closed e605603149534 ∧ code e605603149534 = 2804626405086 := by decide
theorem cert_e605603149534 : check e605603149534 [[],[]] .chain = true := by decide
def e605603149538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605603149538 : Closed e605603149538 ∧ code e605603149538 = 2804626405090 := by decide
theorem cert_e605603149538 : check e605603149538 [[],[]] .smaller = true := by decide
def e605603149550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e605603149550 : Closed e605603149550 ∧ code e605603149550 = 2804626405102 := by decide
theorem cert_e605603149550 : check e605603149550 [[],[]] .smaller = true := by decide
def e605603149558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e605603149558 : Closed e605603149558 ∧ code e605603149558 = 2804626405110 := by decide
theorem cert_e605603149558 : check e605603149558 [[],[]] .chain = true := by decide
def e605603149590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e605603149590 : Closed e605603149590 ∧ code e605603149590 = 2804626405142 := by decide
theorem cert_e605603149590 : check e605603149590 [[],[]] .smaller = true := by decide
def e605603149662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e605603149662 : Closed e605603149662 ∧ code e605603149662 = 2804626405214 := by decide
theorem cert_e605603149662 : check e605603149662 [[],[]] .chain = true := by decide
def e605603149666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e605603149666 : Closed e605603149666 ∧ code e605603149666 = 2804626405218 := by decide
theorem cert_e605603149666 : check e605603149666 [[],[]] .smaller = true := by decide
def e605603149678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e605603149678 : Closed e605603149678 ∧ code e605603149678 = 2804626405230 := by decide
theorem cert_e605603149678 : check e605603149678 [[],[]] .smaller = true := by decide
def e605603149686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e605603149686 : Closed e605603149686 ∧ code e605603149686 = 2804626405238 := by decide
theorem cert_e605603149686 : check e605603149686 [[],[]] .smaller = true := by decide
def e605603149690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e605603149690 : Closed e605603149690 ∧ code e605603149690 = 2804626405242 := by decide
theorem cert_e605603149690 : check e605603149690 [[],[]] .chain = true := by decide
def e605603149742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e605603149742 : Closed e605603149742 ∧ code e605603149742 = 2804626405294 := by decide
theorem cert_e605603149742 : check e605603149742 [[],[]] .chain = true := by decide
def e605603149750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e605603149750 : Closed e605603149750 ∧ code e605603149750 = 2804626405302 := by decide
theorem cert_e605603149750 : check e605603149750 [[],[]] .chain = true := by decide
def e605603149754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e605603149754 : Closed e605603149754 ∧ code e605603149754 = 2804626405306 := by decide
theorem cert_e605603149754 : check e605603149754 [[],[]] .chain = true := by decide
end Blc.Floor41
