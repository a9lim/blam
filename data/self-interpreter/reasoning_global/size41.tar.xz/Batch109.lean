import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605602555322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e605602555322 : Closed e605602555322 ∧ code e605602555322 = 2804625810874 := by decide
theorem cert_e605602555322 : check e605602555322 [[],[]] .chain = true := by decide
def e605602555370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e605602555370 : Closed e605602555370 ∧ code e605602555370 = 2804625810922 := by decide
theorem cert_e605602555370 : check e605602555370 [[],[]] .chain = true := by decide
def e605602555502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e605602555502 : Closed e605602555502 ∧ code e605602555502 = 2804625811054 := by decide
theorem cert_e605602555502 : check e605602555502 [[],[]] .chain = true := by decide
def e605602555514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e605602555514 : Closed e605602555514 ∧ code e605602555514 = 2804625811066 := by decide
theorem cert_e605602555514 : check e605602555514 [[],[]] .chain = true := by decide
def e605602555678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e605602555678 : Closed e605602555678 ∧ code e605602555678 = 2804625811230 := by decide
theorem cert_e605602555678 : check e605602555678 [[],[]] .chain = true := by decide
def e605602555778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e605602555778 : Closed e605602555778 ∧ code e605602555778 = 2804625811330 := by decide
theorem cert_e605602555778 : check e605602555778 [[],[]] .chain = true := by decide
def e605602555790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e605602555790 : Closed e605602555790 ∧ code e605602555790 = 2804625811342 := by decide
theorem cert_e605602555790 : check e605602555790 [[],[]] .chain = true := by decide
def e605602555802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e605602555802 : Closed e605602555802 ∧ code e605602555802 = 2804625811354 := by decide
theorem cert_e605602555802 : check e605602555802 [[],[]] .chain = true := by decide
def e605602558174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e605602558174 : Closed e605602558174 ∧ code e605602558174 = 2804625813726 := by decide
theorem cert_e605602558174 : check e605602558174 [[],[]] .chain = true := by decide
def e605602558202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e605602558202 : Closed e605602558202 ∧ code e605602558202 = 2804625813754 := by decide
theorem cert_e605602558202 : check e605602558202 [[],[]] .chain = true := by decide
def e605602558750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e605602558750 : Closed e605602558750 ∧ code e605602558750 = 2804625814302 := by decide
theorem cert_e605602558750 : check e605602558750 [[],[]] .chain = true := by decide
def e605602558918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e605602558918 : Closed e605602558918 ∧ code e605602558918 = 2804625814470 := by decide
theorem cert_e605602558918 : check e605602558918 [[],[]] .chain = true := by decide
def e605602560026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605602560026 : Closed e605602560026 ∧ code e605602560026 = 2804625815578 := by decide
theorem cert_e605602560026 : checkPay e605602560026 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left]] = true := by decide
def e605602560062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 4))))))))
theorem wire_e605602560062 : Closed e605602560062 ∧ code e605602560062 = 2804625815614 := by decide
theorem cert_e605602560062 : checkPay e605602560062 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left]] = true := by decide
def e605602560110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e605602560110 : Closed e605602560110 ∧ code e605602560110 = 2804625815662 := by decide
theorem cert_e605602560110 : check e605602560110 [[],[]] .chain = true := by decide
def e605602560118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e605602560118 : Closed e605602560118 ∧ code e605602560118 = 2804625815670 := by decide
theorem cert_e605602560118 : check e605602560118 [[],[]] .chain = true := by decide
def e605602560122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e605602560122 : Closed e605602560122 ∧ code e605602560122 = 2804625815674 := by decide
theorem cert_e605602560122 : check e605602560122 [[],[]] .chain = true := by decide
def e605602560362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e605602560362 : Closed e605602560362 ∧ code e605602560362 = 2804625815914 := by decide
theorem cert_e605602560362 : check e605602560362 [[],[]] .chain = true := by decide
def e605602560386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e605602560386 : Closed e605602560386 ∧ code e605602560386 = 2804625815938 := by decide
theorem cert_e605602560386 : check e605602560386 [[],[]] .chain = true := by decide
def e605602560398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e605602560398 : Closed e605602560398 ∧ code e605602560398 = 2804625815950 := by decide
theorem cert_e605602560398 : check e605602560398 [[],[]] .chain = true := by decide
def e605602560410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e605602560410 : Closed e605602560410 ∧ code e605602560410 = 2804625815962 := by decide
theorem cert_e605602560410 : check e605602560410 [[],[]] .chain = true := by decide
def e605602560454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e605602560454 : Closed e605602560454 ∧ code e605602560454 = 2804625816006 := by decide
theorem cert_e605602560454 : check e605602560454 [[],[]] .chain = true := by decide
def e605602560482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e605602560482 : Closed e605602560482 ∧ code e605602560482 = 2804625816034 := by decide
theorem cert_e605602560482 : checkPay e605602560482 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left],[.under,.right]] = true := by decide
def e605602560494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 2)))))))
theorem wire_e605602560494 : Closed e605602560494 ∧ code e605602560494 = 2804625816046 := by decide
theorem cert_e605602560494 : checkPay e605602560494 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left],[.under,.right]] = true := by decide
def e605602562926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e605602562926 : Closed e605602562926 ∧ code e605602562926 = 2804625818478 := by decide
theorem cert_e605602562926 : check e605602562926 [[],[]] .chain = true := by decide
def e605602562938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e605602562938 : Closed e605602562938 ∧ code e605602562938 = 2804625818490 := by decide
theorem cert_e605602562938 : check e605602562938 [[],[]] .chain = true := by decide
def e605602562990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e605602562990 : Closed e605602562990 ∧ code e605602562990 = 2804625818542 := by decide
theorem cert_e605602562990 : check e605602562990 [[],[]] .chain = true := by decide
def e605602563050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e605602563050 : Closed e605602563050 ∧ code e605602563050 = 2804625818602 := by decide
theorem cert_e605602563050 : check e605602563050 [[],[]] .chain = true := by decide
def e605602563694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602563694 : Closed e605602563694 ∧ code e605602563694 = 2804625819246 := by decide
theorem cert_e605602563694 : check e605602563694 [[],[]] .chain = true := by decide
def e605602563706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602563706 : Closed e605602563706 ∧ code e605602563706 = 2804625819258 := by decide
theorem cert_e605602563706 : check e605602563706 [[],[]] .chain = true := by decide
def e605602563994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602563994 : Closed e605602563994 ∧ code e605602563994 = 2804625819546 := by decide
theorem cert_e605602563994 : check e605602563994 [[],[]] .chain = true := by decide
def e605602565230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.var 2))))))
theorem wire_e605602565230 : Closed e605602565230 ∧ code e605602565230 = 2804625820782 := by decide
theorem cert_e605602565230 : check e605602565230 [[],[]] .chain = true := by decide
def e605602565242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))) (.var 0))))))
theorem wire_e605602565242 : Closed e605602565242 ∧ code e605602565242 = 2804625820794 := by decide
theorem cert_e605602565242 : check e605602565242 [[],[]] .chain = true := by decide
def e605602565406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e605602565406 : Closed e605602565406 ∧ code e605602565406 = 2804625820958 := by decide
theorem cert_e605602565406 : check e605602565406 [[],[]] .chain = true := by decide
def e605602565574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e605602565574 : Closed e605602565574 ∧ code e605602565574 = 2804625821126 := by decide
theorem cert_e605602565574 : check e605602565574 [[],[]] .chain = true := by decide
def e605602565914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))) (.var 0))))))
theorem wire_e605602565914 : Closed e605602565914 ∧ code e605602565914 = 2804625821466 := by decide
theorem cert_e605602565914 : check e605602565914 [[],[]] .chain = true := by decide
def e605602565958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e605602565958 : Closed e605602565958 ∧ code e605602565958 = 2804625821510 := by decide
theorem cert_e605602565958 : check e605602565958 [[],[]] .chain = true := by decide
def e605602566366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e605602566366 : Closed e605602566366 ∧ code e605602566366 = 2804625821918 := by decide
theorem cert_e605602566366 : check e605602566366 [[],[]] .chain = true := by decide
def e605602566394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e605602566394 : Closed e605602566394 ∧ code e605602566394 = 2804625821946 := by decide
theorem cert_e605602566394 : check e605602566394 [[],[]] .chain = true := by decide
def e605602566942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e605602566942 : Closed e605602566942 ∧ code e605602566942 = 2804625822494 := by decide
theorem cert_e605602566942 : check e605602566942 [[],[]] .chain = true := by decide
def e605602567110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e605602567110 : Closed e605602567110 ∧ code e605602567110 = 2804625822662 := by decide
theorem cert_e605602567110 : check e605602567110 [[],[]] .chain = true := by decide
def e605602569270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e605602569270 : Closed e605602569270 ∧ code e605602569270 = 2804625824822 := by decide
theorem cert_e605602569270 : check e605602569270 [[],[]] .chain = true := by decide
def e605602569274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e605602569274 : Closed e605602569274 ∧ code e605602569274 = 2804625824826 := by decide
theorem cert_e605602569274 : check e605602569274 [[],[]] .chain = true := by decide
def e605602569414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e605602569414 : Closed e605602569414 ∧ code e605602569414 = 2804625824966 := by decide
theorem cert_e605602569414 : check e605602569414 [[],[]] .chain = true := by decide
def e605602570346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0))))))
theorem wire_e605602570346 : Closed e605602570346 ∧ code e605602570346 = 2804625825898 := by decide
theorem cert_e605602570346 : checkPay e605602570346 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e605602570394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602570394 : Closed e605602570394 ∧ code e605602570394 = 2804625825946 := by decide
theorem cert_e605602570394 : check e605602570394 [[],[]] .chain = true := by decide
def e605602570478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e605602570478 : Closed e605602570478 ∧ code e605602570478 = 2804625826030 := by decide
theorem cert_e605602570478 : checkPay e605602570478 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e605602570490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e605602570490 : Closed e605602570490 ∧ code e605602570490 = 2804625826042 := by decide
theorem cert_e605602570490 : checkPay e605602570490 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e605602570678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e605602570678 : Closed e605602570678 ∧ code e605602570678 = 2804625826230 := by decide
theorem cert_e605602570678 : check e605602570678 [[],[]] .chain = true := by decide
def e605602570682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e605602570682 : Closed e605602570682 ∧ code e605602570682 = 2804625826234 := by decide
theorem cert_e605602570682 : check e605602570682 [[],[]] .chain = true := by decide
def e605602570710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e605602570710 : Closed e605602570710 ∧ code e605602570710 = 2804625826262 := by decide
theorem cert_e605602570710 : check e605602570710 [[],[]] .chain = true := by decide
def e605602570714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))) (.var 0))))))
theorem wire_e605602570714 : Closed e605602570714 ∧ code e605602570714 = 2804625826266 := by decide
theorem cert_e605602570714 : check e605602570714 [[],[]] .chain = true := by decide
def e605602570730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e605602570730 : Closed e605602570730 ∧ code e605602570730 = 2804625826282 := by decide
theorem cert_e605602570730 : check e605602570730 [[],[]] .chain = true := by decide
def e605602570862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602570862 : Closed e605602570862 ∧ code e605602570862 = 2804625826414 := by decide
theorem cert_e605602570862 : checkPay e605602570862 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e605602570874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602570874 : Closed e605602570874 ∧ code e605602570874 = 2804625826426 := by decide
theorem cert_e605602570874 : checkPay e605602570874 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right],[.under,.under,.right]] = true := by decide
def e605602571038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e605602571038 : Closed e605602571038 ∧ code e605602571038 = 2804625826590 := by decide
theorem cert_e605602571038 : checkPay e605602571038 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e605602571062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602571062 : Closed e605602571062 ∧ code e605602571062 = 2804625826614 := by decide
theorem cert_e605602571062 : check e605602571062 [[],[]] .chain = true := by decide
def e605602571066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602571066 : Closed e605602571066 ∧ code e605602571066 = 2804625826618 := by decide
theorem cert_e605602571066 : check e605602571066 [[],[]] .chain = true := by decide
def e605602571162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602571162 : Closed e605602571162 ∧ code e605602571162 = 2804625826714 := by decide
theorem cert_e605602571162 : check e605602571162 [[],[]] .chain = true := by decide
def e605602571206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e605602571206 : Closed e605602571206 ∧ code e605602571206 = 2804625826758 := by decide
theorem cert_e605602571206 : checkPay e605602571206 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e605602571690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e605602571690 : Closed e605602571690 ∧ code e605602571690 = 2804625827242 := by decide
theorem cert_e605602571690 : check e605602571690 [[],[]] .chain = true := by decide
def e605602571786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e605602571786 : Closed e605602571786 ∧ code e605602571786 = 2804625827338 := by decide
theorem cert_e605602571786 : check e605602571786 [[],[]] .chain = true := by decide
def e605602571822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e605602571822 : Closed e605602571822 ∧ code e605602571822 = 2804625827374 := by decide
theorem cert_e605602571822 : checkPay e605602571822 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.right],[.under,.under,.right,.left],[.under,.under,.right]] = true := by decide
def e605602571830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.var 1))))))
theorem wire_e605602571830 : Closed e605602571830 ∧ code e605602571830 = 2804625827382 := by decide
theorem cert_e605602571830 : check e605602571830 [[],[]] .chain = true := by decide
def e605602571834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))) (.var 0))))))
theorem wire_e605602571834 : Closed e605602571834 ∧ code e605602571834 = 2804625827386 := by decide
theorem cert_e605602571834 : check e605602571834 [[],[]] .chain = true := by decide
def e605602571882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e605602571882 : Closed e605602571882 ∧ code e605602571882 = 2804625827434 := by decide
theorem cert_e605602571882 : check e605602571882 [[],[]] .chain = true := by decide
def e605602571906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.lam (.var 0))))))))
theorem wire_e605602571906 : Closed e605602571906 ∧ code e605602571906 = 2804625827458 := by decide
theorem cert_e605602571906 : check e605602571906 [[],[]] .chain = true := by decide
def e605602571918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e605602571918 : Closed e605602571918 ∧ code e605602571918 = 2804625827470 := by decide
theorem cert_e605602571918 : check e605602571918 [[],[]] .chain = true := by decide
def e605602571930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602571930 : Closed e605602571930 ∧ code e605602571930 = 2804625827482 := by decide
theorem cert_e605602571930 : check e605602571930 [[],[]] .chain = true := by decide
def e605602571974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e605602571974 : Closed e605602571974 ∧ code e605602571974 = 2804625827526 := by decide
theorem cert_e605602571974 : check e605602571974 [[],[]] .chain = true := by decide
def e605602572002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e605602572002 : Closed e605602572002 ∧ code e605602572002 = 2804625827554 := by decide
theorem cert_e605602572002 : checkPay e605602572002 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left,.left,.left,.right],[.under,.under,.left,.right,.left,.left,.left,.right,.left],[.under,.under,.left,.right,.left,.left,.left,.right],[.under,.under,.left,.right,.left,.left,.left,.right,.under,.left],[.under,.under,.left,.right,.left,.left,.left,.right,.under,.left,.left,.left],[.under,.under,.left,.right,.left,.left,.left,.right,.under,.left,.left]] = true := by decide
def e605602572014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e605602572014 : Closed e605602572014 ∧ code e605602572014 = 2804625827566 := by decide
theorem cert_e605602572014 : checkPay e605602572014 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left,.left,.left,.right],[.under,.under,.left,.right,.left,.left,.left,.right,.left],[.under,.under,.left,.right,.left,.left,.left,.right],[.under,.under,.left,.right,.left,.left,.left,.right,.under,.left],[.under,.under,.left,.right,.left,.left,.left,.right,.under,.left,.left,.left],[.under,.under,.left,.right,.left,.left,.left,.right,.under,.left,.left],[.under,.under,.right],[.under,.under,.right,.left],[.under,.under,.right],[.under,.under,.right,.under,.left],[.under,.under,.right,.under,.left,.left,.left],[.under,.under,.right,.under,.left,.left]] = true := by decide
def e605602572058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))) (.var 0))))))
theorem wire_e605602572058 : Closed e605602572058 ∧ code e605602572058 = 2804625827610 := by decide
theorem cert_e605602572058 : check e605602572058 [[],[]] .chain = true := by decide
def e605602572102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e605602572102 : Closed e605602572102 ∧ code e605602572102 = 2804625827654 := by decide
theorem cert_e605602572102 : check e605602572102 [[],[]] .chain = true := by decide
def e605602572170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e605602572170 : Closed e605602572170 ∧ code e605602572170 = 2804625827722 := by decide
theorem cert_e605602572170 : checkPay e605602572170 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.under,.left,.left,.left],[.under,.under,.left,.right,.under,.left,.left],[.under,.under,.left,.right,.under,.left],[.under,.under,.left,.right,.under,.left,.left],[.under,.under,.left,.right,.under,.left,.left],[.under,.under,.left,.right,.under,.left,.left],[.under,.under,.left,.right,.under,.left],[.under,.under,.left,.right,.under,.left],[.under,.under,.left,.right,.under,.left],[.under,.under,.left,.right,.under]] = true := by decide
def e605602572194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e605602572194 : Closed e605602572194 ∧ code e605602572194 = 2804625827746 := by decide
theorem cert_e605602572194 : checkPay e605602572194 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.under,.left,.left,.left],[.under,.under,.left,.right,.under,.left,.left],[.under,.under,.left,.right,.under,.left],[.under,.under,.left,.right,.under,.left,.left,.right],[.under,.under,.left,.right,.under,.left,.left,.right,.left,.left],[.under,.under,.left,.right,.under,.left,.left,.right,.left,.left,.left,.left],[.under,.under,.left,.right,.under,.left,.left,.right,.left,.left,.left,.left,.left,.left]] = true := by decide
def e605602572206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e605602572206 : Closed e605602572206 ∧ code e605602572206 = 2804625827758 := by decide
theorem cert_e605602572206 : checkPay e605602572206 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e605602572218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e605602572218 : Closed e605602572218 ∧ code e605602572218 = 2804625827770 := by decide
theorem cert_e605602572218 : checkPay e605602572218 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e605602572314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605602572314 : Closed e605602572314 ∧ code e605602572314 = 2804625827866 := by decide
theorem cert_e605602572314 : checkPay e605602572314 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e605602572350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e605602572350 : Closed e605602572350 ∧ code e605602572350 = 2804625827902 := by decide
theorem cert_e605602572350 : checkPay e605602572350 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e605602572398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e605602572398 : Closed e605602572398 ∧ code e605602572398 = 2804625827950 := by decide
theorem cert_e605602572398 : check e605602572398 [[],[]] .chain = true := by decide
def e605602572406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e605602572406 : Closed e605602572406 ∧ code e605602572406 = 2804625827958 := by decide
theorem cert_e605602572406 : check e605602572406 [[],[]] .chain = true := by decide
def e605602572410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e605602572410 : Closed e605602572410 ∧ code e605602572410 = 2804625827962 := by decide
theorem cert_e605602572410 : check e605602572410 [[],[]] .chain = true := by decide
def e605602572650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e605602572650 : Closed e605602572650 ∧ code e605602572650 = 2804625828202 := by decide
theorem cert_e605602572650 : check e605602572650 [[],[]] .chain = true := by decide
def e605602572674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e605602572674 : Closed e605602572674 ∧ code e605602572674 = 2804625828226 := by decide
theorem cert_e605602572674 : check e605602572674 [[],[]] .chain = true := by decide
def e605602572686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e605602572686 : Closed e605602572686 ∧ code e605602572686 = 2804625828238 := by decide
theorem cert_e605602572686 : check e605602572686 [[],[]] .chain = true := by decide
def e605602572698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e605602572698 : Closed e605602572698 ∧ code e605602572698 = 2804625828250 := by decide
theorem cert_e605602572698 : check e605602572698 [[],[]] .chain = true := by decide
def e605602572742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e605602572742 : Closed e605602572742 ∧ code e605602572742 = 2804625828294 := by decide
theorem cert_e605602572742 : check e605602572742 [[],[]] .chain = true := by decide
def e605602572770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e605602572770 : Closed e605602572770 ∧ code e605602572770 = 2804625828322 := by decide
theorem cert_e605602572770 : checkPay e605602572770 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right],[.under,.under,.right],[.under,.under,.right,.left],[.under,.under,.right]] = true := by decide
def e605602572782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e605602572782 : Closed e605602572782 ∧ code e605602572782 = 2804625828334 := by decide
theorem cert_e605602572782 : checkPay e605602572782 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right],[.under,.under,.right],[.under,.under,.right,.left],[.under,.under,.right,.left,.left],[.under,.under,.right,.left],[.under,.under,.right]] = true := by decide
def e605602573366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e605602573366 : Closed e605602573366 ∧ code e605602573366 = 2804625828918 := by decide
theorem cert_e605602573366 : check e605602573366 [[],[]] .chain = true := by decide
def e605602573370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e605602573370 : Closed e605602573370 ∧ code e605602573370 = 2804625828922 := by decide
theorem cert_e605602573370 : check e605602573370 [[],[]] .chain = true := by decide
def e605602573510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e605602573510 : Closed e605602573510 ∧ code e605602573510 = 2804625829062 := by decide
theorem cert_e605602573510 : check e605602573510 [[],[]] .chain = true := by decide
def e605602573838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e605602573838 : Closed e605602573838 ∧ code e605602573838 = 2804625829390 := by decide
theorem cert_e605602573838 : checkPay e605602573838 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e605602573922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e605602573922 : Closed e605602573922 ∧ code e605602573922 = 2804625829474 := by decide
theorem cert_e605602573922 : checkPay e605602573922 [[.left,.left],[.left,.left],[.left],[]] 1 [[],[.left],[]] = true := by decide
def e605602573934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602573934 : Closed e605602573934 ∧ code e605602573934 = 2804625829486 := by decide
theorem cert_e605602573934 : checkPay e605602573934 [[.left,.left],[.left,.left],[.left],[]] 1 [[],[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] = true := by decide
def e605602573946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602573946 : Closed e605602573946 ∧ code e605602573946 = 2804625829498 := by decide
theorem cert_e605602573946 : checkPay e605602573946 [[.left,.left],[.left,.left],[.left],[]] 1 [[],[.under,.under,.left,.right],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.right]] = true := by decide
def e605602580414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.var 4)))))))))
theorem wire_e605602580414 : Closed e605602580414 ∧ code e605602580414 = 2804625835966 := by decide
theorem cert_e605602580414 : check e605602580414 [[],[]] .chain = true := by decide
def e605602580462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 4) (.var 2)))))))))
theorem wire_e605602580462 : Closed e605602580462 ∧ code e605602580462 = 2804625836014 := by decide
theorem cert_e605602580462 : check e605602580462 [[],[]] .chain = true := by decide
def e605602584286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e605602584286 : Closed e605602584286 ∧ code e605602584286 = 2804625839838 := by decide
theorem cert_e605602584286 : check e605602584286 [[],[]] .chain = true := by decide
def e605602584310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e605602584310 : Closed e605602584310 ∧ code e605602584310 = 2804625839862 := by decide
theorem cert_e605602584310 : check e605602584310 [[],[]] .chain = true := by decide
def e605602584414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e605602584414 : Closed e605602584414 ∧ code e605602584414 = 2804625839966 := by decide
theorem cert_e605602584414 : check e605602584414 [[],[]] .chain = true := by decide
def e605602584442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e605602584442 : Closed e605602584442 ∧ code e605602584442 = 2804625839994 := by decide
theorem cert_e605602584442 : check e605602584442 [[],[]] .chain = true := by decide
def e605602584534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e605602584534 : Closed e605602584534 ∧ code e605602584534 = 2804625840086 := by decide
theorem cert_e605602584534 : check e605602584534 [[],[]] .chain = true := by decide
def e605602584538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e605602584538 : Closed e605602584538 ∧ code e605602584538 = 2804625840090 := by decide
theorem cert_e605602584538 : check e605602584538 [[],[]] .chain = true := by decide
def e605602585054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e605602585054 : Closed e605602585054 ∧ code e605602585054 = 2804625840606 := by decide
theorem cert_e605602585054 : check e605602585054 [[],[]] .chain = true := by decide
def e605602585078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e605602585078 : Closed e605602585078 ∧ code e605602585078 = 2804625840630 := by decide
theorem cert_e605602585078 : check e605602585078 [[],[]] .chain = true := by decide
def e605602585822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e605602585822 : Closed e605602585822 ∧ code e605602585822 = 2804625841374 := by decide
theorem cert_e605602585822 : check e605602585822 [[],[]] .chain = true := by decide
def e605602585850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e605602585850 : Closed e605602585850 ∧ code e605602585850 = 2804625841402 := by decide
theorem cert_e605602585850 : check e605602585850 [[],[]] .chain = true := by decide
def e605602586174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e605602586174 : Closed e605602586174 ∧ code e605602586174 = 2804625841726 := by decide
theorem cert_e605602586174 : check e605602586174 [[],[]] .chain = true := by decide
def e605602586398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e605602586398 : Closed e605602586398 ∧ code e605602586398 = 2804625841950 := by decide
theorem cert_e605602586398 : check e605602586398 [[],[]] .chain = true := by decide
def e605602586422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e605602586422 : Closed e605602586422 ∧ code e605602586422 = 2804625841974 := by decide
theorem cert_e605602586422 : check e605602586422 [[],[]] .chain = true := by decide
def e605602586426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e605602586426 : Closed e605602586426 ∧ code e605602586426 = 2804625841978 := by decide
theorem cert_e605602586426 : check e605602586426 [[],[]] .chain = true := by decide
def e605602600622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e605602600622 : Closed e605602600622 ∧ code e605602600622 = 2804625856174 := by decide
theorem cert_e605602600622 : check e605602600622 [[],[]] .chain = true := by decide
def e605602600634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e605602600634 : Closed e605602600634 ∧ code e605602600634 = 2804625856186 := by decide
theorem cert_e605602600634 : check e605602600634 [[],[]] .chain = true := by decide
def e605602600682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e605602600682 : Closed e605602600682 ∧ code e605602600682 = 2804625856234 := by decide
theorem cert_e605602600682 : check e605602600682 [[],[]] .chain = true := by decide
def e605602600874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e605602600874 : Closed e605602600874 ∧ code e605602600874 = 2804625856426 := by decide
theorem cert_e605602600874 : check e605602600874 [[],[]] .chain = true := by decide
def e605602601006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e605602601006 : Closed e605602601006 ∧ code e605602601006 = 2804625856558 := by decide
theorem cert_e605602601006 : check e605602601006 [[],[]] .chain = true := by decide
def e605602601198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605602601198 : Closed e605602601198 ∧ code e605602601198 = 2804625856750 := by decide
theorem cert_e605602601198 : check e605602601198 [[],[]] .chain = true := by decide
def e605602601206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605602601206 : Closed e605602601206 ∧ code e605602601206 = 2804625856758 := by decide
theorem cert_e605602601206 : check e605602601206 [[],[]] .chain = true := by decide
def e605602601390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e605602601390 : Closed e605602601390 ∧ code e605602601390 = 2804625856942 := by decide
theorem cert_e605602601390 : check e605602601390 [[],[]] .chain = true := by decide
def e605602601402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e605602601402 : Closed e605602601402 ∧ code e605602601402 = 2804625856954 := by decide
theorem cert_e605602601402 : check e605602601402 [[],[]] .chain = true := by decide
def e605602601450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e605602601450 : Closed e605602601450 ∧ code e605602601450 = 2804625857002 := by decide
theorem cert_e605602601450 : check e605602601450 [[],[]] .chain = true := by decide
def e605602601582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e605602601582 : Closed e605602601582 ∧ code e605602601582 = 2804625857134 := by decide
theorem cert_e605602601582 : check e605602601582 [[],[]] .chain = true := by decide
def e605602601594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605602601594 : Closed e605602601594 ∧ code e605602601594 = 2804625857146 := by decide
theorem cert_e605602601594 : check e605602601594 [[],[]] .chain = true := by decide
def e605602601758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605602601758 : Closed e605602601758 ∧ code e605602601758 = 2804625857310 := by decide
theorem cert_e605602601758 : check e605602601758 [[],[]] .chain = true := by decide
def e605602601858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e605602601858 : Closed e605602601858 ∧ code e605602601858 = 2804625857410 := by decide
theorem cert_e605602601858 : check e605602601858 [[],[]] .chain = true := by decide
def e605602601870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605602601870 : Closed e605602601870 ∧ code e605602601870 = 2804625857422 := by decide
theorem cert_e605602601870 : check e605602601870 [[],[]] .chain = true := by decide
def e605602601882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605602601882 : Closed e605602601882 ∧ code e605602601882 = 2804625857434 := by decide
theorem cert_e605602601882 : check e605602601882 [[],[]] .chain = true := by decide
def e605602602094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605602602094 : Closed e605602602094 ∧ code e605602602094 = 2804625857646 := by decide
theorem cert_e605602602094 : check e605602602094 [[],[]] .chain = true := by decide
def e605602602106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605602602106 : Closed e605602602106 ∧ code e605602602106 = 2804625857658 := by decide
theorem cert_e605602602106 : check e605602602106 [[],[]] .chain = true := by decide
def e605602602270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605602602270 : Closed e605602602270 ∧ code e605602602270 = 2804625857822 := by decide
theorem cert_e605602602270 : check e605602602270 [[],[]] .chain = true := by decide
def e605602602438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605602602438 : Closed e605602602438 ∧ code e605602602438 = 2804625857990 := by decide
theorem cert_e605602602438 : check e605602602438 [[],[]] .chain = true := by decide
def e605602602506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e605602602506 : Closed e605602602506 ∧ code e605602602506 = 2804625858058 := by decide
theorem cert_e605602602506 : check e605602602506 [[],[]] .chain = true := by decide
def e605602602542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 2)))))))
theorem wire_e605602602542 : Closed e605602602542 ∧ code e605602602542 = 2804625858094 := by decide
theorem cert_e605602602542 : checkPay e605602602542 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602602550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605602602550 : Closed e605602602550 ∧ code e605602602550 = 2804625858102 := by decide
theorem cert_e605602602550 : check e605602602550 [[],[]] .chain = true := by decide
def e605602602554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605602602554 : Closed e605602602554 ∧ code e605602602554 = 2804625858106 := by decide
theorem cert_e605602602554 : check e605602602554 [[],[]] .chain = true := by decide
def e605602602602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e605602602602 : Closed e605602602602 ∧ code e605602602602 = 2804625858154 := by decide
theorem cert_e605602602602 : check e605602602602 [[],[]] .chain = true := by decide
def e605602602626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e605602602626 : Closed e605602602626 ∧ code e605602602626 = 2804625858178 := by decide
theorem cert_e605602602626 : check e605602602626 [[],[]] .chain = true := by decide
def e605602602638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605602602638 : Closed e605602602638 ∧ code e605602602638 = 2804625858190 := by decide
theorem cert_e605602602638 : check e605602602638 [[],[]] .chain = true := by decide
def e605602602650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e605602602650 : Closed e605602602650 ∧ code e605602602650 = 2804625858202 := by decide
theorem cert_e605602602650 : check e605602602650 [[],[]] .chain = true := by decide
def e605602602694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605602602694 : Closed e605602602694 ∧ code e605602602694 = 2804625858246 := by decide
theorem cert_e605602602694 : check e605602602694 [[],[]] .chain = true := by decide
def e605602602722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.lam (.var 0))))))))
theorem wire_e605602602722 : Closed e605602602722 ∧ code e605602602722 = 2804625858274 := by decide
theorem cert_e605602602722 : checkPay e605602602722 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602602734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 2)))))))
theorem wire_e605602602734 : Closed e605602602734 ∧ code e605602602734 = 2804625858286 := by decide
theorem cert_e605602602734 : checkPay e605602602734 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e605602603486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605602603486 : Closed e605602603486 ∧ code e605602603486 = 2804625859038 := by decide
theorem cert_e605602603486 : check e605602603486 [[],[]] .chain = true := by decide
def e605602603510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605602603510 : Closed e605602603510 ∧ code e605602603510 = 2804625859062 := by decide
theorem cert_e605602603510 : check e605602603510 [[],[]] .chain = true := by decide
def e605602604462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605602604462 : Closed e605602604462 ∧ code e605602604462 = 2804625860014 := by decide
theorem cert_e605602604462 : check e605602604462 [[],[]] .chain = true := by decide
def e605602604474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605602604474 : Closed e605602604474 ∧ code e605602604474 = 2804625860026 := by decide
theorem cert_e605602604474 : check e605602604474 [[],[]] .chain = true := by decide
def e605602604522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605602604522 : Closed e605602604522 ∧ code e605602604522 = 2804625860074 := by decide
theorem cert_e605602604522 : check e605602604522 [[],[]] .chain = true := by decide
def e605602604654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605602604654 : Closed e605602604654 ∧ code e605602604654 = 2804625860206 := by decide
theorem cert_e605602604654 : check e605602604654 [[],[]] .chain = true := by decide
def e605602604666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605602604666 : Closed e605602604666 ∧ code e605602604666 = 2804625860218 := by decide
theorem cert_e605602604666 : check e605602604666 [[],[]] .chain = true := by decide
def e605602604830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605602604830 : Closed e605602604830 ∧ code e605602604830 = 2804625860382 := by decide
theorem cert_e605602604830 : check e605602604830 [[],[]] .chain = true := by decide
def e605602604930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e605602604930 : Closed e605602604930 ∧ code e605602604930 = 2804625860482 := by decide
theorem cert_e605602604930 : check e605602604930 [[],[]] .chain = true := by decide
def e605602604942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605602604942 : Closed e605602604942 ∧ code e605602604942 = 2804625860494 := by decide
theorem cert_e605602604942 : check e605602604942 [[],[]] .chain = true := by decide
def e605602604954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605602604954 : Closed e605602604954 ∧ code e605602604954 = 2804625860506 := by decide
theorem cert_e605602604954 : check e605602604954 [[],[]] .chain = true := by decide
def e605602607326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e605602607326 : Closed e605602607326 ∧ code e605602607326 = 2804625862878 := by decide
theorem cert_e605602607326 : check e605602607326 [[],[]] .chain = true := by decide
def e605602607354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e605602607354 : Closed e605602607354 ∧ code e605602607354 = 2804625862906 := by decide
theorem cert_e605602607354 : check e605602607354 [[],[]] .chain = true := by decide
def e605602607902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605602607902 : Closed e605602607902 ∧ code e605602607902 = 2804625863454 := by decide
theorem cert_e605602607902 : check e605602607902 [[],[]] .chain = true := by decide
def e605602608070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605602608070 : Closed e605602608070 ∧ code e605602608070 = 2804625863622 := by decide
theorem cert_e605602608070 : check e605602608070 [[],[]] .chain = true := by decide
def e605602609178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605602609178 : Closed e605602609178 ∧ code e605602609178 = 2804625864730 := by decide
theorem cert_e605602609178 : checkPay e605602609178 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
end Blc.Floor41
