import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605637622394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e605637622394 : Closed e605637622394 ∧ code e605637622394 = 2804660877946 := by decide
theorem cert_e605637622394 : check e605637622394 [[],[]] .chain = true := by decide
def e605637622682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e605637622682 : Closed e605637622682 ∧ code e605637622682 = 2804660878234 := by decide
theorem cert_e605637622682 : check e605637622682 [[],[]] .chain = true := by decide
def e605637622998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e605637622998 : Closed e605637622998 ∧ code e605637622998 = 2804660878550 := by decide
theorem cert_e605637622998 : check e605637622998 [[],[]] .chain = true := by decide
def e605637623002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e605637623002 : Closed e605637623002 ∧ code e605637623002 = 2804660878554 := by decide
theorem cert_e605637623002 : check e605637623002 [[],[]] .chain = true := by decide
def e605637623018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e605637623018 : Closed e605637623018 ∧ code e605637623018 = 2804660878570 := by decide
theorem cert_e605637623018 : check e605637623018 [[],[]] .chain = true := by decide
def e605637623094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e605637623094 : Closed e605637623094 ∧ code e605637623094 = 2804660878646 := by decide
theorem cert_e605637623094 : check e605637623094 [[],[]] .chain = true := by decide
def e605637623098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e605637623098 : Closed e605637623098 ∧ code e605637623098 = 2804660878650 := by decide
theorem cert_e605637623098 : check e605637623098 [[],[]] .chain = true := by decide
def e605637623194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e605637623194 : Closed e605637623194 ∧ code e605637623194 = 2804660878746 := by decide
theorem cert_e605637623194 : check e605637623194 [[],[]] .chain = true := by decide
def e605637624798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e605637624798 : Closed e605637624798 ∧ code e605637624798 = 2804660880350 := by decide
theorem cert_e605637624798 : check e605637624798 [[],[]] .chain = true := by decide
def e605637624814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e605637624814 : Closed e605637624814 ∧ code e605637624814 = 2804660880366 := by decide
theorem cert_e605637624814 : check e605637624814 [[],[]] .chain = true := by decide
def e605637626734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605637626734 : Closed e605637626734 ∧ code e605637626734 = 2804660882286 := by decide
theorem cert_e605637626734 : check e605637626734 [[],[]] .chain = true := by decide
def e605637626742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605637626742 : Closed e605637626742 ∧ code e605637626742 = 2804660882294 := by decide
theorem cert_e605637626742 : check e605637626742 [[],[]] .chain = true := by decide
def e605637626798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605637626798 : Closed e605637626798 ∧ code e605637626798 = 2804660882350 := by decide
theorem cert_e605637626798 : check e605637626798 [[],[]] .chain = true := by decide
def e605637626810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605637626810 : Closed e605637626810 ∧ code e605637626810 = 2804660882362 := by decide
theorem cert_e605637626810 : check e605637626810 [[],[]] .chain = true := by decide
def e605637626838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605637626838 : Closed e605637626838 ∧ code e605637626838 = 2804660882390 := by decide
theorem cert_e605637626838 : check e605637626838 [[],[]] .chain = true := by decide
def e605637626842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605637626842 : Closed e605637626842 ∧ code e605637626842 = 2804660882394 := by decide
theorem cert_e605637626842 : check e605637626842 [[],[]] .chain = true := by decide
def e605637627118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605637627118 : Closed e605637627118 ∧ code e605637627118 = 2804660882670 := by decide
theorem cert_e605637627118 : check e605637627118 [[],[]] .chain = true := by decide
def e605637627126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605637627126 : Closed e605637627126 ∧ code e605637627126 = 2804660882678 := by decide
theorem cert_e605637627126 : check e605637627126 [[],[]] .chain = true := by decide
def e605637627502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605637627502 : Closed e605637627502 ∧ code e605637627502 = 2804660883054 := by decide
theorem cert_e605637627502 : check e605637627502 [[],[]] .chain = true := by decide
def e605637627514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605637627514 : Closed e605637627514 ∧ code e605637627514 = 2804660883066 := by decide
theorem cert_e605637627514 : check e605637627514 [[],[]] .chain = true := by decide
def e605637627702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605637627702 : Closed e605637627702 ∧ code e605637627702 = 2804660883254 := by decide
theorem cert_e605637627702 : check e605637627702 [[],[]] .chain = true := by decide
def e605637627706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605637627706 : Closed e605637627706 ∧ code e605637627706 = 2804660883258 := by decide
theorem cert_e605637627706 : check e605637627706 [[],[]] .chain = true := by decide
def e605637632478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605637632478 : Closed e605637632478 ∧ code e605637632478 = 2804660888030 := by decide
theorem cert_e605637632478 : check e605637632478 [[],[]] .chain = true := by decide
def e605637632502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605637632502 : Closed e605637632502 ∧ code e605637632502 = 2804660888054 := by decide
theorem cert_e605637632502 : check e605637632502 [[],[]] .chain = true := by decide
def e605637633454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605637633454 : Closed e605637633454 ∧ code e605637633454 = 2804660889006 := by decide
theorem cert_e605637633454 : check e605637633454 [[],[]] .chain = true := by decide
def e605637633466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605637633466 : Closed e605637633466 ∧ code e605637633466 = 2804660889018 := by decide
theorem cert_e605637633466 : check e605637633466 [[],[]] .chain = true := by decide
def e605637633514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605637633514 : Closed e605637633514 ∧ code e605637633514 = 2804660889066 := by decide
theorem cert_e605637633514 : check e605637633514 [[],[]] .chain = true := by decide
def e605637633646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605637633646 : Closed e605637633646 ∧ code e605637633646 = 2804660889198 := by decide
theorem cert_e605637633646 : check e605637633646 [[],[]] .chain = true := by decide
def e605637633658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605637633658 : Closed e605637633658 ∧ code e605637633658 = 2804660889210 := by decide
theorem cert_e605637633658 : check e605637633658 [[],[]] .chain = true := by decide
def e605637633946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605637633946 : Closed e605637633946 ∧ code e605637633946 = 2804660889498 := by decide
theorem cert_e605637633946 : check e605637633946 [[],[]] .chain = true := by decide
def e605637636334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605637636334 : Closed e605637636334 ∧ code e605637636334 = 2804660891886 := by decide
theorem cert_e605637636334 : check e605637636334 [[],[]] .chain = true := by decide
def e605637636342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605637636342 : Closed e605637636342 ∧ code e605637636342 = 2804660891894 := by decide
theorem cert_e605637636342 : check e605637636342 [[],[]] .chain = true := by decide
def e605637636822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605637636822 : Closed e605637636822 ∧ code e605637636822 = 2804660892374 := by decide
theorem cert_e605637636822 : check e605637636822 [[],[]] .chain = true := by decide
def e605637636826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605637636826 : Closed e605637636826 ∧ code e605637636826 = 2804660892378 := by decide
theorem cert_e605637636826 : check e605637636826 [[],[]] .chain = true := by decide
def e605637636842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605637636842 : Closed e605637636842 ∧ code e605637636842 = 2804660892394 := by decide
theorem cert_e605637636842 : check e605637636842 [[],[]] .chain = true := by decide
def e605637636918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605637636918 : Closed e605637636918 ∧ code e605637636918 = 2804660892470 := by decide
theorem cert_e605637636918 : check e605637636918 [[],[]] .chain = true := by decide
def e605637636922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605637636922 : Closed e605637636922 ∧ code e605637636922 = 2804660892474 := by decide
theorem cert_e605637636922 : check e605637636922 [[],[]] .chain = true := by decide
def e605637637018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605637637018 : Closed e605637637018 ∧ code e605637637018 = 2804660892570 := by decide
theorem cert_e605637637018 : check e605637637018 [[],[]] .chain = true := by decide
def e605637774190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605637774190 : Closed e605637774190 ∧ code e605637774190 = 2804661029742 := by decide
theorem cert_e605637774190 : check e605637774190 [[],[]] .chain = true := by decide
def e605637774198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605637774198 : Closed e605637774198 ∧ code e605637774198 = 2804661029750 := by decide
theorem cert_e605637774198 : check e605637774198 [[],[]] .chain = true := by decide
def e605637774254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605637774254 : Closed e605637774254 ∧ code e605637774254 = 2804661029806 := by decide
theorem cert_e605637774254 : check e605637774254 [[],[]] .chain = true := by decide
def e605637774266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605637774266 : Closed e605637774266 ∧ code e605637774266 = 2804661029818 := by decide
theorem cert_e605637774266 : check e605637774266 [[],[]] .chain = true := by decide
def e605637774294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605637774294 : Closed e605637774294 ∧ code e605637774294 = 2804661029846 := by decide
theorem cert_e605637774294 : check e605637774294 [[],[]] .chain = true := by decide
def e605637774298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605637774298 : Closed e605637774298 ∧ code e605637774298 = 2804661029850 := by decide
theorem cert_e605637774298 : check e605637774298 [[],[]] .chain = true := by decide
def e605637774574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605637774574 : Closed e605637774574 ∧ code e605637774574 = 2804661030126 := by decide
theorem cert_e605637774574 : check e605637774574 [[],[]] .chain = true := by decide
def e605637774582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605637774582 : Closed e605637774582 ∧ code e605637774582 = 2804661030134 := by decide
theorem cert_e605637774582 : check e605637774582 [[],[]] .chain = true := by decide
def e605637774958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605637774958 : Closed e605637774958 ∧ code e605637774958 = 2804661030510 := by decide
theorem cert_e605637774958 : check e605637774958 [[],[]] .chain = true := by decide
def e605637774970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605637774970 : Closed e605637774970 ∧ code e605637774970 = 2804661030522 := by decide
theorem cert_e605637774970 : check e605637774970 [[],[]] .chain = true := by decide
def e605637775158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605637775158 : Closed e605637775158 ∧ code e605637775158 = 2804661030710 := by decide
theorem cert_e605637775158 : check e605637775158 [[],[]] .chain = true := by decide
def e605637775162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605637775162 : Closed e605637775162 ∧ code e605637775162 = 2804661030714 := by decide
theorem cert_e605637775162 : check e605637775162 [[],[]] .chain = true := by decide
def e605638104798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e605638104798 : Closed e605638104798 ∧ code e605638104798 = 2804661360350 := by decide
theorem cert_e605638104798 : check e605638104798 [[],[]] .sourceHead = true := by decide
def e605638104822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e605638104822 : Closed e605638104822 ∧ code e605638104822 = 2804661360374 := by decide
theorem cert_e605638104822 : check e605638104822 [[],[]] .sourceHead = true := by decide
def e605638104926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e605638104926 : Closed e605638104926 ∧ code e605638104926 = 2804661360478 := by decide
theorem cert_e605638104926 : check e605638104926 [[],[]] .sourceHead = true := by decide
def e605638104954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e605638104954 : Closed e605638104954 ∧ code e605638104954 = 2804661360506 := by decide
theorem cert_e605638104954 : check e605638104954 [[],[]] .sourceHead = true := by decide
def e605638105046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e605638105046 : Closed e605638105046 ∧ code e605638105046 = 2804661360598 := by decide
theorem cert_e605638105046 : check e605638105046 [[],[]] .sourceHead = true := by decide
def e605638105050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e605638105050 : Closed e605638105050 ∧ code e605638105050 = 2804661360602 := by decide
theorem cert_e605638105050 : check e605638105050 [[],[]] .sourceHead = true := by decide
def e605638105566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e605638105566 : Closed e605638105566 ∧ code e605638105566 = 2804661361118 := by decide
theorem cert_e605638105566 : check e605638105566 [[],[]] .sourceHead = true := by decide
def e605638105590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e605638105590 : Closed e605638105590 ∧ code e605638105590 = 2804661361142 := by decide
theorem cert_e605638105590 : check e605638105590 [[],[]] .sourceHead = true := by decide
def e605638106334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e605638106334 : Closed e605638106334 ∧ code e605638106334 = 2804661361886 := by decide
theorem cert_e605638106334 : check e605638106334 [[],[]] .sourceHead = true := by decide
def e605638106362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e605638106362 : Closed e605638106362 ∧ code e605638106362 = 2804661361914 := by decide
theorem cert_e605638106362 : check e605638106362 [[],[]] .sourceHead = true := by decide
def e605638106934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e605638106934 : Closed e605638106934 ∧ code e605638106934 = 2804661362486 := by decide
theorem cert_e605638106934 : check e605638106934 [[],[]] .sourceHead = true := by decide
def e605638106938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e605638106938 : Closed e605638106938 ∧ code e605638106938 = 2804661362490 := by decide
theorem cert_e605638106938 : check e605638106938 [[],[]] .sourceHead = true := by decide
def e605638121710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605638121710 : Closed e605638121710 ∧ code e605638121710 = 2804661377262 := by decide
theorem cert_e605638121710 : check e605638121710 [[],[]] .sourceHead = true := by decide
def e605638121718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605638121718 : Closed e605638121718 ∧ code e605638121718 = 2804661377270 := by decide
theorem cert_e605638121718 : check e605638121718 [[],[]] .sourceHead = true := by decide
def e605638122270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605638122270 : Closed e605638122270 ∧ code e605638122270 = 2804661377822 := by decide
theorem cert_e605638122270 : check e605638122270 [[],[]] .sourceHead = true := by decide
def e605638122382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605638122382 : Closed e605638122382 ∧ code e605638122382 = 2804661377934 := by decide
theorem cert_e605638122382 : check e605638122382 [[],[]] .sourceHead = true := by decide
def e605638122606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605638122606 : Closed e605638122606 ∧ code e605638122606 = 2804661378158 := by decide
theorem cert_e605638122606 : check e605638122606 [[],[]] .sourceHead = true := by decide
def e605638122618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605638122618 : Closed e605638122618 ∧ code e605638122618 = 2804661378170 := by decide
theorem cert_e605638122618 : check e605638122618 [[],[]] .sourceHead = true := by decide
def e605638122782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605638122782 : Closed e605638122782 ∧ code e605638122782 = 2804661378334 := by decide
theorem cert_e605638122782 : check e605638122782 [[],[]] .sourceHead = true := by decide
def e605638122950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605638122950 : Closed e605638122950 ∧ code e605638122950 = 2804661378502 := by decide
theorem cert_e605638122950 : check e605638122950 [[],[]] .sourceHead = true := by decide
def e605638123062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605638123062 : Closed e605638123062 ∧ code e605638123062 = 2804661378614 := by decide
theorem cert_e605638123062 : check e605638123062 [[],[]] .sourceHead = true := by decide
def e605638123066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605638123066 : Closed e605638123066 ∧ code e605638123066 = 2804661378618 := by decide
theorem cert_e605638123066 : check e605638123066 [[],[]] .sourceHead = true := by decide
def e605638123150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605638123150 : Closed e605638123150 ∧ code e605638123150 = 2804661378702 := by decide
theorem cert_e605638123150 : check e605638123150 [[],[]] .sourceHead = true := by decide
def e605638123206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605638123206 : Closed e605638123206 ∧ code e605638123206 = 2804661378758 := by decide
theorem cert_e605638123206 : check e605638123206 [[],[]] .sourceHead = true := by decide
def e605638125342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605638125342 : Closed e605638125342 ∧ code e605638125342 = 2804661380894 := by decide
theorem cert_e605638125342 : check e605638125342 [[],[]] .sourceHead = true := by decide
def e605638125454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605638125454 : Closed e605638125454 ∧ code e605638125454 = 2804661381006 := by decide
theorem cert_e605638125454 : check e605638125454 [[],[]] .sourceHead = true := by decide
def e605638128414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605638128414 : Closed e605638128414 ∧ code e605638128414 = 2804661383966 := by decide
theorem cert_e605638128414 : check e605638128414 [[],[]] .sourceHead = true := by decide
def e605638128582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605638128582 : Closed e605638128582 ∧ code e605638128582 = 2804661384134 := by decide
theorem cert_e605638128582 : check e605638128582 [[],[]] .sourceHead = true := by decide
def e605638130062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605638130062 : Closed e605638130062 ∧ code e605638130062 = 2804661385614 := by decide
theorem cert_e605638130062 : check e605638130062 [[],[]] .sourceHead = true := by decide
def e605638130118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605638130118 : Closed e605638130118 ∧ code e605638130118 = 2804661385670 := by decide
theorem cert_e605638130118 : check e605638130118 [[],[]] .sourceHead = true := by decide
def e605638646646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 1)))))
theorem wire_e605638646646 : Closed e605638646646 ∧ code e605638646646 = 2804661902198 := by decide
theorem cert_e605638646646 : check e605638646646 [[],[],[.under,.left]] .chain = true := by decide
def e605638646650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))) (.var 0)))))
theorem wire_e605638646650 : Closed e605638646650 ∧ code e605638646650 = 2804661902202 := by decide
theorem cert_e605638646650 : check e605638646650 [[],[],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e605638646710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1)))))
theorem wire_e605638646710 : Closed e605638646710 ∧ code e605638646710 = 2804661902262 := by decide
theorem cert_e605638646710 : check e605638646710 [[],[],[.under,.left]] .chain = true := by decide
def e605638646746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))) (.var 0)))))
theorem wire_e605638646746 : Closed e605638646746 ∧ code e605638646746 = 2804661902298 := by decide
theorem cert_e605638646746 : check e605638646746 [[],[],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e605638647158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 1)))))
theorem wire_e605638647158 : Closed e605638647158 ∧ code e605638647158 = 2804661902710 := by decide
theorem cert_e605638647158 : check e605638647158 [[],[],[.under,.left]] .chain = true := by decide
def e605638647162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))) (.var 0)))))
theorem wire_e605638647162 : Closed e605638647162 ∧ code e605638647162 = 2804661902714 := by decide
theorem cert_e605638647162 : check e605638647162 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e605638647254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1)))))
theorem wire_e605638647254 : Closed e605638647254 ∧ code e605638647254 = 2804661902806 := by decide
theorem cert_e605638647254 : check e605638647254 [[],[],[.under,.left]] .chain = true := by decide
def e605638647274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))) (.var 0)))))
theorem wire_e605638647274 : Closed e605638647274 ∧ code e605638647274 = 2804661902826 := by decide
private def t_e605638647274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))) (.var 0)))))
theorem cert_e605638647274 : ¬ IsSelfInterpreter e605638647274 :=
  wSource (t := t_e605638647274) (replay_sound (ps := []) (t := e605638647274) (by decide)) (by decide)
def e605638647478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1)))))
theorem wire_e605638647478 : Closed e605638647478 ∧ code e605638647478 = 2804661903030 := by decide
theorem cert_e605638647478 : check e605638647478 [[],[],[.under,.left]] .chain = true := by decide
def e605638647510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1)))))
theorem wire_e605638647510 : Closed e605638647510 ∧ code e605638647510 = 2804661903062 := by decide
theorem cert_e605638647510 : check e605638647510 [[],[],[.under,.left]] .chain = true := by decide
def e605638647642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e605638647642 : Closed e605638647642 ∧ code e605638647642 = 2804661903194 := by decide
theorem cert_e605638647642 : check e605638647642 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605638647658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e605638647658 : Closed e605638647658 ∧ code e605638647658 = 2804661903210 := by decide
private def t_e605638647658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))) (.var 0)))))
theorem cert_e605638647658 : ¬ IsSelfInterpreter e605638647658 :=
  wSource (t := t_e605638647658) (replay_sound (ps := []) (t := e605638647658) (by decide)) (by decide)
def e605638649718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 1)))))
theorem wire_e605638649718 : Closed e605638649718 ∧ code e605638649718 = 2804661905270 := by decide
theorem cert_e605638649718 : check e605638649718 [[],[],[.under,.left]] .chain = true := by decide
def e605638649722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))) (.var 0)))))
theorem wire_e605638649722 : Closed e605638649722 ∧ code e605638649722 = 2804661905274 := by decide
theorem cert_e605638649722 : check e605638649722 [[],[],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e605638649782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 1)))))
theorem wire_e605638649782 : Closed e605638649782 ∧ code e605638649782 = 2804661905334 := by decide
theorem cert_e605638649782 : check e605638649782 [[],[],[.under,.left]] .chain = true := by decide
def e605638649818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))) (.var 0)))))
theorem wire_e605638649818 : Closed e605638649818 ∧ code e605638649818 = 2804661905370 := by decide
theorem cert_e605638649818 : check e605638649818 [[],[],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e605638652790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 1)))))
theorem wire_e605638652790 : Closed e605638652790 ∧ code e605638652790 = 2804661908342 := by decide
theorem cert_e605638652790 : check e605638652790 [[],[],[.under,.left]] .chain = true := by decide
def e605638652794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))) (.var 0)))))
theorem wire_e605638652794 : Closed e605638652794 ∧ code e605638652794 = 2804661908346 := by decide
theorem cert_e605638652794 : checkPay e605638652794 [[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605638652886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 1)))))
theorem wire_e605638652886 : Closed e605638652886 ∧ code e605638652886 = 2804661908438 := by decide
theorem cert_e605638652886 : check e605638652886 [[],[],[.under,.left]] .chain = true := by decide
def e605638652906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))) (.var 0)))))
theorem wire_e605638652906 : Closed e605638652906 ∧ code e605638652906 = 2804661908458 := by decide
theorem cert_e605638652906 : check e605638652906 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e605638654390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 1)))))
theorem wire_e605638654390 : Closed e605638654390 ∧ code e605638654390 = 2804661909942 := by decide
theorem cert_e605638654390 : check e605638654390 [[],[],[.under,.left]] .chain = true := by decide
def e605638654422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 1)))))
theorem wire_e605638654422 : Closed e605638654422 ∧ code e605638654422 = 2804661909974 := by decide
theorem cert_e605638654422 : check e605638654422 [[],[],[.under,.left]] .chain = true := by decide
def e605638655194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e605638655194 : Closed e605638655194 ∧ code e605638655194 = 2804661910746 := by decide
theorem cert_e605638655194 : check e605638655194 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e605638655210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e605638655210 : Closed e605638655210 ∧ code e605638655210 = 2804661910762 := by decide
theorem cert_e605638655210 : check e605638655210 [[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e605638714298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))) (.var 0)))))
theorem wire_e605638714298 : Closed e605638714298 ∧ code e605638714298 = 2804661969850 := by decide
theorem cert_e605638714298 : check e605638714298 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e605638714330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))) (.var 0)))))
theorem wire_e605638714330 : Closed e605638714330 ∧ code e605638714330 = 2804661969882 := by decide
theorem cert_e605638714330 : check e605638714330 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e605638716538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))) (.var 0)))))
theorem wire_e605638716538 : Closed e605638716538 ∧ code e605638716538 = 2804661972090 := by decide
theorem cert_e605638716538 : check e605638716538 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e605638716870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 1))))))
theorem wire_e605638716870 : Closed e605638716870 ∧ code e605638716870 = 2804661972422 := by decide
theorem cert_e605638716870 : check e605638716870 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e605638716986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))) (.var 0)))))
theorem wire_e605638716986 : Closed e605638716986 ∧ code e605638716986 = 2804661972538 := by decide
private def t_e605638716986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))) (.var 0)))))
theorem cert_e605638716986 : ¬ IsSelfInterpreter e605638716986 :=
  wSource (t := t_e605638716986) (replay_sound (ps := []) (t := e605638716986) (by decide)) (by decide)
def e605638717126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 1))))))
theorem wire_e605638717126 : Closed e605638717126 ∧ code e605638717126 = 2804661972678 := by decide
private def t_e605638717126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 1))))))
theorem cert_e605638717126 : ¬ IsSelfInterpreter e605638717126 :=
  wSource (t := t_e605638717126) (replay_sound (ps := []) (t := e605638717126) (by decide)) (by decide)
def e605638717882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))) (.var 0)))))
theorem wire_e605638717882 : Closed e605638717882 ∧ code e605638717882 = 2804661973434 := by decide
theorem cert_e605638717882 : check e605638717882 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e605638717930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))) (.var 0)))))
theorem wire_e605638717930 : Closed e605638717930 ∧ code e605638717930 = 2804661973482 := by decide
theorem cert_e605638717930 : check e605638717930 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e605638718586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))) (.var 0)))))
theorem wire_e605638718586 : Closed e605638718586 ∧ code e605638718586 = 2804661974138 := by decide
theorem cert_e605638718586 : check e605638718586 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e605638718918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 1))))))
theorem wire_e605638718918 : Closed e605638718918 ∧ code e605638718918 = 2804661974470 := by decide
theorem cert_e605638718918 : check e605638718918 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e605638719258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))) (.var 0)))))
theorem wire_e605638719258 : Closed e605638719258 ∧ code e605638719258 = 2804661974810 := by decide
theorem cert_e605638719258 : check e605638719258 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e605638719302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 1))))))
theorem wire_e605638719302 : Closed e605638719302 ∧ code e605638719302 = 2804661974854 := by decide
theorem cert_e605638719302 : check e605638719302 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e605638719706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))) (.var 0)))))
theorem wire_e605638719706 : Closed e605638719706 ∧ code e605638719706 = 2804661975258 := by decide
theorem cert_e605638719706 : check e605638719706 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605638719722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))) (.var 0)))))
theorem wire_e605638719722 : Closed e605638719722 ∧ code e605638719722 = 2804661975274 := by decide
theorem cert_e605638719722 : check e605638719722 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605638720058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))) (.var 0)))))
theorem wire_e605638720058 : Closed e605638720058 ∧ code e605638720058 = 2804661975610 := by decide
private def t_e605638720058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))) (.var 0)))))
theorem cert_e605638720058 : ¬ IsSelfInterpreter e605638720058 :=
  wSource (t := t_e605638720058) (replay_sound (ps := []) (t := e605638720058) (by decide)) (by decide)
def e605638720198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 1))))))
theorem wire_e605638720198 : Closed e605638720198 ∧ code e605638720198 = 2804661975750 := by decide
private def t_e605638720198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 1))))))
theorem cert_e605638720198 : ¬ IsSelfInterpreter e605638720198 :=
  wSource (t := t_e605638720198) (replay_sound (ps := []) (t := e605638720198) (by decide)) (by decide)
def e605638720282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))) (.var 0)))))
theorem wire_e605638720282 : Closed e605638720282 ∧ code e605638720282 = 2804661975834 := by decide
theorem cert_e605638720282 : check e605638720282 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605638720326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 1))))))
theorem wire_e605638720326 : Closed e605638720326 ∧ code e605638720326 = 2804661975878 := by decide
theorem cert_e605638720326 : check e605638720326 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605638728826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))) (.var 0)))))
theorem wire_e605638728826 : Closed e605638728826 ∧ code e605638728826 = 2804661984378 := by decide
theorem cert_e605638728826 : check e605638728826 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e605638729158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 1))))))
theorem wire_e605638729158 : Closed e605638729158 ∧ code e605638729158 = 2804661984710 := by decide
theorem cert_e605638729158 : check e605638729158 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e605638729274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))) (.var 0)))))
theorem wire_e605638729274 : Closed e605638729274 ∧ code e605638729274 = 2804661984826 := by decide
theorem cert_e605638729274 : check e605638729274 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605638729414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 1))))))
theorem wire_e605638729414 : Closed e605638729414 ∧ code e605638729414 = 2804661984966 := by decide
theorem cert_e605638729414 : check e605638729414 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605638741114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))) (.var 0)))))
theorem wire_e605638741114 : Closed e605638741114 ∧ code e605638741114 = 2804661996666 := by decide
theorem cert_e605638741114 : check e605638741114 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e605638741446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 1))))))
theorem wire_e605638741446 : Closed e605638741446 ∧ code e605638741446 = 2804661996998 := by decide
theorem cert_e605638741446 : check e605638741446 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e605638741786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))) (.var 0)))))
theorem wire_e605638741786 : Closed e605638741786 ∧ code e605638741786 = 2804661997338 := by decide
theorem cert_e605638741786 : check e605638741786 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e605638741830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 1))))))
theorem wire_e605638741830 : Closed e605638741830 ∧ code e605638741830 = 2804661997382 := by decide
theorem cert_e605638741830 : check e605638741830 [[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e605638747706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))) (.var 0)))))
theorem wire_e605638747706 : Closed e605638747706 ∧ code e605638747706 = 2804662003258 := by decide
theorem cert_e605638747706 : check e605638747706 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e605638747846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 1))))))
theorem wire_e605638747846 : Closed e605638747846 ∧ code e605638747846 = 2804662003398 := by decide
theorem cert_e605638747846 : check e605638747846 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605638747930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))) (.var 0)))))
theorem wire_e605638747930 : Closed e605638747930 ∧ code e605638747930 = 2804662003482 := by decide
theorem cert_e605638747930 : check e605638747930 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e605638747974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 1))))))
theorem wire_e605638747974 : Closed e605638747974 ∧ code e605638747974 = 2804662003526 := by decide
theorem cert_e605638747974 : check e605638747974 [[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e605638822766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605638822766 : Closed e605638822766 ∧ code e605638822766 = 2804662078318 := by decide
theorem cert_e605638822766 : check e605638822766 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605638822774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605638822774 : Closed e605638822774 ∧ code e605638822774 = 2804662078326 := by decide
theorem cert_e605638822774 : check e605638822774 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605638822830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605638822830 : Closed e605638822830 ∧ code e605638822830 = 2804662078382 := by decide
theorem cert_e605638822830 : check e605638822830 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605638822842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605638822842 : Closed e605638822842 ∧ code e605638822842 = 2804662078394 := by decide
theorem cert_e605638822842 : check e605638822842 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605638822870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605638822870 : Closed e605638822870 ∧ code e605638822870 = 2804662078422 := by decide
theorem cert_e605638822870 : check e605638822870 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605638822874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605638822874 : Closed e605638822874 ∧ code e605638822874 = 2804662078426 := by decide
theorem cert_e605638822874 : check e605638822874 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605638823150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605638823150 : Closed e605638823150 ∧ code e605638823150 = 2804662078702 := by decide
theorem cert_e605638823150 : check e605638823150 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605638823158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605638823158 : Closed e605638823158 ∧ code e605638823158 = 2804662078710 := by decide
theorem cert_e605638823158 : check e605638823158 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605638823534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605638823534 : Closed e605638823534 ∧ code e605638823534 = 2804662079086 := by decide
theorem cert_e605638823534 : check e605638823534 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605638823546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605638823546 : Closed e605638823546 ∧ code e605638823546 = 2804662079098 := by decide
theorem cert_e605638823546 : check e605638823546 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605638823734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605638823734 : Closed e605638823734 ∧ code e605638823734 = 2804662079286 := by decide
theorem cert_e605638823734 : check e605638823734 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605638823738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605638823738 : Closed e605638823738 ∧ code e605638823738 = 2804662079290 := by decide
theorem cert_e605638823738 : check e605638823738 [[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605639153374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e605639153374 : Closed e605639153374 ∧ code e605639153374 = 2804662408926 := by decide
theorem cert_e605639153374 : check e605639153374 [[],[],[.under,.left]] .chain = true := by decide
def e605639153398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e605639153398 : Closed e605639153398 ∧ code e605639153398 = 2804662408950 := by decide
theorem cert_e605639153398 : check e605639153398 [[],[],[.under,.left]] .chain = true := by decide
def e605639153502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e605639153502 : Closed e605639153502 ∧ code e605639153502 = 2804662409054 := by decide
theorem cert_e605639153502 : check e605639153502 [[],[],[.under,.left]] .chain = true := by decide
def e605639153530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e605639153530 : Closed e605639153530 ∧ code e605639153530 = 2804662409082 := by decide
theorem cert_e605639153530 : check e605639153530 [[],[],[.under,.left]] .chain = true := by decide
def e605639153622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e605639153622 : Closed e605639153622 ∧ code e605639153622 = 2804662409174 := by decide
theorem cert_e605639153622 : check e605639153622 [[],[],[.under,.left]] .chain = true := by decide
def e605639153626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e605639153626 : Closed e605639153626 ∧ code e605639153626 = 2804662409178 := by decide
theorem cert_e605639153626 : check e605639153626 [[],[],[.under,.left]] .chain = true := by decide
def e605639154142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e605639154142 : Closed e605639154142 ∧ code e605639154142 = 2804662409694 := by decide
theorem cert_e605639154142 : check e605639154142 [[],[],[.under,.left]] .chain = true := by decide
def e605639154166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e605639154166 : Closed e605639154166 ∧ code e605639154166 = 2804662409718 := by decide
theorem cert_e605639154166 : check e605639154166 [[],[],[.under,.left]] .chain = true := by decide
def e605639154910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e605639154910 : Closed e605639154910 ∧ code e605639154910 = 2804662410462 := by decide
theorem cert_e605639154910 : check e605639154910 [[],[],[.under,.left]] .chain = true := by decide
def e605639154938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e605639154938 : Closed e605639154938 ∧ code e605639154938 = 2804662410490 := by decide
theorem cert_e605639154938 : check e605639154938 [[],[],[.under,.left]] .chain = true := by decide
def e605639155510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e605639155510 : Closed e605639155510 ∧ code e605639155510 = 2804662411062 := by decide
theorem cert_e605639155510 : check e605639155510 [[],[],[.under,.left]] .chain = true := by decide
def e605639155514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e605639155514 : Closed e605639155514 ∧ code e605639155514 = 2804662411066 := by decide
theorem cert_e605639155514 : check e605639155514 [[],[],[.under,.left]] .chain = true := by decide
def e605639170286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605639170286 : Closed e605639170286 ∧ code e605639170286 = 2804662425838 := by decide
theorem cert_e605639170286 : check e605639170286 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e605639170294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605639170294 : Closed e605639170294 ∧ code e605639170294 = 2804662425846 := by decide
theorem cert_e605639170294 : check e605639170294 [[],[],[.under,.left],[.under]] .sourceHead = true := by decide
end Blc.Floor41
