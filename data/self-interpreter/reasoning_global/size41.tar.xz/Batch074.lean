import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605591108422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e605591108422 : Closed e605591108422 ∧ code e605591108422 = 2804614363974 := by decide
theorem cert_e605591108422 : check e605591108422 [[],[]] .smaller = true := by decide
def e605591108446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e605591108446 : Closed e605591108446 ∧ code e605591108446 = 2804614363998 := by decide
theorem cert_e605591108446 : check e605591108446 [[],[]] .smaller = true := by decide
def e605591108462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e605591108462 : Closed e605591108462 ∧ code e605591108462 = 2804614364014 := by decide
theorem cert_e605591108462 : check e605591108462 [[],[]] .smaller = true := by decide
def e605591108470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e605591108470 : Closed e605591108470 ∧ code e605591108470 = 2804614364022 := by decide
theorem cert_e605591108470 : check e605591108470 [[],[]] .smaller = true := by decide
def e605591108474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e605591108474 : Closed e605591108474 ∧ code e605591108474 = 2804614364026 := by decide
theorem cert_e605591108474 : check e605591108474 [[],[]] .smaller = true := by decide
def e605591108526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e605591108526 : Closed e605591108526 ∧ code e605591108526 = 2804614364078 := by decide
theorem cert_e605591108526 : check e605591108526 [[],[]] .smaller = true := by decide
def e605591108534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e605591108534 : Closed e605591108534 ∧ code e605591108534 = 2804614364086 := by decide
theorem cert_e605591108534 : check e605591108534 [[],[]] .smaller = true := by decide
def e605591108538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e605591108538 : Closed e605591108538 ∧ code e605591108538 = 2804614364090 := by decide
theorem cert_e605591108538 : check e605591108538 [[],[]] .smaller = true := by decide
def e605591108566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e605591108566 : Closed e605591108566 ∧ code e605591108566 = 2804614364118 := by decide
theorem cert_e605591108566 : check e605591108566 [[],[]] .smaller = true := by decide
def e605591108570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e605591108570 : Closed e605591108570 ∧ code e605591108570 = 2804614364122 := by decide
theorem cert_e605591108570 : check e605591108570 [[],[]] .smaller = true := by decide
def e605591108586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 4)) (.var 0)) (.var 0))))))))
theorem wire_e605591108586 : Closed e605591108586 ∧ code e605591108586 = 2804614364138 := by decide
theorem cert_e605591108586 : check e605591108586 [[],[]] .three = true := by decide
def e605591108958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e605591108958 : Closed e605591108958 ∧ code e605591108958 = 2804614364510 := by decide
theorem cert_e605591108958 : check e605591108958 [[],[]] .three = true := by decide
def e605591108986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e605591108986 : Closed e605591108986 ∧ code e605591108986 = 2804614364538 := by decide
theorem cert_e605591108986 : check e605591108986 [[],[]] .three = true := by decide
def e605591109098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e605591109098 : Closed e605591109098 ∧ code e605591109098 = 2804614364650 := by decide
theorem cert_e605591109098 : check e605591109098 [[],[]] .three = true := by decide
def e605591113454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))))
theorem wire_e605591113454 : Closed e605591113454 ∧ code e605591113454 = 2804614369006 := by decide
theorem cert_e605591113454 : check e605591113454 [[],[]] .smaller = true := by decide
def e605591113462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))))
theorem wire_e605591113462 : Closed e605591113462 ∧ code e605591113462 = 2804614369014 := by decide
theorem cert_e605591113462 : check e605591113462 [[],[]] .smaller = true := by decide
def e605591113582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))))
theorem wire_e605591113582 : Closed e605591113582 ∧ code e605591113582 = 2804614369134 := by decide
theorem cert_e605591113582 : check e605591113582 [[],[]] .smaller = true := by decide
def e605591113594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))))
theorem wire_e605591113594 : Closed e605591113594 ∧ code e605591113594 = 2804614369146 := by decide
theorem cert_e605591113594 : check e605591113594 [[],[]] .smaller = true := by decide
def e605591113654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))))
theorem wire_e605591113654 : Closed e605591113654 ∧ code e605591113654 = 2804614369206 := by decide
theorem cert_e605591113654 : check e605591113654 [[],[]] .smaller = true := by decide
def e605591113658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))))
theorem wire_e605591113658 : Closed e605591113658 ∧ code e605591113658 = 2804614369210 := by decide
theorem cert_e605591113658 : check e605591113658 [[],[]] .smaller = true := by decide
def e605591116254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 3)))))))))
theorem wire_e605591116254 : Closed e605591116254 ∧ code e605591116254 = 2804614371806 := by decide
theorem cert_e605591116254 : check e605591116254 [[],[]] .smaller = true := by decide
def e605591116278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.var 1)))))))))
theorem wire_e605591116278 : Closed e605591116278 ∧ code e605591116278 = 2804614371830 := by decide
theorem cert_e605591116278 : check e605591116278 [[],[]] .smaller = true := by decide
def e605591117022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 3)))))))))
theorem wire_e605591117022 : Closed e605591117022 ∧ code e605591117022 = 2804614372574 := by decide
theorem cert_e605591117022 : check e605591117022 [[],[]] .smaller = true := by decide
def e605591117038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))))
theorem wire_e605591117038 : Closed e605591117038 ∧ code e605591117038 = 2804614372590 := by decide
theorem cert_e605591117038 : check e605591117038 [[],[]] .smaller = true := by decide
def e605591117046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))))
theorem wire_e605591117046 : Closed e605591117046 ∧ code e605591117046 = 2804614372598 := by decide
theorem cert_e605591117046 : check e605591117046 [[],[]] .smaller = true := by decide
def e605591117050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.var 0)))))))))
theorem wire_e605591117050 : Closed e605591117050 ∧ code e605591117050 = 2804614372602 := by decide
theorem cert_e605591117050 : check e605591117050 [[],[]] .smaller = true := by decide
def e605591117430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))))
theorem wire_e605591117430 : Closed e605591117430 ∧ code e605591117430 = 2804614372982 := by decide
theorem cert_e605591117430 : check e605591117430 [[],[]] .smaller = true := by decide
def e605591117622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.var 1)))))))))
theorem wire_e605591117622 : Closed e605591117622 ∧ code e605591117622 = 2804614373174 := by decide
theorem cert_e605591117622 : check e605591117622 [[],[]] .smaller = true := by decide
def e605591117626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.var 0)))))))))
theorem wire_e605591117626 : Closed e605591117626 ∧ code e605591117626 = 2804614373178 := by decide
theorem cert_e605591117626 : check e605591117626 [[],[]] .smaller = true := by decide
def e605591121262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))))
theorem wire_e605591121262 : Closed e605591121262 ∧ code e605591121262 = 2804614376814 := by decide
theorem cert_e605591121262 : check e605591121262 [[],[]] .smaller = true := by decide
def e605591121270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))))
theorem wire_e605591121270 : Closed e605591121270 ∧ code e605591121270 = 2804614376822 := by decide
theorem cert_e605591121270 : check e605591121270 [[],[]] .smaller = true := by decide
def e605591121326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))))
theorem wire_e605591121326 : Closed e605591121326 ∧ code e605591121326 = 2804614376878 := by decide
theorem cert_e605591121326 : check e605591121326 [[],[]] .smaller = true := by decide
def e605591121338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))))
theorem wire_e605591121338 : Closed e605591121338 ∧ code e605591121338 = 2804614376890 := by decide
theorem cert_e605591121338 : check e605591121338 [[],[]] .smaller = true := by decide
def e605591121366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))))
theorem wire_e605591121366 : Closed e605591121366 ∧ code e605591121366 = 2804614376918 := by decide
theorem cert_e605591121366 : check e605591121366 [[],[]] .smaller = true := by decide
def e605591121370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))))
theorem wire_e605591121370 : Closed e605591121370 ∧ code e605591121370 = 2804614376922 := by decide
theorem cert_e605591121370 : check e605591121370 [[],[]] .smaller = true := by decide
def e605591121582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e605591121582 : Closed e605591121582 ∧ code e605591121582 = 2804614377134 := by decide
theorem cert_e605591121582 : check e605591121582 [[],[]] .smaller = true := by decide
def e605591121594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e605591121594 : Closed e605591121594 ∧ code e605591121594 = 2804614377146 := by decide
theorem cert_e605591121594 : check e605591121594 [[],[]] .smaller = true := by decide
def e605591121642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e605591121642 : Closed e605591121642 ∧ code e605591121642 = 2804614377194 := by decide
theorem cert_e605591121642 : check e605591121642 [[],[]] .smaller = true := by decide
def e605591121750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e605591121750 : Closed e605591121750 ∧ code e605591121750 = 2804614377302 := by decide
theorem cert_e605591121750 : check e605591121750 [[],[]] .smaller = true := by decide
def e605591121754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e605591121754 : Closed e605591121754 ∧ code e605591121754 = 2804614377306 := by decide
theorem cert_e605591121754 : check e605591121754 [[],[]] .smaller = true := by decide
def e605591121770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e605591121770 : Closed e605591121770 ∧ code e605591121770 = 2804614377322 := by decide
theorem cert_e605591121770 : check e605591121770 [[],[]] .smaller = true := by decide
def e605591122398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 3))))))))
theorem wire_e605591122398 : Closed e605591122398 ∧ code e605591122398 = 2804614377950 := by decide
theorem cert_e605591122398 : check e605591122398 [[],[]] .smaller = true := by decide
def e605591122422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.var 1))))))))
theorem wire_e605591122422 : Closed e605591122422 ∧ code e605591122422 = 2804614377974 := by decide
theorem cert_e605591122422 : check e605591122422 [[],[]] .smaller = true := by decide
def e605591122798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e605591122798 : Closed e605591122798 ∧ code e605591122798 = 2804614378350 := by decide
theorem cert_e605591122798 : check e605591122798 [[],[]] .smaller = true := by decide
def e605591122806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))))
theorem wire_e605591122806 : Closed e605591122806 ∧ code e605591122806 = 2804614378358 := by decide
theorem cert_e605591122806 : check e605591122806 [[],[]] .smaller = true := by decide
def e605591122862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e605591122862 : Closed e605591122862 ∧ code e605591122862 = 2804614378414 := by decide
theorem cert_e605591122862 : check e605591122862 [[],[]] .smaller = true := by decide
def e605591122874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e605591122874 : Closed e605591122874 ∧ code e605591122874 = 2804614378426 := by decide
theorem cert_e605591122874 : check e605591122874 [[],[]] .smaller = true := by decide
def e605591122902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))))
theorem wire_e605591122902 : Closed e605591122902 ∧ code e605591122902 = 2804614378454 := by decide
theorem cert_e605591122902 : check e605591122902 [[],[]] .smaller = true := by decide
def e605591122906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e605591122906 : Closed e605591122906 ∧ code e605591122906 = 2804614378458 := by decide
theorem cert_e605591122906 : check e605591122906 [[],[]] .smaller = true := by decide
def e605591123182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e605591123182 : Closed e605591123182 ∧ code e605591123182 = 2804614378734 := by decide
theorem cert_e605591123182 : check e605591123182 [[],[]] .smaller = true := by decide
def e605591123190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e605591123190 : Closed e605591123190 ∧ code e605591123190 = 2804614378742 := by decide
theorem cert_e605591123190 : check e605591123190 [[],[]] .smaller = true := by decide
def e605591123518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 4)))))))))
theorem wire_e605591123518 : Closed e605591123518 ∧ code e605591123518 = 2804614379070 := by decide
theorem cert_e605591123518 : check e605591123518 [[],[]] .smaller = true := by decide
def e605591123566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e605591123566 : Closed e605591123566 ∧ code e605591123566 = 2804614379118 := by decide
theorem cert_e605591123566 : check e605591123566 [[],[]] .smaller = true := by decide
def e605591123578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e605591123578 : Closed e605591123578 ∧ code e605591123578 = 2804614379130 := by decide
theorem cert_e605591123578 : check e605591123578 [[],[]] .smaller = true := by decide
def e605591123766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e605591123766 : Closed e605591123766 ∧ code e605591123766 = 2804614379318 := by decide
theorem cert_e605591123766 : check e605591123766 [[],[]] .smaller = true := by decide
def e605591123770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e605591123770 : Closed e605591123770 ∧ code e605591123770 = 2804614379322 := by decide
theorem cert_e605591123770 : check e605591123770 [[],[]] .smaller = true := by decide
def e605591123854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 2)))))))))
theorem wire_e605591123854 : Closed e605591123854 ∧ code e605591123854 = 2804614379406 := by decide
theorem cert_e605591123854 : check e605591123854 [[],[]] .smaller = true := by decide
def e605591123902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 4))))))))
theorem wire_e605591123902 : Closed e605591123902 ∧ code e605591123902 = 2804614379454 := by decide
theorem cert_e605591123902 : check e605591123902 [[],[]] .three = true := by decide
def e605591123934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 3))))))))
theorem wire_e605591123934 : Closed e605591123934 ∧ code e605591123934 = 2804614379486 := by decide
theorem cert_e605591123934 : check e605591123934 [[],[]] .three = true := by decide
def e605591124190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 3))))))))
theorem wire_e605591124190 : Closed e605591124190 ∧ code e605591124190 = 2804614379742 := by decide
theorem cert_e605591124190 : check e605591124190 [[],[]] .smaller = true := by decide
def e605591124206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e605591124206 : Closed e605591124206 ∧ code e605591124206 = 2804614379758 := by decide
theorem cert_e605591124206 : check e605591124206 [[],[]] .smaller = true := by decide
def e605591124214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e605591124214 : Closed e605591124214 ∧ code e605591124214 = 2804614379766 := by decide
theorem cert_e605591124214 : check e605591124214 [[],[]] .smaller = true := by decide
def e605591124218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.var 0))))))))
theorem wire_e605591124218 : Closed e605591124218 ∧ code e605591124218 = 2804614379770 := by decide
theorem cert_e605591124218 : check e605591124218 [[],[]] .smaller = true := by decide
def e605591124398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e605591124398 : Closed e605591124398 ∧ code e605591124398 = 2804614379950 := by decide
theorem cert_e605591124398 : check e605591124398 [[],[]] .smaller = true := by decide
def e605591124410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e605591124410 : Closed e605591124410 ∧ code e605591124410 = 2804614379962 := by decide
theorem cert_e605591124410 : check e605591124410 [[],[]] .smaller = true := by decide
def e605591124458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e605591124458 : Closed e605591124458 ∧ code e605591124458 = 2804614380010 := by decide
theorem cert_e605591124458 : check e605591124458 [[],[]] .smaller = true := by decide
def e605591124542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 4)))))))))
theorem wire_e605591124542 : Closed e605591124542 ∧ code e605591124542 = 2804614380094 := by decide
theorem cert_e605591124542 : check e605591124542 [[],[]] .smaller = true := by decide
def e605591124590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e605591124590 : Closed e605591124590 ∧ code e605591124590 = 2804614380142 := by decide
theorem cert_e605591124590 : check e605591124590 [[],[]] .smaller = true := by decide
def e605591124602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e605591124602 : Closed e605591124602 ∧ code e605591124602 = 2804614380154 := by decide
theorem cert_e605591124602 : check e605591124602 [[],[]] .smaller = true := by decide
def e605591124766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e605591124766 : Closed e605591124766 ∧ code e605591124766 = 2804614380318 := by decide
theorem cert_e605591124766 : check e605591124766 [[],[]] .smaller = true := by decide
def e605591124878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e605591124878 : Closed e605591124878 ∧ code e605591124878 = 2804614380430 := by decide
theorem cert_e605591124878 : check e605591124878 [[],[]] .smaller = true := by decide
def e605591124890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591124890 : Closed e605591124890 ∧ code e605591124890 = 2804614380442 := by decide
theorem cert_e605591124890 : check e605591124890 [[],[]] .smaller = true := by decide
def e605591124934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 1)))))))))
theorem wire_e605591124934 : Closed e605591124934 ∧ code e605591124934 = 2804614380486 := by decide
theorem cert_e605591124934 : check e605591124934 [[],[]] .smaller = true := by decide
def e605591124958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 3))))))))
theorem wire_e605591124958 : Closed e605591124958 ∧ code e605591124958 = 2804614380510 := by decide
theorem cert_e605591124958 : check e605591124958 [[],[]] .smaller = true := by decide
def e605591125110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e605591125110 : Closed e605591125110 ∧ code e605591125110 = 2804614380662 := by decide
theorem cert_e605591125110 : check e605591125110 [[],[]] .smaller = true := by decide
def e605591125206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e605591125206 : Closed e605591125206 ∧ code e605591125206 = 2804614380758 := by decide
theorem cert_e605591125206 : check e605591125206 [[],[]] .smaller = true := by decide
def e605591125210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e605591125210 : Closed e605591125210 ∧ code e605591125210 = 2804614380762 := by decide
theorem cert_e605591125210 : check e605591125210 [[],[]] .smaller = true := by decide
def e605591125226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e605591125226 : Closed e605591125226 ∧ code e605591125226 = 2804614380778 := by decide
theorem cert_e605591125226 : check e605591125226 [[],[]] .smaller = true := by decide
def e605591125302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e605591125302 : Closed e605591125302 ∧ code e605591125302 = 2804614380854 := by decide
theorem cert_e605591125302 : check e605591125302 [[],[]] .smaller = true := by decide
def e605591125306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e605591125306 : Closed e605591125306 ∧ code e605591125306 = 2804614380858 := by decide
theorem cert_e605591125306 : check e605591125306 [[],[]] .smaller = true := by decide
def e605591125390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e605591125390 : Closed e605591125390 ∧ code e605591125390 = 2804614380942 := by decide
theorem cert_e605591125390 : check e605591125390 [[],[]] .smaller = true := by decide
def e605591125402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591125402 : Closed e605591125402 ∧ code e605591125402 = 2804614380954 := by decide
theorem cert_e605591125402 : check e605591125402 [[],[]] .smaller = true := by decide
def e605591125470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 3))))))))
theorem wire_e605591125470 : Closed e605591125470 ∧ code e605591125470 = 2804614381022 := by decide
theorem cert_e605591125470 : check e605591125470 [[],[]] .smaller = true := by decide
def e605591125486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 2))))))))
theorem wire_e605591125486 : Closed e605591125486 ∧ code e605591125486 = 2804614381038 := by decide
theorem cert_e605591125486 : check e605591125486 [[],[]] .smaller = true := by decide
def e605591125558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e605591125558 : Closed e605591125558 ∧ code e605591125558 = 2804614381110 := by decide
theorem cert_e605591125558 : check e605591125558 [[],[]] .smaller = true := by decide
def e605591125562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e605591125562 : Closed e605591125562 ∧ code e605591125562 = 2804614381114 := by decide
theorem cert_e605591125562 : check e605591125562 [[],[]] .smaller = true := by decide
def e605591125646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e605591125646 : Closed e605591125646 ∧ code e605591125646 = 2804614381198 := by decide
theorem cert_e605591125646 : check e605591125646 [[],[]] .smaller = true := by decide
def e605591125694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 4))))))))
theorem wire_e605591125694 : Closed e605591125694 ∧ code e605591125694 = 2804614381246 := by decide
theorem cert_e605591125694 : check e605591125694 [[],[]] .three = true := by decide
def e605591125702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e605591125702 : Closed e605591125702 ∧ code e605591125702 = 2804614381254 := by decide
theorem cert_e605591125702 : check e605591125702 [[],[]] .smaller = true := by decide
def e605591125726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 3))))))))
theorem wire_e605591125726 : Closed e605591125726 ∧ code e605591125726 = 2804614381278 := by decide
theorem cert_e605591125726 : check e605591125726 [[],[]] .smaller = true := by decide
def e605591125742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 2))))))))
theorem wire_e605591125742 : Closed e605591125742 ∧ code e605591125742 = 2804614381294 := by decide
theorem cert_e605591125742 : check e605591125742 [[],[]] .smaller = true := by decide
def e605591125750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 1))))))))
theorem wire_e605591125750 : Closed e605591125750 ∧ code e605591125750 = 2804614381302 := by decide
theorem cert_e605591125750 : check e605591125750 [[],[]] .smaller = true := by decide
def e605591125754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 4))) (.var 0))))))))
theorem wire_e605591125754 : Closed e605591125754 ∧ code e605591125754 = 2804614381306 := by decide
theorem cert_e605591125754 : check e605591125754 [[],[]] .three = true := by decide
def e605591125854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 3))))))))
theorem wire_e605591125854 : Closed e605591125854 ∧ code e605591125854 = 2804614381406 := by decide
theorem cert_e605591125854 : check e605591125854 [[],[]] .three = true := by decide
def e605591125882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 3))) (.var 0))))))))
theorem wire_e605591125882 : Closed e605591125882 ∧ code e605591125882 = 2804614381434 := by decide
theorem cert_e605591125882 : check e605591125882 [[],[]] .three = true := by decide
def e605591127006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e605591127006 : Closed e605591127006 ∧ code e605591127006 = 2804614382558 := by decide
theorem cert_e605591127006 : check e605591127006 [[],[]] .smaller = true := by decide
def e605591127022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e605591127022 : Closed e605591127022 ∧ code e605591127022 = 2804614382574 := by decide
theorem cert_e605591127022 : check e605591127022 [[],[]] .smaller = true := by decide
def e605591128942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605591128942 : Closed e605591128942 ∧ code e605591128942 = 2804614384494 := by decide
theorem cert_e605591128942 : check e605591128942 [[],[]] .smaller = true := by decide
def e605591128950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605591128950 : Closed e605591128950 ∧ code e605591128950 = 2804614384502 := by decide
theorem cert_e605591128950 : check e605591128950 [[],[]] .smaller = true := by decide
def e605591129006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605591129006 : Closed e605591129006 ∧ code e605591129006 = 2804614384558 := by decide
theorem cert_e605591129006 : check e605591129006 [[],[]] .smaller = true := by decide
def e605591129018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605591129018 : Closed e605591129018 ∧ code e605591129018 = 2804614384570 := by decide
theorem cert_e605591129018 : check e605591129018 [[],[]] .smaller = true := by decide
def e605591129046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605591129046 : Closed e605591129046 ∧ code e605591129046 = 2804614384598 := by decide
theorem cert_e605591129046 : check e605591129046 [[],[]] .smaller = true := by decide
def e605591129050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605591129050 : Closed e605591129050 ∧ code e605591129050 = 2804614384602 := by decide
theorem cert_e605591129050 : check e605591129050 [[],[]] .smaller = true := by decide
def e605591129326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605591129326 : Closed e605591129326 ∧ code e605591129326 = 2804614384878 := by decide
theorem cert_e605591129326 : check e605591129326 [[],[]] .smaller = true := by decide
def e605591129334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605591129334 : Closed e605591129334 ∧ code e605591129334 = 2804614384886 := by decide
theorem cert_e605591129334 : check e605591129334 [[],[]] .smaller = true := by decide
def e605591129662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e605591129662 : Closed e605591129662 ∧ code e605591129662 = 2804614385214 := by decide
theorem cert_e605591129662 : check e605591129662 [[],[]] .smaller = true := by decide
def e605591129710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605591129710 : Closed e605591129710 ∧ code e605591129710 = 2804614385262 := by decide
theorem cert_e605591129710 : check e605591129710 [[],[]] .smaller = true := by decide
def e605591129722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605591129722 : Closed e605591129722 ∧ code e605591129722 = 2804614385274 := by decide
theorem cert_e605591129722 : check e605591129722 [[],[]] .smaller = true := by decide
def e605591129910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605591129910 : Closed e605591129910 ∧ code e605591129910 = 2804614385462 := by decide
theorem cert_e605591129910 : check e605591129910 [[],[]] .smaller = true := by decide
def e605591129914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605591129914 : Closed e605591129914 ∧ code e605591129914 = 2804614385466 := by decide
theorem cert_e605591129914 : check e605591129914 [[],[]] .smaller = true := by decide
def e605591129998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e605591129998 : Closed e605591129998 ∧ code e605591129998 = 2804614385550 := by decide
theorem cert_e605591129998 : check e605591129998 [[],[]] .smaller = true := by decide
def e605591130046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 4)))))))))
theorem wire_e605591130046 : Closed e605591130046 ∧ code e605591130046 = 2804614385598 := by decide
theorem cert_e605591130046 : check e605591130046 [[],[]] .three = true := by decide
def e605591130078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 3)))))))))
theorem wire_e605591130078 : Closed e605591130078 ∧ code e605591130078 = 2804614385630 := by decide
theorem cert_e605591130078 : check e605591130078 [[],[]] .three = true := by decide
def e605591134686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605591134686 : Closed e605591134686 ∧ code e605591134686 = 2804614390238 := by decide
theorem cert_e605591134686 : check e605591134686 [[],[]] .smaller = true := by decide
def e605591134710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605591134710 : Closed e605591134710 ∧ code e605591134710 = 2804614390262 := by decide
theorem cert_e605591134710 : check e605591134710 [[],[]] .smaller = true := by decide
def e605591135662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605591135662 : Closed e605591135662 ∧ code e605591135662 = 2804614391214 := by decide
theorem cert_e605591135662 : check e605591135662 [[],[]] .smaller = true := by decide
def e605591135674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605591135674 : Closed e605591135674 ∧ code e605591135674 = 2804614391226 := by decide
theorem cert_e605591135674 : check e605591135674 [[],[]] .smaller = true := by decide
def e605591135722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605591135722 : Closed e605591135722 ∧ code e605591135722 = 2804614391274 := by decide
theorem cert_e605591135722 : check e605591135722 [[],[]] .smaller = true := by decide
def e605591135806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e605591135806 : Closed e605591135806 ∧ code e605591135806 = 2804614391358 := by decide
theorem cert_e605591135806 : check e605591135806 [[],[]] .smaller = true := by decide
def e605591135854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605591135854 : Closed e605591135854 ∧ code e605591135854 = 2804614391406 := by decide
theorem cert_e605591135854 : check e605591135854 [[],[]] .smaller = true := by decide
def e605591135866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605591135866 : Closed e605591135866 ∧ code e605591135866 = 2804614391418 := by decide
theorem cert_e605591135866 : check e605591135866 [[],[]] .smaller = true := by decide
def e605591136030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605591136030 : Closed e605591136030 ∧ code e605591136030 = 2804614391582 := by decide
theorem cert_e605591136030 : check e605591136030 [[],[]] .smaller = true := by decide
def e605591136142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605591136142 : Closed e605591136142 ∧ code e605591136142 = 2804614391694 := by decide
theorem cert_e605591136142 : check e605591136142 [[],[]] .smaller = true := by decide
def e605591136154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591136154 : Closed e605591136154 ∧ code e605591136154 = 2804614391706 := by decide
theorem cert_e605591136154 : check e605591136154 [[],[]] .smaller = true := by decide
def e605591136198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e605591136198 : Closed e605591136198 ∧ code e605591136198 = 2804614391750 := by decide
theorem cert_e605591136198 : check e605591136198 [[],[]] .smaller = true := by decide
def e605591136222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 3)))))))))
theorem wire_e605591136222 : Closed e605591136222 ∧ code e605591136222 = 2804614391774 := by decide
theorem cert_e605591136222 : check e605591136222 [[],[]] .smaller = true := by decide
def e605591138542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605591138542 : Closed e605591138542 ∧ code e605591138542 = 2804614394094 := by decide
theorem cert_e605591138542 : check e605591138542 [[],[]] .smaller = true := by decide
def e605591138550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605591138550 : Closed e605591138550 ∧ code e605591138550 = 2804614394102 := by decide
theorem cert_e605591138550 : check e605591138550 [[],[]] .smaller = true := by decide
def e605591139030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605591139030 : Closed e605591139030 ∧ code e605591139030 = 2804614394582 := by decide
theorem cert_e605591139030 : check e605591139030 [[],[]] .smaller = true := by decide
def e605591139034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605591139034 : Closed e605591139034 ∧ code e605591139034 = 2804614394586 := by decide
theorem cert_e605591139034 : check e605591139034 [[],[]] .smaller = true := by decide
def e605591139050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605591139050 : Closed e605591139050 ∧ code e605591139050 = 2804614394602 := by decide
theorem cert_e605591139050 : check e605591139050 [[],[]] .smaller = true := by decide
def e605591139126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605591139126 : Closed e605591139126 ∧ code e605591139126 = 2804614394678 := by decide
theorem cert_e605591139126 : check e605591139126 [[],[]] .smaller = true := by decide
def e605591139130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605591139130 : Closed e605591139130 ∧ code e605591139130 = 2804614394682 := by decide
theorem cert_e605591139130 : check e605591139130 [[],[]] .smaller = true := by decide
def e605591139214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e605591139214 : Closed e605591139214 ∧ code e605591139214 = 2804614394766 := by decide
theorem cert_e605591139214 : check e605591139214 [[],[]] .smaller = true := by decide
def e605591139226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605591139226 : Closed e605591139226 ∧ code e605591139226 = 2804614394778 := by decide
theorem cert_e605591139226 : check e605591139226 [[],[]] .smaller = true := by decide
def e605591139294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 3)))))))))
theorem wire_e605591139294 : Closed e605591139294 ∧ code e605591139294 = 2804614394846 := by decide
theorem cert_e605591139294 : check e605591139294 [[],[]] .smaller = true := by decide
def e605591139310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 2)))))))))
theorem wire_e605591139310 : Closed e605591139310 ∧ code e605591139310 = 2804614394862 := by decide
theorem cert_e605591139310 : check e605591139310 [[],[]] .smaller = true := by decide
def e605591140750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605591140750 : Closed e605591140750 ∧ code e605591140750 = 2804614396302 := by decide
theorem cert_e605591140750 : check e605591140750 [[],[]] .smaller = true := by decide
def e605591140798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 4)))))))))
theorem wire_e605591140798 : Closed e605591140798 ∧ code e605591140798 = 2804614396350 := by decide
theorem cert_e605591140798 : check e605591140798 [[],[]] .three = true := by decide
def e605591140806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605591140806 : Closed e605591140806 ∧ code e605591140806 = 2804614396358 := by decide
theorem cert_e605591140806 : check e605591140806 [[],[]] .smaller = true := by decide
def e605591140830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605591140830 : Closed e605591140830 ∧ code e605591140830 = 2804614396382 := by decide
theorem cert_e605591140830 : check e605591140830 [[],[]] .smaller = true := by decide
def e605591140846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 2)))))))))
theorem wire_e605591140846 : Closed e605591140846 ∧ code e605591140846 = 2804614396398 := by decide
theorem cert_e605591140846 : check e605591140846 [[],[]] .smaller = true := by decide
def e605591140854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605591140854 : Closed e605591140854 ∧ code e605591140854 = 2804614396406 := by decide
theorem cert_e605591140854 : check e605591140854 [[],[]] .smaller = true := by decide
def e605591140858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 4) (.var 0)))))))))
theorem wire_e605591140858 : Closed e605591140858 ∧ code e605591140858 = 2804614396410 := by decide
theorem cert_e605591140858 : check e605591140858 [[],[]] .three = true := by decide
def e605591141598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605591141598 : Closed e605591141598 ∧ code e605591141598 = 2804614397150 := by decide
theorem cert_e605591141598 : check e605591141598 [[],[]] .three = true := by decide
def e605591141626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605591141626 : Closed e605591141626 ∧ code e605591141626 = 2804614397178 := by decide
theorem cert_e605591141626 : check e605591141626 [[],[]] .three = true := by decide
def e605591144302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))))
theorem wire_e605591144302 : Closed e605591144302 ∧ code e605591144302 = 2804614399854 := by decide
theorem cert_e605591144302 : check e605591144302 [[],[]] .smaller = true := by decide
def e605591144314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))))
theorem wire_e605591144314 : Closed e605591144314 ∧ code e605591144314 = 2804614399866 := by decide
theorem cert_e605591144314 : check e605591144314 [[],[]] .smaller = true := by decide
def e605591144410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))))
theorem wire_e605591144410 : Closed e605591144410 ∧ code e605591144410 = 2804614399962 := by decide
theorem cert_e605591144410 : check e605591144410 [[],[]] .smaller = true := by decide
def e605591145694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 3)))))))))
theorem wire_e605591145694 : Closed e605591145694 ∧ code e605591145694 = 2804614401246 := by decide
theorem cert_e605591145694 : check e605591145694 [[],[]] .smaller = true := by decide
def e605591145710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e605591145710 : Closed e605591145710 ∧ code e605591145710 = 2804614401262 := by decide
theorem cert_e605591145710 : check e605591145710 [[],[]] .smaller = true := by decide
def e605591145718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e605591145718 : Closed e605591145718 ∧ code e605591145718 = 2804614401270 := by decide
theorem cert_e605591145718 : check e605591145718 [[],[]] .smaller = true := by decide
def e605591145722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.var 0)))))))))
theorem wire_e605591145722 : Closed e605591145722 ∧ code e605591145722 = 2804614401274 := by decide
theorem cert_e605591145722 : check e605591145722 [[],[]] .smaller = true := by decide
def e605591146094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e605591146094 : Closed e605591146094 ∧ code e605591146094 = 2804614401646 := by decide
theorem cert_e605591146094 : check e605591146094 [[],[]] .smaller = true := by decide
def e605591146106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e605591146106 : Closed e605591146106 ∧ code e605591146106 = 2804614401658 := by decide
theorem cert_e605591146106 : check e605591146106 [[],[]] .smaller = true := by decide
def e605591146294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e605591146294 : Closed e605591146294 ∧ code e605591146294 = 2804614401846 := by decide
theorem cert_e605591146294 : check e605591146294 [[],[]] .smaller = true := by decide
def e605591146298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e605591146298 : Closed e605591146298 ∧ code e605591146298 = 2804614401850 := by decide
theorem cert_e605591146298 : check e605591146298 [[],[]] .smaller = true := by decide
def e605591146394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591146394 : Closed e605591146394 ∧ code e605591146394 = 2804614401946 := by decide
theorem cert_e605591146394 : check e605591146394 [[],[]] .smaller = true := by decide
def e605591148206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e605591148206 : Closed e605591148206 ∧ code e605591148206 = 2804614403758 := by decide
theorem cert_e605591148206 : check e605591148206 [[],[]] .smaller = true := by decide
def e605591148218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e605591148218 : Closed e605591148218 ∧ code e605591148218 = 2804614403770 := by decide
theorem cert_e605591148218 : check e605591148218 [[],[]] .smaller = true := by decide
end Blc.Floor41
