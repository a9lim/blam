import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605601983726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605601983726 : Closed e605601983726 ∧ code e605601983726 = 2804625239278 := by decide
theorem cert_e605601983726 : check e605601983726 [[],[]] .chain = true := by decide
def e605601983734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605601983734 : Closed e605601983734 ∧ code e605601983734 = 2804625239286 := by decide
theorem cert_e605601983734 : check e605601983734 [[],[]] .chain = true := by decide
def e605601984110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605601984110 : Closed e605601984110 ∧ code e605601984110 = 2804625239662 := by decide
theorem cert_e605601984110 : check e605601984110 [[],[]] .chain = true := by decide
def e605601984122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605601984122 : Closed e605601984122 ∧ code e605601984122 = 2804625239674 := by decide
theorem cert_e605601984122 : check e605601984122 [[],[]] .chain = true := by decide
def e605601984310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601984310 : Closed e605601984310 ∧ code e605601984310 = 2804625239862 := by decide
theorem cert_e605601984310 : check e605601984310 [[],[]] .chain = true := by decide
def e605601984314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601984314 : Closed e605601984314 ∧ code e605601984314 = 2804625239866 := by decide
theorem cert_e605601984314 : check e605601984314 [[],[]] .chain = true := by decide
def e605601985006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 3))))) (.var 2))))))
theorem wire_e605601985006 : Closed e605601985006 ∧ code e605601985006 = 2804625240558 := by decide
theorem cert_e605601985006 : check e605601985006 [[],[]] .chain = true := by decide
def e605601985014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))) (.var 1))))))
theorem wire_e605601985014 : Closed e605601985014 ∧ code e605601985014 = 2804625240566 := by decide
theorem cert_e605601985014 : check e605601985014 [[],[]] .chain = true := by decide
def e605601985378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 0)))))))
theorem wire_e605601985378 : Closed e605601985378 ∧ code e605601985378 = 2804625240930 := by decide
theorem cert_e605601985378 : check e605601985378 [[],[]] .smaller = true := by decide
def e605601985390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e605601985390 : Closed e605601985390 ∧ code e605601985390 = 2804625240942 := by decide
theorem cert_e605601985390 : check e605601985390 [[],[]] .chain = true := by decide
def e605601985402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e605601985402 : Closed e605601985402 ∧ code e605601985402 = 2804625240954 := by decide
theorem cert_e605601985402 : check e605601985402 [[],[]] .chain = true := by decide
def e605601985442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e605601985442 : Closed e605601985442 ∧ code e605601985442 = 2804625240994 := by decide
theorem cert_e605601985442 : check e605601985442 [[],[]] .smaller = true := by decide
def e605601985454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e605601985454 : Closed e605601985454 ∧ code e605601985454 = 2804625241006 := by decide
theorem cert_e605601985454 : check e605601985454 [[],[]] .chain = true := by decide
def e605601985514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e605601985514 : Closed e605601985514 ∧ code e605601985514 = 2804625241066 := by decide
theorem cert_e605601985514 : check e605601985514 [[],[]] .chain = true := by decide
def e605601985774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e605601985774 : Closed e605601985774 ∧ code e605601985774 = 2804625241326 := by decide
theorem cert_e605601985774 : check e605601985774 [[],[]] .chain = true := by decide
def e605601985782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e605601985782 : Closed e605601985782 ∧ code e605601985782 = 2804625241334 := by decide
theorem cert_e605601985782 : check e605601985782 [[],[]] .chain = true := by decide
def e605601986158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605601986158 : Closed e605601986158 ∧ code e605601986158 = 2804625241710 := by decide
theorem cert_e605601986158 : check e605601986158 [[],[]] .chain = true := by decide
def e605601986170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605601986170 : Closed e605601986170 ∧ code e605601986170 = 2804625241722 := by decide
theorem cert_e605601986170 : check e605601986170 [[],[]] .chain = true := by decide
def e605601986334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.lam (.var 3)))))))
theorem wire_e605601986334 : Closed e605601986334 ∧ code e605601986334 = 2804625241886 := by decide
theorem cert_e605601986334 : check e605601986334 [[],[]] .chain = true := by decide
def e605601986446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.lam (.var 2)))))))
theorem wire_e605601986446 : Closed e605601986446 ∧ code e605601986446 = 2804625241998 := by decide
theorem cert_e605601986446 : check e605601986446 [[],[]] .chain = true := by decide
def e605601986458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601986458 : Closed e605601986458 ∧ code e605601986458 = 2804625242010 := by decide
theorem cert_e605601986458 : check e605601986458 [[],[]] .chain = true := by decide
def e605601986806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))) (.var 1))))))
theorem wire_e605601986806 : Closed e605601986806 ∧ code e605601986806 = 2804625242358 := by decide
theorem cert_e605601986806 : check e605601986806 [[],[]] .chain = true := by decide
def e605601986998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e605601986998 : Closed e605601986998 ∧ code e605601986998 = 2804625242550 := by decide
theorem cert_e605601986998 : check e605601986998 [[],[]] .chain = true := by decide
def e605601987002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e605601987002 : Closed e605601987002 ∧ code e605601987002 = 2804625242554 := by decide
theorem cert_e605601987002 : check e605601987002 [[],[]] .chain = true := by decide
def e605601987030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e605601987030 : Closed e605601987030 ∧ code e605601987030 = 2804625242582 := by decide
theorem cert_e605601987030 : check e605601987030 [[],[]] .chain = true := by decide
def e605601987050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e605601987050 : Closed e605601987050 ∧ code e605601987050 = 2804625242602 := by decide
theorem cert_e605601987050 : check e605601987050 [[],[]] .chain = true := by decide
def e605601987190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 1)))))))
theorem wire_e605601987190 : Closed e605601987190 ∧ code e605601987190 = 2804625242742 := by decide
theorem cert_e605601987190 : check e605601987190 [[],[]] .chain = true := by decide
def e605601987382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601987382 : Closed e605601987382 ∧ code e605601987382 = 2804625242934 := by decide
theorem cert_e605601987382 : check e605601987382 [[],[]] .chain = true := by decide
def e605601987386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601987386 : Closed e605601987386 ∧ code e605601987386 = 2804625242938 := by decide
theorem cert_e605601987386 : check e605601987386 [[],[]] .chain = true := by decide
def e605601987470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e605601987470 : Closed e605601987470 ∧ code e605601987470 = 2804625243022 := by decide
theorem cert_e605601987470 : check e605601987470 [[],[]] .chain = true := by decide
def e605601987482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e605601987482 : Closed e605601987482 ∧ code e605601987482 = 2804625243034 := by decide
theorem cert_e605601987482 : check e605601987482 [[],[]] .chain = true := by decide
def e605601991534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605601991534 : Closed e605601991534 ∧ code e605601991534 = 2804625247086 := by decide
theorem cert_e605601991534 : check e605601991534 [[],[]] .smaller = true := by decide
def e605601991542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605601991542 : Closed e605601991542 ∧ code e605601991542 = 2804625247094 := by decide
theorem cert_e605601991542 : check e605601991542 [[],[]] .smaller = true := by decide
def e605601991598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605601991598 : Closed e605601991598 ∧ code e605601991598 = 2804625247150 := by decide
theorem cert_e605601991598 : check e605601991598 [[],[]] .smaller = true := by decide
def e605601991610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605601991610 : Closed e605601991610 ∧ code e605601991610 = 2804625247162 := by decide
theorem cert_e605601991610 : check e605601991610 [[],[]] .smaller = true := by decide
def e605601991638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605601991638 : Closed e605601991638 ∧ code e605601991638 = 2804625247190 := by decide
theorem cert_e605601991638 : check e605601991638 [[],[]] .smaller = true := by decide
def e605601991642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605601991642 : Closed e605601991642 ∧ code e605601991642 = 2804625247194 := by decide
theorem cert_e605601991642 : check e605601991642 [[],[]] .smaller = true := by decide
def e605601991918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605601991918 : Closed e605601991918 ∧ code e605601991918 = 2804625247470 := by decide
theorem cert_e605601991918 : check e605601991918 [[],[]] .smaller = true := by decide
def e605601991926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605601991926 : Closed e605601991926 ∧ code e605601991926 = 2804625247478 := by decide
theorem cert_e605601991926 : check e605601991926 [[],[]] .smaller = true := by decide
def e605601992302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605601992302 : Closed e605601992302 ∧ code e605601992302 = 2804625247854 := by decide
theorem cert_e605601992302 : check e605601992302 [[],[]] .smaller = true := by decide
def e605601992314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605601992314 : Closed e605601992314 ∧ code e605601992314 = 2804625247866 := by decide
theorem cert_e605601992314 : check e605601992314 [[],[]] .smaller = true := by decide
def e605601992502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605601992502 : Closed e605601992502 ∧ code e605601992502 = 2804625248054 := by decide
theorem cert_e605601992502 : check e605601992502 [[],[]] .smaller = true := by decide
def e605601992506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605601992506 : Closed e605601992506 ∧ code e605601992506 = 2804625248058 := by decide
theorem cert_e605601992506 : check e605601992506 [[],[]] .smaller = true := by decide
def e605602000622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e605602000622 : Closed e605602000622 ∧ code e605602000622 = 2804625256174 := by decide
theorem cert_e605602000622 : check e605602000622 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602000750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e605602000750 : Closed e605602000750 ∧ code e605602000750 = 2804625256302 := by decide
theorem cert_e605602000750 : check e605602000750 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602000758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e605602000758 : Closed e605602000758 ∧ code e605602000758 = 2804625256310 := by decide
theorem cert_e605602000758 : check e605602000758 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602003438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e605602003438 : Closed e605602003438 ∧ code e605602003438 = 2804625258990 := by decide
theorem cert_e605602003438 : check e605602003438 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602004206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e605602004206 : Closed e605602004206 ∧ code e605602004206 = 2804625259758 := by decide
theorem cert_e605602004206 : check e605602004206 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602004214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e605602004214 : Closed e605602004214 ∧ code e605602004214 = 2804625259766 := by decide
theorem cert_e605602004214 : check e605602004214 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602027374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e605602027374 : Closed e605602027374 ∧ code e605602027374 = 2804625282926 := by decide
theorem cert_e605602027374 : check e605602027374 [[],[]] .chain = true := by decide
def e605602027382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e605602027382 : Closed e605602027382 ∧ code e605602027382 = 2804625282934 := by decide
theorem cert_e605602027382 : check e605602027382 [[],[]] .chain = true := by decide
def e605602027446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e605602027446 : Closed e605602027446 ∧ code e605602027446 = 2804625282998 := by decide
theorem cert_e605602027446 : check e605602027446 [[],[]] .chain = true := by decide
def e605602028782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e605602028782 : Closed e605602028782 ∧ code e605602028782 = 2804625284334 := by decide
theorem cert_e605602028782 : check e605602028782 [[],[]] .chain = true := by decide
def e605602028790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e605602028790 : Closed e605602028790 ∧ code e605602028790 = 2804625284342 := by decide
theorem cert_e605602028790 : check e605602028790 [[],[]] .chain = true := by decide
def e605602029174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e605602029174 : Closed e605602029174 ∧ code e605602029174 = 2804625284726 := by decide
theorem cert_e605602029174 : check e605602029174 [[],[]] .chain = true := by decide
def e605602038750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e605602038750 : Closed e605602038750 ∧ code e605602038750 = 2804625294302 := by decide
theorem cert_e605602038750 : check e605602038750 [[],[]] .chain = true := by decide
def e605602038766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e605602038766 : Closed e605602038766 ∧ code e605602038766 = 2804625294318 := by decide
theorem cert_e605602038766 : check e605602038766 [[],[]] .chain = true := by decide
def e605602040686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e605602040686 : Closed e605602040686 ∧ code e605602040686 = 2804625296238 := by decide
theorem cert_e605602040686 : check e605602040686 [[],[]] .chain = true := by decide
def e605602040694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e605602040694 : Closed e605602040694 ∧ code e605602040694 = 2804625296246 := by decide
theorem cert_e605602040694 : check e605602040694 [[],[]] .chain = true := by decide
def e605602040750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e605602040750 : Closed e605602040750 ∧ code e605602040750 = 2804625296302 := by decide
theorem cert_e605602040750 : check e605602040750 [[],[]] .chain = true := by decide
def e605602040762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e605602040762 : Closed e605602040762 ∧ code e605602040762 = 2804625296314 := by decide
theorem cert_e605602040762 : check e605602040762 [[],[]] .chain = true := by decide
def e605602040790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e605602040790 : Closed e605602040790 ∧ code e605602040790 = 2804625296342 := by decide
theorem cert_e605602040790 : check e605602040790 [[],[]] .chain = true := by decide
def e605602040794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e605602040794 : Closed e605602040794 ∧ code e605602040794 = 2804625296346 := by decide
theorem cert_e605602040794 : check e605602040794 [[],[]] .chain = true := by decide
def e605602041070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e605602041070 : Closed e605602041070 ∧ code e605602041070 = 2804625296622 := by decide
theorem cert_e605602041070 : check e605602041070 [[],[]] .chain = true := by decide
def e605602041078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e605602041078 : Closed e605602041078 ∧ code e605602041078 = 2804625296630 := by decide
theorem cert_e605602041078 : check e605602041078 [[],[]] .chain = true := by decide
def e605602041454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e605602041454 : Closed e605602041454 ∧ code e605602041454 = 2804625297006 := by decide
theorem cert_e605602041454 : check e605602041454 [[],[]] .chain = true := by decide
def e605602041466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e605602041466 : Closed e605602041466 ∧ code e605602041466 = 2804625297018 := by decide
theorem cert_e605602041466 : check e605602041466 [[],[]] .chain = true := by decide
def e605602041630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e605602041630 : Closed e605602041630 ∧ code e605602041630 = 2804625297182 := by decide
theorem cert_e605602041630 : checkPay e605602041630 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e605602041654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e605602041654 : Closed e605602041654 ∧ code e605602041654 = 2804625297206 := by decide
theorem cert_e605602041654 : check e605602041654 [[],[]] .chain = true := by decide
def e605602041658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e605602041658 : Closed e605602041658 ∧ code e605602041658 = 2804625297210 := by decide
theorem cert_e605602041658 : check e605602041658 [[],[]] .chain = true := by decide
def e605602046446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e605602046446 : Closed e605602046446 ∧ code e605602046446 = 2804625301998 := by decide
theorem cert_e605602046446 : check e605602046446 [[],[]] .chain = true := by decide
def e605602047414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e605602047414 : Closed e605602047414 ∧ code e605602047414 = 2804625302966 := by decide
theorem cert_e605602047414 : check e605602047414 [[],[]] .chain = true := by decide
def e605602047446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e605602047446 : Closed e605602047446 ∧ code e605602047446 = 2804625302998 := by decide
theorem cert_e605602047446 : check e605602047446 [[],[]] .chain = true := by decide
def e605602047450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e605602047450 : Closed e605602047450 ∧ code e605602047450 = 2804625303002 := by decide
theorem cert_e605602047450 : check e605602047450 [[],[]] .chain = true := by decide
def e605602047606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e605602047606 : Closed e605602047606 ∧ code e605602047606 = 2804625303158 := by decide
theorem cert_e605602047606 : check e605602047606 [[],[]] .chain = true := by decide
def e605602047774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e605602047774 : Closed e605602047774 ∧ code e605602047774 = 2804625303326 := by decide
theorem cert_e605602047774 : check e605602047774 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602047798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e605602047798 : Closed e605602047798 ∧ code e605602047798 = 2804625303350 := by decide
theorem cert_e605602047798 : check e605602047798 [[],[]] .chain = true := by decide
def e605602047802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e605602047802 : Closed e605602047802 ∧ code e605602047802 = 2804625303354 := by decide
theorem cert_e605602047802 : check e605602047802 [[],[]] .chain = true := by decide
def e605602047886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e605602047886 : Closed e605602047886 ∧ code e605602047886 = 2804625303438 := by decide
theorem cert_e605602047886 : check e605602047886 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e605602100590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e605602100590 : Closed e605602100590 ∧ code e605602100590 = 2804625356142 := by decide
theorem cert_e605602100590 : check e605602100590 [[],[]] .chain = true := by decide
def e605602100598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e605602100598 : Closed e605602100598 ∧ code e605602100598 = 2804625356150 := by decide
theorem cert_e605602100598 : check e605602100598 [[],[]] .chain = true := by decide
def e605602100654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e605602100654 : Closed e605602100654 ∧ code e605602100654 = 2804625356206 := by decide
theorem cert_e605602100654 : check e605602100654 [[],[]] .chain = true := by decide
def e605602100666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e605602100666 : Closed e605602100666 ∧ code e605602100666 = 2804625356218 := by decide
theorem cert_e605602100666 : check e605602100666 [[],[]] .chain = true := by decide
def e605602100694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e605602100694 : Closed e605602100694 ∧ code e605602100694 = 2804625356246 := by decide
theorem cert_e605602100694 : check e605602100694 [[],[]] .chain = true := by decide
def e605602100698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e605602100698 : Closed e605602100698 ∧ code e605602100698 = 2804625356250 := by decide
theorem cert_e605602100698 : check e605602100698 [[],[]] .chain = true := by decide
def e605602100910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e605602100910 : Closed e605602100910 ∧ code e605602100910 = 2804625356462 := by decide
theorem cert_e605602100910 : check e605602100910 [[],[]] .chain = true := by decide
def e605602100922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e605602100922 : Closed e605602100922 ∧ code e605602100922 = 2804625356474 := by decide
theorem cert_e605602100922 : check e605602100922 [[],[]] .chain = true := by decide
def e605602100970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e605602100970 : Closed e605602100970 ∧ code e605602100970 = 2804625356522 := by decide
theorem cert_e605602100970 : check e605602100970 [[],[]] .chain = true := by decide
def e605602101078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e605602101078 : Closed e605602101078 ∧ code e605602101078 = 2804625356630 := by decide
theorem cert_e605602101078 : check e605602101078 [[],[]] .chain = true := by decide
def e605602101082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e605602101082 : Closed e605602101082 ∧ code e605602101082 = 2804625356634 := by decide
theorem cert_e605602101082 : check e605602101082 [[],[]] .chain = true := by decide
def e605602101098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e605602101098 : Closed e605602101098 ∧ code e605602101098 = 2804625356650 := by decide
theorem cert_e605602101098 : check e605602101098 [[],[]] .chain = true := by decide
def e605602101934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e605602101934 : Closed e605602101934 ∧ code e605602101934 = 2804625357486 := by decide
theorem cert_e605602101934 : check e605602101934 [[],[]] .chain = true := by decide
def e605602101946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e605602101946 : Closed e605602101946 ∧ code e605602101946 = 2804625357498 := by decide
theorem cert_e605602101946 : check e605602101946 [[],[]] .chain = true := by decide
def e605602101994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e605602101994 : Closed e605602101994 ∧ code e605602101994 = 2804625357546 := by decide
theorem cert_e605602101994 : check e605602101994 [[],[]] .chain = true := by decide
def e605602102186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e605602102186 : Closed e605602102186 ∧ code e605602102186 = 2804625357738 := by decide
theorem cert_e605602102186 : check e605602102186 [[],[]] .chain = true := by decide
def e605602102614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e605602102614 : Closed e605602102614 ∧ code e605602102614 = 2804625358166 := by decide
theorem cert_e605602102614 : check e605602102614 [[],[]] .chain = true := by decide
def e605602102618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e605602102618 : Closed e605602102618 ∧ code e605602102618 = 2804625358170 := by decide
theorem cert_e605602102618 : check e605602102618 [[],[]] .chain = true := by decide
def e605602102634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e605602102634 : Closed e605602102634 ∧ code e605602102634 = 2804625358186 := by decide
theorem cert_e605602102634 : check e605602102634 [[],[]] .chain = true := by decide
def e605602102698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e605602102698 : Closed e605602102698 ∧ code e605602102698 = 2804625358250 := by decide
theorem cert_e605602102698 : check e605602102698 [[],[]] .chain = true := by decide
def e605602103662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))) (.var 2))))))
theorem wire_e605602103662 : Closed e605602103662 ∧ code e605602103662 = 2804625359214 := by decide
theorem cert_e605602103662 : check e605602103662 [[],[]] .chain = true := by decide
def e605602103670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))) (.var 1))))))
theorem wire_e605602103670 : Closed e605602103670 ∧ code e605602103670 = 2804625359222 := by decide
theorem cert_e605602103670 : check e605602103670 [[],[]] .chain = true := by decide
def e605602105198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))) (.var 2))))))
theorem wire_e605602105198 : Closed e605602105198 ∧ code e605602105198 = 2804625360750 := by decide
theorem cert_e605602105198 : check e605602105198 [[],[]] .chain = true := by decide
def e605602105206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))) (.var 1))))))
theorem wire_e605602105206 : Closed e605602105206 ∧ code e605602105206 = 2804625360758 := by decide
theorem cert_e605602105206 : check e605602105206 [[],[]] .chain = true := by decide
def e605602105270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))) (.var 1))))))
theorem wire_e605602105270 : Closed e605602105270 ∧ code e605602105270 = 2804625360822 := by decide
theorem cert_e605602105270 : check e605602105270 [[],[]] .chain = true := by decide
def e605602106734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e605602106734 : Closed e605602106734 ∧ code e605602106734 = 2804625362286 := by decide
theorem cert_e605602106734 : check e605602106734 [[],[]] .chain = true := by decide
def e605602106742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e605602106742 : Closed e605602106742 ∧ code e605602106742 = 2804625362294 := by decide
theorem cert_e605602106742 : check e605602106742 [[],[]] .chain = true := by decide
def e605602106798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e605602106798 : Closed e605602106798 ∧ code e605602106798 = 2804625362350 := by decide
theorem cert_e605602106798 : check e605602106798 [[],[]] .chain = true := by decide
def e605602106810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e605602106810 : Closed e605602106810 ∧ code e605602106810 = 2804625362362 := by decide
theorem cert_e605602106810 : check e605602106810 [[],[]] .chain = true := by decide
def e605602106838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))) (.var 1))))))
theorem wire_e605602106838 : Closed e605602106838 ∧ code e605602106838 = 2804625362390 := by decide
theorem cert_e605602106838 : check e605602106838 [[],[]] .chain = true := by decide
def e605602106842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.var 0))))))
theorem wire_e605602106842 : Closed e605602106842 ∧ code e605602106842 = 2804625362394 := by decide
theorem cert_e605602106842 : check e605602106842 [[],[]] .chain = true := by decide
def e605602107054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e605602107054 : Closed e605602107054 ∧ code e605602107054 = 2804625362606 := by decide
theorem cert_e605602107054 : check e605602107054 [[],[]] .chain = true := by decide
def e605602107066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e605602107066 : Closed e605602107066 ∧ code e605602107066 = 2804625362618 := by decide
theorem cert_e605602107066 : check e605602107066 [[],[]] .chain = true := by decide
def e605602107114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e605602107114 : Closed e605602107114 ∧ code e605602107114 = 2804625362666 := by decide
theorem cert_e605602107114 : check e605602107114 [[],[]] .chain = true := by decide
def e605602107222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e605602107222 : Closed e605602107222 ∧ code e605602107222 = 2804625362774 := by decide
theorem cert_e605602107222 : check e605602107222 [[],[]] .chain = true := by decide
def e605602107226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e605602107226 : Closed e605602107226 ∧ code e605602107226 = 2804625362778 := by decide
theorem cert_e605602107226 : check e605602107226 [[],[]] .chain = true := by decide
def e605602107242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e605602107242 : Closed e605602107242 ∧ code e605602107242 = 2804625362794 := by decide
theorem cert_e605602107242 : check e605602107242 [[],[]] .chain = true := by decide
def e605602108270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e605602108270 : Closed e605602108270 ∧ code e605602108270 = 2804625363822 := by decide
theorem cert_e605602108270 : check e605602108270 [[],[]] .chain = true := by decide
def e605602108278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e605602108278 : Closed e605602108278 ∧ code e605602108278 = 2804625363830 := by decide
theorem cert_e605602108278 : check e605602108278 [[],[]] .chain = true := by decide
def e605602108334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e605602108334 : Closed e605602108334 ∧ code e605602108334 = 2804625363886 := by decide
theorem cert_e605602108334 : check e605602108334 [[],[]] .chain = true := by decide
def e605602108346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e605602108346 : Closed e605602108346 ∧ code e605602108346 = 2804625363898 := by decide
theorem cert_e605602108346 : check e605602108346 [[],[]] .chain = true := by decide
def e605602108374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e605602108374 : Closed e605602108374 ∧ code e605602108374 = 2804625363926 := by decide
theorem cert_e605602108374 : check e605602108374 [[],[]] .chain = true := by decide
def e605602108378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e605602108378 : Closed e605602108378 ∧ code e605602108378 = 2804625363930 := by decide
theorem cert_e605602108378 : check e605602108378 [[],[]] .chain = true := by decide
def e605602108654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e605602108654 : Closed e605602108654 ∧ code e605602108654 = 2804625364206 := by decide
theorem cert_e605602108654 : check e605602108654 [[],[]] .chain = true := by decide
def e605602108662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e605602108662 : Closed e605602108662 ∧ code e605602108662 = 2804625364214 := by decide
theorem cert_e605602108662 : check e605602108662 [[],[]] .chain = true := by decide
def e605602109038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602109038 : Closed e605602109038 ∧ code e605602109038 = 2804625364590 := by decide
theorem cert_e605602109038 : check e605602109038 [[],[]] .chain = true := by decide
def e605602109050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602109050 : Closed e605602109050 ∧ code e605602109050 = 2804625364602 := by decide
theorem cert_e605602109050 : check e605602109050 [[],[]] .chain = true := by decide
def e605602109238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602109238 : Closed e605602109238 ∧ code e605602109238 = 2804625364790 := by decide
theorem cert_e605602109238 : check e605602109238 [[],[]] .chain = true := by decide
def e605602109242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602109242 : Closed e605602109242 ∧ code e605602109242 = 2804625364794 := by decide
theorem cert_e605602109242 : check e605602109242 [[],[]] .chain = true := by decide
def e605602109486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e605602109486 : Closed e605602109486 ∧ code e605602109486 = 2804625365038 := by decide
theorem cert_e605602109486 : check e605602109486 [[],[]] .chain = true := by decide
def e605602109678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))) (.var 2))))))
theorem wire_e605602109678 : Closed e605602109678 ∧ code e605602109678 = 2804625365230 := by decide
theorem cert_e605602109678 : check e605602109678 [[],[]] .chain = true := by decide
def e605602109686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))) (.var 1))))))
theorem wire_e605602109686 : Closed e605602109686 ∧ code e605602109686 = 2804625365238 := by decide
theorem cert_e605602109686 : check e605602109686 [[],[]] .chain = true := by decide
def e605602109870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e605602109870 : Closed e605602109870 ∧ code e605602109870 = 2804625365422 := by decide
theorem cert_e605602109870 : check e605602109870 [[],[]] .chain = true := by decide
def e605602109882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e605602109882 : Closed e605602109882 ∧ code e605602109882 = 2804625365434 := by decide
theorem cert_e605602109882 : check e605602109882 [[],[]] .chain = true := by decide
def e605602109930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e605602109930 : Closed e605602109930 ∧ code e605602109930 = 2804625365482 := by decide
theorem cert_e605602109930 : check e605602109930 [[],[]] .chain = true := by decide
def e605602110062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e605602110062 : Closed e605602110062 ∧ code e605602110062 = 2804625365614 := by decide
theorem cert_e605602110062 : check e605602110062 [[],[]] .chain = true := by decide
def e605602110074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e605602110074 : Closed e605602110074 ∧ code e605602110074 = 2804625365626 := by decide
theorem cert_e605602110074 : check e605602110074 [[],[]] .chain = true := by decide
def e605602110238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.lam (.var 3)))))))
theorem wire_e605602110238 : Closed e605602110238 ∧ code e605602110238 = 2804625365790 := by decide
theorem cert_e605602110238 : check e605602110238 [[],[]] .chain = true := by decide
def e605602110338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e605602110338 : Closed e605602110338 ∧ code e605602110338 = 2804625365890 := by decide
theorem cert_e605602110338 : check e605602110338 [[],[]] .chain = true := by decide
def e605602110350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 2)))))))
theorem wire_e605602110350 : Closed e605602110350 ∧ code e605602110350 = 2804625365902 := by decide
theorem cert_e605602110350 : check e605602110350 [[],[]] .chain = true := by decide
def e605602110362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602110362 : Closed e605602110362 ∧ code e605602110362 = 2804625365914 := by decide
theorem cert_e605602110362 : check e605602110362 [[],[]] .chain = true := by decide
def e605602110486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e605602110486 : Closed e605602110486 ∧ code e605602110486 = 2804625366038 := by decide
theorem cert_e605602110486 : check e605602110486 [[],[]] .chain = true := by decide
def e605602110582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))) (.var 1))))))
theorem wire_e605602110582 : Closed e605602110582 ∧ code e605602110582 = 2804625366134 := by decide
theorem cert_e605602110582 : check e605602110582 [[],[]] .chain = true := by decide
def e605602110678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e605602110678 : Closed e605602110678 ∧ code e605602110678 = 2804625366230 := by decide
theorem cert_e605602110678 : check e605602110678 [[],[]] .chain = true := by decide
def e605602110682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e605602110682 : Closed e605602110682 ∧ code e605602110682 = 2804625366234 := by decide
theorem cert_e605602110682 : check e605602110682 [[],[]] .chain = true := by decide
def e605602110698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e605602110698 : Closed e605602110698 ∧ code e605602110698 = 2804625366250 := by decide
theorem cert_e605602110698 : check e605602110698 [[],[]] .chain = true := by decide
def e605602110774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e605602110774 : Closed e605602110774 ∧ code e605602110774 = 2804625366326 := by decide
theorem cert_e605602110774 : check e605602110774 [[],[]] .chain = true := by decide
def e605602110778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e605602110778 : Closed e605602110778 ∧ code e605602110778 = 2804625366330 := by decide
theorem cert_e605602110778 : check e605602110778 [[],[]] .chain = true := by decide
def e605602110850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e605602110850 : Closed e605602110850 ∧ code e605602110850 = 2804625366402 := by decide
theorem cert_e605602110850 : check e605602110850 [[],[]] .chain = true := by decide
def e605602110862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 2)))))))
theorem wire_e605602110862 : Closed e605602110862 ∧ code e605602110862 = 2804625366414 := by decide
theorem cert_e605602110862 : check e605602110862 [[],[]] .chain = true := by decide
def e605602110874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e605602110874 : Closed e605602110874 ∧ code e605602110874 = 2804625366426 := by decide
theorem cert_e605602110874 : check e605602110874 [[],[]] .chain = true := by decide
def e605602111662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))) (.var 2))))))
theorem wire_e605602111662 : Closed e605602111662 ∧ code e605602111662 = 2804625367214 := by decide
theorem cert_e605602111662 : check e605602111662 [[],[]] .chain = true := by decide
def e605602111674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2))) (.var 0))))))
theorem wire_e605602111674 : Closed e605602111674 ∧ code e605602111674 = 2804625367226 := by decide
theorem cert_e605602111674 : check e605602111674 [[],[]] .chain = true := by decide
def e605602112238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 2))))))
theorem wire_e605602112238 : Closed e605602112238 ∧ code e605602112238 = 2804625367790 := by decide
theorem cert_e605602112238 : check e605602112238 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e605602112366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))) (.var 2))))))
theorem wire_e605602112366 : Closed e605602112366 ∧ code e605602112366 = 2804625367918 := by decide
theorem cert_e605602112366 : check e605602112366 [[],[]] .chain = true := by decide
def e605602112374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))) (.var 1))))))
theorem wire_e605602112374 : Closed e605602112374 ∧ code e605602112374 = 2804625367926 := by decide
theorem cert_e605602112374 : check e605602112374 [[],[]] .chain = true := by decide
def e605602112430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))) (.var 2))))))
theorem wire_e605602112430 : Closed e605602112430 ∧ code e605602112430 = 2804625367982 := by decide
theorem cert_e605602112430 : check e605602112430 [[],[]] .chain = true := by decide
def e605602112442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))) (.var 0))))))
theorem wire_e605602112442 : Closed e605602112442 ∧ code e605602112442 = 2804625367994 := by decide
theorem cert_e605602112442 : check e605602112442 [[],[]] .chain = true := by decide
def e605602112470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))) (.var 1))))))
theorem wire_e605602112470 : Closed e605602112470 ∧ code e605602112470 = 2804625368022 := by decide
theorem cert_e605602112470 : check e605602112470 [[],[]] .chain = true := by decide
def e605602112474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))) (.var 0))))))
theorem wire_e605602112474 : Closed e605602112474 ∧ code e605602112474 = 2804625368026 := by decide
theorem cert_e605602112474 : check e605602112474 [[],[]] .chain = true := by decide
def e605602113198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e605602113198 : Closed e605602113198 ∧ code e605602113198 = 2804625368750 := by decide
theorem cert_e605602113198 : check e605602113198 [[],[]] .chain = true := by decide
end Blc.Floor41
