import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e553831990882 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553831990882 : Closed e553831990882 ∧ code e553831990882 = 2752855246434 := by decide
theorem cert_e553831990882 : check e553831990882 [[]] .width = true := by decide
def e553832050202 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553832050202 : Closed e553832050202 ∧ code e553832050202 = 2752855305754 := by decide
theorem cert_e553832050202 : check e553832050202 [[]] .width = true := by decide
def e553832053274 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553832053274 : Closed e553832053274 ∧ code e553832053274 = 2752855308826 := by decide
theorem cert_e553832053274 : check e553832053274 [[]] .width = true := by decide
def e553832054810 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553832054810 : Closed e553832054810 ∧ code e553832054810 = 2752855310362 := by decide
theorem cert_e553832054810 : check e553832054810 [[]] .width = true := by decide
def e553832054902 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553832054902 : Closed e553832054902 ∧ code e553832054902 = 2752855310454 := by decide
theorem cert_e553832054902 : check e553832054902 [[]] .width = true := by decide
def e553832055146 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553832055146 : Closed e553832055146 ∧ code e553832055146 = 2752855310698 := by decide
theorem cert_e553832055146 : check e553832055146 [[]] .width = true := by decide
def e553832055194 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553832055194 : Closed e553832055194 ∧ code e553832055194 = 2752855310746 := by decide
theorem cert_e553832055194 : check e553832055194 [[]] .width = true := by decide
def e553832056202 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553832056202 : Closed e553832056202 ∧ code e553832056202 = 2752855311754 := by decide
theorem cert_e553832056202 : check e553832056202 [[]] .width = true := by decide
def e553832056226 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553832056226 : Closed e553832056226 ∧ code e553832056226 = 2752855311778 := by decide
theorem cert_e553832056226 : check e553832056226 [[]] .width = true := by decide
def e553832056334 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553832056334 : Closed e553832056334 ∧ code e553832056334 = 2752855311886 := by decide
theorem cert_e553832056334 : check e553832056334 [[]] .width = true := by decide
def e553832056346 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553832056346 : Closed e553832056346 ∧ code e553832056346 = 2752855311898 := by decide
theorem cert_e553832056346 : check e553832056346 [[]] .width = true := by decide
def e553832056418 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553832056418 : Closed e553832056418 ∧ code e553832056418 = 2752855311970 := by decide
theorem cert_e553832056418 : check e553832056418 [[]] .width = true := by decide
def e553832101402 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553832101402 : Closed e553832101402 ∧ code e553832101402 = 2752855356954 := by decide
private def t_e553832101402 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e553832101402 : ¬ IsSelfInterpreter e553832101402 :=
  wSource (t := t_e553832101402) (replay_sound (ps := []) (t := e553832101402) (by decide)) (by decide)
def e553832102426 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553832102426 : Closed e553832102426 ∧ code e553832102426 = 2752855357978 := by decide
private def t_e553832102426 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e553832102426 : ¬ IsSelfInterpreter e553832102426 :=
  wSource (t := t_e553832102426) (replay_sound (ps := []) (t := e553832102426) (by decide)) (by decide)
def e553835752986 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553835752986 : Closed e553835752986 ∧ code e553835752986 = 2752859008538 := by decide
theorem cert_e553835752986 : check e553835752986 [[]] .width = true := by decide
def e553835785754 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553835785754 : Closed e553835785754 ∧ code e553835785754 = 2752859041306 := by decide
theorem cert_e553835785754 : check e553835785754 [[]] .width = true := by decide
def e553835787802 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553835787802 : Closed e553835787802 ∧ code e553835787802 = 2752859043354 := by decide
theorem cert_e553835787802 : check e553835787802 [[]] .width = true := by decide
def e553836473882 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553836473882 : Closed e553836473882 ∧ code e553836473882 = 2752859729434 := by decide
theorem cert_e553836473882 : check e553836473882 [[]] .width = true := by decide
def e553836576794 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553836576794 : Closed e553836576794 ∧ code e553836576794 = 2752859832346 := by decide
theorem cert_e553836576794 : check e553836576794 [[]] .width = true := by decide
def e553836576886 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553836576886 : Closed e553836576886 ∧ code e553836576886 = 2752859832438 := by decide
theorem cert_e553836576886 : check e553836576886 [[]] .width = true := by decide
def e553836577130 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553836577130 : Closed e553836577130 ∧ code e553836577130 = 2752859832682 := by decide
theorem cert_e553836577130 : check e553836577130 [[]] .width = true := by decide
def e553836577178 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553836577178 : Closed e553836577178 ∧ code e553836577178 = 2752859832730 := by decide
theorem cert_e553836577178 : check e553836577178 [[]] .width = true := by decide
def e553836578186 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553836578186 : Closed e553836578186 ∧ code e553836578186 = 2752859833738 := by decide
theorem cert_e553836578186 : check e553836578186 [[]] .width = true := by decide
def e553836578210 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553836578210 : Closed e553836578210 ∧ code e553836578210 = 2752859833762 := by decide
theorem cert_e553836578210 : check e553836578210 [[]] .width = true := by decide
def e553836578318 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553836578318 : Closed e553836578318 ∧ code e553836578318 = 2752859833870 := by decide
theorem cert_e553836578318 : check e553836578318 [[]] .width = true := by decide
def e553836578330 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553836578330 : Closed e553836578330 ∧ code e553836578330 = 2752859833882 := by decide
theorem cert_e553836578330 : check e553836578330 [[]] .width = true := by decide
def e553836578402 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553836578402 : Closed e553836578402 ∧ code e553836578402 = 2752859833954 := by decide
theorem cert_e553836578402 : check e553836578402 [[]] .width = true := by decide
def e553836670490 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553836670490 : Closed e553836670490 ∧ code e553836670490 = 2752859926042 := by decide
theorem cert_e553836670490 : check e553836670490 [[]] .width = true := by decide
def e553836672538 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553836672538 : Closed e553836672538 ∧ code e553836672538 = 2752859928090 := by decide
theorem cert_e553836672538 : check e553836672538 [[]] .width = true := by decide
def e553836707866 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553836707866 : Closed e553836707866 ∧ code e553836707866 = 2752859963418 := by decide
theorem cert_e553836707866 : check e553836707866 [[]] .width = true := by decide
def e553836707958 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553836707958 : Closed e553836707958 ∧ code e553836707958 = 2752859963510 := by decide
theorem cert_e553836707958 : check e553836707958 [[]] .width = true := by decide
def e553836708202 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553836708202 : Closed e553836708202 ∧ code e553836708202 = 2752859963754 := by decide
theorem cert_e553836708202 : check e553836708202 [[]] .width = true := by decide
def e553836708250 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553836708250 : Closed e553836708250 ∧ code e553836708250 = 2752859963802 := by decide
theorem cert_e553836708250 : check e553836708250 [[]] .width = true := by decide
def e553836709258 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553836709258 : Closed e553836709258 ∧ code e553836709258 = 2752859964810 := by decide
theorem cert_e553836709258 : check e553836709258 [[]] .width = true := by decide
def e553836709282 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553836709282 : Closed e553836709282 ∧ code e553836709282 = 2752859964834 := by decide
theorem cert_e553836709282 : check e553836709282 [[]] .width = true := by decide
def e553836709390 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553836709390 : Closed e553836709390 ∧ code e553836709390 = 2752859964942 := by decide
theorem cert_e553836709390 : check e553836709390 [[]] .width = true := by decide
def e553836709402 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553836709402 : Closed e553836709402 ∧ code e553836709402 = 2752859964954 := by decide
theorem cert_e553836709402 : check e553836709402 [[]] .width = true := by decide
def e553836709474 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553836709474 : Closed e553836709474 ∧ code e553836709474 = 2752859965026 := by decide
theorem cert_e553836709474 : check e553836709474 [[]] .width = true := by decide
def e553842568730 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553842568730 : Closed e553842568730 ∧ code e553842568730 = 2752865824282 := by decide
theorem cert_e553842568730 : check e553842568730 [[]] .width = true := by decide
def e553842617882 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553842617882 : Closed e553842617882 ∧ code e553842617882 = 2752865873434 := by decide
theorem cert_e553842617882 : check e553842617882 [[]] .width = true := by decide
def e553842620954 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553842620954 : Closed e553842620954 ∧ code e553842620954 = 2752865876506 := by decide
theorem cert_e553842620954 : check e553842620954 [[]] .width = true := by decide
def e553842765338 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553842765338 : Closed e553842765338 ∧ code e553842765338 = 2752866020890 := by decide
theorem cert_e553842765338 : check e553842765338 [[]] .width = true := by decide
def e553842868250 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553842868250 : Closed e553842868250 ∧ code e553842868250 = 2752866123802 := by decide
theorem cert_e553842868250 : check e553842868250 [[]] .width = true := by decide
def e553842868342 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553842868342 : Closed e553842868342 ∧ code e553842868342 = 2752866123894 := by decide
theorem cert_e553842868342 : check e553842868342 [[]] .width = true := by decide
def e553842868586 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553842868586 : Closed e553842868586 ∧ code e553842868586 = 2752866124138 := by decide
theorem cert_e553842868586 : check e553842868586 [[]] .width = true := by decide
def e553842868634 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553842868634 : Closed e553842868634 ∧ code e553842868634 = 2752866124186 := by decide
theorem cert_e553842868634 : check e553842868634 [[]] .width = true := by decide
def e553842869642 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553842869642 : Closed e553842869642 ∧ code e553842869642 = 2752866125194 := by decide
theorem cert_e553842869642 : check e553842869642 [[]] .width = true := by decide
def e553842869666 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553842869666 : Closed e553842869666 ∧ code e553842869666 = 2752866125218 := by decide
theorem cert_e553842869666 : check e553842869666 [[]] .width = true := by decide
def e553842869774 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553842869774 : Closed e553842869774 ∧ code e553842869774 = 2752866125326 := by decide
theorem cert_e553842869774 : check e553842869774 [[]] .width = true := by decide
def e553842869786 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553842869786 : Closed e553842869786 ∧ code e553842869786 = 2752866125338 := by decide
theorem cert_e553842869786 : check e553842869786 [[]] .width = true := by decide
def e553842869858 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553842869858 : Closed e553842869858 ∧ code e553842869858 = 2752866125410 := by decide
theorem cert_e553842869858 : check e553842869858 [[]] .width = true := by decide
def e553843060250 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553843060250 : Closed e553843060250 ∧ code e553843060250 = 2752866315802 := by decide
theorem cert_e553843060250 : check e553843060250 [[]] .width = true := by decide
def e553843063322 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553843063322 : Closed e553843063322 ∧ code e553843063322 = 2752866318874 := by decide
theorem cert_e553843063322 : check e553843063322 [[]] .width = true := by decide
def e553843064858 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553843064858 : Closed e553843064858 ∧ code e553843064858 = 2752866320410 := by decide
theorem cert_e553843064858 : check e553843064858 [[]] .width = true := by decide
def e553843064950 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553843064950 : Closed e553843064950 ∧ code e553843064950 = 2752866320502 := by decide
theorem cert_e553843064950 : check e553843064950 [[]] .width = true := by decide
def e553843065194 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553843065194 : Closed e553843065194 ∧ code e553843065194 = 2752866320746 := by decide
theorem cert_e553843065194 : check e553843065194 [[]] .width = true := by decide
def e553843065242 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553843065242 : Closed e553843065242 ∧ code e553843065242 = 2752866320794 := by decide
theorem cert_e553843065242 : check e553843065242 [[]] .width = true := by decide
def e553843066250 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553843066250 : Closed e553843066250 ∧ code e553843066250 = 2752866321802 := by decide
theorem cert_e553843066250 : check e553843066250 [[]] .width = true := by decide
def e553843066274 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553843066274 : Closed e553843066274 ∧ code e553843066274 = 2752866321826 := by decide
theorem cert_e553843066274 : check e553843066274 [[]] .width = true := by decide
def e553843066382 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553843066382 : Closed e553843066382 ∧ code e553843066382 = 2752866321934 := by decide
theorem cert_e553843066382 : check e553843066382 [[]] .width = true := by decide
def e553843066394 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553843066394 : Closed e553843066394 ∧ code e553843066394 = 2752866321946 := by decide
theorem cert_e553843066394 : check e553843066394 [[]] .width = true := by decide
def e553843066466 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553843066466 : Closed e553843066466 ∧ code e553843066466 = 2752866322018 := by decide
theorem cert_e553843066466 : check e553843066466 [[]] .width = true := by decide
def e553846009370 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553846009370 : Closed e553846009370 ∧ code e553846009370 = 2752869264922 := by decide
theorem cert_e553846009370 : check e553846009370 [[]] .width = true := by decide
def e553846011418 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553846011418 : Closed e553846011418 ∧ code e553846011418 = 2752869266970 := by decide
theorem cert_e553846011418 : check e553846011418 [[]] .width = true := by decide
def e553846025754 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553846025754 : Closed e553846025754 ∧ code e553846025754 = 2752869281306 := by decide
theorem cert_e553846025754 : check e553846025754 [[]] .width = true := by decide
def e553846028826 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553846028826 : Closed e553846028826 ∧ code e553846028826 = 2752869284378 := by decide
theorem cert_e553846028826 : check e553846028826 [[]] .width = true := by decide
def e553846035994 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553846035994 : Closed e553846035994 ∧ code e553846035994 = 2752869291546 := by decide
theorem cert_e553846035994 : check e553846035994 [[]] .width = true := by decide
def e553846037018 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553846037018 : Closed e553846037018 ∧ code e553846037018 = 2752869292570 := by decide
theorem cert_e553846037018 : check e553846037018 [[]] .width = true := by decide
def e553846107674 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553846107674 : Closed e553846107674 ∧ code e553846107674 = 2752869363226 := by decide
theorem cert_e553846107674 : check e553846107674 [[]] .width = true := by decide
def e553846109722 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553846109722 : Closed e553846109722 ∧ code e553846109722 = 2752869365274 := by decide
theorem cert_e553846109722 : check e553846109722 [[]] .width = true := by decide
def e553846145050 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553846145050 : Closed e553846145050 ∧ code e553846145050 = 2752869400602 := by decide
theorem cert_e553846145050 : check e553846145050 [[]] .width = true := by decide
def e553846145142 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553846145142 : Closed e553846145142 ∧ code e553846145142 = 2752869400694 := by decide
theorem cert_e553846145142 : check e553846145142 [[]] .width = true := by decide
def e553846145386 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553846145386 : Closed e553846145386 ∧ code e553846145386 = 2752869400938 := by decide
theorem cert_e553846145386 : check e553846145386 [[]] .width = true := by decide
def e553846145434 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553846145434 : Closed e553846145434 ∧ code e553846145434 = 2752869400986 := by decide
theorem cert_e553846145434 : check e553846145434 [[]] .width = true := by decide
def e553846146442 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553846146442 : Closed e553846146442 ∧ code e553846146442 = 2752869401994 := by decide
theorem cert_e553846146442 : check e553846146442 [[]] .width = true := by decide
def e553846146466 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553846146466 : Closed e553846146466 ∧ code e553846146466 = 2752869402018 := by decide
theorem cert_e553846146466 : check e553846146466 [[]] .width = true := by decide
def e553846146574 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553846146574 : Closed e553846146574 ∧ code e553846146574 = 2752869402126 := by decide
theorem cert_e553846146574 : check e553846146574 [[]] .width = true := by decide
def e553846146586 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553846146586 : Closed e553846146586 ∧ code e553846146586 = 2752869402138 := by decide
theorem cert_e553846146586 : check e553846146586 [[]] .width = true := by decide
def e553846146658 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553846146658 : Closed e553846146658 ∧ code e553846146658 = 2752869402210 := by decide
theorem cert_e553846146658 : check e553846146658 [[]] .width = true := by decide
def e553846205978 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553846205978 : Closed e553846205978 ∧ code e553846205978 = 2752869461530 := by decide
theorem cert_e553846205978 : check e553846205978 [[]] .width = true := by decide
def e553846209050 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553846209050 : Closed e553846209050 ∧ code e553846209050 = 2752869464602 := by decide
theorem cert_e553846209050 : check e553846209050 [[]] .width = true := by decide
def e553846210586 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553846210586 : Closed e553846210586 ∧ code e553846210586 = 2752869466138 := by decide
theorem cert_e553846210586 : check e553846210586 [[]] .width = true := by decide
def e553846210678 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553846210678 : Closed e553846210678 ∧ code e553846210678 = 2752869466230 := by decide
theorem cert_e553846210678 : check e553846210678 [[]] .width = true := by decide
def e553846210922 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553846210922 : Closed e553846210922 ∧ code e553846210922 = 2752869466474 := by decide
theorem cert_e553846210922 : check e553846210922 [[]] .width = true := by decide
def e553846210970 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553846210970 : Closed e553846210970 ∧ code e553846210970 = 2752869466522 := by decide
theorem cert_e553846210970 : check e553846210970 [[]] .width = true := by decide
def e553846211978 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553846211978 : Closed e553846211978 ∧ code e553846211978 = 2752869467530 := by decide
theorem cert_e553846211978 : check e553846211978 [[]] .width = true := by decide
def e553846212002 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553846212002 : Closed e553846212002 ∧ code e553846212002 = 2752869467554 := by decide
theorem cert_e553846212002 : check e553846212002 [[]] .width = true := by decide
def e553846212110 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553846212110 : Closed e553846212110 ∧ code e553846212110 = 2752869467662 := by decide
theorem cert_e553846212110 : check e553846212110 [[]] .width = true := by decide
def e553846212122 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553846212122 : Closed e553846212122 ∧ code e553846212122 = 2752869467674 := by decide
theorem cert_e553846212122 : check e553846212122 [[]] .width = true := by decide
def e553846212194 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553846212194 : Closed e553846212194 ∧ code e553846212194 = 2752869467746 := by decide
theorem cert_e553846212194 : check e553846212194 [[]] .width = true := by decide
def e553846257178 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553846257178 : Closed e553846257178 ∧ code e553846257178 = 2752869512730 := by decide
theorem cert_e553846257178 : check e553846257178 [[]] .width = true := by decide
def e553846258202 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553846258202 : Closed e553846258202 ∧ code e553846258202 = 2752869513754 := by decide
theorem cert_e553846258202 : check e553846258202 [[]] .width = true := by decide
def e553899830638 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e553899830638 : Closed e553899830638 ∧ code e553899830638 = 2752923086190 := by decide
theorem cert_e553899830638 : check e553899830638 [[],[.under,.under]] .three = true := by decide
def e553899830646 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e553899830646 : Closed e553899830646 ∧ code e553899830646 = 2752923086198 := by decide
theorem cert_e553899830646 : check e553899830646 [[],[.under,.under]] .three = true := by decide
def e553899830702 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e553899830702 : Closed e553899830702 ∧ code e553899830702 = 2752923086254 := by decide
theorem cert_e553899830702 : check e553899830702 [[],[.under,.under]] .three = true := by decide
def e553899830714 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e553899830714 : Closed e553899830714 ∧ code e553899830714 = 2752923086266 := by decide
theorem cert_e553899830714 : check e553899830714 [[],[.under,.under]] .three = true := by decide
def e553899830742 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e553899830742 : Closed e553899830742 ∧ code e553899830742 = 2752923086294 := by decide
theorem cert_e553899830742 : check e553899830742 [[],[.under,.under]] .three = true := by decide
def e553899830746 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e553899830746 : Closed e553899830746 ∧ code e553899830746 = 2752923086298 := by decide
theorem cert_e553899830746 : check e553899830746 [[],[.under,.under]] .three = true := by decide
def e553899830958 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e553899830958 : Closed e553899830958 ∧ code e553899830958 = 2752923086510 := by decide
theorem cert_e553899830958 : check e553899830958 [[],[.under,.under]] .three = true := by decide
def e553899830970 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e553899830970 : Closed e553899830970 ∧ code e553899830970 = 2752923086522 := by decide
theorem cert_e553899830970 : check e553899830970 [[],[.under,.under]] .three = true := by decide
def e553899831018 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e553899831018 : Closed e553899831018 ∧ code e553899831018 = 2752923086570 := by decide
theorem cert_e553899831018 : check e553899831018 [[],[.under,.under]] .three = true := by decide
def e553899831126 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e553899831126 : Closed e553899831126 ∧ code e553899831126 = 2752923086678 := by decide
theorem cert_e553899831126 : check e553899831126 [[],[.under,.under]] .three = true := by decide
def e553899831130 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e553899831130 : Closed e553899831130 ∧ code e553899831130 = 2752923086682 := by decide
theorem cert_e553899831130 : check e553899831130 [[],[.under,.under]] .three = true := by decide
def e553899831146 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e553899831146 : Closed e553899831146 ∧ code e553899831146 = 2752923086698 := by decide
theorem cert_e553899831146 : check e553899831146 [[],[.under,.under]] .three = true := by decide
def e553899832174 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e553899832174 : Closed e553899832174 ∧ code e553899832174 = 2752923087726 := by decide
theorem cert_e553899832174 : check e553899832174 [[],[.under,.under]] .three = true := by decide
def e553899832182 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e553899832182 : Closed e553899832182 ∧ code e553899832182 = 2752923087734 := by decide
theorem cert_e553899832182 : check e553899832182 [[],[.under,.under]] .three = true := by decide
def e553899832238 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e553899832238 : Closed e553899832238 ∧ code e553899832238 = 2752923087790 := by decide
theorem cert_e553899832238 : check e553899832238 [[],[.under,.under]] .three = true := by decide
def e553899832250 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e553899832250 : Closed e553899832250 ∧ code e553899832250 = 2752923087802 := by decide
theorem cert_e553899832250 : check e553899832250 [[],[.under,.under]] .three = true := by decide
def e553899832278 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e553899832278 : Closed e553899832278 ∧ code e553899832278 = 2752923087830 := by decide
theorem cert_e553899832278 : check e553899832278 [[],[.under,.under]] .three = true := by decide
def e553899832282 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e553899832282 : Closed e553899832282 ∧ code e553899832282 = 2752923087834 := by decide
theorem cert_e553899832282 : check e553899832282 [[],[.under,.under]] .three = true := by decide
def e553899832558 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e553899832558 : Closed e553899832558 ∧ code e553899832558 = 2752923088110 := by decide
theorem cert_e553899832558 : check e553899832558 [[],[.under,.under]] .three = true := by decide
def e553899832566 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e553899832566 : Closed e553899832566 ∧ code e553899832566 = 2752923088118 := by decide
theorem cert_e553899832566 : check e553899832566 [[],[.under,.under]] .three = true := by decide
def e553899832942 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e553899832942 : Closed e553899832942 ∧ code e553899832942 = 2752923088494 := by decide
theorem cert_e553899832942 : check e553899832942 [[],[.under,.under]] .three = true := by decide
def e553899832954 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e553899832954 : Closed e553899832954 ∧ code e553899832954 = 2752923088506 := by decide
theorem cert_e553899832954 : check e553899832954 [[],[.under,.under]] .three = true := by decide
def e553899833142 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e553899833142 : Closed e553899833142 ∧ code e553899833142 = 2752923088694 := by decide
theorem cert_e553899833142 : check e553899833142 [[],[.under,.under]] .three = true := by decide
def e553899833146 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e553899833146 : Closed e553899833146 ∧ code e553899833146 = 2752923088698 := by decide
theorem cert_e553899833146 : check e553899833146 [[],[.under,.under]] .three = true := by decide
def e553899833774 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e553899833774 : Closed e553899833774 ∧ code e553899833774 = 2752923089326 := by decide
theorem cert_e553899833774 : check e553899833774 [[],[.under,.under]] .three = true := by decide
def e553899833786 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e553899833786 : Closed e553899833786 ∧ code e553899833786 = 2752923089338 := by decide
theorem cert_e553899833786 : check e553899833786 [[],[.under,.under]] .three = true := by decide
def e553899833834 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e553899833834 : Closed e553899833834 ∧ code e553899833834 = 2752923089386 := by decide
theorem cert_e553899833834 : check e553899833834 [[],[.under,.under]] .three = true := by decide
def e553899833966 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e553899833966 : Closed e553899833966 ∧ code e553899833966 = 2752923089518 := by decide
theorem cert_e553899833966 : check e553899833966 [[],[.under,.under]] .three = true := by decide
def e553899833978 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e553899833978 : Closed e553899833978 ∧ code e553899833978 = 2752923089530 := by decide
theorem cert_e553899833978 : check e553899833978 [[],[.under,.under]] .three = true := by decide
def e553899834266 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e553899834266 : Closed e553899834266 ∧ code e553899834266 = 2752923089818 := by decide
theorem cert_e553899834266 : check e553899834266 [[],[.under,.under]] .three = true := by decide
def e553899834582 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e553899834582 : Closed e553899834582 ∧ code e553899834582 = 2752923090134 := by decide
theorem cert_e553899834582 : check e553899834582 [[],[.under,.under]] .three = true := by decide
def e553899834586 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e553899834586 : Closed e553899834586 ∧ code e553899834586 = 2752923090138 := by decide
theorem cert_e553899834586 : check e553899834586 [[],[.under,.under]] .three = true := by decide
def e553899834602 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e553899834602 : Closed e553899834602 ∧ code e553899834602 = 2752923090154 := by decide
theorem cert_e553899834602 : check e553899834602 [[],[.under,.under]] .three = true := by decide
def e553899834678 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e553899834678 : Closed e553899834678 ∧ code e553899834678 = 2752923090230 := by decide
theorem cert_e553899834678 : check e553899834678 [[],[.under,.under]] .three = true := by decide
def e553899834682 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e553899834682 : Closed e553899834682 ∧ code e553899834682 = 2752923090234 := by decide
theorem cert_e553899834682 : check e553899834682 [[],[.under,.under]] .three = true := by decide
def e553899834778 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e553899834778 : Closed e553899834778 ∧ code e553899834778 = 2752923090330 := by decide
theorem cert_e553899834778 : check e553899834778 [[],[.under,.under]] .three = true := by decide
def e553899838318 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e553899838318 : Closed e553899838318 ∧ code e553899838318 = 2752923093870 := by decide
theorem cert_e553899838318 : check e553899838318 [[],[.under,.under]] .three = true := by decide
def e553899838326 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e553899838326 : Closed e553899838326 ∧ code e553899838326 = 2752923093878 := by decide
theorem cert_e553899838326 : check e553899838326 [[],[.under,.under]] .three = true := by decide
def e553899838382 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e553899838382 : Closed e553899838382 ∧ code e553899838382 = 2752923093934 := by decide
theorem cert_e553899838382 : check e553899838382 [[],[.under,.under]] .three = true := by decide
def e553899838394 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e553899838394 : Closed e553899838394 ∧ code e553899838394 = 2752923093946 := by decide
theorem cert_e553899838394 : check e553899838394 [[],[.under,.under]] .three = true := by decide
def e553899838422 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e553899838422 : Closed e553899838422 ∧ code e553899838422 = 2752923093974 := by decide
theorem cert_e553899838422 : check e553899838422 [[],[.under,.under]] .three = true := by decide
def e553899838426 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e553899838426 : Closed e553899838426 ∧ code e553899838426 = 2752923093978 := by decide
theorem cert_e553899838426 : check e553899838426 [[],[.under,.under]] .three = true := by decide
def e553899838702 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e553899838702 : Closed e553899838702 ∧ code e553899838702 = 2752923094254 := by decide
theorem cert_e553899838702 : check e553899838702 [[],[.under,.under]] .three = true := by decide
def e553899838710 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e553899838710 : Closed e553899838710 ∧ code e553899838710 = 2752923094262 := by decide
theorem cert_e553899838710 : check e553899838710 [[],[.under,.under]] .three = true := by decide
def e553899839086 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e553899839086 : Closed e553899839086 ∧ code e553899839086 = 2752923094638 := by decide
theorem cert_e553899839086 : check e553899839086 [[],[.under,.under]] .three = true := by decide
def e553899839098 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e553899839098 : Closed e553899839098 ∧ code e553899839098 = 2752923094650 := by decide
theorem cert_e553899839098 : check e553899839098 [[],[.under,.under]] .three = true := by decide
def e553899839286 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e553899839286 : Closed e553899839286 ∧ code e553899839286 = 2752923094838 := by decide
theorem cert_e553899839286 : check e553899839286 [[],[.under,.under]] .three = true := by decide
def e553899839290 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e553899839290 : Closed e553899839290 ∧ code e553899839290 = 2752923094842 := by decide
theorem cert_e553899839290 : check e553899839290 [[],[.under,.under]] .three = true := by decide
def e553899845038 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e553899845038 : Closed e553899845038 ∧ code e553899845038 = 2752923100590 := by decide
theorem cert_e553899845038 : check e553899845038 [[],[.under,.under]] .three = true := by decide
def e553899845050 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e553899845050 : Closed e553899845050 ∧ code e553899845050 = 2752923100602 := by decide
theorem cert_e553899845050 : check e553899845050 [[],[.under,.under]] .three = true := by decide
def e553899845098 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e553899845098 : Closed e553899845098 ∧ code e553899845098 = 2752923100650 := by decide
theorem cert_e553899845098 : check e553899845098 [[],[.under,.under]] .three = true := by decide
def e553899845230 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e553899845230 : Closed e553899845230 ∧ code e553899845230 = 2752923100782 := by decide
theorem cert_e553899845230 : check e553899845230 [[],[.under,.under]] .three = true := by decide
def e553899845242 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e553899845242 : Closed e553899845242 ∧ code e553899845242 = 2752923100794 := by decide
theorem cert_e553899845242 : check e553899845242 [[],[.under,.under]] .three = true := by decide
def e553899845530 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e553899845530 : Closed e553899845530 ∧ code e553899845530 = 2752923101082 := by decide
theorem cert_e553899845530 : check e553899845530 [[],[.under,.under]] .three = true := by decide
def e553899848406 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e553899848406 : Closed e553899848406 ∧ code e553899848406 = 2752923103958 := by decide
theorem cert_e553899848406 : check e553899848406 [[],[.under,.under]] .three = true := by decide
def e553899848410 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e553899848410 : Closed e553899848410 ∧ code e553899848410 = 2752923103962 := by decide
theorem cert_e553899848410 : check e553899848410 [[],[.under,.under]] .three = true := by decide
def e553899848426 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e553899848426 : Closed e553899848426 ∧ code e553899848426 = 2752923103978 := by decide
theorem cert_e553899848426 : check e553899848426 [[],[.under,.under]] .three = true := by decide
def e553899848502 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e553899848502 : Closed e553899848502 ∧ code e553899848502 = 2752923104054 := by decide
theorem cert_e553899848502 : check e553899848502 [[],[.under,.under]] .three = true := by decide
def e553899848506 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e553899848506 : Closed e553899848506 ∧ code e553899848506 = 2752923104058 := by decide
theorem cert_e553899848506 : check e553899848506 [[],[.under,.under]] .three = true := by decide
def e553899848602 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e553899848602 : Closed e553899848602 ∧ code e553899848602 = 2752923104154 := by decide
theorem cert_e553899848602 : check e553899848602 [[],[.under,.under]] .three = true := by decide
def e553899985774 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e553899985774 : Closed e553899985774 ∧ code e553899985774 = 2752923241326 := by decide
theorem cert_e553899985774 : check e553899985774 [[],[.under,.under]] .three = true := by decide
def e553899985782 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e553899985782 : Closed e553899985782 ∧ code e553899985782 = 2752923241334 := by decide
theorem cert_e553899985782 : check e553899985782 [[],[.under,.under]] .three = true := by decide
def e553899985838 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e553899985838 : Closed e553899985838 ∧ code e553899985838 = 2752923241390 := by decide
theorem cert_e553899985838 : check e553899985838 [[],[.under,.under]] .three = true := by decide
def e553899985850 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e553899985850 : Closed e553899985850 ∧ code e553899985850 = 2752923241402 := by decide
theorem cert_e553899985850 : check e553899985850 [[],[.under,.under]] .three = true := by decide
def e553899985878 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e553899985878 : Closed e553899985878 ∧ code e553899985878 = 2752923241430 := by decide
theorem cert_e553899985878 : check e553899985878 [[],[.under,.under]] .three = true := by decide
def e553899985882 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e553899985882 : Closed e553899985882 ∧ code e553899985882 = 2752923241434 := by decide
theorem cert_e553899985882 : check e553899985882 [[],[.under,.under]] .three = true := by decide
def e553899986158 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e553899986158 : Closed e553899986158 ∧ code e553899986158 = 2752923241710 := by decide
theorem cert_e553899986158 : check e553899986158 [[],[.under,.under]] .three = true := by decide
def e553899986166 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e553899986166 : Closed e553899986166 ∧ code e553899986166 = 2752923241718 := by decide
theorem cert_e553899986166 : check e553899986166 [[],[.under,.under]] .three = true := by decide
end Blc.Floor41
