import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598355226078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e598355226078 : Closed e598355226078 ∧ code e598355226078 = 2797378481630 := by decide
theorem cert_e598355226078 : check e598355226078 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e598355226094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e598355226094 : Closed e598355226094 ∧ code e598355226094 = 2797378481646 := by decide
theorem cert_e598355226094 : check e598355226094 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e598355226462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e598355226462 : Closed e598355226462 ∧ code e598355226462 = 2797378482014 := by decide
theorem cert_e598355226462 : check e598355226462 [[],[.left],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e598355226490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e598355226490 : Closed e598355226490 ∧ code e598355226490 = 2797378482042 := by decide
private def t_e598355226490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem cert_e598355226490 : ¬ IsSelfInterpreter e598355226490 :=
  wSource (t := t_e598355226490) (replay_sound (ps := []) (t := e598355226490) (by decide)) (by decide)
def e598355226542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e598355226542 : Closed e598355226542 ∧ code e598355226542 = 2797378482094 := by decide
theorem cert_e598355226542 : check e598355226542 [[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e598355226554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e598355226554 : Closed e598355226554 ∧ code e598355226554 = 2797378482106 := by decide
private def t_e598355226554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem cert_e598355226554 : ¬ IsSelfInterpreter e598355226554 :=
  wSource (t := t_e598355226554) (replay_sound (ps := []) (t := e598355226554) (by decide)) (by decide)
def e598355227614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e598355227614 : Closed e598355227614 ∧ code e598355227614 = 2797378483166 := by decide
theorem cert_e598355227614 : check e598355227614 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e598355227630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e598355227630 : Closed e598355227630 ∧ code e598355227630 = 2797378483182 := by decide
theorem cert_e598355227630 : check e598355227630 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e598355229918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e598355229918 : Closed e598355229918 ∧ code e598355229918 = 2797378485470 := by decide
theorem cert_e598355229918 : check e598355229918 [[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e598355229946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e598355229946 : Closed e598355229946 ∧ code e598355229946 = 2797378485498 := by decide
theorem cert_e598355229946 : check e598355229946 [[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e598355230318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e598355230318 : Closed e598355230318 ∧ code e598355230318 = 2797378485870 := by decide
theorem cert_e598355230318 : check e598355230318 [[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e598355230330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e598355230330 : Closed e598355230330 ∧ code e598355230330 = 2797378485882 := by decide
theorem cert_e598355230330 : check e598355230330 [[],[.left],[.left],[.left],[],[.under],[.under,.left],[.under]] .chain = true := by decide
def e598355258734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e598355258734 : Closed e598355258734 ∧ code e598355258734 = 2797378514286 := by decide
def e598355258742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e598355258742 : Closed e598355258742 ∧ code e598355258742 = 2797378514294 := by decide
def e598355258798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e598355258798 : Closed e598355258798 ∧ code e598355258798 = 2797378514350 := by decide
def e598355258810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e598355258810 : Closed e598355258810 ∧ code e598355258810 = 2797378514362 := by decide
def e598355258838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e598355258838 : Closed e598355258838 ∧ code e598355258838 = 2797378514390 := by decide
def e598355258842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e598355258842 : Closed e598355258842 ∧ code e598355258842 = 2797378514394 := by decide
def e598355259054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e598355259054 : Closed e598355259054 ∧ code e598355259054 = 2797378514606 := by decide
def e598355259066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e598355259066 : Closed e598355259066 ∧ code e598355259066 = 2797378514618 := by decide
def e598355259114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e598355259114 : Closed e598355259114 ∧ code e598355259114 = 2797378514666 := by decide
private def t_e598355259114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem cert_e598355259114 : ¬ IsSelfInterpreter e598355259114 :=
  wSource (t := t_e598355259114) (replay_sound (ps := []) (t := e598355259114) (by decide)) (by decide)
def e598355259222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e598355259222 : Closed e598355259222 ∧ code e598355259222 = 2797378514774 := by decide
def e598355259226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e598355259226 : Closed e598355259226 ∧ code e598355259226 = 2797378514778 := by decide
def e598355259242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e598355259242 : Closed e598355259242 ∧ code e598355259242 = 2797378514794 := by decide
private def t_e598355259242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem cert_e598355259242 : ¬ IsSelfInterpreter e598355259242 :=
  wSource (t := t_e598355259242) (replay_sound (ps := []) (t := e598355259242) (by decide)) (by decide)
def e598355260270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e598355260270 : Closed e598355260270 ∧ code e598355260270 = 2797378515822 := by decide
def e598355260278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e598355260278 : Closed e598355260278 ∧ code e598355260278 = 2797378515830 := by decide
def e598355260334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e598355260334 : Closed e598355260334 ∧ code e598355260334 = 2797378515886 := by decide
def e598355260346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e598355260346 : Closed e598355260346 ∧ code e598355260346 = 2797378515898 := by decide
def e598355260374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e598355260374 : Closed e598355260374 ∧ code e598355260374 = 2797378515926 := by decide
def e598355260378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e598355260378 : Closed e598355260378 ∧ code e598355260378 = 2797378515930 := by decide
def e598355260654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e598355260654 : Closed e598355260654 ∧ code e598355260654 = 2797378516206 := by decide
def e598355260662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e598355260662 : Closed e598355260662 ∧ code e598355260662 = 2797378516214 := by decide
def e598355261038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e598355261038 : Closed e598355261038 ∧ code e598355261038 = 2797378516590 := by decide
def e598355261050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e598355261050 : Closed e598355261050 ∧ code e598355261050 = 2797378516602 := by decide
def e598355261238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e598355261238 : Closed e598355261238 ∧ code e598355261238 = 2797378516790 := by decide
def e598355261242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e598355261242 : Closed e598355261242 ∧ code e598355261242 = 2797378516794 := by decide
def e598355261870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e598355261870 : Closed e598355261870 ∧ code e598355261870 = 2797378517422 := by decide
def e598355261882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e598355261882 : Closed e598355261882 ∧ code e598355261882 = 2797378517434 := by decide
def e598355261930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e598355261930 : Closed e598355261930 ∧ code e598355261930 = 2797378517482 := by decide
def e598355262062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e598355262062 : Closed e598355262062 ∧ code e598355262062 = 2797378517614 := by decide
def e598355262074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e598355262074 : Closed e598355262074 ∧ code e598355262074 = 2797378517626 := by decide
def e598355262362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e598355262362 : Closed e598355262362 ∧ code e598355262362 = 2797378517914 := by decide
private def t_e598355262362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem cert_e598355262362 : ¬ IsSelfInterpreter e598355262362 :=
  wSource (t := t_e598355262362) (replay_sound (ps := []) (t := e598355262362) (by decide)) (by decide)
def e598355262678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e598355262678 : Closed e598355262678 ∧ code e598355262678 = 2797378518230 := by decide
def e598355262682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e598355262682 : Closed e598355262682 ∧ code e598355262682 = 2797378518234 := by decide
def e598355262698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e598355262698 : Closed e598355262698 ∧ code e598355262698 = 2797378518250 := by decide
def e598355262774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e598355262774 : Closed e598355262774 ∧ code e598355262774 = 2797378518326 := by decide
def e598355262778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e598355262778 : Closed e598355262778 ∧ code e598355262778 = 2797378518330 := by decide
def e598355262874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e598355262874 : Closed e598355262874 ∧ code e598355262874 = 2797378518426 := by decide
private def t_e598355262874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem cert_e598355262874 : ¬ IsSelfInterpreter e598355262874 :=
  wSource (t := t_e598355262874) (replay_sound (ps := []) (t := e598355262874) (by decide)) (by decide)
def e598355264478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e598355264478 : Closed e598355264478 ∧ code e598355264478 = 2797378520030 := by decide
theorem cert_e598355264478 : check e598355264478 [[],[.left],[.left],[.left],[],[],[],[]] .sourceHead = true := by decide
def e598355264494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e598355264494 : Closed e598355264494 ∧ code e598355264494 = 2797378520046 := by decide
theorem cert_e598355264494 : check e598355264494 [[],[.left],[.left],[.left],[],[],[],[],[]] .sourceHead = true := by decide
def e598355266414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598355266414 : Closed e598355266414 ∧ code e598355266414 = 2797378521966 := by decide
def e598355266422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598355266422 : Closed e598355266422 ∧ code e598355266422 = 2797378521974 := by decide
theorem cert_e598355266422 : check e598355266422 [[],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e598355266478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598355266478 : Closed e598355266478 ∧ code e598355266478 = 2797378522030 := by decide
def e598355266490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598355266490 : Closed e598355266490 ∧ code e598355266490 = 2797378522042 := by decide
def e598355266518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598355266518 : Closed e598355266518 ∧ code e598355266518 = 2797378522070 := by decide
theorem cert_e598355266518 : check e598355266518 [[],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e598355266522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598355266522 : Closed e598355266522 ∧ code e598355266522 = 2797378522074 := by decide
def e598355266798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598355266798 : Closed e598355266798 ∧ code e598355266798 = 2797378522350 := by decide
theorem cert_e598355266798 : check e598355266798 [[],[.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e598355266806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598355266806 : Closed e598355266806 ∧ code e598355266806 = 2797378522358 := by decide
def e598355267182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598355267182 : Closed e598355267182 ∧ code e598355267182 = 2797378522734 := by decide
theorem cert_e598355267182 : check e598355267182 [[],[.left],[.left],[.left],[],[],[.left],[],[]] .sourceHead = true := by decide
def e598355267194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598355267194 : Closed e598355267194 ∧ code e598355267194 = 2797378522746 := by decide
theorem cert_e598355267194 : check e598355267194 [[],[.left],[.left],[.left],[],[],[.left],[],[]] .sourceHead = true := by decide
def e598355267382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598355267382 : Closed e598355267382 ∧ code e598355267382 = 2797378522934 := by decide
def e598355267386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598355267386 : Closed e598355267386 ∧ code e598355267386 = 2797378522938 := by decide
theorem cert_e598355267386 : check e598355267386 [[],[.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e598355272158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e598355272158 : Closed e598355272158 ∧ code e598355272158 = 2797378527710 := by decide
theorem cert_e598355272158 : check e598355272158 [[],[.left],[.left],[.left],[],[],[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e598355272182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e598355272182 : Closed e598355272182 ∧ code e598355272182 = 2797378527734 := by decide
theorem cert_e598355272182 : check e598355272182 [[],[.left],[.left],[.left],[],[],[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e598355273134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e598355273134 : Closed e598355273134 ∧ code e598355273134 = 2797378528686 := by decide
def e598355273146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e598355273146 : Closed e598355273146 ∧ code e598355273146 = 2797378528698 := by decide
def e598355273194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e598355273194 : Closed e598355273194 ∧ code e598355273194 = 2797378528746 := by decide
def e598355273326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e598355273326 : Closed e598355273326 ∧ code e598355273326 = 2797378528878 := by decide
def e598355273338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e598355273338 : Closed e598355273338 ∧ code e598355273338 = 2797378528890 := by decide
def e598355273626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e598355273626 : Closed e598355273626 ∧ code e598355273626 = 2797378529178 := by decide
def e598355276014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e598355276014 : Closed e598355276014 ∧ code e598355276014 = 2797378531566 := by decide
theorem cert_e598355276014 : check e598355276014 [[],[.left],[.left],[.left],[],[],[],[],[],[.under],[.under,.under],[.under,.under]] .chain = true := by decide
def e598355276022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e598355276022 : Closed e598355276022 ∧ code e598355276022 = 2797378531574 := by decide
theorem cert_e598355276022 : check e598355276022 [[],[.left],[.left],[.left],[],[],[],[],[.under],[.under,.under],[.under,.under]] .chain = true := by decide
def e598355276502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e598355276502 : Closed e598355276502 ∧ code e598355276502 = 2797378532054 := by decide
def e598355276506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e598355276506 : Closed e598355276506 ∧ code e598355276506 = 2797378532058 := by decide
def e598355276522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e598355276522 : Closed e598355276522 ∧ code e598355276522 = 2797378532074 := by decide
def e598355276598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e598355276598 : Closed e598355276598 ∧ code e598355276598 = 2797378532150 := by decide
def e598355276602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e598355276602 : Closed e598355276602 ∧ code e598355276602 = 2797378532154 := by decide
def e598355276698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e598355276698 : Closed e598355276698 ∧ code e598355276698 = 2797378532250 := by decide
def e598355413870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598355413870 : Closed e598355413870 ∧ code e598355413870 = 2797378669422 := by decide
private def t_e598355413870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e598355413870 : ¬ IsSelfInterpreter e598355413870 :=
  wSource (t := t_e598355413870) (replay_sound (ps := []) (t := e598355413870) (by decide)) (by decide)
def e598355413878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598355413878 : Closed e598355413878 ∧ code e598355413878 = 2797378669430 := by decide
private def t_e598355413878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e598355413878 : ¬ IsSelfInterpreter e598355413878 :=
  wSource (t := t_e598355413878) (replay_sound (ps := []) (t := e598355413878) (by decide)) (by decide)
def e598355413934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598355413934 : Closed e598355413934 ∧ code e598355413934 = 2797378669486 := by decide
private def t_e598355413934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e598355413934 : ¬ IsSelfInterpreter e598355413934 :=
  wSource (t := t_e598355413934) (replay_sound (ps := []) (t := e598355413934) (by decide)) (by decide)
def e598355413946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598355413946 : Closed e598355413946 ∧ code e598355413946 = 2797378669498 := by decide
private def t_e598355413946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e598355413946 : ¬ IsSelfInterpreter e598355413946 :=
  wSource (t := t_e598355413946) (replay_sound (ps := []) (t := e598355413946) (by decide)) (by decide)
def e598355413974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598355413974 : Closed e598355413974 ∧ code e598355413974 = 2797378669526 := by decide
private def t_e598355413974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e598355413974 : ¬ IsSelfInterpreter e598355413974 :=
  wSource (t := t_e598355413974) (replay_sound (ps := []) (t := e598355413974) (by decide)) (by decide)
def e598355413978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598355413978 : Closed e598355413978 ∧ code e598355413978 = 2797378669530 := by decide
private def t_e598355413978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e598355413978 : ¬ IsSelfInterpreter e598355413978 :=
  wSource (t := t_e598355413978) (replay_sound (ps := []) (t := e598355413978) (by decide)) (by decide)
def e598355414254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598355414254 : Closed e598355414254 ∧ code e598355414254 = 2797378669806 := by decide
private def t_e598355414254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e598355414254 : ¬ IsSelfInterpreter e598355414254 :=
  wSource (t := t_e598355414254) (replay_sound (ps := []) (t := e598355414254) (by decide)) (by decide)
def e598355414262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598355414262 : Closed e598355414262 ∧ code e598355414262 = 2797378669814 := by decide
private def t_e598355414262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e598355414262 : ¬ IsSelfInterpreter e598355414262 :=
  wSource (t := t_e598355414262) (replay_sound (ps := []) (t := e598355414262) (by decide)) (by decide)
def e598355414638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598355414638 : Closed e598355414638 ∧ code e598355414638 = 2797378670190 := by decide
private def t_e598355414638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e598355414638 : ¬ IsSelfInterpreter e598355414638 :=
  wSource (t := t_e598355414638) (replay_sound (ps := []) (t := e598355414638) (by decide)) (by decide)
def e598355414650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598355414650 : Closed e598355414650 ∧ code e598355414650 = 2797378670202 := by decide
private def t_e598355414650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e598355414650 : ¬ IsSelfInterpreter e598355414650 :=
  wSource (t := t_e598355414650) (replay_sound (ps := []) (t := e598355414650) (by decide)) (by decide)
def e598355414838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598355414838 : Closed e598355414838 ∧ code e598355414838 = 2797378670390 := by decide
private def t_e598355414838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e598355414838 : ¬ IsSelfInterpreter e598355414838 :=
  wSource (t := t_e598355414838) (replay_sound (ps := []) (t := e598355414838) (by decide)) (by decide)
def e598355414842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598355414842 : Closed e598355414842 ∧ code e598355414842 = 2797378670394 := by decide
private def t_e598355414842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e598355414842 : ¬ IsSelfInterpreter e598355414842 :=
  wSource (t := t_e598355414842) (replay_sound (ps := []) (t := e598355414842) (by decide)) (by decide)
def e598356003694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598356003694 : Closed e598356003694 ∧ code e598356003694 = 2797379259246 := by decide
def e598356003702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598356003702 : Closed e598356003702 ∧ code e598356003702 = 2797379259254 := by decide
def e598356003758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598356003758 : Closed e598356003758 ∧ code e598356003758 = 2797379259310 := by decide
def e598356003770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598356003770 : Closed e598356003770 ∧ code e598356003770 = 2797379259322 := by decide
private def t_e598356003770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e598356003770 : ¬ IsSelfInterpreter e598356003770 :=
  wSource (t := t_e598356003770) (replay_sound (ps := []) (t := e598356003770) (by decide)) (by decide)
def e598356003798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598356003798 : Closed e598356003798 ∧ code e598356003798 = 2797379259350 := by decide
def e598356003802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598356003802 : Closed e598356003802 ∧ code e598356003802 = 2797379259354 := by decide
private def t_e598356003802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e598356003802 : ¬ IsSelfInterpreter e598356003802 :=
  wSource (t := t_e598356003802) (replay_sound (ps := []) (t := e598356003802) (by decide)) (by decide)
def e598356004078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598356004078 : Closed e598356004078 ∧ code e598356004078 = 2797379259630 := by decide
def e598356004086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598356004086 : Closed e598356004086 ∧ code e598356004086 = 2797379259638 := by decide
def e598356004462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598356004462 : Closed e598356004462 ∧ code e598356004462 = 2797379260014 := by decide
def e598356004474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598356004474 : Closed e598356004474 ∧ code e598356004474 = 2797379260026 := by decide
def e598356004662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598356004662 : Closed e598356004662 ∧ code e598356004662 = 2797379260214 := by decide
def e598356004666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598356004666 : Closed e598356004666 ∧ code e598356004666 = 2797379260218 := by decide
def e601343377606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601343377606 : Closed e601343377606 ∧ code e601343377606 = 2800366633158 := by decide
theorem cert_e601343377606 : check e601343377606 [[]] .width = true := by decide
def e601343516698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601343516698 : Closed e601343516698 ∧ code e601343516698 = 2800366772250 := by decide
theorem cert_e601343516698 : check e601343516698 [[]] .width = true := by decide
def e601343516790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601343516790 : Closed e601343516790 ∧ code e601343516790 = 2800366772342 := by decide
theorem cert_e601343516790 : check e601343516790 [[]] .width = true := by decide
def e601343517034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601343517034 : Closed e601343517034 ∧ code e601343517034 = 2800366772586 := by decide
theorem cert_e601343517034 : check e601343517034 [[]] .width = true := by decide
def e601343517082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601343517082 : Closed e601343517082 ∧ code e601343517082 = 2800366772634 := by decide
theorem cert_e601343517082 : check e601343517082 [[]] .width = true := by decide
def e601343574214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601343574214 : Closed e601343574214 ∧ code e601343574214 = 2800366829766 := by decide
theorem cert_e601343574214 : check e601343574214 [[]] .width = true := by decide
def e601343582234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601343582234 : Closed e601343582234 ∧ code e601343582234 = 2800366837786 := by decide
theorem cert_e601343582234 : check e601343582234 [[]] .width = true := by decide
def e601343582326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601343582326 : Closed e601343582326 ∧ code e601343582326 = 2800366837878 := by decide
theorem cert_e601343582326 : check e601343582326 [[]] .width = true := by decide
def e601343582570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601343582570 : Closed e601343582570 ∧ code e601343582570 = 2800366838122 := by decide
theorem cert_e601343582570 : check e601343582570 [[]] .width = true := by decide
def e601343582618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601343582618 : Closed e601343582618 ∧ code e601343582618 = 2800366838170 := by decide
theorem cert_e601343582618 : check e601343582618 [[]] .width = true := by decide
def e601344426182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601344426182 : Closed e601344426182 ∧ code e601344426182 = 2800367681734 := by decide
theorem cert_e601344426182 : check e601344426182 [[]] .width = true := by decide
def e601344635078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601344635078 : Closed e601344635078 ∧ code e601344635078 = 2800367890630 := by decide
theorem cert_e601344635078 : check e601344635078 [[]] .width = true := by decide
def e601344655558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601344655558 : Closed e601344655558 ∧ code e601344655558 = 2800367911110 := by decide
theorem cert_e601344655558 : check e601344655558 [[]] .width = true := by decide
def e601344667846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601344667846 : Closed e601344667846 ∧ code e601344667846 = 2800367923398 := by decide
theorem cert_e601344667846 : check e601344667846 [[]] .width = true := by decide
def e601345089562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601345089562 : Closed e601345089562 ∧ code e601345089562 = 2800368345114 := by decide
theorem cert_e601345089562 : check e601345089562 [[]] .width = true := by decide
def e601345089654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601345089654 : Closed e601345089654 ∧ code e601345089654 = 2800368345206 := by decide
theorem cert_e601345089654 : check e601345089654 [[]] .width = true := by decide
def e601345089898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601345089898 : Closed e601345089898 ∧ code e601345089898 = 2800368345450 := by decide
theorem cert_e601345089898 : check e601345089898 [[]] .width = true := by decide
def e601345089946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601345089946 : Closed e601345089946 ∧ code e601345089946 = 2800368345498 := by decide
theorem cert_e601345089946 : check e601345089946 [[]] .width = true := by decide
def e601345159366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601345159366 : Closed e601345159366 ∧ code e601345159366 = 2800368414918 := by decide
theorem cert_e601345159366 : check e601345159366 [[]] .width = true := by decide
def e601345204250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601345204250 : Closed e601345204250 ∧ code e601345204250 = 2800368459802 := by decide
theorem cert_e601345204250 : check e601345204250 [[]] .width = true := by decide
def e601345204342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601345204342 : Closed e601345204342 ∧ code e601345204342 = 2800368459894 := by decide
private def t_e601345204342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e601345204342 : ¬ IsSelfInterpreter e601345204342 :=
  wSource (t := t_e601345204342) (replay_sound (ps := []) (t := e601345204342) (by decide)) (by decide)
def e601345204586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601345204586 : Closed e601345204586 ∧ code e601345204586 = 2800368460138 := by decide
private def t_e601345204586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e601345204586 : ¬ IsSelfInterpreter e601345204586 :=
  wSource (t := t_e601345204586) (replay_sound (ps := []) (t := e601345204586) (by decide)) (by decide)
def e601345204634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601345204634 : Closed e601345204634 ∧ code e601345204634 = 2800368460186 := by decide
private def t_e601345204634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e601345204634 : ¬ IsSelfInterpreter e601345204634 :=
  wSource (t := t_e601345204634) (replay_sound (ps := []) (t := e601345204634) (by decide)) (by decide)
def e601345208518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601345208518 : Closed e601345208518 ∧ code e601345208518 = 2800368464070 := by decide
theorem cert_e601345208518 : check e601345208518 [[]] .width = true := by decide
def e601345409222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601345409222 : Closed e601345409222 ∧ code e601345409222 = 2800368664774 := by decide
theorem cert_e601345409222 : check e601345409222 [[]] .width = true := by decide
def e601345417242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601345417242 : Closed e601345417242 ∧ code e601345417242 = 2800368672794 := by decide
theorem cert_e601345417242 : check e601345417242 [[]] .width = true := by decide
def e601345417334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601345417334 : Closed e601345417334 ∧ code e601345417334 = 2800368672886 := by decide
theorem cert_e601345417334 : check e601345417334 [[]] .width = true := by decide
def e601345417578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601345417578 : Closed e601345417578 ∧ code e601345417578 = 2800368673130 := by decide
theorem cert_e601345417578 : check e601345417578 [[]] .width = true := by decide
def e601345417626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601345417626 : Closed e601345417626 ∧ code e601345417626 = 2800368673178 := by decide
theorem cert_e601345417626 : check e601345417626 [[]] .width = true := by decide
def e601345441990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601345441990 : Closed e601345441990 ∧ code e601345441990 = 2800368697542 := by decide
theorem cert_e601345441990 : check e601345441990 [[]] .width = true := by decide
def e601345454278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601345454278 : Closed e601345454278 ∧ code e601345454278 = 2800368709830 := by decide
theorem cert_e601345454278 : check e601345454278 [[]] .width = true := by decide
def e601345466394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601345466394 : Closed e601345466394 ∧ code e601345466394 = 2800368721946 := by decide
theorem cert_e601345466394 : check e601345466394 [[]] .width = true := by decide
def e601345466486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601345466486 : Closed e601345466486 ∧ code e601345466486 = 2800368722038 := by decide
private def t_e601345466486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e601345466486 : ¬ IsSelfInterpreter e601345466486 :=
  wSource (t := t_e601345466486) (replay_sound (ps := []) (t := e601345466486) (by decide)) (by decide)
def e601345466730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601345466730 : Closed e601345466730 ∧ code e601345466730 = 2800368722282 := by decide
private def t_e601345466730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e601345466730 : ¬ IsSelfInterpreter e601345466730 :=
  wSource (t := t_e601345466730) (replay_sound (ps := []) (t := e601345466730) (by decide)) (by decide)
def e601345466778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601345466778 : Closed e601345466778 ∧ code e601345466778 = 2800368722330 := by decide
private def t_e601345466778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e601345466778 : ¬ IsSelfInterpreter e601345466778 :=
  wSource (t := t_e601345466778) (replay_sound (ps := []) (t := e601345466778) (by decide)) (by decide)
def e601345470662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601345470662 : Closed e601345470662 ∧ code e601345470662 = 2800368726214 := by decide
theorem cert_e601345470662 : check e601345470662 [[]] .width = true := by decide
def e601349669062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601349669062 : Closed e601349669062 ∧ code e601349669062 = 2800372924614 := by decide
theorem cert_e601349669062 : check e601349669062 [[]] .width = true := by decide
def e601349808154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601349808154 : Closed e601349808154 ∧ code e601349808154 = 2800373063706 := by decide
theorem cert_e601349808154 : check e601349808154 [[]] .width = true := by decide
def e601349808246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601349808246 : Closed e601349808246 ∧ code e601349808246 = 2800373063798 := by decide
theorem cert_e601349808246 : check e601349808246 [[]] .width = true := by decide
def e601349808490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601349808490 : Closed e601349808490 ∧ code e601349808490 = 2800373064042 := by decide
theorem cert_e601349808490 : check e601349808490 [[]] .width = true := by decide
def e601349808538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601349808538 : Closed e601349808538 ∧ code e601349808538 = 2800373064090 := by decide
theorem cert_e601349808538 : check e601349808538 [[]] .width = true := by decide
def e601349865670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601349865670 : Closed e601349865670 ∧ code e601349865670 = 2800373121222 := by decide
theorem cert_e601349865670 : check e601349865670 [[]] .width = true := by decide
def e601349873690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601349873690 : Closed e601349873690 ∧ code e601349873690 = 2800373129242 := by decide
theorem cert_e601349873690 : check e601349873690 [[]] .width = true := by decide
def e601349873782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601349873782 : Closed e601349873782 ∧ code e601349873782 = 2800373129334 := by decide
theorem cert_e601349873782 : check e601349873782 [[]] .width = true := by decide
def e601349874026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601349874026 : Closed e601349874026 ∧ code e601349874026 = 2800373129578 := by decide
theorem cert_e601349874026 : check e601349874026 [[]] .width = true := by decide
def e601349874074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601349874074 : Closed e601349874074 ∧ code e601349874074 = 2800373129626 := by decide
theorem cert_e601349874074 : check e601349874074 [[]] .width = true := by decide
def e601355960518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601355960518 : Closed e601355960518 ∧ code e601355960518 = 2800379216070 := by decide
theorem cert_e601355960518 : check e601355960518 [[]] .width = true := by decide
def e601356169414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601356169414 : Closed e601356169414 ∧ code e601356169414 = 2800379424966 := by decide
theorem cert_e601356169414 : check e601356169414 [[]] .width = true := by decide
def e601356189894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e601356189894 : Closed e601356189894 ∧ code e601356189894 = 2800379445446 := by decide
theorem cert_e601356189894 : check e601356189894 [[]] .width = true := by decide
def e601356202182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601356202182 : Closed e601356202182 ∧ code e601356202182 = 2800379457734 := by decide
theorem cert_e601356202182 : check e601356202182 [[]] .width = true := by decide
def e601359245338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601359245338 : Closed e601359245338 ∧ code e601359245338 = 2800382500890 := by decide
theorem cert_e601359245338 : check e601359245338 [[]] .width = true := by decide
def e601359245430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601359245430 : Closed e601359245430 ∧ code e601359245430 = 2800382500982 := by decide
theorem cert_e601359245430 : check e601359245430 [[]] .width = true := by decide
def e601359245674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601359245674 : Closed e601359245674 ∧ code e601359245674 = 2800382501226 := by decide
theorem cert_e601359245674 : check e601359245674 [[]] .width = true := by decide
def e601359245722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e601359245722 : Closed e601359245722 ∧ code e601359245722 = 2800382501274 := by decide
theorem cert_e601359245722 : check e601359245722 [[]] .width = true := by decide
def e601359315142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e601359315142 : Closed e601359315142 ∧ code e601359315142 = 2800382570694 := by decide
theorem cert_e601359315142 : check e601359315142 [[]] .width = true := by decide
def e601359360026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601359360026 : Closed e601359360026 ∧ code e601359360026 = 2800382615578 := by decide
theorem cert_e601359360026 : check e601359360026 [[]] .width = true := by decide
def e601359360118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e601359360118 : Closed e601359360118 ∧ code e601359360118 = 2800382615670 := by decide
theorem cert_e601359360118 : check e601359360118 [[]] .width = true := by decide
def e601359360362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e601359360362 : Closed e601359360362 ∧ code e601359360362 = 2800382615914 := by decide
theorem cert_e601359360362 : check e601359360362 [[]] .width = true := by decide
end Blc.Floor41
