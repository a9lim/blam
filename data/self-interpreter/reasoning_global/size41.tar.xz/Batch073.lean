import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605591095222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1))))))))
theorem wire_e605591095222 : Closed e605591095222 ∧ code e605591095222 = 2804614350774 := by decide
theorem cert_e605591095222 : check e605591095222 [[],[]] .smaller = true := by decide
def e605591095254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.var 1))))))))
theorem wire_e605591095254 : Closed e605591095254 ∧ code e605591095254 = 2804614350806 := by decide
theorem cert_e605591095254 : check e605591095254 [[],[]] .smaller = true := by decide
def e605591095258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.var 0))))))))
theorem wire_e605591095258 : Closed e605591095258 ∧ code e605591095258 = 2804614350810 := by decide
theorem cert_e605591095258 : check e605591095258 [[],[]] .smaller = true := by decide
def e605591096686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e605591096686 : Closed e605591096686 ∧ code e605591096686 = 2804614352238 := by decide
theorem cert_e605591096686 : check e605591096686 [[],[]] .smaller = true := by decide
def e605591096694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e605591096694 : Closed e605591096694 ∧ code e605591096694 = 2804614352246 := by decide
theorem cert_e605591096694 : check e605591096694 [[],[]] .smaller = true := by decide
def e605591096750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e605591096750 : Closed e605591096750 ∧ code e605591096750 = 2804614352302 := by decide
theorem cert_e605591096750 : check e605591096750 [[],[]] .smaller = true := by decide
def e605591096762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e605591096762 : Closed e605591096762 ∧ code e605591096762 = 2804614352314 := by decide
theorem cert_e605591096762 : check e605591096762 [[],[]] .smaller = true := by decide
def e605591096790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e605591096790 : Closed e605591096790 ∧ code e605591096790 = 2804614352342 := by decide
theorem cert_e605591096790 : check e605591096790 [[],[]] .smaller = true := by decide
def e605591096794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e605591096794 : Closed e605591096794 ∧ code e605591096794 = 2804614352346 := by decide
theorem cert_e605591096794 : check e605591096794 [[],[]] .smaller = true := by decide
def e605591097006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e605591097006 : Closed e605591097006 ∧ code e605591097006 = 2804614352558 := by decide
theorem cert_e605591097006 : check e605591097006 [[],[]] .smaller = true := by decide
def e605591097018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e605591097018 : Closed e605591097018 ∧ code e605591097018 = 2804614352570 := by decide
theorem cert_e605591097018 : check e605591097018 [[],[]] .smaller = true := by decide
def e605591097066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e605591097066 : Closed e605591097066 ∧ code e605591097066 = 2804614352618 := by decide
theorem cert_e605591097066 : check e605591097066 [[],[]] .smaller = true := by decide
def e605591097174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e605591097174 : Closed e605591097174 ∧ code e605591097174 = 2804614352726 := by decide
theorem cert_e605591097174 : check e605591097174 [[],[]] .smaller = true := by decide
def e605591097178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e605591097178 : Closed e605591097178 ∧ code e605591097178 = 2804614352730 := by decide
theorem cert_e605591097178 : check e605591097178 [[],[]] .smaller = true := by decide
def e605591097194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e605591097194 : Closed e605591097194 ∧ code e605591097194 = 2804614352746 := by decide
theorem cert_e605591097194 : check e605591097194 [[],[]] .smaller = true := by decide
def e605591097822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 3))))))))
theorem wire_e605591097822 : Closed e605591097822 ∧ code e605591097822 = 2804614353374 := by decide
theorem cert_e605591097822 : check e605591097822 [[],[]] .smaller = true := by decide
def e605591097846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 1))))))))
theorem wire_e605591097846 : Closed e605591097846 ∧ code e605591097846 = 2804614353398 := by decide
theorem cert_e605591097846 : check e605591097846 [[],[]] .smaller = true := by decide
def e605591098222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605591098222 : Closed e605591098222 ∧ code e605591098222 = 2804614353774 := by decide
theorem cert_e605591098222 : check e605591098222 [[],[]] .smaller = true := by decide
def e605591098230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605591098230 : Closed e605591098230 ∧ code e605591098230 = 2804614353782 := by decide
theorem cert_e605591098230 : check e605591098230 [[],[]] .smaller = true := by decide
def e605591098286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605591098286 : Closed e605591098286 ∧ code e605591098286 = 2804614353838 := by decide
theorem cert_e605591098286 : check e605591098286 [[],[]] .smaller = true := by decide
def e605591098298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605591098298 : Closed e605591098298 ∧ code e605591098298 = 2804614353850 := by decide
theorem cert_e605591098298 : check e605591098298 [[],[]] .smaller = true := by decide
def e605591098326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605591098326 : Closed e605591098326 ∧ code e605591098326 = 2804614353878 := by decide
theorem cert_e605591098326 : check e605591098326 [[],[]] .smaller = true := by decide
def e605591098330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605591098330 : Closed e605591098330 ∧ code e605591098330 = 2804614353882 := by decide
theorem cert_e605591098330 : check e605591098330 [[],[]] .smaller = true := by decide
def e605591098606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605591098606 : Closed e605591098606 ∧ code e605591098606 = 2804614354158 := by decide
theorem cert_e605591098606 : check e605591098606 [[],[]] .smaller = true := by decide
def e605591098614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605591098614 : Closed e605591098614 ∧ code e605591098614 = 2804614354166 := by decide
theorem cert_e605591098614 : check e605591098614 [[],[]] .smaller = true := by decide
def e605591098942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e605591098942 : Closed e605591098942 ∧ code e605591098942 = 2804614354494 := by decide
theorem cert_e605591098942 : check e605591098942 [[],[]] .smaller = true := by decide
def e605591098990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605591098990 : Closed e605591098990 ∧ code e605591098990 = 2804614354542 := by decide
theorem cert_e605591098990 : check e605591098990 [[],[]] .smaller = true := by decide
def e605591099002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605591099002 : Closed e605591099002 ∧ code e605591099002 = 2804614354554 := by decide
theorem cert_e605591099002 : check e605591099002 [[],[]] .smaller = true := by decide
def e605591099190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605591099190 : Closed e605591099190 ∧ code e605591099190 = 2804614354742 := by decide
theorem cert_e605591099190 : check e605591099190 [[],[]] .smaller = true := by decide
def e605591099194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605591099194 : Closed e605591099194 ∧ code e605591099194 = 2804614354746 := by decide
theorem cert_e605591099194 : check e605591099194 [[],[]] .smaller = true := by decide
def e605591099278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e605591099278 : Closed e605591099278 ∧ code e605591099278 = 2804614354830 := by decide
theorem cert_e605591099278 : check e605591099278 [[],[]] .smaller = true := by decide
def e605591099326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 4))))))))
theorem wire_e605591099326 : Closed e605591099326 ∧ code e605591099326 = 2804614354878 := by decide
theorem cert_e605591099326 : check e605591099326 [[],[]] .three = true := by decide
def e605591099358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 3))))))))
theorem wire_e605591099358 : Closed e605591099358 ∧ code e605591099358 = 2804614354910 := by decide
theorem cert_e605591099358 : check e605591099358 [[],[]] .three = true := by decide
def e605591099614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 3))))))))
theorem wire_e605591099614 : Closed e605591099614 ∧ code e605591099614 = 2804614355166 := by decide
theorem cert_e605591099614 : check e605591099614 [[],[]] .smaller = true := by decide
def e605591099630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605591099630 : Closed e605591099630 ∧ code e605591099630 = 2804614355182 := by decide
theorem cert_e605591099630 : check e605591099630 [[],[]] .smaller = true := by decide
def e605591099638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605591099638 : Closed e605591099638 ∧ code e605591099638 = 2804614355190 := by decide
theorem cert_e605591099638 : check e605591099638 [[],[]] .smaller = true := by decide
def e605591099642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.var 0))))))))
theorem wire_e605591099642 : Closed e605591099642 ∧ code e605591099642 = 2804614355194 := by decide
theorem cert_e605591099642 : check e605591099642 [[],[]] .smaller = true := by decide
def e605591099822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605591099822 : Closed e605591099822 ∧ code e605591099822 = 2804614355374 := by decide
theorem cert_e605591099822 : check e605591099822 [[],[]] .smaller = true := by decide
def e605591099834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605591099834 : Closed e605591099834 ∧ code e605591099834 = 2804614355386 := by decide
theorem cert_e605591099834 : check e605591099834 [[],[]] .smaller = true := by decide
def e605591099882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605591099882 : Closed e605591099882 ∧ code e605591099882 = 2804614355434 := by decide
theorem cert_e605591099882 : check e605591099882 [[],[]] .smaller = true := by decide
def e605591099966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e605591099966 : Closed e605591099966 ∧ code e605591099966 = 2804614355518 := by decide
theorem cert_e605591099966 : check e605591099966 [[],[]] .smaller = true := by decide
def e605591100014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605591100014 : Closed e605591100014 ∧ code e605591100014 = 2804614355566 := by decide
theorem cert_e605591100014 : check e605591100014 [[],[]] .smaller = true := by decide
def e605591100026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605591100026 : Closed e605591100026 ∧ code e605591100026 = 2804614355578 := by decide
theorem cert_e605591100026 : check e605591100026 [[],[]] .smaller = true := by decide
def e605591100190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605591100190 : Closed e605591100190 ∧ code e605591100190 = 2804614355742 := by decide
theorem cert_e605591100190 : check e605591100190 [[],[]] .smaller = true := by decide
def e605591100302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605591100302 : Closed e605591100302 ∧ code e605591100302 = 2804614355854 := by decide
theorem cert_e605591100302 : check e605591100302 [[],[]] .smaller = true := by decide
def e605591100314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591100314 : Closed e605591100314 ∧ code e605591100314 = 2804614355866 := by decide
theorem cert_e605591100314 : check e605591100314 [[],[]] .smaller = true := by decide
def e605591100358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e605591100358 : Closed e605591100358 ∧ code e605591100358 = 2804614355910 := by decide
theorem cert_e605591100358 : check e605591100358 [[],[]] .smaller = true := by decide
def e605591100382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 3))))))))
theorem wire_e605591100382 : Closed e605591100382 ∧ code e605591100382 = 2804614355934 := by decide
theorem cert_e605591100382 : check e605591100382 [[],[]] .smaller = true := by decide
def e605591100534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e605591100534 : Closed e605591100534 ∧ code e605591100534 = 2804614356086 := by decide
theorem cert_e605591100534 : check e605591100534 [[],[]] .smaller = true := by decide
def e605591100630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605591100630 : Closed e605591100630 ∧ code e605591100630 = 2804614356182 := by decide
theorem cert_e605591100630 : check e605591100630 [[],[]] .smaller = true := by decide
def e605591100634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605591100634 : Closed e605591100634 ∧ code e605591100634 = 2804614356186 := by decide
theorem cert_e605591100634 : check e605591100634 [[],[]] .smaller = true := by decide
def e605591100650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605591100650 : Closed e605591100650 ∧ code e605591100650 = 2804614356202 := by decide
theorem cert_e605591100650 : check e605591100650 [[],[]] .smaller = true := by decide
def e605591100726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605591100726 : Closed e605591100726 ∧ code e605591100726 = 2804614356278 := by decide
theorem cert_e605591100726 : check e605591100726 [[],[]] .smaller = true := by decide
def e605591100730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605591100730 : Closed e605591100730 ∧ code e605591100730 = 2804614356282 := by decide
theorem cert_e605591100730 : check e605591100730 [[],[]] .smaller = true := by decide
def e605591100814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e605591100814 : Closed e605591100814 ∧ code e605591100814 = 2804614356366 := by decide
theorem cert_e605591100814 : check e605591100814 [[],[]] .smaller = true := by decide
def e605591100826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591100826 : Closed e605591100826 ∧ code e605591100826 = 2804614356378 := by decide
theorem cert_e605591100826 : check e605591100826 [[],[]] .smaller = true := by decide
def e605591100894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 3))))))))
theorem wire_e605591100894 : Closed e605591100894 ∧ code e605591100894 = 2804614356446 := by decide
theorem cert_e605591100894 : check e605591100894 [[],[]] .smaller = true := by decide
def e605591100910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 2))))))))
theorem wire_e605591100910 : Closed e605591100910 ∧ code e605591100910 = 2804614356462 := by decide
theorem cert_e605591100910 : check e605591100910 [[],[]] .smaller = true := by decide
def e605591100982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605591100982 : Closed e605591100982 ∧ code e605591100982 = 2804614356534 := by decide
theorem cert_e605591100982 : check e605591100982 [[],[]] .smaller = true := by decide
def e605591100986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605591100986 : Closed e605591100986 ∧ code e605591100986 = 2804614356538 := by decide
theorem cert_e605591100986 : check e605591100986 [[],[]] .smaller = true := by decide
def e605591101070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605591101070 : Closed e605591101070 ∧ code e605591101070 = 2804614356622 := by decide
theorem cert_e605591101070 : check e605591101070 [[],[]] .smaller = true := by decide
def e605591101118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 4))))))))
theorem wire_e605591101118 : Closed e605591101118 ∧ code e605591101118 = 2804614356670 := by decide
theorem cert_e605591101118 : check e605591101118 [[],[]] .three = true := by decide
def e605591101126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605591101126 : Closed e605591101126 ∧ code e605591101126 = 2804614356678 := by decide
theorem cert_e605591101126 : check e605591101126 [[],[]] .smaller = true := by decide
def e605591101150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 3))))))))
theorem wire_e605591101150 : Closed e605591101150 ∧ code e605591101150 = 2804614356702 := by decide
theorem cert_e605591101150 : check e605591101150 [[],[]] .smaller = true := by decide
def e605591101166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 2))))))))
theorem wire_e605591101166 : Closed e605591101166 ∧ code e605591101166 = 2804614356718 := by decide
theorem cert_e605591101166 : check e605591101166 [[],[]] .smaller = true := by decide
def e605591101174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 1))))))))
theorem wire_e605591101174 : Closed e605591101174 ∧ code e605591101174 = 2804614356726 := by decide
theorem cert_e605591101174 : check e605591101174 [[],[]] .smaller = true := by decide
def e605591101178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 4)) (.var 0))))))))
theorem wire_e605591101178 : Closed e605591101178 ∧ code e605591101178 = 2804614356730 := by decide
theorem cert_e605591101178 : check e605591101178 [[],[]] .three = true := by decide
def e605591101278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 3))))))))
theorem wire_e605591101278 : Closed e605591101278 ∧ code e605591101278 = 2804614356830 := by decide
theorem cert_e605591101278 : check e605591101278 [[],[]] .three = true := by decide
def e605591101306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 3)) (.var 0))))))))
theorem wire_e605591101306 : Closed e605591101306 ∧ code e605591101306 = 2804614356858 := by decide
theorem cert_e605591101306 : check e605591101306 [[],[]] .three = true := by decide
def e605591102302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 3))))))))
theorem wire_e605591102302 : Closed e605591102302 ∧ code e605591102302 = 2804614357854 := by decide
theorem cert_e605591102302 : check e605591102302 [[],[]] .smaller = true := by decide
def e605591102318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e605591102318 : Closed e605591102318 ∧ code e605591102318 = 2804614357870 := by decide
theorem cert_e605591102318 : check e605591102318 [[],[]] .smaller = true := by decide
def e605591102326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e605591102326 : Closed e605591102326 ∧ code e605591102326 = 2804614357878 := by decide
theorem cert_e605591102326 : check e605591102326 [[],[]] .smaller = true := by decide
def e605591102330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.var 0))))))))
theorem wire_e605591102330 : Closed e605591102330 ∧ code e605591102330 = 2804614357882 := by decide
theorem cert_e605591102330 : check e605591102330 [[],[]] .smaller = true := by decide
def e605591102382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e605591102382 : Closed e605591102382 ∧ code e605591102382 = 2804614357934 := by decide
theorem cert_e605591102382 : check e605591102382 [[],[]] .smaller = true := by decide
def e605591102394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e605591102394 : Closed e605591102394 ∧ code e605591102394 = 2804614357946 := by decide
theorem cert_e605591102394 : check e605591102394 [[],[]] .smaller = true := by decide
def e605591102422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e605591102422 : Closed e605591102422 ∧ code e605591102422 = 2804614357974 := by decide
theorem cert_e605591102422 : check e605591102422 [[],[]] .smaller = true := by decide
def e605591102426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e605591102426 : Closed e605591102426 ∧ code e605591102426 = 2804614357978 := by decide
theorem cert_e605591102426 : check e605591102426 [[],[]] .smaller = true := by decide
def e605591102442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.var 0))))))))
theorem wire_e605591102442 : Closed e605591102442 ∧ code e605591102442 = 2804614357994 := by decide
theorem cert_e605591102442 : check e605591102442 [[],[]] .smaller = true := by decide
def e605591103150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e605591103150 : Closed e605591103150 ∧ code e605591103150 = 2804614358702 := by decide
theorem cert_e605591103150 : check e605591103150 [[],[]] .smaller = true := by decide
def e605591103162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e605591103162 : Closed e605591103162 ∧ code e605591103162 = 2804614358714 := by decide
theorem cert_e605591103162 : check e605591103162 [[],[]] .smaller = true := by decide
def e605591103210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e605591103210 : Closed e605591103210 ∧ code e605591103210 = 2804614358762 := by decide
theorem cert_e605591103210 : check e605591103210 [[],[]] .smaller = true := by decide
def e605591103402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e605591103402 : Closed e605591103402 ∧ code e605591103402 = 2804614358954 := by decide
theorem cert_e605591103402 : check e605591103402 [[],[]] .smaller = true := by decide
def e605591103710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 3))))))))
theorem wire_e605591103710 : Closed e605591103710 ∧ code e605591103710 = 2804614359262 := by decide
theorem cert_e605591103710 : check e605591103710 [[],[]] .smaller = true := by decide
def e605591103726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605591103726 : Closed e605591103726 ∧ code e605591103726 = 2804614359278 := by decide
theorem cert_e605591103726 : check e605591103726 [[],[]] .smaller = true := by decide
def e605591103734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605591103734 : Closed e605591103734 ∧ code e605591103734 = 2804614359286 := by decide
theorem cert_e605591103734 : check e605591103734 [[],[]] .smaller = true := by decide
def e605591103738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.var 0))))))))
theorem wire_e605591103738 : Closed e605591103738 ∧ code e605591103738 = 2804614359290 := by decide
theorem cert_e605591103738 : check e605591103738 [[],[]] .smaller = true := by decide
def e605591103918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605591103918 : Closed e605591103918 ∧ code e605591103918 = 2804614359470 := by decide
theorem cert_e605591103918 : check e605591103918 [[],[]] .smaller = true := by decide
def e605591103930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605591103930 : Closed e605591103930 ∧ code e605591103930 = 2804614359482 := by decide
theorem cert_e605591103930 : check e605591103930 [[],[]] .smaller = true := by decide
def e605591103978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605591103978 : Closed e605591103978 ∧ code e605591103978 = 2804614359530 := by decide
theorem cert_e605591103978 : check e605591103978 [[],[]] .smaller = true := by decide
def e605591104062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e605591104062 : Closed e605591104062 ∧ code e605591104062 = 2804614359614 := by decide
theorem cert_e605591104062 : check e605591104062 [[],[]] .smaller = true := by decide
def e605591104110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605591104110 : Closed e605591104110 ∧ code e605591104110 = 2804614359662 := by decide
theorem cert_e605591104110 : check e605591104110 [[],[]] .smaller = true := by decide
def e605591104122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605591104122 : Closed e605591104122 ∧ code e605591104122 = 2804614359674 := by decide
theorem cert_e605591104122 : check e605591104122 [[],[]] .smaller = true := by decide
def e605591104286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605591104286 : Closed e605591104286 ∧ code e605591104286 = 2804614359838 := by decide
theorem cert_e605591104286 : check e605591104286 [[],[]] .smaller = true := by decide
def e605591104398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605591104398 : Closed e605591104398 ∧ code e605591104398 = 2804614359950 := by decide
theorem cert_e605591104398 : check e605591104398 [[],[]] .smaller = true := by decide
def e605591104410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591104410 : Closed e605591104410 ∧ code e605591104410 = 2804614359962 := by decide
theorem cert_e605591104410 : check e605591104410 [[],[]] .smaller = true := by decide
def e605591104454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e605591104454 : Closed e605591104454 ∧ code e605591104454 = 2804614360006 := by decide
theorem cert_e605591104454 : check e605591104454 [[],[]] .smaller = true := by decide
def e605591104478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 3))))))))
theorem wire_e605591104478 : Closed e605591104478 ∧ code e605591104478 = 2804614360030 := by decide
theorem cert_e605591104478 : check e605591104478 [[],[]] .smaller = true := by decide
def e605591104622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605591104622 : Closed e605591104622 ∧ code e605591104622 = 2804614360174 := by decide
theorem cert_e605591104622 : check e605591104622 [[],[]] .smaller = true := by decide
def e605591104634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605591104634 : Closed e605591104634 ∧ code e605591104634 = 2804614360186 := by decide
theorem cert_e605591104634 : check e605591104634 [[],[]] .smaller = true := by decide
def e605591104798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605591104798 : Closed e605591104798 ∧ code e605591104798 = 2804614360350 := by decide
theorem cert_e605591104798 : check e605591104798 [[],[]] .smaller = true := by decide
def e605591104966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605591104966 : Closed e605591104966 ∧ code e605591104966 = 2804614360518 := by decide
theorem cert_e605591104966 : check e605591104966 [[],[]] .smaller = true := by decide
def e605591104990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e605591104990 : Closed e605591104990 ∧ code e605591104990 = 2804614360542 := by decide
theorem cert_e605591104990 : check e605591104990 [[],[]] .smaller = true := by decide
def e605591105006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e605591105006 : Closed e605591105006 ∧ code e605591105006 = 2804614360558 := by decide
theorem cert_e605591105006 : check e605591105006 [[],[]] .smaller = true := by decide
def e605591105078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605591105078 : Closed e605591105078 ∧ code e605591105078 = 2804614360630 := by decide
theorem cert_e605591105078 : check e605591105078 [[],[]] .smaller = true := by decide
def e605591105082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605591105082 : Closed e605591105082 ∧ code e605591105082 = 2804614360634 := by decide
theorem cert_e605591105082 : check e605591105082 [[],[]] .smaller = true := by decide
def e605591105130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605591105130 : Closed e605591105130 ∧ code e605591105130 = 2804614360682 := by decide
theorem cert_e605591105130 : check e605591105130 [[],[]] .smaller = true := by decide
def e605591105166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605591105166 : Closed e605591105166 ∧ code e605591105166 = 2804614360718 := by decide
theorem cert_e605591105166 : check e605591105166 [[],[]] .smaller = true := by decide
def e605591105178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591105178 : Closed e605591105178 ∧ code e605591105178 = 2804614360730 := by decide
theorem cert_e605591105178 : check e605591105178 [[],[]] .smaller = true := by decide
def e605591105222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605591105222 : Closed e605591105222 ∧ code e605591105222 = 2804614360774 := by decide
theorem cert_e605591105222 : check e605591105222 [[],[]] .smaller = true := by decide
def e605591105246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e605591105246 : Closed e605591105246 ∧ code e605591105246 = 2804614360798 := by decide
theorem cert_e605591105246 : check e605591105246 [[],[]] .smaller = true := by decide
def e605591105270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e605591105270 : Closed e605591105270 ∧ code e605591105270 = 2804614360822 := by decide
theorem cert_e605591105270 : check e605591105270 [[],[]] .smaller = true := by decide
def e605591105306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e605591105306 : Closed e605591105306 ∧ code e605591105306 = 2804614360858 := by decide
theorem cert_e605591105306 : check e605591105306 [[],[]] .smaller = true := by decide
def e605591105350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e605591105350 : Closed e605591105350 ∧ code e605591105350 = 2804614360902 := by decide
theorem cert_e605591105350 : check e605591105350 [[],[]] .smaller = true := by decide
def e605591105374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 3))))))))
theorem wire_e605591105374 : Closed e605591105374 ∧ code e605591105374 = 2804614360926 := by decide
theorem cert_e605591105374 : check e605591105374 [[],[]] .smaller = true := by decide
def e605591105390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e605591105390 : Closed e605591105390 ∧ code e605591105390 = 2804614360942 := by decide
theorem cert_e605591105390 : check e605591105390 [[],[]] .smaller = true := by decide
def e605591105398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e605591105398 : Closed e605591105398 ∧ code e605591105398 = 2804614360950 := by decide
theorem cert_e605591105398 : check e605591105398 [[],[]] .smaller = true := by decide
def e605591105402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 3)) (.var 0))))))))
theorem wire_e605591105402 : Closed e605591105402 ∧ code e605591105402 = 2804614360954 := by decide
theorem cert_e605591105402 : check e605591105402 [[],[]] .smaller = true := by decide
def e605591105974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1))))))))
theorem wire_e605591105974 : Closed e605591105974 ∧ code e605591105974 = 2804614361526 := by decide
theorem cert_e605591105974 : check e605591105974 [[],[]] .smaller = true := by decide
def e605591106006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e605591106006 : Closed e605591106006 ∧ code e605591106006 = 2804614361558 := by decide
theorem cert_e605591106006 : check e605591106006 [[],[]] .smaller = true := by decide
def e605591106010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e605591106010 : Closed e605591106010 ∧ code e605591106010 = 2804614361562 := by decide
theorem cert_e605591106010 : check e605591106010 [[],[]] .smaller = true := by decide
def e605591106390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e605591106390 : Closed e605591106390 ∧ code e605591106390 = 2804614361942 := by decide
theorem cert_e605591106390 : check e605591106390 [[],[]] .smaller = true := by decide
def e605591106394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e605591106394 : Closed e605591106394 ∧ code e605591106394 = 2804614361946 := by decide
theorem cert_e605591106394 : check e605591106394 [[],[]] .smaller = true := by decide
def e605591106410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e605591106410 : Closed e605591106410 ∧ code e605591106410 = 2804614361962 := by decide
theorem cert_e605591106410 : check e605591106410 [[],[]] .smaller = true := by decide
def e605591106474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e605591106474 : Closed e605591106474 ∧ code e605591106474 = 2804614362026 := by decide
theorem cert_e605591106474 : check e605591106474 [[],[]] .smaller = true := by decide
def e605591106678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e605591106678 : Closed e605591106678 ∧ code e605591106678 = 2804614362230 := by decide
theorem cert_e605591106678 : check e605591106678 [[],[]] .smaller = true := by decide
def e605591106774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605591106774 : Closed e605591106774 ∧ code e605591106774 = 2804614362326 := by decide
theorem cert_e605591106774 : check e605591106774 [[],[]] .smaller = true := by decide
def e605591106778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605591106778 : Closed e605591106778 ∧ code e605591106778 = 2804614362330 := by decide
theorem cert_e605591106778 : check e605591106778 [[],[]] .smaller = true := by decide
def e605591106794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605591106794 : Closed e605591106794 ∧ code e605591106794 = 2804614362346 := by decide
theorem cert_e605591106794 : check e605591106794 [[],[]] .smaller = true := by decide
def e605591106870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605591106870 : Closed e605591106870 ∧ code e605591106870 = 2804614362422 := by decide
theorem cert_e605591106870 : check e605591106870 [[],[]] .smaller = true := by decide
def e605591106874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605591106874 : Closed e605591106874 ∧ code e605591106874 = 2804614362426 := by decide
theorem cert_e605591106874 : check e605591106874 [[],[]] .smaller = true := by decide
def e605591106958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e605591106958 : Closed e605591106958 ∧ code e605591106958 = 2804614362510 := by decide
theorem cert_e605591106958 : check e605591106958 [[],[]] .smaller = true := by decide
def e605591106970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591106970 : Closed e605591106970 ∧ code e605591106970 = 2804614362522 := by decide
theorem cert_e605591106970 : check e605591106970 [[],[]] .smaller = true := by decide
def e605591107038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e605591107038 : Closed e605591107038 ∧ code e605591107038 = 2804614362590 := by decide
theorem cert_e605591107038 : check e605591107038 [[],[]] .smaller = true := by decide
def e605591107054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e605591107054 : Closed e605591107054 ∧ code e605591107054 = 2804614362606 := by decide
theorem cert_e605591107054 : check e605591107054 [[],[]] .smaller = true := by decide
def e605591107126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605591107126 : Closed e605591107126 ∧ code e605591107126 = 2804614362678 := by decide
theorem cert_e605591107126 : check e605591107126 [[],[]] .smaller = true := by decide
def e605591107130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605591107130 : Closed e605591107130 ∧ code e605591107130 = 2804614362682 := by decide
theorem cert_e605591107130 : check e605591107130 [[],[]] .smaller = true := by decide
def e605591107178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605591107178 : Closed e605591107178 ∧ code e605591107178 = 2804614362730 := by decide
theorem cert_e605591107178 : check e605591107178 [[],[]] .smaller = true := by decide
def e605591107214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605591107214 : Closed e605591107214 ∧ code e605591107214 = 2804614362766 := by decide
theorem cert_e605591107214 : check e605591107214 [[],[]] .smaller = true := by decide
def e605591107226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605591107226 : Closed e605591107226 ∧ code e605591107226 = 2804614362778 := by decide
theorem cert_e605591107226 : check e605591107226 [[],[]] .smaller = true := by decide
def e605591107270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605591107270 : Closed e605591107270 ∧ code e605591107270 = 2804614362822 := by decide
theorem cert_e605591107270 : check e605591107270 [[],[]] .smaller = true := by decide
def e605591107294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e605591107294 : Closed e605591107294 ∧ code e605591107294 = 2804614362846 := by decide
theorem cert_e605591107294 : check e605591107294 [[],[]] .smaller = true := by decide
def e605591107318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e605591107318 : Closed e605591107318 ∧ code e605591107318 = 2804614362870 := by decide
theorem cert_e605591107318 : check e605591107318 [[],[]] .smaller = true := by decide
def e605591107422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e605591107422 : Closed e605591107422 ∧ code e605591107422 = 2804614362974 := by decide
theorem cert_e605591107422 : check e605591107422 [[],[]] .smaller = true := by decide
def e605591107450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e605591107450 : Closed e605591107450 ∧ code e605591107450 = 2804614363002 := by decide
theorem cert_e605591107450 : check e605591107450 [[],[]] .smaller = true := by decide
def e605591107502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e605591107502 : Closed e605591107502 ∧ code e605591107502 = 2804614363054 := by decide
theorem cert_e605591107502 : check e605591107502 [[],[]] .smaller = true := by decide
def e605591107510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e605591107510 : Closed e605591107510 ∧ code e605591107510 = 2804614363062 := by decide
theorem cert_e605591107510 : check e605591107510 [[],[]] .smaller = true := by decide
def e605591107514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e605591107514 : Closed e605591107514 ∧ code e605591107514 = 2804614363066 := by decide
theorem cert_e605591107514 : check e605591107514 [[],[]] .smaller = true := by decide
def e605591107798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e605591107798 : Closed e605591107798 ∧ code e605591107798 = 2804614363350 := by decide
theorem cert_e605591107798 : check e605591107798 [[],[]] .smaller = true := by decide
def e605591107802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e605591107802 : Closed e605591107802 ∧ code e605591107802 = 2804614363354 := by decide
theorem cert_e605591107802 : check e605591107802 [[],[]] .smaller = true := by decide
def e605591107818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e605591107818 : Closed e605591107818 ∧ code e605591107818 = 2804614363370 := by decide
theorem cert_e605591107818 : check e605591107818 [[],[]] .smaller = true := by decide
def e605591108150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605591108150 : Closed e605591108150 ∧ code e605591108150 = 2804614363702 := by decide
theorem cert_e605591108150 : check e605591108150 [[],[]] .smaller = true := by decide
def e605591108154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605591108154 : Closed e605591108154 ∧ code e605591108154 = 2804614363706 := by decide
theorem cert_e605591108154 : check e605591108154 [[],[]] .smaller = true := by decide
def e605591108238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605591108238 : Closed e605591108238 ∧ code e605591108238 = 2804614363790 := by decide
theorem cert_e605591108238 : check e605591108238 [[],[]] .smaller = true := by decide
def e605591108286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 4))))))))
theorem wire_e605591108286 : Closed e605591108286 ∧ code e605591108286 = 2804614363838 := by decide
theorem cert_e605591108286 : check e605591108286 [[],[]] .three = true := by decide
def e605591108294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605591108294 : Closed e605591108294 ∧ code e605591108294 = 2804614363846 := by decide
theorem cert_e605591108294 : check e605591108294 [[],[]] .smaller = true := by decide
def e605591108318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e605591108318 : Closed e605591108318 ∧ code e605591108318 = 2804614363870 := by decide
theorem cert_e605591108318 : check e605591108318 [[],[]] .smaller = true := by decide
def e605591108334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e605591108334 : Closed e605591108334 ∧ code e605591108334 = 2804614363886 := by decide
theorem cert_e605591108334 : check e605591108334 [[],[]] .smaller = true := by decide
def e605591108342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e605591108342 : Closed e605591108342 ∧ code e605591108342 = 2804614363894 := by decide
theorem cert_e605591108342 : check e605591108342 [[],[]] .smaller = true := by decide
def e605591108346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 4)) (.var 0))))))))
theorem wire_e605591108346 : Closed e605591108346 ∧ code e605591108346 = 2804614363898 := by decide
theorem cert_e605591108346 : check e605591108346 [[],[]] .three = true := by decide
def e605591108378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e605591108378 : Closed e605591108378 ∧ code e605591108378 = 2804614363930 := by decide
theorem cert_e605591108378 : check e605591108378 [[],[]] .smaller = true := by decide
end Blc.Floor41
