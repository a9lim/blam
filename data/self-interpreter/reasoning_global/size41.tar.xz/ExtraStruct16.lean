import Extra41
import Batch070
import Batch116
import Batch119
import Batch138
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness604798455030
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u0 u1
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u0 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := SO.app sou0 sou1
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private def u14 := Term.app u5 u0
private def u15 := Term.app u0 u5
private theorem sou4 : SO u4 := SO.var 2
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou0 sou6
private theorem sou14 : SO u14 := SO.app sou5 sou0
private theorem sou8 : SO u8 := SO.lam (r := u14) (g := u15) sou7 sou14 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.lam (r := u0) (g := u8) sou8 sou0 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.app sou0 sou9
private theorem sou11 : SO u11 := SO.app sou0 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege604798455030 : ¬ IsSelfInterpreter e604798455030 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege604798455030
end Witness604798455030
namespace Witness604798455606
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u0 u1
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege604798455606 : ¬ IsSelfInterpreter e604798455606 := by
  intro he
  have h : replay [] e604798455606 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege604798455606
end Witness604798455606
namespace Witness604798455610
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u0 u1
private def u3 := Term.lam u2
private def u4 := Term.var 2
private def u5 := Term.var 1
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u0 u9
private def u11 := Term.app u0 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
theorem nege604798455610 : ¬ IsSelfInterpreter e604798455610 := by
  intro he
  have h : replay [] e604798455610 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege604798455610
end Witness604798455610
namespace Witness605603690338
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u3
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.lam u0
private def u8 := Term.app u6 u7
private def u9 := Term.app u0 u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u14 := Term.app u3 u5
private def u15 := Term.app u14 u7
private def u16 := Term.app u0 u15
private def u17 := Term.lam u16
private def u18 := Term.app u5 u5
private def u19 := Term.app u18 u0
private def u20 := Term.app u19 u7
private def u21 := Term.app u0 u5
private theorem sou3 : SO u3 := SO.var 2
private theorem sou4 : SO u4 := SO.app sou3 sou3
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := so_closed_lam (by decide) sou0
private theorem sou8 : SO u8 := SO.app sou6 sou7
private theorem sou9 : SO u9 := SO.app sou0 sou8
private theorem sou18 : SO u18 := SO.app sou5 sou5
private theorem sou19 : SO u19 := SO.app sou18 sou0
private theorem sou20 : SO u20 := SO.app sou19 sou7
private theorem sou10 : SO u10 := SO.lam (r := u20) (g := u21) sou9 sou20 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.lam (r := u1) (g := u17) sou10 sou1 (by decide) (by decide)
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou2 sou12
theorem nege605603690338 : ¬ IsSelfInterpreter e605603690338 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege605603690338
end Witness605603690338
namespace Witness605603690350
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u3
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u6 u3
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u13 := Term.app u5 u5
private def u14 := Term.app u13 u0
private def u15 := Term.app u14 u5
private def u16 := Term.app u0 u5
private theorem sou3 : SO u3 := SO.var 2
private theorem sou4 : SO u4 := SO.app sou3 sou3
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou6 sou3
private theorem sou8 : SO u8 := SO.app sou0 sou7
private theorem sou13 : SO u13 := SO.app sou5 sou5
private theorem sou14 : SO u14 := SO.app sou13 sou0
private theorem sou15 : SO u15 := SO.app sou14 sou5
private theorem sou9 : SO u9 := SO.lam (r := u15) (g := u16) sou8 sou15 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
private theorem sou12 : SO u12 := SO.app sou2 sou11
theorem nege605603690350 : ¬ IsSelfInterpreter e605603690350 := by
  exact rawSO [] (t := u12) (by decide) sou12
#print axioms nege605603690350
end Witness605603690350
namespace Witness605603966838
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u3
private def u5 := Term.var 1
private def u6 := Term.app u4 u5
private def u7 := Term.app u3 u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.app u2 u11
private theorem sou0 : SO u0 := SO.var 0
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_closed_lam (by decide) sou1
private def u13 := Term.app u5 u5
private def u14 := Term.app u13 u0
private def u15 := Term.app u5 u14
private def u16 := Term.app u0 u5
private theorem sou3 : SO u3 := SO.var 2
private theorem sou4 : SO u4 := SO.app sou3 sou3
private theorem sou5 : SO u5 := SO.var 1
private theorem sou6 : SO u6 := SO.app sou4 sou5
private theorem sou7 : SO u7 := SO.app sou3 sou6
private theorem sou8 : SO u8 := SO.app sou0 sou7
private theorem sou13 : SO u13 := SO.app sou5 sou5
private theorem sou14 : SO u14 := SO.app sou13 sou0
private theorem sou15 : SO u15 := SO.app sou5 sou14
private theorem sou9 : SO u9 := SO.lam (r := u15) (g := u16) sou8 sou15 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.lam (r := u0) (g := u9) sou9 sou0 (by decide) (by decide)
private theorem sou11 : SO u11 := so_closed_lam (by decide) sou10
private theorem sou12 : SO u12 := SO.app sou2 sou11
theorem nege605603966838 : ¬ IsSelfInterpreter e605603966838 := by
  exact rawSO [] (t := u12) (by decide) sou12
#print axioms nege605603966838
end Witness605603966838
namespace Witness605770790634
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u0 u3
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605770790634 : ¬ IsSelfInterpreter e605770790634 := by
  intro he
  have h : replay [] e605770790634 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605770790634
end Witness605770790634
namespace Witness605770791658
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.var 1
private def u4 := Term.app u3 u0
private def u5 := Term.var 2
private def u6 := Term.app u4 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u0 u8
private def u10 := Term.app u9 u0
private def u11 := Term.app u10 u0
private def u12 := Term.lam u11
private def u13 := Term.app u2 u12
theorem nege605770791658 : ¬ IsSelfInterpreter e605770791658 := by
  intro he
  have h : replay [] e605770791658 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege605770791658
end Witness605770791658
end Blc.Floor41
