import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605603746518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605603746518 : Closed e605603746518 ∧ code e605603746518 = 2804627002070 := by decide
theorem cert_e605603746518 : check e605603746518 [[],[]] .chain = true := by decide
def e605603746522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605603746522 : Closed e605603746522 ∧ code e605603746522 = 2804627002074 := by decide
theorem cert_e605603746522 : check e605603746522 [[],[]] .chain = true := by decide
def e605603746538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605603746538 : Closed e605603746538 ∧ code e605603746538 = 2804627002090 := by decide
theorem cert_e605603746538 : check e605603746538 [[],[]] .chain = true := by decide
def e605603746614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605603746614 : Closed e605603746614 ∧ code e605603746614 = 2804627002166 := by decide
theorem cert_e605603746614 : check e605603746614 [[],[]] .chain = true := by decide
def e605603746618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605603746618 : Closed e605603746618 ∧ code e605603746618 = 2804627002170 := by decide
theorem cert_e605603746618 : check e605603746618 [[],[]] .chain = true := by decide
def e605603746690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e605603746690 : Closed e605603746690 ∧ code e605603746690 = 2804627002242 := by decide
theorem cert_e605603746690 : check e605603746690 [[],[]] .chain = true := by decide
def e605603746702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e605603746702 : Closed e605603746702 ∧ code e605603746702 = 2804627002254 := by decide
theorem cert_e605603746702 : check e605603746702 [[],[]] .chain = true := by decide
def e605603746714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603746714 : Closed e605603746714 ∧ code e605603746714 = 2804627002266 := by decide
theorem cert_e605603746714 : check e605603746714 [[],[]] .chain = true := by decide
def e605603747866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605603747866 : Closed e605603747866 ∧ code e605603747866 = 2804627003418 := by decide
theorem cert_e605603747866 : checkPay e605603747866 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605603747902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e605603747902 : Closed e605603747902 ∧ code e605603747902 = 2804627003454 := by decide
theorem cert_e605603747902 : checkPay e605603747902 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605603747950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e605603747950 : Closed e605603747950 ∧ code e605603747950 = 2804627003502 := by decide
theorem cert_e605603747950 : check e605603747950 [[],[]] .chain = true := by decide
def e605603747958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e605603747958 : Closed e605603747958 ∧ code e605603747958 = 2804627003510 := by decide
theorem cert_e605603747958 : check e605603747958 [[],[]] .chain = true := by decide
def e605603747962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e605603747962 : Closed e605603747962 ∧ code e605603747962 = 2804627003514 := by decide
theorem cert_e605603747962 : check e605603747962 [[],[]] .chain = true := by decide
def e605603748202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e605603748202 : Closed e605603748202 ∧ code e605603748202 = 2804627003754 := by decide
theorem cert_e605603748202 : check e605603748202 [[],[]] .chain = true := by decide
def e605603748226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e605603748226 : Closed e605603748226 ∧ code e605603748226 = 2804627003778 := by decide
theorem cert_e605603748226 : check e605603748226 [[],[]] .chain = true := by decide
def e605603748238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605603748238 : Closed e605603748238 ∧ code e605603748238 = 2804627003790 := by decide
theorem cert_e605603748238 : check e605603748238 [[],[]] .chain = true := by decide
def e605603748250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603748250 : Closed e605603748250 ∧ code e605603748250 = 2804627003802 := by decide
theorem cert_e605603748250 : check e605603748250 [[],[]] .chain = true := by decide
def e605603748294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605603748294 : Closed e605603748294 ∧ code e605603748294 = 2804627003846 := by decide
theorem cert_e605603748294 : check e605603748294 [[],[]] .chain = true := by decide
def e605603748322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e605603748322 : Closed e605603748322 ∧ code e605603748322 = 2804627003874 := by decide
theorem cert_e605603748322 : checkPay e605603748322 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [[],[.under,.under,.right,.left],[.under,.under,.right,.right]] = true := by decide
def e605603748334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e605603748334 : Closed e605603748334 ∧ code e605603748334 = 2804627003886 := by decide
theorem cert_e605603748334 : checkPay e605603748334 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 1 [] = true := by decide
def e605603748894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e605603748894 : Closed e605603748894 ∧ code e605603748894 = 2804627004446 := by decide
theorem cert_e605603748894 : check e605603748894 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605603749090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e605603749090 : Closed e605603749090 ∧ code e605603749090 = 2804627004642 := by decide
theorem cert_e605603749090 : check e605603749090 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605603749102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e605603749102 : Closed e605603749102 ∧ code e605603749102 = 2804627004654 := by decide
theorem cert_e605603749102 : check e605603749102 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605603749110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e605603749110 : Closed e605603749110 ∧ code e605603749110 = 2804627004662 := by decide
theorem cert_e605603749110 : check e605603749110 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605603761006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605603761006 : Closed e605603761006 ∧ code e605603761006 = 2804627016558 := by decide
theorem cert_e605603761006 : check e605603761006 [[],[]] .smaller = true := by decide
def e605603761014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605603761014 : Closed e605603761014 ∧ code e605603761014 = 2804627016566 := by decide
theorem cert_e605603761014 : check e605603761014 [[],[]] .smaller = true := by decide
def e605603761070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605603761070 : Closed e605603761070 ∧ code e605603761070 = 2804627016622 := by decide
theorem cert_e605603761070 : check e605603761070 [[],[]] .smaller = true := by decide
def e605603761082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605603761082 : Closed e605603761082 ∧ code e605603761082 = 2804627016634 := by decide
theorem cert_e605603761082 : check e605603761082 [[],[]] .smaller = true := by decide
def e605603761110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605603761110 : Closed e605603761110 ∧ code e605603761110 = 2804627016662 := by decide
theorem cert_e605603761110 : check e605603761110 [[],[]] .smaller = true := by decide
def e605603761114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605603761114 : Closed e605603761114 ∧ code e605603761114 = 2804627016666 := by decide
theorem cert_e605603761114 : check e605603761114 [[],[]] .smaller = true := by decide
def e605603761390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605603761390 : Closed e605603761390 ∧ code e605603761390 = 2804627016942 := by decide
theorem cert_e605603761390 : check e605603761390 [[],[]] .smaller = true := by decide
def e605603761398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605603761398 : Closed e605603761398 ∧ code e605603761398 = 2804627016950 := by decide
theorem cert_e605603761398 : check e605603761398 [[],[]] .smaller = true := by decide
def e605603761774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605603761774 : Closed e605603761774 ∧ code e605603761774 = 2804627017326 := by decide
theorem cert_e605603761774 : check e605603761774 [[],[]] .smaller = true := by decide
def e605603761786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605603761786 : Closed e605603761786 ∧ code e605603761786 = 2804627017338 := by decide
theorem cert_e605603761786 : check e605603761786 [[],[]] .smaller = true := by decide
def e605603761974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605603761974 : Closed e605603761974 ∧ code e605603761974 = 2804627017526 := by decide
theorem cert_e605603761974 : check e605603761974 [[],[]] .smaller = true := by decide
def e605603761978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605603761978 : Closed e605603761978 ∧ code e605603761978 = 2804627017530 := by decide
theorem cert_e605603761978 : check e605603761978 [[],[]] .smaller = true := by decide
def e605603762110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e605603762110 : Closed e605603762110 ∧ code e605603762110 = 2804627017662 := by decide
theorem cert_e605603762110 : check e605603762110 [[],[]] .chain = true := by decide
def e605603762142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e605603762142 : Closed e605603762142 ∧ code e605603762142 = 2804627017694 := by decide
theorem cert_e605603762142 : check e605603762142 [[],[]] .chain = true := by decide
def e605603769822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605603769822 : Closed e605603769822 ∧ code e605603769822 = 2804627025374 := by decide
theorem cert_e605603769822 : check e605603769822 [[],[]] .chain = true := by decide
def e605603769838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605603769838 : Closed e605603769838 ∧ code e605603769838 = 2804627025390 := by decide
theorem cert_e605603769838 : check e605603769838 [[],[]] .chain = true := by decide
def e605603770206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605603770206 : Closed e605603770206 ∧ code e605603770206 = 2804627025758 := by decide
theorem cert_e605603770206 : check e605603770206 [[],[]] .chain = true := by decide
def e605603770234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605603770234 : Closed e605603770234 ∧ code e605603770234 = 2804627025786 := by decide
theorem cert_e605603770234 : check e605603770234 [[],[]] .chain = true := by decide
def e605603770286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605603770286 : Closed e605603770286 ∧ code e605603770286 = 2804627025838 := by decide
theorem cert_e605603770286 : check e605603770286 [[],[]] .chain = true := by decide
def e605603770298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605603770298 : Closed e605603770298 ∧ code e605603770298 = 2804627025850 := by decide
theorem cert_e605603770298 : check e605603770298 [[],[]] .chain = true := by decide
def e605603771358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605603771358 : Closed e605603771358 ∧ code e605603771358 = 2804627026910 := by decide
theorem cert_e605603771358 : check e605603771358 [[],[]] .chain = true := by decide
def e605603771374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605603771374 : Closed e605603771374 ∧ code e605603771374 = 2804627026926 := by decide
theorem cert_e605603771374 : check e605603771374 [[],[]] .chain = true := by decide
def e605603773662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605603773662 : Closed e605603773662 ∧ code e605603773662 = 2804627029214 := by decide
theorem cert_e605603773662 : check e605603773662 [[],[]] .chain = true := by decide
def e605603773690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605603773690 : Closed e605603773690 ∧ code e605603773690 = 2804627029242 := by decide
theorem cert_e605603773690 : check e605603773690 [[],[]] .chain = true := by decide
def e605603774062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605603774062 : Closed e605603774062 ∧ code e605603774062 = 2804627029614 := by decide
theorem cert_e605603774062 : check e605603774062 [[],[]] .chain = true := by decide
def e605603774074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605603774074 : Closed e605603774074 ∧ code e605603774074 = 2804627029626 := by decide
theorem cert_e605603774074 : check e605603774074 [[],[]] .chain = true := by decide
def e605603802478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605603802478 : Closed e605603802478 ∧ code e605603802478 = 2804627058030 := by decide
theorem cert_e605603802478 : check e605603802478 [[],[]] .chain = true := by decide
def e605603802486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605603802486 : Closed e605603802486 ∧ code e605603802486 = 2804627058038 := by decide
theorem cert_e605603802486 : check e605603802486 [[],[]] .chain = true := by decide
def e605603802542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605603802542 : Closed e605603802542 ∧ code e605603802542 = 2804627058094 := by decide
theorem cert_e605603802542 : check e605603802542 [[],[]] .chain = true := by decide
def e605603802554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605603802554 : Closed e605603802554 ∧ code e605603802554 = 2804627058106 := by decide
theorem cert_e605603802554 : check e605603802554 [[],[]] .chain = true := by decide
def e605603802582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605603802582 : Closed e605603802582 ∧ code e605603802582 = 2804627058134 := by decide
theorem cert_e605603802582 : check e605603802582 [[],[]] .chain = true := by decide
def e605603802586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605603802586 : Closed e605603802586 ∧ code e605603802586 = 2804627058138 := by decide
theorem cert_e605603802586 : check e605603802586 [[],[]] .chain = true := by decide
def e605603802798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605603802798 : Closed e605603802798 ∧ code e605603802798 = 2804627058350 := by decide
theorem cert_e605603802798 : check e605603802798 [[],[]] .chain = true := by decide
def e605603802810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605603802810 : Closed e605603802810 ∧ code e605603802810 = 2804627058362 := by decide
theorem cert_e605603802810 : check e605603802810 [[],[]] .chain = true := by decide
def e605603802858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605603802858 : Closed e605603802858 ∧ code e605603802858 = 2804627058410 := by decide
theorem cert_e605603802858 : check e605603802858 [[],[]] .chain = true := by decide
def e605603802966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605603802966 : Closed e605603802966 ∧ code e605603802966 = 2804627058518 := by decide
theorem cert_e605603802966 : check e605603802966 [[],[]] .chain = true := by decide
def e605603802970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605603802970 : Closed e605603802970 ∧ code e605603802970 = 2804627058522 := by decide
theorem cert_e605603802970 : check e605603802970 [[],[]] .chain = true := by decide
def e605603802986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605603802986 : Closed e605603802986 ∧ code e605603802986 = 2804627058538 := by decide
theorem cert_e605603802986 : check e605603802986 [[],[]] .chain = true := by decide
def e605603804014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605603804014 : Closed e605603804014 ∧ code e605603804014 = 2804627059566 := by decide
theorem cert_e605603804014 : check e605603804014 [[],[]] .chain = true := by decide
def e605603804022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605603804022 : Closed e605603804022 ∧ code e605603804022 = 2804627059574 := by decide
theorem cert_e605603804022 : check e605603804022 [[],[]] .chain = true := by decide
def e605603804078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605603804078 : Closed e605603804078 ∧ code e605603804078 = 2804627059630 := by decide
theorem cert_e605603804078 : check e605603804078 [[],[]] .chain = true := by decide
def e605603804090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605603804090 : Closed e605603804090 ∧ code e605603804090 = 2804627059642 := by decide
theorem cert_e605603804090 : check e605603804090 [[],[]] .chain = true := by decide
def e605603804118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605603804118 : Closed e605603804118 ∧ code e605603804118 = 2804627059670 := by decide
theorem cert_e605603804118 : check e605603804118 [[],[]] .chain = true := by decide
def e605603804122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605603804122 : Closed e605603804122 ∧ code e605603804122 = 2804627059674 := by decide
theorem cert_e605603804122 : check e605603804122 [[],[]] .chain = true := by decide
def e605603804398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605603804398 : Closed e605603804398 ∧ code e605603804398 = 2804627059950 := by decide
theorem cert_e605603804398 : check e605603804398 [[],[]] .chain = true := by decide
def e605603804406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605603804406 : Closed e605603804406 ∧ code e605603804406 = 2804627059958 := by decide
theorem cert_e605603804406 : check e605603804406 [[],[]] .chain = true := by decide
def e605603804782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605603804782 : Closed e605603804782 ∧ code e605603804782 = 2804627060334 := by decide
theorem cert_e605603804782 : check e605603804782 [[],[]] .chain = true := by decide
def e605603804794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605603804794 : Closed e605603804794 ∧ code e605603804794 = 2804627060346 := by decide
theorem cert_e605603804794 : check e605603804794 [[],[]] .chain = true := by decide
def e605603804982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605603804982 : Closed e605603804982 ∧ code e605603804982 = 2804627060534 := by decide
theorem cert_e605603804982 : check e605603804982 [[],[]] .chain = true := by decide
def e605603804986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605603804986 : Closed e605603804986 ∧ code e605603804986 = 2804627060538 := by decide
theorem cert_e605603804986 : check e605603804986 [[],[]] .chain = true := by decide
def e605603805230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605603805230 : Closed e605603805230 ∧ code e605603805230 = 2804627060782 := by decide
theorem cert_e605603805230 : check e605603805230 [[],[]] .chain = true := by decide
def e605603805422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605603805422 : Closed e605603805422 ∧ code e605603805422 = 2804627060974 := by decide
theorem cert_e605603805422 : check e605603805422 [[],[]] .chain = true := by decide
def e605603805430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605603805430 : Closed e605603805430 ∧ code e605603805430 = 2804627060982 := by decide
theorem cert_e605603805430 : check e605603805430 [[],[]] .chain = true := by decide
def e605603805614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605603805614 : Closed e605603805614 ∧ code e605603805614 = 2804627061166 := by decide
theorem cert_e605603805614 : check e605603805614 [[],[]] .chain = true := by decide
def e605603805626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605603805626 : Closed e605603805626 ∧ code e605603805626 = 2804627061178 := by decide
theorem cert_e605603805626 : check e605603805626 [[],[]] .chain = true := by decide
def e605603805674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605603805674 : Closed e605603805674 ∧ code e605603805674 = 2804627061226 := by decide
theorem cert_e605603805674 : check e605603805674 [[],[]] .chain = true := by decide
def e605603805806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605603805806 : Closed e605603805806 ∧ code e605603805806 = 2804627061358 := by decide
theorem cert_e605603805806 : check e605603805806 [[],[]] .chain = true := by decide
def e605603805818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605603805818 : Closed e605603805818 ∧ code e605603805818 = 2804627061370 := by decide
theorem cert_e605603805818 : check e605603805818 [[],[]] .chain = true := by decide
def e605603805982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605603805982 : Closed e605603805982 ∧ code e605603805982 = 2804627061534 := by decide
theorem cert_e605603805982 : check e605603805982 [[],[]] .chain = true := by decide
def e605603806082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e605603806082 : Closed e605603806082 ∧ code e605603806082 = 2804627061634 := by decide
theorem cert_e605603806082 : check e605603806082 [[],[]] .chain = true := by decide
def e605603806094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605603806094 : Closed e605603806094 ∧ code e605603806094 = 2804627061646 := by decide
theorem cert_e605603806094 : check e605603806094 [[],[]] .chain = true := by decide
def e605603806106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603806106 : Closed e605603806106 ∧ code e605603806106 = 2804627061658 := by decide
theorem cert_e605603806106 : check e605603806106 [[],[]] .chain = true := by decide
def e605603806230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605603806230 : Closed e605603806230 ∧ code e605603806230 = 2804627061782 := by decide
theorem cert_e605603806230 : check e605603806230 [[],[]] .chain = true := by decide
def e605603806326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e605603806326 : Closed e605603806326 ∧ code e605603806326 = 2804627061878 := by decide
theorem cert_e605603806326 : check e605603806326 [[],[]] .chain = true := by decide
def e605603806422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605603806422 : Closed e605603806422 ∧ code e605603806422 = 2804627061974 := by decide
theorem cert_e605603806422 : check e605603806422 [[],[]] .chain = true := by decide
def e605603806426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605603806426 : Closed e605603806426 ∧ code e605603806426 = 2804627061978 := by decide
theorem cert_e605603806426 : check e605603806426 [[],[]] .chain = true := by decide
def e605603806442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605603806442 : Closed e605603806442 ∧ code e605603806442 = 2804627061994 := by decide
theorem cert_e605603806442 : check e605603806442 [[],[]] .chain = true := by decide
def e605603806518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605603806518 : Closed e605603806518 ∧ code e605603806518 = 2804627062070 := by decide
theorem cert_e605603806518 : check e605603806518 [[],[]] .chain = true := by decide
def e605603806522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605603806522 : Closed e605603806522 ∧ code e605603806522 = 2804627062074 := by decide
theorem cert_e605603806522 : check e605603806522 [[],[]] .chain = true := by decide
def e605603806594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e605603806594 : Closed e605603806594 ∧ code e605603806594 = 2804627062146 := by decide
theorem cert_e605603806594 : check e605603806594 [[],[]] .chain = true := by decide
def e605603806606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e605603806606 : Closed e605603806606 ∧ code e605603806606 = 2804627062158 := by decide
theorem cert_e605603806606 : check e605603806606 [[],[]] .chain = true := by decide
def e605603806618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603806618 : Closed e605603806618 ∧ code e605603806618 = 2804627062170 := by decide
theorem cert_e605603806618 : check e605603806618 [[],[]] .chain = true := by decide
def e605603808222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e605603808222 : Closed e605603808222 ∧ code e605603808222 = 2804627063774 := by decide
theorem cert_e605603808222 : check e605603808222 [[],[]] .chain = true := by decide
def e605603808238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e605603808238 : Closed e605603808238 ∧ code e605603808238 = 2804627063790 := by decide
theorem cert_e605603808238 : check e605603808238 [[],[]] .chain = true := by decide
def e605603810158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605603810158 : Closed e605603810158 ∧ code e605603810158 = 2804627065710 := by decide
theorem cert_e605603810158 : check e605603810158 [[],[]] .chain = true := by decide
def e605603810166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605603810166 : Closed e605603810166 ∧ code e605603810166 = 2804627065718 := by decide
theorem cert_e605603810166 : check e605603810166 [[],[]] .chain = true := by decide
def e605603810222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605603810222 : Closed e605603810222 ∧ code e605603810222 = 2804627065774 := by decide
theorem cert_e605603810222 : check e605603810222 [[],[]] .chain = true := by decide
def e605603810234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605603810234 : Closed e605603810234 ∧ code e605603810234 = 2804627065786 := by decide
theorem cert_e605603810234 : check e605603810234 [[],[]] .chain = true := by decide
def e605603810262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605603810262 : Closed e605603810262 ∧ code e605603810262 = 2804627065814 := by decide
theorem cert_e605603810262 : check e605603810262 [[],[]] .chain = true := by decide
def e605603810266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605603810266 : Closed e605603810266 ∧ code e605603810266 = 2804627065818 := by decide
theorem cert_e605603810266 : check e605603810266 [[],[]] .chain = true := by decide
def e605603810542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605603810542 : Closed e605603810542 ∧ code e605603810542 = 2804627066094 := by decide
theorem cert_e605603810542 : check e605603810542 [[],[]] .chain = true := by decide
def e605603810550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605603810550 : Closed e605603810550 ∧ code e605603810550 = 2804627066102 := by decide
theorem cert_e605603810550 : check e605603810550 [[],[]] .chain = true := by decide
def e605603810926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605603810926 : Closed e605603810926 ∧ code e605603810926 = 2804627066478 := by decide
theorem cert_e605603810926 : check e605603810926 [[],[]] .chain = true := by decide
def e605603810938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605603810938 : Closed e605603810938 ∧ code e605603810938 = 2804627066490 := by decide
theorem cert_e605603810938 : check e605603810938 [[],[]] .chain = true := by decide
def e605603811126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605603811126 : Closed e605603811126 ∧ code e605603811126 = 2804627066678 := by decide
theorem cert_e605603811126 : check e605603811126 [[],[]] .chain = true := by decide
def e605603811130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605603811130 : Closed e605603811130 ∧ code e605603811130 = 2804627066682 := by decide
theorem cert_e605603811130 : check e605603811130 [[],[]] .chain = true := by decide
def e605603815902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605603815902 : Closed e605603815902 ∧ code e605603815902 = 2804627071454 := by decide
theorem cert_e605603815902 : check e605603815902 [[],[]] .chain = true := by decide
def e605603815926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605603815926 : Closed e605603815926 ∧ code e605603815926 = 2804627071478 := by decide
theorem cert_e605603815926 : check e605603815926 [[],[]] .chain = true := by decide
def e605603816878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605603816878 : Closed e605603816878 ∧ code e605603816878 = 2804627072430 := by decide
theorem cert_e605603816878 : check e605603816878 [[],[]] .chain = true := by decide
def e605603816890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605603816890 : Closed e605603816890 ∧ code e605603816890 = 2804627072442 := by decide
theorem cert_e605603816890 : check e605603816890 [[],[]] .chain = true := by decide
def e605603816938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605603816938 : Closed e605603816938 ∧ code e605603816938 = 2804627072490 := by decide
theorem cert_e605603816938 : check e605603816938 [[],[]] .chain = true := by decide
def e605603817070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605603817070 : Closed e605603817070 ∧ code e605603817070 = 2804627072622 := by decide
theorem cert_e605603817070 : check e605603817070 [[],[]] .chain = true := by decide
def e605603817082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605603817082 : Closed e605603817082 ∧ code e605603817082 = 2804627072634 := by decide
theorem cert_e605603817082 : check e605603817082 [[],[]] .chain = true := by decide
def e605603817246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605603817246 : Closed e605603817246 ∧ code e605603817246 = 2804627072798 := by decide
theorem cert_e605603817246 : check e605603817246 [[],[]] .chain = true := by decide
def e605603817346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e605603817346 : Closed e605603817346 ∧ code e605603817346 = 2804627072898 := by decide
theorem cert_e605603817346 : check e605603817346 [[],[]] .chain = true := by decide
def e605603817358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605603817358 : Closed e605603817358 ∧ code e605603817358 = 2804627072910 := by decide
theorem cert_e605603817358 : check e605603817358 [[],[]] .chain = true := by decide
def e605603817370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605603817370 : Closed e605603817370 ∧ code e605603817370 = 2804627072922 := by decide
theorem cert_e605603817370 : check e605603817370 [[],[]] .chain = true := by decide
def e605603819758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605603819758 : Closed e605603819758 ∧ code e605603819758 = 2804627075310 := by decide
theorem cert_e605603819758 : check e605603819758 [[],[]] .chain = true := by decide
def e605603819766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605603819766 : Closed e605603819766 ∧ code e605603819766 = 2804627075318 := by decide
theorem cert_e605603819766 : check e605603819766 [[],[]] .chain = true := by decide
def e605603820246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605603820246 : Closed e605603820246 ∧ code e605603820246 = 2804627075798 := by decide
theorem cert_e605603820246 : check e605603820246 [[],[]] .chain = true := by decide
def e605603820250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605603820250 : Closed e605603820250 ∧ code e605603820250 = 2804627075802 := by decide
theorem cert_e605603820250 : check e605603820250 [[],[]] .chain = true := by decide
def e605603820266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605603820266 : Closed e605603820266 ∧ code e605603820266 = 2804627075818 := by decide
theorem cert_e605603820266 : check e605603820266 [[],[]] .chain = true := by decide
def e605603820342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605603820342 : Closed e605603820342 ∧ code e605603820342 = 2804627075894 := by decide
theorem cert_e605603820342 : check e605603820342 [[],[]] .chain = true := by decide
def e605603820346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605603820346 : Closed e605603820346 ∧ code e605603820346 = 2804627075898 := by decide
theorem cert_e605603820346 : check e605603820346 [[],[]] .chain = true := by decide
def e605603820418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e605603820418 : Closed e605603820418 ∧ code e605603820418 = 2804627075970 := by decide
theorem cert_e605603820418 : check e605603820418 [[],[]] .chain = true := by decide
def e605603820430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e605603820430 : Closed e605603820430 ∧ code e605603820430 = 2804627075982 := by decide
theorem cert_e605603820430 : check e605603820430 [[],[]] .chain = true := by decide
def e605603820442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605603820442 : Closed e605603820442 ∧ code e605603820442 = 2804627075994 := by decide
theorem cert_e605603820442 : check e605603820442 [[],[]] .chain = true := by decide
def e605603891134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e605603891134 : Closed e605603891134 ∧ code e605603891134 = 2804627146686 := by decide
theorem cert_e605603891134 : check e605603891134 [[],[]] .chain = true := by decide
def e605603891182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e605603891182 : Closed e605603891182 ∧ code e605603891182 = 2804627146734 := by decide
theorem cert_e605603891182 : check e605603891182 [[],[]] .chain = true := by decide
def e605603895006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605603895006 : Closed e605603895006 ∧ code e605603895006 = 2804627150558 := by decide
theorem cert_e605603895006 : check e605603895006 [[],[]] .chain = true := by decide
def e605603895030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605603895030 : Closed e605603895030 ∧ code e605603895030 = 2804627150582 := by decide
theorem cert_e605603895030 : check e605603895030 [[],[]] .chain = true := by decide
def e605603895134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605603895134 : Closed e605603895134 ∧ code e605603895134 = 2804627150686 := by decide
theorem cert_e605603895134 : check e605603895134 [[],[]] .chain = true := by decide
def e605603895162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605603895162 : Closed e605603895162 ∧ code e605603895162 = 2804627150714 := by decide
theorem cert_e605603895162 : check e605603895162 [[],[]] .chain = true := by decide
def e605603895254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605603895254 : Closed e605603895254 ∧ code e605603895254 = 2804627150806 := by decide
theorem cert_e605603895254 : check e605603895254 [[],[]] .chain = true := by decide
def e605603895258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605603895258 : Closed e605603895258 ∧ code e605603895258 = 2804627150810 := by decide
theorem cert_e605603895258 : check e605603895258 [[],[]] .chain = true := by decide
def e605603895774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605603895774 : Closed e605603895774 ∧ code e605603895774 = 2804627151326 := by decide
theorem cert_e605603895774 : check e605603895774 [[],[]] .chain = true := by decide
def e605603895798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605603895798 : Closed e605603895798 ∧ code e605603895798 = 2804627151350 := by decide
theorem cert_e605603895798 : check e605603895798 [[],[]] .chain = true := by decide
def e605603896542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605603896542 : Closed e605603896542 ∧ code e605603896542 = 2804627152094 := by decide
theorem cert_e605603896542 : check e605603896542 [[],[]] .chain = true := by decide
def e605603896570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605603896570 : Closed e605603896570 ∧ code e605603896570 = 2804627152122 := by decide
theorem cert_e605603896570 : check e605603896570 [[],[]] .chain = true := by decide
def e605603896894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e605603896894 : Closed e605603896894 ∧ code e605603896894 = 2804627152446 := by decide
theorem cert_e605603896894 : check e605603896894 [[],[]] .chain = true := by decide
def e605603897118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e605603897118 : Closed e605603897118 ∧ code e605603897118 = 2804627152670 := by decide
theorem cert_e605603897118 : check e605603897118 [[],[]] .chain = true := by decide
def e605603897142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605603897142 : Closed e605603897142 ∧ code e605603897142 = 2804627152694 := by decide
theorem cert_e605603897142 : check e605603897142 [[],[]] .chain = true := by decide
def e605603897146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605603897146 : Closed e605603897146 ∧ code e605603897146 = 2804627152698 := by decide
theorem cert_e605603897146 : check e605603897146 [[],[]] .chain = true := by decide
def e605603911342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605603911342 : Closed e605603911342 ∧ code e605603911342 = 2804627166894 := by decide
theorem cert_e605603911342 : check e605603911342 [[],[]] .chain = true := by decide
def e605603911354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605603911354 : Closed e605603911354 ∧ code e605603911354 = 2804627166906 := by decide
theorem cert_e605603911354 : check e605603911354 [[],[]] .chain = true := by decide
def e605603911402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605603911402 : Closed e605603911402 ∧ code e605603911402 = 2804627166954 := by decide
theorem cert_e605603911402 : check e605603911402 [[],[]] .chain = true := by decide
def e605603911594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605603911594 : Closed e605603911594 ∧ code e605603911594 = 2804627167146 := by decide
theorem cert_e605603911594 : check e605603911594 [[],[]] .chain = true := by decide
def e605603911726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e605603911726 : Closed e605603911726 ∧ code e605603911726 = 2804627167278 := by decide
theorem cert_e605603911726 : check e605603911726 [[],[]] .chain = true := by decide
def e605603911918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605603911918 : Closed e605603911918 ∧ code e605603911918 = 2804627167470 := by decide
theorem cert_e605603911918 : check e605603911918 [[],[]] .chain = true := by decide
def e605603911926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605603911926 : Closed e605603911926 ∧ code e605603911926 = 2804627167478 := by decide
theorem cert_e605603911926 : check e605603911926 [[],[]] .chain = true := by decide
def e605603912110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605603912110 : Closed e605603912110 ∧ code e605603912110 = 2804627167662 := by decide
theorem cert_e605603912110 : check e605603912110 [[],[]] .chain = true := by decide
def e605603912122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605603912122 : Closed e605603912122 ∧ code e605603912122 = 2804627167674 := by decide
theorem cert_e605603912122 : check e605603912122 [[],[]] .chain = true := by decide
def e605603912170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605603912170 : Closed e605603912170 ∧ code e605603912170 = 2804627167722 := by decide
theorem cert_e605603912170 : check e605603912170 [[],[]] .chain = true := by decide
def e605603912302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605603912302 : Closed e605603912302 ∧ code e605603912302 = 2804627167854 := by decide
theorem cert_e605603912302 : check e605603912302 [[],[]] .chain = true := by decide
def e605603912314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605603912314 : Closed e605603912314 ∧ code e605603912314 = 2804627167866 := by decide
theorem cert_e605603912314 : check e605603912314 [[],[]] .chain = true := by decide
def e605603912478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605603912478 : Closed e605603912478 ∧ code e605603912478 = 2804627168030 := by decide
theorem cert_e605603912478 : check e605603912478 [[],[]] .chain = true := by decide
end Blc.Floor41
