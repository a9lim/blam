import Extra41
import Batch030
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness565606140846
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.app u0 u1
private def u4 := Term.var 2
private def u5 := Term.app u3 u4
private def u6 := Term.app u1 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565606140846 : ¬ IsSelfInterpreter e565606140846 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565606140846 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565606140846 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565606140846
end Witness565606140846
namespace Witness565606141754
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u0 u1
private def u5 := Term.app u3 u4
private def u6 := Term.app u1 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565606141754 : ¬ IsSelfInterpreter e565606141754 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565606141754 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565606141754 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565606141754
end Witness565606141754
namespace Witness565606150874
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u0
private def u5 := Term.app u4 u1
private def u6 := Term.app u3 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565606150874 : ¬ IsSelfInterpreter e565606150874 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565606150874 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565606150874 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565606150874
end Witness565606150874
namespace Witness565606150890
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u0 u1
private def u5 := Term.app u4 u1
private def u6 := Term.app u3 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565606150890 : ¬ IsSelfInterpreter e565606150890 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565606150890 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565606150890 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565606150890
end Witness565606150890
namespace Witness565606150970
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u0 u1
private def u5 := Term.app u1 u4
private def u6 := Term.app u3 u5
private def u7 := Term.lam u6
private def u8 := Term.lam u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565606150970 : ¬ IsSelfInterpreter e565606150970 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565606150970 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565606150970 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565606150970
end Witness565606150970
namespace Witness565606878070
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565606878070 : ¬ IsSelfInterpreter e565606878070 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565606878070 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565606878070 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565606878070
end Witness565606878070
namespace Witness565606878166
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u3 u1
private def u5 := Term.app u4 u0
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565606878166 : ¬ IsSelfInterpreter e565606878166 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565606878166 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565606878166 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565606878166
end Witness565606878166
namespace Witness565606878830
private def u0 := Term.var 1
private def u1 := Term.var 0
private def u2 := Term.lam u1
private def u3 := Term.var 2
private def u4 := Term.app u1 u3
private def u5 := Term.app u0 u4
private def u6 := Term.lam u5
private def u7 := Term.lam u6
private def u8 := Term.app u1 u7
private def u9 := Term.app u1 u8
private def u10 := Term.lam u9
private def u11 := Term.app u10 u10
private def u12 := Term.lam u0
private def u13 := Term.lam u12
private def u14 := Term.app u1 u13
private def u15 := Term.lam u2
private def u16 := Term.app u1 u15
private def u17 := Term.var 4
private def u18 := Term.app u14 u17
private def u19 := Term.lam u18
private def u20 := Term.app u16 u19
private def u21 := Term.lam u20
private def u22 := Term.app u14 u21
private def u23 := Term.lam u22
private def u24 := Term.app u14 u23
private def u25 := Term.lam u24
private def u26 := Term.app u11 u25
private def u27 := Term.app u0 u15
private def u28 := Term.app u27 u1
theorem nege565606878830 : ¬ IsSelfInterpreter e565606878830 := by
  intro he
  have hv : NFt u28 := by decide
  have reach : Betas (Floor40.call e565606878830 u0 u2 u1 []) u28 := reachesNF [] he (by decide) (by decide) hv
  have hr : replay [[.left,.left],[.left]] (Floor40.call e565606878830 u0 u2 u1 []) = some u26 := by decide
  exact scopeMismatch hv reach hr 1 (by decide) (by decide)
#print axioms nege565606878830
end Witness565606878830
end Blc.Floor41
