import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605601799126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e605601799126 : Closed e605601799126 ∧ code e605601799126 = 2804625054678 := by decide
theorem cert_e605601799126 : check e605601799126 [[],[]] .chain = true := by decide
def e605601799130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e605601799130 : Closed e605601799130 ∧ code e605601799130 = 2804625054682 := by decide
theorem cert_e605601799130 : check e605601799130 [[],[]] .chain = true := by decide
def e605601799534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e605601799534 : Closed e605601799534 ∧ code e605601799534 = 2804625055086 := by decide
theorem cert_e605601799534 : check e605601799534 [[],[]] .chain = true := by decide
def e605601799542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e605601799542 : Closed e605601799542 ∧ code e605601799542 = 2804625055094 := by decide
theorem cert_e605601799542 : check e605601799542 [[],[]] .chain = true := by decide
def e605601799598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e605601799598 : Closed e605601799598 ∧ code e605601799598 = 2804625055150 := by decide
theorem cert_e605601799598 : check e605601799598 [[],[]] .chain = true := by decide
def e605601799610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e605601799610 : Closed e605601799610 ∧ code e605601799610 = 2804625055162 := by decide
theorem cert_e605601799610 : check e605601799610 [[],[]] .chain = true := by decide
def e605601799658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e605601799658 : Closed e605601799658 ∧ code e605601799658 = 2804625055210 := by decide
theorem cert_e605601799658 : check e605601799658 [[],[]] .chain = true := by decide
def e605601799854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e605601799854 : Closed e605601799854 ∧ code e605601799854 = 2804625055406 := by decide
theorem cert_e605601799854 : check e605601799854 [[],[]] .chain = true := by decide
def e605601799866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e605601799866 : Closed e605601799866 ∧ code e605601799866 = 2804625055418 := by decide
theorem cert_e605601799866 : check e605601799866 [[],[]] .chain = true := by decide
def e605601800022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e605601800022 : Closed e605601800022 ∧ code e605601800022 = 2804625055574 := by decide
theorem cert_e605601800022 : check e605601800022 [[],[]] .chain = true := by decide
def e605601800026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e605601800026 : Closed e605601800026 ∧ code e605601800026 = 2804625055578 := by decide
theorem cert_e605601800026 : check e605601800026 [[],[]] .chain = true := by decide
def e605601800042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e605601800042 : Closed e605601800042 ∧ code e605601800042 = 2804625055594 := by decide
theorem cert_e605601800042 : check e605601800042 [[],[]] .chain = true := by decide
def e605601801966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e605601801966 : Closed e605601801966 ∧ code e605601801966 = 2804625057518 := by decide
theorem cert_e605601801966 : check e605601801966 [[],[]] .sourceHead = true := by decide
def e605601802158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e605601802158 : Closed e605601802158 ∧ code e605601802158 = 2804625057710 := by decide
theorem cert_e605601802158 : check e605601802158 [[],[]] .sourceHead = true := by decide
def e605601802170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e605601802170 : Closed e605601802170 ∧ code e605601802170 = 2804625057722 := by decide
theorem cert_e605601802170 : check e605601802170 [[],[]] .sourceHead = true := by decide
def e605601802734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e605601802734 : Closed e605601802734 ∧ code e605601802734 = 2804625058286 := by decide
theorem cert_e605601802734 : check e605601802734 [[],[]] .sourceHead = true := by decide
def e605601803886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601803886 : Closed e605601803886 ∧ code e605601803886 = 2804625059438 := by decide
theorem cert_e605601803886 : check e605601803886 [[],[]] .sourceHead = true := by decide
def e605601803898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601803898 : Closed e605601803898 ∧ code e605601803898 = 2804625059450 := by decide
theorem cert_e605601803898 : check e605601803898 [[],[]] .sourceHead = true := by decide
def e605601804782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.var 2))))))
theorem wire_e605601804782 : Closed e605601804782 ∧ code e605601804782 = 2804625060334 := by decide
theorem cert_e605601804782 : check e605601804782 [[],[]] .sourceHead = true := by decide
def e605601805166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e605601805166 : Closed e605601805166 ∧ code e605601805166 = 2804625060718 := by decide
theorem cert_e605601805166 : check e605601805166 [[],[]] .chain = true := by decide
def e605601805174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e605601805174 : Closed e605601805174 ∧ code e605601805174 = 2804625060726 := by decide
theorem cert_e605601805174 : check e605601805174 [[],[]] .chain = true := by decide
def e605601805230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e605601805230 : Closed e605601805230 ∧ code e605601805230 = 2804625060782 := by decide
theorem cert_e605601805230 : check e605601805230 [[],[]] .chain = true := by decide
def e605601805242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e605601805242 : Closed e605601805242 ∧ code e605601805242 = 2804625060794 := by decide
theorem cert_e605601805242 : check e605601805242 [[],[]] .chain = true := by decide
def e605601805270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e605601805270 : Closed e605601805270 ∧ code e605601805270 = 2804625060822 := by decide
theorem cert_e605601805270 : check e605601805270 [[],[]] .chain = true := by decide
def e605601805274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e605601805274 : Closed e605601805274 ∧ code e605601805274 = 2804625060826 := by decide
theorem cert_e605601805274 : check e605601805274 [[],[]] .chain = true := by decide
def e605601805550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e605601805550 : Closed e605601805550 ∧ code e605601805550 = 2804625061102 := by decide
theorem cert_e605601805550 : check e605601805550 [[],[]] .chain = true := by decide
def e605601805558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e605601805558 : Closed e605601805558 ∧ code e605601805558 = 2804625061110 := by decide
theorem cert_e605601805558 : check e605601805558 [[],[]] .chain = true := by decide
def e605601805934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601805934 : Closed e605601805934 ∧ code e605601805934 = 2804625061486 := by decide
theorem cert_e605601805934 : check e605601805934 [[],[]] .chain = true := by decide
def e605601805946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601805946 : Closed e605601805946 ∧ code e605601805946 = 2804625061498 := by decide
theorem cert_e605601805946 : check e605601805946 [[],[]] .chain = true := by decide
def e605601806110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 3)))))))
theorem wire_e605601806110 : Closed e605601806110 ∧ code e605601806110 = 2804625061662 := by decide
theorem cert_e605601806110 : check e605601806110 [[],[]] .sourceHead = true := by decide
def e605601806134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601806134 : Closed e605601806134 ∧ code e605601806134 = 2804625061686 := by decide
theorem cert_e605601806134 : check e605601806134 [[],[]] .chain = true := by decide
def e605601806138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601806138 : Closed e605601806138 ∧ code e605601806138 = 2804625061690 := by decide
theorem cert_e605601806138 : check e605601806138 [[],[]] .chain = true := by decide
def e605601806766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e605601806766 : Closed e605601806766 ∧ code e605601806766 = 2804625062318 := by decide
theorem cert_e605601806766 : check e605601806766 [[],[]] .chain = true := by decide
def e605601806778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e605601806778 : Closed e605601806778 ∧ code e605601806778 = 2804625062330 := by decide
theorem cert_e605601806778 : check e605601806778 [[],[]] .chain = true := by decide
def e605601806826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e605601806826 : Closed e605601806826 ∧ code e605601806826 = 2804625062378 := by decide
theorem cert_e605601806826 : check e605601806826 [[],[]] .chain = true := by decide
def e605601806958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601806958 : Closed e605601806958 ∧ code e605601806958 = 2804625062510 := by decide
theorem cert_e605601806958 : check e605601806958 [[],[]] .chain = true := by decide
def e605601806970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601806970 : Closed e605601806970 ∧ code e605601806970 = 2804625062522 := by decide
theorem cert_e605601806970 : check e605601806970 [[],[]] .chain = true := by decide
def e605601807258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601807258 : Closed e605601807258 ∧ code e605601807258 = 2804625062810 := by decide
theorem cert_e605601807258 : check e605601807258 [[],[]] .chain = true := by decide
def e605601807470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.var 2))))))
theorem wire_e605601807470 : Closed e605601807470 ∧ code e605601807470 = 2804625063022 := by decide
theorem cert_e605601807470 : check e605601807470 [[],[]] .sourceHead = true := by decide
def e605601807482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 3))) (.var 0))))))
theorem wire_e605601807482 : Closed e605601807482 ∧ code e605601807482 = 2804625063034 := by decide
theorem cert_e605601807482 : check e605601807482 [[],[]] .sourceHead = true := by decide
def e605601807574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e605601807574 : Closed e605601807574 ∧ code e605601807574 = 2804625063126 := by decide
theorem cert_e605601807574 : check e605601807574 [[],[]] .chain = true := by decide
def e605601807578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e605601807578 : Closed e605601807578 ∧ code e605601807578 = 2804625063130 := by decide
theorem cert_e605601807578 : check e605601807578 [[],[]] .chain = true := by decide
def e605601807594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e605601807594 : Closed e605601807594 ∧ code e605601807594 = 2804625063146 := by decide
theorem cert_e605601807594 : check e605601807594 [[],[]] .chain = true := by decide
def e605601807646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e605601807646 : Closed e605601807646 ∧ code e605601807646 = 2804625063198 := by decide
theorem cert_e605601807646 : check e605601807646 [[],[]] .sourceHead = true := by decide
def e605601807670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e605601807670 : Closed e605601807670 ∧ code e605601807670 = 2804625063222 := by decide
theorem cert_e605601807670 : check e605601807670 [[],[]] .chain = true := by decide
def e605601807674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e605601807674 : Closed e605601807674 ∧ code e605601807674 = 2804625063226 := by decide
theorem cert_e605601807674 : check e605601807674 [[],[]] .chain = true := by decide
def e605601807770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601807770 : Closed e605601807770 ∧ code e605601807770 = 2804625063322 := by decide
theorem cert_e605601807770 : check e605601807770 [[],[]] .chain = true := by decide
def e605601807814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e605601807814 : Closed e605601807814 ∧ code e605601807814 = 2804625063366 := by decide
theorem cert_e605601807814 : check e605601807814 [[],[]] .sourceHead = true := by decide
def e605601815214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e605601815214 : Closed e605601815214 ∧ code e605601815214 = 2804625070766 := by decide
theorem cert_e605601815214 : check e605601815214 [[],[]] .chain = true := by decide
def e605601815226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e605601815226 : Closed e605601815226 ∧ code e605601815226 = 2804625070778 := by decide
theorem cert_e605601815226 : check e605601815226 [[],[]] .chain = true := by decide
def e605601815274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e605601815274 : Closed e605601815274 ∧ code e605601815274 = 2804625070826 := by decide
theorem cert_e605601815274 : check e605601815274 [[],[]] .chain = true := by decide
def e605601815466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e605601815466 : Closed e605601815466 ∧ code e605601815466 = 2804625071018 := by decide
theorem cert_e605601815466 : check e605601815466 [[],[]] .chain = true := by decide
def e605601816234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e605601816234 : Closed e605601816234 ∧ code e605601816234 = 2804625071786 := by decide
theorem cert_e605601816234 : check e605601816234 [[],[]] .chain = true := by decide
def e605601816750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e605601816750 : Closed e605601816750 ∧ code e605601816750 = 2804625072302 := by decide
theorem cert_e605601816750 : check e605601816750 [[],[]] .chain = true := by decide
def e605601816762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e605601816762 : Closed e605601816762 ∧ code e605601816762 = 2804625072314 := by decide
theorem cert_e605601816762 : check e605601816762 [[],[]] .chain = true := by decide
def e605601817326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 2))))))
theorem wire_e605601817326 : Closed e605601817326 ∧ code e605601817326 = 2804625072878 := by decide
theorem cert_e605601817326 : check e605601817326 [[],[]] .sourceHead = true := by decide
def e605601817454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e605601817454 : Closed e605601817454 ∧ code e605601817454 = 2804625073006 := by decide
theorem cert_e605601817454 : check e605601817454 [[],[]] .chain = true := by decide
def e605601817462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e605601817462 : Closed e605601817462 ∧ code e605601817462 = 2804625073014 := by decide
theorem cert_e605601817462 : check e605601817462 [[],[]] .chain = true := by decide
def e605601817518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e605601817518 : Closed e605601817518 ∧ code e605601817518 = 2804625073070 := by decide
theorem cert_e605601817518 : check e605601817518 [[],[]] .chain = true := by decide
def e605601817530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e605601817530 : Closed e605601817530 ∧ code e605601817530 = 2804625073082 := by decide
theorem cert_e605601817530 : check e605601817530 [[],[]] .chain = true := by decide
def e605601817558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e605601817558 : Closed e605601817558 ∧ code e605601817558 = 2804625073110 := by decide
theorem cert_e605601817558 : check e605601817558 [[],[]] .chain = true := by decide
def e605601817562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e605601817562 : Closed e605601817562 ∧ code e605601817562 = 2804625073114 := by decide
theorem cert_e605601817562 : check e605601817562 [[],[]] .chain = true := by decide
def e605601818286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e605601818286 : Closed e605601818286 ∧ code e605601818286 = 2804625073838 := by decide
theorem cert_e605601818286 : check e605601818286 [[],[]] .chain = true := by decide
def e605601818298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e605601818298 : Closed e605601818298 ∧ code e605601818298 = 2804625073850 := by decide
theorem cert_e605601818298 : check e605601818298 [[],[]] .chain = true := by decide
def e605601818346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e605601818346 : Closed e605601818346 ∧ code e605601818346 = 2804625073898 := by decide
theorem cert_e605601818346 : check e605601818346 [[],[]] .chain = true := by decide
def e605601818538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e605601818538 : Closed e605601818538 ∧ code e605601818538 = 2804625074090 := by decide
theorem cert_e605601818538 : check e605601818538 [[],[]] .chain = true := by decide
def e605601818670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e605601818670 : Closed e605601818670 ∧ code e605601818670 = 2804625074222 := by decide
theorem cert_e605601818670 : check e605601818670 [[],[]] .chain = true := by decide
def e605601818862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.var 2))))))
theorem wire_e605601818862 : Closed e605601818862 ∧ code e605601818862 = 2804625074414 := by decide
theorem cert_e605601818862 : check e605601818862 [[],[]] .chain = true := by decide
def e605601818870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))) (.var 1))))))
theorem wire_e605601818870 : Closed e605601818870 ∧ code e605601818870 = 2804625074422 := by decide
theorem cert_e605601818870 : check e605601818870 [[],[]] .chain = true := by decide
def e605601819054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e605601819054 : Closed e605601819054 ∧ code e605601819054 = 2804625074606 := by decide
theorem cert_e605601819054 : check e605601819054 [[],[]] .chain = true := by decide
def e605601819066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e605601819066 : Closed e605601819066 ∧ code e605601819066 = 2804625074618 := by decide
theorem cert_e605601819066 : check e605601819066 [[],[]] .chain = true := by decide
def e605601819114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e605601819114 : Closed e605601819114 ∧ code e605601819114 = 2804625074666 := by decide
theorem cert_e605601819114 : check e605601819114 [[],[]] .chain = true := by decide
def e605601819246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e605601819246 : Closed e605601819246 ∧ code e605601819246 = 2804625074798 := by decide
theorem cert_e605601819246 : check e605601819246 [[],[]] .chain = true := by decide
def e605601819258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e605601819258 : Closed e605601819258 ∧ code e605601819258 = 2804625074810 := by decide
theorem cert_e605601819258 : check e605601819258 [[],[]] .chain = true := by decide
def e605601819422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e605601819422 : Closed e605601819422 ∧ code e605601819422 = 2804625074974 := by decide
theorem cert_e605601819422 : check e605601819422 [[],[]] .chain = true := by decide
def e605601819522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e605601819522 : Closed e605601819522 ∧ code e605601819522 = 2804625075074 := by decide
theorem cert_e605601819522 : check e605601819522 [[],[]] .chain = true := by decide
def e605601819534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e605601819534 : Closed e605601819534 ∧ code e605601819534 = 2804625075086 := by decide
theorem cert_e605601819534 : check e605601819534 [[],[]] .chain = true := by decide
def e605601819546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601819546 : Closed e605601819546 ∧ code e605601819546 = 2804625075098 := by decide
theorem cert_e605601819546 : check e605601819546 [[],[]] .chain = true := by decide
def e605601819758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e605601819758 : Closed e605601819758 ∧ code e605601819758 = 2804625075310 := by decide
theorem cert_e605601819758 : check e605601819758 [[],[]] .chain = true := by decide
def e605601819770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e605601819770 : Closed e605601819770 ∧ code e605601819770 = 2804625075322 := by decide
theorem cert_e605601819770 : check e605601819770 [[],[]] .chain = true := by decide
def e605601819934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e605601819934 : Closed e605601819934 ∧ code e605601819934 = 2804625075486 := by decide
theorem cert_e605601819934 : check e605601819934 [[],[]] .chain = true := by decide
def e605601820102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e605601820102 : Closed e605601820102 ∧ code e605601820102 = 2804625075654 := by decide
theorem cert_e605601820102 : check e605601820102 [[],[]] .chain = true := by decide
def e605601820170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601820170 : Closed e605601820170 ∧ code e605601820170 = 2804625075722 := by decide
theorem cert_e605601820170 : check e605601820170 [[],[]] .chain = true := by decide
def e605601820206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 2))))))
theorem wire_e605601820206 : Closed e605601820206 ∧ code e605601820206 = 2804625075758 := by decide
theorem cert_e605601820206 : check e605601820206 [[],[]] .sourceHead = true := by decide
def e605601820214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))) (.var 1))))))
theorem wire_e605601820214 : Closed e605601820214 ∧ code e605601820214 = 2804625075766 := by decide
theorem cert_e605601820214 : check e605601820214 [[],[]] .chain = true := by decide
def e605601820218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.var 0))))))
theorem wire_e605601820218 : Closed e605601820218 ∧ code e605601820218 = 2804625075770 := by decide
theorem cert_e605601820218 : check e605601820218 [[],[]] .chain = true := by decide
def e605601820266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e605601820266 : Closed e605601820266 ∧ code e605601820266 = 2804625075818 := by decide
theorem cert_e605601820266 : check e605601820266 [[],[]] .chain = true := by decide
def e605601820290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e605601820290 : Closed e605601820290 ∧ code e605601820290 = 2804625075842 := by decide
theorem cert_e605601820290 : check e605601820290 [[],[]] .chain = true := by decide
def e605601820302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e605601820302 : Closed e605601820302 ∧ code e605601820302 = 2804625075854 := by decide
theorem cert_e605601820302 : check e605601820302 [[],[]] .chain = true := by decide
def e605601820314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601820314 : Closed e605601820314 ∧ code e605601820314 = 2804625075866 := by decide
theorem cert_e605601820314 : check e605601820314 [[],[]] .chain = true := by decide
def e605601820358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e605601820358 : Closed e605601820358 ∧ code e605601820358 = 2804625075910 := by decide
theorem cert_e605601820358 : check e605601820358 [[],[]] .chain = true := by decide
def e605601820386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e605601820386 : Closed e605601820386 ∧ code e605601820386 = 2804625075938 := by decide
theorem cert_e605601820386 : check e605601820386 [[],[]] .sourceHead = true := by decide
def e605601820398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 2))))))
theorem wire_e605601820398 : Closed e605601820398 ∧ code e605601820398 = 2804625075950 := by decide
theorem cert_e605601820398 : check e605601820398 [[],[]] .sourceHead = true := by decide
def e605601821102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e605601821102 : Closed e605601821102 ∧ code e605601821102 = 2804625076654 := by decide
theorem cert_e605601821102 : check e605601821102 [[],[]] .chain = true := by decide
def e605601821114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e605601821114 : Closed e605601821114 ∧ code e605601821114 = 2804625076666 := by decide
theorem cert_e605601821114 : check e605601821114 [[],[]] .chain = true := by decide
def e605601821162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e605601821162 : Closed e605601821162 ∧ code e605601821162 = 2804625076714 := by decide
theorem cert_e605601821162 : check e605601821162 [[],[]] .chain = true := by decide
def e605601821806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.var 2))))))
theorem wire_e605601821806 : Closed e605601821806 ∧ code e605601821806 = 2804625077358 := by decide
theorem cert_e605601821806 : check e605601821806 [[],[]] .chain = true := by decide
def e605601821818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.var 0))))))
theorem wire_e605601821818 : Closed e605601821818 ∧ code e605601821818 = 2804625077370 := by decide
theorem cert_e605601821818 : check e605601821818 [[],[]] .chain = true := by decide
def e605601821982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e605601821982 : Closed e605601821982 ∧ code e605601821982 = 2804625077534 := by decide
theorem cert_e605601821982 : check e605601821982 [[],[]] .chain = true := by decide
def e605601822150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e605601822150 : Closed e605601822150 ∧ code e605601822150 = 2804625077702 := by decide
theorem cert_e605601822150 : check e605601822150 [[],[]] .chain = true := by decide
def e605601822490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.var 0))))))
theorem wire_e605601822490 : Closed e605601822490 ∧ code e605601822490 = 2804625078042 := by decide
theorem cert_e605601822490 : check e605601822490 [[],[]] .chain = true := by decide
def e605601822534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e605601822534 : Closed e605601822534 ∧ code e605601822534 = 2804625078086 := by decide
theorem cert_e605601822534 : check e605601822534 [[],[]] .chain = true := by decide
def e605601822762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e605601822762 : Closed e605601822762 ∧ code e605601822762 = 2804625078314 := by decide
theorem cert_e605601822762 : check e605601822762 [[],[]] .chain = true := by decide
def e605601822894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e605601822894 : Closed e605601822894 ∧ code e605601822894 = 2804625078446 := by decide
theorem cert_e605601822894 : check e605601822894 [[],[]] .sourceHead = true := by decide
def e605601822906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e605601822906 : Closed e605601822906 ∧ code e605601822906 = 2804625078458 := by decide
theorem cert_e605601822906 : check e605601822906 [[],[]] .sourceHead = true := by decide
def e605601822934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e605601822934 : Closed e605601822934 ∧ code e605601822934 = 2804625078486 := by decide
theorem cert_e605601822934 : check e605601822934 [[],[]] .chain = true := by decide
def e605601822938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e605601822938 : Closed e605601822938 ∧ code e605601822938 = 2804625078490 := by decide
theorem cert_e605601822938 : check e605601822938 [[],[]] .chain = true := by decide
def e605601822954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e605601822954 : Closed e605601822954 ∧ code e605601822954 = 2804625078506 := by decide
theorem cert_e605601822954 : check e605601822954 [[],[]] .chain = true := by decide
def e605601823146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e605601823146 : Closed e605601823146 ∧ code e605601823146 = 2804625078698 := by decide
theorem cert_e605601823146 : check e605601823146 [[],[]] .chain = true := by decide
def e605601823242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e605601823242 : Closed e605601823242 ∧ code e605601823242 = 2804625078794 := by decide
theorem cert_e605601823242 : check e605601823242 [[],[]] .chain = true := by decide
def e605601823278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e605601823278 : Closed e605601823278 ∧ code e605601823278 = 2804625078830 := by decide
theorem cert_e605601823278 : check e605601823278 [[],[]] .sourceHead = true := by decide
def e605601823286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))) (.var 1))))))
theorem wire_e605601823286 : Closed e605601823286 ∧ code e605601823286 = 2804625078838 := by decide
theorem cert_e605601823286 : check e605601823286 [[],[]] .chain = true := by decide
def e605601823290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.var 0))))))
theorem wire_e605601823290 : Closed e605601823290 ∧ code e605601823290 = 2804625078842 := by decide
theorem cert_e605601823290 : check e605601823290 [[],[]] .chain = true := by decide
def e605601823338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e605601823338 : Closed e605601823338 ∧ code e605601823338 = 2804625078890 := by decide
theorem cert_e605601823338 : check e605601823338 [[],[]] .chain = true := by decide
def e605601823362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e605601823362 : Closed e605601823362 ∧ code e605601823362 = 2804625078914 := by decide
theorem cert_e605601823362 : check e605601823362 [[],[]] .chain = true := by decide
def e605601823374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e605601823374 : Closed e605601823374 ∧ code e605601823374 = 2804625078926 := by decide
theorem cert_e605601823374 : check e605601823374 [[],[]] .chain = true := by decide
def e605601823386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e605601823386 : Closed e605601823386 ∧ code e605601823386 = 2804625078938 := by decide
theorem cert_e605601823386 : check e605601823386 [[],[]] .chain = true := by decide
def e605601823430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e605601823430 : Closed e605601823430 ∧ code e605601823430 = 2804625078982 := by decide
theorem cert_e605601823430 : check e605601823430 [[],[]] .chain = true := by decide
def e605601823458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e605601823458 : Closed e605601823458 ∧ code e605601823458 = 2804625079010 := by decide
theorem cert_e605601823458 : check e605601823458 [[],[]] .sourceHead = true := by decide
def e605601823470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e605601823470 : Closed e605601823470 ∧ code e605601823470 = 2804625079022 := by decide
theorem cert_e605601823470 : check e605601823470 [[],[]] .sourceHead = true := by decide
def e605601823514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.var 0))))))
theorem wire_e605601823514 : Closed e605601823514 ∧ code e605601823514 = 2804625079066 := by decide
theorem cert_e605601823514 : check e605601823514 [[],[]] .chain = true := by decide
def e605601823558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e605601823558 : Closed e605601823558 ∧ code e605601823558 = 2804625079110 := by decide
theorem cert_e605601823558 : check e605601823558 [[],[]] .chain = true := by decide
def e605601823626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e605601823626 : Closed e605601823626 ∧ code e605601823626 = 2804625079178 := by decide
theorem cert_e605601823626 : check e605601823626 [[],[]] .sourceHead = true := by decide
def e605601823650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e605601823650 : Closed e605601823650 ∧ code e605601823650 = 2804625079202 := by decide
theorem cert_e605601823650 : check e605601823650 [[],[]] .sourceHead = true := by decide
def e605601823662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e605601823662 : Closed e605601823662 ∧ code e605601823662 = 2804625079214 := by decide
theorem cert_e605601823662 : check e605601823662 [[],[]] .sourceHead = true := by decide
def e605601823674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e605601823674 : Closed e605601823674 ∧ code e605601823674 = 2804625079226 := by decide
theorem cert_e605601823674 : check e605601823674 [[],[]] .sourceHead = true := by decide
def e605601825198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e605601825198 : Closed e605601825198 ∧ code e605601825198 = 2804625080750 := by decide
theorem cert_e605601825198 : check e605601825198 [[],[]] .sourceHead = true := by decide
def e605601825390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e605601825390 : Closed e605601825390 ∧ code e605601825390 = 2804625080942 := by decide
theorem cert_e605601825390 : check e605601825390 [[],[]] .chain = true := by decide
def e605601825402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e605601825402 : Closed e605601825402 ∧ code e605601825402 = 2804625080954 := by decide
theorem cert_e605601825402 : check e605601825402 [[],[]] .chain = true := by decide
def e605601825774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.var 2))))))
theorem wire_e605601825774 : Closed e605601825774 ∧ code e605601825774 = 2804625081326 := by decide
theorem cert_e605601825774 : check e605601825774 [[],[]] .sourceHead = true := by decide
def e605601826542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e605601826542 : Closed e605601826542 ∧ code e605601826542 = 2804625082094 := by decide
theorem cert_e605601826542 : check e605601826542 [[],[]] .chain = true := by decide
def e605601826550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))) (.var 1))))))
theorem wire_e605601826550 : Closed e605601826550 ∧ code e605601826550 = 2804625082102 := by decide
theorem cert_e605601826550 : check e605601826550 [[],[]] .chain = true := by decide
def e605601826670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e605601826670 : Closed e605601826670 ∧ code e605601826670 = 2804625082222 := by decide
theorem cert_e605601826670 : check e605601826670 [[],[]] .chain = true := by decide
def e605601826682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e605601826682 : Closed e605601826682 ∧ code e605601826682 = 2804625082234 := by decide
theorem cert_e605601826682 : check e605601826682 [[],[]] .chain = true := by decide
def e605601826734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e605601826734 : Closed e605601826734 ∧ code e605601826734 = 2804625082286 := by decide
theorem cert_e605601826734 : check e605601826734 [[],[]] .chain = true := by decide
def e605601826774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))) (.var 1))))))
theorem wire_e605601826774 : Closed e605601826774 ∧ code e605601826774 = 2804625082326 := by decide
theorem cert_e605601826774 : check e605601826774 [[],[]] .chain = true := by decide
def e605601826778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e605601826778 : Closed e605601826778 ∧ code e605601826778 = 2804625082330 := by decide
theorem cert_e605601826778 : check e605601826778 [[],[]] .chain = true := by decide
def e605601827310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e605601827310 : Closed e605601827310 ∧ code e605601827310 = 2804625082862 := by decide
theorem cert_e605601827310 : check e605601827310 [[],[]] .sourceHead = true := by decide
def e605601828078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e605601828078 : Closed e605601828078 ∧ code e605601828078 = 2804625083630 := by decide
theorem cert_e605601828078 : check e605601828078 [[],[]] .chain = true := by decide
def e605601828086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e605601828086 : Closed e605601828086 ∧ code e605601828086 = 2804625083638 := by decide
theorem cert_e605601828086 : check e605601828086 [[],[]] .chain = true := by decide
def e605601828462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e605601828462 : Closed e605601828462 ∧ code e605601828462 = 2804625084014 := by decide
theorem cert_e605601828462 : check e605601828462 [[],[]] .chain = true := by decide
def e605601828474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e605601828474 : Closed e605601828474 ∧ code e605601828474 = 2804625084026 := by decide
theorem cert_e605601828474 : check e605601828474 [[],[]] .chain = true := by decide
def e605601828638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 3)))))))
theorem wire_e605601828638 : Closed e605601828638 ∧ code e605601828638 = 2804625084190 := by decide
theorem cert_e605601828638 : check e605601828638 [[],[]] .sourceHead = true := by decide
def e605601828662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e605601828662 : Closed e605601828662 ∧ code e605601828662 = 2804625084214 := by decide
theorem cert_e605601828662 : check e605601828662 [[],[]] .chain = true := by decide
def e605601828666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e605601828666 : Closed e605601828666 ∧ code e605601828666 = 2804625084218 := by decide
theorem cert_e605601828666 : check e605601828666 [[],[]] .chain = true := by decide
def e605601830574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e605601830574 : Closed e605601830574 ∧ code e605601830574 = 2804625086126 := by decide
theorem cert_e605601830574 : check e605601830574 [[],[]] .chain = true := by decide
def e605601830586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e605601830586 : Closed e605601830586 ∧ code e605601830586 = 2804625086138 := by decide
theorem cert_e605601830586 : check e605601830586 [[],[]] .chain = true := by decide
def e605601830634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e605601830634 : Closed e605601830634 ∧ code e605601830634 = 2804625086186 := by decide
theorem cert_e605601830634 : check e605601830634 [[],[]] .chain = true := by decide
def e605601830826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e605601830826 : Closed e605601830826 ∧ code e605601830826 = 2804625086378 := by decide
theorem cert_e605601830826 : check e605601830826 [[],[]] .chain = true := by decide
def e605601830958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e605601830958 : Closed e605601830958 ∧ code e605601830958 = 2804625086510 := by decide
theorem cert_e605601830958 : check e605601830958 [[],[]] .chain = true := by decide
def e605601831150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e605601831150 : Closed e605601831150 ∧ code e605601831150 = 2804625086702 := by decide
theorem cert_e605601831150 : check e605601831150 [[],[]] .chain = true := by decide
def e605601831158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e605601831158 : Closed e605601831158 ∧ code e605601831158 = 2804625086710 := by decide
theorem cert_e605601831158 : check e605601831158 [[],[]] .chain = true := by decide
def e605601831342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e605601831342 : Closed e605601831342 ∧ code e605601831342 = 2804625086894 := by decide
theorem cert_e605601831342 : check e605601831342 [[],[]] .chain = true := by decide
def e605601831354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e605601831354 : Closed e605601831354 ∧ code e605601831354 = 2804625086906 := by decide
theorem cert_e605601831354 : check e605601831354 [[],[]] .chain = true := by decide
def e605601831402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e605601831402 : Closed e605601831402 ∧ code e605601831402 = 2804625086954 := by decide
theorem cert_e605601831402 : check e605601831402 [[],[]] .chain = true := by decide
def e605601831534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e605601831534 : Closed e605601831534 ∧ code e605601831534 = 2804625087086 := by decide
theorem cert_e605601831534 : check e605601831534 [[],[]] .chain = true := by decide
def e605601831546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e605601831546 : Closed e605601831546 ∧ code e605601831546 = 2804625087098 := by decide
theorem cert_e605601831546 : check e605601831546 [[],[]] .chain = true := by decide
def e605601831710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e605601831710 : Closed e605601831710 ∧ code e605601831710 = 2804625087262 := by decide
theorem cert_e605601831710 : check e605601831710 [[],[]] .chain = true := by decide
def e605601831810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e605601831810 : Closed e605601831810 ∧ code e605601831810 = 2804625087362 := by decide
theorem cert_e605601831810 : check e605601831810 [[],[]] .chain = true := by decide
def e605601831822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e605601831822 : Closed e605601831822 ∧ code e605601831822 = 2804625087374 := by decide
theorem cert_e605601831822 : check e605601831822 [[],[]] .chain = true := by decide
end Blc.Floor41
