import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605804311518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605804311518 : Closed e605804311518 ∧ code e605804311518 = 2804827567070 := by decide
theorem cert_e605804311518 : check e605804311518 [[],[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e605804311534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605804311534 : Closed e605804311534 ∧ code e605804311534 = 2804827567086 := by decide
theorem cert_e605804311534 : check e605804311534 [[],[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e605804313822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605804313822 : Closed e605804313822 ∧ code e605804313822 = 2804827569374 := by decide
theorem cert_e605804313822 : check e605804313822 [[],[],[],[.left],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e605804313850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605804313850 : Closed e605804313850 ∧ code e605804313850 = 2804827569402 := by decide
theorem cert_e605804313850 : check e605804313850 [[],[],[],[.left],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e605804314222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605804314222 : Closed e605804314222 ∧ code e605804314222 = 2804827569774 := by decide
theorem cert_e605804314222 : check e605804314222 [[],[],[],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e605804314234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605804314234 : Closed e605804314234 ∧ code e605804314234 = 2804827569786 := by decide
def e605804342638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605804342638 : Closed e605804342638 ∧ code e605804342638 = 2804827598190 := by decide
def e605804342646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605804342646 : Closed e605804342646 ∧ code e605804342646 = 2804827598198 := by decide
def e605804342702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605804342702 : Closed e605804342702 ∧ code e605804342702 = 2804827598254 := by decide
def e605804342714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605804342714 : Closed e605804342714 ∧ code e605804342714 = 2804827598266 := by decide
def e605804342742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605804342742 : Closed e605804342742 ∧ code e605804342742 = 2804827598294 := by decide
def e605804342746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605804342746 : Closed e605804342746 ∧ code e605804342746 = 2804827598298 := by decide
def e605804342958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605804342958 : Closed e605804342958 ∧ code e605804342958 = 2804827598510 := by decide
def e605804342970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605804342970 : Closed e605804342970 ∧ code e605804342970 = 2804827598522 := by decide
def e605804343018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605804343018 : Closed e605804343018 ∧ code e605804343018 = 2804827598570 := by decide
private def t_e605804343018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem cert_e605804343018 : ¬ IsSelfInterpreter e605804343018 :=
  wSource (t := t_e605804343018) (replay_sound (ps := []) (t := e605804343018) (by decide)) (by decide)
def e605804343126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605804343126 : Closed e605804343126 ∧ code e605804343126 = 2804827598678 := by decide
def e605804343130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605804343130 : Closed e605804343130 ∧ code e605804343130 = 2804827598682 := by decide
def e605804343146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605804343146 : Closed e605804343146 ∧ code e605804343146 = 2804827598698 := by decide
private def t_e605804343146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem cert_e605804343146 : ¬ IsSelfInterpreter e605804343146 :=
  wSource (t := t_e605804343146) (replay_sound (ps := []) (t := e605804343146) (by decide)) (by decide)
def e605804344174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605804344174 : Closed e605804344174 ∧ code e605804344174 = 2804827599726 := by decide
def e605804344182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605804344182 : Closed e605804344182 ∧ code e605804344182 = 2804827599734 := by decide
def e605804344238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605804344238 : Closed e605804344238 ∧ code e605804344238 = 2804827599790 := by decide
def e605804344250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605804344250 : Closed e605804344250 ∧ code e605804344250 = 2804827599802 := by decide
def e605804344278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605804344278 : Closed e605804344278 ∧ code e605804344278 = 2804827599830 := by decide
def e605804344282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605804344282 : Closed e605804344282 ∧ code e605804344282 = 2804827599834 := by decide
def e605804344558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605804344558 : Closed e605804344558 ∧ code e605804344558 = 2804827600110 := by decide
def e605804344566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605804344566 : Closed e605804344566 ∧ code e605804344566 = 2804827600118 := by decide
def e605804344942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605804344942 : Closed e605804344942 ∧ code e605804344942 = 2804827600494 := by decide
def e605804344954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605804344954 : Closed e605804344954 ∧ code e605804344954 = 2804827600506 := by decide
def e605804345142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605804345142 : Closed e605804345142 ∧ code e605804345142 = 2804827600694 := by decide
def e605804345146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605804345146 : Closed e605804345146 ∧ code e605804345146 = 2804827600698 := by decide
def e605804345774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e605804345774 : Closed e605804345774 ∧ code e605804345774 = 2804827601326 := by decide
def e605804345786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e605804345786 : Closed e605804345786 ∧ code e605804345786 = 2804827601338 := by decide
def e605804345834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e605804345834 : Closed e605804345834 ∧ code e605804345834 = 2804827601386 := by decide
def e605804345966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605804345966 : Closed e605804345966 ∧ code e605804345966 = 2804827601518 := by decide
def e605804345978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605804345978 : Closed e605804345978 ∧ code e605804345978 = 2804827601530 := by decide
def e605804346266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605804346266 : Closed e605804346266 ∧ code e605804346266 = 2804827601818 := by decide
private def t_e605804346266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem cert_e605804346266 : ¬ IsSelfInterpreter e605804346266 :=
  wSource (t := t_e605804346266) (replay_sound (ps := []) (t := e605804346266) (by decide)) (by decide)
def e605804346582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605804346582 : Closed e605804346582 ∧ code e605804346582 = 2804827602134 := by decide
def e605804346586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605804346586 : Closed e605804346586 ∧ code e605804346586 = 2804827602138 := by decide
def e605804346602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605804346602 : Closed e605804346602 ∧ code e605804346602 = 2804827602154 := by decide
def e605804346678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605804346678 : Closed e605804346678 ∧ code e605804346678 = 2804827602230 := by decide
def e605804346682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605804346682 : Closed e605804346682 ∧ code e605804346682 = 2804827602234 := by decide
def e605804346778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605804346778 : Closed e605804346778 ∧ code e605804346778 = 2804827602330 := by decide
private def t_e605804346778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem cert_e605804346778 : ¬ IsSelfInterpreter e605804346778 :=
  wSource (t := t_e605804346778) (replay_sound (ps := []) (t := e605804346778) (by decide)) (by decide)
def e605804348382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e605804348382 : Closed e605804348382 ∧ code e605804348382 = 2804827603934 := by decide
theorem cert_e605804348382 : check e605804348382 [[],[],[],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[],[],[],[]] .sourceHead = true := by decide
def e605804348398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e605804348398 : Closed e605804348398 ∧ code e605804348398 = 2804827603950 := by decide
theorem cert_e605804348398 : check e605804348398 [[],[],[],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[.left],[],[],[],[.left],[],[.left,.left],[.left],[.left],[],[],[],[]] .sourceHead = true := by decide
def e605804350318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605804350318 : Closed e605804350318 ∧ code e605804350318 = 2804827605870 := by decide
def e605804350326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605804350326 : Closed e605804350326 ∧ code e605804350326 = 2804827605878 := by decide
def e605804350382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605804350382 : Closed e605804350382 ∧ code e605804350382 = 2804827605934 := by decide
def e605804350394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605804350394 : Closed e605804350394 ∧ code e605804350394 = 2804827605946 := by decide
def e605804350422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605804350422 : Closed e605804350422 ∧ code e605804350422 = 2804827605974 := by decide
def e605804350426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605804350426 : Closed e605804350426 ∧ code e605804350426 = 2804827605978 := by decide
def e605804350702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605804350702 : Closed e605804350702 ∧ code e605804350702 = 2804827606254 := by decide
def e605804350710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605804350710 : Closed e605804350710 ∧ code e605804350710 = 2804827606262 := by decide
def e605804351086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605804351086 : Closed e605804351086 ∧ code e605804351086 = 2804827606638 := by decide
def e605804351098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605804351098 : Closed e605804351098 ∧ code e605804351098 = 2804827606650 := by decide
def e605804351286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605804351286 : Closed e605804351286 ∧ code e605804351286 = 2804827606838 := by decide
def e605804351290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605804351290 : Closed e605804351290 ∧ code e605804351290 = 2804827606842 := by decide
def e605804356062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605804356062 : Closed e605804356062 ∧ code e605804356062 = 2804827611614 := by decide
theorem cert_e605804356062 : check e605804356062 [[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[],[],[],[],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[],[]] .identityHead = true := by decide
def e605804356086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605804356086 : Closed e605804356086 ∧ code e605804356086 = 2804827611638 := by decide
def e605804357038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605804357038 : Closed e605804357038 ∧ code e605804357038 = 2804827612590 := by decide
def e605804357050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605804357050 : Closed e605804357050 ∧ code e605804357050 = 2804827612602 := by decide
def e605804357098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605804357098 : Closed e605804357098 ∧ code e605804357098 = 2804827612650 := by decide
def e605804357230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605804357230 : Closed e605804357230 ∧ code e605804357230 = 2804827612782 := by decide
def e605804357242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605804357242 : Closed e605804357242 ∧ code e605804357242 = 2804827612794 := by decide
def e605804357530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605804357530 : Closed e605804357530 ∧ code e605804357530 = 2804827613082 := by decide
def e605804359918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605804359918 : Closed e605804359918 ∧ code e605804359918 = 2804827615470 := by decide
def e605804359926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605804359926 : Closed e605804359926 ∧ code e605804359926 = 2804827615478 := by decide
def e605804360406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605804360406 : Closed e605804360406 ∧ code e605804360406 = 2804827615958 := by decide
def e605804360410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605804360410 : Closed e605804360410 ∧ code e605804360410 = 2804827615962 := by decide
def e605804360426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605804360426 : Closed e605804360426 ∧ code e605804360426 = 2804827615978 := by decide
def e605804360502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605804360502 : Closed e605804360502 ∧ code e605804360502 = 2804827616054 := by decide
def e605804360506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605804360506 : Closed e605804360506 ∧ code e605804360506 = 2804827616058 := by decide
def e605804360602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605804360602 : Closed e605804360602 ∧ code e605804360602 = 2804827616154 := by decide
def e605804497774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605804497774 : Closed e605804497774 ∧ code e605804497774 = 2804827753326 := by decide
private def t_e605804497774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem cert_e605804497774 : ¬ IsSelfInterpreter e605804497774 :=
  wSource (t := t_e605804497774) (replay_sound (ps := []) (t := e605804497774) (by decide)) (by decide)
def e605804497782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605804497782 : Closed e605804497782 ∧ code e605804497782 = 2804827753334 := by decide
private def t_e605804497782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem cert_e605804497782 : ¬ IsSelfInterpreter e605804497782 :=
  wSource (t := t_e605804497782) (replay_sound (ps := []) (t := e605804497782) (by decide)) (by decide)
def e605804497838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605804497838 : Closed e605804497838 ∧ code e605804497838 = 2804827753390 := by decide
private def t_e605804497838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem cert_e605804497838 : ¬ IsSelfInterpreter e605804497838 :=
  wSource (t := t_e605804497838) (replay_sound (ps := []) (t := e605804497838) (by decide)) (by decide)
def e605804497850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605804497850 : Closed e605804497850 ∧ code e605804497850 = 2804827753402 := by decide
private def t_e605804497850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e605804497850 : ¬ IsSelfInterpreter e605804497850 :=
  wSource (t := t_e605804497850) (replay_sound (ps := []) (t := e605804497850) (by decide)) (by decide)
def e605804497878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605804497878 : Closed e605804497878 ∧ code e605804497878 = 2804827753430 := by decide
private def t_e605804497878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem cert_e605804497878 : ¬ IsSelfInterpreter e605804497878 :=
  wSource (t := t_e605804497878) (replay_sound (ps := []) (t := e605804497878) (by decide)) (by decide)
def e605804497882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605804497882 : Closed e605804497882 ∧ code e605804497882 = 2804827753434 := by decide
private def t_e605804497882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e605804497882 : ¬ IsSelfInterpreter e605804497882 :=
  wSource (t := t_e605804497882) (replay_sound (ps := []) (t := e605804497882) (by decide)) (by decide)
def e605804498158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605804498158 : Closed e605804498158 ∧ code e605804498158 = 2804827753710 := by decide
private def t_e605804498158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem cert_e605804498158 : ¬ IsSelfInterpreter e605804498158 :=
  wSource (t := t_e605804498158) (replay_sound (ps := []) (t := e605804498158) (by decide)) (by decide)
def e605804498166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605804498166 : Closed e605804498166 ∧ code e605804498166 = 2804827753718 := by decide
private def t_e605804498166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem cert_e605804498166 : ¬ IsSelfInterpreter e605804498166 :=
  wSource (t := t_e605804498166) (replay_sound (ps := []) (t := e605804498166) (by decide)) (by decide)
def e605804498542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605804498542 : Closed e605804498542 ∧ code e605804498542 = 2804827754094 := by decide
private def t_e605804498542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem cert_e605804498542 : ¬ IsSelfInterpreter e605804498542 :=
  wSource (t := t_e605804498542) (replay_sound (ps := []) (t := e605804498542) (by decide)) (by decide)
def e605804498554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605804498554 : Closed e605804498554 ∧ code e605804498554 = 2804827754106 := by decide
private def t_e605804498554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem cert_e605804498554 : ¬ IsSelfInterpreter e605804498554 :=
  wSource (t := t_e605804498554) (replay_sound (ps := []) (t := e605804498554) (by decide)) (by decide)
def e605804498742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605804498742 : Closed e605804498742 ∧ code e605804498742 = 2804827754294 := by decide
private def t_e605804498742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem cert_e605804498742 : ¬ IsSelfInterpreter e605804498742 :=
  wSource (t := t_e605804498742) (replay_sound (ps := []) (t := e605804498742) (by decide)) (by decide)
def e605804498746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605804498746 : Closed e605804498746 ∧ code e605804498746 = 2804827754298 := by decide
private def t_e605804498746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem cert_e605804498746 : ¬ IsSelfInterpreter e605804498746 :=
  wSource (t := t_e605804498746) (replay_sound (ps := []) (t := e605804498746) (by decide)) (by decide)
def e605805087598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605805087598 : Closed e605805087598 ∧ code e605805087598 = 2804828343150 := by decide
def e605805087606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605805087606 : Closed e605805087606 ∧ code e605805087606 = 2804828343158 := by decide
def e605805087662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605805087662 : Closed e605805087662 ∧ code e605805087662 = 2804828343214 := by decide
def e605805087674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605805087674 : Closed e605805087674 ∧ code e605805087674 = 2804828343226 := by decide
private def t_e605805087674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e605805087674 : ¬ IsSelfInterpreter e605805087674 :=
  wSource (t := t_e605805087674) (replay_sound (ps := []) (t := e605805087674) (by decide)) (by decide)
def e605805087702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605805087702 : Closed e605805087702 ∧ code e605805087702 = 2804828343254 := by decide
def e605805087706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605805087706 : Closed e605805087706 ∧ code e605805087706 = 2804828343258 := by decide
private def t_e605805087706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e605805087706 : ¬ IsSelfInterpreter e605805087706 :=
  wSource (t := t_e605805087706) (replay_sound (ps := []) (t := e605805087706) (by decide)) (by decide)
def e605805087982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605805087982 : Closed e605805087982 ∧ code e605805087982 = 2804828343534 := by decide
def e605805087990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605805087990 : Closed e605805087990 ∧ code e605805087990 = 2804828343542 := by decide
def e605805088366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605805088366 : Closed e605805088366 ∧ code e605805088366 = 2804828343918 := by decide
def e605805088378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605805088378 : Closed e605805088378 ∧ code e605805088378 = 2804828343930 := by decide
def e605805088566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605805088566 : Closed e605805088566 ∧ code e605805088566 = 2804828344118 := by decide
def e605805088570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605805088570 : Closed e605805088570 ∧ code e605805088570 = 2804828344122 := by decide
def e606181788526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e606181788526 : Closed e606181788526 ∧ code e606181788526 = 2805205044078 := by decide
theorem cert_e606181788526 : check e606181788526 [[],[.left]] .chain = true := by decide
def e606181788534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e606181788534 : Closed e606181788534 ∧ code e606181788534 = 2805205044086 := by decide
theorem cert_e606181788534 : check e606181788534 [[],[.left]] .chain = true := by decide
def e606181788590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e606181788590 : Closed e606181788590 ∧ code e606181788590 = 2805205044142 := by decide
theorem cert_e606181788590 : check e606181788590 [[],[.left]] .chain = true := by decide
def e606181788602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e606181788602 : Closed e606181788602 ∧ code e606181788602 = 2805205044154 := by decide
theorem cert_e606181788602 : check e606181788602 [[],[.left]] .chain = true := by decide
def e606181788630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e606181788630 : Closed e606181788630 ∧ code e606181788630 = 2805205044182 := by decide
theorem cert_e606181788630 : check e606181788630 [[],[.left]] .chain = true := by decide
def e606181788634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e606181788634 : Closed e606181788634 ∧ code e606181788634 = 2805205044186 := by decide
theorem cert_e606181788634 : check e606181788634 [[],[.left]] .chain = true := by decide
def e606181788910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e606181788910 : Closed e606181788910 ∧ code e606181788910 = 2805205044462 := by decide
theorem cert_e606181788910 : check e606181788910 [[],[.left]] .chain = true := by decide
def e606181788918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e606181788918 : Closed e606181788918 ∧ code e606181788918 = 2805205044470 := by decide
theorem cert_e606181788918 : check e606181788918 [[],[.left]] .chain = true := by decide
def e606181789294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e606181789294 : Closed e606181789294 ∧ code e606181789294 = 2805205044846 := by decide
theorem cert_e606181789294 : check e606181789294 [[],[.left]] .chain = true := by decide
def e606181789306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e606181789306 : Closed e606181789306 ∧ code e606181789306 = 2805205044858 := by decide
theorem cert_e606181789306 : check e606181789306 [[],[.left]] .chain = true := by decide
def e606181789494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e606181789494 : Closed e606181789494 ∧ code e606181789494 = 2805205045046 := by decide
theorem cert_e606181789494 : check e606181789494 [[],[.left]] .chain = true := by decide
def e606181789498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e606181789498 : Closed e606181789498 ∧ code e606181789498 = 2805205045050 := by decide
theorem cert_e606181789498 : check e606181789498 [[],[.left]] .chain = true := by decide
def e700127609250 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 0)))
theorem wire_e700127609250 : Closed e700127609250 ∧ code e700127609250 = 2899150864802 := by decide
theorem cert_e700127609250 : check e700127609250 [[.left]] .width = true := by decide
def e700127740322 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 0)))
theorem wire_e700127740322 : Closed e700127740322 ∧ code e700127740322 = 2899150995874 := by decide
theorem cert_e700127740322 : check e700127740322 [[.left]] .width = true := by decide
def e700128657826 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 0)))
theorem wire_e700128657826 : Closed e700128657826 ∧ code e700128657826 = 2899151913378 := by decide
theorem cert_e700128657826 : check e700128657826 [[.left]] .width = true := by decide
def e700128854434 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 0)))
theorem wire_e700128854434 : Closed e700128854434 ∧ code e700128854434 = 2899152109986 := by decide
theorem cert_e700128854434 : check e700128854434 [[.left]] .width = true := by decide
def e700129313186 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 0)))
theorem wire_e700129313186 : Closed e700129313186 ∧ code e700129313186 = 2899152568738 := by decide
theorem cert_e700129313186 : check e700129313186 [[.left]] .width = true := by decide
def e700129378722 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 0)))
theorem wire_e700129378722 : Closed e700129378722 ∧ code e700129378722 = 2899152634274 := by decide
theorem cert_e700129378722 : check e700129378722 [[.left]] .width = true := by decide
def e700133900706 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 0)))
theorem wire_e700133900706 : Closed e700133900706 ∧ code e700133900706 = 2899157156258 := by decide
theorem cert_e700133900706 : check e700133900706 [[.left]] .width = true := by decide
def e700134031778 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 0)))
theorem wire_e700134031778 : Closed e700134031778 ∧ code e700134031778 = 2899157287330 := by decide
theorem cert_e700134031778 : check e700134031778 [[.left]] .width = true := by decide
def e700140192162 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 0)))
theorem wire_e700140192162 : Closed e700140192162 ∧ code e700140192162 = 2899163447714 := by decide
theorem cert_e700140192162 : check e700140192162 [[.left]] .width = true := by decide
def e700140388770 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 0)))
theorem wire_e700140388770 : Closed e700140388770 ∧ code e700140388770 = 2899163644322 := by decide
theorem cert_e700140388770 : check e700140388770 [[.left]] .width = true := by decide
def e700143468962 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 0)))
theorem wire_e700143468962 : Closed e700143468962 ∧ code e700143468962 = 2899166724514 := by decide
theorem cert_e700143468962 : check e700143468962 [[.left]] .width = true := by decide
def e700143534498 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 0)))
theorem wire_e700143534498 : Closed e700143534498 ∧ code e700143534498 = 2899166790050 := by decide
theorem cert_e700143534498 : check e700143534498 [[.left]] .width = true := by decide
def e701154121442 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701154121442 : Closed e701154121442 ∧ code e701154121442 = 2900177376994 := by decide
theorem cert_e701154121442 : check e701154121442 [[.left],[.left]] .smaller = true := by decide
def e701154121570 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e701154121570 : Closed e701154121570 ∧ code e701154121570 = 2900177377122 := by decide
theorem cert_e701154121570 : check e701154121570 [[.left],[.left]] .smaller = true := by decide
def e701154122466 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701154122466 : Closed e701154122466 ∧ code e701154122466 = 2900177378018 := by decide
theorem cert_e701154122466 : check e701154122466 [[.left],[.left]] .smaller = true := by decide
def e701154122658 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701154122658 : Closed e701154122658 ∧ code e701154122658 = 2900177378210 := by decide
theorem cert_e701154122658 : check e701154122658 [[.left],[.left]] .smaller = true := by decide
def e701154123106 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e701154123106 : Closed e701154123106 ∧ code e701154123106 = 2900177378658 := by decide
theorem cert_e701154123106 : check e701154123106 [[.left],[.left]] .smaller = true := by decide
def e701154123170 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701154123170 : Closed e701154123170 ∧ code e701154123170 = 2900177378722 := by decide
theorem cert_e701154123170 : check e701154123170 [[.left],[.left]] .smaller = true := by decide
def e701154126562 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701154126562 : Closed e701154126562 ∧ code e701154126562 = 2900177382114 := by decide
theorem cert_e701154126562 : check e701154126562 [[.left],[.left]] .smaller = true := by decide
def e701154126754 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701154126754 : Closed e701154126754 ∧ code e701154126754 = 2900177382306 := by decide
theorem cert_e701154126754 : check e701154126754 [[.left],[.left]] .smaller = true := by decide
def e701154127522 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701154127522 : Closed e701154127522 ∧ code e701154127522 = 2900177383074 := by decide
theorem cert_e701154127522 : check e701154127522 [[.left],[.left]] .smaller = true := by decide
def e701154129250 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e701154129250 : Closed e701154129250 ∧ code e701154129250 = 2900177384802 := by decide
theorem cert_e701154129250 : check e701154129250 [[.left],[.left]] .smaller = true := by decide
def e701154129314 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701154129314 : Closed e701154129314 ∧ code e701154129314 = 2900177384866 := by decide
theorem cert_e701154129314 : check e701154129314 [[.left],[.left]] .smaller = true := by decide
def e701154129570 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701154129570 : Closed e701154129570 ∧ code e701154129570 = 2900177385122 := by decide
theorem cert_e701154129570 : check e701154129570 [[.left],[.left]] .smaller = true := by decide
def e701154146018 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701154146018 : Closed e701154146018 ∧ code e701154146018 = 2900177401570 := by decide
theorem cert_e701154146018 : check e701154146018 [[.left],[.left]] .smaller = true := by decide
def e701154146146 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e701154146146 : Closed e701154146146 ∧ code e701154146146 = 2900177401698 := by decide
theorem cert_e701154146146 : check e701154146146 [[.left],[.left]] .smaller = true := by decide
def e701154147042 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701154147042 : Closed e701154147042 ∧ code e701154147042 = 2900177402594 := by decide
theorem cert_e701154147042 : check e701154147042 [[.left],[.left]] .smaller = true := by decide
def e701154147234 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701154147234 : Closed e701154147234 ∧ code e701154147234 = 2900177402786 := by decide
theorem cert_e701154147234 : check e701154147234 [[.left],[.left]] .smaller = true := by decide
def e701154147682 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e701154147682 : Closed e701154147682 ∧ code e701154147682 = 2900177403234 := by decide
theorem cert_e701154147682 : check e701154147682 [[.left],[.left]] .smaller = true := by decide
def e701154147746 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701154147746 : Closed e701154147746 ∧ code e701154147746 = 2900177403298 := by decide
theorem cert_e701154147746 : check e701154147746 [[.left],[.left]] .smaller = true := by decide
def e701154152162 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701154152162 : Closed e701154152162 ∧ code e701154152162 = 2900177407714 := by decide
theorem cert_e701154152162 : check e701154152162 [[.left],[.left]] .smaller = true := by decide
def e701154152290 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e701154152290 : Closed e701154152290 ∧ code e701154152290 = 2900177407842 := by decide
theorem cert_e701154152290 : check e701154152290 [[.left],[.left]] .smaller = true := by decide
def e701154158306 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701154158306 : Closed e701154158306 ∧ code e701154158306 = 2900177413858 := by decide
theorem cert_e701154158306 : check e701154158306 [[.left],[.left]] .smaller = true := by decide
def e701154158498 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701154158498 : Closed e701154158498 ∧ code e701154158498 = 2900177414050 := by decide
theorem cert_e701154158498 : check e701154158498 [[.left],[.left]] .smaller = true := by decide
def e701154160154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e701154160154 : Closed e701154160154 ∧ code e701154160154 = 2900177415706 := by decide
theorem cert_e701154160154 : check e701154160154 [[.left]] .chain = true := by decide
def e701154161506 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e701154161506 : Closed e701154161506 ∧ code e701154161506 = 2900177417058 := by decide
theorem cert_e701154161506 : check e701154161506 [[.left],[.left]] .smaller = true := by decide
def e701154161570 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701154161570 : Closed e701154161570 ∧ code e701154161570 = 2900177417122 := by decide
theorem cert_e701154161570 : check e701154161570 [[.left],[.left]] .smaller = true := by decide
def e701154162202 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e701154162202 : Closed e701154162202 ∧ code e701154162202 = 2900177417754 := by decide
theorem cert_e701154162202 : check e701154162202 [[.left]] .chain = true := by decide
def e701154171618 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.var 0)))
theorem wire_e701154171618 : Closed e701154171618 ∧ code e701154171618 = 2900177427170 := by decide
theorem cert_e701154171618 : check e701154171618 [[.left],[.left]] .smaller = true := by decide
def e701154171810 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701154171810 : Closed e701154171810 ∧ code e701154171810 = 2900177427362 := by decide
theorem cert_e701154171810 : check e701154171810 [[.left],[.left]] .smaller = true := by decide
def e701154172578 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701154172578 : Closed e701154172578 ∧ code e701154172578 = 2900177428130 := by decide
theorem cert_e701154172578 : check e701154172578 [[.left],[.left]] .smaller = true := by decide
def e701154174690 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e701154174690 : Closed e701154174690 ∧ code e701154174690 = 2900177430242 := by decide
theorem cert_e701154174690 : check e701154174690 [[.left],[.left]] .smaller = true := by decide
def e701154174882 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701154174882 : Closed e701154174882 ∧ code e701154174882 = 2900177430434 := by decide
theorem cert_e701154174882 : check e701154174882 [[.left],[.left]] .smaller = true := by decide
def e701154176538 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e701154176538 : Closed e701154176538 ∧ code e701154176538 = 2900177432090 := by decide
theorem cert_e701154176538 : check e701154176538 [[.left]] .chain = true := by decide
def e701154179490 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701154179490 : Closed e701154179490 ∧ code e701154179490 = 2900177435042 := by decide
theorem cert_e701154179490 : check e701154179490 [[.left],[.left]] .smaller = true := by decide
def e701154179610 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e701154179610 : Closed e701154179610 ∧ code e701154179610 = 2900177435162 := by decide
theorem cert_e701154179610 : check e701154179610 [[.left]] .chain = true := by decide
def e701154184546 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.var 0)))
theorem wire_e701154184546 : Closed e701154184546 ∧ code e701154184546 = 2900177440098 := by decide
theorem cert_e701154184546 : check e701154184546 [[.left],[.left]] .smaller = true := by decide
def e701154184610 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701154184610 : Closed e701154184610 ∧ code e701154184610 = 2900177440162 := by decide
theorem cert_e701154184610 : check e701154184610 [[.left],[.left]] .smaller = true := by decide
def e701154184866 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.var 0)))
theorem wire_e701154184866 : Closed e701154184866 ∧ code e701154184866 = 2900177440418 := by decide
theorem cert_e701154184866 : check e701154184866 [[.left],[.left]] .smaller = true := by decide
def e701154186082 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e701154186082 : Closed e701154186082 ∧ code e701154186082 = 2900177441634 := by decide
theorem cert_e701154186082 : check e701154186082 [[.left],[.left]] .smaller = true := by decide
def e701154186146 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e701154186146 : Closed e701154186146 ∧ code e701154186146 = 2900177441698 := by decide
theorem cert_e701154186146 : check e701154186146 [[.left],[.left]] .smaller = true := by decide
def e701154186778 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e701154186778 : Closed e701154186778 ∧ code e701154186778 = 2900177442330 := by decide
theorem cert_e701154186778 : check e701154186778 [[.left]] .chain = true := by decide
end Blc.Floor41
