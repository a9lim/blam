import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605603912578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e605603912578 : Closed e605603912578 ∧ code e605603912578 = 2804627168130 := by decide
theorem cert_e605603912578 : check e605603912578 [[],[]] .chain = true := by decide
def e605603912590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605603912590 : Closed e605603912590 ∧ code e605603912590 = 2804627168142 := by decide
theorem cert_e605603912590 : check e605603912590 [[],[]] .chain = true := by decide
def e605603912602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603912602 : Closed e605603912602 ∧ code e605603912602 = 2804627168154 := by decide
theorem cert_e605603912602 : check e605603912602 [[],[]] .chain = true := by decide
def e605603912814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605603912814 : Closed e605603912814 ∧ code e605603912814 = 2804627168366 := by decide
theorem cert_e605603912814 : check e605603912814 [[],[]] .chain = true := by decide
def e605603912826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605603912826 : Closed e605603912826 ∧ code e605603912826 = 2804627168378 := by decide
theorem cert_e605603912826 : check e605603912826 [[],[]] .chain = true := by decide
def e605603912990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605603912990 : Closed e605603912990 ∧ code e605603912990 = 2804627168542 := by decide
theorem cert_e605603912990 : check e605603912990 [[],[]] .chain = true := by decide
def e605603913158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605603913158 : Closed e605603913158 ∧ code e605603913158 = 2804627168710 := by decide
theorem cert_e605603913158 : check e605603913158 [[],[]] .chain = true := by decide
def e605603913226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605603913226 : Closed e605603913226 ∧ code e605603913226 = 2804627168778 := by decide
theorem cert_e605603913226 : check e605603913226 [[],[]] .chain = true := by decide
def e605603913262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605603913262 : Closed e605603913262 ∧ code e605603913262 = 2804627168814 := by decide
theorem cert_e605603913262 : check e605603913262 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603913270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605603913270 : Closed e605603913270 ∧ code e605603913270 = 2804627168822 := by decide
theorem cert_e605603913270 : check e605603913270 [[],[]] .chain = true := by decide
def e605603913274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605603913274 : Closed e605603913274 ∧ code e605603913274 = 2804627168826 := by decide
theorem cert_e605603913274 : check e605603913274 [[],[]] .chain = true := by decide
def e605603913322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605603913322 : Closed e605603913322 ∧ code e605603913322 = 2804627168874 := by decide
theorem cert_e605603913322 : check e605603913322 [[],[]] .chain = true := by decide
def e605603913346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e605603913346 : Closed e605603913346 ∧ code e605603913346 = 2804627168898 := by decide
theorem cert_e605603913346 : check e605603913346 [[],[]] .chain = true := by decide
def e605603913358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605603913358 : Closed e605603913358 ∧ code e605603913358 = 2804627168910 := by decide
theorem cert_e605603913358 : check e605603913358 [[],[]] .chain = true := by decide
def e605603913370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603913370 : Closed e605603913370 ∧ code e605603913370 = 2804627168922 := by decide
theorem cert_e605603913370 : check e605603913370 [[],[]] .chain = true := by decide
def e605603913414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605603913414 : Closed e605603913414 ∧ code e605603913414 = 2804627168966 := by decide
theorem cert_e605603913414 : check e605603913414 [[],[]] .chain = true := by decide
def e605603913442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605603913442 : Closed e605603913442 ∧ code e605603913442 = 2804627168994 := by decide
theorem cert_e605603913442 : check e605603913442 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603913454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 2))))))))
theorem wire_e605603913454 : Closed e605603913454 ∧ code e605603913454 = 2804627169006 := by decide
theorem cert_e605603913454 : check e605603913454 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603914206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e605603914206 : Closed e605603914206 ∧ code e605603914206 = 2804627169758 := by decide
theorem cert_e605603914206 : check e605603914206 [[],[]] .chain = true := by decide
def e605603914230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e605603914230 : Closed e605603914230 ∧ code e605603914230 = 2804627169782 := by decide
theorem cert_e605603914230 : check e605603914230 [[],[]] .chain = true := by decide
def e605603915182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e605603915182 : Closed e605603915182 ∧ code e605603915182 = 2804627170734 := by decide
theorem cert_e605603915182 : check e605603915182 [[],[]] .chain = true := by decide
def e605603915194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e605603915194 : Closed e605603915194 ∧ code e605603915194 = 2804627170746 := by decide
theorem cert_e605603915194 : check e605603915194 [[],[]] .chain = true := by decide
def e605603915242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e605603915242 : Closed e605603915242 ∧ code e605603915242 = 2804627170794 := by decide
theorem cert_e605603915242 : check e605603915242 [[],[]] .chain = true := by decide
def e605603915374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e605603915374 : Closed e605603915374 ∧ code e605603915374 = 2804627170926 := by decide
theorem cert_e605603915374 : check e605603915374 [[],[]] .chain = true := by decide
def e605603915386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e605603915386 : Closed e605603915386 ∧ code e605603915386 = 2804627170938 := by decide
theorem cert_e605603915386 : check e605603915386 [[],[]] .chain = true := by decide
def e605603915550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605603915550 : Closed e605603915550 ∧ code e605603915550 = 2804627171102 := by decide
theorem cert_e605603915550 : check e605603915550 [[],[]] .chain = true := by decide
def e605603915650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e605603915650 : Closed e605603915650 ∧ code e605603915650 = 2804627171202 := by decide
theorem cert_e605603915650 : check e605603915650 [[],[]] .chain = true := by decide
def e605603915662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605603915662 : Closed e605603915662 ∧ code e605603915662 = 2804627171214 := by decide
theorem cert_e605603915662 : check e605603915662 [[],[]] .chain = true := by decide
def e605603915674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e605603915674 : Closed e605603915674 ∧ code e605603915674 = 2804627171226 := by decide
theorem cert_e605603915674 : check e605603915674 [[],[]] .chain = true := by decide
def e605603918046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e605603918046 : Closed e605603918046 ∧ code e605603918046 = 2804627173598 := by decide
theorem cert_e605603918046 : check e605603918046 [[],[]] .chain = true := by decide
def e605603918074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e605603918074 : Closed e605603918074 ∧ code e605603918074 = 2804627173626 := by decide
theorem cert_e605603918074 : check e605603918074 [[],[]] .chain = true := by decide
def e605603918622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605603918622 : Closed e605603918622 ∧ code e605603918622 = 2804627174174 := by decide
theorem cert_e605603918622 : check e605603918622 [[],[]] .chain = true := by decide
def e605603918790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605603918790 : Closed e605603918790 ∧ code e605603918790 = 2804627174342 := by decide
theorem cert_e605603918790 : check e605603918790 [[],[]] .chain = true := by decide
def e605603919898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e605603919898 : Closed e605603919898 ∧ code e605603919898 = 2804627175450 := by decide
theorem cert_e605603919898 : check e605603919898 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603919934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 4))))))))))
theorem wire_e605603919934 : Closed e605603919934 ∧ code e605603919934 = 2804627175486 := by decide
theorem cert_e605603919934 : check e605603919934 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603919982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e605603919982 : Closed e605603919982 ∧ code e605603919982 = 2804627175534 := by decide
theorem cert_e605603919982 : check e605603919982 [[],[]] .chain = true := by decide
def e605603919990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605603919990 : Closed e605603919990 ∧ code e605603919990 = 2804627175542 := by decide
theorem cert_e605603919990 : check e605603919990 [[],[]] .chain = true := by decide
def e605603919994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e605603919994 : Closed e605603919994 ∧ code e605603919994 = 2804627175546 := by decide
theorem cert_e605603919994 : check e605603919994 [[],[]] .chain = true := by decide
def e605603920234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605603920234 : Closed e605603920234 ∧ code e605603920234 = 2804627175786 := by decide
theorem cert_e605603920234 : check e605603920234 [[],[]] .chain = true := by decide
def e605603920258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e605603920258 : Closed e605603920258 ∧ code e605603920258 = 2804627175810 := by decide
theorem cert_e605603920258 : check e605603920258 [[],[]] .chain = true := by decide
def e605603920270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605603920270 : Closed e605603920270 ∧ code e605603920270 = 2804627175822 := by decide
theorem cert_e605603920270 : check e605603920270 [[],[]] .chain = true := by decide
def e605603920282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605603920282 : Closed e605603920282 ∧ code e605603920282 = 2804627175834 := by decide
theorem cert_e605603920282 : check e605603920282 [[],[]] .chain = true := by decide
def e605603920326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605603920326 : Closed e605603920326 ∧ code e605603920326 = 2804627175878 := by decide
theorem cert_e605603920326 : check e605603920326 [[],[]] .chain = true := by decide
def e605603920354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605603920354 : Closed e605603920354 ∧ code e605603920354 = 2804627175906 := by decide
theorem cert_e605603920354 : check e605603920354 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603920366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 2)))))))))
theorem wire_e605603920366 : Closed e605603920366 ∧ code e605603920366 = 2804627175918 := by decide
theorem cert_e605603920366 : check e605603920366 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603955678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e605603955678 : Closed e605603955678 ∧ code e605603955678 = 2804627211230 := by decide
theorem cert_e605603955678 : check e605603955678 [[],[]] .chain = true := by decide
def e605603955694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e605603955694 : Closed e605603955694 ∧ code e605603955694 = 2804627211246 := by decide
theorem cert_e605603955694 : check e605603955694 [[],[]] .chain = true := by decide
def e605603957614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605603957614 : Closed e605603957614 ∧ code e605603957614 = 2804627213166 := by decide
theorem cert_e605603957614 : check e605603957614 [[],[]] .chain = true := by decide
def e605603957622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605603957622 : Closed e605603957622 ∧ code e605603957622 = 2804627213174 := by decide
theorem cert_e605603957622 : check e605603957622 [[],[]] .chain = true := by decide
def e605603957678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605603957678 : Closed e605603957678 ∧ code e605603957678 = 2804627213230 := by decide
theorem cert_e605603957678 : check e605603957678 [[],[]] .chain = true := by decide
def e605603957690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605603957690 : Closed e605603957690 ∧ code e605603957690 = 2804627213242 := by decide
theorem cert_e605603957690 : check e605603957690 [[],[]] .chain = true := by decide
def e605603957718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605603957718 : Closed e605603957718 ∧ code e605603957718 = 2804627213270 := by decide
theorem cert_e605603957718 : check e605603957718 [[],[]] .chain = true := by decide
def e605603957722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605603957722 : Closed e605603957722 ∧ code e605603957722 = 2804627213274 := by decide
theorem cert_e605603957722 : check e605603957722 [[],[]] .chain = true := by decide
def e605603957998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605603957998 : Closed e605603957998 ∧ code e605603957998 = 2804627213550 := by decide
theorem cert_e605603957998 : check e605603957998 [[],[]] .chain = true := by decide
def e605603958006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605603958006 : Closed e605603958006 ∧ code e605603958006 = 2804627213558 := by decide
theorem cert_e605603958006 : check e605603958006 [[],[]] .chain = true := by decide
def e605603958382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605603958382 : Closed e605603958382 ∧ code e605603958382 = 2804627213934 := by decide
theorem cert_e605603958382 : check e605603958382 [[],[]] .chain = true := by decide
def e605603958394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605603958394 : Closed e605603958394 ∧ code e605603958394 = 2804627213946 := by decide
theorem cert_e605603958394 : check e605603958394 [[],[]] .chain = true := by decide
def e605603958558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e605603958558 : Closed e605603958558 ∧ code e605603958558 = 2804627214110 := by decide
theorem cert_e605603958558 : check e605603958558 [[],[]] .chain = true := by decide
def e605603958582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605603958582 : Closed e605603958582 ∧ code e605603958582 = 2804627214134 := by decide
theorem cert_e605603958582 : check e605603958582 [[],[]] .chain = true := by decide
def e605603958586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605603958586 : Closed e605603958586 ∧ code e605603958586 = 2804627214138 := by decide
theorem cert_e605603958586 : check e605603958586 [[],[]] .chain = true := by decide
def e605603965782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605603965782 : Closed e605603965782 ∧ code e605603965782 = 2804627221334 := by decide
theorem cert_e605603965782 : check e605603965782 [[],[]] .chain = true := by decide
def e605603965786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605603965786 : Closed e605603965786 ∧ code e605603965786 = 2804627221338 := by decide
theorem cert_e605603965786 : check e605603965786 [[],[]] .chain = true := by decide
def e605603965802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605603965802 : Closed e605603965802 ∧ code e605603965802 = 2804627221354 := by decide
theorem cert_e605603965802 : check e605603965802 [[],[]] .chain = true := by decide
def e605603965866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605603965866 : Closed e605603965866 ∧ code e605603965866 = 2804627221418 := by decide
theorem cert_e605603965866 : check e605603965866 [[],[]] .chain = true := by decide
def e605603965974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e605603965974 : Closed e605603965974 ∧ code e605603965974 = 2804627221526 := by decide
theorem cert_e605603965974 : check e605603965974 [[],[]] .chain = true := by decide
def e605603966070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e605603966070 : Closed e605603966070 ∧ code e605603966070 = 2804627221622 := by decide
theorem cert_e605603966070 : check e605603966070 [[],[]] .chain = true := by decide
def e605603966166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e605603966166 : Closed e605603966166 ∧ code e605603966166 = 2804627221718 := by decide
theorem cert_e605603966166 : check e605603966166 [[],[]] .chain = true := by decide
def e605603966170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e605603966170 : Closed e605603966170 ∧ code e605603966170 = 2804627221722 := by decide
theorem cert_e605603966170 : check e605603966170 [[],[]] .chain = true := by decide
def e605603966186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605603966186 : Closed e605603966186 ∧ code e605603966186 = 2804627221738 := by decide
theorem cert_e605603966186 : check e605603966186 [[],[]] .chain = true := by decide
def e605603966262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605603966262 : Closed e605603966262 ∧ code e605603966262 = 2804627221814 := by decide
theorem cert_e605603966262 : check e605603966262 [[],[]] .chain = true := by decide
def e605603966266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605603966266 : Closed e605603966266 ∧ code e605603966266 = 2804627221818 := by decide
theorem cert_e605603966266 : check e605603966266 [[],[]] .chain = true := by decide
def e605603966338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e605603966338 : Closed e605603966338 ∧ code e605603966338 = 2804627221890 := by decide
theorem cert_e605603966338 : check e605603966338 [[],[]] .chain = true := by decide
def e605603966350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e605603966350 : Closed e605603966350 ∧ code e605603966350 = 2804627221902 := by decide
theorem cert_e605603966350 : check e605603966350 [[],[]] .chain = true := by decide
def e605603966362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603966362 : Closed e605603966362 ∧ code e605603966362 = 2804627221914 := by decide
theorem cert_e605603966362 : check e605603966362 [[],[]] .chain = true := by decide
def e605603966474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e605603966474 : Closed e605603966474 ∧ code e605603966474 = 2804627222026 := by decide
theorem cert_e605603966474 : check e605603966474 [[],[]] .chain = true := by decide
def e605603966510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605603966510 : Closed e605603966510 ∧ code e605603966510 = 2804627222062 := by decide
theorem cert_e605603966510 : check e605603966510 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603966518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605603966518 : Closed e605603966518 ∧ code e605603966518 = 2804627222070 := by decide
theorem cert_e605603966518 : check e605603966518 [[],[]] .chain = true := by decide
def e605603966522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605603966522 : Closed e605603966522 ∧ code e605603966522 = 2804627222074 := by decide
theorem cert_e605603966522 : check e605603966522 [[],[]] .chain = true := by decide
def e605603966570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e605603966570 : Closed e605603966570 ∧ code e605603966570 = 2804627222122 := by decide
theorem cert_e605603966570 : check e605603966570 [[],[]] .chain = true := by decide
def e605603966594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e605603966594 : Closed e605603966594 ∧ code e605603966594 = 2804627222146 := by decide
theorem cert_e605603966594 : check e605603966594 [[],[]] .chain = true := by decide
def e605603966606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605603966606 : Closed e605603966606 ∧ code e605603966606 = 2804627222158 := by decide
theorem cert_e605603966606 : check e605603966606 [[],[]] .chain = true := by decide
def e605603966618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605603966618 : Closed e605603966618 ∧ code e605603966618 = 2804627222170 := by decide
theorem cert_e605603966618 : check e605603966618 [[],[]] .chain = true := by decide
def e605603966662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605603966662 : Closed e605603966662 ∧ code e605603966662 = 2804627222214 := by decide
theorem cert_e605603966662 : check e605603966662 [[],[]] .chain = true := by decide
def e605603966690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605603966690 : Closed e605603966690 ∧ code e605603966690 = 2804627222242 := by decide
theorem cert_e605603966690 : check e605603966690 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603966702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e605603966702 : Closed e605603966702 ∧ code e605603966702 = 2804627222254 := by decide
theorem cert_e605603966702 : check e605603966702 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603966742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e605603966742 : Closed e605603966742 ∧ code e605603966742 = 2804627222294 := by decide
theorem cert_e605603966742 : check e605603966742 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e605603966818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e605603966818 : Closed e605603966818 ∧ code e605603966818 = 2804627222370 := by decide
theorem cert_e605603966818 : check e605603966818 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e605603966830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e605603966830 : Closed e605603966830 ∧ code e605603966830 = 2804627222382 := by decide
theorem cert_e605603966830 : check e605603966830 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e605603966838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e605603966838 : Closed e605603966838 ∧ code e605603966838 = 2804627222390 := by decide
def e605603967214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e605603967214 : Closed e605603967214 ∧ code e605603967214 = 2804627222766 := by decide
theorem cert_e605603967214 : check e605603967214 [[],[]] .chain = true := by decide
def e605603967222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e605603967222 : Closed e605603967222 ∧ code e605603967222 = 2804627222774 := by decide
theorem cert_e605603967222 : check e605603967222 [[],[]] .chain = true := by decide
def e605603967702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605603967702 : Closed e605603967702 ∧ code e605603967702 = 2804627223254 := by decide
theorem cert_e605603967702 : check e605603967702 [[],[]] .chain = true := by decide
def e605603967706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605603967706 : Closed e605603967706 ∧ code e605603967706 = 2804627223258 := by decide
theorem cert_e605603967706 : check e605603967706 [[],[]] .chain = true := by decide
def e605603967722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605603967722 : Closed e605603967722 ∧ code e605603967722 = 2804627223274 := by decide
theorem cert_e605603967722 : check e605603967722 [[],[]] .chain = true := by decide
def e605603967798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605603967798 : Closed e605603967798 ∧ code e605603967798 = 2804627223350 := by decide
theorem cert_e605603967798 : check e605603967798 [[],[]] .chain = true := by decide
def e605603967802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605603967802 : Closed e605603967802 ∧ code e605603967802 = 2804627223354 := by decide
theorem cert_e605603967802 : check e605603967802 [[],[]] .chain = true := by decide
def e605603967874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e605603967874 : Closed e605603967874 ∧ code e605603967874 = 2804627223426 := by decide
theorem cert_e605603967874 : check e605603967874 [[],[]] .chain = true := by decide
def e605603967886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e605603967886 : Closed e605603967886 ∧ code e605603967886 = 2804627223438 := by decide
theorem cert_e605603967886 : check e605603967886 [[],[]] .chain = true := by decide
def e605603967898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605603967898 : Closed e605603967898 ∧ code e605603967898 = 2804627223450 := by decide
theorem cert_e605603967898 : check e605603967898 [[],[]] .chain = true := by decide
def e605603969050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e605603969050 : Closed e605603969050 ∧ code e605603969050 = 2804627224602 := by decide
theorem cert_e605603969050 : check e605603969050 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603969086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e605603969086 : Closed e605603969086 ∧ code e605603969086 = 2804627224638 := by decide
theorem cert_e605603969086 : check e605603969086 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603969134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e605603969134 : Closed e605603969134 ∧ code e605603969134 = 2804627224686 := by decide
theorem cert_e605603969134 : check e605603969134 [[],[]] .chain = true := by decide
def e605603969142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e605603969142 : Closed e605603969142 ∧ code e605603969142 = 2804627224694 := by decide
theorem cert_e605603969142 : check e605603969142 [[],[]] .chain = true := by decide
def e605603969146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e605603969146 : Closed e605603969146 ∧ code e605603969146 = 2804627224698 := by decide
theorem cert_e605603969146 : check e605603969146 [[],[]] .chain = true := by decide
def e605603969386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e605603969386 : Closed e605603969386 ∧ code e605603969386 = 2804627224938 := by decide
theorem cert_e605603969386 : check e605603969386 [[],[]] .chain = true := by decide
def e605603969410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e605603969410 : Closed e605603969410 ∧ code e605603969410 = 2804627224962 := by decide
theorem cert_e605603969410 : check e605603969410 [[],[]] .chain = true := by decide
def e605603969422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605603969422 : Closed e605603969422 ∧ code e605603969422 = 2804627224974 := by decide
theorem cert_e605603969422 : check e605603969422 [[],[]] .chain = true := by decide
def e605603969434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e605603969434 : Closed e605603969434 ∧ code e605603969434 = 2804627224986 := by decide
theorem cert_e605603969434 : check e605603969434 [[],[]] .chain = true := by decide
def e605603969478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605603969478 : Closed e605603969478 ∧ code e605603969478 = 2804627225030 := by decide
theorem cert_e605603969478 : check e605603969478 [[],[]] .chain = true := by decide
def e605603969506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605603969506 : Closed e605603969506 ∧ code e605603969506 = 2804627225058 := by decide
theorem cert_e605603969506 : check e605603969506 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603969518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e605603969518 : Closed e605603969518 ∧ code e605603969518 = 2804627225070 := by decide
theorem cert_e605603969518 : check e605603969518 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e605603970078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e605603970078 : Closed e605603970078 ∧ code e605603970078 = 2804627225630 := by decide
theorem cert_e605603970078 : check e605603970078 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e605603970274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e605603970274 : Closed e605603970274 ∧ code e605603970274 = 2804627225826 := by decide
theorem cert_e605603970274 : checkPay e605603970274 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605603970286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e605603970286 : Closed e605603970286 ∧ code e605603970286 = 2804627225838 := by decide
theorem cert_e605603970286 : checkPay e605603970286 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e605603970294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e605603970294 : Closed e605603970294 ∧ code e605603970294 = 2804627225846 := by decide
theorem cert_e605603970294 : check e605603970294 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e605605092830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e605605092830 : Closed e605605092830 ∧ code e605605092830 = 2804628348382 := by decide
theorem cert_e605605092830 : check e605605092830 [[],[]] .smaller = true := by decide
def e605605092846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e605605092846 : Closed e605605092846 ∧ code e605605092846 = 2804628348398 := by decide
theorem cert_e605605092846 : check e605605092846 [[],[]] .smaller = true := by decide
def e605605093086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e605605093086 : Closed e605605093086 ∧ code e605605093086 = 2804628348638 := by decide
theorem cert_e605605093086 : check e605605093086 [[],[]] .smaller = true := by decide
def e605605093110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e605605093110 : Closed e605605093110 ∧ code e605605093110 = 2804628348662 := by decide
theorem cert_e605605093110 : check e605605093110 [[],[]] .smaller = true := by decide
def e605605093230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e605605093230 : Closed e605605093230 ∧ code e605605093230 = 2804628348782 := by decide
theorem cert_e605605093230 : check e605605093230 [[],[]] .smaller = true := by decide
def e605605093238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e605605093238 : Closed e605605093238 ∧ code e605605093238 = 2804628348790 := by decide
theorem cert_e605605093238 : check e605605093238 [[],[]] .smaller = true := by decide
def e605605098462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e605605098462 : Closed e605605098462 ∧ code e605605098462 = 2804628354014 := by decide
theorem cert_e605605098462 : check e605605098462 [[],[]] .smaller = true := by decide
def e605605098478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e605605098478 : Closed e605605098478 ∧ code e605605098478 = 2804628354030 := by decide
theorem cert_e605605098478 : check e605605098478 [[],[]] .smaller = true := by decide
def e605605099998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e605605099998 : Closed e605605099998 ∧ code e605605099998 = 2804628355550 := by decide
theorem cert_e605605099998 : check e605605099998 [[],[]] .smaller = true := by decide
def e605605100022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e605605100022 : Closed e605605100022 ∧ code e605605100022 = 2804628355574 := by decide
theorem cert_e605605100022 : check e605605100022 [[],[]] .smaller = true := by decide
def e605605100782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e605605100782 : Closed e605605100782 ∧ code e605605100782 = 2804628356334 := by decide
theorem cert_e605605100782 : check e605605100782 [[],[]] .smaller = true := by decide
def e605605100790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e605605100790 : Closed e605605100790 ∧ code e605605100790 = 2804628356342 := by decide
theorem cert_e605605100790 : check e605605100790 [[],[]] .smaller = true := by decide
def e605605157598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e605605157598 : Closed e605605157598 ∧ code e605605157598 = 2804628413150 := by decide
theorem cert_e605605157598 : check e605605157598 [[],[]] .chain = true := by decide
def e605605157622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e605605157622 : Closed e605605157622 ∧ code e605605157622 = 2804628413174 := by decide
theorem cert_e605605157622 : check e605605157622 [[],[]] .chain = true := by decide
def e605605157726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e605605157726 : Closed e605605157726 ∧ code e605605157726 = 2804628413278 := by decide
theorem cert_e605605157726 : check e605605157726 [[],[]] .chain = true := by decide
def e605605157742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e605605157742 : Closed e605605157742 ∧ code e605605157742 = 2804628413294 := by decide
theorem cert_e605605157742 : check e605605157742 [[],[]] .smaller = true := by decide
def e605605157750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e605605157750 : Closed e605605157750 ∧ code e605605157750 = 2804628413302 := by decide
theorem cert_e605605157750 : check e605605157750 [[],[]] .smaller = true := by decide
def e605605157754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e605605157754 : Closed e605605157754 ∧ code e605605157754 = 2804628413306 := by decide
theorem cert_e605605157754 : check e605605157754 [[],[]] .chain = true := by decide
def e605605157814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e605605157814 : Closed e605605157814 ∧ code e605605157814 = 2804628413366 := by decide
theorem cert_e605605157814 : check e605605157814 [[],[]] .smaller = true := by decide
def e605605157846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e605605157846 : Closed e605605157846 ∧ code e605605157846 = 2804628413398 := by decide
theorem cert_e605605157846 : check e605605157846 [[],[]] .chain = true := by decide
def e605605157850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e605605157850 : Closed e605605157850 ∧ code e605605157850 = 2804628413402 := by decide
theorem cert_e605605157850 : check e605605157850 [[],[]] .chain = true := by decide
def e605605158238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e605605158238 : Closed e605605158238 ∧ code e605605158238 = 2804628413790 := by decide
theorem cert_e605605158238 : check e605605158238 [[],[]] .chain = true := by decide
def e605605158254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605605158254 : Closed e605605158254 ∧ code e605605158254 = 2804628413806 := by decide
theorem cert_e605605158254 : check e605605158254 [[],[]] .smaller = true := by decide
def e605605158262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605605158262 : Closed e605605158262 ∧ code e605605158262 = 2804628413814 := by decide
theorem cert_e605605158262 : check e605605158262 [[],[]] .smaller = true := by decide
def e605605158266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e605605158266 : Closed e605605158266 ∧ code e605605158266 = 2804628413818 := by decide
theorem cert_e605605158266 : check e605605158266 [[],[]] .chain = true := by decide
def e605605158318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605605158318 : Closed e605605158318 ∧ code e605605158318 = 2804628413870 := by decide
theorem cert_e605605158318 : check e605605158318 [[],[]] .smaller = true := by decide
def e605605158330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605605158330 : Closed e605605158330 ∧ code e605605158330 = 2804628413882 := by decide
theorem cert_e605605158330 : check e605605158330 [[],[]] .smaller = true := by decide
def e605605158358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605605158358 : Closed e605605158358 ∧ code e605605158358 = 2804628413910 := by decide
theorem cert_e605605158358 : check e605605158358 [[],[]] .smaller = true := by decide
def e605605158362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605605158362 : Closed e605605158362 ∧ code e605605158362 = 2804628413914 := by decide
theorem cert_e605605158362 : check e605605158362 [[],[]] .smaller = true := by decide
def e605605158378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e605605158378 : Closed e605605158378 ∧ code e605605158378 = 2804628413930 := by decide
theorem cert_e605605158378 : check e605605158378 [[],[]] .chain = true := by decide
def e605605158582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e605605158582 : Closed e605605158582 ∧ code e605605158582 = 2804628414134 := by decide
theorem cert_e605605158582 : check e605605158582 [[],[]] .smaller = true := by decide
def e605605158614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e605605158614 : Closed e605605158614 ∧ code e605605158614 = 2804628414166 := by decide
theorem cert_e605605158614 : check e605605158614 [[],[]] .smaller = true := by decide
def e605605158618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e605605158618 : Closed e605605158618 ∧ code e605605158618 = 2804628414170 := by decide
theorem cert_e605605158618 : check e605605158618 [[],[]] .smaller = true := by decide
def e605605158742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605605158742 : Closed e605605158742 ∧ code e605605158742 = 2804628414294 := by decide
theorem cert_e605605158742 : check e605605158742 [[],[]] .chain = true := by decide
def e605605158746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605605158746 : Closed e605605158746 ∧ code e605605158746 = 2804628414298 := by decide
theorem cert_e605605158746 : check e605605158746 [[],[]] .chain = true := by decide
def e605605158762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605605158762 : Closed e605605158762 ∧ code e605605158762 = 2804628414314 := by decide
theorem cert_e605605158762 : check e605605158762 [[],[]] .chain = true := by decide
def e605605159902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 3))))))))
theorem wire_e605605159902 : Closed e605605159902 ∧ code e605605159902 = 2804628415454 := by decide
theorem cert_e605605159902 : check e605605159902 [[],[]] .chain = true := by decide
def e605605159918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 2))))))))
theorem wire_e605605159918 : Closed e605605159918 ∧ code e605605159918 = 2804628415470 := by decide
theorem cert_e605605159918 : check e605605159918 [[],[]] .chain = true := by decide
def e605605160670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e605605160670 : Closed e605605160670 ∧ code e605605160670 = 2804628416222 := by decide
theorem cert_e605605160670 : check e605605160670 [[],[]] .chain = true := by decide
def e605605160694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e605605160694 : Closed e605605160694 ∧ code e605605160694 = 2804628416246 := by decide
theorem cert_e605605160694 : check e605605160694 [[],[]] .chain = true := by decide
def e605605160798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e605605160798 : Closed e605605160798 ∧ code e605605160798 = 2804628416350 := by decide
theorem cert_e605605160798 : check e605605160798 [[],[]] .chain = true := by decide
def e605605160814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e605605160814 : Closed e605605160814 ∧ code e605605160814 = 2804628416366 := by decide
theorem cert_e605605160814 : check e605605160814 [[],[]] .smaller = true := by decide
def e605605160822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e605605160822 : Closed e605605160822 ∧ code e605605160822 = 2804628416374 := by decide
theorem cert_e605605160822 : check e605605160822 [[],[]] .smaller = true := by decide
def e605605160826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e605605160826 : Closed e605605160826 ∧ code e605605160826 = 2804628416378 := by decide
theorem cert_e605605160826 : check e605605160826 [[],[]] .chain = true := by decide
def e605605160886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e605605160886 : Closed e605605160886 ∧ code e605605160886 = 2804628416438 := by decide
theorem cert_e605605160886 : check e605605160886 [[],[]] .smaller = true := by decide
end Blc.Floor41
