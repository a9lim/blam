import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e604332145878 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e604332145878 : Closed e604332145878 ∧ code e604332145878 = 2803355401430 := by decide
theorem cert_e604332145878 : check e604332145878 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e604332145882 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e604332145882 : Closed e604332145882 ∧ code e604332145882 = 2803355401434 := by decide
theorem cert_e604332145882 : check e604332145882 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e604332145898 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e604332145898 : Closed e604332145898 ∧ code e604332145898 = 2803355401450 := by decide
theorem cert_e604332145898 : check e604332145898 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e604332145974 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e604332145974 : Closed e604332145974 ∧ code e604332145974 = 2803355401526 := by decide
theorem cert_e604332145974 : check e604332145974 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e604332145978 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e604332145978 : Closed e604332145978 ∧ code e604332145978 = 2803355401530 := by decide
theorem cert_e604332145978 : check e604332145978 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e604332146074 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e604332146074 : Closed e604332146074 ∧ code e604332146074 = 2803355401626 := by decide
theorem cert_e604332146074 : check e604332146074 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e604332149614 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604332149614 : Closed e604332149614 ∧ code e604332149614 = 2803355405166 := by decide
theorem cert_e604332149614 : check e604332149614 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e604332149622 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604332149622 : Closed e604332149622 ∧ code e604332149622 = 2803355405174 := by decide
theorem cert_e604332149622 : check e604332149622 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e604332149678 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604332149678 : Closed e604332149678 ∧ code e604332149678 = 2803355405230 := by decide
theorem cert_e604332149678 : check e604332149678 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604332149690 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604332149690 : Closed e604332149690 ∧ code e604332149690 = 2803355405242 := by decide
theorem cert_e604332149690 : check e604332149690 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604332149718 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604332149718 : Closed e604332149718 ∧ code e604332149718 = 2803355405270 := by decide
theorem cert_e604332149718 : check e604332149718 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e604332149722 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604332149722 : Closed e604332149722 ∧ code e604332149722 = 2803355405274 := by decide
theorem cert_e604332149722 : check e604332149722 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604332149998 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604332149998 : Closed e604332149998 ∧ code e604332149998 = 2803355405550 := by decide
theorem cert_e604332149998 : check e604332149998 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e604332150006 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604332150006 : Closed e604332150006 ∧ code e604332150006 = 2803355405558 := by decide
theorem cert_e604332150006 : check e604332150006 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e604332150382 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604332150382 : Closed e604332150382 ∧ code e604332150382 = 2803355405934 := by decide
theorem cert_e604332150382 : check e604332150382 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604332150394 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604332150394 : Closed e604332150394 ∧ code e604332150394 = 2803355405946 := by decide
theorem cert_e604332150394 : check e604332150394 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e604332150582 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604332150582 : Closed e604332150582 ∧ code e604332150582 = 2803355406134 := by decide
theorem cert_e604332150582 : check e604332150582 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e604332150586 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604332150586 : Closed e604332150586 ∧ code e604332150586 = 2803355406138 := by decide
theorem cert_e604332150586 : check e604332150586 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e604332156334 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e604332156334 : Closed e604332156334 ∧ code e604332156334 = 2803355411886 := by decide
theorem cert_e604332156334 : check e604332156334 [[],[]] .sourceHead = true := by decide
def e604332156346 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e604332156346 : Closed e604332156346 ∧ code e604332156346 = 2803355411898 := by decide
theorem cert_e604332156346 : check e604332156346 [[],[]] .sourceHead = true := by decide
def e604332156394 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e604332156394 : Closed e604332156394 ∧ code e604332156394 = 2803355411946 := by decide
theorem cert_e604332156394 : check e604332156394 [[],[]] .sourceHead = true := by decide
def e604332156526 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e604332156526 : Closed e604332156526 ∧ code e604332156526 = 2803355412078 := by decide
theorem cert_e604332156526 : check e604332156526 [[],[]] .sourceHead = true := by decide
def e604332156538 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e604332156538 : Closed e604332156538 ∧ code e604332156538 = 2803355412090 := by decide
theorem cert_e604332156538 : check e604332156538 [[],[]] .sourceHead = true := by decide
def e604332156826 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e604332156826 : Closed e604332156826 ∧ code e604332156826 = 2803355412378 := by decide
theorem cert_e604332156826 : check e604332156826 [[],[]] .sourceHead = true := by decide
def e604332159702 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e604332159702 : Closed e604332159702 ∧ code e604332159702 = 2803355415254 := by decide
theorem cert_e604332159702 : check e604332159702 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e604332159706 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e604332159706 : Closed e604332159706 ∧ code e604332159706 = 2803355415258 := by decide
theorem cert_e604332159706 : check e604332159706 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e604332159722 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e604332159722 : Closed e604332159722 ∧ code e604332159722 = 2803355415274 := by decide
theorem cert_e604332159722 : check e604332159722 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e604332159798 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e604332159798 : Closed e604332159798 ∧ code e604332159798 = 2803355415350 := by decide
theorem cert_e604332159798 : check e604332159798 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e604332159802 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e604332159802 : Closed e604332159802 ∧ code e604332159802 = 2803355415354 := by decide
theorem cert_e604332159802 : check e604332159802 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e604332159898 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e604332159898 : Closed e604332159898 ∧ code e604332159898 = 2803355415450 := by decide
theorem cert_e604332159898 : check e604332159898 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e604332297070 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604332297070 : Closed e604332297070 ∧ code e604332297070 = 2803355552622 := by decide
theorem cert_e604332297070 : check e604332297070 [[],[]] .sourceHead = true := by decide
def e604332297078 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604332297078 : Closed e604332297078 ∧ code e604332297078 = 2803355552630 := by decide
theorem cert_e604332297078 : check e604332297078 [[],[]] .sourceHead = true := by decide
def e604332297134 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604332297134 : Closed e604332297134 ∧ code e604332297134 = 2803355552686 := by decide
theorem cert_e604332297134 : check e604332297134 [[],[]] .sourceHead = true := by decide
def e604332297146 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604332297146 : Closed e604332297146 ∧ code e604332297146 = 2803355552698 := by decide
theorem cert_e604332297146 : check e604332297146 [[],[]] .sourceHead = true := by decide
def e604332297174 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604332297174 : Closed e604332297174 ∧ code e604332297174 = 2803355552726 := by decide
theorem cert_e604332297174 : check e604332297174 [[],[]] .sourceHead = true := by decide
def e604332297178 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604332297178 : Closed e604332297178 ∧ code e604332297178 = 2803355552730 := by decide
theorem cert_e604332297178 : check e604332297178 [[],[]] .sourceHead = true := by decide
def e604332297454 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604332297454 : Closed e604332297454 ∧ code e604332297454 = 2803355553006 := by decide
theorem cert_e604332297454 : check e604332297454 [[],[]] .sourceHead = true := by decide
def e604332297462 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604332297462 : Closed e604332297462 ∧ code e604332297462 = 2803355553014 := by decide
theorem cert_e604332297462 : check e604332297462 [[],[]] .sourceHead = true := by decide
def e604332297838 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604332297838 : Closed e604332297838 ∧ code e604332297838 = 2803355553390 := by decide
theorem cert_e604332297838 : check e604332297838 [[],[]] .sourceHead = true := by decide
def e604332297850 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604332297850 : Closed e604332297850 ∧ code e604332297850 = 2803355553402 := by decide
theorem cert_e604332297850 : check e604332297850 [[],[]] .sourceHead = true := by decide
def e604332298038 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604332298038 : Closed e604332298038 ∧ code e604332298038 = 2803355553590 := by decide
theorem cert_e604332298038 : check e604332298038 [[],[]] .sourceHead = true := by decide
def e604332298042 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604332298042 : Closed e604332298042 ∧ code e604332298042 = 2803355553594 := by decide
theorem cert_e604332298042 : check e604332298042 [[],[]] .sourceHead = true := by decide
def e604332886894 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e604332886894 : Closed e604332886894 ∧ code e604332886894 = 2803356142446 := by decide
def e604332886902 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e604332886902 : Closed e604332886902 ∧ code e604332886902 = 2803356142454 := by decide
def e604332886958 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e604332886958 : Closed e604332886958 ∧ code e604332886958 = 2803356142510 := by decide
def e604332886970 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e604332886970 : Closed e604332886970 ∧ code e604332886970 = 2803356142522 := by decide
private def t_e604332886970 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e604332886970 : ¬ IsSelfInterpreter e604332886970 :=
  wSource (t := t_e604332886970) (replay_sound (ps := []) (t := e604332886970) (by decide)) (by decide)
def e604332886998 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e604332886998 : Closed e604332886998 ∧ code e604332886998 = 2803356142550 := by decide
def e604332887002 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e604332887002 : Closed e604332887002 ∧ code e604332887002 = 2803356142554 := by decide
private def t_e604332887002 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e604332887002 : ¬ IsSelfInterpreter e604332887002 :=
  wSource (t := t_e604332887002) (replay_sound (ps := []) (t := e604332887002) (by decide)) (by decide)
def e604332887278 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e604332887278 : Closed e604332887278 ∧ code e604332887278 = 2803356142830 := by decide
theorem cert_e604332887278 : check e604332887278 [[],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604332887286 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e604332887286 : Closed e604332887286 ∧ code e604332887286 = 2803356142838 := by decide
theorem cert_e604332887286 : check e604332887286 [[],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e604332887662 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e604332887662 : Closed e604332887662 ∧ code e604332887662 = 2803356143214 := by decide
def e604332887674 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e604332887674 : Closed e604332887674 ∧ code e604332887674 = 2803356143226 := by decide
theorem cert_e604332887674 : check e604332887674 [[],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e604332887862 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e604332887862 : Closed e604332887862 ∧ code e604332887862 = 2803356143414 := by decide
def e604332887866 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e604332887866 : Closed e604332887866 ∧ code e604332887866 = 2803356143418 := by decide
def e604517395994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604517395994 : Closed e604517395994 ∧ code e604517395994 = 2803540651546 := by decide
theorem cert_e604517395994 : check e604517395994 [[],[],[.left]] .chain = true := by decide
def e604517398042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604517398042 : Closed e604517398042 ∧ code e604517398042 = 2803540653594 := by decide
theorem cert_e604517398042 : check e604517398042 [[],[],[.left]] .chain = true := by decide
def e604517412378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604517412378 : Closed e604517412378 ∧ code e604517412378 = 2803540667930 := by decide
theorem cert_e604517412378 : check e604517412378 [[],[],[.left]] .chain = true := by decide
def e604517415450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604517415450 : Closed e604517415450 ∧ code e604517415450 = 2803540671002 := by decide
theorem cert_e604517415450 : check e604517415450 [[],[],[.left]] .chain = true := by decide
def e604517422618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604517422618 : Closed e604517422618 ∧ code e604517422618 = 2803540678170 := by decide
theorem cert_e604517422618 : check e604517422618 [[],[],[.left]] .chain = true := by decide
def e604517423642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604517423642 : Closed e604517423642 ∧ code e604517423642 = 2803540679194 := by decide
theorem cert_e604517423642 : check e604517423642 [[],[],[.left]] .chain = true := by decide
def e604517494298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604517494298 : Closed e604517494298 ∧ code e604517494298 = 2803540749850 := by decide
theorem cert_e604517494298 : check e604517494298 [[],[],[.left]] .chain = true := by decide
def e604517496346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604517496346 : Closed e604517496346 ∧ code e604517496346 = 2803540751898 := by decide
theorem cert_e604517496346 : check e604517496346 [[],[],[.left]] .chain = true := by decide
def e604517592602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604517592602 : Closed e604517592602 ∧ code e604517592602 = 2803540848154 := by decide
theorem cert_e604517592602 : check e604517592602 [[],[],[.left]] .chain = true := by decide
def e604517595674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604517595674 : Closed e604517595674 ∧ code e604517595674 = 2803540851226 := by decide
theorem cert_e604517595674 : check e604517595674 [[],[],[.left]] .chain = true := by decide
def e604517643802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604517643802 : Closed e604517643802 ∧ code e604517643802 = 2803540899354 := by decide
theorem cert_e604517643802 : check e604517643802 [[],[],[.left]] .chain = true := by decide
def e604517644826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604517644826 : Closed e604517644826 ∧ code e604517644826 = 2803540900378 := by decide
theorem cert_e604517644826 : check e604517644826 [[],[],[.left]] .chain = true := by decide
def e604519643162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e604519643162 : Closed e604519643162 ∧ code e604519643162 = 2803542898714 := by decide
theorem cert_e604519643162 : check e604519643162 [[],[]] .smaller = true := by decide
def e604519651354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e604519651354 : Closed e604519651354 ∧ code e604519651354 = 2803542906906 := by decide
theorem cert_e604519651354 : check e604519651354 [[],[]] .smaller = true := by decide
def e604519652890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604519652890 : Closed e604519652890 ∧ code e604519652890 = 2803542908442 := by decide
theorem cert_e604519652890 : check e604519652890 [[]] .width = true := by decide
def e604519656986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604519656986 : Closed e604519656986 ∧ code e604519656986 = 2803542912538 := by decide
theorem cert_e604519656986 : check e604519656986 [[]] .width = true := by decide
def e604519708698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e604519708698 : Closed e604519708698 ∧ code e604519708698 = 2803542964250 := by decide
theorem cert_e604519708698 : check e604519708698 [[],[]] .smaller = true := by decide
def e604519720986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e604519720986 : Closed e604519720986 ∧ code e604519720986 = 2803542976538 := by decide
theorem cert_e604519720986 : check e604519720986 [[],[]] .smaller = true := by decide
def e604519749658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e604519749658 : Closed e604519749658 ∧ code e604519749658 = 2803543005210 := by decide
theorem cert_e604519749658 : check e604519749658 [[],[]] .smaller = true := by decide
def e604519751194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604519751194 : Closed e604519751194 ∧ code e604519751194 = 2803543006746 := by decide
theorem cert_e604519751194 : check e604519751194 [[]] .width = true := by decide
def e604519753754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e604519753754 : Closed e604519753754 ∧ code e604519753754 = 2803543009306 := by decide
theorem cert_e604519753754 : check e604519753754 [[],[]] .smaller = true := by decide
def e604519758362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604519758362 : Closed e604519758362 ∧ code e604519758362 = 2803543013914 := by decide
private def t_e604519758362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604519758362 : ¬ IsSelfInterpreter e604519758362 :=
  wSource (t := t_e604519758362) (replay_sound (ps := []) (t := e604519758362) (by decide)) (by decide)
def e604519771674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604519771674 : Closed e604519771674 ∧ code e604519771674 = 2803543027226 := by decide
theorem cert_e604519771674 : check e604519771674 [[]] .width = true := by decide
def e604519774746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604519774746 : Closed e604519774746 ∧ code e604519774746 = 2803543030298 := by decide
private def t_e604519774746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604519774746 : ¬ IsSelfInterpreter e604519774746 :=
  wSource (t := t_e604519774746) (replay_sound (ps := []) (t := e604519774746) (by decide)) (by decide)
def e604520036378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e604520036378 : Closed e604520036378 ∧ code e604520036378 = 2803543291930 := by decide
theorem cert_e604520036378 : check e604520036378 [[],[]] .smaller = true := by decide
def e604520044570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e604520044570 : Closed e604520044570 ∧ code e604520044570 = 2803543300122 := by decide
theorem cert_e604520044570 : check e604520044570 [[],[]] .smaller = true := by decide
def e604520046106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604520046106 : Closed e604520046106 ∧ code e604520046106 = 2803543301658 := by decide
theorem cert_e604520046106 : check e604520046106 [[]] .width = true := by decide
def e604520050202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604520050202 : Closed e604520050202 ∧ code e604520050202 = 2803543305754 := by decide
theorem cert_e604520050202 : check e604520050202 [[]] .width = true := by decide
def e604520429594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e604520429594 : Closed e604520429594 ∧ code e604520429594 = 2803543685146 := by decide
theorem cert_e604520429594 : check e604520429594 [[],[]] .smaller = true := by decide
def e604520441882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e604520441882 : Closed e604520441882 ∧ code e604520441882 = 2803543697434 := by decide
theorem cert_e604520441882 : check e604520441882 [[],[]] .smaller = true := by decide
def e604520634394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e604520634394 : Closed e604520634394 ∧ code e604520634394 = 2803543889946 := by decide
theorem cert_e604520634394 : check e604520634394 [[],[]] .smaller = true := by decide
def e604520635930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604520635930 : Closed e604520635930 ∧ code e604520635930 = 2803543891482 := by decide
theorem cert_e604520635930 : check e604520635930 [[]] .width = true := by decide
def e604520638490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e604520638490 : Closed e604520638490 ∧ code e604520638490 = 2803543894042 := by decide
theorem cert_e604520638490 : check e604520638490 [[],[]] .smaller = true := by decide
def e604520643098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604520643098 : Closed e604520643098 ∧ code e604520643098 = 2803543898650 := by decide
theorem cert_e604520643098 : check e604520643098 [[]] .width = true := by decide
def e604520738330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604520738330 : Closed e604520738330 ∧ code e604520738330 = 2803543993882 := by decide
theorem cert_e604520738330 : check e604520738330 [[]] .width = true := by decide
def e604520741402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604520741402 : Closed e604520741402 ∧ code e604520741402 = 2803543996954 := by decide
theorem cert_e604520741402 : check e604520741402 [[]] .width = true := by decide
def e604528012826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528012826 : Closed e604528012826 ∧ code e604528012826 = 2803551268378 := by decide
theorem cert_e604528012826 : check e604528012826 [[]] .width = true := by decide
def e604528014874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528014874 : Closed e604528014874 ∧ code e604528014874 = 2803551270426 := by decide
theorem cert_e604528014874 : check e604528014874 [[]] .width = true := by decide
def e604528029210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528029210 : Closed e604528029210 ∧ code e604528029210 = 2803551284762 := by decide
theorem cert_e604528029210 : check e604528029210 [[]] .width = true := by decide
def e604528032282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528032282 : Closed e604528032282 ∧ code e604528032282 = 2803551287834 := by decide
theorem cert_e604528032282 : check e604528032282 [[]] .width = true := by decide
def e604528039450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528039450 : Closed e604528039450 ∧ code e604528039450 = 2803551295002 := by decide
theorem cert_e604528039450 : check e604528039450 [[]] .width = true := by decide
def e604528040474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528040474 : Closed e604528040474 ∧ code e604528040474 = 2803551296026 := by decide
theorem cert_e604528040474 : check e604528040474 [[]] .width = true := by decide
def e604528094746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528094746 : Closed e604528094746 ∧ code e604528094746 = 2803551350298 := by decide
theorem cert_e604528094746 : check e604528094746 [[]] .width = true := by decide
def e604528097818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528097818 : Closed e604528097818 ∧ code e604528097818 = 2803551353370 := by decide
theorem cert_e604528097818 : check e604528097818 [[]] .width = true := by decide
def e604528110106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528110106 : Closed e604528110106 ∧ code e604528110106 = 2803551365658 := by decide
private def t_e604528110106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604528110106 : ¬ IsSelfInterpreter e604528110106 :=
  wSource (t := t_e604528110106) (replay_sound (ps := []) (t := e604528110106) (by decide)) (by decide)
def e604528137754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528137754 : Closed e604528137754 ∧ code e604528137754 = 2803551393306 := by decide
theorem cert_e604528137754 : check e604528137754 [[]] .width = true := by decide
def e604528138778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528138778 : Closed e604528138778 ∧ code e604528138778 = 2803551394330 := by decide
theorem cert_e604528138778 : check e604528138778 [[]] .width = true := by decide
def e604528142874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528142874 : Closed e604528142874 ∧ code e604528142874 = 2803551398426 := by decide
private def t_e604528142874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604528142874 : ¬ IsSelfInterpreter e604528142874 :=
  wSource (t := t_e604528142874) (replay_sound (ps := []) (t := e604528142874) (by decide)) (by decide)
def e604528406042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528406042 : Closed e604528406042 ∧ code e604528406042 = 2803551661594 := by decide
theorem cert_e604528406042 : check e604528406042 [[]] .width = true := by decide
def e604528408090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528408090 : Closed e604528408090 ∧ code e604528408090 = 2803551663642 := by decide
theorem cert_e604528408090 : check e604528408090 [[]] .width = true := by decide
def e604528422426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528422426 : Closed e604528422426 ∧ code e604528422426 = 2803551677978 := by decide
theorem cert_e604528422426 : check e604528422426 [[]] .width = true := by decide
def e604528425498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528425498 : Closed e604528425498 ∧ code e604528425498 = 2803551681050 := by decide
theorem cert_e604528425498 : check e604528425498 [[]] .width = true := by decide
def e604528432666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528432666 : Closed e604528432666 ∧ code e604528432666 = 2803551688218 := by decide
theorem cert_e604528432666 : check e604528432666 [[]] .width = true := by decide
def e604528433690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528433690 : Closed e604528433690 ∧ code e604528433690 = 2803551689242 := by decide
theorem cert_e604528433690 : check e604528433690 [[]] .width = true := by decide
def e604528504346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528504346 : Closed e604528504346 ∧ code e604528504346 = 2803551759898 := by decide
theorem cert_e604528504346 : check e604528504346 [[]] .width = true := by decide
def e604528506394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528506394 : Closed e604528506394 ∧ code e604528506394 = 2803551761946 := by decide
theorem cert_e604528506394 : check e604528506394 [[]] .width = true := by decide
def e604528602650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528602650 : Closed e604528602650 ∧ code e604528602650 = 2803551858202 := by decide
theorem cert_e604528602650 : check e604528602650 [[]] .width = true := by decide
def e604528605722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528605722 : Closed e604528605722 ∧ code e604528605722 = 2803551861274 := by decide
theorem cert_e604528605722 : check e604528605722 [[]] .width = true := by decide
def e604528631834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604528631834 : Closed e604528631834 ∧ code e604528631834 = 2803551887386 := by decide
theorem cert_e604528631834 : check e604528631834 [[]] .width = true := by decide
def e604528631926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e604528631926 : Closed e604528631926 ∧ code e604528631926 = 2803551887478 := by decide
theorem cert_e604528631926 : check e604528631926 [[]] .width = true := by decide
def e604528632170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e604528632170 : Closed e604528632170 ∧ code e604528632170 = 2803551887722 := by decide
theorem cert_e604528632170 : check e604528632170 [[]] .width = true := by decide
def e604528632218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e604528632218 : Closed e604528632218 ∧ code e604528632218 = 2803551887770 := by decide
theorem cert_e604528632218 : check e604528632218 [[]] .width = true := by decide
def e604528653850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528653850 : Closed e604528653850 ∧ code e604528653850 = 2803551909402 := by decide
theorem cert_e604528653850 : check e604528653850 [[]] .width = true := by decide
def e604528654874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528654874 : Closed e604528654874 ∧ code e604528654874 = 2803551910426 := by decide
theorem cert_e604528654874 : check e604528654874 [[]] .width = true := by decide
def e604528664602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604528664602 : Closed e604528664602 ∧ code e604528664602 = 2803551920154 := by decide
theorem cert_e604528664602 : check e604528664602 [[]] .width = true := by decide
def e604528664694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e604528664694 : Closed e604528664694 ∧ code e604528664694 = 2803551920246 := by decide
theorem cert_e604528664694 : check e604528664694 [[]] .width = true := by decide
def e604528664938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e604528664938 : Closed e604528664938 ∧ code e604528664938 = 2803551920490 := by decide
theorem cert_e604528664938 : check e604528664938 [[]] .width = true := by decide
def e604528664986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e604528664986 : Closed e604528664986 ∧ code e604528664986 = 2803551920538 := by decide
theorem cert_e604528664986 : check e604528664986 [[]] .width = true := by decide
def e604528815642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528815642 : Closed e604528815642 ∧ code e604528815642 = 2803552071194 := by decide
theorem cert_e604528815642 : check e604528815642 [[]] .width = true := by decide
def e604528818714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528818714 : Closed e604528818714 ∧ code e604528818714 = 2803552074266 := by decide
theorem cert_e604528818714 : check e604528818714 [[]] .width = true := by decide
def e604528831002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528831002 : Closed e604528831002 ∧ code e604528831002 = 2803552086554 := by decide
theorem cert_e604528831002 : check e604528831002 [[]] .width = true := by decide
def e604528864794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528864794 : Closed e604528864794 ∧ code e604528864794 = 2803552120346 := by decide
theorem cert_e604528864794 : check e604528864794 [[]] .width = true := by decide
def e604528867866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528867866 : Closed e604528867866 ∧ code e604528867866 = 2803552123418 := by decide
theorem cert_e604528867866 : check e604528867866 [[]] .width = true := by decide
def e604528893978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604528893978 : Closed e604528893978 ∧ code e604528893978 = 2803552149530 := by decide
theorem cert_e604528893978 : check e604528893978 [[]] .width = true := by decide
def e604528894070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e604528894070 : Closed e604528894070 ∧ code e604528894070 = 2803552149622 := by decide
theorem cert_e604528894070 : check e604528894070 [[]] .width = true := by decide
def e604528894314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e604528894314 : Closed e604528894314 ∧ code e604528894314 = 2803552149866 := by decide
theorem cert_e604528894314 : check e604528894314 [[]] .width = true := by decide
def e604528894362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e604528894362 : Closed e604528894362 ∧ code e604528894362 = 2803552149914 := by decide
theorem cert_e604528894362 : check e604528894362 [[]] .width = true := by decide
def e604528941594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604528941594 : Closed e604528941594 ∧ code e604528941594 = 2803552197146 := by decide
private def t_e604528941594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604528941594 : ¬ IsSelfInterpreter e604528941594 :=
  wSource (t := t_e604528941594) (replay_sound (ps := []) (t := e604528941594) (by decide)) (by decide)
def e604528943130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604528943130 : Closed e604528943130 ∧ code e604528943130 = 2803552198682 := by decide
theorem cert_e604528943130 : check e604528943130 [[]] .width = true := by decide
def e604528943222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e604528943222 : Closed e604528943222 ∧ code e604528943222 = 2803552198774 := by decide
private def t_e604528943222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e604528943222 : ¬ IsSelfInterpreter e604528943222 :=
  wSource (t := t_e604528943222) (replay_sound (ps := []) (t := e604528943222) (by decide)) (by decide)
def e604528943466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e604528943466 : Closed e604528943466 ∧ code e604528943466 = 2803552199018 := by decide
private def t_e604528943466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e604528943466 : ¬ IsSelfInterpreter e604528943466 :=
  wSource (t := t_e604528943466) (replay_sound (ps := []) (t := e604528943466) (by decide)) (by decide)
def e604528943514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e604528943514 : Closed e604528943514 ∧ code e604528943514 = 2803552199066 := by decide
private def t_e604528943514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e604528943514 : ¬ IsSelfInterpreter e604528943514 :=
  wSource (t := t_e604528943514) (replay_sound (ps := []) (t := e604528943514) (by decide)) (by decide)
def e604529022490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604529022490 : Closed e604529022490 ∧ code e604529022490 = 2803552278042 := by decide
theorem cert_e604529022490 : check e604529022490 [[]] .width = true := by decide
def e604529023514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604529023514 : Closed e604529023514 ∧ code e604529023514 = 2803552279066 := by decide
theorem cert_e604529023514 : check e604529023514 [[]] .width = true := by decide
def e604529027610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604529027610 : Closed e604529027610 ∧ code e604529027610 = 2803552283162 := by decide
theorem cert_e604529027610 : check e604529027610 [[]] .width = true := by decide
def e604529047066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604529047066 : Closed e604529047066 ∧ code e604529047066 = 2803552302618 := by decide
theorem cert_e604529047066 : check e604529047066 [[]] .width = true := by decide
def e604529048090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604529048090 : Closed e604529048090 ∧ code e604529048090 = 2803552303642 := by decide
theorem cert_e604529048090 : check e604529048090 [[]] .width = true := by decide
def e604529057818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604529057818 : Closed e604529057818 ∧ code e604529057818 = 2803552313370 := by decide
theorem cert_e604529057818 : check e604529057818 [[]] .width = true := by decide
def e604529057910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e604529057910 : Closed e604529057910 ∧ code e604529057910 = 2803552313462 := by decide
theorem cert_e604529057910 : check e604529057910 [[]] .width = true := by decide
def e604529058154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e604529058154 : Closed e604529058154 ∧ code e604529058154 = 2803552313706 := by decide
theorem cert_e604529058154 : check e604529058154 [[]] .width = true := by decide
def e604529058202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e604529058202 : Closed e604529058202 ∧ code e604529058202 = 2803552313754 := by decide
theorem cert_e604529058202 : check e604529058202 [[]] .width = true := by decide
def e604529072666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604529072666 : Closed e604529072666 ∧ code e604529072666 = 2803552328218 := by decide
private def t_e604529072666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e604529072666 : ¬ IsSelfInterpreter e604529072666 :=
  wSource (t := t_e604529072666) (replay_sound (ps := []) (t := e604529072666) (by decide)) (by decide)
def e604529074202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604529074202 : Closed e604529074202 ∧ code e604529074202 = 2803552329754 := by decide
theorem cert_e604529074202 : check e604529074202 [[]] .width = true := by decide
def e604529074294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e604529074294 : Closed e604529074294 ∧ code e604529074294 = 2803552329846 := by decide
private def t_e604529074294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e604529074294 : ¬ IsSelfInterpreter e604529074294 :=
  wSource (t := t_e604529074294) (replay_sound (ps := []) (t := e604529074294) (by decide)) (by decide)
def e604529074538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e604529074538 : Closed e604529074538 ∧ code e604529074538 = 2803552330090 := by decide
private def t_e604529074538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e604529074538 : ¬ IsSelfInterpreter e604529074538 :=
  wSource (t := t_e604529074538) (replay_sound (ps := []) (t := e604529074538) (by decide)) (by decide)
def e604529074586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e604529074586 : Closed e604529074586 ∧ code e604529074586 = 2803552330138 := by decide
private def t_e604529074586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e604529074586 : ¬ IsSelfInterpreter e604529074586 :=
  wSource (t := t_e604529074586) (replay_sound (ps := []) (t := e604529074586) (by decide)) (by decide)
def e604529483290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604529483290 : Closed e604529483290 ∧ code e604529483290 = 2803552738842 := by decide
theorem cert_e604529483290 : check e604529483290 [[]] .width = true := by decide
def e604529487386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604529487386 : Closed e604529487386 ∧ code e604529487386 = 2803552742938 := by decide
theorem cert_e604529487386 : check e604529487386 [[]] .width = true := by decide
def e604529978906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604529978906 : Closed e604529978906 ∧ code e604529978906 = 2803553234458 := by decide
theorem cert_e604529978906 : check e604529978906 [[]] .width = true := by decide
def e604529980954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604529980954 : Closed e604529980954 ∧ code e604529980954 = 2803553236506 := by decide
theorem cert_e604529980954 : check e604529980954 [[]] .width = true := by decide
def e604529995290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604529995290 : Closed e604529995290 ∧ code e604529995290 = 2803553250842 := by decide
theorem cert_e604529995290 : check e604529995290 [[]] .width = true := by decide
def e604529998362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604529998362 : Closed e604529998362 ∧ code e604529998362 = 2803553253914 := by decide
theorem cert_e604529998362 : check e604529998362 [[]] .width = true := by decide
def e604530005530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604530005530 : Closed e604530005530 ∧ code e604530005530 = 2803553261082 := by decide
theorem cert_e604530005530 : check e604530005530 [[]] .width = true := by decide
def e604530006554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604530006554 : Closed e604530006554 ∧ code e604530006554 = 2803553262106 := by decide
theorem cert_e604530006554 : check e604530006554 [[]] .width = true := by decide
def e604530077210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604530077210 : Closed e604530077210 ∧ code e604530077210 = 2803553332762 := by decide
theorem cert_e604530077210 : check e604530077210 [[]] .width = true := by decide
def e604530079258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e604530079258 : Closed e604530079258 ∧ code e604530079258 = 2803553334810 := by decide
theorem cert_e604530079258 : check e604530079258 [[]] .width = true := by decide
end Blc.Floor41
