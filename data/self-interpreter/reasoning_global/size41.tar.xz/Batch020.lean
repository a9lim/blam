import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e562322148310 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e562322148310 : Closed e562322148310 ∧ code e562322148310 = 2761345403862 := by decide
theorem cert_e562322148310 : check e562322148310 [[],[.under,.left]] .chain = true := by decide
def e562322148314 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e562322148314 : Closed e562322148314 ∧ code e562322148314 = 2761345403866 := by decide
theorem cert_e562322148314 : check e562322148314 [[],[.under,.left]] .chain = true := by decide
def e562322148590 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e562322148590 : Closed e562322148590 ∧ code e562322148590 = 2761345404142 := by decide
theorem cert_e562322148590 : check e562322148590 [[],[.under,.left]] .chain = true := by decide
def e562322148598 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e562322148598 : Closed e562322148598 ∧ code e562322148598 = 2761345404150 := by decide
theorem cert_e562322148598 : check e562322148598 [[],[.under,.left]] .chain = true := by decide
def e562322148974 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e562322148974 : Closed e562322148974 ∧ code e562322148974 = 2761345404526 := by decide
theorem cert_e562322148974 : check e562322148974 [[],[.under,.left]] .chain = true := by decide
def e562322148986 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e562322148986 : Closed e562322148986 ∧ code e562322148986 = 2761345404538 := by decide
theorem cert_e562322148986 : check e562322148986 [[],[.under,.left]] .chain = true := by decide
def e562322149174 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e562322149174 : Closed e562322149174 ∧ code e562322149174 = 2761345404726 := by decide
theorem cert_e562322149174 : check e562322149174 [[],[.under,.left]] .chain = true := by decide
def e562322149178 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e562322149178 : Closed e562322149178 ∧ code e562322149178 = 2761345404730 := by decide
theorem cert_e562322149178 : check e562322149178 [[],[.under,.left]] .chain = true := by decide
def e562322738030 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e562322738030 : Closed e562322738030 ∧ code e562322738030 = 2761345993582 := by decide
theorem cert_e562322738030 : check e562322738030 [[],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e562322738038 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e562322738038 : Closed e562322738038 ∧ code e562322738038 = 2761345993590 := by decide
theorem cert_e562322738038 : check e562322738038 [[],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e562322738094 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e562322738094 : Closed e562322738094 ∧ code e562322738094 = 2761345993646 := by decide
theorem cert_e562322738094 : check e562322738094 [[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e562322738106 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e562322738106 : Closed e562322738106 ∧ code e562322738106 = 2761345993658 := by decide
private def t_e562322738106 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e562322738106 : ¬ IsSelfInterpreter e562322738106 :=
  wSource (t := t_e562322738106) (replay_sound (ps := []) (t := e562322738106) (by decide)) (by decide)
def e562322738134 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e562322738134 : Closed e562322738134 ∧ code e562322738134 = 2761345993686 := by decide
theorem cert_e562322738134 : check e562322738134 [[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e562322738138 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e562322738138 : Closed e562322738138 ∧ code e562322738138 = 2761345993690 := by decide
private def t_e562322738138 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e562322738138 : ¬ IsSelfInterpreter e562322738138 :=
  wSource (t := t_e562322738138) (replay_sound (ps := []) (t := e562322738138) (by decide)) (by decide)
def e562322738414 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e562322738414 : Closed e562322738414 ∧ code e562322738414 = 2761345993966 := by decide
theorem cert_e562322738414 : check e562322738414 [[],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e562322738422 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e562322738422 : Closed e562322738422 ∧ code e562322738422 = 2761345993974 := by decide
theorem cert_e562322738422 : check e562322738422 [[],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e562322738798 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e562322738798 : Closed e562322738798 ∧ code e562322738798 = 2761345994350 := by decide
theorem cert_e562322738798 : checkPay e562322738798 [[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e562322738810 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e562322738810 : Closed e562322738810 ∧ code e562322738810 = 2761345994362 := by decide
theorem cert_e562322738810 : check e562322738810 [[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e562322738998 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e562322738998 : Closed e562322738998 ∧ code e562322738998 = 2761345994550 := by decide
theorem cert_e562322738998 : check e562322738998 [[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e562322739002 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e562322739002 : Closed e562322739002 ∧ code e562322739002 = 2761345994554 := by decide
theorem cert_e562322739002 : check e562322739002 [[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e563586232518 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e563586232518 : Closed e563586232518 ∧ code e563586232518 = 2762609488070 := by decide
theorem cert_e563586232518 : check e563586232518 [[]] .width = true := by decide
def e563586248902 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e563586248902 : Closed e563586248902 ∧ code e563586248902 = 2762609504454 := by decide
theorem cert_e563586248902 : check e563586248902 [[]] .width = true := by decide
def e563586363590 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e563586363590 : Closed e563586363590 ∧ code e563586363590 = 2762609619142 := by decide
theorem cert_e563586363590 : check e563586363590 [[]] .width = true := by decide
def e563586388166 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e563586388166 : Closed e563586388166 ∧ code e563586388166 = 2762609643718 := by decide
theorem cert_e563586388166 : check e563586388166 [[]] .width = true := by decide
def e563586445510 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e563586445510 : Closed e563586445510 ∧ code e563586445510 = 2762609701062 := by decide
theorem cert_e563586445510 : check e563586445510 [[]] .width = true := by decide
def e563586453702 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e563586453702 : Closed e563586453702 ∧ code e563586453702 = 2762609709254 := by decide
theorem cert_e563586453702 : check e563586453702 [[]] .width = true := by decide
def e563587018950 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e563587018950 : Closed e563587018950 ∧ code e563587018950 = 2762610274502 := by decide
theorem cert_e563587018950 : check e563587018950 [[]] .width = true := by decide
def e563587035334 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e563587035334 : Closed e563587035334 ∧ code e563587035334 = 2762610290886 := by decide
theorem cert_e563587035334 : check e563587035334 [[]] .width = true := by decide
def e563587805382 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e563587805382 : Closed e563587805382 ∧ code e563587805382 = 2762611060934 := by decide
theorem cert_e563587805382 : check e563587805382 [[]] .width = true := by decide
def e563587829958 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e563587829958 : Closed e563587829958 ∧ code e563587829958 = 2762611085510 := by decide
theorem cert_e563587829958 : check e563587829958 [[]] .width = true := by decide
def e563588214982 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e563588214982 : Closed e563588214982 ∧ code e563588214982 = 2762611470534 := by decide
theorem cert_e563588214982 : check e563588214982 [[]] .width = true := by decide
def e563588223174 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e563588223174 : Closed e563588223174 ∧ code e563588223174 = 2762611478726 := by decide
theorem cert_e563588223174 : check e563588223174 [[]] .width = true := by decide
def e563630615918 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e563630615918 : Closed e563630615918 ∧ code e563630615918 = 2762653871470 := by decide
theorem cert_e563630615918 : check e563630615918 [[]] .sourceHead = true := by decide
def e563630615926 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e563630615926 : Closed e563630615926 ∧ code e563630615926 = 2762653871478 := by decide
theorem cert_e563630615926 : check e563630615926 [[]] .sourceHead = true := by decide
def e563630615982 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e563630615982 : Closed e563630615982 ∧ code e563630615982 = 2762653871534 := by decide
theorem cert_e563630615982 : check e563630615982 [[]] .sourceHead = true := by decide
def e563630615994 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e563630615994 : Closed e563630615994 ∧ code e563630615994 = 2762653871546 := by decide
theorem cert_e563630615994 : check e563630615994 [[]] .sourceHead = true := by decide
def e563630616022 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e563630616022 : Closed e563630616022 ∧ code e563630616022 = 2762653871574 := by decide
theorem cert_e563630616022 : check e563630616022 [[]] .sourceHead = true := by decide
def e563630616026 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e563630616026 : Closed e563630616026 ∧ code e563630616026 = 2762653871578 := by decide
theorem cert_e563630616026 : check e563630616026 [[]] .sourceHead = true := by decide
def e563630616238 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e563630616238 : Closed e563630616238 ∧ code e563630616238 = 2762653871790 := by decide
theorem cert_e563630616238 : check e563630616238 [[]] .sourceHead = true := by decide
def e563630616250 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e563630616250 : Closed e563630616250 ∧ code e563630616250 = 2762653871802 := by decide
theorem cert_e563630616250 : check e563630616250 [[]] .sourceHead = true := by decide
def e563630616298 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e563630616298 : Closed e563630616298 ∧ code e563630616298 = 2762653871850 := by decide
theorem cert_e563630616298 : check e563630616298 [[]] .sourceHead = true := by decide
def e563630616406 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e563630616406 : Closed e563630616406 ∧ code e563630616406 = 2762653871958 := by decide
theorem cert_e563630616406 : check e563630616406 [[]] .sourceHead = true := by decide
def e563630616410 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e563630616410 : Closed e563630616410 ∧ code e563630616410 = 2762653871962 := by decide
theorem cert_e563630616410 : check e563630616410 [[]] .sourceHead = true := by decide
def e563630616426 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e563630616426 : Closed e563630616426 ∧ code e563630616426 = 2762653871978 := by decide
theorem cert_e563630616426 : check e563630616426 [[]] .sourceHead = true := by decide
def e563630617454 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e563630617454 : Closed e563630617454 ∧ code e563630617454 = 2762653873006 := by decide
theorem cert_e563630617454 : check e563630617454 [[]] .sourceHead = true := by decide
def e563630617462 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e563630617462 : Closed e563630617462 ∧ code e563630617462 = 2762653873014 := by decide
theorem cert_e563630617462 : check e563630617462 [[]] .sourceHead = true := by decide
def e563630617518 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e563630617518 : Closed e563630617518 ∧ code e563630617518 = 2762653873070 := by decide
theorem cert_e563630617518 : check e563630617518 [[]] .sourceHead = true := by decide
def e563630617530 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e563630617530 : Closed e563630617530 ∧ code e563630617530 = 2762653873082 := by decide
theorem cert_e563630617530 : check e563630617530 [[]] .sourceHead = true := by decide
def e563630617558 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e563630617558 : Closed e563630617558 ∧ code e563630617558 = 2762653873110 := by decide
theorem cert_e563630617558 : check e563630617558 [[]] .sourceHead = true := by decide
def e563630617562 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e563630617562 : Closed e563630617562 ∧ code e563630617562 = 2762653873114 := by decide
theorem cert_e563630617562 : check e563630617562 [[]] .sourceHead = true := by decide
def e563630617838 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e563630617838 : Closed e563630617838 ∧ code e563630617838 = 2762653873390 := by decide
theorem cert_e563630617838 : check e563630617838 [[]] .sourceHead = true := by decide
def e563630617846 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e563630617846 : Closed e563630617846 ∧ code e563630617846 = 2762653873398 := by decide
theorem cert_e563630617846 : check e563630617846 [[]] .sourceHead = true := by decide
def e563630618222 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e563630618222 : Closed e563630618222 ∧ code e563630618222 = 2762653873774 := by decide
theorem cert_e563630618222 : check e563630618222 [[]] .sourceHead = true := by decide
def e563630618234 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e563630618234 : Closed e563630618234 ∧ code e563630618234 = 2762653873786 := by decide
theorem cert_e563630618234 : check e563630618234 [[]] .sourceHead = true := by decide
def e563630618422 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e563630618422 : Closed e563630618422 ∧ code e563630618422 = 2762653873974 := by decide
theorem cert_e563630618422 : check e563630618422 [[]] .sourceHead = true := by decide
def e563630618426 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e563630618426 : Closed e563630618426 ∧ code e563630618426 = 2762653873978 := by decide
theorem cert_e563630618426 : check e563630618426 [[]] .sourceHead = true := by decide
def e563630619054 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e563630619054 : Closed e563630619054 ∧ code e563630619054 = 2762653874606 := by decide
theorem cert_e563630619054 : check e563630619054 [[]] .sourceHead = true := by decide
def e563630619066 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e563630619066 : Closed e563630619066 ∧ code e563630619066 = 2762653874618 := by decide
theorem cert_e563630619066 : check e563630619066 [[]] .sourceHead = true := by decide
def e563630619114 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e563630619114 : Closed e563630619114 ∧ code e563630619114 = 2762653874666 := by decide
theorem cert_e563630619114 : check e563630619114 [[]] .sourceHead = true := by decide
def e563630619246 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e563630619246 : Closed e563630619246 ∧ code e563630619246 = 2762653874798 := by decide
theorem cert_e563630619246 : check e563630619246 [[]] .sourceHead = true := by decide
def e563630619258 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e563630619258 : Closed e563630619258 ∧ code e563630619258 = 2762653874810 := by decide
theorem cert_e563630619258 : check e563630619258 [[]] .sourceHead = true := by decide
def e563630619546 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e563630619546 : Closed e563630619546 ∧ code e563630619546 = 2762653875098 := by decide
theorem cert_e563630619546 : check e563630619546 [[]] .sourceHead = true := by decide
def e563630619862 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e563630619862 : Closed e563630619862 ∧ code e563630619862 = 2762653875414 := by decide
theorem cert_e563630619862 : check e563630619862 [[]] .sourceHead = true := by decide
def e563630619866 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e563630619866 : Closed e563630619866 ∧ code e563630619866 = 2762653875418 := by decide
theorem cert_e563630619866 : check e563630619866 [[]] .sourceHead = true := by decide
def e563630619882 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e563630619882 : Closed e563630619882 ∧ code e563630619882 = 2762653875434 := by decide
theorem cert_e563630619882 : check e563630619882 [[]] .sourceHead = true := by decide
def e563630619958 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e563630619958 : Closed e563630619958 ∧ code e563630619958 = 2762653875510 := by decide
theorem cert_e563630619958 : check e563630619958 [[]] .sourceHead = true := by decide
def e563630619962 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e563630619962 : Closed e563630619962 ∧ code e563630619962 = 2762653875514 := by decide
theorem cert_e563630619962 : check e563630619962 [[]] .sourceHead = true := by decide
def e563630620058 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e563630620058 : Closed e563630620058 ∧ code e563630620058 = 2762653875610 := by decide
theorem cert_e563630620058 : check e563630620058 [[]] .sourceHead = true := by decide
def e563630623598 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e563630623598 : Closed e563630623598 ∧ code e563630623598 = 2762653879150 := by decide
theorem cert_e563630623598 : check e563630623598 [[]] .sourceHead = true := by decide
def e563630623606 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e563630623606 : Closed e563630623606 ∧ code e563630623606 = 2762653879158 := by decide
theorem cert_e563630623606 : check e563630623606 [[]] .sourceHead = true := by decide
def e563630623662 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e563630623662 : Closed e563630623662 ∧ code e563630623662 = 2762653879214 := by decide
theorem cert_e563630623662 : check e563630623662 [[]] .sourceHead = true := by decide
def e563630623674 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e563630623674 : Closed e563630623674 ∧ code e563630623674 = 2762653879226 := by decide
theorem cert_e563630623674 : check e563630623674 [[]] .sourceHead = true := by decide
def e563630623702 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e563630623702 : Closed e563630623702 ∧ code e563630623702 = 2762653879254 := by decide
theorem cert_e563630623702 : check e563630623702 [[]] .sourceHead = true := by decide
def e563630623706 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e563630623706 : Closed e563630623706 ∧ code e563630623706 = 2762653879258 := by decide
theorem cert_e563630623706 : check e563630623706 [[]] .sourceHead = true := by decide
def e563630623982 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e563630623982 : Closed e563630623982 ∧ code e563630623982 = 2762653879534 := by decide
theorem cert_e563630623982 : check e563630623982 [[]] .sourceHead = true := by decide
def e563630623990 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e563630623990 : Closed e563630623990 ∧ code e563630623990 = 2762653879542 := by decide
theorem cert_e563630623990 : check e563630623990 [[]] .sourceHead = true := by decide
def e563630624366 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e563630624366 : Closed e563630624366 ∧ code e563630624366 = 2762653879918 := by decide
theorem cert_e563630624366 : check e563630624366 [[]] .sourceHead = true := by decide
def e563630624378 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e563630624378 : Closed e563630624378 ∧ code e563630624378 = 2762653879930 := by decide
theorem cert_e563630624378 : check e563630624378 [[]] .sourceHead = true := by decide
def e563630624566 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e563630624566 : Closed e563630624566 ∧ code e563630624566 = 2762653880118 := by decide
theorem cert_e563630624566 : check e563630624566 [[]] .sourceHead = true := by decide
def e563630624570 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e563630624570 : Closed e563630624570 ∧ code e563630624570 = 2762653880122 := by decide
theorem cert_e563630624570 : check e563630624570 [[]] .sourceHead = true := by decide
def e563630630318 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e563630630318 : Closed e563630630318 ∧ code e563630630318 = 2762653885870 := by decide
theorem cert_e563630630318 : check e563630630318 [[]] .sourceHead = true := by decide
def e563630630330 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e563630630330 : Closed e563630630330 ∧ code e563630630330 = 2762653885882 := by decide
theorem cert_e563630630330 : check e563630630330 [[]] .sourceHead = true := by decide
def e563630630378 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e563630630378 : Closed e563630630378 ∧ code e563630630378 = 2762653885930 := by decide
theorem cert_e563630630378 : check e563630630378 [[]] .sourceHead = true := by decide
def e563630630510 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e563630630510 : Closed e563630630510 ∧ code e563630630510 = 2762653886062 := by decide
theorem cert_e563630630510 : check e563630630510 [[]] .sourceHead = true := by decide
def e563630630522 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e563630630522 : Closed e563630630522 ∧ code e563630630522 = 2762653886074 := by decide
theorem cert_e563630630522 : check e563630630522 [[]] .sourceHead = true := by decide
def e563630630810 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e563630630810 : Closed e563630630810 ∧ code e563630630810 = 2762653886362 := by decide
theorem cert_e563630630810 : check e563630630810 [[]] .sourceHead = true := by decide
def e563630633686 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e563630633686 : Closed e563630633686 ∧ code e563630633686 = 2762653889238 := by decide
theorem cert_e563630633686 : check e563630633686 [[]] .sourceHead = true := by decide
def e563630633690 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e563630633690 : Closed e563630633690 ∧ code e563630633690 = 2762653889242 := by decide
theorem cert_e563630633690 : check e563630633690 [[]] .sourceHead = true := by decide
def e563630633706 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e563630633706 : Closed e563630633706 ∧ code e563630633706 = 2762653889258 := by decide
theorem cert_e563630633706 : check e563630633706 [[]] .sourceHead = true := by decide
def e563630633782 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e563630633782 : Closed e563630633782 ∧ code e563630633782 = 2762653889334 := by decide
theorem cert_e563630633782 : check e563630633782 [[]] .sourceHead = true := by decide
def e563630633786 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e563630633786 : Closed e563630633786 ∧ code e563630633786 = 2762653889338 := by decide
theorem cert_e563630633786 : check e563630633786 [[]] .sourceHead = true := by decide
def e563630633882 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e563630633882 : Closed e563630633882 ∧ code e563630633882 = 2762653889434 := by decide
theorem cert_e563630633882 : check e563630633882 [[]] .sourceHead = true := by decide
def e563630771054 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e563630771054 : Closed e563630771054 ∧ code e563630771054 = 2762654026606 := by decide
theorem cert_e563630771054 : check e563630771054 [[]] .sourceHead = true := by decide
def e563630771062 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e563630771062 : Closed e563630771062 ∧ code e563630771062 = 2762654026614 := by decide
theorem cert_e563630771062 : check e563630771062 [[]] .sourceHead = true := by decide
def e563630771118 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e563630771118 : Closed e563630771118 ∧ code e563630771118 = 2762654026670 := by decide
theorem cert_e563630771118 : check e563630771118 [[]] .sourceHead = true := by decide
def e563630771130 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e563630771130 : Closed e563630771130 ∧ code e563630771130 = 2762654026682 := by decide
theorem cert_e563630771130 : check e563630771130 [[]] .sourceHead = true := by decide
def e563630771158 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e563630771158 : Closed e563630771158 ∧ code e563630771158 = 2762654026710 := by decide
theorem cert_e563630771158 : check e563630771158 [[]] .sourceHead = true := by decide
def e563630771162 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e563630771162 : Closed e563630771162 ∧ code e563630771162 = 2762654026714 := by decide
theorem cert_e563630771162 : check e563630771162 [[]] .sourceHead = true := by decide
def e563630771438 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e563630771438 : Closed e563630771438 ∧ code e563630771438 = 2762654026990 := by decide
theorem cert_e563630771438 : check e563630771438 [[]] .sourceHead = true := by decide
def e563630771446 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e563630771446 : Closed e563630771446 ∧ code e563630771446 = 2762654026998 := by decide
theorem cert_e563630771446 : check e563630771446 [[]] .sourceHead = true := by decide
def e563630771822 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e563630771822 : Closed e563630771822 ∧ code e563630771822 = 2762654027374 := by decide
theorem cert_e563630771822 : check e563630771822 [[]] .sourceHead = true := by decide
def e563630771834 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e563630771834 : Closed e563630771834 ∧ code e563630771834 = 2762654027386 := by decide
theorem cert_e563630771834 : check e563630771834 [[]] .sourceHead = true := by decide
def e563630772022 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e563630772022 : Closed e563630772022 ∧ code e563630772022 = 2762654027574 := by decide
theorem cert_e563630772022 : check e563630772022 [[]] .sourceHead = true := by decide
def e563630772026 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e563630772026 : Closed e563630772026 ∧ code e563630772026 = 2762654027578 := by decide
theorem cert_e563630772026 : check e563630772026 [[]] .sourceHead = true := by decide
def e563631360878 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e563631360878 : Closed e563631360878 ∧ code e563631360878 = 2762654616430 := by decide
theorem cert_e563631360878 : check e563631360878 [[]] .sourceHead = true := by decide
def e563631360886 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e563631360886 : Closed e563631360886 ∧ code e563631360886 = 2762654616438 := by decide
theorem cert_e563631360886 : check e563631360886 [[]] .sourceHead = true := by decide
def e563631360942 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e563631360942 : Closed e563631360942 ∧ code e563631360942 = 2762654616494 := by decide
theorem cert_e563631360942 : check e563631360942 [[]] .sourceHead = true := by decide
def e563631360954 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e563631360954 : Closed e563631360954 ∧ code e563631360954 = 2762654616506 := by decide
theorem cert_e563631360954 : check e563631360954 [[]] .sourceHead = true := by decide
def e563631360982 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e563631360982 : Closed e563631360982 ∧ code e563631360982 = 2762654616534 := by decide
theorem cert_e563631360982 : check e563631360982 [[]] .sourceHead = true := by decide
def e563631360986 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e563631360986 : Closed e563631360986 ∧ code e563631360986 = 2762654616538 := by decide
theorem cert_e563631360986 : check e563631360986 [[]] .sourceHead = true := by decide
def e563631361262 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e563631361262 : Closed e563631361262 ∧ code e563631361262 = 2762654616814 := by decide
theorem cert_e563631361262 : check e563631361262 [[]] .sourceHead = true := by decide
def e563631361270 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e563631361270 : Closed e563631361270 ∧ code e563631361270 = 2762654616822 := by decide
theorem cert_e563631361270 : check e563631361270 [[]] .sourceHead = true := by decide
def e563631361646 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e563631361646 : Closed e563631361646 ∧ code e563631361646 = 2762654617198 := by decide
theorem cert_e563631361646 : check e563631361646 [[]] .sourceHead = true := by decide
def e563631361658 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e563631361658 : Closed e563631361658 ∧ code e563631361658 = 2762654617210 := by decide
theorem cert_e563631361658 : check e563631361658 [[]] .sourceHead = true := by decide
def e563631361846 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e563631361846 : Closed e563631361846 ∧ code e563631361846 = 2762654617398 := by decide
theorem cert_e563631361846 : check e563631361846 [[]] .sourceHead = true := by decide
def e563631361850 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e563631361850 : Closed e563631361850 ∧ code e563631361850 = 2762654617402 := by decide
theorem cert_e563631361850 : check e563631361850 [[]] .sourceHead = true := by decide
def e564812177434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564812177434 : Closed e564812177434 ∧ code e564812177434 = 2763835432986 := by decide
theorem cert_e564812177434 : check e564812177434 [[]] .width = true := by decide
def e564812177526 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564812177526 : Closed e564812177526 ∧ code e564812177526 = 2763835433078 := by decide
theorem cert_e564812177526 : check e564812177526 [[]] .width = true := by decide
def e564812177770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564812177770 : Closed e564812177770 ∧ code e564812177770 = 2763835433322 := by decide
theorem cert_e564812177770 : check e564812177770 [[]] .width = true := by decide
def e564812177818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564812177818 : Closed e564812177818 ∧ code e564812177818 = 2763835433370 := by decide
theorem cert_e564812177818 : check e564812177818 [[]] .width = true := by decide
def e564812275738 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564812275738 : Closed e564812275738 ∧ code e564812275738 = 2763835531290 := by decide
theorem cert_e564812275738 : check e564812275738 [[]] .width = true := by decide
def e564812275830 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564812275830 : Closed e564812275830 ∧ code e564812275830 = 2763835531382 := by decide
theorem cert_e564812275830 : check e564812275830 [[]] .width = true := by decide
def e564812276074 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564812276074 : Closed e564812276074 ∧ code e564812276074 = 2763835531626 := by decide
theorem cert_e564812276074 : check e564812276074 [[]] .width = true := by decide
def e564812276122 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564812276122 : Closed e564812276122 ∧ code e564812276122 = 2763835531674 := by decide
theorem cert_e564812276122 : check e564812276122 [[]] .width = true := by decide
def e564812701722 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564812701722 : Closed e564812701722 ∧ code e564812701722 = 2763835957274 := by decide
theorem cert_e564812701722 : check e564812701722 [[]] .width = true := by decide
def e564812701814 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564812701814 : Closed e564812701814 ∧ code e564812701814 = 2763835957366 := by decide
theorem cert_e564812701814 : check e564812701814 [[]] .width = true := by decide
def e564812702058 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564812702058 : Closed e564812702058 ∧ code e564812702058 = 2763835957610 := by decide
theorem cert_e564812702058 : check e564812702058 [[]] .width = true := by decide
def e564812702106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564812702106 : Closed e564812702106 ∧ code e564812702106 = 2763835957658 := by decide
theorem cert_e564812702106 : check e564812702106 [[]] .width = true := by decide
def e564812816410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564812816410 : Closed e564812816410 ∧ code e564812816410 = 2763836071962 := by decide
theorem cert_e564812816410 : check e564812816410 [[]] .width = true := by decide
def e564812816502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564812816502 : Closed e564812816502 ∧ code e564812816502 = 2763836072054 := by decide
private def t_e564812816502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e564812816502 : ¬ IsSelfInterpreter e564812816502 :=
  wSource (t := t_e564812816502) (replay_sound (ps := []) (t := e564812816502) (by decide)) (by decide)
def e564812816746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564812816746 : Closed e564812816746 ∧ code e564812816746 = 2763836072298 := by decide
private def t_e564812816746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e564812816746 : ¬ IsSelfInterpreter e564812816746 :=
  wSource (t := t_e564812816746) (replay_sound (ps := []) (t := e564812816746) (by decide)) (by decide)
def e564812816794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564812816794 : Closed e564812816794 ∧ code e564812816794 = 2763836072346 := by decide
private def t_e564812816794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e564812816794 : ¬ IsSelfInterpreter e564812816794 :=
  wSource (t := t_e564812816794) (replay_sound (ps := []) (t := e564812816794) (by decide)) (by decide)
def e564813193242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564813193242 : Closed e564813193242 ∧ code e564813193242 = 2763836448794 := by decide
theorem cert_e564813193242 : check e564813193242 [[]] .width = true := by decide
def e564813193334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564813193334 : Closed e564813193334 ∧ code e564813193334 = 2763836448886 := by decide
theorem cert_e564813193334 : check e564813193334 [[]] .width = true := by decide
def e564813193578 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564813193578 : Closed e564813193578 ∧ code e564813193578 = 2763836449130 := by decide
theorem cert_e564813193578 : check e564813193578 [[]] .width = true := by decide
def e564813193626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564813193626 : Closed e564813193626 ∧ code e564813193626 = 2763836449178 := by decide
theorem cert_e564813193626 : check e564813193626 [[]] .width = true := by decide
def e564813209626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564813209626 : Closed e564813209626 ∧ code e564813209626 = 2763836465178 := by decide
theorem cert_e564813209626 : check e564813209626 [[]] .width = true := by decide
def e564813209718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564813209718 : Closed e564813209718 ∧ code e564813209718 = 2763836465270 := by decide
private def t_e564813209718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e564813209718 : ¬ IsSelfInterpreter e564813209718 :=
  wSource (t := t_e564813209718) (replay_sound (ps := []) (t := e564813209718) (by decide)) (by decide)
def e564813209962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564813209962 : Closed e564813209962 ∧ code e564813209962 = 2763836465514 := by decide
private def t_e564813209962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e564813209962 : ¬ IsSelfInterpreter e564813209962 :=
  wSource (t := t_e564813209962) (replay_sound (ps := []) (t := e564813209962) (by decide)) (by decide)
def e564813210010 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564813210010 : Closed e564813210010 ∧ code e564813210010 = 2763836465562 := by decide
private def t_e564813210010 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e564813210010 : ¬ IsSelfInterpreter e564813210010 :=
  wSource (t := t_e564813210010) (replay_sound (ps := []) (t := e564813210010) (by decide)) (by decide)
def e564815323162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564815323162 : Closed e564815323162 ∧ code e564815323162 = 2763838578714 := by decide
theorem cert_e564815323162 : check e564815323162 [[]] .width = true := by decide
def e564815323254 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564815323254 : Closed e564815323254 ∧ code e564815323254 = 2763838578806 := by decide
theorem cert_e564815323254 : check e564815323254 [[]] .width = true := by decide
def e564815323498 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564815323498 : Closed e564815323498 ∧ code e564815323498 = 2763838579050 := by decide
theorem cert_e564815323498 : check e564815323498 [[]] .width = true := by decide
def e564815323546 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564815323546 : Closed e564815323546 ∧ code e564815323546 = 2763838579098 := by decide
theorem cert_e564815323546 : check e564815323546 [[]] .width = true := by decide
def e564815421466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564815421466 : Closed e564815421466 ∧ code e564815421466 = 2763838677018 := by decide
theorem cert_e564815421466 : check e564815421466 [[]] .width = true := by decide
def e564815421558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564815421558 : Closed e564815421558 ∧ code e564815421558 = 2763838677110 := by decide
theorem cert_e564815421558 : check e564815421558 [[]] .width = true := by decide
def e564815421802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564815421802 : Closed e564815421802 ∧ code e564815421802 = 2763838677354 := by decide
theorem cert_e564815421802 : check e564815421802 [[]] .width = true := by decide
def e564815421850 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564815421850 : Closed e564815421850 ∧ code e564815421850 = 2763838677402 := by decide
theorem cert_e564815421850 : check e564815421850 [[]] .width = true := by decide
def e564818468890 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564818468890 : Closed e564818468890 ∧ code e564818468890 = 2763841724442 := by decide
theorem cert_e564818468890 : check e564818468890 [[]] .width = true := by decide
def e564818468982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564818468982 : Closed e564818468982 ∧ code e564818468982 = 2763841724534 := by decide
theorem cert_e564818468982 : check e564818468982 [[]] .width = true := by decide
def e564818469226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564818469226 : Closed e564818469226 ∧ code e564818469226 = 2763841724778 := by decide
theorem cert_e564818469226 : check e564818469226 [[]] .width = true := by decide
def e564818469274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564818469274 : Closed e564818469274 ∧ code e564818469274 = 2763841724826 := by decide
theorem cert_e564818469274 : check e564818469274 [[]] .width = true := by decide
def e564818583578 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564818583578 : Closed e564818583578 ∧ code e564818583578 = 2763841839130 := by decide
theorem cert_e564818583578 : check e564818583578 [[]] .width = true := by decide
def e564818583670 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564818583670 : Closed e564818583670 ∧ code e564818583670 = 2763841839222 := by decide
theorem cert_e564818583670 : check e564818583670 [[]] .width = true := by decide
def e564818583914 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564818583914 : Closed e564818583914 ∧ code e564818583914 = 2763841839466 := by decide
theorem cert_e564818583914 : check e564818583914 [[]] .width = true := by decide
def e564818583962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564818583962 : Closed e564818583962 ∧ code e564818583962 = 2763841839514 := by decide
theorem cert_e564818583962 : check e564818583962 [[]] .width = true := by decide
def e564820926490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e564820926490 : Closed e564820926490 ∧ code e564820926490 = 2763844182042 := by decide
theorem cert_e564820926490 : check e564820926490 [[]] .width = true := by decide
def e564820926582 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e564820926582 : Closed e564820926582 ∧ code e564820926582 = 2763844182134 := by decide
theorem cert_e564820926582 : check e564820926582 [[]] .width = true := by decide
def e564820926826 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e564820926826 : Closed e564820926826 ∧ code e564820926826 = 2763844182378 := by decide
theorem cert_e564820926826 : check e564820926826 [[]] .width = true := by decide
def e564820926874 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e564820926874 : Closed e564820926874 ∧ code e564820926874 = 2763844182426 := by decide
theorem cert_e564820926874 : check e564820926874 [[]] .width = true := by decide
end Blc.Floor41
