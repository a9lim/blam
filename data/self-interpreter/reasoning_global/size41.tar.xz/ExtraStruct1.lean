import Extra41
import Batch030
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound WeakHeadClock Round3Floor38 SelfintSingleObject
set_option maxRecDepth 32000
set_option maxHeartbeats 5000000
namespace Witness565606140890
private def u0 := Term.var 1
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.lam u2
private def u4 := Term.var 0
private def u5 := Term.var 2
private def u6 := Term.app u5 u0
private def u7 := Term.app u6 u4
private def u8 := Term.app u4 u7
private def u9 := Term.lam u8
private def u10 := Term.lam u9
private def u11 := Term.app u4 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 1
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_dead (by decide) sou1
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private theorem sou4 : SO u4 := SO.var 0
private def u14 := Term.app u0 u4
private def u15 := Term.app u4 u14
private theorem sou5 : SO u5 := SO.var 2
private theorem sou6 : SO u6 := SO.app sou5 sou0
private theorem sou7 : SO u7 := SO.app sou6 sou4
private theorem sou8 : SO u8 := SO.app sou4 sou7
private theorem sou14 : SO u14 := SO.app sou0 sou4
private theorem sou9 : SO u9 := SO.lam (r := u14) (g := u15) sou8 sou14 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.lam (r := u4) (g := u9) sou9 sou4 (by decide) (by decide)
private theorem sou11 : SO u11 := SO.app sou4 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege565606140890 : ¬ IsSelfInterpreter e565606140890 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege565606140890
end Witness565606140890
namespace Witness565606878062
private def u0 := Term.var 0
private def u1 := Term.var 1
private def u2 := Term.app u0 u1
private def u3 := Term.var 2
private def u4 := Term.app u2 u3
private def u5 := Term.lam u4
private def u6 := Term.lam u5
private def u7 := Term.app u0 u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.lam u10
private def u12 := Term.app u0 u0
private def u13 := Term.lam u12
private def u14 := Term.app u11 u13
theorem nege565606878062 : ¬ IsSelfInterpreter e565606878062 := by
  intro he
  have h : replay [[.left]] (.app e565606878062 diag) = some u14 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u14) (by decide) (by decide) hj
#print axioms nege565606878062
end Witness565606878062
namespace Witness565606878126
private def u0 := Term.var 0
private def u1 := Term.var 1
private def u2 := Term.app u1 u0
private def u3 := Term.var 2
private def u4 := Term.app u2 u3
private def u5 := Term.lam u4
private def u6 := Term.lam u5
private def u7 := Term.app u0 u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.lam u10
private def u12 := Term.app u0 u0
private def u13 := Term.lam u12
private def u14 := Term.app u11 u13
theorem nege565606878126 : ¬ IsSelfInterpreter e565606878126 := by
  intro he
  have h : replay [[.left]] (.app e565606878126 diag) = some u14 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u14) (by decide) (by decide) hj
#print axioms nege565606878126
end Witness565606878126
namespace Witness565606878446
private def u0 := Term.var 1
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.lam u2
private def u4 := Term.var 0
private def u5 := Term.var 2
private def u6 := Term.app u0 u5
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u4 u9
private def u11 := Term.app u4 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 1
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_dead (by decide) sou1
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private theorem sou4 : SO u4 := SO.var 0
private def u14 := Term.app u4 u0
private theorem sou5 : SO u5 := SO.var 2
private theorem sou6 : SO u6 := SO.app sou0 sou5
private theorem sou7 : SO u7 := SO.app sou4 sou6
private theorem sou14 : SO u14 := SO.app sou4 sou0
private theorem sou8 : SO u8 := SO.lam (r := u14) (g := u14) sou7 sou14 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.lam (r := u4) (g := u8) sou8 sou4 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.app sou4 sou9
private theorem sou11 : SO u11 := SO.app sou4 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege565606878446 : ¬ IsSelfInterpreter e565606878446 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege565606878446
end Witness565606878446
namespace Witness565606878454
private def u0 := Term.var 1
private def u1 := Term.app u0 u0
private def u2 := Term.lam u1
private def u3 := Term.lam u2
private def u4 := Term.var 0
private def u5 := Term.var 2
private def u6 := Term.app u5 u0
private def u7 := Term.app u4 u6
private def u8 := Term.lam u7
private def u9 := Term.lam u8
private def u10 := Term.app u4 u9
private def u11 := Term.app u4 u10
private def u12 := Term.lam u11
private def u13 := Term.app u3 u12
private theorem sou0 : SO u0 := SO.var 1
private theorem sou1 : SO u1 := SO.app sou0 sou0
private theorem sou2 : SO u2 := so_dead (by decide) sou1
private theorem sou3 : SO u3 := so_closed_lam (by decide) sou2
private theorem sou4 : SO u4 := SO.var 0
private def u14 := Term.app u0 u4
private def u15 := Term.app u4 u0
private theorem sou5 : SO u5 := SO.var 2
private theorem sou6 : SO u6 := SO.app sou5 sou0
private theorem sou7 : SO u7 := SO.app sou4 sou6
private theorem sou14 : SO u14 := SO.app sou0 sou4
private theorem sou8 : SO u8 := SO.lam (r := u14) (g := u15) sou7 sou14 (by decide) (by decide)
private theorem sou9 : SO u9 := SO.lam (r := u4) (g := u8) sou8 sou4 (by decide) (by decide)
private theorem sou10 : SO u10 := SO.app sou4 sou9
private theorem sou11 : SO u11 := SO.app sou4 sou10
private theorem sou12 : SO u12 := so_closed_lam (by decide) sou11
private theorem sou13 : SO u13 := SO.app sou3 sou12
theorem nege565606878454 : ¬ IsSelfInterpreter e565606878454 := by
  exact rawSO [] (t := u13) (by decide) sou13
#print axioms nege565606878454
end Witness565606878454
namespace Witness565606879030
private def u0 := Term.var 0
private def u1 := Term.var 2
private def u2 := Term.var 1
private def u3 := Term.app u0 u2
private def u4 := Term.app u1 u3
private def u5 := Term.lam u4
private def u6 := Term.lam u5
private def u7 := Term.app u0 u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.lam u10
private def u12 := Term.app u0 u0
private def u13 := Term.lam u12
private def u14 := Term.app u11 u13
theorem nege565606879030 : ¬ IsSelfInterpreter e565606879030 := by
  intro he
  have h : replay [[.left]] (.app e565606879030 diag) = some u14 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u14) (by decide) (by decide) hj
#print axioms nege565606879030
end Witness565606879030
namespace Witness565606879034
private def u0 := Term.var 0
private def u1 := Term.var 2
private def u2 := Term.var 1
private def u3 := Term.app u2 u0
private def u4 := Term.app u1 u3
private def u5 := Term.lam u4
private def u6 := Term.lam u5
private def u7 := Term.app u0 u6
private def u8 := Term.app u0 u7
private def u9 := Term.lam u8
private def u10 := Term.app u9 u9
private def u11 := Term.lam u10
private def u12 := Term.app u0 u0
private def u13 := Term.lam u12
private def u14 := Term.app u11 u13
theorem nege565606879034 : ¬ IsSelfInterpreter e565606879034 := by
  intro he
  have h : replay [[.left]] (.app e565606879034 diag) = some u14 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (deltaCount he) h
  exact Floor40.Weighted.no_clock 1 (by decide : Closed u14) (by decide) (by decide) hj
#print axioms nege565606879034
end Witness565606879034
namespace Witness596279078362
private def u0 := Term.var 0
private def u1 := Term.app u0 u0
private def u2 := Term.app u1 u0
private def u3 := Term.app u2 u0
private def u4 := Term.lam u3
private def u5 := Term.var 2
private def u6 := Term.app u0 u5
private def u7 := Term.var 1
private def u8 := Term.app u6 u7
private def u9 := Term.app u8 u0
private def u10 := Term.lam u9
private def u11 := Term.lam u10
private def u12 := Term.lam u11
private def u13 := Term.app u4 u12
theorem nege596279078362 : ¬ IsSelfInterpreter e596279078362 := by
  intro he
  have h : replay [] e596279078362 = some u13 := by decide
  obtain ⟨j,hj⟩ := Floor40.clocks_replay (Floor40.rawCount he) h
  exact Floor40.Weighted.no_clock 3 (by decide : Closed u13) (by decide) (by decide) hj
#print axioms nege596279078362
end Witness596279078362
end Blc.Floor41
