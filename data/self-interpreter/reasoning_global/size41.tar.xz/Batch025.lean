import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e565593685358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e565593685358 : Closed e565593685358 ∧ code e565593685358 = 2764616940910 := by decide
theorem cert_e565593685358 : check e565593685358 [[],[.under]] .smaller = true := by decide
def e565593685366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e565593685366 : Closed e565593685366 ∧ code e565593685366 = 2764616940918 := by decide
theorem cert_e565593685366 : check e565593685366 [[],[.under]] .smaller = true := by decide
def e565593685370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e565593685370 : Closed e565593685370 ∧ code e565593685370 = 2764616940922 := by decide
theorem cert_e565593685370 : check e565593685370 [[],[.under]] .three = true := by decide
def e565593685422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e565593685422 : Closed e565593685422 ∧ code e565593685422 = 2764616940974 := by decide
theorem cert_e565593685422 : check e565593685422 [[],[.under]] .smaller = true := by decide
def e565593685434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e565593685434 : Closed e565593685434 ∧ code e565593685434 = 2764616940986 := by decide
theorem cert_e565593685434 : check e565593685434 [[],[.under]] .smaller = true := by decide
def e565593685462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e565593685462 : Closed e565593685462 ∧ code e565593685462 = 2764616941014 := by decide
theorem cert_e565593685462 : check e565593685462 [[],[.under]] .smaller = true := by decide
def e565593685466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e565593685466 : Closed e565593685466 ∧ code e565593685466 = 2764616941018 := by decide
theorem cert_e565593685466 : check e565593685466 [[],[.under]] .smaller = true := by decide
def e565593685482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e565593685482 : Closed e565593685482 ∧ code e565593685482 = 2764616941034 := by decide
theorem cert_e565593685482 : check e565593685482 [[],[.under]] .three = true := by decide
def e565593685678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e565593685678 : Closed e565593685678 ∧ code e565593685678 = 2764616941230 := by decide
theorem cert_e565593685678 : check e565593685678 [[],[.under]] .three = true := by decide
def e565593685686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e565593685686 : Closed e565593685686 ∧ code e565593685686 = 2764616941238 := by decide
theorem cert_e565593685686 : check e565593685686 [[],[.under]] .three = true := by decide
def e565593685690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e565593685690 : Closed e565593685690 ∧ code e565593685690 = 2764616941242 := by decide
theorem cert_e565593685690 : check e565593685690 [[],[.under]] .three = true := by decide
def e565593685718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e565593685718 : Closed e565593685718 ∧ code e565593685718 = 2764616941270 := by decide
theorem cert_e565593685718 : check e565593685718 [[],[.under]] .three = true := by decide
def e565593685722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e565593685722 : Closed e565593685722 ∧ code e565593685722 = 2764616941274 := by decide
theorem cert_e565593685722 : check e565593685722 [[],[.under]] .three = true := by decide
def e565593685738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e565593685738 : Closed e565593685738 ∧ code e565593685738 = 2764616941290 := by decide
theorem cert_e565593685738 : check e565593685738 [[],[.under]] .three = true := by decide
def e565593689566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e565593689566 : Closed e565593689566 ∧ code e565593689566 = 2764616945118 := by decide
theorem cert_e565593689566 : check e565593689566 [[],[.under]] .three = true := by decide
def e565593689582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e565593689582 : Closed e565593689582 ∧ code e565593689582 = 2764616945134 := by decide
theorem cert_e565593689582 : check e565593689582 [[],[.under]] .three = true := by decide
def e565593689822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e565593689822 : Closed e565593689822 ∧ code e565593689822 = 2764616945374 := by decide
theorem cert_e565593689822 : check e565593689822 [[],[.under]] .three = true := by decide
def e565593689838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e565593689838 : Closed e565593689838 ∧ code e565593689838 = 2764616945390 := by decide
theorem cert_e565593689838 : check e565593689838 [[],[.under]] .smaller = true := by decide
def e565593689846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e565593689846 : Closed e565593689846 ∧ code e565593689846 = 2764616945398 := by decide
theorem cert_e565593689846 : check e565593689846 [[],[.under]] .three = true := by decide
def e565593689950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e565593689950 : Closed e565593689950 ∧ code e565593689950 = 2764616945502 := by decide
theorem cert_e565593689950 : check e565593689950 [[],[.under]] .three = true := by decide
def e565593689966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e565593689966 : Closed e565593689966 ∧ code e565593689966 = 2764616945518 := by decide
theorem cert_e565593689966 : check e565593689966 [[],[.under]] .smaller = true := by decide
def e565593689974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e565593689974 : Closed e565593689974 ∧ code e565593689974 = 2764616945526 := by decide
theorem cert_e565593689974 : check e565593689974 [[],[.under]] .smaller = true := by decide
def e565593689978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e565593689978 : Closed e565593689978 ∧ code e565593689978 = 2764616945530 := by decide
theorem cert_e565593689978 : check e565593689978 [[],[.under]] .three = true := by decide
def e565593690030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e565593690030 : Closed e565593690030 ∧ code e565593690030 = 2764616945582 := by decide
theorem cert_e565593690030 : check e565593690030 [[],[.under]] .three = true := by decide
def e565593690038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e565593690038 : Closed e565593690038 ∧ code e565593690038 = 2764616945590 := by decide
theorem cert_e565593690038 : check e565593690038 [[],[.under]] .three = true := by decide
def e565593690042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e565593690042 : Closed e565593690042 ∧ code e565593690042 = 2764616945594 := by decide
theorem cert_e565593690042 : check e565593690042 [[],[.under]] .three = true := by decide
def e565593691102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e565593691102 : Closed e565593691102 ∧ code e565593691102 = 2764616946654 := by decide
theorem cert_e565593691102 : check e565593691102 [[],[.under]] .three = true := by decide
def e565593691118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e565593691118 : Closed e565593691118 ∧ code e565593691118 = 2764616946670 := by decide
theorem cert_e565593691118 : check e565593691118 [[],[.under]] .three = true := by decide
def e565593692638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e565593692638 : Closed e565593692638 ∧ code e565593692638 = 2764616948190 := by decide
theorem cert_e565593692638 : check e565593692638 [[],[.under]] .three = true := by decide
def e565593692654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e565593692654 : Closed e565593692654 ∧ code e565593692654 = 2764616948206 := by decide
theorem cert_e565593692654 : check e565593692654 [[],[.under]] .smaller = true := by decide
def e565593692662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e565593692662 : Closed e565593692662 ∧ code e565593692662 = 2764616948214 := by decide
theorem cert_e565593692662 : check e565593692662 [[],[.under]] .three = true := by decide
def e565593693406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e565593693406 : Closed e565593693406 ∧ code e565593693406 = 2764616948958 := by decide
theorem cert_e565593693406 : check e565593693406 [[],[.under]] .three = true := by decide
def e565593693422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e565593693422 : Closed e565593693422 ∧ code e565593693422 = 2764616948974 := by decide
theorem cert_e565593693422 : check e565593693422 [[],[.under]] .smaller = true := by decide
def e565593693430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e565593693430 : Closed e565593693430 ∧ code e565593693430 = 2764616948982 := by decide
theorem cert_e565593693430 : check e565593693430 [[],[.under]] .smaller = true := by decide
def e565593693434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e565593693434 : Closed e565593693434 ∧ code e565593693434 = 2764616948986 := by decide
theorem cert_e565593693434 : check e565593693434 [[],[.under]] .three = true := by decide
def e565593693806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e565593693806 : Closed e565593693806 ∧ code e565593693806 = 2764616949358 := by decide
theorem cert_e565593693806 : check e565593693806 [[],[.under]] .three = true := by decide
def e565593693814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e565593693814 : Closed e565593693814 ∧ code e565593693814 = 2764616949366 := by decide
theorem cert_e565593693814 : check e565593693814 [[],[.under]] .three = true := by decide
def e565593693818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e565593693818 : Closed e565593693818 ∧ code e565593693818 = 2764616949370 := by decide
theorem cert_e565593693818 : check e565593693818 [[],[.under]] .three = true := by decide
def e565593695966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e565593695966 : Closed e565593695966 ∧ code e565593695966 = 2764616951518 := by decide
theorem cert_e565593695966 : check e565593695966 [[],[.under]] .three = true := by decide
def e565593695982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e565593695982 : Closed e565593695982 ∧ code e565593695982 = 2764616951534 := by decide
theorem cert_e565593695982 : check e565593695982 [[],[.under]] .smaller = true := by decide
def e565593695990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e565593695990 : Closed e565593695990 ∧ code e565593695990 = 2764616951542 := by decide
theorem cert_e565593695990 : check e565593695990 [[],[.under]] .three = true := by decide
def e565593696094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e565593696094 : Closed e565593696094 ∧ code e565593696094 = 2764616951646 := by decide
theorem cert_e565593696094 : check e565593696094 [[],[.under]] .three = true := by decide
def e565593696122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e565593696122 : Closed e565593696122 ∧ code e565593696122 = 2764616951674 := by decide
theorem cert_e565593696122 : check e565593696122 [[],[.under]] .three = true := by decide
def e565593696174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e565593696174 : Closed e565593696174 ∧ code e565593696174 = 2764616951726 := by decide
theorem cert_e565593696174 : check e565593696174 [[],[.under]] .smaller = true := by decide
def e565593696186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e565593696186 : Closed e565593696186 ∧ code e565593696186 = 2764616951738 := by decide
theorem cert_e565593696186 : check e565593696186 [[],[.under]] .smaller = true := by decide
def e565593696214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e565593696214 : Closed e565593696214 ∧ code e565593696214 = 2764616951766 := by decide
theorem cert_e565593696214 : check e565593696214 [[],[.under]] .three = true := by decide
def e565593696218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e565593696218 : Closed e565593696218 ∧ code e565593696218 = 2764616951770 := by decide
theorem cert_e565593696218 : check e565593696218 [[],[.under]] .three = true := by decide
def e565593696734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e565593696734 : Closed e565593696734 ∧ code e565593696734 = 2764616952286 := by decide
theorem cert_e565593696734 : check e565593696734 [[],[.under]] .three = true := by decide
def e565593696750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e565593696750 : Closed e565593696750 ∧ code e565593696750 = 2764616952302 := by decide
theorem cert_e565593696750 : check e565593696750 [[],[.under]] .smaller = true := by decide
def e565593696758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e565593696758 : Closed e565593696758 ∧ code e565593696758 = 2764616952310 := by decide
theorem cert_e565593696758 : check e565593696758 [[],[.under]] .three = true := by decide
def e565593697502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e565593697502 : Closed e565593697502 ∧ code e565593697502 = 2764616953054 := by decide
theorem cert_e565593697502 : check e565593697502 [[],[.under]] .three = true := by decide
def e565593697530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e565593697530 : Closed e565593697530 ∧ code e565593697530 = 2764616953082 := by decide
theorem cert_e565593697530 : check e565593697530 [[],[.under]] .three = true := by decide
def e565593697902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e565593697902 : Closed e565593697902 ∧ code e565593697902 = 2764616953454 := by decide
theorem cert_e565593697902 : check e565593697902 [[],[.under]] .smaller = true := by decide
def e565593697914 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e565593697914 : Closed e565593697914 ∧ code e565593697914 = 2764616953466 := by decide
theorem cert_e565593697914 : check e565593697914 [[],[.under]] .smaller = true := by decide
def e565593698102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e565593698102 : Closed e565593698102 ∧ code e565593698102 = 2764616953654 := by decide
theorem cert_e565593698102 : check e565593698102 [[],[.under]] .three = true := by decide
def e565593698106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e565593698106 : Closed e565593698106 ∧ code e565593698106 = 2764616953658 := by decide
theorem cert_e565593698106 : check e565593698106 [[],[.under]] .three = true := by decide
def e565593699166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e565593699166 : Closed e565593699166 ∧ code e565593699166 = 2764616954718 := by decide
theorem cert_e565593699166 : check e565593699166 [[],[.under]] .three = true := by decide
def e565593699182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e565593699182 : Closed e565593699182 ∧ code e565593699182 = 2764616954734 := by decide
theorem cert_e565593699182 : check e565593699182 [[],[.under]] .smaller = true := by decide
def e565593699190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e565593699190 : Closed e565593699190 ∧ code e565593699190 = 2764616954742 := by decide
theorem cert_e565593699190 : check e565593699190 [[],[.under]] .smaller = true := by decide
def e565593699194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e565593699194 : Closed e565593699194 ∧ code e565593699194 = 2764616954746 := by decide
theorem cert_e565593699194 : check e565593699194 [[],[.under]] .three = true := by decide
def e565593699246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e565593699246 : Closed e565593699246 ∧ code e565593699246 = 2764616954798 := by decide
theorem cert_e565593699246 : check e565593699246 [[],[.under]] .smaller = true := by decide
def e565593699258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e565593699258 : Closed e565593699258 ∧ code e565593699258 = 2764616954810 := by decide
theorem cert_e565593699258 : check e565593699258 [[],[.under]] .smaller = true := by decide
def e565593699286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e565593699286 : Closed e565593699286 ∧ code e565593699286 = 2764616954838 := by decide
theorem cert_e565593699286 : check e565593699286 [[],[.under]] .smaller = true := by decide
def e565593699290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e565593699290 : Closed e565593699290 ∧ code e565593699290 = 2764616954842 := by decide
theorem cert_e565593699290 : check e565593699290 [[],[.under]] .smaller = true := by decide
def e565593699306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e565593699306 : Closed e565593699306 ∧ code e565593699306 = 2764616954858 := by decide
theorem cert_e565593699306 : check e565593699306 [[],[.under]] .three = true := by decide
def e565593699550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e565593699550 : Closed e565593699550 ∧ code e565593699550 = 2764616955102 := by decide
theorem cert_e565593699550 : check e565593699550 [[],[.under]] .three = true := by decide
def e565593699566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e565593699566 : Closed e565593699566 ∧ code e565593699566 = 2764616955118 := by decide
theorem cert_e565593699566 : check e565593699566 [[],[.under]] .smaller = true := by decide
def e565593699574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e565593699574 : Closed e565593699574 ∧ code e565593699574 = 2764616955126 := by decide
theorem cert_e565593699574 : check e565593699574 [[],[.under]] .smaller = true := by decide
def e565593699578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e565593699578 : Closed e565593699578 ∧ code e565593699578 = 2764616955130 := by decide
theorem cert_e565593699578 : check e565593699578 [[],[.under]] .three = true := by decide
def e565593699950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e565593699950 : Closed e565593699950 ∧ code e565593699950 = 2764616955502 := by decide
theorem cert_e565593699950 : check e565593699950 [[],[.under]] .smaller = true := by decide
def e565593699962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e565593699962 : Closed e565593699962 ∧ code e565593699962 = 2764616955514 := by decide
theorem cert_e565593699962 : check e565593699962 [[],[.under]] .smaller = true := by decide
def e565593700150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e565593700150 : Closed e565593700150 ∧ code e565593700150 = 2764616955702 := by decide
theorem cert_e565593700150 : check e565593700150 [[],[.under]] .smaller = true := by decide
def e565593700154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e565593700154 : Closed e565593700154 ∧ code e565593700154 = 2764616955706 := by decide
theorem cert_e565593700154 : check e565593700154 [[],[.under]] .smaller = true := by decide
def e565593700250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e565593700250 : Closed e565593700250 ∧ code e565593700250 = 2764616955802 := by decide
theorem cert_e565593700250 : check e565593700250 [[],[.under]] .three = true := by decide
def e565593700782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e565593700782 : Closed e565593700782 ∧ code e565593700782 = 2764616956334 := by decide
theorem cert_e565593700782 : check e565593700782 [[],[.under]] .three = true := by decide
def e565593700790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e565593700790 : Closed e565593700790 ∧ code e565593700790 = 2764616956342 := by decide
theorem cert_e565593700790 : check e565593700790 [[],[.under]] .three = true := by decide
def e565593700794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e565593700794 : Closed e565593700794 ∧ code e565593700794 = 2764616956346 := by decide
theorem cert_e565593700794 : check e565593700794 [[],[.under]] .three = true := by decide
def e565593700822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e565593700822 : Closed e565593700822 ∧ code e565593700822 = 2764616956374 := by decide
theorem cert_e565593700822 : check e565593700822 [[],[.under]] .three = true := by decide
def e565593700826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e565593700826 : Closed e565593700826 ∧ code e565593700826 = 2764616956378 := by decide
theorem cert_e565593700826 : check e565593700826 [[],[.under]] .three = true := by decide
def e565593700842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e565593700842 : Closed e565593700842 ∧ code e565593700842 = 2764616956394 := by decide
theorem cert_e565593700842 : check e565593700842 [[],[.under]] .three = true := by decide
def e565593700974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e565593700974 : Closed e565593700974 ∧ code e565593700974 = 2764616956526 := by decide
theorem cert_e565593700974 : check e565593700974 [[],[.under]] .three = true := by decide
def e565593700982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e565593700982 : Closed e565593700982 ∧ code e565593700982 = 2764616956534 := by decide
theorem cert_e565593700982 : check e565593700982 [[],[.under]] .three = true := by decide
def e565593700986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e565593700986 : Closed e565593700986 ∧ code e565593700986 = 2764616956538 := by decide
theorem cert_e565593700986 : check e565593700986 [[],[.under]] .three = true := by decide
def e565593701174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e565593701174 : Closed e565593701174 ∧ code e565593701174 = 2764616956726 := by decide
theorem cert_e565593701174 : check e565593701174 [[],[.under]] .three = true := by decide
def e565593701178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e565593701178 : Closed e565593701178 ∧ code e565593701178 = 2764616956730 := by decide
theorem cert_e565593701178 : check e565593701178 [[],[.under]] .three = true := by decide
def e565593701274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e565593701274 : Closed e565593701274 ∧ code e565593701274 = 2764616956826 := by decide
theorem cert_e565593701274 : check e565593701274 [[],[.under]] .three = true := by decide
def e565593705326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e565593705326 : Closed e565593705326 ∧ code e565593705326 = 2764616960878 := by decide
theorem cert_e565593705326 : check e565593705326 [[],[.under]] .smaller = true := by decide
def e565593705334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e565593705334 : Closed e565593705334 ∧ code e565593705334 = 2764616960886 := by decide
theorem cert_e565593705334 : check e565593705334 [[],[.under]] .smaller = true := by decide
def e565593705390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e565593705390 : Closed e565593705390 ∧ code e565593705390 = 2764616960942 := by decide
theorem cert_e565593705390 : check e565593705390 [[],[.under]] .smaller = true := by decide
def e565593705402 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e565593705402 : Closed e565593705402 ∧ code e565593705402 = 2764616960954 := by decide
theorem cert_e565593705402 : check e565593705402 [[],[.under]] .smaller = true := by decide
def e565593705430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e565593705430 : Closed e565593705430 ∧ code e565593705430 = 2764616960982 := by decide
theorem cert_e565593705430 : check e565593705430 [[],[.under]] .smaller = true := by decide
def e565593705434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e565593705434 : Closed e565593705434 ∧ code e565593705434 = 2764616960986 := by decide
theorem cert_e565593705434 : check e565593705434 [[],[.under]] .smaller = true := by decide
def e565593705710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e565593705710 : Closed e565593705710 ∧ code e565593705710 = 2764616961262 := by decide
theorem cert_e565593705710 : check e565593705710 [[],[.under]] .smaller = true := by decide
def e565593705718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e565593705718 : Closed e565593705718 ∧ code e565593705718 = 2764616961270 := by decide
theorem cert_e565593705718 : check e565593705718 [[],[.under]] .smaller = true := by decide
def e565593706094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e565593706094 : Closed e565593706094 ∧ code e565593706094 = 2764616961646 := by decide
theorem cert_e565593706094 : check e565593706094 [[],[.under]] .smaller = true := by decide
def e565593706106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e565593706106 : Closed e565593706106 ∧ code e565593706106 = 2764616961658 := by decide
theorem cert_e565593706106 : check e565593706106 [[],[.under]] .smaller = true := by decide
def e565593706294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e565593706294 : Closed e565593706294 ∧ code e565593706294 = 2764616961846 := by decide
theorem cert_e565593706294 : check e565593706294 [[],[.under]] .smaller = true := by decide
def e565593706298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e565593706298 : Closed e565593706298 ∧ code e565593706298 = 2764616961850 := by decide
theorem cert_e565593706298 : check e565593706298 [[],[.under]] .smaller = true := by decide
def e565593714142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e565593714142 : Closed e565593714142 ∧ code e565593714142 = 2764616969694 := by decide
theorem cert_e565593714142 : check e565593714142 [[],[.under]] .three = true := by decide
def e565593714158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e565593714158 : Closed e565593714158 ∧ code e565593714158 = 2764616969710 := by decide
theorem cert_e565593714158 : check e565593714158 [[],[.under]] .three = true := by decide
def e565593714398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e565593714398 : Closed e565593714398 ∧ code e565593714398 = 2764616969950 := by decide
theorem cert_e565593714398 : check e565593714398 [[],[.under]] .three = true := by decide
def e565593714414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e565593714414 : Closed e565593714414 ∧ code e565593714414 = 2764616969966 := by decide
theorem cert_e565593714414 : check e565593714414 [[],[.under]] .smaller = true := by decide
def e565593714422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e565593714422 : Closed e565593714422 ∧ code e565593714422 = 2764616969974 := by decide
theorem cert_e565593714422 : check e565593714422 [[],[.under]] .three = true := by decide
def e565593714526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e565593714526 : Closed e565593714526 ∧ code e565593714526 = 2764616970078 := by decide
theorem cert_e565593714526 : check e565593714526 [[],[.under]] .three = true := by decide
def e565593714542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e565593714542 : Closed e565593714542 ∧ code e565593714542 = 2764616970094 := by decide
theorem cert_e565593714542 : check e565593714542 [[],[.under]] .smaller = true := by decide
def e565593714550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e565593714550 : Closed e565593714550 ∧ code e565593714550 = 2764616970102 := by decide
theorem cert_e565593714550 : check e565593714550 [[],[.under]] .smaller = true := by decide
def e565593714554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e565593714554 : Closed e565593714554 ∧ code e565593714554 = 2764616970106 := by decide
theorem cert_e565593714554 : check e565593714554 [[],[.under]] .three = true := by decide
def e565593714606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e565593714606 : Closed e565593714606 ∧ code e565593714606 = 2764616970158 := by decide
theorem cert_e565593714606 : check e565593714606 [[],[.under]] .three = true := by decide
def e565593714614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e565593714614 : Closed e565593714614 ∧ code e565593714614 = 2764616970166 := by decide
theorem cert_e565593714614 : check e565593714614 [[],[.under]] .three = true := by decide
def e565593714618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e565593714618 : Closed e565593714618 ∧ code e565593714618 = 2764616970170 := by decide
theorem cert_e565593714618 : check e565593714618 [[],[.under]] .three = true := by decide
def e565593715678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e565593715678 : Closed e565593715678 ∧ code e565593715678 = 2764616971230 := by decide
theorem cert_e565593715678 : check e565593715678 [[],[.under]] .three = true := by decide
def e565593715694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e565593715694 : Closed e565593715694 ∧ code e565593715694 = 2764616971246 := by decide
theorem cert_e565593715694 : check e565593715694 [[],[.under]] .three = true := by decide
def e565593717214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e565593717214 : Closed e565593717214 ∧ code e565593717214 = 2764616972766 := by decide
theorem cert_e565593717214 : check e565593717214 [[],[.under]] .three = true := by decide
def e565593717230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e565593717230 : Closed e565593717230 ∧ code e565593717230 = 2764616972782 := by decide
theorem cert_e565593717230 : check e565593717230 [[],[.under]] .smaller = true := by decide
def e565593717238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e565593717238 : Closed e565593717238 ∧ code e565593717238 = 2764616972790 := by decide
theorem cert_e565593717238 : check e565593717238 [[],[.under]] .three = true := by decide
def e565593717982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e565593717982 : Closed e565593717982 ∧ code e565593717982 = 2764616973534 := by decide
theorem cert_e565593717982 : check e565593717982 [[],[.under]] .three = true := by decide
def e565593717998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e565593717998 : Closed e565593717998 ∧ code e565593717998 = 2764616973550 := by decide
theorem cert_e565593717998 : check e565593717998 [[],[.under]] .smaller = true := by decide
def e565593718006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e565593718006 : Closed e565593718006 ∧ code e565593718006 = 2764616973558 := by decide
theorem cert_e565593718006 : check e565593718006 [[],[.under]] .smaller = true := by decide
def e565593718010 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e565593718010 : Closed e565593718010 ∧ code e565593718010 = 2764616973562 := by decide
theorem cert_e565593718010 : check e565593718010 [[],[.under]] .three = true := by decide
def e565593718382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e565593718382 : Closed e565593718382 ∧ code e565593718382 = 2764616973934 := by decide
theorem cert_e565593718382 : check e565593718382 [[],[.under]] .three = true := by decide
def e565593718390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e565593718390 : Closed e565593718390 ∧ code e565593718390 = 2764616973942 := by decide
theorem cert_e565593718390 : check e565593718390 [[],[.under]] .three = true := by decide
def e565593718394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e565593718394 : Closed e565593718394 ∧ code e565593718394 = 2764616973946 := by decide
theorem cert_e565593718394 : check e565593718394 [[],[.under]] .three = true := by decide
def e565593741022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e565593741022 : Closed e565593741022 ∧ code e565593741022 = 2764616996574 := by decide
theorem cert_e565593741022 : check e565593741022 [[],[.under]] .three = true := by decide
def e565593741038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e565593741038 : Closed e565593741038 ∧ code e565593741038 = 2764616996590 := by decide
theorem cert_e565593741038 : check e565593741038 [[],[.under]] .smaller = true := by decide
def e565593741046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e565593741046 : Closed e565593741046 ∧ code e565593741046 = 2764616996598 := by decide
theorem cert_e565593741046 : check e565593741046 [[],[.under]] .three = true := by decide
def e565593741150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e565593741150 : Closed e565593741150 ∧ code e565593741150 = 2764616996702 := by decide
theorem cert_e565593741150 : check e565593741150 [[],[.under]] .three = true := by decide
def e565593741178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e565593741178 : Closed e565593741178 ∧ code e565593741178 = 2764616996730 := by decide
theorem cert_e565593741178 : check e565593741178 [[],[.under]] .three = true := by decide
def e565593741230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e565593741230 : Closed e565593741230 ∧ code e565593741230 = 2764616996782 := by decide
theorem cert_e565593741230 : check e565593741230 [[],[.under]] .smaller = true := by decide
def e565593741242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e565593741242 : Closed e565593741242 ∧ code e565593741242 = 2764616996794 := by decide
theorem cert_e565593741242 : check e565593741242 [[],[.under]] .smaller = true := by decide
def e565593741270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e565593741270 : Closed e565593741270 ∧ code e565593741270 = 2764616996822 := by decide
theorem cert_e565593741270 : check e565593741270 [[],[.under]] .three = true := by decide
def e565593741274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e565593741274 : Closed e565593741274 ∧ code e565593741274 = 2764616996826 := by decide
theorem cert_e565593741274 : check e565593741274 [[],[.under]] .three = true := by decide
def e565593741790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e565593741790 : Closed e565593741790 ∧ code e565593741790 = 2764616997342 := by decide
theorem cert_e565593741790 : check e565593741790 [[],[.under]] .three = true := by decide
def e565593741806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e565593741806 : Closed e565593741806 ∧ code e565593741806 = 2764616997358 := by decide
theorem cert_e565593741806 : check e565593741806 [[],[.under]] .smaller = true := by decide
def e565593741814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e565593741814 : Closed e565593741814 ∧ code e565593741814 = 2764616997366 := by decide
theorem cert_e565593741814 : check e565593741814 [[],[.under]] .three = true := by decide
def e565593742558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e565593742558 : Closed e565593742558 ∧ code e565593742558 = 2764616998110 := by decide
theorem cert_e565593742558 : check e565593742558 [[],[.under]] .three = true := by decide
def e565593742586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e565593742586 : Closed e565593742586 ∧ code e565593742586 = 2764616998138 := by decide
theorem cert_e565593742586 : check e565593742586 [[],[.under]] .three = true := by decide
def e565593742958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e565593742958 : Closed e565593742958 ∧ code e565593742958 = 2764616998510 := by decide
theorem cert_e565593742958 : check e565593742958 [[],[.under]] .smaller = true := by decide
def e565593742970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e565593742970 : Closed e565593742970 ∧ code e565593742970 = 2764616998522 := by decide
theorem cert_e565593742970 : check e565593742970 [[],[.under]] .smaller = true := by decide
def e565593743158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e565593743158 : Closed e565593743158 ∧ code e565593743158 = 2764616998710 := by decide
theorem cert_e565593743158 : check e565593743158 [[],[.under]] .three = true := by decide
def e565593743162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e565593743162 : Closed e565593743162 ∧ code e565593743162 = 2764616998714 := by decide
theorem cert_e565593743162 : check e565593743162 [[],[.under]] .three = true := by decide
def e565593754462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e565593754462 : Closed e565593754462 ∧ code e565593754462 = 2764617010014 := by decide
theorem cert_e565593754462 : check e565593754462 [[],[.under]] .three = true := by decide
def e565593754478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e565593754478 : Closed e565593754478 ∧ code e565593754478 = 2764617010030 := by decide
theorem cert_e565593754478 : check e565593754478 [[],[.under]] .smaller = true := by decide
def e565593754486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e565593754486 : Closed e565593754486 ∧ code e565593754486 = 2764617010038 := by decide
theorem cert_e565593754486 : check e565593754486 [[],[.under]] .smaller = true := by decide
def e565593754490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e565593754490 : Closed e565593754490 ∧ code e565593754490 = 2764617010042 := by decide
theorem cert_e565593754490 : check e565593754490 [[],[.under]] .three = true := by decide
def e565593754542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e565593754542 : Closed e565593754542 ∧ code e565593754542 = 2764617010094 := by decide
theorem cert_e565593754542 : check e565593754542 [[],[.under]] .smaller = true := by decide
def e565593754554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e565593754554 : Closed e565593754554 ∧ code e565593754554 = 2764617010106 := by decide
theorem cert_e565593754554 : check e565593754554 [[],[.under]] .smaller = true := by decide
def e565593754582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e565593754582 : Closed e565593754582 ∧ code e565593754582 = 2764617010134 := by decide
theorem cert_e565593754582 : check e565593754582 [[],[.under]] .smaller = true := by decide
def e565593754586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e565593754586 : Closed e565593754586 ∧ code e565593754586 = 2764617010138 := by decide
theorem cert_e565593754586 : check e565593754586 [[],[.under]] .smaller = true := by decide
def e565593754602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e565593754602 : Closed e565593754602 ∧ code e565593754602 = 2764617010154 := by decide
theorem cert_e565593754602 : check e565593754602 [[],[.under]] .three = true := by decide
def e565593754846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e565593754846 : Closed e565593754846 ∧ code e565593754846 = 2764617010398 := by decide
theorem cert_e565593754846 : check e565593754846 [[],[.under]] .three = true := by decide
def e565593754862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e565593754862 : Closed e565593754862 ∧ code e565593754862 = 2764617010414 := by decide
theorem cert_e565593754862 : check e565593754862 [[],[.under]] .smaller = true := by decide
def e565593754870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e565593754870 : Closed e565593754870 ∧ code e565593754870 = 2764617010422 := by decide
theorem cert_e565593754870 : check e565593754870 [[],[.under]] .smaller = true := by decide
def e565593754874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e565593754874 : Closed e565593754874 ∧ code e565593754874 = 2764617010426 := by decide
theorem cert_e565593754874 : check e565593754874 [[],[.under]] .three = true := by decide
def e565593755246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e565593755246 : Closed e565593755246 ∧ code e565593755246 = 2764617010798 := by decide
theorem cert_e565593755246 : check e565593755246 [[],[.under]] .smaller = true := by decide
def e565593755258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e565593755258 : Closed e565593755258 ∧ code e565593755258 = 2764617010810 := by decide
theorem cert_e565593755258 : check e565593755258 [[],[.under]] .smaller = true := by decide
def e565593755446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e565593755446 : Closed e565593755446 ∧ code e565593755446 = 2764617010998 := by decide
theorem cert_e565593755446 : check e565593755446 [[],[.under]] .smaller = true := by decide
def e565593755450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e565593755450 : Closed e565593755450 ∧ code e565593755450 = 2764617011002 := by decide
theorem cert_e565593755450 : check e565593755450 [[],[.under]] .smaller = true := by decide
def e565593755546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e565593755546 : Closed e565593755546 ∧ code e565593755546 = 2764617011098 := by decide
theorem cert_e565593755546 : check e565593755546 [[],[.under]] .three = true := by decide
def e565593761198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e565593761198 : Closed e565593761198 ∧ code e565593761198 = 2764617016750 := by decide
theorem cert_e565593761198 : check e565593761198 [[],[.under]] .three = true := by decide
def e565593761206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e565593761206 : Closed e565593761206 ∧ code e565593761206 = 2764617016758 := by decide
theorem cert_e565593761206 : check e565593761206 [[],[.under]] .three = true := by decide
end Blc.Floor41
