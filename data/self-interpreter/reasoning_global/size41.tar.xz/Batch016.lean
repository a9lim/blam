import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e553232692762 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553232692762 : Closed e553232692762 ∧ code e553232692762 = 2752255948314 := by decide
theorem cert_e553232692762 : check e553232692762 [[]] .width = true := by decide
def e553232728090 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553232728090 : Closed e553232728090 ∧ code e553232728090 = 2752255983642 := by decide
theorem cert_e553232728090 : check e553232728090 [[]] .width = true := by decide
def e553232728182 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553232728182 : Closed e553232728182 ∧ code e553232728182 = 2752255983734 := by decide
theorem cert_e553232728182 : check e553232728182 [[]] .width = true := by decide
def e553232728426 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553232728426 : Closed e553232728426 ∧ code e553232728426 = 2752255983978 := by decide
theorem cert_e553232728426 : check e553232728426 [[]] .width = true := by decide
def e553232728474 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553232728474 : Closed e553232728474 ∧ code e553232728474 = 2752255984026 := by decide
theorem cert_e553232728474 : check e553232728474 [[]] .width = true := by decide
def e553232729482 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553232729482 : Closed e553232729482 ∧ code e553232729482 = 2752255985034 := by decide
theorem cert_e553232729482 : check e553232729482 [[]] .width = true := by decide
def e553232729506 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553232729506 : Closed e553232729506 ∧ code e553232729506 = 2752255985058 := by decide
theorem cert_e553232729506 : check e553232729506 [[]] .width = true := by decide
def e553232729614 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553232729614 : Closed e553232729614 ∧ code e553232729614 = 2752255985166 := by decide
theorem cert_e553232729614 : check e553232729614 [[]] .width = true := by decide
def e553232729626 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553232729626 : Closed e553232729626 ∧ code e553232729626 = 2752255985178 := by decide
theorem cert_e553232729626 : check e553232729626 [[]] .width = true := by decide
def e553232729698 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553232729698 : Closed e553232729698 ∧ code e553232729698 = 2752255985250 := by decide
theorem cert_e553232729698 : check e553232729698 [[]] .width = true := by decide
def e553605066266 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553605066266 : Closed e553605066266 ∧ code e553605066266 = 2752628321818 := by decide
theorem cert_e553605066266 : check e553605066266 [[]] .width = true := by decide
def e553605852698 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553605852698 : Closed e553605852698 ∧ code e553605852698 = 2752629108250 := by decide
theorem cert_e553605852698 : check e553605852698 [[]] .width = true := by decide
def e553605901850 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553605901850 : Closed e553605901850 ∧ code e553605901850 = 2752629157402 := by decide
theorem cert_e553605901850 : check e553605901850 [[]] .width = true := by decide
def e553605904922 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553605904922 : Closed e553605904922 ∧ code e553605904922 = 2752629160474 := by decide
theorem cert_e553605904922 : check e553605904922 [[]] .width = true := by decide
def e553608211994 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553608211994 : Closed e553608211994 ∧ code e553608211994 = 2752631467546 := by decide
theorem cert_e553608211994 : check e553608211994 [[]] .width = true := by decide
def e553609981466 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553609981466 : Closed e553609981466 ∧ code e553609981466 = 2752633237018 := by decide
theorem cert_e553609981466 : check e553609981466 [[]] .width = true := by decide
def e553610084378 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553610084378 : Closed e553610084378 ∧ code e553610084378 = 2752633339930 := by decide
theorem cert_e553610084378 : check e553610084378 [[]] .width = true := by decide
def e553610084470 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553610084470 : Closed e553610084470 ∧ code e553610084470 = 2752633340022 := by decide
theorem cert_e553610084470 : check e553610084470 [[]] .width = true := by decide
def e553610084714 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553610084714 : Closed e553610084714 ∧ code e553610084714 = 2752633340266 := by decide
theorem cert_e553610084714 : check e553610084714 [[]] .width = true := by decide
def e553610084762 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553610084762 : Closed e553610084762 ∧ code e553610084762 = 2752633340314 := by decide
theorem cert_e553610084762 : check e553610084762 [[]] .width = true := by decide
def e553610085770 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553610085770 : Closed e553610085770 ∧ code e553610085770 = 2752633341322 := by decide
theorem cert_e553610085770 : check e553610085770 [[]] .width = true := by decide
def e553610085794 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553610085794 : Closed e553610085794 ∧ code e553610085794 = 2752633341346 := by decide
theorem cert_e553610085794 : check e553610085794 [[]] .width = true := by decide
def e553610085902 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553610085902 : Closed e553610085902 ∧ code e553610085902 = 2752633341454 := by decide
theorem cert_e553610085902 : check e553610085902 [[]] .width = true := by decide
def e553610085914 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553610085914 : Closed e553610085914 ∧ code e553610085914 = 2752633341466 := by decide
theorem cert_e553610085914 : check e553610085914 [[]] .width = true := by decide
def e553610085986 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553610085986 : Closed e553610085986 ∧ code e553610085986 = 2752633341538 := by decide
theorem cert_e553610085986 : check e553610085986 [[]] .width = true := by decide
def e553612930586 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553612930586 : Closed e553612930586 ∧ code e553612930586 = 2752636186138 := by decide
theorem cert_e553612930586 : check e553612930586 [[]] .width = true := by decide
def e553612979738 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553612979738 : Closed e553612979738 ∧ code e553612979738 = 2752636235290 := by decide
theorem cert_e553612979738 : check e553612979738 [[]] .width = true := by decide
def e553612982810 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553612982810 : Closed e553612982810 ∧ code e553612982810 = 2752636238362 := by decide
theorem cert_e553612982810 : check e553612982810 [[]] .width = true := by decide
def e553613127194 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553613127194 : Closed e553613127194 ∧ code e553613127194 = 2752636382746 := by decide
theorem cert_e553613127194 : check e553613127194 [[]] .width = true := by decide
def e553613230106 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553613230106 : Closed e553613230106 ∧ code e553613230106 = 2752636485658 := by decide
theorem cert_e553613230106 : check e553613230106 [[]] .width = true := by decide
def e553613230198 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553613230198 : Closed e553613230198 ∧ code e553613230198 = 2752636485750 := by decide
theorem cert_e553613230198 : check e553613230198 [[]] .width = true := by decide
def e553613230442 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553613230442 : Closed e553613230442 ∧ code e553613230442 = 2752636485994 := by decide
theorem cert_e553613230442 : check e553613230442 [[]] .width = true := by decide
def e553613230490 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553613230490 : Closed e553613230490 ∧ code e553613230490 = 2752636486042 := by decide
theorem cert_e553613230490 : check e553613230490 [[]] .width = true := by decide
def e553613231498 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553613231498 : Closed e553613231498 ∧ code e553613231498 = 2752636487050 := by decide
theorem cert_e553613231498 : check e553613231498 [[]] .width = true := by decide
def e553613231522 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553613231522 : Closed e553613231522 ∧ code e553613231522 = 2752636487074 := by decide
theorem cert_e553613231522 : check e553613231522 [[]] .width = true := by decide
def e553613231630 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553613231630 : Closed e553613231630 ∧ code e553613231630 = 2752636487182 := by decide
theorem cert_e553613231630 : check e553613231630 [[]] .width = true := by decide
def e553613231642 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553613231642 : Closed e553613231642 ∧ code e553613231642 = 2752636487194 := by decide
theorem cert_e553613231642 : check e553613231642 [[]] .width = true := by decide
def e553613231714 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553613231714 : Closed e553613231714 ∧ code e553613231714 = 2752636487266 := by decide
theorem cert_e553613231714 : check e553613231714 [[]] .width = true := by decide
def e553613422106 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553613422106 : Closed e553613422106 ∧ code e553613422106 = 2752636677658 := by decide
theorem cert_e553613422106 : check e553613422106 [[]] .width = true := by decide
def e553613425178 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553613425178 : Closed e553613425178 ∧ code e553613425178 = 2752636680730 := by decide
theorem cert_e553613425178 : check e553613425178 [[]] .width = true := by decide
def e553613426714 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553613426714 : Closed e553613426714 ∧ code e553613426714 = 2752636682266 := by decide
theorem cert_e553613426714 : check e553613426714 [[]] .width = true := by decide
def e553613426806 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553613426806 : Closed e553613426806 ∧ code e553613426806 = 2752636682358 := by decide
theorem cert_e553613426806 : check e553613426806 [[]] .width = true := by decide
def e553613427050 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553613427050 : Closed e553613427050 ∧ code e553613427050 = 2752636682602 := by decide
theorem cert_e553613427050 : check e553613427050 [[]] .width = true := by decide
def e553613427098 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553613427098 : Closed e553613427098 ∧ code e553613427098 = 2752636682650 := by decide
theorem cert_e553613427098 : check e553613427098 [[]] .width = true := by decide
def e553613428106 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553613428106 : Closed e553613428106 ∧ code e553613428106 = 2752636683658 := by decide
theorem cert_e553613428106 : check e553613428106 [[]] .width = true := by decide
def e553613428130 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553613428130 : Closed e553613428130 ∧ code e553613428130 = 2752636683682 := by decide
theorem cert_e553613428130 : check e553613428130 [[]] .width = true := by decide
def e553613428238 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553613428238 : Closed e553613428238 ∧ code e553613428238 = 2752636683790 := by decide
theorem cert_e553613428238 : check e553613428238 [[]] .width = true := by decide
def e553613428250 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553613428250 : Closed e553613428250 ∧ code e553613428250 = 2752636683802 := by decide
theorem cert_e553613428250 : check e553613428250 [[]] .width = true := by decide
def e553613428322 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553613428322 : Closed e553613428322 ∧ code e553613428322 = 2752636683874 := by decide
theorem cert_e553613428322 : check e553613428322 [[]] .width = true := by decide
def e553620794906 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553620794906 : Closed e553620794906 ∧ code e553620794906 = 2752644050458 := by decide
theorem cert_e553620794906 : check e553620794906 [[]] .width = true := by decide
def e553622564378 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553622564378 : Closed e553622564378 ∧ code e553622564378 = 2752645819930 := by decide
theorem cert_e553622564378 : check e553622564378 [[]] .width = true := by decide
def e553622667290 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553622667290 : Closed e553622667290 ∧ code e553622667290 = 2752645922842 := by decide
theorem cert_e553622667290 : check e553622667290 [[]] .width = true := by decide
def e553622667382 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553622667382 : Closed e553622667382 ∧ code e553622667382 = 2752645922934 := by decide
theorem cert_e553622667382 : check e553622667382 [[]] .width = true := by decide
def e553622667626 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553622667626 : Closed e553622667626 ∧ code e553622667626 = 2752645923178 := by decide
theorem cert_e553622667626 : check e553622667626 [[]] .width = true := by decide
def e553622667674 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553622667674 : Closed e553622667674 ∧ code e553622667674 = 2752645923226 := by decide
theorem cert_e553622667674 : check e553622667674 [[]] .width = true := by decide
def e553622668682 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553622668682 : Closed e553622668682 ∧ code e553622668682 = 2752645924234 := by decide
theorem cert_e553622668682 : check e553622668682 [[]] .width = true := by decide
def e553622668706 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553622668706 : Closed e553622668706 ∧ code e553622668706 = 2752645924258 := by decide
theorem cert_e553622668706 : check e553622668706 [[]] .width = true := by decide
def e553622668814 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553622668814 : Closed e553622668814 ∧ code e553622668814 = 2752645924366 := by decide
theorem cert_e553622668814 : check e553622668814 [[]] .width = true := by decide
def e553622668826 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553622668826 : Closed e553622668826 ∧ code e553622668826 = 2752645924378 := by decide
theorem cert_e553622668826 : check e553622668826 [[]] .width = true := by decide
def e553622668898 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553622668898 : Closed e553622668898 ∧ code e553622668898 = 2752645924450 := by decide
theorem cert_e553622668898 : check e553622668898 [[]] .width = true := by decide
def e553641242138 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553641242138 : Closed e553641242138 ∧ code e553641242138 = 2752664497690 := by decide
theorem cert_e553641242138 : check e553641242138 [[]] .width = true := by decide
def e553641291290 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553641291290 : Closed e553641291290 ∧ code e553641291290 = 2752664546842 := by decide
theorem cert_e553641291290 : check e553641291290 [[]] .width = true := by decide
def e553641294362 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553641294362 : Closed e553641294362 ∧ code e553641294362 = 2752664549914 := by decide
theorem cert_e553641294362 : check e553641294362 [[]] .width = true := by decide
def e553641438746 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553641438746 : Closed e553641438746 ∧ code e553641438746 = 2752664694298 := by decide
theorem cert_e553641438746 : check e553641438746 [[]] .width = true := by decide
def e553641541658 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553641541658 : Closed e553641541658 ∧ code e553641541658 = 2752664797210 := by decide
theorem cert_e553641541658 : check e553641541658 [[]] .width = true := by decide
def e553641541750 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553641541750 : Closed e553641541750 ∧ code e553641541750 = 2752664797302 := by decide
theorem cert_e553641541750 : check e553641541750 [[]] .width = true := by decide
def e553641541994 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553641541994 : Closed e553641541994 ∧ code e553641541994 = 2752664797546 := by decide
theorem cert_e553641541994 : check e553641541994 [[]] .width = true := by decide
def e553641542042 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553641542042 : Closed e553641542042 ∧ code e553641542042 = 2752664797594 := by decide
theorem cert_e553641542042 : check e553641542042 [[]] .width = true := by decide
def e553641543050 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553641543050 : Closed e553641543050 ∧ code e553641543050 = 2752664798602 := by decide
theorem cert_e553641543050 : check e553641543050 [[]] .width = true := by decide
def e553641543074 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553641543074 : Closed e553641543074 ∧ code e553641543074 = 2752664798626 := by decide
theorem cert_e553641543074 : check e553641543074 [[]] .width = true := by decide
def e553641543182 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553641543182 : Closed e553641543182 ∧ code e553641543182 = 2752664798734 := by decide
theorem cert_e553641543182 : check e553641543182 [[]] .width = true := by decide
def e553641543194 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553641543194 : Closed e553641543194 ∧ code e553641543194 = 2752664798746 := by decide
theorem cert_e553641543194 : check e553641543194 [[]] .width = true := by decide
def e553641543266 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553641543266 : Closed e553641543266 ∧ code e553641543266 = 2752664798818 := by decide
theorem cert_e553641543266 : check e553641543266 [[]] .width = true := by decide
def e553641733658 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553641733658 : Closed e553641733658 ∧ code e553641733658 = 2752664989210 := by decide
theorem cert_e553641733658 : check e553641733658 [[]] .width = true := by decide
def e553641736730 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553641736730 : Closed e553641736730 ∧ code e553641736730 = 2752664992282 := by decide
theorem cert_e553641736730 : check e553641736730 [[]] .width = true := by decide
def e553641738266 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553641738266 : Closed e553641738266 ∧ code e553641738266 = 2752664993818 := by decide
theorem cert_e553641738266 : check e553641738266 [[]] .width = true := by decide
def e553641738358 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553641738358 : Closed e553641738358 ∧ code e553641738358 = 2752664993910 := by decide
theorem cert_e553641738358 : check e553641738358 [[]] .width = true := by decide
def e553641738602 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553641738602 : Closed e553641738602 ∧ code e553641738602 = 2752664994154 := by decide
theorem cert_e553641738602 : check e553641738602 [[]] .width = true := by decide
def e553641738650 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553641738650 : Closed e553641738650 ∧ code e553641738650 = 2752664994202 := by decide
theorem cert_e553641738650 : check e553641738650 [[]] .width = true := by decide
def e553641739658 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553641739658 : Closed e553641739658 ∧ code e553641739658 = 2752664995210 := by decide
theorem cert_e553641739658 : check e553641739658 [[]] .width = true := by decide
def e553641739682 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553641739682 : Closed e553641739682 ∧ code e553641739682 = 2752664995234 := by decide
theorem cert_e553641739682 : check e553641739682 [[]] .width = true := by decide
def e553641739790 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553641739790 : Closed e553641739790 ∧ code e553641739790 = 2752664995342 := by decide
theorem cert_e553641739790 : check e553641739790 [[]] .width = true := by decide
def e553641739802 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553641739802 : Closed e553641739802 ∧ code e553641739802 = 2752664995354 := by decide
theorem cert_e553641739802 : check e553641739802 [[]] .width = true := by decide
def e553641739874 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553641739874 : Closed e553641739874 ∧ code e553641739874 = 2752664995426 := by decide
theorem cert_e553641739874 : check e553641739874 [[]] .width = true := by decide
def e553827888666 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553827888666 : Closed e553827888666 ∧ code e553827888666 = 2752851144218 := by decide
theorem cert_e553827888666 : check e553827888666 [[]] .width = true := by decide
def e553827921434 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553827921434 : Closed e553827921434 ∧ code e553827921434 = 2752851176986 := by decide
theorem cert_e553827921434 : check e553827921434 [[]] .width = true := by decide
def e553827923482 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553827923482 : Closed e553827923482 ∧ code e553827923482 = 2752851179034 := by decide
theorem cert_e553827923482 : check e553827923482 [[]] .width = true := by decide
def e553828150810 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553828150810 : Closed e553828150810 ∧ code e553828150810 = 2752851406362 := by decide
theorem cert_e553828150810 : check e553828150810 [[]] .width = true := by decide
def e553828199962 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553828199962 : Closed e553828199962 ∧ code e553828199962 = 2752851455514 := by decide
theorem cert_e553828199962 : check e553828199962 [[]] .width = true := by decide
def e553828203034 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553828203034 : Closed e553828203034 ∧ code e553828203034 = 2752851458586 := by decide
theorem cert_e553828203034 : check e553828203034 [[]] .width = true := by decide
def e553828314650 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553828314650 : Closed e553828314650 ∧ code e553828314650 = 2752851570202 := by decide
theorem cert_e553828314650 : check e553828314650 [[]] .width = true := by decide
def e553828316698 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553828316698 : Closed e553828316698 ∧ code e553828316698 = 2752851572250 := by decide
theorem cert_e553828316698 : check e553828316698 [[]] .width = true := by decide
def e553828331034 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553828331034 : Closed e553828331034 ∧ code e553828331034 = 2752851586586 := by decide
theorem cert_e553828331034 : check e553828331034 [[]] .width = true := by decide
def e553828334106 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553828334106 : Closed e553828334106 ∧ code e553828334106 = 2752851589658 := by decide
theorem cert_e553828334106 : check e553828334106 [[]] .width = true := by decide
def e553828341274 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553828341274 : Closed e553828341274 ∧ code e553828341274 = 2752851596826 := by decide
private def t_e553828341274 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e553828341274 : ¬ IsSelfInterpreter e553828341274 :=
  wSource (t := t_e553828341274) (replay_sound (ps := []) (t := e553828341274) (by decide)) (by decide)
def e553828342298 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553828342298 : Closed e553828342298 ∧ code e553828342298 = 2752851597850 := by decide
private def t_e553828342298 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e553828342298 : ¬ IsSelfInterpreter e553828342298 :=
  wSource (t := t_e553828342298) (replay_sound (ps := []) (t := e553828342298) (by decide)) (by decide)
def e553829461530 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553829461530 : Closed e553829461530 ∧ code e553829461530 = 2752852717082 := by decide
theorem cert_e553829461530 : check e553829461530 [[]] .width = true := by decide
def e553829494298 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553829494298 : Closed e553829494298 ∧ code e553829494298 = 2752852749850 := by decide
theorem cert_e553829494298 : check e553829494298 [[]] .width = true := by decide
def e553829496346 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553829496346 : Closed e553829496346 ∧ code e553829496346 = 2752852751898 := by decide
theorem cert_e553829496346 : check e553829496346 [[]] .width = true := by decide
def e553830182426 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553830182426 : Closed e553830182426 ∧ code e553830182426 = 2752853437978 := by decide
theorem cert_e553830182426 : check e553830182426 [[]] .width = true := by decide
def e553830285338 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553830285338 : Closed e553830285338 ∧ code e553830285338 = 2752853540890 := by decide
theorem cert_e553830285338 : check e553830285338 [[]] .width = true := by decide
def e553830285430 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553830285430 : Closed e553830285430 ∧ code e553830285430 = 2752853540982 := by decide
theorem cert_e553830285430 : check e553830285430 [[]] .width = true := by decide
def e553830285674 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553830285674 : Closed e553830285674 ∧ code e553830285674 = 2752853541226 := by decide
theorem cert_e553830285674 : check e553830285674 [[]] .width = true := by decide
def e553830285722 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553830285722 : Closed e553830285722 ∧ code e553830285722 = 2752853541274 := by decide
theorem cert_e553830285722 : check e553830285722 [[]] .width = true := by decide
def e553830286730 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553830286730 : Closed e553830286730 ∧ code e553830286730 = 2752853542282 := by decide
theorem cert_e553830286730 : check e553830286730 [[]] .width = true := by decide
def e553830286754 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553830286754 : Closed e553830286754 ∧ code e553830286754 = 2752853542306 := by decide
theorem cert_e553830286754 : check e553830286754 [[]] .width = true := by decide
def e553830286862 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553830286862 : Closed e553830286862 ∧ code e553830286862 = 2752853542414 := by decide
theorem cert_e553830286862 : check e553830286862 [[]] .width = true := by decide
def e553830286874 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553830286874 : Closed e553830286874 ∧ code e553830286874 = 2752853542426 := by decide
theorem cert_e553830286874 : check e553830286874 [[]] .width = true := by decide
def e553830286946 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553830286946 : Closed e553830286946 ∧ code e553830286946 = 2752853542498 := by decide
theorem cert_e553830286946 : check e553830286946 [[]] .width = true := by decide
def e553830379034 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553830379034 : Closed e553830379034 ∧ code e553830379034 = 2752853634586 := by decide
theorem cert_e553830379034 : check e553830379034 [[]] .width = true := by decide
def e553830381082 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553830381082 : Closed e553830381082 ∧ code e553830381082 = 2752853636634 := by decide
theorem cert_e553830381082 : check e553830381082 [[]] .width = true := by decide
def e553830416410 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553830416410 : Closed e553830416410 ∧ code e553830416410 = 2752853671962 := by decide
theorem cert_e553830416410 : check e553830416410 [[]] .width = true := by decide
def e553830416502 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553830416502 : Closed e553830416502 ∧ code e553830416502 = 2752853672054 := by decide
theorem cert_e553830416502 : check e553830416502 [[]] .width = true := by decide
def e553830416746 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553830416746 : Closed e553830416746 ∧ code e553830416746 = 2752853672298 := by decide
theorem cert_e553830416746 : check e553830416746 [[]] .width = true := by decide
def e553830416794 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553830416794 : Closed e553830416794 ∧ code e553830416794 = 2752853672346 := by decide
theorem cert_e553830416794 : check e553830416794 [[]] .width = true := by decide
def e553830417802 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553830417802 : Closed e553830417802 ∧ code e553830417802 = 2752853673354 := by decide
theorem cert_e553830417802 : check e553830417802 [[]] .width = true := by decide
def e553830417826 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553830417826 : Closed e553830417826 ∧ code e553830417826 = 2752853673378 := by decide
theorem cert_e553830417826 : check e553830417826 [[]] .width = true := by decide
def e553830417934 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553830417934 : Closed e553830417934 ∧ code e553830417934 = 2752853673486 := by decide
theorem cert_e553830417934 : check e553830417934 [[]] .width = true := by decide
def e553830417946 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553830417946 : Closed e553830417946 ∧ code e553830417946 = 2752853673498 := by decide
theorem cert_e553830417946 : check e553830417946 [[]] .width = true := by decide
def e553830418018 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553830418018 : Closed e553830418018 ∧ code e553830418018 = 2752853673570 := by decide
theorem cert_e553830418018 : check e553830418018 [[]] .width = true := by decide
def e553831034394 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831034394 : Closed e553831034394 ∧ code e553831034394 = 2752854289946 := by decide
theorem cert_e553831034394 : check e553831034394 [[]] .width = true := by decide
def e553831083546 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831083546 : Closed e553831083546 ∧ code e553831083546 = 2752854339098 := by decide
theorem cert_e553831083546 : check e553831083546 [[]] .width = true := by decide
def e553831086618 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831086618 : Closed e553831086618 ∧ code e553831086618 = 2752854342170 := by decide
theorem cert_e553831086618 : check e553831086618 [[]] .width = true := by decide
def e553831231002 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831231002 : Closed e553831231002 ∧ code e553831231002 = 2752854486554 := by decide
theorem cert_e553831231002 : check e553831231002 [[]] .width = true := by decide
def e553831333914 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553831333914 : Closed e553831333914 ∧ code e553831333914 = 2752854589466 := by decide
theorem cert_e553831333914 : check e553831333914 [[]] .width = true := by decide
def e553831334006 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553831334006 : Closed e553831334006 ∧ code e553831334006 = 2752854589558 := by decide
theorem cert_e553831334006 : check e553831334006 [[]] .width = true := by decide
def e553831334250 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553831334250 : Closed e553831334250 ∧ code e553831334250 = 2752854589802 := by decide
theorem cert_e553831334250 : check e553831334250 [[]] .width = true := by decide
def e553831334298 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553831334298 : Closed e553831334298 ∧ code e553831334298 = 2752854589850 := by decide
theorem cert_e553831334298 : check e553831334298 [[]] .width = true := by decide
def e553831335306 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553831335306 : Closed e553831335306 ∧ code e553831335306 = 2752854590858 := by decide
theorem cert_e553831335306 : check e553831335306 [[]] .width = true := by decide
def e553831335330 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553831335330 : Closed e553831335330 ∧ code e553831335330 = 2752854590882 := by decide
theorem cert_e553831335330 : check e553831335330 [[]] .width = true := by decide
def e553831335438 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553831335438 : Closed e553831335438 ∧ code e553831335438 = 2752854590990 := by decide
theorem cert_e553831335438 : check e553831335438 [[]] .width = true := by decide
def e553831335450 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553831335450 : Closed e553831335450 ∧ code e553831335450 = 2752854591002 := by decide
theorem cert_e553831335450 : check e553831335450 [[]] .width = true := by decide
def e553831335522 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553831335522 : Closed e553831335522 ∧ code e553831335522 = 2752854591074 := by decide
theorem cert_e553831335522 : check e553831335522 [[]] .width = true := by decide
def e553831525914 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831525914 : Closed e553831525914 ∧ code e553831525914 = 2752854781466 := by decide
theorem cert_e553831525914 : check e553831525914 [[]] .width = true := by decide
def e553831528986 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831528986 : Closed e553831528986 ∧ code e553831528986 = 2752854784538 := by decide
theorem cert_e553831528986 : check e553831528986 [[]] .width = true := by decide
def e553831530522 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553831530522 : Closed e553831530522 ∧ code e553831530522 = 2752854786074 := by decide
theorem cert_e553831530522 : check e553831530522 [[]] .width = true := by decide
def e553831530614 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553831530614 : Closed e553831530614 ∧ code e553831530614 = 2752854786166 := by decide
theorem cert_e553831530614 : check e553831530614 [[]] .width = true := by decide
def e553831530858 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553831530858 : Closed e553831530858 ∧ code e553831530858 = 2752854786410 := by decide
theorem cert_e553831530858 : check e553831530858 [[]] .width = true := by decide
def e553831530906 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553831530906 : Closed e553831530906 ∧ code e553831530906 = 2752854786458 := by decide
theorem cert_e553831530906 : check e553831530906 [[]] .width = true := by decide
def e553831531914 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553831531914 : Closed e553831531914 ∧ code e553831531914 = 2752854787466 := by decide
theorem cert_e553831531914 : check e553831531914 [[]] .width = true := by decide
def e553831531938 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553831531938 : Closed e553831531938 ∧ code e553831531938 = 2752854787490 := by decide
theorem cert_e553831531938 : check e553831531938 [[]] .width = true := by decide
def e553831532046 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553831532046 : Closed e553831532046 ∧ code e553831532046 = 2752854787598 := by decide
theorem cert_e553831532046 : check e553831532046 [[]] .width = true := by decide
def e553831532058 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553831532058 : Closed e553831532058 ∧ code e553831532058 = 2752854787610 := by decide
theorem cert_e553831532058 : check e553831532058 [[]] .width = true := by decide
def e553831532130 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e553831532130 : Closed e553831532130 ∧ code e553831532130 = 2752854787682 := by decide
theorem cert_e553831532130 : check e553831532130 [[]] .width = true := by decide
def e553831853594 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831853594 : Closed e553831853594 ∧ code e553831853594 = 2752855109146 := by decide
theorem cert_e553831853594 : check e553831853594 [[]] .width = true := by decide
def e553831855642 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831855642 : Closed e553831855642 ∧ code e553831855642 = 2752855111194 := by decide
theorem cert_e553831855642 : check e553831855642 [[]] .width = true := by decide
def e553831869978 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831869978 : Closed e553831869978 ∧ code e553831869978 = 2752855125530 := by decide
theorem cert_e553831869978 : check e553831869978 [[]] .width = true := by decide
def e553831873050 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831873050 : Closed e553831873050 ∧ code e553831873050 = 2752855128602 := by decide
theorem cert_e553831873050 : check e553831873050 [[]] .width = true := by decide
def e553831880218 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831880218 : Closed e553831880218 ∧ code e553831880218 = 2752855135770 := by decide
theorem cert_e553831880218 : check e553831880218 [[]] .width = true := by decide
def e553831881242 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831881242 : Closed e553831881242 ∧ code e553831881242 = 2752855136794 := by decide
theorem cert_e553831881242 : check e553831881242 [[]] .width = true := by decide
def e553831951898 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831951898 : Closed e553831951898 ∧ code e553831951898 = 2752855207450 := by decide
theorem cert_e553831951898 : check e553831951898 [[]] .width = true := by decide
def e553831953946 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e553831953946 : Closed e553831953946 ∧ code e553831953946 = 2752855209498 := by decide
theorem cert_e553831953946 : check e553831953946 [[]] .width = true := by decide
def e553831989274 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e553831989274 : Closed e553831989274 ∧ code e553831989274 = 2752855244826 := by decide
theorem cert_e553831989274 : check e553831989274 [[]] .width = true := by decide
def e553831989366 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e553831989366 : Closed e553831989366 ∧ code e553831989366 = 2752855244918 := by decide
theorem cert_e553831989366 : check e553831989366 [[]] .width = true := by decide
def e553831989610 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e553831989610 : Closed e553831989610 ∧ code e553831989610 = 2752855245162 := by decide
theorem cert_e553831989610 : check e553831989610 [[]] .width = true := by decide
def e553831989658 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e553831989658 : Closed e553831989658 ∧ code e553831989658 = 2752855245210 := by decide
theorem cert_e553831989658 : check e553831989658 [[]] .width = true := by decide
def e553831990666 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e553831990666 : Closed e553831990666 ∧ code e553831990666 = 2752855246218 := by decide
theorem cert_e553831990666 : check e553831990666 [[]] .width = true := by decide
def e553831990690 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e553831990690 : Closed e553831990690 ∧ code e553831990690 = 2752855246242 := by decide
theorem cert_e553831990690 : check e553831990690 [[]] .width = true := by decide
def e553831990798 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e553831990798 : Closed e553831990798 ∧ code e553831990798 = 2752855246350 := by decide
theorem cert_e553831990798 : check e553831990798 [[]] .width = true := by decide
def e553831990810 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e553831990810 : Closed e553831990810 ∧ code e553831990810 = 2752855246362 := by decide
theorem cert_e553831990810 : check e553831990810 [[]] .width = true := by decide
end Blc.Floor41
