import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605593430510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 2))))))))
theorem wire_e605593430510 : Closed e605593430510 ∧ code e605593430510 = 2804616686062 := by decide
theorem cert_e605593430510 : check e605593430510 [[],[]] .smaller = true := by decide
def e605593430518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e605593430518 : Closed e605593430518 ∧ code e605593430518 = 2804616686070 := by decide
theorem cert_e605593430518 : check e605593430518 [[],[]] .three = true := by decide
def e605593431262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e605593431262 : Closed e605593431262 ∧ code e605593431262 = 2804616686814 := by decide
theorem cert_e605593431262 : check e605593431262 [[],[]] .three = true := by decide
def e605593431278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e605593431278 : Closed e605593431278 ∧ code e605593431278 = 2804616686830 := by decide
theorem cert_e605593431278 : check e605593431278 [[],[]] .smaller = true := by decide
def e605593431286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e605593431286 : Closed e605593431286 ∧ code e605593431286 = 2804616686838 := by decide
theorem cert_e605593431286 : check e605593431286 [[],[]] .smaller = true := by decide
def e605593431290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e605593431290 : Closed e605593431290 ∧ code e605593431290 = 2804616686842 := by decide
theorem cert_e605593431290 : check e605593431290 [[],[]] .three = true := by decide
def e605593431566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 2)))))))))
theorem wire_e605593431566 : Closed e605593431566 ∧ code e605593431566 = 2804616687118 := by decide
theorem cert_e605593431566 : check e605593431566 [[],[]] .smaller = true := by decide
def e605593431578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605593431578 : Closed e605593431578 ∧ code e605593431578 = 2804616687130 := by decide
theorem cert_e605593431578 : check e605593431578 [[],[]] .smaller = true := by decide
def e605593431650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605593431650 : Closed e605593431650 ∧ code e605593431650 = 2804616687202 := by decide
theorem cert_e605593431650 : check e605593431650 [[],[]] .smaller = true := by decide
def e605593431662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593431662 : Closed e605593431662 ∧ code e605593431662 = 2804616687214 := by decide
theorem cert_e605593431662 : check e605593431662 [[],[]] .smaller = true := by decide
def e605593431670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e605593431670 : Closed e605593431670 ∧ code e605593431670 = 2804616687222 := by decide
theorem cert_e605593431670 : check e605593431670 [[],[]] .smaller = true := by decide
def e605593431674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593431674 : Closed e605593431674 ∧ code e605593431674 = 2804616687226 := by decide
theorem cert_e605593431674 : check e605593431674 [[],[]] .smaller = true := by decide
def e605593431862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593431862 : Closed e605593431862 ∧ code e605593431862 = 2804616687414 := by decide
theorem cert_e605593431862 : check e605593431862 [[],[]] .three = true := by decide
def e605593431866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593431866 : Closed e605593431866 ∧ code e605593431866 = 2804616687418 := by decide
theorem cert_e605593431866 : check e605593431866 [[],[]] .three = true := by decide
def e605593432926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e605593432926 : Closed e605593432926 ∧ code e605593432926 = 2804616688478 := by decide
theorem cert_e605593432926 : check e605593432926 [[],[]] .three = true := by decide
def e605593432942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e605593432942 : Closed e605593432942 ∧ code e605593432942 = 2804616688494 := by decide
theorem cert_e605593432942 : check e605593432942 [[],[]] .smaller = true := by decide
def e605593432950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e605593432950 : Closed e605593432950 ∧ code e605593432950 = 2804616688502 := by decide
theorem cert_e605593432950 : check e605593432950 [[],[]] .smaller = true := by decide
def e605593432954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e605593432954 : Closed e605593432954 ∧ code e605593432954 = 2804616688506 := by decide
theorem cert_e605593432954 : check e605593432954 [[],[]] .three = true := by decide
def e605593433006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e605593433006 : Closed e605593433006 ∧ code e605593433006 = 2804616688558 := by decide
theorem cert_e605593433006 : check e605593433006 [[],[]] .smaller = true := by decide
def e605593433018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e605593433018 : Closed e605593433018 ∧ code e605593433018 = 2804616688570 := by decide
theorem cert_e605593433018 : check e605593433018 [[],[]] .smaller = true := by decide
def e605593433046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e605593433046 : Closed e605593433046 ∧ code e605593433046 = 2804616688598 := by decide
theorem cert_e605593433046 : check e605593433046 [[],[]] .smaller = true := by decide
def e605593433050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e605593433050 : Closed e605593433050 ∧ code e605593433050 = 2804616688602 := by decide
theorem cert_e605593433050 : check e605593433050 [[],[]] .smaller = true := by decide
def e605593433066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e605593433066 : Closed e605593433066 ∧ code e605593433066 = 2804616688618 := by decide
theorem cert_e605593433066 : check e605593433066 [[],[]] .three = true := by decide
def e605593433310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e605593433310 : Closed e605593433310 ∧ code e605593433310 = 2804616688862 := by decide
theorem cert_e605593433310 : check e605593433310 [[],[]] .three = true := by decide
def e605593433326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e605593433326 : Closed e605593433326 ∧ code e605593433326 = 2804616688878 := by decide
theorem cert_e605593433326 : check e605593433326 [[],[]] .smaller = true := by decide
def e605593433334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e605593433334 : Closed e605593433334 ∧ code e605593433334 = 2804616688886 := by decide
theorem cert_e605593433334 : check e605593433334 [[],[]] .smaller = true := by decide
def e605593433338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e605593433338 : Closed e605593433338 ∧ code e605593433338 = 2804616688890 := by decide
theorem cert_e605593433338 : check e605593433338 [[],[]] .three = true := by decide
def e605593433710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593433710 : Closed e605593433710 ∧ code e605593433710 = 2804616689262 := by decide
theorem cert_e605593433710 : check e605593433710 [[],[]] .smaller = true := by decide
def e605593433722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593433722 : Closed e605593433722 ∧ code e605593433722 = 2804616689274 := by decide
theorem cert_e605593433722 : check e605593433722 [[],[]] .smaller = true := by decide
def e605593433910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593433910 : Closed e605593433910 ∧ code e605593433910 = 2804616689462 := by decide
theorem cert_e605593433910 : check e605593433910 [[],[]] .smaller = true := by decide
def e605593433914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593433914 : Closed e605593433914 ∧ code e605593433914 = 2804616689466 := by decide
theorem cert_e605593433914 : check e605593433914 [[],[]] .smaller = true := by decide
def e605593434010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593434010 : Closed e605593434010 ∧ code e605593434010 = 2804616689562 := by decide
theorem cert_e605593434010 : check e605593434010 [[],[]] .three = true := by decide
def e605593434170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 0)))))))
theorem wire_e605593434170 : Closed e605593434170 ∧ code e605593434170 = 2804616689722 := by decide
theorem cert_e605593434170 : check e605593434170 [[],[]] .smaller = true := by decide
def e605593434218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e605593434218 : Closed e605593434218 ∧ code e605593434218 = 2804616689770 := by decide
theorem cert_e605593434218 : check e605593434218 [[],[]] .smaller = true := by decide
def e605593434266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593434266 : Closed e605593434266 ∧ code e605593434266 = 2804616689818 := by decide
theorem cert_e605593434266 : check e605593434266 [[],[]] .smaller = true := by decide
def e605593434310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 1))))))))
theorem wire_e605593434310 : Closed e605593434310 ∧ code e605593434310 = 2804616689862 := by decide
theorem cert_e605593434310 : check e605593434310 [[],[]] .smaller = true := by decide
def e605593434506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e605593434506 : Closed e605593434506 ∧ code e605593434506 = 2804616690058 := by decide
theorem cert_e605593434506 : check e605593434506 [[],[]] .smaller = true := by decide
def e605593434530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e605593434530 : Closed e605593434530 ∧ code e605593434530 = 2804616690082 := by decide
theorem cert_e605593434530 : check e605593434530 [[],[]] .smaller = true := by decide
def e605593434542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e605593434542 : Closed e605593434542 ∧ code e605593434542 = 2804616690094 := by decide
theorem cert_e605593434542 : check e605593434542 [[],[]] .smaller = true := by decide
def e605593434550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e605593434550 : Closed e605593434550 ∧ code e605593434550 = 2804616690102 := by decide
theorem cert_e605593434550 : check e605593434550 [[],[]] .smaller = true := by decide
def e605593434554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e605593434554 : Closed e605593434554 ∧ code e605593434554 = 2804616690106 := by decide
theorem cert_e605593434554 : check e605593434554 [[],[]] .smaller = true := by decide
def e605593434582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e605593434582 : Closed e605593434582 ∧ code e605593434582 = 2804616690134 := by decide
theorem cert_e605593434582 : check e605593434582 [[],[]] .smaller = true := by decide
def e605593434586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e605593434586 : Closed e605593434586 ∧ code e605593434586 = 2804616690138 := by decide
theorem cert_e605593434586 : check e605593434586 [[],[]] .smaller = true := by decide
def e605593434602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e605593434602 : Closed e605593434602 ∧ code e605593434602 = 2804616690154 := by decide
theorem cert_e605593434602 : check e605593434602 [[],[]] .smaller = true := by decide
def e605593434638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 2)))))))))
theorem wire_e605593434638 : Closed e605593434638 ∧ code e605593434638 = 2804616690190 := by decide
theorem cert_e605593434638 : check e605593434638 [[],[]] .smaller = true := by decide
def e605593434650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e605593434650 : Closed e605593434650 ∧ code e605593434650 = 2804616690202 := by decide
theorem cert_e605593434650 : check e605593434650 [[],[]] .smaller = true := by decide
def e605593434722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e605593434722 : Closed e605593434722 ∧ code e605593434722 = 2804616690274 := by decide
theorem cert_e605593434722 : check e605593434722 [[],[]] .smaller = true := by decide
def e605593434734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e605593434734 : Closed e605593434734 ∧ code e605593434734 = 2804616690286 := by decide
theorem cert_e605593434734 : check e605593434734 [[],[]] .smaller = true := by decide
def e605593434742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e605593434742 : Closed e605593434742 ∧ code e605593434742 = 2804616690294 := by decide
theorem cert_e605593434742 : check e605593434742 [[],[]] .smaller = true := by decide
def e605593434746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e605593434746 : Closed e605593434746 ∧ code e605593434746 = 2804616690298 := by decide
theorem cert_e605593434746 : check e605593434746 [[],[]] .smaller = true := by decide
def e605593434934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593434934 : Closed e605593434934 ∧ code e605593434934 = 2804616690486 := by decide
theorem cert_e605593434934 : check e605593434934 [[],[]] .smaller = true := by decide
def e605593434938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593434938 : Closed e605593434938 ∧ code e605593434938 = 2804616690490 := by decide
theorem cert_e605593434938 : check e605593434938 [[],[]] .smaller = true := by decide
def e605593435034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593435034 : Closed e605593435034 ∧ code e605593435034 = 2804616690586 := by decide
theorem cert_e605593435034 : check e605593435034 [[],[]] .smaller = true := by decide
def e605593435102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 3)))))))
theorem wire_e605593435102 : Closed e605593435102 ∧ code e605593435102 = 2804616690654 := by decide
theorem cert_e605593435102 : check e605593435102 [[],[]] .three = true := by decide
def e605593435350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e605593435350 : Closed e605593435350 ∧ code e605593435350 = 2804616690902 := by decide
theorem cert_e605593435350 : check e605593435350 [[],[]] .three = true := by decide
def e605593435354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e605593435354 : Closed e605593435354 ∧ code e605593435354 = 2804616690906 := by decide
theorem cert_e605593435354 : check e605593435354 [[],[]] .three = true := by decide
def e605593435370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e605593435370 : Closed e605593435370 ∧ code e605593435370 = 2804616690922 := by decide
theorem cert_e605593435370 : check e605593435370 [[],[]] .three = true := by decide
def e605593435446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593435446 : Closed e605593435446 ∧ code e605593435446 = 2804616690998 := by decide
theorem cert_e605593435446 : check e605593435446 [[],[]] .three = true := by decide
def e605593435450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593435450 : Closed e605593435450 ∧ code e605593435450 = 2804616691002 := by decide
theorem cert_e605593435450 : check e605593435450 [[],[]] .three = true := by decide
def e605593435546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593435546 : Closed e605593435546 ∧ code e605593435546 = 2804616691098 := by decide
theorem cert_e605593435546 : check e605593435546 [[],[]] .three = true := by decide
def e605593435614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 3)))))))
theorem wire_e605593435614 : Closed e605593435614 ∧ code e605593435614 = 2804616691166 := by decide
theorem cert_e605593435614 : check e605593435614 [[],[]] .three = true := by decide
def e605593435630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 3))) (.var 2)))))))
theorem wire_e605593435630 : Closed e605593435630 ∧ code e605593435630 = 2804616691182 := by decide
theorem cert_e605593435630 : check e605593435630 [[],[]] .three = true := by decide
def e605593438142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 4)))))))))
theorem wire_e605593438142 : Closed e605593438142 ∧ code e605593438142 = 2804616693694 := by decide
theorem cert_e605593438142 : check e605593438142 [[],[]] .three = true := by decide
def e605593438174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e605593438174 : Closed e605593438174 ∧ code e605593438174 = 2804616693726 := by decide
theorem cert_e605593438174 : check e605593438174 [[],[]] .smaller = true := by decide
def e605593438190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 4) (.var 2)))))))))
theorem wire_e605593438190 : Closed e605593438190 ∧ code e605593438190 = 2804616693742 := by decide
theorem cert_e605593438190 : check e605593438190 [[],[]] .three = true := by decide
def e605593441838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e605593441838 : Closed e605593441838 ∧ code e605593441838 = 2804616697390 := by decide
theorem cert_e605593441838 : check e605593441838 [[],[]] .smaller = true := by decide
def e605593442014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e605593442014 : Closed e605593442014 ∧ code e605593442014 = 2804616697566 := by decide
theorem cert_e605593442014 : check e605593442014 [[],[]] .three = true := by decide
def e605593442018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e605593442018 : Closed e605593442018 ∧ code e605593442018 = 2804616697570 := by decide
theorem cert_e605593442018 : check e605593442018 [[],[]] .smaller = true := by decide
def e605593442030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e605593442030 : Closed e605593442030 ∧ code e605593442030 = 2804616697582 := by decide
theorem cert_e605593442030 : check e605593442030 [[],[]] .smaller = true := by decide
def e605593442038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e605593442038 : Closed e605593442038 ∧ code e605593442038 = 2804616697590 := by decide
theorem cert_e605593442038 : check e605593442038 [[],[]] .three = true := by decide
def e605593442142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e605593442142 : Closed e605593442142 ∧ code e605593442142 = 2804616697694 := by decide
theorem cert_e605593442142 : check e605593442142 [[],[]] .three = true := by decide
def e605593442158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e605593442158 : Closed e605593442158 ∧ code e605593442158 = 2804616697710 := by decide
theorem cert_e605593442158 : check e605593442158 [[],[]] .smaller = true := by decide
def e605593442166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e605593442166 : Closed e605593442166 ∧ code e605593442166 = 2804616697718 := by decide
theorem cert_e605593442166 : check e605593442166 [[],[]] .smaller = true := by decide
def e605593442170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e605593442170 : Closed e605593442170 ∧ code e605593442170 = 2804616697722 := by decide
theorem cert_e605593442170 : check e605593442170 [[],[]] .three = true := by decide
def e605593442186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605593442186 : Closed e605593442186 ∧ code e605593442186 = 2804616697738 := by decide
theorem cert_e605593442186 : check e605593442186 [[],[]] .smaller = true := by decide
def e605593442210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605593442210 : Closed e605593442210 ∧ code e605593442210 = 2804616697762 := by decide
theorem cert_e605593442210 : check e605593442210 [[],[]] .smaller = true := by decide
def e605593442222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e605593442222 : Closed e605593442222 ∧ code e605593442222 = 2804616697774 := by decide
theorem cert_e605593442222 : check e605593442222 [[],[]] .smaller = true := by decide
def e605593442230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e605593442230 : Closed e605593442230 ∧ code e605593442230 = 2804616697782 := by decide
theorem cert_e605593442230 : check e605593442230 [[],[]] .smaller = true := by decide
def e605593442234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e605593442234 : Closed e605593442234 ∧ code e605593442234 = 2804616697786 := by decide
theorem cert_e605593442234 : check e605593442234 [[],[]] .smaller = true := by decide
def e605593442262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e605593442262 : Closed e605593442262 ∧ code e605593442262 = 2804616697814 := by decide
theorem cert_e605593442262 : check e605593442262 [[],[]] .three = true := by decide
def e605593442266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e605593442266 : Closed e605593442266 ∧ code e605593442266 = 2804616697818 := by decide
theorem cert_e605593442266 : check e605593442266 [[],[]] .three = true := by decide
def e605593442366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e605593442366 : Closed e605593442366 ∧ code e605593442366 = 2804616697918 := by decide
theorem cert_e605593442366 : check e605593442366 [[],[]] .smaller = true := by decide
def e605593442782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e605593442782 : Closed e605593442782 ∧ code e605593442782 = 2804616698334 := by decide
theorem cert_e605593442782 : check e605593442782 [[],[]] .three = true := by decide
def e605593442786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e605593442786 : Closed e605593442786 ∧ code e605593442786 = 2804616698338 := by decide
theorem cert_e605593442786 : check e605593442786 [[],[]] .smaller = true := by decide
def e605593442798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e605593442798 : Closed e605593442798 ∧ code e605593442798 = 2804616698350 := by decide
theorem cert_e605593442798 : check e605593442798 [[],[]] .smaller = true := by decide
def e605593442806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e605593442806 : Closed e605593442806 ∧ code e605593442806 = 2804616698358 := by decide
theorem cert_e605593442806 : check e605593442806 [[],[]] .three = true := by decide
def e605593443550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e605593443550 : Closed e605593443550 ∧ code e605593443550 = 2804616699102 := by decide
theorem cert_e605593443550 : check e605593443550 [[],[]] .three = true := by decide
def e605593443566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e605593443566 : Closed e605593443566 ∧ code e605593443566 = 2804616699118 := by decide
theorem cert_e605593443566 : check e605593443566 [[],[]] .smaller = true := by decide
def e605593443574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e605593443574 : Closed e605593443574 ∧ code e605593443574 = 2804616699126 := by decide
theorem cert_e605593443574 : check e605593443574 [[],[]] .smaller = true := by decide
def e605593443578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e605593443578 : Closed e605593443578 ∧ code e605593443578 = 2804616699130 := by decide
theorem cert_e605593443578 : check e605593443578 [[],[]] .three = true := by decide
def e605593443854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e605593443854 : Closed e605593443854 ∧ code e605593443854 = 2804616699406 := by decide
theorem cert_e605593443854 : check e605593443854 [[],[]] .smaller = true := by decide
def e605593443866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605593443866 : Closed e605593443866 ∧ code e605593443866 = 2804616699418 := by decide
theorem cert_e605593443866 : check e605593443866 [[],[]] .smaller = true := by decide
def e605593443938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605593443938 : Closed e605593443938 ∧ code e605593443938 = 2804616699490 := by decide
theorem cert_e605593443938 : check e605593443938 [[],[]] .smaller = true := by decide
def e605593443950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593443950 : Closed e605593443950 ∧ code e605593443950 = 2804616699502 := by decide
theorem cert_e605593443950 : check e605593443950 [[],[]] .smaller = true := by decide
def e605593443958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e605593443958 : Closed e605593443958 ∧ code e605593443958 = 2804616699510 := by decide
theorem cert_e605593443958 : check e605593443958 [[],[]] .smaller = true := by decide
def e605593443962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593443962 : Closed e605593443962 ∧ code e605593443962 = 2804616699514 := by decide
theorem cert_e605593443962 : check e605593443962 [[],[]] .smaller = true := by decide
def e605593444150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593444150 : Closed e605593444150 ∧ code e605593444150 = 2804616699702 := by decide
theorem cert_e605593444150 : check e605593444150 [[],[]] .three = true := by decide
def e605593444154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593444154 : Closed e605593444154 ∧ code e605593444154 = 2804616699706 := by decide
theorem cert_e605593444154 : check e605593444154 [[],[]] .three = true := by decide
def e605593453502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 4)))))))))
theorem wire_e605593453502 : Closed e605593453502 ∧ code e605593453502 = 2804616709054 := by decide
theorem cert_e605593453502 : check e605593453502 [[],[]] .three = true := by decide
def e605593453558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 4) (.var 1)))))))))
theorem wire_e605593453558 : Closed e605593453558 ∧ code e605593453558 = 2804616709110 := by decide
theorem cert_e605593453558 : check e605593453558 [[],[]] .three = true := by decide
def e605593455454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e605593455454 : Closed e605593455454 ∧ code e605593455454 = 2804616711006 := by decide
theorem cert_e605593455454 : check e605593455454 [[],[]] .three = true := by decide
def e605593455470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605593455470 : Closed e605593455470 ∧ code e605593455470 = 2804616711022 := by decide
theorem cert_e605593455470 : check e605593455470 [[],[]] .smaller = true := by decide
def e605593455478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605593455478 : Closed e605593455478 ∧ code e605593455478 = 2804616711030 := by decide
theorem cert_e605593455478 : check e605593455478 [[],[]] .smaller = true := by decide
def e605593455482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e605593455482 : Closed e605593455482 ∧ code e605593455482 = 2804616711034 := by decide
theorem cert_e605593455482 : check e605593455482 [[],[]] .three = true := by decide
def e605593455534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605593455534 : Closed e605593455534 ∧ code e605593455534 = 2804616711086 := by decide
theorem cert_e605593455534 : check e605593455534 [[],[]] .smaller = true := by decide
def e605593455546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605593455546 : Closed e605593455546 ∧ code e605593455546 = 2804616711098 := by decide
theorem cert_e605593455546 : check e605593455546 [[],[]] .smaller = true := by decide
def e605593455574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605593455574 : Closed e605593455574 ∧ code e605593455574 = 2804616711126 := by decide
theorem cert_e605593455574 : check e605593455574 [[],[]] .smaller = true := by decide
def e605593455578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605593455578 : Closed e605593455578 ∧ code e605593455578 = 2804616711130 := by decide
theorem cert_e605593455578 : check e605593455578 [[],[]] .smaller = true := by decide
def e605593455594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e605593455594 : Closed e605593455594 ∧ code e605593455594 = 2804616711146 := by decide
theorem cert_e605593455594 : check e605593455594 [[],[]] .three = true := by decide
def e605593455838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e605593455838 : Closed e605593455838 ∧ code e605593455838 = 2804616711390 := by decide
theorem cert_e605593455838 : check e605593455838 [[],[]] .three = true := by decide
def e605593455854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605593455854 : Closed e605593455854 ∧ code e605593455854 = 2804616711406 := by decide
theorem cert_e605593455854 : check e605593455854 [[],[]] .smaller = true := by decide
def e605593455862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605593455862 : Closed e605593455862 ∧ code e605593455862 = 2804616711414 := by decide
theorem cert_e605593455862 : check e605593455862 [[],[]] .smaller = true := by decide
def e605593455866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e605593455866 : Closed e605593455866 ∧ code e605593455866 = 2804616711418 := by decide
theorem cert_e605593455866 : check e605593455866 [[],[]] .three = true := by decide
def e605593456238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593456238 : Closed e605593456238 ∧ code e605593456238 = 2804616711790 := by decide
theorem cert_e605593456238 : check e605593456238 [[],[]] .smaller = true := by decide
def e605593456250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593456250 : Closed e605593456250 ∧ code e605593456250 = 2804616711802 := by decide
theorem cert_e605593456250 : check e605593456250 [[],[]] .smaller = true := by decide
def e605593456438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593456438 : Closed e605593456438 ∧ code e605593456438 = 2804616711990 := by decide
theorem cert_e605593456438 : check e605593456438 [[],[]] .smaller = true := by decide
def e605593456442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593456442 : Closed e605593456442 ∧ code e605593456442 = 2804616711994 := by decide
theorem cert_e605593456442 : check e605593456442 [[],[]] .smaller = true := by decide
def e605593456538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593456538 : Closed e605593456538 ∧ code e605593456538 = 2804616712090 := by decide
theorem cert_e605593456538 : check e605593456538 [[],[]] .three = true := by decide
def e605593461214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e605593461214 : Closed e605593461214 ∧ code e605593461214 = 2804616716766 := by decide
theorem cert_e605593461214 : check e605593461214 [[],[]] .smaller = true := by decide
def e605593461238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e605593461238 : Closed e605593461238 ∧ code e605593461238 = 2804616716790 := by decide
theorem cert_e605593461238 : check e605593461238 [[],[]] .smaller = true := by decide
def e605593462154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e605593462154 : Closed e605593462154 ∧ code e605593462154 = 2804616717706 := by decide
theorem cert_e605593462154 : check e605593462154 [[],[]] .smaller = true := by decide
def e605593462178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e605593462178 : Closed e605593462178 ∧ code e605593462178 = 2804616717730 := by decide
theorem cert_e605593462178 : check e605593462178 [[],[]] .smaller = true := by decide
def e605593462190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e605593462190 : Closed e605593462190 ∧ code e605593462190 = 2804616717742 := by decide
theorem cert_e605593462190 : check e605593462190 [[],[]] .smaller = true := by decide
def e605593462198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e605593462198 : Closed e605593462198 ∧ code e605593462198 = 2804616717750 := by decide
theorem cert_e605593462198 : check e605593462198 [[],[]] .smaller = true := by decide
def e605593462202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e605593462202 : Closed e605593462202 ∧ code e605593462202 = 2804616717754 := by decide
theorem cert_e605593462202 : check e605593462202 [[],[]] .smaller = true := by decide
def e605593462230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e605593462230 : Closed e605593462230 ∧ code e605593462230 = 2804616717782 := by decide
theorem cert_e605593462230 : check e605593462230 [[],[]] .smaller = true := by decide
def e605593462234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e605593462234 : Closed e605593462234 ∧ code e605593462234 = 2804616717786 := by decide
theorem cert_e605593462234 : check e605593462234 [[],[]] .smaller = true := by decide
def e605593462250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e605593462250 : Closed e605593462250 ∧ code e605593462250 = 2804616717802 := by decide
theorem cert_e605593462250 : check e605593462250 [[],[]] .smaller = true := by decide
def e605593462286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e605593462286 : Closed e605593462286 ∧ code e605593462286 = 2804616717838 := by decide
theorem cert_e605593462286 : check e605593462286 [[],[]] .smaller = true := by decide
def e605593462298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e605593462298 : Closed e605593462298 ∧ code e605593462298 = 2804616717850 := by decide
theorem cert_e605593462298 : check e605593462298 [[],[]] .smaller = true := by decide
def e605593462370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e605593462370 : Closed e605593462370 ∧ code e605593462370 = 2804616717922 := by decide
theorem cert_e605593462370 : check e605593462370 [[],[]] .smaller = true := by decide
def e605593462382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e605593462382 : Closed e605593462382 ∧ code e605593462382 = 2804616717934 := by decide
theorem cert_e605593462382 : check e605593462382 [[],[]] .smaller = true := by decide
def e605593462390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e605593462390 : Closed e605593462390 ∧ code e605593462390 = 2804616717942 := by decide
theorem cert_e605593462390 : check e605593462390 [[],[]] .smaller = true := by decide
def e605593462394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e605593462394 : Closed e605593462394 ∧ code e605593462394 = 2804616717946 := by decide
theorem cert_e605593462394 : check e605593462394 [[],[]] .smaller = true := by decide
def e605593462582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593462582 : Closed e605593462582 ∧ code e605593462582 = 2804616718134 := by decide
theorem cert_e605593462582 : check e605593462582 [[],[]] .smaller = true := by decide
def e605593462586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593462586 : Closed e605593462586 ∧ code e605593462586 = 2804616718138 := by decide
theorem cert_e605593462586 : check e605593462586 [[],[]] .smaller = true := by decide
def e605593462682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593462682 : Closed e605593462682 ∧ code e605593462682 = 2804616718234 := by decide
theorem cert_e605593462682 : check e605593462682 [[],[]] .smaller = true := by decide
def e605593462750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 3))))))))
theorem wire_e605593462750 : Closed e605593462750 ∧ code e605593462750 = 2804616718302 := by decide
theorem cert_e605593462750 : check e605593462750 [[],[]] .three = true := by decide
def e605593465070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e605593465070 : Closed e605593465070 ∧ code e605593465070 = 2804616720622 := by decide
theorem cert_e605593465070 : check e605593465070 [[],[]] .three = true := by decide
def e605593465078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e605593465078 : Closed e605593465078 ∧ code e605593465078 = 2804616720630 := by decide
theorem cert_e605593465078 : check e605593465078 [[],[]] .three = true := by decide
def e605593465558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e605593465558 : Closed e605593465558 ∧ code e605593465558 = 2804616721110 := by decide
theorem cert_e605593465558 : check e605593465558 [[],[]] .three = true := by decide
def e605593465562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e605593465562 : Closed e605593465562 ∧ code e605593465562 = 2804616721114 := by decide
theorem cert_e605593465562 : check e605593465562 [[],[]] .three = true := by decide
def e605593465578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e605593465578 : Closed e605593465578 ∧ code e605593465578 = 2804616721130 := by decide
theorem cert_e605593465578 : check e605593465578 [[],[]] .three = true := by decide
def e605593465654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e605593465654 : Closed e605593465654 ∧ code e605593465654 = 2804616721206 := by decide
theorem cert_e605593465654 : check e605593465654 [[],[]] .three = true := by decide
def e605593465658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e605593465658 : Closed e605593465658 ∧ code e605593465658 = 2804616721210 := by decide
theorem cert_e605593465658 : check e605593465658 [[],[]] .three = true := by decide
def e605593465754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e605593465754 : Closed e605593465754 ∧ code e605593465754 = 2804616721306 := by decide
theorem cert_e605593465754 : check e605593465754 [[],[]] .three = true := by decide
def e605593465822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 3))))))))
theorem wire_e605593465822 : Closed e605593465822 ∧ code e605593465822 = 2804616721374 := by decide
theorem cert_e605593465822 : check e605593465822 [[],[]] .three = true := by decide
def e605593465838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 3) (.var 2))))))))
theorem wire_e605593465838 : Closed e605593465838 ∧ code e605593465838 = 2804616721390 := by decide
theorem cert_e605593465838 : check e605593465838 [[],[]] .three = true := by decide
def e605593470774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593470774 : Closed e605593470774 ∧ code e605593470774 = 2804616726326 := by decide
theorem cert_e605593470774 : check e605593470774 [[],[]] .smaller = true := by decide
def e605593470778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593470778 : Closed e605593470778 ∧ code e605593470778 = 2804616726330 := by decide
theorem cert_e605593470778 : check e605593470778 [[],[]] .smaller = true := by decide
def e605593470874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 0))))))))
theorem wire_e605593470874 : Closed e605593470874 ∧ code e605593470874 = 2804616726426 := by decide
theorem cert_e605593470874 : check e605593470874 [[],[]] .smaller = true := by decide
def e605593472310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e605593472310 : Closed e605593472310 ∧ code e605593472310 = 2804616727862 := by decide
theorem cert_e605593472310 : check e605593472310 [[],[]] .smaller = true := by decide
def e605593472314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e605593472314 : Closed e605593472314 ∧ code e605593472314 = 2804616727866 := by decide
theorem cert_e605593472314 : check e605593472314 [[],[]] .smaller = true := by decide
def e605593472734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 3)))))))
theorem wire_e605593472734 : Closed e605593472734 ∧ code e605593472734 = 2804616728286 := by decide
theorem cert_e605593472734 : check e605593472734 [[],[]] .three = true := by decide
def e605593472750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e605593472750 : Closed e605593472750 ∧ code e605593472750 = 2804616728302 := by decide
theorem cert_e605593472750 : check e605593472750 [[],[]] .smaller = true := by decide
def e605593472758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e605593472758 : Closed e605593472758 ∧ code e605593472758 = 2804616728310 := by decide
theorem cert_e605593472758 : check e605593472758 [[],[]] .smaller = true := by decide
def e605593472762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 4)))) (.var 0)))))))
theorem wire_e605593472762 : Closed e605593472762 ∧ code e605593472762 = 2804616728314 := by decide
theorem cert_e605593472762 : check e605593472762 [[],[]] .three = true := by decide
def e605593472878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e605593472878 : Closed e605593472878 ∧ code e605593472878 = 2804616728430 := by decide
theorem cert_e605593472878 : check e605593472878 [[],[]] .smaller = true := by decide
def e605593472890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e605593472890 : Closed e605593472890 ∧ code e605593472890 = 2804616728442 := by decide
theorem cert_e605593472890 : check e605593472890 [[],[]] .smaller = true := by decide
def e605593472950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e605593472950 : Closed e605593472950 ∧ code e605593472950 = 2804616728502 := by decide
theorem cert_e605593472950 : check e605593472950 [[],[]] .smaller = true := by decide
end Blc.Floor41
