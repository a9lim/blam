import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598090162202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598090162202 : Closed e598090162202 ∧ code e598090162202 = 2797113417754 := by decide
theorem cert_e598090162202 : check e598090162202 [[]] .width = true := by decide
def e598090162294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e598090162294 : Closed e598090162294 ∧ code e598090162294 = 2797113417846 := by decide
private def t_e598090162294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e598090162294 : ¬ IsSelfInterpreter e598090162294 :=
  wSource (t := t_e598090162294) (replay_sound (ps := []) (t := e598090162294) (by decide)) (by decide)
def e598090162538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e598090162538 : Closed e598090162538 ∧ code e598090162538 = 2797113418090 := by decide
private def t_e598090162538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e598090162538 : ¬ IsSelfInterpreter e598090162538 :=
  wSource (t := t_e598090162538) (replay_sound (ps := []) (t := e598090162538) (by decide)) (by decide)
def e598090162586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e598090162586 : Closed e598090162586 ∧ code e598090162586 = 2797113418138 := by decide
private def t_e598090162586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e598090162586 : ¬ IsSelfInterpreter e598090162586 :=
  wSource (t := t_e598090162586) (replay_sound (ps := []) (t := e598090162586) (by decide)) (by decide)
def e598091017582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e598091017582 : Closed e598091017582 ∧ code e598091017582 = 2797114273134 := by decide
theorem cert_e598091017582 : check e598091017582 [[],[.left]] .chain = true := by decide
def e598091017590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e598091017590 : Closed e598091017590 ∧ code e598091017590 = 2797114273142 := by decide
theorem cert_e598091017590 : check e598091017590 [[],[.left]] .chain = true := by decide
def e598091017646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e598091017646 : Closed e598091017646 ∧ code e598091017646 = 2797114273198 := by decide
theorem cert_e598091017646 : check e598091017646 [[],[.left]] .chain = true := by decide
def e598091017658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e598091017658 : Closed e598091017658 ∧ code e598091017658 = 2797114273210 := by decide
theorem cert_e598091017658 : check e598091017658 [[],[.left]] .chain = true := by decide
def e598091017686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e598091017686 : Closed e598091017686 ∧ code e598091017686 = 2797114273238 := by decide
theorem cert_e598091017686 : check e598091017686 [[],[.left]] .chain = true := by decide
def e598091017690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e598091017690 : Closed e598091017690 ∧ code e598091017690 = 2797114273242 := by decide
theorem cert_e598091017690 : check e598091017690 [[],[.left]] .chain = true := by decide
def e598091017902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e598091017902 : Closed e598091017902 ∧ code e598091017902 = 2797114273454 := by decide
theorem cert_e598091017902 : check e598091017902 [[],[.left]] .chain = true := by decide
def e598091017914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e598091017914 : Closed e598091017914 ∧ code e598091017914 = 2797114273466 := by decide
theorem cert_e598091017914 : check e598091017914 [[],[.left]] .chain = true := by decide
def e598091017962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e598091017962 : Closed e598091017962 ∧ code e598091017962 = 2797114273514 := by decide
theorem cert_e598091017962 : check e598091017962 [[],[.left]] .chain = true := by decide
def e598091018070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e598091018070 : Closed e598091018070 ∧ code e598091018070 = 2797114273622 := by decide
theorem cert_e598091018070 : check e598091018070 [[],[.left]] .chain = true := by decide
def e598091018074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e598091018074 : Closed e598091018074 ∧ code e598091018074 = 2797114273626 := by decide
theorem cert_e598091018074 : check e598091018074 [[],[.left]] .chain = true := by decide
def e598091018090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e598091018090 : Closed e598091018090 ∧ code e598091018090 = 2797114273642 := by decide
theorem cert_e598091018090 : check e598091018090 [[],[.left]] .chain = true := by decide
def e598091019118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e598091019118 : Closed e598091019118 ∧ code e598091019118 = 2797114274670 := by decide
theorem cert_e598091019118 : check e598091019118 [[],[.left]] .chain = true := by decide
def e598091019126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e598091019126 : Closed e598091019126 ∧ code e598091019126 = 2797114274678 := by decide
theorem cert_e598091019126 : check e598091019126 [[],[.left]] .chain = true := by decide
def e598091019182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e598091019182 : Closed e598091019182 ∧ code e598091019182 = 2797114274734 := by decide
theorem cert_e598091019182 : check e598091019182 [[],[.left]] .chain = true := by decide
def e598091019194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e598091019194 : Closed e598091019194 ∧ code e598091019194 = 2797114274746 := by decide
theorem cert_e598091019194 : check e598091019194 [[],[.left]] .chain = true := by decide
def e598091019222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e598091019222 : Closed e598091019222 ∧ code e598091019222 = 2797114274774 := by decide
theorem cert_e598091019222 : check e598091019222 [[],[.left]] .chain = true := by decide
def e598091019226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e598091019226 : Closed e598091019226 ∧ code e598091019226 = 2797114274778 := by decide
theorem cert_e598091019226 : check e598091019226 [[],[.left]] .chain = true := by decide
def e598091019502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e598091019502 : Closed e598091019502 ∧ code e598091019502 = 2797114275054 := by decide
theorem cert_e598091019502 : check e598091019502 [[],[.left]] .chain = true := by decide
def e598091019510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e598091019510 : Closed e598091019510 ∧ code e598091019510 = 2797114275062 := by decide
theorem cert_e598091019510 : check e598091019510 [[],[.left]] .chain = true := by decide
def e598091019886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e598091019886 : Closed e598091019886 ∧ code e598091019886 = 2797114275438 := by decide
theorem cert_e598091019886 : check e598091019886 [[],[.left]] .chain = true := by decide
def e598091019898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e598091019898 : Closed e598091019898 ∧ code e598091019898 = 2797114275450 := by decide
theorem cert_e598091019898 : check e598091019898 [[],[.left]] .chain = true := by decide
def e598091020086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e598091020086 : Closed e598091020086 ∧ code e598091020086 = 2797114275638 := by decide
theorem cert_e598091020086 : check e598091020086 [[],[.left]] .chain = true := by decide
def e598091020090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e598091020090 : Closed e598091020090 ∧ code e598091020090 = 2797114275642 := by decide
theorem cert_e598091020090 : check e598091020090 [[],[.left]] .chain = true := by decide
def e598091020718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e598091020718 : Closed e598091020718 ∧ code e598091020718 = 2797114276270 := by decide
theorem cert_e598091020718 : check e598091020718 [[],[.left]] .chain = true := by decide
def e598091020730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e598091020730 : Closed e598091020730 ∧ code e598091020730 = 2797114276282 := by decide
theorem cert_e598091020730 : check e598091020730 [[],[.left]] .chain = true := by decide
def e598091020778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e598091020778 : Closed e598091020778 ∧ code e598091020778 = 2797114276330 := by decide
theorem cert_e598091020778 : check e598091020778 [[],[.left]] .chain = true := by decide
def e598091020910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e598091020910 : Closed e598091020910 ∧ code e598091020910 = 2797114276462 := by decide
theorem cert_e598091020910 : check e598091020910 [[],[.left]] .chain = true := by decide
def e598091020922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e598091020922 : Closed e598091020922 ∧ code e598091020922 = 2797114276474 := by decide
theorem cert_e598091020922 : check e598091020922 [[],[.left]] .chain = true := by decide
def e598091021210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e598091021210 : Closed e598091021210 ∧ code e598091021210 = 2797114276762 := by decide
theorem cert_e598091021210 : check e598091021210 [[],[.left]] .chain = true := by decide
def e598091021526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e598091021526 : Closed e598091021526 ∧ code e598091021526 = 2797114277078 := by decide
theorem cert_e598091021526 : check e598091021526 [[],[.left]] .chain = true := by decide
def e598091021530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e598091021530 : Closed e598091021530 ∧ code e598091021530 = 2797114277082 := by decide
theorem cert_e598091021530 : check e598091021530 [[],[.left]] .chain = true := by decide
def e598091021546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e598091021546 : Closed e598091021546 ∧ code e598091021546 = 2797114277098 := by decide
theorem cert_e598091021546 : check e598091021546 [[],[.left]] .chain = true := by decide
def e598091021622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e598091021622 : Closed e598091021622 ∧ code e598091021622 = 2797114277174 := by decide
theorem cert_e598091021622 : check e598091021622 [[],[.left]] .chain = true := by decide
def e598091021626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e598091021626 : Closed e598091021626 ∧ code e598091021626 = 2797114277178 := by decide
theorem cert_e598091021626 : check e598091021626 [[],[.left]] .chain = true := by decide
def e598091021722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e598091021722 : Closed e598091021722 ∧ code e598091021722 = 2797114277274 := by decide
theorem cert_e598091021722 : check e598091021722 [[],[.left]] .chain = true := by decide
def e598091025262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e598091025262 : Closed e598091025262 ∧ code e598091025262 = 2797114280814 := by decide
theorem cert_e598091025262 : check e598091025262 [[],[.left]] .chain = true := by decide
def e598091025270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e598091025270 : Closed e598091025270 ∧ code e598091025270 = 2797114280822 := by decide
theorem cert_e598091025270 : check e598091025270 [[],[.left]] .chain = true := by decide
def e598091025326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e598091025326 : Closed e598091025326 ∧ code e598091025326 = 2797114280878 := by decide
theorem cert_e598091025326 : check e598091025326 [[],[.left]] .chain = true := by decide
def e598091025338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e598091025338 : Closed e598091025338 ∧ code e598091025338 = 2797114280890 := by decide
theorem cert_e598091025338 : check e598091025338 [[],[.left]] .chain = true := by decide
def e598091025366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e598091025366 : Closed e598091025366 ∧ code e598091025366 = 2797114280918 := by decide
theorem cert_e598091025366 : check e598091025366 [[],[.left]] .chain = true := by decide
def e598091025370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e598091025370 : Closed e598091025370 ∧ code e598091025370 = 2797114280922 := by decide
theorem cert_e598091025370 : check e598091025370 [[],[.left]] .chain = true := by decide
def e598091025646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e598091025646 : Closed e598091025646 ∧ code e598091025646 = 2797114281198 := by decide
theorem cert_e598091025646 : check e598091025646 [[],[.left]] .chain = true := by decide
def e598091025654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e598091025654 : Closed e598091025654 ∧ code e598091025654 = 2797114281206 := by decide
theorem cert_e598091025654 : check e598091025654 [[],[.left]] .chain = true := by decide
def e598091026030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e598091026030 : Closed e598091026030 ∧ code e598091026030 = 2797114281582 := by decide
theorem cert_e598091026030 : check e598091026030 [[],[.left]] .chain = true := by decide
def e598091026042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e598091026042 : Closed e598091026042 ∧ code e598091026042 = 2797114281594 := by decide
theorem cert_e598091026042 : check e598091026042 [[],[.left]] .chain = true := by decide
def e598091026230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e598091026230 : Closed e598091026230 ∧ code e598091026230 = 2797114281782 := by decide
theorem cert_e598091026230 : check e598091026230 [[],[.left]] .chain = true := by decide
def e598091026234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e598091026234 : Closed e598091026234 ∧ code e598091026234 = 2797114281786 := by decide
theorem cert_e598091026234 : check e598091026234 [[],[.left]] .chain = true := by decide
def e598091031982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e598091031982 : Closed e598091031982 ∧ code e598091031982 = 2797114287534 := by decide
theorem cert_e598091031982 : check e598091031982 [[],[.left]] .chain = true := by decide
def e598091031994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e598091031994 : Closed e598091031994 ∧ code e598091031994 = 2797114287546 := by decide
theorem cert_e598091031994 : check e598091031994 [[],[.left]] .chain = true := by decide
def e598091032042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e598091032042 : Closed e598091032042 ∧ code e598091032042 = 2797114287594 := by decide
theorem cert_e598091032042 : check e598091032042 [[],[.left]] .chain = true := by decide
def e598091032174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e598091032174 : Closed e598091032174 ∧ code e598091032174 = 2797114287726 := by decide
theorem cert_e598091032174 : check e598091032174 [[],[.left]] .chain = true := by decide
def e598091032186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e598091032186 : Closed e598091032186 ∧ code e598091032186 = 2797114287738 := by decide
theorem cert_e598091032186 : check e598091032186 [[],[.left]] .chain = true := by decide
def e598091032474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e598091032474 : Closed e598091032474 ∧ code e598091032474 = 2797114288026 := by decide
theorem cert_e598091032474 : check e598091032474 [[],[.left]] .chain = true := by decide
def e598091035350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e598091035350 : Closed e598091035350 ∧ code e598091035350 = 2797114290902 := by decide
theorem cert_e598091035350 : check e598091035350 [[],[.left]] .chain = true := by decide
def e598091035354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e598091035354 : Closed e598091035354 ∧ code e598091035354 = 2797114290906 := by decide
theorem cert_e598091035354 : check e598091035354 [[],[.left]] .chain = true := by decide
def e598091035370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e598091035370 : Closed e598091035370 ∧ code e598091035370 = 2797114290922 := by decide
theorem cert_e598091035370 : check e598091035370 [[],[.left]] .chain = true := by decide
def e598091035446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e598091035446 : Closed e598091035446 ∧ code e598091035446 = 2797114290998 := by decide
theorem cert_e598091035446 : check e598091035446 [[],[.left]] .chain = true := by decide
def e598091035450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e598091035450 : Closed e598091035450 ∧ code e598091035450 = 2797114291002 := by decide
theorem cert_e598091035450 : check e598091035450 [[],[.left]] .chain = true := by decide
def e598091035546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e598091035546 : Closed e598091035546 ∧ code e598091035546 = 2797114291098 := by decide
theorem cert_e598091035546 : check e598091035546 [[],[.left]] .chain = true := by decide
def e598091172718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e598091172718 : Closed e598091172718 ∧ code e598091172718 = 2797114428270 := by decide
theorem cert_e598091172718 : check e598091172718 [[],[.left]] .chain = true := by decide
def e598091172726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e598091172726 : Closed e598091172726 ∧ code e598091172726 = 2797114428278 := by decide
theorem cert_e598091172726 : check e598091172726 [[],[.left]] .chain = true := by decide
def e598091172782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e598091172782 : Closed e598091172782 ∧ code e598091172782 = 2797114428334 := by decide
theorem cert_e598091172782 : check e598091172782 [[],[.left]] .chain = true := by decide
def e598091172794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e598091172794 : Closed e598091172794 ∧ code e598091172794 = 2797114428346 := by decide
theorem cert_e598091172794 : check e598091172794 [[],[.left]] .chain = true := by decide
def e598091172822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e598091172822 : Closed e598091172822 ∧ code e598091172822 = 2797114428374 := by decide
theorem cert_e598091172822 : check e598091172822 [[],[.left]] .chain = true := by decide
def e598091172826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e598091172826 : Closed e598091172826 ∧ code e598091172826 = 2797114428378 := by decide
theorem cert_e598091172826 : check e598091172826 [[],[.left]] .chain = true := by decide
def e598091173102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e598091173102 : Closed e598091173102 ∧ code e598091173102 = 2797114428654 := by decide
theorem cert_e598091173102 : check e598091173102 [[],[.left]] .chain = true := by decide
def e598091173110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e598091173110 : Closed e598091173110 ∧ code e598091173110 = 2797114428662 := by decide
theorem cert_e598091173110 : check e598091173110 [[],[.left]] .chain = true := by decide
def e598091173486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e598091173486 : Closed e598091173486 ∧ code e598091173486 = 2797114429038 := by decide
theorem cert_e598091173486 : check e598091173486 [[],[.left]] .chain = true := by decide
def e598091173498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e598091173498 : Closed e598091173498 ∧ code e598091173498 = 2797114429050 := by decide
theorem cert_e598091173498 : check e598091173498 [[],[.left]] .chain = true := by decide
def e598091173686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e598091173686 : Closed e598091173686 ∧ code e598091173686 = 2797114429238 := by decide
theorem cert_e598091173686 : check e598091173686 [[],[.left]] .chain = true := by decide
def e598091173690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e598091173690 : Closed e598091173690 ∧ code e598091173690 = 2797114429242 := by decide
theorem cert_e598091173690 : check e598091173690 [[],[.left]] .chain = true := by decide
def e598091762542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e598091762542 : Closed e598091762542 ∧ code e598091762542 = 2797115018094 := by decide
theorem cert_e598091762542 : check e598091762542 [[],[.left],[.left],[.left],[],[.left]] .smaller = true := by decide
def e598091762550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e598091762550 : Closed e598091762550 ∧ code e598091762550 = 2797115018102 := by decide
theorem cert_e598091762550 : check e598091762550 [[],[.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e598091762606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e598091762606 : Closed e598091762606 ∧ code e598091762606 = 2797115018158 := by decide
theorem cert_e598091762606 : check e598091762606 [[],[.left],[.left],[.left],[],[.left],[],[.left]] .chain = true := by decide
def e598091762618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e598091762618 : Closed e598091762618 ∧ code e598091762618 = 2797115018170 := by decide
private def t_e598091762618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e598091762618 : ¬ IsSelfInterpreter e598091762618 :=
  wSource (t := t_e598091762618) (replay_sound (ps := []) (t := e598091762618) (by decide)) (by decide)
def e598091762646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e598091762646 : Closed e598091762646 ∧ code e598091762646 = 2797115018198 := by decide
theorem cert_e598091762646 : check e598091762646 [[],[.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e598091762650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e598091762650 : Closed e598091762650 ∧ code e598091762650 = 2797115018202 := by decide
private def t_e598091762650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e598091762650 : ¬ IsSelfInterpreter e598091762650 :=
  wSource (t := t_e598091762650) (replay_sound (ps := []) (t := e598091762650) (by decide)) (by decide)
def e598091762926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e598091762926 : Closed e598091762926 ∧ code e598091762926 = 2797115018478 := by decide
theorem cert_e598091762926 : check e598091762926 [[],[.left],[.left],[.left],[],[]] .smaller = true := by decide
def e598091762934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e598091762934 : Closed e598091762934 ∧ code e598091762934 = 2797115018486 := by decide
theorem cert_e598091762934 : check e598091762934 [[],[.left],[.left],[.left],[],[]] .smaller = true := by decide
def e598091763310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e598091763310 : Closed e598091763310 ∧ code e598091763310 = 2797115018862 := by decide
theorem cert_e598091763310 : check e598091763310 [[],[.left],[.left],[.left],[],[],[.under,.left]] .chain = true := by decide
def e598091763322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e598091763322 : Closed e598091763322 ∧ code e598091763322 = 2797115018874 := by decide
theorem cert_e598091763322 : check e598091763322 [[],[.left],[.left],[.left],[],[],[.under,.left]] .chain = true := by decide
def e598091763510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e598091763510 : Closed e598091763510 ∧ code e598091763510 = 2797115019062 := by decide
theorem cert_e598091763510 : check e598091763510 [[],[.left],[.left],[.left],[],[],[.left]] .chain = true := by decide
def e598091763514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e598091763514 : Closed e598091763514 ∧ code e598091763514 = 2797115019066 := by decide
theorem cert_e598091763514 : check e598091763514 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left]] .chain = true := by decide
def e598125276698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598125276698 : Closed e598125276698 ∧ code e598125276698 = 2797148532250 := by decide
private def t_e598125276698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598125276698 : ¬ IsSelfInterpreter e598125276698 :=
  wSource (t := t_e598125276698) (replay_sound (ps := []) (t := e598125276698) (by decide)) (by decide)
def e598125278746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598125278746 : Closed e598125278746 ∧ code e598125278746 = 2797148534298 := by decide
private def t_e598125278746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598125278746 : ¬ IsSelfInterpreter e598125278746 :=
  wSource (t := t_e598125278746) (replay_sound (ps := []) (t := e598125278746) (by decide)) (by decide)
def e598125293082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598125293082 : Closed e598125293082 ∧ code e598125293082 = 2797148548634 := by decide
private def t_e598125293082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598125293082 : ¬ IsSelfInterpreter e598125293082 :=
  wSource (t := t_e598125293082) (replay_sound (ps := []) (t := e598125293082) (by decide)) (by decide)
def e598125296154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598125296154 : Closed e598125296154 ∧ code e598125296154 = 2797148551706 := by decide
private def t_e598125296154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598125296154 : ¬ IsSelfInterpreter e598125296154 :=
  wSource (t := t_e598125296154) (replay_sound (ps := []) (t := e598125296154) (by decide)) (by decide)
def e598125303322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598125303322 : Closed e598125303322 ∧ code e598125303322 = 2797148558874 := by decide
private def t_e598125303322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598125303322 : ¬ IsSelfInterpreter e598125303322 :=
  wSource (t := t_e598125303322) (replay_sound (ps := []) (t := e598125303322) (by decide)) (by decide)
def e598125304346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598125304346 : Closed e598125304346 ∧ code e598125304346 = 2797148559898 := by decide
private def t_e598125304346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598125304346 : ¬ IsSelfInterpreter e598125304346 :=
  wSource (t := t_e598125304346) (replay_sound (ps := []) (t := e598125304346) (by decide)) (by decide)
def e598125375002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598125375002 : Closed e598125375002 ∧ code e598125375002 = 2797148630554 := by decide
private def t_e598125375002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598125375002 : ¬ IsSelfInterpreter e598125375002 :=
  wSource (t := t_e598125375002) (replay_sound (ps := []) (t := e598125375002) (by decide)) (by decide)
def e598125377050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598125377050 : Closed e598125377050 ∧ code e598125377050 = 2797148632602 := by decide
private def t_e598125377050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598125377050 : ¬ IsSelfInterpreter e598125377050 :=
  wSource (t := t_e598125377050) (replay_sound (ps := []) (t := e598125377050) (by decide)) (by decide)
def e598125473306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598125473306 : Closed e598125473306 ∧ code e598125473306 = 2797148728858 := by decide
private def t_e598125473306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598125473306 : ¬ IsSelfInterpreter e598125473306 :=
  wSource (t := t_e598125473306) (replay_sound (ps := []) (t := e598125473306) (by decide)) (by decide)
def e598125476378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598125476378 : Closed e598125476378 ∧ code e598125476378 = 2797148731930 := by decide
private def t_e598125476378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598125476378 : ¬ IsSelfInterpreter e598125476378 :=
  wSource (t := t_e598125476378) (replay_sound (ps := []) (t := e598125476378) (by decide)) (by decide)
def e598125524506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598125524506 : Closed e598125524506 ∧ code e598125524506 = 2797148780058 := by decide
private def t_e598125524506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598125524506 : ¬ IsSelfInterpreter e598125524506 :=
  wSource (t := t_e598125524506) (replay_sound (ps := []) (t := e598125524506) (by decide)) (by decide)
def e598125525530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e598125525530 : Closed e598125525530 ∧ code e598125525530 = 2797148781082 := by decide
private def t_e598125525530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e598125525530 : ¬ IsSelfInterpreter e598125525530 :=
  wSource (t := t_e598125525530) (replay_sound (ps := []) (t := e598125525530) (by decide)) (by decide)
def e598141349230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e598141349230 : Closed e598141349230 ∧ code e598141349230 = 2797164604782 := by decide
theorem cert_e598141349230 : check e598141349230 [[],[.left]] .smaller = true := by decide
def e598141349238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e598141349238 : Closed e598141349238 ∧ code e598141349238 = 2797164604790 := by decide
theorem cert_e598141349238 : check e598141349238 [[],[.left]] .smaller = true := by decide
def e598141349294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e598141349294 : Closed e598141349294 ∧ code e598141349294 = 2797164604846 := by decide
theorem cert_e598141349294 : check e598141349294 [[],[.left]] .smaller = true := by decide
def e598141349306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e598141349306 : Closed e598141349306 ∧ code e598141349306 = 2797164604858 := by decide
theorem cert_e598141349306 : check e598141349306 [[],[.left]] .smaller = true := by decide
def e598141349334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e598141349334 : Closed e598141349334 ∧ code e598141349334 = 2797164604886 := by decide
theorem cert_e598141349334 : check e598141349334 [[],[.left]] .smaller = true := by decide
def e598141349338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e598141349338 : Closed e598141349338 ∧ code e598141349338 = 2797164604890 := by decide
theorem cert_e598141349338 : check e598141349338 [[],[.left]] .smaller = true := by decide
def e598141349550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e598141349550 : Closed e598141349550 ∧ code e598141349550 = 2797164605102 := by decide
theorem cert_e598141349550 : check e598141349550 [[],[.left]] .smaller = true := by decide
def e598141349562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e598141349562 : Closed e598141349562 ∧ code e598141349562 = 2797164605114 := by decide
theorem cert_e598141349562 : check e598141349562 [[],[.left]] .smaller = true := by decide
def e598141349610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e598141349610 : Closed e598141349610 ∧ code e598141349610 = 2797164605162 := by decide
theorem cert_e598141349610 : check e598141349610 [[],[.left]] .smaller = true := by decide
def e598141349718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e598141349718 : Closed e598141349718 ∧ code e598141349718 = 2797164605270 := by decide
theorem cert_e598141349718 : check e598141349718 [[],[.left]] .smaller = true := by decide
def e598141349722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e598141349722 : Closed e598141349722 ∧ code e598141349722 = 2797164605274 := by decide
theorem cert_e598141349722 : check e598141349722 [[],[.left]] .smaller = true := by decide
def e598141349738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e598141349738 : Closed e598141349738 ∧ code e598141349738 = 2797164605290 := by decide
theorem cert_e598141349738 : check e598141349738 [[],[.left]] .smaller = true := by decide
def e598141350766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e598141350766 : Closed e598141350766 ∧ code e598141350766 = 2797164606318 := by decide
theorem cert_e598141350766 : check e598141350766 [[],[.left]] .smaller = true := by decide
def e598141350774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e598141350774 : Closed e598141350774 ∧ code e598141350774 = 2797164606326 := by decide
theorem cert_e598141350774 : check e598141350774 [[],[.left]] .smaller = true := by decide
def e598141350830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e598141350830 : Closed e598141350830 ∧ code e598141350830 = 2797164606382 := by decide
theorem cert_e598141350830 : check e598141350830 [[],[.left]] .smaller = true := by decide
def e598141350842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e598141350842 : Closed e598141350842 ∧ code e598141350842 = 2797164606394 := by decide
theorem cert_e598141350842 : check e598141350842 [[],[.left]] .smaller = true := by decide
def e598141350870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e598141350870 : Closed e598141350870 ∧ code e598141350870 = 2797164606422 := by decide
theorem cert_e598141350870 : check e598141350870 [[],[.left]] .smaller = true := by decide
def e598141350874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e598141350874 : Closed e598141350874 ∧ code e598141350874 = 2797164606426 := by decide
theorem cert_e598141350874 : check e598141350874 [[],[.left]] .smaller = true := by decide
def e598141351150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e598141351150 : Closed e598141351150 ∧ code e598141351150 = 2797164606702 := by decide
theorem cert_e598141351150 : check e598141351150 [[],[.left]] .smaller = true := by decide
def e598141351158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e598141351158 : Closed e598141351158 ∧ code e598141351158 = 2797164606710 := by decide
theorem cert_e598141351158 : check e598141351158 [[],[.left]] .smaller = true := by decide
def e598141351534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e598141351534 : Closed e598141351534 ∧ code e598141351534 = 2797164607086 := by decide
theorem cert_e598141351534 : check e598141351534 [[],[.left]] .smaller = true := by decide
def e598141351546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e598141351546 : Closed e598141351546 ∧ code e598141351546 = 2797164607098 := by decide
theorem cert_e598141351546 : check e598141351546 [[],[.left]] .smaller = true := by decide
def e598141351734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e598141351734 : Closed e598141351734 ∧ code e598141351734 = 2797164607286 := by decide
theorem cert_e598141351734 : check e598141351734 [[],[.left]] .smaller = true := by decide
def e598141351738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e598141351738 : Closed e598141351738 ∧ code e598141351738 = 2797164607290 := by decide
theorem cert_e598141351738 : check e598141351738 [[],[.left]] .smaller = true := by decide
def e598141352366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e598141352366 : Closed e598141352366 ∧ code e598141352366 = 2797164607918 := by decide
theorem cert_e598141352366 : check e598141352366 [[],[.left]] .smaller = true := by decide
def e598141352378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e598141352378 : Closed e598141352378 ∧ code e598141352378 = 2797164607930 := by decide
theorem cert_e598141352378 : check e598141352378 [[],[.left]] .smaller = true := by decide
def e598141352426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e598141352426 : Closed e598141352426 ∧ code e598141352426 = 2797164607978 := by decide
theorem cert_e598141352426 : check e598141352426 [[],[.left]] .smaller = true := by decide
def e598141352558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e598141352558 : Closed e598141352558 ∧ code e598141352558 = 2797164608110 := by decide
theorem cert_e598141352558 : check e598141352558 [[],[.left]] .smaller = true := by decide
def e598141352570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e598141352570 : Closed e598141352570 ∧ code e598141352570 = 2797164608122 := by decide
theorem cert_e598141352570 : check e598141352570 [[],[.left]] .smaller = true := by decide
def e598141352858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e598141352858 : Closed e598141352858 ∧ code e598141352858 = 2797164608410 := by decide
theorem cert_e598141352858 : check e598141352858 [[],[.left]] .smaller = true := by decide
def e598141353174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e598141353174 : Closed e598141353174 ∧ code e598141353174 = 2797164608726 := by decide
theorem cert_e598141353174 : check e598141353174 [[],[.left]] .smaller = true := by decide
def e598141353178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e598141353178 : Closed e598141353178 ∧ code e598141353178 = 2797164608730 := by decide
theorem cert_e598141353178 : check e598141353178 [[],[.left]] .smaller = true := by decide
def e598141353194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e598141353194 : Closed e598141353194 ∧ code e598141353194 = 2797164608746 := by decide
theorem cert_e598141353194 : check e598141353194 [[],[.left]] .smaller = true := by decide
def e598141353270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e598141353270 : Closed e598141353270 ∧ code e598141353270 = 2797164608822 := by decide
theorem cert_e598141353270 : check e598141353270 [[],[.left]] .smaller = true := by decide
def e598141353274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e598141353274 : Closed e598141353274 ∧ code e598141353274 = 2797164608826 := by decide
theorem cert_e598141353274 : check e598141353274 [[],[.left]] .smaller = true := by decide
def e598141353370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e598141353370 : Closed e598141353370 ∧ code e598141353370 = 2797164608922 := by decide
theorem cert_e598141353370 : check e598141353370 [[],[.left]] .smaller = true := by decide
def e598141356910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598141356910 : Closed e598141356910 ∧ code e598141356910 = 2797164612462 := by decide
theorem cert_e598141356910 : check e598141356910 [[],[.left]] .smaller = true := by decide
def e598141356918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598141356918 : Closed e598141356918 ∧ code e598141356918 = 2797164612470 := by decide
theorem cert_e598141356918 : check e598141356918 [[],[.left]] .smaller = true := by decide
def e598141356974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598141356974 : Closed e598141356974 ∧ code e598141356974 = 2797164612526 := by decide
theorem cert_e598141356974 : check e598141356974 [[],[.left]] .smaller = true := by decide
def e598141356986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598141356986 : Closed e598141356986 ∧ code e598141356986 = 2797164612538 := by decide
theorem cert_e598141356986 : check e598141356986 [[],[.left]] .smaller = true := by decide
def e598141357014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598141357014 : Closed e598141357014 ∧ code e598141357014 = 2797164612566 := by decide
theorem cert_e598141357014 : check e598141357014 [[],[.left]] .smaller = true := by decide
def e598141357018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598141357018 : Closed e598141357018 ∧ code e598141357018 = 2797164612570 := by decide
theorem cert_e598141357018 : check e598141357018 [[],[.left]] .smaller = true := by decide
def e598141357294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598141357294 : Closed e598141357294 ∧ code e598141357294 = 2797164612846 := by decide
theorem cert_e598141357294 : check e598141357294 [[],[.left]] .smaller = true := by decide
def e598141357302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598141357302 : Closed e598141357302 ∧ code e598141357302 = 2797164612854 := by decide
theorem cert_e598141357302 : check e598141357302 [[],[.left]] .smaller = true := by decide
def e598141357678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598141357678 : Closed e598141357678 ∧ code e598141357678 = 2797164613230 := by decide
theorem cert_e598141357678 : check e598141357678 [[],[.left]] .smaller = true := by decide
def e598141357690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598141357690 : Closed e598141357690 ∧ code e598141357690 = 2797164613242 := by decide
theorem cert_e598141357690 : check e598141357690 [[],[.left]] .smaller = true := by decide
def e598141357878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598141357878 : Closed e598141357878 ∧ code e598141357878 = 2797164613430 := by decide
theorem cert_e598141357878 : check e598141357878 [[],[.left]] .smaller = true := by decide
def e598141357882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598141357882 : Closed e598141357882 ∧ code e598141357882 = 2797164613434 := by decide
theorem cert_e598141357882 : check e598141357882 [[],[.left]] .smaller = true := by decide
def e598141363630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e598141363630 : Closed e598141363630 ∧ code e598141363630 = 2797164619182 := by decide
theorem cert_e598141363630 : check e598141363630 [[],[.left]] .smaller = true := by decide
def e598141363642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e598141363642 : Closed e598141363642 ∧ code e598141363642 = 2797164619194 := by decide
theorem cert_e598141363642 : check e598141363642 [[],[.left]] .smaller = true := by decide
def e598141363690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e598141363690 : Closed e598141363690 ∧ code e598141363690 = 2797164619242 := by decide
theorem cert_e598141363690 : check e598141363690 [[],[.left]] .smaller = true := by decide
def e598141363822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e598141363822 : Closed e598141363822 ∧ code e598141363822 = 2797164619374 := by decide
theorem cert_e598141363822 : check e598141363822 [[],[.left]] .smaller = true := by decide
def e598141363834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e598141363834 : Closed e598141363834 ∧ code e598141363834 = 2797164619386 := by decide
theorem cert_e598141363834 : check e598141363834 [[],[.left]] .smaller = true := by decide
def e598141364122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e598141364122 : Closed e598141364122 ∧ code e598141364122 = 2797164619674 := by decide
theorem cert_e598141364122 : check e598141364122 [[],[.left]] .smaller = true := by decide
def e598141366998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e598141366998 : Closed e598141366998 ∧ code e598141366998 = 2797164622550 := by decide
theorem cert_e598141366998 : check e598141366998 [[],[.left]] .smaller = true := by decide
def e598141367002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e598141367002 : Closed e598141367002 ∧ code e598141367002 = 2797164622554 := by decide
theorem cert_e598141367002 : check e598141367002 [[],[.left]] .smaller = true := by decide
def e598141367018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e598141367018 : Closed e598141367018 ∧ code e598141367018 = 2797164622570 := by decide
theorem cert_e598141367018 : check e598141367018 [[],[.left]] .smaller = true := by decide
def e598141367094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e598141367094 : Closed e598141367094 ∧ code e598141367094 = 2797164622646 := by decide
theorem cert_e598141367094 : check e598141367094 [[],[.left]] .smaller = true := by decide
def e598141367098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e598141367098 : Closed e598141367098 ∧ code e598141367098 = 2797164622650 := by decide
theorem cert_e598141367098 : check e598141367098 [[],[.left]] .smaller = true := by decide
def e598141367194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e598141367194 : Closed e598141367194 ∧ code e598141367194 = 2797164622746 := by decide
theorem cert_e598141367194 : check e598141367194 [[],[.left]] .smaller = true := by decide
end Blc.Floor41
