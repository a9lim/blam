import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605590582510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e605590582510 : Closed e605590582510 ∧ code e605590582510 = 2804613838062 := by decide
theorem cert_e605590582510 : check e605590582510 [[],[]] .smaller = true := by decide
def e605590582518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e605590582518 : Closed e605590582518 ∧ code e605590582518 = 2804613838070 := by decide
theorem cert_e605590582518 : check e605590582518 [[],[]] .smaller = true := by decide
def e605590582522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e605590582522 : Closed e605590582522 ∧ code e605590582522 = 2804613838074 := by decide
theorem cert_e605590582522 : check e605590582522 [[],[]] .smaller = true := by decide
def e605590582894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605590582894 : Closed e605590582894 ∧ code e605590582894 = 2804613838446 := by decide
theorem cert_e605590582894 : check e605590582894 [[],[]] .smaller = true := by decide
def e605590582906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605590582906 : Closed e605590582906 ∧ code e605590582906 = 2804613838458 := by decide
theorem cert_e605590582906 : check e605590582906 [[],[]] .smaller = true := by decide
def e605590583094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605590583094 : Closed e605590583094 ∧ code e605590583094 = 2804613838646 := by decide
theorem cert_e605590583094 : check e605590583094 [[],[]] .smaller = true := by decide
def e605590583098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605590583098 : Closed e605590583098 ∧ code e605590583098 = 2804613838650 := by decide
theorem cert_e605590583098 : check e605590583098 [[],[]] .smaller = true := by decide
def e605590583194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605590583194 : Closed e605590583194 ∧ code e605590583194 = 2804613838746 := by decide
theorem cert_e605590583194 : check e605590583194 [[],[]] .smaller = true := by decide
def e605590583726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e605590583726 : Closed e605590583726 ∧ code e605590583726 = 2804613839278 := by decide
theorem cert_e605590583726 : check e605590583726 [[],[]] .smaller = true := by decide
def e605590583734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e605590583734 : Closed e605590583734 ∧ code e605590583734 = 2804613839286 := by decide
theorem cert_e605590583734 : check e605590583734 [[],[]] .smaller = true := by decide
def e605590583738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e605590583738 : Closed e605590583738 ∧ code e605590583738 = 2804613839290 := by decide
theorem cert_e605590583738 : check e605590583738 [[],[]] .smaller = true := by decide
def e605590583766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e605590583766 : Closed e605590583766 ∧ code e605590583766 = 2804613839318 := by decide
theorem cert_e605590583766 : check e605590583766 [[],[]] .smaller = true := by decide
def e605590583770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e605590583770 : Closed e605590583770 ∧ code e605590583770 = 2804613839322 := by decide
theorem cert_e605590583770 : check e605590583770 [[],[]] .smaller = true := by decide
def e605590583786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e605590583786 : Closed e605590583786 ∧ code e605590583786 = 2804613839338 := by decide
theorem cert_e605590583786 : check e605590583786 [[],[]] .smaller = true := by decide
def e605590583918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605590583918 : Closed e605590583918 ∧ code e605590583918 = 2804613839470 := by decide
theorem cert_e605590583918 : check e605590583918 [[],[]] .smaller = true := by decide
def e605590583926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e605590583926 : Closed e605590583926 ∧ code e605590583926 = 2804613839478 := by decide
theorem cert_e605590583926 : check e605590583926 [[],[]] .smaller = true := by decide
def e605590583930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605590583930 : Closed e605590583930 ∧ code e605590583930 = 2804613839482 := by decide
theorem cert_e605590583930 : check e605590583930 [[],[]] .smaller = true := by decide
def e605590584118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605590584118 : Closed e605590584118 ∧ code e605590584118 = 2804613839670 := by decide
theorem cert_e605590584118 : check e605590584118 [[],[]] .smaller = true := by decide
def e605590584122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605590584122 : Closed e605590584122 ∧ code e605590584122 = 2804613839674 := by decide
theorem cert_e605590584122 : check e605590584122 [[],[]] .smaller = true := by decide
def e605590584218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605590584218 : Closed e605590584218 ∧ code e605590584218 = 2804613839770 := by decide
theorem cert_e605590584218 : check e605590584218 [[],[]] .smaller = true := by decide
def e605590584534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e605590584534 : Closed e605590584534 ∧ code e605590584534 = 2804613840086 := by decide
theorem cert_e605590584534 : check e605590584534 [[],[]] .smaller = true := by decide
def e605590584538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e605590584538 : Closed e605590584538 ∧ code e605590584538 = 2804613840090 := by decide
theorem cert_e605590584538 : check e605590584538 [[],[]] .smaller = true := by decide
def e605590584554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e605590584554 : Closed e605590584554 ∧ code e605590584554 = 2804613840106 := by decide
theorem cert_e605590584554 : check e605590584554 [[],[]] .smaller = true := by decide
def e605590584630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605590584630 : Closed e605590584630 ∧ code e605590584630 = 2804613840182 := by decide
theorem cert_e605590584630 : check e605590584630 [[],[]] .smaller = true := by decide
def e605590584634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605590584634 : Closed e605590584634 ∧ code e605590584634 = 2804613840186 := by decide
theorem cert_e605590584634 : check e605590584634 [[],[]] .smaller = true := by decide
def e605590584730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605590584730 : Closed e605590584730 ∧ code e605590584730 = 2804613840282 := by decide
theorem cert_e605590584730 : check e605590584730 [[],[]] .smaller = true := by decide
def e605590588270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e605590588270 : Closed e605590588270 ∧ code e605590588270 = 2804613843822 := by decide
theorem cert_e605590588270 : check e605590588270 [[],[]] .smaller = true := by decide
def e605590588278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e605590588278 : Closed e605590588278 ∧ code e605590588278 = 2804613843830 := by decide
theorem cert_e605590588278 : check e605590588278 [[],[]] .smaller = true := by decide
def e605590588334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e605590588334 : Closed e605590588334 ∧ code e605590588334 = 2804613843886 := by decide
theorem cert_e605590588334 : check e605590588334 [[],[]] .smaller = true := by decide
def e605590588346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e605590588346 : Closed e605590588346 ∧ code e605590588346 = 2804613843898 := by decide
theorem cert_e605590588346 : check e605590588346 [[],[]] .smaller = true := by decide
def e605590588374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e605590588374 : Closed e605590588374 ∧ code e605590588374 = 2804613843926 := by decide
theorem cert_e605590588374 : check e605590588374 [[],[]] .smaller = true := by decide
def e605590588378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e605590588378 : Closed e605590588378 ∧ code e605590588378 = 2804613843930 := by decide
theorem cert_e605590588378 : check e605590588378 [[],[]] .smaller = true := by decide
def e605590588654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e605590588654 : Closed e605590588654 ∧ code e605590588654 = 2804613844206 := by decide
theorem cert_e605590588654 : check e605590588654 [[],[]] .smaller = true := by decide
def e605590588662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e605590588662 : Closed e605590588662 ∧ code e605590588662 = 2804613844214 := by decide
theorem cert_e605590588662 : check e605590588662 [[],[]] .smaller = true := by decide
def e605590589038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e605590589038 : Closed e605590589038 ∧ code e605590589038 = 2804613844590 := by decide
theorem cert_e605590589038 : check e605590589038 [[],[]] .smaller = true := by decide
def e605590589050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e605590589050 : Closed e605590589050 ∧ code e605590589050 = 2804613844602 := by decide
theorem cert_e605590589050 : check e605590589050 [[],[]] .smaller = true := by decide
def e605590589238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e605590589238 : Closed e605590589238 ∧ code e605590589238 = 2804613844790 := by decide
theorem cert_e605590589238 : check e605590589238 [[],[]] .smaller = true := by decide
def e605590589242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e605590589242 : Closed e605590589242 ∧ code e605590589242 = 2804613844794 := by decide
theorem cert_e605590589242 : check e605590589242 [[],[]] .smaller = true := by decide
def e605590597054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 4))))))))))
theorem wire_e605590597054 : Closed e605590597054 ∧ code e605590597054 = 2804613852606 := by decide
theorem cert_e605590597054 : check e605590597054 [[],[]] .smaller = true := by decide
def e605590597086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e605590597086 : Closed e605590597086 ∧ code e605590597086 = 2804613852638 := by decide
theorem cert_e605590597086 : check e605590597086 [[],[]] .smaller = true := by decide
def e605590597102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e605590597102 : Closed e605590597102 ∧ code e605590597102 = 2804613852654 := by decide
theorem cert_e605590597102 : check e605590597102 [[],[]] .smaller = true := by decide
def e605590597110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 1))))))))))
theorem wire_e605590597110 : Closed e605590597110 ∧ code e605590597110 = 2804613852662 := by decide
theorem cert_e605590597110 : check e605590597110 [[],[]] .smaller = true := by decide
def e605590597310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 4))))))))))
theorem wire_e605590597310 : Closed e605590597310 ∧ code e605590597310 = 2804613852862 := by decide
theorem cert_e605590597310 : check e605590597310 [[],[]] .smaller = true := by decide
def e605590597342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))))
theorem wire_e605590597342 : Closed e605590597342 ∧ code e605590597342 = 2804613852894 := by decide
theorem cert_e605590597342 : check e605590597342 [[],[]] .smaller = true := by decide
def e605590597358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))))
theorem wire_e605590597358 : Closed e605590597358 ∧ code e605590597358 = 2804613852910 := by decide
theorem cert_e605590597358 : check e605590597358 [[],[]] .smaller = true := by decide
def e605590597366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))))
theorem wire_e605590597366 : Closed e605590597366 ∧ code e605590597366 = 2804613852918 := by decide
theorem cert_e605590597366 : check e605590597366 [[],[]] .smaller = true := by decide
def e605590597370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.var 0))))))))))
theorem wire_e605590597370 : Closed e605590597370 ∧ code e605590597370 = 2804613852922 := by decide
theorem cert_e605590597370 : check e605590597370 [[],[]] .smaller = true := by decide
def e605590597470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e605590597470 : Closed e605590597470 ∧ code e605590597470 = 2804613853022 := by decide
theorem cert_e605590597470 : check e605590597470 [[],[]] .smaller = true := by decide
def e605590597486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))))
theorem wire_e605590597486 : Closed e605590597486 ∧ code e605590597486 = 2804613853038 := by decide
theorem cert_e605590597486 : check e605590597486 [[],[]] .smaller = true := by decide
def e605590597494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))))
theorem wire_e605590597494 : Closed e605590597494 ∧ code e605590597494 = 2804613853046 := by decide
theorem cert_e605590597494 : check e605590597494 [[],[]] .smaller = true := by decide
def e605590597498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e605590597498 : Closed e605590597498 ∧ code e605590597498 = 2804613853050 := by decide
theorem cert_e605590597498 : check e605590597498 [[],[]] .smaller = true := by decide
def e605590597550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e605590597550 : Closed e605590597550 ∧ code e605590597550 = 2804613853102 := by decide
theorem cert_e605590597550 : check e605590597550 [[],[]] .smaller = true := by decide
def e605590597558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))))
theorem wire_e605590597558 : Closed e605590597558 ∧ code e605590597558 = 2804613853110 := by decide
theorem cert_e605590597558 : check e605590597558 [[],[]] .smaller = true := by decide
def e605590597562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e605590597562 : Closed e605590597562 ∧ code e605590597562 = 2804613853114 := by decide
theorem cert_e605590597562 : check e605590597562 [[],[]] .smaller = true := by decide
def e605590597590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 1))))))))))
theorem wire_e605590597590 : Closed e605590597590 ∧ code e605590597590 = 2804613853142 := by decide
theorem cert_e605590597590 : check e605590597590 [[],[]] .smaller = true := by decide
def e605590597594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.var 0))))))))))
theorem wire_e605590597594 : Closed e605590597594 ∧ code e605590597594 = 2804613853146 := by decide
theorem cert_e605590597594 : check e605590597594 [[],[]] .smaller = true := by decide
def e605590598590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 4)))))))))))
theorem wire_e605590598590 : Closed e605590598590 ∧ code e605590598590 = 2804613854142 := by decide
theorem cert_e605590598590 : check e605590598590 [[],[]] .smaller = true := by decide
def e605590598622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e605590598622 : Closed e605590598622 ∧ code e605590598622 = 2804613854174 := by decide
theorem cert_e605590598622 : check e605590598622 [[],[]] .smaller = true := by decide
def e605590598638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e605590598638 : Closed e605590598638 ∧ code e605590598638 = 2804613854190 := by decide
theorem cert_e605590598638 : check e605590598638 [[],[]] .smaller = true := by decide
def e605590598646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 1)))))))))))
theorem wire_e605590598646 : Closed e605590598646 ∧ code e605590598646 = 2804613854198 := by decide
theorem cert_e605590598646 : check e605590598646 [[],[]] .smaller = true := by decide
def e605590600126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 4)))))))))))
theorem wire_e605590600126 : Closed e605590600126 ∧ code e605590600126 = 2804613855678 := by decide
theorem cert_e605590600126 : check e605590600126 [[],[]] .smaller = true := by decide
def e605590600158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))))
theorem wire_e605590600158 : Closed e605590600158 ∧ code e605590600158 = 2804613855710 := by decide
theorem cert_e605590600158 : check e605590600158 [[],[]] .smaller = true := by decide
def e605590600174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))))
theorem wire_e605590600174 : Closed e605590600174 ∧ code e605590600174 = 2804613855726 := by decide
theorem cert_e605590600174 : check e605590600174 [[],[]] .smaller = true := by decide
def e605590600182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))))
theorem wire_e605590600182 : Closed e605590600182 ∧ code e605590600182 = 2804613855734 := by decide
theorem cert_e605590600182 : check e605590600182 [[],[]] .smaller = true := by decide
def e605590600186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.var 0)))))))))))
theorem wire_e605590600186 : Closed e605590600186 ∧ code e605590600186 = 2804613855738 := by decide
theorem cert_e605590600186 : check e605590600186 [[],[]] .smaller = true := by decide
def e605590600926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e605590600926 : Closed e605590600926 ∧ code e605590600926 = 2804613856478 := by decide
theorem cert_e605590600926 : check e605590600926 [[],[]] .smaller = true := by decide
def e605590600942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605590600942 : Closed e605590600942 ∧ code e605590600942 = 2804613856494 := by decide
theorem cert_e605590600942 : check e605590600942 [[],[]] .smaller = true := by decide
def e605590600950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605590600950 : Closed e605590600950 ∧ code e605590600950 = 2804613856502 := by decide
theorem cert_e605590600950 : check e605590600950 [[],[]] .smaller = true := by decide
def e605590600954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e605590600954 : Closed e605590600954 ∧ code e605590600954 = 2804613856506 := by decide
theorem cert_e605590600954 : check e605590600954 [[],[]] .smaller = true := by decide
def e605590601326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605590601326 : Closed e605590601326 ∧ code e605590601326 = 2804613856878 := by decide
theorem cert_e605590601326 : check e605590601326 [[],[]] .smaller = true := by decide
def e605590601334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))))
theorem wire_e605590601334 : Closed e605590601334 ∧ code e605590601334 = 2804613856886 := by decide
theorem cert_e605590601334 : check e605590601334 [[],[]] .smaller = true := by decide
def e605590601338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605590601338 : Closed e605590601338 ∧ code e605590601338 = 2804613856890 := by decide
theorem cert_e605590601338 : check e605590601338 [[],[]] .smaller = true := by decide
def e605590601526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605590601526 : Closed e605590601526 ∧ code e605590601526 = 2804613857078 := by decide
theorem cert_e605590601526 : check e605590601526 [[],[]] .smaller = true := by decide
def e605590601530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605590601530 : Closed e605590601530 ∧ code e605590601530 = 2804613857082 := by decide
theorem cert_e605590601530 : check e605590601530 [[],[]] .smaller = true := by decide
def e605590623934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 4))))))))))
theorem wire_e605590623934 : Closed e605590623934 ∧ code e605590623934 = 2804613879486 := by decide
theorem cert_e605590623934 : check e605590623934 [[],[]] .smaller = true := by decide
def e605590623966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e605590623966 : Closed e605590623966 ∧ code e605590623966 = 2804613879518 := by decide
theorem cert_e605590623966 : check e605590623966 [[],[]] .smaller = true := by decide
def e605590623982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))))
theorem wire_e605590623982 : Closed e605590623982 ∧ code e605590623982 = 2804613879534 := by decide
theorem cert_e605590623982 : check e605590623982 [[],[]] .smaller = true := by decide
def e605590623990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e605590623990 : Closed e605590623990 ∧ code e605590623990 = 2804613879542 := by decide
theorem cert_e605590623990 : check e605590623990 [[],[]] .smaller = true := by decide
def e605590623994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.var 0))))))))))
theorem wire_e605590623994 : Closed e605590623994 ∧ code e605590623994 = 2804613879546 := by decide
theorem cert_e605590623994 : check e605590623994 [[],[]] .smaller = true := by decide
def e605590624094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e605590624094 : Closed e605590624094 ∧ code e605590624094 = 2804613879646 := by decide
theorem cert_e605590624094 : check e605590624094 [[],[]] .smaller = true := by decide
def e605590624122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e605590624122 : Closed e605590624122 ∧ code e605590624122 = 2804613879674 := by decide
theorem cert_e605590624122 : check e605590624122 [[],[]] .smaller = true := by decide
def e605590624174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))))
theorem wire_e605590624174 : Closed e605590624174 ∧ code e605590624174 = 2804613879726 := by decide
theorem cert_e605590624174 : check e605590624174 [[],[]] .smaller = true := by decide
def e605590624186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))))
theorem wire_e605590624186 : Closed e605590624186 ∧ code e605590624186 = 2804613879738 := by decide
theorem cert_e605590624186 : check e605590624186 [[],[]] .smaller = true := by decide
def e605590624214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e605590624214 : Closed e605590624214 ∧ code e605590624214 = 2804613879766 := by decide
theorem cert_e605590624214 : check e605590624214 [[],[]] .smaller = true := by decide
def e605590624218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e605590624218 : Closed e605590624218 ∧ code e605590624218 = 2804613879770 := by decide
theorem cert_e605590624218 : check e605590624218 [[],[]] .smaller = true := by decide
def e605590624234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.var 0))))))))))
theorem wire_e605590624234 : Closed e605590624234 ∧ code e605590624234 = 2804613879786 := by decide
theorem cert_e605590624234 : check e605590624234 [[],[]] .smaller = true := by decide
def e605590624702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 4)))))))))))
theorem wire_e605590624702 : Closed e605590624702 ∧ code e605590624702 = 2804613880254 := by decide
theorem cert_e605590624702 : check e605590624702 [[],[]] .smaller = true := by decide
def e605590624734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e605590624734 : Closed e605590624734 ∧ code e605590624734 = 2804613880286 := by decide
theorem cert_e605590624734 : check e605590624734 [[],[]] .smaller = true := by decide
def e605590624750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))))
theorem wire_e605590624750 : Closed e605590624750 ∧ code e605590624750 = 2804613880302 := by decide
theorem cert_e605590624750 : check e605590624750 [[],[]] .smaller = true := by decide
def e605590624758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e605590624758 : Closed e605590624758 ∧ code e605590624758 = 2804613880310 := by decide
theorem cert_e605590624758 : check e605590624758 [[],[]] .smaller = true := by decide
def e605590624762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.var 0)))))))))))
theorem wire_e605590624762 : Closed e605590624762 ∧ code e605590624762 = 2804613880314 := by decide
theorem cert_e605590624762 : check e605590624762 [[],[]] .smaller = true := by decide
def e605590625502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e605590625502 : Closed e605590625502 ∧ code e605590625502 = 2804613881054 := by decide
theorem cert_e605590625502 : check e605590625502 [[],[]] .smaller = true := by decide
def e605590625530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e605590625530 : Closed e605590625530 ∧ code e605590625530 = 2804613881082 := by decide
theorem cert_e605590625530 : check e605590625530 [[],[]] .smaller = true := by decide
def e605590625902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605590625902 : Closed e605590625902 ∧ code e605590625902 = 2804613881454 := by decide
theorem cert_e605590625902 : check e605590625902 [[],[]] .smaller = true := by decide
def e605590625914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605590625914 : Closed e605590625914 ∧ code e605590625914 = 2804613881466 := by decide
theorem cert_e605590625914 : check e605590625914 [[],[]] .smaller = true := by decide
def e605590626102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605590626102 : Closed e605590626102 ∧ code e605590626102 = 2804613881654 := by decide
theorem cert_e605590626102 : check e605590626102 [[],[]] .smaller = true := by decide
def e605590626106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605590626106 : Closed e605590626106 ∧ code e605590626106 = 2804613881658 := by decide
theorem cert_e605590626106 : check e605590626106 [[],[]] .smaller = true := by decide
def e605590626202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605590626202 : Closed e605590626202 ∧ code e605590626202 = 2804613881754 := by decide
theorem cert_e605590626202 : check e605590626202 [[],[]] .smaller = true := by decide
def e605590637406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e605590637406 : Closed e605590637406 ∧ code e605590637406 = 2804613892958 := by decide
theorem cert_e605590637406 : check e605590637406 [[],[]] .smaller = true := by decide
def e605590637422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605590637422 : Closed e605590637422 ∧ code e605590637422 = 2804613892974 := by decide
theorem cert_e605590637422 : check e605590637422 [[],[]] .smaller = true := by decide
def e605590637430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605590637430 : Closed e605590637430 ∧ code e605590637430 = 2804613892982 := by decide
theorem cert_e605590637430 : check e605590637430 [[],[]] .smaller = true := by decide
def e605590637434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e605590637434 : Closed e605590637434 ∧ code e605590637434 = 2804613892986 := by decide
theorem cert_e605590637434 : check e605590637434 [[],[]] .smaller = true := by decide
def e605590637486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605590637486 : Closed e605590637486 ∧ code e605590637486 = 2804613893038 := by decide
theorem cert_e605590637486 : check e605590637486 [[],[]] .smaller = true := by decide
def e605590637498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605590637498 : Closed e605590637498 ∧ code e605590637498 = 2804613893050 := by decide
theorem cert_e605590637498 : check e605590637498 [[],[]] .smaller = true := by decide
def e605590637526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605590637526 : Closed e605590637526 ∧ code e605590637526 = 2804613893078 := by decide
theorem cert_e605590637526 : check e605590637526 [[],[]] .smaller = true := by decide
def e605590637530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605590637530 : Closed e605590637530 ∧ code e605590637530 = 2804613893082 := by decide
theorem cert_e605590637530 : check e605590637530 [[],[]] .smaller = true := by decide
def e605590637546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e605590637546 : Closed e605590637546 ∧ code e605590637546 = 2804613893098 := by decide
theorem cert_e605590637546 : check e605590637546 [[],[]] .smaller = true := by decide
def e605590637790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e605590637790 : Closed e605590637790 ∧ code e605590637790 = 2804613893342 := by decide
theorem cert_e605590637790 : check e605590637790 [[],[]] .smaller = true := by decide
def e605590637806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605590637806 : Closed e605590637806 ∧ code e605590637806 = 2804613893358 := by decide
theorem cert_e605590637806 : check e605590637806 [[],[]] .smaller = true := by decide
def e605590637814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605590637814 : Closed e605590637814 ∧ code e605590637814 = 2804613893366 := by decide
theorem cert_e605590637814 : check e605590637814 [[],[]] .smaller = true := by decide
def e605590637818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e605590637818 : Closed e605590637818 ∧ code e605590637818 = 2804613893370 := by decide
theorem cert_e605590637818 : check e605590637818 [[],[]] .smaller = true := by decide
def e605590638190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605590638190 : Closed e605590638190 ∧ code e605590638190 = 2804613893742 := by decide
theorem cert_e605590638190 : check e605590638190 [[],[]] .smaller = true := by decide
def e605590638202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605590638202 : Closed e605590638202 ∧ code e605590638202 = 2804613893754 := by decide
theorem cert_e605590638202 : check e605590638202 [[],[]] .smaller = true := by decide
def e605590638390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605590638390 : Closed e605590638390 ∧ code e605590638390 = 2804613893942 := by decide
theorem cert_e605590638390 : check e605590638390 [[],[]] .smaller = true := by decide
def e605590638394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605590638394 : Closed e605590638394 ∧ code e605590638394 = 2804613893946 := by decide
theorem cert_e605590638394 : check e605590638394 [[],[]] .smaller = true := by decide
def e605590638490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605590638490 : Closed e605590638490 ∧ code e605590638490 = 2804613894042 := by decide
theorem cert_e605590638490 : check e605590638490 [[],[]] .smaller = true := by decide
def e605590644142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e605590644142 : Closed e605590644142 ∧ code e605590644142 = 2804613899694 := by decide
theorem cert_e605590644142 : check e605590644142 [[],[]] .smaller = true := by decide
def e605590644150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e605590644150 : Closed e605590644150 ∧ code e605590644150 = 2804613899702 := by decide
theorem cert_e605590644150 : check e605590644150 [[],[]] .smaller = true := by decide
def e605590644154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e605590644154 : Closed e605590644154 ∧ code e605590644154 = 2804613899706 := by decide
theorem cert_e605590644154 : check e605590644154 [[],[]] .smaller = true := by decide
def e605590644182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e605590644182 : Closed e605590644182 ∧ code e605590644182 = 2804613899734 := by decide
theorem cert_e605590644182 : check e605590644182 [[],[]] .smaller = true := by decide
def e605590644186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e605590644186 : Closed e605590644186 ∧ code e605590644186 = 2804613899738 := by decide
theorem cert_e605590644186 : check e605590644186 [[],[]] .smaller = true := by decide
def e605590644202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e605590644202 : Closed e605590644202 ∧ code e605590644202 = 2804613899754 := by decide
theorem cert_e605590644202 : check e605590644202 [[],[]] .smaller = true := by decide
def e605590644334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605590644334 : Closed e605590644334 ∧ code e605590644334 = 2804613899886 := by decide
theorem cert_e605590644334 : check e605590644334 [[],[]] .smaller = true := by decide
def e605590644342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e605590644342 : Closed e605590644342 ∧ code e605590644342 = 2804613899894 := by decide
theorem cert_e605590644342 : check e605590644342 [[],[]] .smaller = true := by decide
def e605590644346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605590644346 : Closed e605590644346 ∧ code e605590644346 = 2804613899898 := by decide
theorem cert_e605590644346 : check e605590644346 [[],[]] .smaller = true := by decide
def e605590644534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605590644534 : Closed e605590644534 ∧ code e605590644534 = 2804613900086 := by decide
theorem cert_e605590644534 : check e605590644534 [[],[]] .smaller = true := by decide
def e605590644538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605590644538 : Closed e605590644538 ∧ code e605590644538 = 2804613900090 := by decide
theorem cert_e605590644538 : check e605590644538 [[],[]] .smaller = true := by decide
def e605590644634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605590644634 : Closed e605590644634 ∧ code e605590644634 = 2804613900186 := by decide
theorem cert_e605590644634 : check e605590644634 [[],[]] .smaller = true := by decide
def e605590647510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e605590647510 : Closed e605590647510 ∧ code e605590647510 = 2804613903062 := by decide
theorem cert_e605590647510 : check e605590647510 [[],[]] .smaller = true := by decide
def e605590647514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e605590647514 : Closed e605590647514 ∧ code e605590647514 = 2804613903066 := by decide
theorem cert_e605590647514 : check e605590647514 [[],[]] .smaller = true := by decide
def e605590647530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e605590647530 : Closed e605590647530 ∧ code e605590647530 = 2804613903082 := by decide
theorem cert_e605590647530 : check e605590647530 [[],[]] .smaller = true := by decide
def e605590647606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605590647606 : Closed e605590647606 ∧ code e605590647606 = 2804613903158 := by decide
theorem cert_e605590647606 : check e605590647606 [[],[]] .smaller = true := by decide
def e605590647610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605590647610 : Closed e605590647610 ∧ code e605590647610 = 2804613903162 := by decide
theorem cert_e605590647610 : check e605590647610 [[],[]] .smaller = true := by decide
def e605590647706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605590647706 : Closed e605590647706 ∧ code e605590647706 = 2804613903258 := by decide
theorem cert_e605590647706 : check e605590647706 [[],[]] .smaller = true := by decide
def e605591090542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605591090542 : Closed e605591090542 ∧ code e605591090542 = 2804614346094 := by decide
theorem cert_e605591090542 : check e605591090542 [[],[]] .smaller = true := by decide
def e605591090550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605591090550 : Closed e605591090550 ∧ code e605591090550 = 2804614346102 := by decide
theorem cert_e605591090550 : check e605591090550 [[],[]] .smaller = true := by decide
def e605591090606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605591090606 : Closed e605591090606 ∧ code e605591090606 = 2804614346158 := by decide
theorem cert_e605591090606 : check e605591090606 [[],[]] .smaller = true := by decide
def e605591090618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605591090618 : Closed e605591090618 ∧ code e605591090618 = 2804614346170 := by decide
theorem cert_e605591090618 : check e605591090618 [[],[]] .smaller = true := by decide
def e605591090646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605591090646 : Closed e605591090646 ∧ code e605591090646 = 2804614346198 := by decide
theorem cert_e605591090646 : check e605591090646 [[],[]] .smaller = true := by decide
def e605591090650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605591090650 : Closed e605591090650 ∧ code e605591090650 = 2804614346202 := by decide
theorem cert_e605591090650 : check e605591090650 [[],[]] .smaller = true := by decide
def e605591090862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605591090862 : Closed e605591090862 ∧ code e605591090862 = 2804614346414 := by decide
theorem cert_e605591090862 : check e605591090862 [[],[]] .smaller = true := by decide
def e605591090874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605591090874 : Closed e605591090874 ∧ code e605591090874 = 2804614346426 := by decide
theorem cert_e605591090874 : check e605591090874 [[],[]] .smaller = true := by decide
def e605591090922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605591090922 : Closed e605591090922 ∧ code e605591090922 = 2804614346474 := by decide
theorem cert_e605591090922 : check e605591090922 [[],[]] .smaller = true := by decide
def e605591091030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605591091030 : Closed e605591091030 ∧ code e605591091030 = 2804614346582 := by decide
theorem cert_e605591091030 : check e605591091030 [[],[]] .smaller = true := by decide
def e605591091034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605591091034 : Closed e605591091034 ∧ code e605591091034 = 2804614346586 := by decide
theorem cert_e605591091034 : check e605591091034 [[],[]] .smaller = true := by decide
def e605591091050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605591091050 : Closed e605591091050 ∧ code e605591091050 = 2804614346602 := by decide
theorem cert_e605591091050 : check e605591091050 [[],[]] .smaller = true := by decide
def e605591091886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e605591091886 : Closed e605591091886 ∧ code e605591091886 = 2804614347438 := by decide
theorem cert_e605591091886 : check e605591091886 [[],[]] .smaller = true := by decide
def e605591091898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e605591091898 : Closed e605591091898 ∧ code e605591091898 = 2804614347450 := by decide
theorem cert_e605591091898 : check e605591091898 [[],[]] .smaller = true := by decide
def e605591091946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e605591091946 : Closed e605591091946 ∧ code e605591091946 = 2804614347498 := by decide
theorem cert_e605591091946 : check e605591091946 [[],[]] .smaller = true := by decide
def e605591092138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605591092138 : Closed e605591092138 ∧ code e605591092138 = 2804614347690 := by decide
theorem cert_e605591092138 : check e605591092138 [[],[]] .smaller = true := by decide
def e605591092566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e605591092566 : Closed e605591092566 ∧ code e605591092566 = 2804614348118 := by decide
theorem cert_e605591092566 : check e605591092566 [[],[]] .smaller = true := by decide
def e605591092570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e605591092570 : Closed e605591092570 ∧ code e605591092570 = 2804614348122 := by decide
theorem cert_e605591092570 : check e605591092570 [[],[]] .smaller = true := by decide
def e605591092586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e605591092586 : Closed e605591092586 ∧ code e605591092586 = 2804614348138 := by decide
theorem cert_e605591092586 : check e605591092586 [[],[]] .smaller = true := by decide
def e605591092650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e605591092650 : Closed e605591092650 ∧ code e605591092650 = 2804614348202 := by decide
theorem cert_e605591092650 : check e605591092650 [[],[]] .smaller = true := by decide
def e605591095006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 3))))))))
theorem wire_e605591095006 : Closed e605591095006 ∧ code e605591095006 = 2804614350558 := by decide
theorem cert_e605591095006 : check e605591095006 [[],[]] .smaller = true := by decide
def e605591095030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.var 1))))))))
theorem wire_e605591095030 : Closed e605591095030 ∧ code e605591095030 = 2804614350582 := by decide
theorem cert_e605591095030 : check e605591095030 [[],[]] .smaller = true := by decide
def e605591095134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 3))))))))
theorem wire_e605591095134 : Closed e605591095134 ∧ code e605591095134 = 2804614350686 := by decide
theorem cert_e605591095134 : check e605591095134 [[],[]] .smaller = true := by decide
def e605591095150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2))))))))
theorem wire_e605591095150 : Closed e605591095150 ∧ code e605591095150 = 2804614350702 := by decide
theorem cert_e605591095150 : check e605591095150 [[],[]] .smaller = true := by decide
def e605591095158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1))))))))
theorem wire_e605591095158 : Closed e605591095158 ∧ code e605591095158 = 2804614350710 := by decide
theorem cert_e605591095158 : check e605591095158 [[],[]] .smaller = true := by decide
def e605591095162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.var 0))))))))
theorem wire_e605591095162 : Closed e605591095162 ∧ code e605591095162 = 2804614350714 := by decide
theorem cert_e605591095162 : check e605591095162 [[],[]] .smaller = true := by decide
end Blc.Floor41
