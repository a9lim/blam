import Floor41
namespace Blc.Floor41
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e208524062442 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e208524062442 : Closed e208524062442 ∧ code e208524062442 = 2407547317994 := by decide
theorem cert_e208524062442 : check e208524062442 [] .sourceHead = true := by decide
def e208524062550 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e208524062550 : Closed e208524062550 ∧ code e208524062550 = 2407547318102 := by decide
theorem cert_e208524062550 : check e208524062550 [] .sourceHead = true := by decide
def e208524062554 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e208524062554 : Closed e208524062554 ∧ code e208524062554 = 2407547318106 := by decide
theorem cert_e208524062554 : check e208524062554 [] .sourceHead = true := by decide
def e208524062570 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e208524062570 : Closed e208524062570 ∧ code e208524062570 = 2407547318122 := by decide
theorem cert_e208524062570 : check e208524062570 [] .sourceHead = true := by decide
def e208524063598 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e208524063598 : Closed e208524063598 ∧ code e208524063598 = 2407547319150 := by decide
theorem cert_e208524063598 : check e208524063598 [] .sourceHead = true := by decide
def e208524063606 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e208524063606 : Closed e208524063606 ∧ code e208524063606 = 2407547319158 := by decide
theorem cert_e208524063606 : check e208524063606 [] .sourceHead = true := by decide
def e208524063662 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e208524063662 : Closed e208524063662 ∧ code e208524063662 = 2407547319214 := by decide
theorem cert_e208524063662 : check e208524063662 [] .sourceHead = true := by decide
def e208524063674 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e208524063674 : Closed e208524063674 ∧ code e208524063674 = 2407547319226 := by decide
theorem cert_e208524063674 : check e208524063674 [] .sourceHead = true := by decide
def e208524063702 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e208524063702 : Closed e208524063702 ∧ code e208524063702 = 2407547319254 := by decide
theorem cert_e208524063702 : check e208524063702 [] .sourceHead = true := by decide
def e208524063706 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e208524063706 : Closed e208524063706 ∧ code e208524063706 = 2407547319258 := by decide
theorem cert_e208524063706 : check e208524063706 [] .sourceHead = true := by decide
def e208524063982 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e208524063982 : Closed e208524063982 ∧ code e208524063982 = 2407547319534 := by decide
theorem cert_e208524063982 : check e208524063982 [] .sourceHead = true := by decide
def e208524063990 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e208524063990 : Closed e208524063990 ∧ code e208524063990 = 2407547319542 := by decide
theorem cert_e208524063990 : check e208524063990 [] .sourceHead = true := by decide
def e208524064366 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e208524064366 : Closed e208524064366 ∧ code e208524064366 = 2407547319918 := by decide
theorem cert_e208524064366 : check e208524064366 [] .sourceHead = true := by decide
def e208524064378 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e208524064378 : Closed e208524064378 ∧ code e208524064378 = 2407547319930 := by decide
theorem cert_e208524064378 : check e208524064378 [] .sourceHead = true := by decide
def e208524064566 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e208524064566 : Closed e208524064566 ∧ code e208524064566 = 2407547320118 := by decide
theorem cert_e208524064566 : check e208524064566 [] .sourceHead = true := by decide
def e208524064570 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e208524064570 : Closed e208524064570 ∧ code e208524064570 = 2407547320122 := by decide
theorem cert_e208524064570 : check e208524064570 [] .sourceHead = true := by decide
def e208524065198 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e208524065198 : Closed e208524065198 ∧ code e208524065198 = 2407547320750 := by decide
theorem cert_e208524065198 : check e208524065198 [] .sourceHead = true := by decide
def e208524065210 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e208524065210 : Closed e208524065210 ∧ code e208524065210 = 2407547320762 := by decide
theorem cert_e208524065210 : check e208524065210 [] .sourceHead = true := by decide
def e208524065258 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e208524065258 : Closed e208524065258 ∧ code e208524065258 = 2407547320810 := by decide
theorem cert_e208524065258 : check e208524065258 [] .sourceHead = true := by decide
def e208524065390 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e208524065390 : Closed e208524065390 ∧ code e208524065390 = 2407547320942 := by decide
theorem cert_e208524065390 : check e208524065390 [] .sourceHead = true := by decide
def e208524065402 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e208524065402 : Closed e208524065402 ∧ code e208524065402 = 2407547320954 := by decide
theorem cert_e208524065402 : check e208524065402 [] .sourceHead = true := by decide
def e208524065690 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e208524065690 : Closed e208524065690 ∧ code e208524065690 = 2407547321242 := by decide
theorem cert_e208524065690 : check e208524065690 [] .sourceHead = true := by decide
def e208524066006 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e208524066006 : Closed e208524066006 ∧ code e208524066006 = 2407547321558 := by decide
theorem cert_e208524066006 : check e208524066006 [] .sourceHead = true := by decide
def e208524066010 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e208524066010 : Closed e208524066010 ∧ code e208524066010 = 2407547321562 := by decide
theorem cert_e208524066010 : check e208524066010 [] .sourceHead = true := by decide
def e208524066026 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e208524066026 : Closed e208524066026 ∧ code e208524066026 = 2407547321578 := by decide
theorem cert_e208524066026 : check e208524066026 [] .sourceHead = true := by decide
def e208524066102 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e208524066102 : Closed e208524066102 ∧ code e208524066102 = 2407547321654 := by decide
theorem cert_e208524066102 : check e208524066102 [] .sourceHead = true := by decide
def e208524066106 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e208524066106 : Closed e208524066106 ∧ code e208524066106 = 2407547321658 := by decide
theorem cert_e208524066106 : check e208524066106 [] .sourceHead = true := by decide
def e208524066202 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e208524066202 : Closed e208524066202 ∧ code e208524066202 = 2407547321754 := by decide
theorem cert_e208524066202 : check e208524066202 [] .sourceHead = true := by decide
def e208524069742 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e208524069742 : Closed e208524069742 ∧ code e208524069742 = 2407547325294 := by decide
theorem cert_e208524069742 : check e208524069742 [] .sourceHead = true := by decide
def e208524069750 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e208524069750 : Closed e208524069750 ∧ code e208524069750 = 2407547325302 := by decide
theorem cert_e208524069750 : check e208524069750 [] .sourceHead = true := by decide
def e208524069806 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e208524069806 : Closed e208524069806 ∧ code e208524069806 = 2407547325358 := by decide
theorem cert_e208524069806 : check e208524069806 [] .sourceHead = true := by decide
def e208524069818 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e208524069818 : Closed e208524069818 ∧ code e208524069818 = 2407547325370 := by decide
theorem cert_e208524069818 : check e208524069818 [] .sourceHead = true := by decide
def e208524069846 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e208524069846 : Closed e208524069846 ∧ code e208524069846 = 2407547325398 := by decide
theorem cert_e208524069846 : check e208524069846 [] .sourceHead = true := by decide
def e208524069850 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e208524069850 : Closed e208524069850 ∧ code e208524069850 = 2407547325402 := by decide
theorem cert_e208524069850 : check e208524069850 [] .sourceHead = true := by decide
def e208524070126 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e208524070126 : Closed e208524070126 ∧ code e208524070126 = 2407547325678 := by decide
theorem cert_e208524070126 : check e208524070126 [] .sourceHead = true := by decide
def e208524070134 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e208524070134 : Closed e208524070134 ∧ code e208524070134 = 2407547325686 := by decide
theorem cert_e208524070134 : check e208524070134 [] .sourceHead = true := by decide
def e208524070510 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e208524070510 : Closed e208524070510 ∧ code e208524070510 = 2407547326062 := by decide
theorem cert_e208524070510 : check e208524070510 [] .sourceHead = true := by decide
def e208524070522 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e208524070522 : Closed e208524070522 ∧ code e208524070522 = 2407547326074 := by decide
theorem cert_e208524070522 : check e208524070522 [] .sourceHead = true := by decide
def e208524070710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e208524070710 : Closed e208524070710 ∧ code e208524070710 = 2407547326262 := by decide
theorem cert_e208524070710 : check e208524070710 [] .sourceHead = true := by decide
def e208524070714 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e208524070714 : Closed e208524070714 ∧ code e208524070714 = 2407547326266 := by decide
theorem cert_e208524070714 : check e208524070714 [] .sourceHead = true := by decide
def e208524076462 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e208524076462 : Closed e208524076462 ∧ code e208524076462 = 2407547332014 := by decide
theorem cert_e208524076462 : check e208524076462 [] .sourceHead = true := by decide
def e208524076474 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e208524076474 : Closed e208524076474 ∧ code e208524076474 = 2407547332026 := by decide
theorem cert_e208524076474 : check e208524076474 [] .sourceHead = true := by decide
def e208524076522 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e208524076522 : Closed e208524076522 ∧ code e208524076522 = 2407547332074 := by decide
theorem cert_e208524076522 : check e208524076522 [] .sourceHead = true := by decide
def e208524076654 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e208524076654 : Closed e208524076654 ∧ code e208524076654 = 2407547332206 := by decide
theorem cert_e208524076654 : check e208524076654 [] .sourceHead = true := by decide
def e208524076666 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e208524076666 : Closed e208524076666 ∧ code e208524076666 = 2407547332218 := by decide
theorem cert_e208524076666 : check e208524076666 [] .sourceHead = true := by decide
def e208524076954 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e208524076954 : Closed e208524076954 ∧ code e208524076954 = 2407547332506 := by decide
theorem cert_e208524076954 : check e208524076954 [] .sourceHead = true := by decide
def e208524079830 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e208524079830 : Closed e208524079830 ∧ code e208524079830 = 2407547335382 := by decide
theorem cert_e208524079830 : check e208524079830 [] .sourceHead = true := by decide
def e208524079834 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e208524079834 : Closed e208524079834 ∧ code e208524079834 = 2407547335386 := by decide
theorem cert_e208524079834 : check e208524079834 [] .sourceHead = true := by decide
def e208524079850 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e208524079850 : Closed e208524079850 ∧ code e208524079850 = 2407547335402 := by decide
theorem cert_e208524079850 : check e208524079850 [] .sourceHead = true := by decide
def e208524079926 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e208524079926 : Closed e208524079926 ∧ code e208524079926 = 2407547335478 := by decide
theorem cert_e208524079926 : check e208524079926 [] .sourceHead = true := by decide
def e208524079930 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e208524079930 : Closed e208524079930 ∧ code e208524079930 = 2407547335482 := by decide
theorem cert_e208524079930 : check e208524079930 [] .sourceHead = true := by decide
def e208524080026 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e208524080026 : Closed e208524080026 ∧ code e208524080026 = 2407547335578 := by decide
theorem cert_e208524080026 : check e208524080026 [] .sourceHead = true := by decide
def e208524217198 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e208524217198 : Closed e208524217198 ∧ code e208524217198 = 2407547472750 := by decide
theorem cert_e208524217198 : check e208524217198 [] .sourceHead = true := by decide
def e208524217206 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e208524217206 : Closed e208524217206 ∧ code e208524217206 = 2407547472758 := by decide
theorem cert_e208524217206 : check e208524217206 [] .sourceHead = true := by decide
def e208524217262 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e208524217262 : Closed e208524217262 ∧ code e208524217262 = 2407547472814 := by decide
theorem cert_e208524217262 : check e208524217262 [] .sourceHead = true := by decide
def e208524217274 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e208524217274 : Closed e208524217274 ∧ code e208524217274 = 2407547472826 := by decide
theorem cert_e208524217274 : check e208524217274 [] .sourceHead = true := by decide
def e208524217302 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e208524217302 : Closed e208524217302 ∧ code e208524217302 = 2407547472854 := by decide
theorem cert_e208524217302 : check e208524217302 [] .sourceHead = true := by decide
def e208524217306 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e208524217306 : Closed e208524217306 ∧ code e208524217306 = 2407547472858 := by decide
theorem cert_e208524217306 : check e208524217306 [] .sourceHead = true := by decide
def e208524217582 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e208524217582 : Closed e208524217582 ∧ code e208524217582 = 2407547473134 := by decide
theorem cert_e208524217582 : check e208524217582 [] .sourceHead = true := by decide
def e208524217590 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e208524217590 : Closed e208524217590 ∧ code e208524217590 = 2407547473142 := by decide
theorem cert_e208524217590 : check e208524217590 [] .sourceHead = true := by decide
def e208524217966 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e208524217966 : Closed e208524217966 ∧ code e208524217966 = 2407547473518 := by decide
theorem cert_e208524217966 : check e208524217966 [] .sourceHead = true := by decide
def e208524217978 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e208524217978 : Closed e208524217978 ∧ code e208524217978 = 2407547473530 := by decide
theorem cert_e208524217978 : check e208524217978 [] .sourceHead = true := by decide
def e208524218166 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e208524218166 : Closed e208524218166 ∧ code e208524218166 = 2407547473718 := by decide
theorem cert_e208524218166 : check e208524218166 [] .sourceHead = true := by decide
def e208524218170 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e208524218170 : Closed e208524218170 ∧ code e208524218170 = 2407547473722 := by decide
theorem cert_e208524218170 : check e208524218170 [] .sourceHead = true := by decide
def e208524807022 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e208524807022 : Closed e208524807022 ∧ code e208524807022 = 2407548062574 := by decide
theorem cert_e208524807022 : check e208524807022 [] .sourceHead = true := by decide
def e208524807030 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e208524807030 : Closed e208524807030 ∧ code e208524807030 = 2407548062582 := by decide
theorem cert_e208524807030 : check e208524807030 [] .sourceHead = true := by decide
def e208524807086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e208524807086 : Closed e208524807086 ∧ code e208524807086 = 2407548062638 := by decide
theorem cert_e208524807086 : check e208524807086 [] .sourceHead = true := by decide
def e208524807098 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e208524807098 : Closed e208524807098 ∧ code e208524807098 = 2407548062650 := by decide
theorem cert_e208524807098 : check e208524807098 [] .sourceHead = true := by decide
def e208524807126 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e208524807126 : Closed e208524807126 ∧ code e208524807126 = 2407548062678 := by decide
theorem cert_e208524807126 : check e208524807126 [] .sourceHead = true := by decide
def e208524807130 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e208524807130 : Closed e208524807130 ∧ code e208524807130 = 2407548062682 := by decide
theorem cert_e208524807130 : check e208524807130 [] .sourceHead = true := by decide
def e208524807406 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e208524807406 : Closed e208524807406 ∧ code e208524807406 = 2407548062958 := by decide
theorem cert_e208524807406 : check e208524807406 [] .sourceHead = true := by decide
def e208524807414 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e208524807414 : Closed e208524807414 ∧ code e208524807414 = 2407548062966 := by decide
theorem cert_e208524807414 : check e208524807414 [] .sourceHead = true := by decide
def e208524807790 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e208524807790 : Closed e208524807790 ∧ code e208524807790 = 2407548063342 := by decide
theorem cert_e208524807790 : check e208524807790 [] .sourceHead = true := by decide
def e208524807802 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e208524807802 : Closed e208524807802 ∧ code e208524807802 = 2407548063354 := by decide
theorem cert_e208524807802 : check e208524807802 [] .sourceHead = true := by decide
def e208524807990 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e208524807990 : Closed e208524807990 ∧ code e208524807990 = 2407548063542 := by decide
theorem cert_e208524807990 : check e208524807990 [] .sourceHead = true := by decide
def e208524807994 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e208524807994 : Closed e208524807994 ∧ code e208524807994 = 2407548063546 := by decide
theorem cert_e208524807994 : check e208524807994 [] .sourceHead = true := by decide
def e215556667418 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e215556667418 : Closed e215556667418 ∧ code e215556667418 = 2414579922970 := by decide
theorem cert_e215556667418 : check e215556667418 [] .sourceHead = true := by decide
def e215556675610 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e215556675610 : Closed e215556675610 ∧ code e215556675610 = 2414579931162 := by decide
theorem cert_e215556675610 : check e215556675610 [] .sourceHead = true := by decide
def e215556732954 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e215556732954 : Closed e215556732954 ∧ code e215556732954 = 2414579988506 := by decide
theorem cert_e215556732954 : check e215556732954 [] .sourceHead = true := by decide
def e215556745242 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e215556745242 : Closed e215556745242 ∧ code e215556745242 = 2414580000794 := by decide
theorem cert_e215556745242 : check e215556745242 [] .sourceHead = true := by decide
def e215556773914 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e215556773914 : Closed e215556773914 ∧ code e215556773914 = 2414580029466 := by decide
theorem cert_e215556773914 : check e215556773914 [] .sourceHead = true := by decide
def e215556778010 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e215556778010 : Closed e215556778010 ∧ code e215556778010 = 2414580033562 := by decide
theorem cert_e215556778010 : check e215556778010 [] .sourceHead = true := by decide
def e215557060634 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e215557060634 : Closed e215557060634 ∧ code e215557060634 = 2414580316186 := by decide
theorem cert_e215557060634 : check e215557060634 [] .sourceHead = true := by decide
def e215557068826 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e215557068826 : Closed e215557068826 ∧ code e215557068826 = 2414580324378 := by decide
theorem cert_e215557068826 : check e215557068826 [] .sourceHead = true := by decide
def e215557453850 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e215557453850 : Closed e215557453850 ∧ code e215557453850 = 2414580709402 := by decide
theorem cert_e215557453850 : check e215557453850 [] .sourceHead = true := by decide
def e215557466138 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e215557466138 : Closed e215557466138 ∧ code e215557466138 = 2414580721690 := by decide
theorem cert_e215557466138 : check e215557466138 [] .sourceHead = true := by decide
def e215557658650 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e215557658650 : Closed e215557658650 ∧ code e215557658650 = 2414580914202 := by decide
theorem cert_e215557658650 : check e215557658650 [] .sourceHead = true := by decide
def e215557662746 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e215557662746 : Closed e215557662746 ∧ code e215557662746 = 2414580918298 := by decide
theorem cert_e215557662746 : check e215557662746 [] .sourceHead = true := by decide
def e215620824430 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e215620824430 : Closed e215620824430 ∧ code e215620824430 = 2414644079982 := by decide
theorem cert_e215620824430 : check e215620824430 [] .sourceHead = true := by decide
def e215620824438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e215620824438 : Closed e215620824438 ∧ code e215620824438 = 2414644079990 := by decide
theorem cert_e215620824438 : check e215620824438 [] .sourceHead = true := by decide
def e215620824494 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e215620824494 : Closed e215620824494 ∧ code e215620824494 = 2414644080046 := by decide
theorem cert_e215620824494 : check e215620824494 [] .sourceHead = true := by decide
def e215620824506 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e215620824506 : Closed e215620824506 ∧ code e215620824506 = 2414644080058 := by decide
theorem cert_e215620824506 : check e215620824506 [] .sourceHead = true := by decide
def e215620824534 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e215620824534 : Closed e215620824534 ∧ code e215620824534 = 2414644080086 := by decide
theorem cert_e215620824534 : check e215620824534 [] .sourceHead = true := by decide
def e215620824538 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e215620824538 : Closed e215620824538 ∧ code e215620824538 = 2414644080090 := by decide
theorem cert_e215620824538 : check e215620824538 [] .sourceHead = true := by decide
def e215620824750 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e215620824750 : Closed e215620824750 ∧ code e215620824750 = 2414644080302 := by decide
theorem cert_e215620824750 : check e215620824750 [] .sourceHead = true := by decide
def e215620824762 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e215620824762 : Closed e215620824762 ∧ code e215620824762 = 2414644080314 := by decide
theorem cert_e215620824762 : check e215620824762 [] .sourceHead = true := by decide
def e215620824810 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e215620824810 : Closed e215620824810 ∧ code e215620824810 = 2414644080362 := by decide
theorem cert_e215620824810 : check e215620824810 [] .sourceHead = true := by decide
def e215620824918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e215620824918 : Closed e215620824918 ∧ code e215620824918 = 2414644080470 := by decide
theorem cert_e215620824918 : check e215620824918 [] .sourceHead = true := by decide
def e215620824922 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e215620824922 : Closed e215620824922 ∧ code e215620824922 = 2414644080474 := by decide
theorem cert_e215620824922 : check e215620824922 [] .sourceHead = true := by decide
def e215620824938 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e215620824938 : Closed e215620824938 ∧ code e215620824938 = 2414644080490 := by decide
theorem cert_e215620824938 : check e215620824938 [] .sourceHead = true := by decide
def e215620825966 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e215620825966 : Closed e215620825966 ∧ code e215620825966 = 2414644081518 := by decide
theorem cert_e215620825966 : check e215620825966 [] .sourceHead = true := by decide
def e215620825974 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e215620825974 : Closed e215620825974 ∧ code e215620825974 = 2414644081526 := by decide
theorem cert_e215620825974 : check e215620825974 [] .sourceHead = true := by decide
def e215620826030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e215620826030 : Closed e215620826030 ∧ code e215620826030 = 2414644081582 := by decide
theorem cert_e215620826030 : check e215620826030 [] .sourceHead = true := by decide
def e215620826042 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e215620826042 : Closed e215620826042 ∧ code e215620826042 = 2414644081594 := by decide
theorem cert_e215620826042 : check e215620826042 [] .sourceHead = true := by decide
def e215620826070 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e215620826070 : Closed e215620826070 ∧ code e215620826070 = 2414644081622 := by decide
theorem cert_e215620826070 : check e215620826070 [] .sourceHead = true := by decide
def e215620826074 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e215620826074 : Closed e215620826074 ∧ code e215620826074 = 2414644081626 := by decide
theorem cert_e215620826074 : check e215620826074 [] .sourceHead = true := by decide
def e215620826350 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e215620826350 : Closed e215620826350 ∧ code e215620826350 = 2414644081902 := by decide
theorem cert_e215620826350 : check e215620826350 [] .sourceHead = true := by decide
def e215620826358 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e215620826358 : Closed e215620826358 ∧ code e215620826358 = 2414644081910 := by decide
theorem cert_e215620826358 : check e215620826358 [] .sourceHead = true := by decide
def e215620826734 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e215620826734 : Closed e215620826734 ∧ code e215620826734 = 2414644082286 := by decide
theorem cert_e215620826734 : check e215620826734 [] .sourceHead = true := by decide
def e215620826746 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e215620826746 : Closed e215620826746 ∧ code e215620826746 = 2414644082298 := by decide
theorem cert_e215620826746 : check e215620826746 [] .sourceHead = true := by decide
def e215620826934 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e215620826934 : Closed e215620826934 ∧ code e215620826934 = 2414644082486 := by decide
theorem cert_e215620826934 : check e215620826934 [] .sourceHead = true := by decide
def e215620826938 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e215620826938 : Closed e215620826938 ∧ code e215620826938 = 2414644082490 := by decide
theorem cert_e215620826938 : check e215620826938 [] .sourceHead = true := by decide
def e215620827566 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e215620827566 : Closed e215620827566 ∧ code e215620827566 = 2414644083118 := by decide
theorem cert_e215620827566 : check e215620827566 [] .sourceHead = true := by decide
def e215620827578 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e215620827578 : Closed e215620827578 ∧ code e215620827578 = 2414644083130 := by decide
theorem cert_e215620827578 : check e215620827578 [] .sourceHead = true := by decide
def e215620827626 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e215620827626 : Closed e215620827626 ∧ code e215620827626 = 2414644083178 := by decide
theorem cert_e215620827626 : check e215620827626 [] .sourceHead = true := by decide
def e215620827758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e215620827758 : Closed e215620827758 ∧ code e215620827758 = 2414644083310 := by decide
theorem cert_e215620827758 : check e215620827758 [] .sourceHead = true := by decide
def e215620827770 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e215620827770 : Closed e215620827770 ∧ code e215620827770 = 2414644083322 := by decide
theorem cert_e215620827770 : check e215620827770 [] .sourceHead = true := by decide
def e215620828058 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e215620828058 : Closed e215620828058 ∧ code e215620828058 = 2414644083610 := by decide
theorem cert_e215620828058 : check e215620828058 [] .sourceHead = true := by decide
def e215620828374 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e215620828374 : Closed e215620828374 ∧ code e215620828374 = 2414644083926 := by decide
theorem cert_e215620828374 : check e215620828374 [] .sourceHead = true := by decide
def e215620828378 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e215620828378 : Closed e215620828378 ∧ code e215620828378 = 2414644083930 := by decide
theorem cert_e215620828378 : check e215620828378 [] .sourceHead = true := by decide
def e215620828394 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e215620828394 : Closed e215620828394 ∧ code e215620828394 = 2414644083946 := by decide
theorem cert_e215620828394 : check e215620828394 [] .sourceHead = true := by decide
def e215620828470 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e215620828470 : Closed e215620828470 ∧ code e215620828470 = 2414644084022 := by decide
theorem cert_e215620828470 : check e215620828470 [] .sourceHead = true := by decide
def e215620828474 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e215620828474 : Closed e215620828474 ∧ code e215620828474 = 2414644084026 := by decide
theorem cert_e215620828474 : check e215620828474 [] .sourceHead = true := by decide
def e215620828570 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e215620828570 : Closed e215620828570 ∧ code e215620828570 = 2414644084122 := by decide
theorem cert_e215620828570 : check e215620828570 [] .sourceHead = true := by decide
def e215620832110 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e215620832110 : Closed e215620832110 ∧ code e215620832110 = 2414644087662 := by decide
theorem cert_e215620832110 : check e215620832110 [] .sourceHead = true := by decide
def e215620832118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e215620832118 : Closed e215620832118 ∧ code e215620832118 = 2414644087670 := by decide
theorem cert_e215620832118 : check e215620832118 [] .sourceHead = true := by decide
def e215620832174 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e215620832174 : Closed e215620832174 ∧ code e215620832174 = 2414644087726 := by decide
theorem cert_e215620832174 : check e215620832174 [] .sourceHead = true := by decide
def e215620832186 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e215620832186 : Closed e215620832186 ∧ code e215620832186 = 2414644087738 := by decide
theorem cert_e215620832186 : check e215620832186 [] .sourceHead = true := by decide
def e215620832214 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e215620832214 : Closed e215620832214 ∧ code e215620832214 = 2414644087766 := by decide
theorem cert_e215620832214 : check e215620832214 [] .sourceHead = true := by decide
def e215620832218 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e215620832218 : Closed e215620832218 ∧ code e215620832218 = 2414644087770 := by decide
theorem cert_e215620832218 : check e215620832218 [] .sourceHead = true := by decide
def e215620832494 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e215620832494 : Closed e215620832494 ∧ code e215620832494 = 2414644088046 := by decide
theorem cert_e215620832494 : check e215620832494 [] .sourceHead = true := by decide
def e215620832502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e215620832502 : Closed e215620832502 ∧ code e215620832502 = 2414644088054 := by decide
theorem cert_e215620832502 : check e215620832502 [] .sourceHead = true := by decide
def e215620832878 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e215620832878 : Closed e215620832878 ∧ code e215620832878 = 2414644088430 := by decide
theorem cert_e215620832878 : check e215620832878 [] .sourceHead = true := by decide
def e215620832890 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e215620832890 : Closed e215620832890 ∧ code e215620832890 = 2414644088442 := by decide
theorem cert_e215620832890 : check e215620832890 [] .sourceHead = true := by decide
def e215620833078 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e215620833078 : Closed e215620833078 ∧ code e215620833078 = 2414644088630 := by decide
theorem cert_e215620833078 : check e215620833078 [] .sourceHead = true := by decide
def e215620833082 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e215620833082 : Closed e215620833082 ∧ code e215620833082 = 2414644088634 := by decide
theorem cert_e215620833082 : check e215620833082 [] .sourceHead = true := by decide
def e215620838830 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e215620838830 : Closed e215620838830 ∧ code e215620838830 = 2414644094382 := by decide
theorem cert_e215620838830 : check e215620838830 [] .sourceHead = true := by decide
def e215620838842 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e215620838842 : Closed e215620838842 ∧ code e215620838842 = 2414644094394 := by decide
theorem cert_e215620838842 : check e215620838842 [] .sourceHead = true := by decide
def e215620838890 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e215620838890 : Closed e215620838890 ∧ code e215620838890 = 2414644094442 := by decide
theorem cert_e215620838890 : check e215620838890 [] .sourceHead = true := by decide
def e215620839022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e215620839022 : Closed e215620839022 ∧ code e215620839022 = 2414644094574 := by decide
theorem cert_e215620839022 : check e215620839022 [] .sourceHead = true := by decide
def e215620839034 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e215620839034 : Closed e215620839034 ∧ code e215620839034 = 2414644094586 := by decide
theorem cert_e215620839034 : check e215620839034 [] .sourceHead = true := by decide
def e215620839322 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e215620839322 : Closed e215620839322 ∧ code e215620839322 = 2414644094874 := by decide
theorem cert_e215620839322 : check e215620839322 [] .sourceHead = true := by decide
def e215620842198 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e215620842198 : Closed e215620842198 ∧ code e215620842198 = 2414644097750 := by decide
theorem cert_e215620842198 : check e215620842198 [] .sourceHead = true := by decide
def e215620842202 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e215620842202 : Closed e215620842202 ∧ code e215620842202 = 2414644097754 := by decide
theorem cert_e215620842202 : check e215620842202 [] .sourceHead = true := by decide
def e215620842218 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e215620842218 : Closed e215620842218 ∧ code e215620842218 = 2414644097770 := by decide
theorem cert_e215620842218 : check e215620842218 [] .sourceHead = true := by decide
def e215620842294 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e215620842294 : Closed e215620842294 ∧ code e215620842294 = 2414644097846 := by decide
theorem cert_e215620842294 : check e215620842294 [] .sourceHead = true := by decide
def e215620842298 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e215620842298 : Closed e215620842298 ∧ code e215620842298 = 2414644097850 := by decide
theorem cert_e215620842298 : check e215620842298 [] .sourceHead = true := by decide
def e215620842394 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e215620842394 : Closed e215620842394 ∧ code e215620842394 = 2414644097946 := by decide
theorem cert_e215620842394 : check e215620842394 [] .sourceHead = true := by decide
def e215620957934 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e215620957934 : Closed e215620957934 ∧ code e215620957934 = 2414644213486 := by decide
theorem cert_e215620957934 : check e215620957934 [] .sourceHead = true := by decide
def e215620958062 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e215620958062 : Closed e215620958062 ∧ code e215620958062 = 2414644213614 := by decide
theorem cert_e215620958062 : check e215620958062 [] .sourceHead = true := by decide
def e215620958070 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e215620958070 : Closed e215620958070 ∧ code e215620958070 = 2414644213622 := by decide
theorem cert_e215620958070 : check e215620958070 [] .sourceHead = true := by decide
def e215620958958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e215620958958 : Closed e215620958958 ∧ code e215620958958 = 2414644214510 := by decide
theorem cert_e215620958958 : check e215620958958 [] .sourceHead = true := by decide
def e215620959150 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e215620959150 : Closed e215620959150 ∧ code e215620959150 = 2414644214702 := by decide
theorem cert_e215620959150 : check e215620959150 [] .sourceHead = true := by decide
def e215620959162 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e215620959162 : Closed e215620959162 ∧ code e215620959162 = 2414644214714 := by decide
theorem cert_e215620959162 : check e215620959162 [] .sourceHead = true := by decide
def e215620959598 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e215620959598 : Closed e215620959598 ∧ code e215620959598 = 2414644215150 := by decide
theorem cert_e215620959598 : check e215620959598 [] .sourceHead = true := by decide
def e215620959606 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e215620959606 : Closed e215620959606 ∧ code e215620959606 = 2414644215158 := by decide
theorem cert_e215620959606 : check e215620959606 [] .sourceHead = true := by decide
def e215620959662 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e215620959662 : Closed e215620959662 ∧ code e215620959662 = 2414644215214 := by decide
theorem cert_e215620959662 : check e215620959662 [] .sourceHead = true := by decide
def e215620959674 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e215620959674 : Closed e215620959674 ∧ code e215620959674 = 2414644215226 := by decide
theorem cert_e215620959674 : check e215620959674 [] .sourceHead = true := by decide
def e215620959702 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e215620959702 : Closed e215620959702 ∧ code e215620959702 = 2414644215254 := by decide
theorem cert_e215620959702 : check e215620959702 [] .sourceHead = true := by decide
def e215620959706 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e215620959706 : Closed e215620959706 ∧ code e215620959706 = 2414644215258 := by decide
theorem cert_e215620959706 : check e215620959706 [] .sourceHead = true := by decide
end Blc.Floor41
