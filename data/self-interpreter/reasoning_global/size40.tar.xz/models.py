from candidates import *
import itertools
def operations(n):
    rows=list(itertools.combinations_with_replacement(range(n),n))
    def extend(acc):
        if len(acc)==n-1:
            yield tuple(acc+[(n-1,)*n]);return
        for row in rows:
            if not acc or all(a<=b for a,b in zip(acc[-1],row)):
                yield from extend(acc+[row])
    yield from extend([])
def abstract(op, xs):
    return next(i for i in range(1,len(op)) if all(a<=b for a,b in zip(xs,op[i])))
def run(op,e,env=()):
    if e[0]=='V':return env[e[1]]
    if e[0]=='A':return op[run(op,e[1],env)][run(op,e[2],env)]
    return abstract(op,[run(op,e[1],(x,)+env) for x in range(len(op))])
