import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e70610511386 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e70610511386 : Closed e70610511386 ∧ code e70610511386 = 1170122139162 := by decide
theorem cert_e70610511386 : check e70610511386 [[.under]] .width = true := by decide
def e70610544154 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e70610544154 : Closed e70610544154 ∧ code e70610544154 = 1170122171930 := by decide
theorem cert_e70610544154 : check e70610544154 [[.under]] .width = true := by decide
def e70610773530 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e70610773530 : Closed e70610773530 ∧ code e70610773530 = 1170122401306 := by decide
theorem cert_e70610773530 : check e70610773530 [[.under]] .width = true := by decide
def e70610822682 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e70610822682 : Closed e70610822682 ∧ code e70610822682 = 1170122450458 := by decide
theorem cert_e70610822682 : check e70610822682 [[.under]] .width = true := by decide
def e70610937370 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e70610937370 : Closed e70610937370 ∧ code e70610937370 = 1170122565146 := by decide
theorem cert_e70610937370 : check e70610937370 [[.under]] .width = true := by decide
def e70610953754 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e70610953754 : Closed e70610953754 ∧ code e70610953754 = 1170122581530 := by decide
theorem cert_e70610953754 : check e70610953754 [[.under]] .width = true := by decide
def e70612084250 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e70612084250 : Closed e70612084250 ∧ code e70612084250 = 1170123712026 := by decide
theorem cert_e70612084250 : check e70612084250 [[.under]] .width = true := by decide
def e70612117018 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e70612117018 : Closed e70612117018 ∧ code e70612117018 = 1170123744794 := by decide
theorem cert_e70612117018 : check e70612117018 [[.under]] .width = true := by decide
def e70613657114 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e70613657114 : Closed e70613657114 ∧ code e70613657114 = 1170125284890 := by decide
theorem cert_e70613657114 : check e70613657114 [[.under]] .width = true := by decide
def e70613706266 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e70613706266 : Closed e70613706266 ∧ code e70613706266 = 1170125334042 := by decide
theorem cert_e70613706266 : check e70613706266 [[.under]] .width = true := by decide
def e70614476314 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e70614476314 : Closed e70614476314 ∧ code e70614476314 = 1170126104090 := by decide
theorem cert_e70614476314 : check e70614476314 [[.under]] .width = true := by decide
def e70614492698 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e70614492698 : Closed e70614492698 ∧ code e70614492698 = 1170126120474 := by decide
theorem cert_e70614492698 : check e70614492698 [[.under]] .width = true := by decide
def e74809650542 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e74809650542 : Closed e74809650542 ∧ code e74809650542 = 1174321278318 := by decide
theorem cert_e74809650542 : check e74809650542 [[.under],[.under,.left]] .chain = true := by decide
def e74809650550 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e74809650550 : Closed e74809650550 ∧ code e74809650550 = 1174321278326 := by decide
theorem cert_e74809650550 : check e74809650550 [[.under],[.under,.left]] .chain = true := by decide
def e74809650606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e74809650606 : Closed e74809650606 ∧ code e74809650606 = 1174321278382 := by decide
theorem cert_e74809650606 : check e74809650606 [[.under],[.under,.left]] .chain = true := by decide
def e74809650618 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e74809650618 : Closed e74809650618 ∧ code e74809650618 = 1174321278394 := by decide
theorem cert_e74809650618 : check e74809650618 [[.under],[.under,.left]] .chain = true := by decide
def e74809650646 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e74809650646 : Closed e74809650646 ∧ code e74809650646 = 1174321278422 := by decide
theorem cert_e74809650646 : check e74809650646 [[.under],[.under,.left]] .chain = true := by decide
def e74809650650 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e74809650650 : Closed e74809650650 ∧ code e74809650650 = 1174321278426 := by decide
theorem cert_e74809650650 : check e74809650650 [[.under],[.under,.left]] .chain = true := by decide
def e74809650862 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e74809650862 : Closed e74809650862 ∧ code e74809650862 = 1174321278638 := by decide
theorem cert_e74809650862 : check e74809650862 [[.under],[.under,.left]] .chain = true := by decide
def e74809650874 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e74809650874 : Closed e74809650874 ∧ code e74809650874 = 1174321278650 := by decide
theorem cert_e74809650874 : check e74809650874 [[.under],[.under,.left]] .chain = true := by decide
def e74809650922 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e74809650922 : Closed e74809650922 ∧ code e74809650922 = 1174321278698 := by decide
theorem cert_e74809650922 : check e74809650922 [[.under],[.under,.left]] .chain = true := by decide
def e74809651030 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e74809651030 : Closed e74809651030 ∧ code e74809651030 = 1174321278806 := by decide
theorem cert_e74809651030 : check e74809651030 [[.under],[.under,.left]] .chain = true := by decide
def e74809651034 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e74809651034 : Closed e74809651034 ∧ code e74809651034 = 1174321278810 := by decide
theorem cert_e74809651034 : check e74809651034 [[.under],[.under,.left]] .chain = true := by decide
def e74809651050 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e74809651050 : Closed e74809651050 ∧ code e74809651050 = 1174321278826 := by decide
theorem cert_e74809651050 : check e74809651050 [[.under],[.under,.left]] .chain = true := by decide
def e74809652078 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e74809652078 : Closed e74809652078 ∧ code e74809652078 = 1174321279854 := by decide
theorem cert_e74809652078 : check e74809652078 [[.under],[.under,.left]] .chain = true := by decide
def e74809652086 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e74809652086 : Closed e74809652086 ∧ code e74809652086 = 1174321279862 := by decide
theorem cert_e74809652086 : check e74809652086 [[.under],[.under,.left]] .chain = true := by decide
def e74809652142 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e74809652142 : Closed e74809652142 ∧ code e74809652142 = 1174321279918 := by decide
theorem cert_e74809652142 : check e74809652142 [[.under],[.under,.left]] .chain = true := by decide
def e74809652154 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e74809652154 : Closed e74809652154 ∧ code e74809652154 = 1174321279930 := by decide
theorem cert_e74809652154 : check e74809652154 [[.under],[.under,.left]] .chain = true := by decide
def e74809652182 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e74809652182 : Closed e74809652182 ∧ code e74809652182 = 1174321279958 := by decide
theorem cert_e74809652182 : check e74809652182 [[.under],[.under,.left]] .chain = true := by decide
def e74809652186 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e74809652186 : Closed e74809652186 ∧ code e74809652186 = 1174321279962 := by decide
theorem cert_e74809652186 : check e74809652186 [[.under],[.under,.left]] .chain = true := by decide
def e74809652462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e74809652462 : Closed e74809652462 ∧ code e74809652462 = 1174321280238 := by decide
theorem cert_e74809652462 : check e74809652462 [[.under],[.under,.left]] .chain = true := by decide
def e74809652470 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e74809652470 : Closed e74809652470 ∧ code e74809652470 = 1174321280246 := by decide
theorem cert_e74809652470 : check e74809652470 [[.under],[.under,.left]] .chain = true := by decide
def e74809652846 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e74809652846 : Closed e74809652846 ∧ code e74809652846 = 1174321280622 := by decide
theorem cert_e74809652846 : check e74809652846 [[.under],[.under,.left]] .chain = true := by decide
def e74809652858 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e74809652858 : Closed e74809652858 ∧ code e74809652858 = 1174321280634 := by decide
theorem cert_e74809652858 : check e74809652858 [[.under],[.under,.left]] .chain = true := by decide
def e74809653046 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e74809653046 : Closed e74809653046 ∧ code e74809653046 = 1174321280822 := by decide
theorem cert_e74809653046 : check e74809653046 [[.under],[.under,.left]] .chain = true := by decide
def e74809653050 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e74809653050 : Closed e74809653050 ∧ code e74809653050 = 1174321280826 := by decide
theorem cert_e74809653050 : check e74809653050 [[.under],[.under,.left]] .chain = true := by decide
def e74809653678 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e74809653678 : Closed e74809653678 ∧ code e74809653678 = 1174321281454 := by decide
theorem cert_e74809653678 : check e74809653678 [[.under],[.under,.left]] .chain = true := by decide
def e74809653690 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e74809653690 : Closed e74809653690 ∧ code e74809653690 = 1174321281466 := by decide
theorem cert_e74809653690 : check e74809653690 [[.under],[.under,.left]] .chain = true := by decide
def e74809653738 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e74809653738 : Closed e74809653738 ∧ code e74809653738 = 1174321281514 := by decide
theorem cert_e74809653738 : check e74809653738 [[.under],[.under,.left]] .chain = true := by decide
def e74809653870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e74809653870 : Closed e74809653870 ∧ code e74809653870 = 1174321281646 := by decide
theorem cert_e74809653870 : check e74809653870 [[.under],[.under,.left]] .chain = true := by decide
def e74809653882 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e74809653882 : Closed e74809653882 ∧ code e74809653882 = 1174321281658 := by decide
theorem cert_e74809653882 : check e74809653882 [[.under],[.under,.left]] .chain = true := by decide
def e74809654170 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e74809654170 : Closed e74809654170 ∧ code e74809654170 = 1174321281946 := by decide
theorem cert_e74809654170 : check e74809654170 [[.under],[.under,.left]] .chain = true := by decide
def e74809654486 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e74809654486 : Closed e74809654486 ∧ code e74809654486 = 1174321282262 := by decide
theorem cert_e74809654486 : check e74809654486 [[.under],[.under,.left]] .chain = true := by decide
def e74809654490 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e74809654490 : Closed e74809654490 ∧ code e74809654490 = 1174321282266 := by decide
theorem cert_e74809654490 : check e74809654490 [[.under],[.under,.left]] .chain = true := by decide
def e74809654506 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e74809654506 : Closed e74809654506 ∧ code e74809654506 = 1174321282282 := by decide
theorem cert_e74809654506 : check e74809654506 [[.under],[.under,.left]] .chain = true := by decide
def e74809654582 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e74809654582 : Closed e74809654582 ∧ code e74809654582 = 1174321282358 := by decide
theorem cert_e74809654582 : check e74809654582 [[.under],[.under,.left]] .chain = true := by decide
def e74809654586 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e74809654586 : Closed e74809654586 ∧ code e74809654586 = 1174321282362 := by decide
theorem cert_e74809654586 : check e74809654586 [[.under],[.under,.left]] .chain = true := by decide
def e74809654682 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e74809654682 : Closed e74809654682 ∧ code e74809654682 = 1174321282458 := by decide
theorem cert_e74809654682 : check e74809654682 [[.under],[.under,.left]] .chain = true := by decide
def e74809658222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e74809658222 : Closed e74809658222 ∧ code e74809658222 = 1174321285998 := by decide
theorem cert_e74809658222 : check e74809658222 [[.under],[.under,.left]] .chain = true := by decide
def e74809658230 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e74809658230 : Closed e74809658230 ∧ code e74809658230 = 1174321286006 := by decide
theorem cert_e74809658230 : check e74809658230 [[.under],[.under,.left]] .chain = true := by decide
def e74809658286 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e74809658286 : Closed e74809658286 ∧ code e74809658286 = 1174321286062 := by decide
theorem cert_e74809658286 : check e74809658286 [[.under],[.under,.left]] .chain = true := by decide
def e74809658298 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e74809658298 : Closed e74809658298 ∧ code e74809658298 = 1174321286074 := by decide
theorem cert_e74809658298 : check e74809658298 [[.under],[.under,.left]] .chain = true := by decide
def e74809658326 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e74809658326 : Closed e74809658326 ∧ code e74809658326 = 1174321286102 := by decide
theorem cert_e74809658326 : check e74809658326 [[.under],[.under,.left]] .chain = true := by decide
def e74809658330 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e74809658330 : Closed e74809658330 ∧ code e74809658330 = 1174321286106 := by decide
theorem cert_e74809658330 : check e74809658330 [[.under],[.under,.left]] .chain = true := by decide
def e74809658606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e74809658606 : Closed e74809658606 ∧ code e74809658606 = 1174321286382 := by decide
theorem cert_e74809658606 : check e74809658606 [[.under],[.under,.left]] .chain = true := by decide
def e74809658614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e74809658614 : Closed e74809658614 ∧ code e74809658614 = 1174321286390 := by decide
theorem cert_e74809658614 : check e74809658614 [[.under],[.under,.left]] .chain = true := by decide
def e74809658990 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e74809658990 : Closed e74809658990 ∧ code e74809658990 = 1174321286766 := by decide
theorem cert_e74809658990 : check e74809658990 [[.under],[.under,.left]] .chain = true := by decide
def e74809659002 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e74809659002 : Closed e74809659002 ∧ code e74809659002 = 1174321286778 := by decide
theorem cert_e74809659002 : check e74809659002 [[.under],[.under,.left]] .chain = true := by decide
def e74809659190 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e74809659190 : Closed e74809659190 ∧ code e74809659190 = 1174321286966 := by decide
theorem cert_e74809659190 : check e74809659190 [[.under],[.under,.left]] .chain = true := by decide
def e74809659194 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e74809659194 : Closed e74809659194 ∧ code e74809659194 = 1174321286970 := by decide
theorem cert_e74809659194 : check e74809659194 [[.under],[.under,.left]] .chain = true := by decide
def e74809664942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e74809664942 : Closed e74809664942 ∧ code e74809664942 = 1174321292718 := by decide
theorem cert_e74809664942 : check e74809664942 [[.under],[.under,.left]] .chain = true := by decide
def e74809664954 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e74809664954 : Closed e74809664954 ∧ code e74809664954 = 1174321292730 := by decide
theorem cert_e74809664954 : check e74809664954 [[.under],[.under,.left]] .chain = true := by decide
def e74809665002 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e74809665002 : Closed e74809665002 ∧ code e74809665002 = 1174321292778 := by decide
theorem cert_e74809665002 : check e74809665002 [[.under],[.under,.left]] .chain = true := by decide
def e74809665134 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e74809665134 : Closed e74809665134 ∧ code e74809665134 = 1174321292910 := by decide
theorem cert_e74809665134 : check e74809665134 [[.under],[.under,.left]] .chain = true := by decide
def e74809665146 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e74809665146 : Closed e74809665146 ∧ code e74809665146 = 1174321292922 := by decide
theorem cert_e74809665146 : check e74809665146 [[.under],[.under,.left]] .chain = true := by decide
def e74809665434 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e74809665434 : Closed e74809665434 ∧ code e74809665434 = 1174321293210 := by decide
theorem cert_e74809665434 : check e74809665434 [[.under],[.under,.left]] .chain = true := by decide
def e74809668310 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e74809668310 : Closed e74809668310 ∧ code e74809668310 = 1174321296086 := by decide
theorem cert_e74809668310 : check e74809668310 [[.under],[.under,.left]] .chain = true := by decide
def e74809668314 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e74809668314 : Closed e74809668314 ∧ code e74809668314 = 1174321296090 := by decide
theorem cert_e74809668314 : check e74809668314 [[.under],[.under,.left]] .chain = true := by decide
def e74809668330 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e74809668330 : Closed e74809668330 ∧ code e74809668330 = 1174321296106 := by decide
theorem cert_e74809668330 : check e74809668330 [[.under],[.under,.left]] .chain = true := by decide
def e74809668406 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e74809668406 : Closed e74809668406 ∧ code e74809668406 = 1174321296182 := by decide
theorem cert_e74809668406 : check e74809668406 [[.under],[.under,.left]] .chain = true := by decide
def e74809668410 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e74809668410 : Closed e74809668410 ∧ code e74809668410 = 1174321296186 := by decide
theorem cert_e74809668410 : check e74809668410 [[.under],[.under,.left]] .chain = true := by decide
def e74809668506 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e74809668506 : Closed e74809668506 ∧ code e74809668506 = 1174321296282 := by decide
theorem cert_e74809668506 : check e74809668506 [[.under],[.under,.left]] .chain = true := by decide
def e74809805678 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e74809805678 : Closed e74809805678 ∧ code e74809805678 = 1174321433454 := by decide
theorem cert_e74809805678 : check e74809805678 [[.under],[.under,.left]] .chain = true := by decide
def e74809805686 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e74809805686 : Closed e74809805686 ∧ code e74809805686 = 1174321433462 := by decide
theorem cert_e74809805686 : check e74809805686 [[.under],[.under,.left]] .chain = true := by decide
def e74809805742 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e74809805742 : Closed e74809805742 ∧ code e74809805742 = 1174321433518 := by decide
theorem cert_e74809805742 : check e74809805742 [[.under],[.under,.left]] .chain = true := by decide
def e74809805754 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e74809805754 : Closed e74809805754 ∧ code e74809805754 = 1174321433530 := by decide
theorem cert_e74809805754 : check e74809805754 [[.under],[.under,.left]] .chain = true := by decide
def e74809805782 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e74809805782 : Closed e74809805782 ∧ code e74809805782 = 1174321433558 := by decide
theorem cert_e74809805782 : check e74809805782 [[.under],[.under,.left]] .chain = true := by decide
def e74809805786 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e74809805786 : Closed e74809805786 ∧ code e74809805786 = 1174321433562 := by decide
theorem cert_e74809805786 : check e74809805786 [[.under],[.under,.left]] .chain = true := by decide
def e74809806062 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e74809806062 : Closed e74809806062 ∧ code e74809806062 = 1174321433838 := by decide
theorem cert_e74809806062 : check e74809806062 [[.under],[.under,.left]] .chain = true := by decide
def e74809806070 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e74809806070 : Closed e74809806070 ∧ code e74809806070 = 1174321433846 := by decide
theorem cert_e74809806070 : check e74809806070 [[.under],[.under,.left]] .chain = true := by decide
def e74809806446 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e74809806446 : Closed e74809806446 ∧ code e74809806446 = 1174321434222 := by decide
theorem cert_e74809806446 : check e74809806446 [[.under],[.under,.left]] .chain = true := by decide
def e74809806458 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e74809806458 : Closed e74809806458 ∧ code e74809806458 = 1174321434234 := by decide
theorem cert_e74809806458 : check e74809806458 [[.under],[.under,.left]] .chain = true := by decide
def e74809806646 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e74809806646 : Closed e74809806646 ∧ code e74809806646 = 1174321434422 := by decide
theorem cert_e74809806646 : check e74809806646 [[.under],[.under,.left]] .chain = true := by decide
def e74809806650 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e74809806650 : Closed e74809806650 ∧ code e74809806650 = 1174321434426 := by decide
theorem cert_e74809806650 : check e74809806650 [[.under],[.under,.left]] .chain = true := by decide
def e74810395502 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e74810395502 : Closed e74810395502 ∧ code e74810395502 = 1174322023278 := by decide
theorem cert_e74810395502 : check e74810395502 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e74810395510 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e74810395510 : Closed e74810395510 ∧ code e74810395510 = 1174322023286 := by decide
theorem cert_e74810395510 : check e74810395510 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e74810395566 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e74810395566 : Closed e74810395566 ∧ code e74810395566 = 1174322023342 := by decide
theorem cert_e74810395566 : check e74810395566 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e74810395578 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e74810395578 : Closed e74810395578 ∧ code e74810395578 = 1174322023354 := by decide
private def t_e74810395578 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e74810395578 : ¬ IsSelfInterpreter e74810395578 :=
  wSource (t := t_e74810395578) (replay_sound (ps := []) (t := e74810395578) (by decide)) (by decide)
def e74810395606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e74810395606 : Closed e74810395606 ∧ code e74810395606 = 1174322023382 := by decide
theorem cert_e74810395606 : check e74810395606 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e74810395610 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e74810395610 : Closed e74810395610 ∧ code e74810395610 = 1174322023386 := by decide
private def t_e74810395610 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e74810395610 : ¬ IsSelfInterpreter e74810395610 :=
  wSource (t := t_e74810395610) (replay_sound (ps := []) (t := e74810395610) (by decide)) (by decide)
def e74810395886 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e74810395886 : Closed e74810395886 ∧ code e74810395886 = 1174322023662 := by decide
theorem cert_e74810395886 : check e74810395886 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e74810395894 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e74810395894 : Closed e74810395894 ∧ code e74810395894 = 1174322023670 := by decide
theorem cert_e74810395894 : check e74810395894 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e74810396270 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e74810396270 : Closed e74810396270 ∧ code e74810396270 = 1174322024046 := by decide
theorem cert_e74810396270 : checkPay e74810396270 [[.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e74810396282 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e74810396282 : Closed e74810396282 ∧ code e74810396282 = 1174322024058 := by decide
theorem cert_e74810396282 : check e74810396282 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e74810396470 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e74810396470 : Closed e74810396470 ∧ code e74810396470 = 1174322024246 := by decide
theorem cert_e74810396470 : check e74810396470 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e74810396474 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e74810396474 : Closed e74810396474 ∧ code e74810396474 = 1174322024250 := by decide
theorem cert_e74810396474 : check e74810396474 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e74843204974 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e74843204974 : Closed e74843204974 ∧ code e74843204974 = 1174354832750 := by decide
theorem cert_e74843204974 : check e74843204974 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843204982 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e74843204982 : Closed e74843204982 ∧ code e74843204982 = 1174354832758 := by decide
theorem cert_e74843204982 : check e74843204982 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843205038 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e74843205038 : Closed e74843205038 ∧ code e74843205038 = 1174354832814 := by decide
theorem cert_e74843205038 : check e74843205038 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843205050 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e74843205050 : Closed e74843205050 ∧ code e74843205050 = 1174354832826 := by decide
theorem cert_e74843205050 : check e74843205050 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843205078 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e74843205078 : Closed e74843205078 ∧ code e74843205078 = 1174354832854 := by decide
theorem cert_e74843205078 : check e74843205078 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843205082 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e74843205082 : Closed e74843205082 ∧ code e74843205082 = 1174354832858 := by decide
theorem cert_e74843205082 : check e74843205082 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843205294 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e74843205294 : Closed e74843205294 ∧ code e74843205294 = 1174354833070 := by decide
theorem cert_e74843205294 : check e74843205294 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843205306 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e74843205306 : Closed e74843205306 ∧ code e74843205306 = 1174354833082 := by decide
theorem cert_e74843205306 : check e74843205306 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843205354 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e74843205354 : Closed e74843205354 ∧ code e74843205354 = 1174354833130 := by decide
theorem cert_e74843205354 : check e74843205354 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843205462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e74843205462 : Closed e74843205462 ∧ code e74843205462 = 1174354833238 := by decide
theorem cert_e74843205462 : check e74843205462 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843205466 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e74843205466 : Closed e74843205466 ∧ code e74843205466 = 1174354833242 := by decide
theorem cert_e74843205466 : check e74843205466 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843205482 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e74843205482 : Closed e74843205482 ∧ code e74843205482 = 1174354833258 := by decide
theorem cert_e74843205482 : check e74843205482 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843206510 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e74843206510 : Closed e74843206510 ∧ code e74843206510 = 1174354834286 := by decide
theorem cert_e74843206510 : check e74843206510 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843206518 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e74843206518 : Closed e74843206518 ∧ code e74843206518 = 1174354834294 := by decide
theorem cert_e74843206518 : check e74843206518 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843206574 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e74843206574 : Closed e74843206574 ∧ code e74843206574 = 1174354834350 := by decide
theorem cert_e74843206574 : check e74843206574 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843206586 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e74843206586 : Closed e74843206586 ∧ code e74843206586 = 1174354834362 := by decide
theorem cert_e74843206586 : check e74843206586 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843206614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e74843206614 : Closed e74843206614 ∧ code e74843206614 = 1174354834390 := by decide
theorem cert_e74843206614 : check e74843206614 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843206618 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e74843206618 : Closed e74843206618 ∧ code e74843206618 = 1174354834394 := by decide
theorem cert_e74843206618 : check e74843206618 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843206894 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e74843206894 : Closed e74843206894 ∧ code e74843206894 = 1174354834670 := by decide
theorem cert_e74843206894 : check e74843206894 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843206902 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e74843206902 : Closed e74843206902 ∧ code e74843206902 = 1174354834678 := by decide
theorem cert_e74843206902 : check e74843206902 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843207278 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e74843207278 : Closed e74843207278 ∧ code e74843207278 = 1174354835054 := by decide
theorem cert_e74843207278 : check e74843207278 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843207290 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e74843207290 : Closed e74843207290 ∧ code e74843207290 = 1174354835066 := by decide
theorem cert_e74843207290 : check e74843207290 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843207478 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e74843207478 : Closed e74843207478 ∧ code e74843207478 = 1174354835254 := by decide
theorem cert_e74843207478 : check e74843207478 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843207482 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e74843207482 : Closed e74843207482 ∧ code e74843207482 = 1174354835258 := by decide
theorem cert_e74843207482 : check e74843207482 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843208110 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e74843208110 : Closed e74843208110 ∧ code e74843208110 = 1174354835886 := by decide
theorem cert_e74843208110 : check e74843208110 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843208122 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e74843208122 : Closed e74843208122 ∧ code e74843208122 = 1174354835898 := by decide
theorem cert_e74843208122 : check e74843208122 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843208170 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e74843208170 : Closed e74843208170 ∧ code e74843208170 = 1174354835946 := by decide
theorem cert_e74843208170 : check e74843208170 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843208302 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e74843208302 : Closed e74843208302 ∧ code e74843208302 = 1174354836078 := by decide
theorem cert_e74843208302 : check e74843208302 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843208314 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e74843208314 : Closed e74843208314 ∧ code e74843208314 = 1174354836090 := by decide
theorem cert_e74843208314 : check e74843208314 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843208602 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e74843208602 : Closed e74843208602 ∧ code e74843208602 = 1174354836378 := by decide
theorem cert_e74843208602 : check e74843208602 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843208918 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e74843208918 : Closed e74843208918 ∧ code e74843208918 = 1174354836694 := by decide
theorem cert_e74843208918 : check e74843208918 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843208922 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e74843208922 : Closed e74843208922 ∧ code e74843208922 = 1174354836698 := by decide
theorem cert_e74843208922 : check e74843208922 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843208938 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e74843208938 : Closed e74843208938 ∧ code e74843208938 = 1174354836714 := by decide
theorem cert_e74843208938 : check e74843208938 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843209014 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e74843209014 : Closed e74843209014 ∧ code e74843209014 = 1174354836790 := by decide
theorem cert_e74843209014 : check e74843209014 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843209018 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e74843209018 : Closed e74843209018 ∧ code e74843209018 = 1174354836794 := by decide
theorem cert_e74843209018 : check e74843209018 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843209114 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e74843209114 : Closed e74843209114 ∧ code e74843209114 = 1174354836890 := by decide
theorem cert_e74843209114 : check e74843209114 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843212654 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e74843212654 : Closed e74843212654 ∧ code e74843212654 = 1174354840430 := by decide
theorem cert_e74843212654 : check e74843212654 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843212662 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e74843212662 : Closed e74843212662 ∧ code e74843212662 = 1174354840438 := by decide
theorem cert_e74843212662 : check e74843212662 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843212718 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e74843212718 : Closed e74843212718 ∧ code e74843212718 = 1174354840494 := by decide
theorem cert_e74843212718 : check e74843212718 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843212730 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e74843212730 : Closed e74843212730 ∧ code e74843212730 = 1174354840506 := by decide
theorem cert_e74843212730 : check e74843212730 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843212758 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e74843212758 : Closed e74843212758 ∧ code e74843212758 = 1174354840534 := by decide
theorem cert_e74843212758 : check e74843212758 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843212762 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e74843212762 : Closed e74843212762 ∧ code e74843212762 = 1174354840538 := by decide
theorem cert_e74843212762 : check e74843212762 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843213038 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e74843213038 : Closed e74843213038 ∧ code e74843213038 = 1174354840814 := by decide
theorem cert_e74843213038 : check e74843213038 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843213046 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e74843213046 : Closed e74843213046 ∧ code e74843213046 = 1174354840822 := by decide
theorem cert_e74843213046 : check e74843213046 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843213422 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e74843213422 : Closed e74843213422 ∧ code e74843213422 = 1174354841198 := by decide
theorem cert_e74843213422 : check e74843213422 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843213434 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e74843213434 : Closed e74843213434 ∧ code e74843213434 = 1174354841210 := by decide
theorem cert_e74843213434 : check e74843213434 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843213622 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e74843213622 : Closed e74843213622 ∧ code e74843213622 = 1174354841398 := by decide
theorem cert_e74843213622 : check e74843213622 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843213626 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e74843213626 : Closed e74843213626 ∧ code e74843213626 = 1174354841402 := by decide
theorem cert_e74843213626 : check e74843213626 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843219374 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e74843219374 : Closed e74843219374 ∧ code e74843219374 = 1174354847150 := by decide
theorem cert_e74843219374 : check e74843219374 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843219386 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e74843219386 : Closed e74843219386 ∧ code e74843219386 = 1174354847162 := by decide
theorem cert_e74843219386 : check e74843219386 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843219434 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e74843219434 : Closed e74843219434 ∧ code e74843219434 = 1174354847210 := by decide
theorem cert_e74843219434 : check e74843219434 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843219566 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e74843219566 : Closed e74843219566 ∧ code e74843219566 = 1174354847342 := by decide
theorem cert_e74843219566 : check e74843219566 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843219578 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e74843219578 : Closed e74843219578 ∧ code e74843219578 = 1174354847354 := by decide
theorem cert_e74843219578 : check e74843219578 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843219866 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e74843219866 : Closed e74843219866 ∧ code e74843219866 = 1174354847642 := by decide
theorem cert_e74843219866 : check e74843219866 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843222742 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e74843222742 : Closed e74843222742 ∧ code e74843222742 = 1174354850518 := by decide
theorem cert_e74843222742 : check e74843222742 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843222746 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e74843222746 : Closed e74843222746 ∧ code e74843222746 = 1174354850522 := by decide
theorem cert_e74843222746 : check e74843222746 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843222762 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e74843222762 : Closed e74843222762 ∧ code e74843222762 = 1174354850538 := by decide
theorem cert_e74843222762 : check e74843222762 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843222838 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e74843222838 : Closed e74843222838 ∧ code e74843222838 = 1174354850614 := by decide
theorem cert_e74843222838 : check e74843222838 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843222842 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e74843222842 : Closed e74843222842 ∧ code e74843222842 = 1174354850618 := by decide
theorem cert_e74843222842 : check e74843222842 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843222938 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e74843222938 : Closed e74843222938 ∧ code e74843222938 = 1174354850714 := by decide
theorem cert_e74843222938 : check e74843222938 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e74843360110 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e74843360110 : Closed e74843360110 ∧ code e74843360110 = 1174354987886 := by decide
theorem cert_e74843360110 : check e74843360110 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e74843360118 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e74843360118 : Closed e74843360118 ∧ code e74843360118 = 1174354987894 := by decide
theorem cert_e74843360118 : check e74843360118 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e74843360174 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e74843360174 : Closed e74843360174 ∧ code e74843360174 = 1174354987950 := by decide
theorem cert_e74843360174 : check e74843360174 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e74843360186 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e74843360186 : Closed e74843360186 ∧ code e74843360186 = 1174354987962 := by decide
theorem cert_e74843360186 : check e74843360186 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
end Blc.Floor40
