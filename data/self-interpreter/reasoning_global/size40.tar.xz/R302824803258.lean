import CodeBridge
import R302824803258Blk0
namespace Certgen.R302824803258
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit92 : Term := .var 0
def lit64 : Term := .var 1
def lit20 : Term := .var 2
def lit56 : Term := .lam lit92
def lit63 : Term := .lam lit64
def lit90 : Term := .app lit92 lit92
def lit55 : Term := .lam lit56
def lit65 : Term := .var 4
def lit62 : Term := .lam lit63
def lit89 : Term := .lam lit90
def lit18 : Term := .app lit64 lit20
def lit53 : Term := .app lit92 lit55
def lit60 : Term := .app lit92 lit62
def lit17 : Term := .app lit18 lit92
def lit84 : Term := .app lit89 lit89
def lit15 : Term := .app lit20 lit17
def lit59 : Term := .app lit60 lit65
def lit14 : Term := .lam lit15
def lit58 : Term := .lam lit59
def lit25 : Term := .app lit64 lit84
def lit12 : Term := .app lit64 lit14
def lit24 : Term := .app lit25 lit92
def lit11 : Term := .lam lit12
def lit23 : Term := .lam lit24
def lit10 : Term := .lam lit11
def lit22 : Term := .lam lit23
def lit52 : Term := .app lit53 lit58
def lit51 : Term := .lam lit52
def lit5 : Term := .app lit89 lit10
def lit45 : Term := .app lit60 lit51
def lit44 : Term := .lam lit45
def lit38 : Term := .app lit60 lit44
def lit37 : Term := .lam lit38
def lit4 : Term := .app lit5 lit22
def lit3 : Term := .app lit4 lit37
def lit2 : Term := .app lit3 lit84
def lit1 : Term := .app lit2 lit84
def lit0 : Term := .app lit1 lit84
def filling : Nat → Term := fun p => if p = 65 then Term.var 4 else Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub92 : model.term 92 = lit92 := model.var_eq 92 0 (by rfl)
theorem sub91 : model.term 91 = lit92 := model.var_eq 91 0 (by rfl)
theorem sub90 : model.term 90 = lit90 := by rw [model.app_eq 90 91 92 (by rfl), sub91, sub92]; rfl
theorem sub89 : model.term 89 = lit89 := by rw [model.lam_eq 89 90 (by rfl), sub90]; rfl
theorem sub88 : model.term 88 = lit92 := model.var_eq 88 0 (by rfl)
theorem sub87 : model.term 87 = lit92 := model.var_eq 87 0 (by rfl)
theorem sub86 : model.term 86 = lit90 := by rw [model.app_eq 86 87 88 (by rfl), sub87, sub88]; rfl
theorem sub85 : model.term 85 = lit89 := by rw [model.lam_eq 85 86 (by rfl), sub86]; rfl
theorem sub84 : model.term 84 = lit84 := by rw [model.app_eq 84 85 89 (by rfl), sub85, sub89]; rfl
theorem sub83 : model.term 83 = lit92 := model.var_eq 83 0 (by rfl)
theorem sub82 : model.term 82 = lit92 := model.var_eq 82 0 (by rfl)
theorem sub81 : model.term 81 = lit90 := by rw [model.app_eq 81 82 83 (by rfl), sub82, sub83]; rfl
theorem sub80 : model.term 80 = lit89 := by rw [model.lam_eq 80 81 (by rfl), sub81]; rfl
theorem sub79 : model.term 79 = lit92 := model.var_eq 79 0 (by rfl)
theorem sub78 : model.term 78 = lit92 := model.var_eq 78 0 (by rfl)
theorem sub77 : model.term 77 = lit90 := by rw [model.app_eq 77 78 79 (by rfl), sub78, sub79]; rfl
theorem sub76 : model.term 76 = lit89 := by rw [model.lam_eq 76 77 (by rfl), sub77]; rfl
theorem sub75 : model.term 75 = lit84 := by rw [model.app_eq 75 76 80 (by rfl), sub76, sub80]; rfl
theorem sub74 : model.term 74 = lit92 := model.var_eq 74 0 (by rfl)
theorem sub73 : model.term 73 = lit92 := model.var_eq 73 0 (by rfl)
theorem sub72 : model.term 72 = lit90 := by rw [model.app_eq 72 73 74 (by rfl), sub73, sub74]; rfl
theorem sub71 : model.term 71 = lit89 := by rw [model.lam_eq 71 72 (by rfl), sub72]; rfl
theorem sub70 : model.term 70 = lit92 := model.var_eq 70 0 (by rfl)
theorem sub69 : model.term 69 = lit92 := model.var_eq 69 0 (by rfl)
theorem sub68 : model.term 68 = lit90 := by rw [model.app_eq 68 69 70 (by rfl), sub69, sub70]; rfl
theorem sub67 : model.term 67 = lit89 := by rw [model.lam_eq 67 68 (by rfl), sub68]; rfl
theorem sub66 : model.term 66 = lit84 := by rw [model.app_eq 66 67 71 (by rfl), sub67, sub71]; rfl
theorem sub65 : model.term 65 = lit65 := (opaqueTerm (rankedCode code ordered_code) filling (p := 65) (by rfl)).trans (by rfl)
theorem sub64 : model.term 64 = lit64 := model.var_eq 64 1 (by rfl)
theorem sub63 : model.term 63 = lit63 := by rw [model.lam_eq 63 64 (by rfl), sub64]; rfl
theorem sub62 : model.term 62 = lit62 := by rw [model.lam_eq 62 63 (by rfl), sub63]; rfl
theorem sub61 : model.term 61 = lit92 := model.var_eq 61 0 (by rfl)
theorem sub60 : model.term 60 = lit60 := by rw [model.app_eq 60 61 62 (by rfl), sub61, sub62]; rfl
theorem sub59 : model.term 59 = lit59 := by rw [model.app_eq 59 60 65 (by rfl), sub60, sub65]; rfl
theorem sub58 : model.term 58 = lit58 := by rw [model.lam_eq 58 59 (by rfl), sub59]; rfl
theorem sub57 : model.term 57 = lit92 := model.var_eq 57 0 (by rfl)
theorem sub56 : model.term 56 = lit56 := by rw [model.lam_eq 56 57 (by rfl), sub57]; rfl
theorem sub55 : model.term 55 = lit55 := by rw [model.lam_eq 55 56 (by rfl), sub56]; rfl
theorem sub54 : model.term 54 = lit92 := model.var_eq 54 0 (by rfl)
theorem sub53 : model.term 53 = lit53 := by rw [model.app_eq 53 54 55 (by rfl), sub54, sub55]; rfl
theorem sub52 : model.term 52 = lit52 := by rw [model.app_eq 52 53 58 (by rfl), sub53, sub58]; rfl
theorem sub51 : model.term 51 = lit51 := by rw [model.lam_eq 51 52 (by rfl), sub52]; rfl
theorem sub50 : model.term 50 = lit64 := model.var_eq 50 1 (by rfl)
theorem sub49 : model.term 49 = lit63 := by rw [model.lam_eq 49 50 (by rfl), sub50]; rfl
theorem sub48 : model.term 48 = lit62 := by rw [model.lam_eq 48 49 (by rfl), sub49]; rfl
theorem sub47 : model.term 47 = lit92 := model.var_eq 47 0 (by rfl)
theorem sub46 : model.term 46 = lit60 := by rw [model.app_eq 46 47 48 (by rfl), sub47, sub48]; rfl
theorem sub45 : model.term 45 = lit45 := by rw [model.app_eq 45 46 51 (by rfl), sub46, sub51]; rfl
theorem sub44 : model.term 44 = lit44 := by rw [model.lam_eq 44 45 (by rfl), sub45]; rfl
theorem sub43 : model.term 43 = lit64 := model.var_eq 43 1 (by rfl)
theorem sub42 : model.term 42 = lit63 := by rw [model.lam_eq 42 43 (by rfl), sub43]; rfl
theorem sub41 : model.term 41 = lit62 := by rw [model.lam_eq 41 42 (by rfl), sub42]; rfl
theorem sub40 : model.term 40 = lit92 := model.var_eq 40 0 (by rfl)
theorem sub39 : model.term 39 = lit60 := by rw [model.app_eq 39 40 41 (by rfl), sub40, sub41]; rfl
theorem sub38 : model.term 38 = lit38 := by rw [model.app_eq 38 39 44 (by rfl), sub39, sub44]; rfl
theorem sub37 : model.term 37 = lit37 := by rw [model.lam_eq 37 38 (by rfl), sub38]; rfl
theorem sub36 : model.term 36 = lit92 := model.var_eq 36 0 (by rfl)
theorem sub35 : model.term 35 = lit92 := model.var_eq 35 0 (by rfl)
theorem sub34 : model.term 34 = lit92 := model.var_eq 34 0 (by rfl)
theorem sub33 : model.term 33 = lit90 := by rw [model.app_eq 33 34 35 (by rfl), sub34, sub35]; rfl
theorem sub32 : model.term 32 = lit89 := by rw [model.lam_eq 32 33 (by rfl), sub33]; rfl
theorem sub31 : model.term 31 = lit92 := model.var_eq 31 0 (by rfl)
theorem sub30 : model.term 30 = lit92 := model.var_eq 30 0 (by rfl)
theorem sub29 : model.term 29 = lit90 := by rw [model.app_eq 29 30 31 (by rfl), sub30, sub31]; rfl
theorem sub28 : model.term 28 = lit89 := by rw [model.lam_eq 28 29 (by rfl), sub29]; rfl
theorem sub27 : model.term 27 = lit84 := by rw [model.app_eq 27 28 32 (by rfl), sub28, sub32]; rfl
theorem sub26 : model.term 26 = lit64 := model.var_eq 26 1 (by rfl)
theorem sub25 : model.term 25 = lit25 := by rw [model.app_eq 25 26 27 (by rfl), sub26, sub27]; rfl
theorem sub24 : model.term 24 = lit24 := by rw [model.app_eq 24 25 36 (by rfl), sub25, sub36]; rfl
theorem sub23 : model.term 23 = lit23 := by rw [model.lam_eq 23 24 (by rfl), sub24]; rfl
theorem sub22 : model.term 22 = lit22 := by rw [model.lam_eq 22 23 (by rfl), sub23]; rfl
theorem sub21 : model.term 21 = lit92 := model.var_eq 21 0 (by rfl)
theorem sub20 : model.term 20 = lit20 := model.var_eq 20 2 (by rfl)
theorem sub19 : model.term 19 = lit64 := model.var_eq 19 1 (by rfl)
theorem sub18 : model.term 18 = lit18 := by rw [model.app_eq 18 19 20 (by rfl), sub19, sub20]; rfl
theorem sub17 : model.term 17 = lit17 := by rw [model.app_eq 17 18 21 (by rfl), sub18, sub21]; rfl
theorem sub16 : model.term 16 = lit20 := model.var_eq 16 2 (by rfl)
theorem sub15 : model.term 15 = lit15 := by rw [model.app_eq 15 16 17 (by rfl), sub16, sub17]; rfl
theorem sub14 : model.term 14 = lit14 := by rw [model.lam_eq 14 15 (by rfl), sub15]; rfl
theorem sub13 : model.term 13 = lit64 := model.var_eq 13 1 (by rfl)
theorem sub12 : model.term 12 = lit12 := by rw [model.app_eq 12 13 14 (by rfl), sub13, sub14]; rfl
theorem sub11 : model.term 11 = lit11 := by rw [model.lam_eq 11 12 (by rfl), sub12]; rfl
theorem sub10 : model.term 10 = lit10 := by rw [model.lam_eq 10 11 (by rfl), sub11]; rfl
theorem sub9 : model.term 9 = lit92 := model.var_eq 9 0 (by rfl)
theorem sub8 : model.term 8 = lit92 := model.var_eq 8 0 (by rfl)
theorem sub7 : model.term 7 = lit90 := by rw [model.app_eq 7 8 9 (by rfl), sub8, sub9]; rfl
theorem sub6 : model.term 6 = lit89 := by rw [model.lam_eq 6 7 (by rfl), sub7]; rfl
theorem sub5 : model.term 5 = lit5 := by rw [model.app_eq 5 6 10 (by rfl), sub6, sub10]; rfl
theorem sub4 : model.term 4 = lit4 := by rw [model.app_eq 4 5 22 (by rfl), sub5, sub22]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 37 (by rfl), sub4, sub37]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 66 (by rfl), sub3, sub66]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 75 (by rfl), sub2, sub75]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 84 (by rfl), sub1, sub84]; rfl
theorem allValid (i : Nat) (h : i < 55) : validState i = true := by
 by_cases h24 : i < 24
 · by_cases h12 : i < 12
   · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
   · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
 · by_cases h36 : i < 36
   · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
   · by_cases h48 : i < 48
     · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 55
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e302824803258 := by
 intro he
 have hp : replay [] (call e302824803258 (.lam (.lam (.app (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))) (.var 0)))) (.lam (.var 0)) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 4) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R302824803258
