import CodeBridge
import R302902171894Blk0
import R302902171894Blk6
import R302902171894Blk12
import R302902171894Blk18
import R302902171894Blk24
import R302902171894Blk30
import R302902171894Blk36
import R302902171894Blk42
import R302902171894Blk48
import R302902171894Blk54
import R302902171894Blk60
import R302902171894Blk66
import R302902171894Blk72
import R302902171894Blk78
import R302902171894Blk84
import R302902171894Blk90
import R302902171894Blk96
import R302902171894Blk102
import R302902171894Blk108
import R302902171894Blk114
import R302902171894Blk120
import R302902171894Blk126
import R302902171894Blk132
import R302902171894Blk138
import R302902171894Blk144
import R302902171894Blk150
import R302902171894Blk156
import R302902171894Blk162
namespace Certgen.R302902171894
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit135 : Term := .var 0
def lit98 : Term := .var 1
def lit90 : Term := .lam lit135
def lit51 : Term := .var 3
def lit97 : Term := .lam lit98
def lit89 : Term := .lam lit90
def lit133 : Term := .app lit135 lit135
def lit50 : Term := .lam lit51
def lit96 : Term := .lam lit97
def lit99 : Term := .var 6
def lit132 : Term := .lam lit133
def lit87 : Term := .app lit135 lit89
def lit48 : Term := .app lit135 lit50
def lit94 : Term := .app lit135 lit96
def lit47 : Term := .app lit48 lit98
def lit46 : Term := .lam lit47
def lit127 : Term := .app lit132 lit132
def lit45 : Term := .lam lit46
def lit93 : Term := .app lit94 lit99
def lit92 : Term := .lam lit93
def lit43 : Term := .app lit135 lit45
def lit41 : Term := .app lit135 lit43
def lit40 : Term := .lam lit41
def lit39 : Term := .lam lit40
def lit86 : Term := .app lit87 lit92
def lit37 : Term := .app lit135 lit39
def lit85 : Term := .lam lit86
def lit36 : Term := .app lit37 lit98
def lit35 : Term := .lam lit36
def lit34 : Term := .lam lit35
def lit79 : Term := .app lit94 lit85
def lit78 : Term := .lam lit79
def lit72 : Term := .app lit94 lit78
def lit71 : Term := .lam lit72
def lit20 : Term := .app lit40 lit34
def lit65 : Term := .app lit94 lit71
def lit64 : Term := .lam lit65
def lit58 : Term := .app lit94 lit64
def lit57 : Term := .lam lit58
def lit6 : Term := .app lit40 lit20
def lit5 : Term := .app lit6 lit89
def lit4 : Term := .app lit5 lit57
def lit3 : Term := .app lit4 lit127
def lit2 : Term := .app lit3 lit127
def lit1 : Term := .app lit2 lit127
def lit0 : Term := .app lit1 lit127
def filling : Nat → Term := fun p => if p = 99 then Term.var 6 else Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub135 : model.term 135 = lit135 := model.var_eq 135 0 (by rfl)
theorem sub134 : model.term 134 = lit135 := model.var_eq 134 0 (by rfl)
theorem sub133 : model.term 133 = lit133 := by rw [model.app_eq 133 134 135 (by rfl), sub134, sub135]; rfl
theorem sub132 : model.term 132 = lit132 := by rw [model.lam_eq 132 133 (by rfl), sub133]; rfl
theorem sub131 : model.term 131 = lit135 := model.var_eq 131 0 (by rfl)
theorem sub130 : model.term 130 = lit135 := model.var_eq 130 0 (by rfl)
theorem sub129 : model.term 129 = lit133 := by rw [model.app_eq 129 130 131 (by rfl), sub130, sub131]; rfl
theorem sub128 : model.term 128 = lit132 := by rw [model.lam_eq 128 129 (by rfl), sub129]; rfl
theorem sub127 : model.term 127 = lit127 := by rw [model.app_eq 127 128 132 (by rfl), sub128, sub132]; rfl
theorem sub126 : model.term 126 = lit135 := model.var_eq 126 0 (by rfl)
theorem sub125 : model.term 125 = lit135 := model.var_eq 125 0 (by rfl)
theorem sub124 : model.term 124 = lit133 := by rw [model.app_eq 124 125 126 (by rfl), sub125, sub126]; rfl
theorem sub123 : model.term 123 = lit132 := by rw [model.lam_eq 123 124 (by rfl), sub124]; rfl
theorem sub122 : model.term 122 = lit135 := model.var_eq 122 0 (by rfl)
theorem sub121 : model.term 121 = lit135 := model.var_eq 121 0 (by rfl)
theorem sub120 : model.term 120 = lit133 := by rw [model.app_eq 120 121 122 (by rfl), sub121, sub122]; rfl
theorem sub119 : model.term 119 = lit132 := by rw [model.lam_eq 119 120 (by rfl), sub120]; rfl
theorem sub118 : model.term 118 = lit127 := by rw [model.app_eq 118 119 123 (by rfl), sub119, sub123]; rfl
theorem sub117 : model.term 117 = lit135 := model.var_eq 117 0 (by rfl)
theorem sub116 : model.term 116 = lit135 := model.var_eq 116 0 (by rfl)
theorem sub115 : model.term 115 = lit133 := by rw [model.app_eq 115 116 117 (by rfl), sub116, sub117]; rfl
theorem sub114 : model.term 114 = lit132 := by rw [model.lam_eq 114 115 (by rfl), sub115]; rfl
theorem sub113 : model.term 113 = lit135 := model.var_eq 113 0 (by rfl)
theorem sub112 : model.term 112 = lit135 := model.var_eq 112 0 (by rfl)
theorem sub111 : model.term 111 = lit133 := by rw [model.app_eq 111 112 113 (by rfl), sub112, sub113]; rfl
theorem sub110 : model.term 110 = lit132 := by rw [model.lam_eq 110 111 (by rfl), sub111]; rfl
theorem sub109 : model.term 109 = lit127 := by rw [model.app_eq 109 110 114 (by rfl), sub110, sub114]; rfl
theorem sub108 : model.term 108 = lit135 := model.var_eq 108 0 (by rfl)
theorem sub107 : model.term 107 = lit135 := model.var_eq 107 0 (by rfl)
theorem sub106 : model.term 106 = lit133 := by rw [model.app_eq 106 107 108 (by rfl), sub107, sub108]; rfl
theorem sub105 : model.term 105 = lit132 := by rw [model.lam_eq 105 106 (by rfl), sub106]; rfl
theorem sub104 : model.term 104 = lit135 := model.var_eq 104 0 (by rfl)
theorem sub103 : model.term 103 = lit135 := model.var_eq 103 0 (by rfl)
theorem sub102 : model.term 102 = lit133 := by rw [model.app_eq 102 103 104 (by rfl), sub103, sub104]; rfl
theorem sub101 : model.term 101 = lit132 := by rw [model.lam_eq 101 102 (by rfl), sub102]; rfl
theorem sub100 : model.term 100 = lit127 := by rw [model.app_eq 100 101 105 (by rfl), sub101, sub105]; rfl
theorem sub99 : model.term 99 = lit99 := (opaqueTerm (rankedCode code ordered_code) filling (p := 99) (by rfl)).trans (by rfl)
theorem sub98 : model.term 98 = lit98 := model.var_eq 98 1 (by rfl)
theorem sub97 : model.term 97 = lit97 := by rw [model.lam_eq 97 98 (by rfl), sub98]; rfl
theorem sub96 : model.term 96 = lit96 := by rw [model.lam_eq 96 97 (by rfl), sub97]; rfl
theorem sub95 : model.term 95 = lit135 := model.var_eq 95 0 (by rfl)
theorem sub94 : model.term 94 = lit94 := by rw [model.app_eq 94 95 96 (by rfl), sub95, sub96]; rfl
theorem sub93 : model.term 93 = lit93 := by rw [model.app_eq 93 94 99 (by rfl), sub94, sub99]; rfl
theorem sub92 : model.term 92 = lit92 := by rw [model.lam_eq 92 93 (by rfl), sub93]; rfl
theorem sub91 : model.term 91 = lit135 := model.var_eq 91 0 (by rfl)
theorem sub90 : model.term 90 = lit90 := by rw [model.lam_eq 90 91 (by rfl), sub91]; rfl
theorem sub89 : model.term 89 = lit89 := by rw [model.lam_eq 89 90 (by rfl), sub90]; rfl
theorem sub88 : model.term 88 = lit135 := model.var_eq 88 0 (by rfl)
theorem sub87 : model.term 87 = lit87 := by rw [model.app_eq 87 88 89 (by rfl), sub88, sub89]; rfl
theorem sub86 : model.term 86 = lit86 := by rw [model.app_eq 86 87 92 (by rfl), sub87, sub92]; rfl
theorem sub85 : model.term 85 = lit85 := by rw [model.lam_eq 85 86 (by rfl), sub86]; rfl
theorem sub84 : model.term 84 = lit98 := model.var_eq 84 1 (by rfl)
theorem sub83 : model.term 83 = lit97 := by rw [model.lam_eq 83 84 (by rfl), sub84]; rfl
theorem sub82 : model.term 82 = lit96 := by rw [model.lam_eq 82 83 (by rfl), sub83]; rfl
theorem sub81 : model.term 81 = lit135 := model.var_eq 81 0 (by rfl)
theorem sub80 : model.term 80 = lit94 := by rw [model.app_eq 80 81 82 (by rfl), sub81, sub82]; rfl
theorem sub79 : model.term 79 = lit79 := by rw [model.app_eq 79 80 85 (by rfl), sub80, sub85]; rfl
theorem sub78 : model.term 78 = lit78 := by rw [model.lam_eq 78 79 (by rfl), sub79]; rfl
theorem sub77 : model.term 77 = lit98 := model.var_eq 77 1 (by rfl)
theorem sub76 : model.term 76 = lit97 := by rw [model.lam_eq 76 77 (by rfl), sub77]; rfl
theorem sub75 : model.term 75 = lit96 := by rw [model.lam_eq 75 76 (by rfl), sub76]; rfl
theorem sub74 : model.term 74 = lit135 := model.var_eq 74 0 (by rfl)
theorem sub73 : model.term 73 = lit94 := by rw [model.app_eq 73 74 75 (by rfl), sub74, sub75]; rfl
theorem sub72 : model.term 72 = lit72 := by rw [model.app_eq 72 73 78 (by rfl), sub73, sub78]; rfl
theorem sub71 : model.term 71 = lit71 := by rw [model.lam_eq 71 72 (by rfl), sub72]; rfl
theorem sub70 : model.term 70 = lit98 := model.var_eq 70 1 (by rfl)
theorem sub69 : model.term 69 = lit97 := by rw [model.lam_eq 69 70 (by rfl), sub70]; rfl
theorem sub68 : model.term 68 = lit96 := by rw [model.lam_eq 68 69 (by rfl), sub69]; rfl
theorem sub67 : model.term 67 = lit135 := model.var_eq 67 0 (by rfl)
theorem sub66 : model.term 66 = lit94 := by rw [model.app_eq 66 67 68 (by rfl), sub67, sub68]; rfl
theorem sub65 : model.term 65 = lit65 := by rw [model.app_eq 65 66 71 (by rfl), sub66, sub71]; rfl
theorem sub64 : model.term 64 = lit64 := by rw [model.lam_eq 64 65 (by rfl), sub65]; rfl
theorem sub63 : model.term 63 = lit98 := model.var_eq 63 1 (by rfl)
theorem sub62 : model.term 62 = lit97 := by rw [model.lam_eq 62 63 (by rfl), sub63]; rfl
theorem sub61 : model.term 61 = lit96 := by rw [model.lam_eq 61 62 (by rfl), sub62]; rfl
theorem sub60 : model.term 60 = lit135 := model.var_eq 60 0 (by rfl)
theorem sub59 : model.term 59 = lit94 := by rw [model.app_eq 59 60 61 (by rfl), sub60, sub61]; rfl
theorem sub58 : model.term 58 = lit58 := by rw [model.app_eq 58 59 64 (by rfl), sub59, sub64]; rfl
theorem sub57 : model.term 57 = lit57 := by rw [model.lam_eq 57 58 (by rfl), sub58]; rfl
theorem sub56 : model.term 56 = lit135 := model.var_eq 56 0 (by rfl)
theorem sub55 : model.term 55 = lit90 := by rw [model.lam_eq 55 56 (by rfl), sub56]; rfl
theorem sub54 : model.term 54 = lit89 := by rw [model.lam_eq 54 55 (by rfl), sub55]; rfl
theorem sub53 : model.term 53 = lit98 := model.var_eq 53 1 (by rfl)
theorem sub52 : model.term 52 = lit98 := model.var_eq 52 1 (by rfl)
theorem sub51 : model.term 51 = lit51 := model.var_eq 51 3 (by rfl)
theorem sub50 : model.term 50 = lit50 := by rw [model.lam_eq 50 51 (by rfl), sub51]; rfl
theorem sub49 : model.term 49 = lit135 := model.var_eq 49 0 (by rfl)
theorem sub48 : model.term 48 = lit48 := by rw [model.app_eq 48 49 50 (by rfl), sub49, sub50]; rfl
theorem sub47 : model.term 47 = lit47 := by rw [model.app_eq 47 48 52 (by rfl), sub48, sub52]; rfl
theorem sub46 : model.term 46 = lit46 := by rw [model.lam_eq 46 47 (by rfl), sub47]; rfl
theorem sub45 : model.term 45 = lit45 := by rw [model.lam_eq 45 46 (by rfl), sub46]; rfl
theorem sub44 : model.term 44 = lit135 := model.var_eq 44 0 (by rfl)
theorem sub43 : model.term 43 = lit43 := by rw [model.app_eq 43 44 45 (by rfl), sub44, sub45]; rfl
theorem sub42 : model.term 42 = lit135 := model.var_eq 42 0 (by rfl)
theorem sub41 : model.term 41 = lit41 := by rw [model.app_eq 41 42 43 (by rfl), sub42, sub43]; rfl
theorem sub40 : model.term 40 = lit40 := by rw [model.lam_eq 40 41 (by rfl), sub41]; rfl
theorem sub39 : model.term 39 = lit39 := by rw [model.lam_eq 39 40 (by rfl), sub40]; rfl
theorem sub38 : model.term 38 = lit135 := model.var_eq 38 0 (by rfl)
theorem sub37 : model.term 37 = lit37 := by rw [model.app_eq 37 38 39 (by rfl), sub38, sub39]; rfl
theorem sub36 : model.term 36 = lit36 := by rw [model.app_eq 36 37 53 (by rfl), sub37, sub53]; rfl
theorem sub35 : model.term 35 = lit35 := by rw [model.lam_eq 35 36 (by rfl), sub36]; rfl
theorem sub34 : model.term 34 = lit34 := by rw [model.lam_eq 34 35 (by rfl), sub35]; rfl
theorem sub33 : model.term 33 = lit98 := model.var_eq 33 1 (by rfl)
theorem sub32 : model.term 32 = lit51 := model.var_eq 32 3 (by rfl)
theorem sub31 : model.term 31 = lit50 := by rw [model.lam_eq 31 32 (by rfl), sub32]; rfl
theorem sub30 : model.term 30 = lit135 := model.var_eq 30 0 (by rfl)
theorem sub29 : model.term 29 = lit48 := by rw [model.app_eq 29 30 31 (by rfl), sub30, sub31]; rfl
theorem sub28 : model.term 28 = lit47 := by rw [model.app_eq 28 29 33 (by rfl), sub29, sub33]; rfl
theorem sub27 : model.term 27 = lit46 := by rw [model.lam_eq 27 28 (by rfl), sub28]; rfl
theorem sub26 : model.term 26 = lit45 := by rw [model.lam_eq 26 27 (by rfl), sub27]; rfl
theorem sub25 : model.term 25 = lit135 := model.var_eq 25 0 (by rfl)
theorem sub24 : model.term 24 = lit43 := by rw [model.app_eq 24 25 26 (by rfl), sub25, sub26]; rfl
theorem sub23 : model.term 23 = lit135 := model.var_eq 23 0 (by rfl)
theorem sub22 : model.term 22 = lit41 := by rw [model.app_eq 22 23 24 (by rfl), sub23, sub24]; rfl
theorem sub21 : model.term 21 = lit40 := by rw [model.lam_eq 21 22 (by rfl), sub22]; rfl
theorem sub20 : model.term 20 = lit20 := by rw [model.app_eq 20 21 34 (by rfl), sub21, sub34]; rfl
theorem sub19 : model.term 19 = lit98 := model.var_eq 19 1 (by rfl)
theorem sub18 : model.term 18 = lit51 := model.var_eq 18 3 (by rfl)
theorem sub17 : model.term 17 = lit50 := by rw [model.lam_eq 17 18 (by rfl), sub18]; rfl
theorem sub16 : model.term 16 = lit135 := model.var_eq 16 0 (by rfl)
theorem sub15 : model.term 15 = lit48 := by rw [model.app_eq 15 16 17 (by rfl), sub16, sub17]; rfl
theorem sub14 : model.term 14 = lit47 := by rw [model.app_eq 14 15 19 (by rfl), sub15, sub19]; rfl
theorem sub13 : model.term 13 = lit46 := by rw [model.lam_eq 13 14 (by rfl), sub14]; rfl
theorem sub12 : model.term 12 = lit45 := by rw [model.lam_eq 12 13 (by rfl), sub13]; rfl
theorem sub11 : model.term 11 = lit135 := model.var_eq 11 0 (by rfl)
theorem sub10 : model.term 10 = lit43 := by rw [model.app_eq 10 11 12 (by rfl), sub11, sub12]; rfl
theorem sub9 : model.term 9 = lit135 := model.var_eq 9 0 (by rfl)
theorem sub8 : model.term 8 = lit41 := by rw [model.app_eq 8 9 10 (by rfl), sub9, sub10]; rfl
theorem sub7 : model.term 7 = lit40 := by rw [model.lam_eq 7 8 (by rfl), sub8]; rfl
theorem sub6 : model.term 6 = lit6 := by rw [model.app_eq 6 7 20 (by rfl), sub7, sub20]; rfl
theorem sub5 : model.term 5 = lit5 := by rw [model.app_eq 5 6 54 (by rfl), sub6, sub54]; rfl
theorem sub4 : model.term 4 = lit4 := by rw [model.app_eq 4 5 57 (by rfl), sub5, sub57]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 100 (by rfl), sub4, sub100]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 109 (by rfl), sub3, sub109]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 118 (by rfl), sub2, sub118]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 127 (by rfl), sub1, sub127]; rfl
theorem allValid (i : Nat) (h : i < 1969) : validState i = true := by
 by_cases h984 : i < 984
 · by_cases h492 : i < 492
   · by_cases h240 : i < 240
     · by_cases h120 : i < 120
       · by_cases h60 : i < 60
         · by_cases h24 : i < 24
           · by_cases h12 : i < 12
             · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
           · by_cases h36 : i < 36
             · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
             · by_cases h48 : i < 48
               · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
         · by_cases h84 : i < 84
           · by_cases h72 : i < 72
             · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
           · by_cases h96 : i < 96
             · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
             · by_cases h108 : i < 108
               · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl108 (by omega) (by omega)
       · by_cases h180 : i < 180
         · by_cases h144 : i < 144
           · by_cases h132 : i < 132
             · exact FloorIndex.rangeOK_at bl120 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl132 (by omega) (by omega)
           · by_cases h156 : i < 156
             · exact FloorIndex.rangeOK_at bl144 (by omega) (by omega)
             · by_cases h168 : i < 168
               · exact FloorIndex.rangeOK_at bl156 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl168 (by omega) (by omega)
         · by_cases h204 : i < 204
           · by_cases h192 : i < 192
             · exact FloorIndex.rangeOK_at bl180 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl192 (by omega) (by omega)
           · by_cases h216 : i < 216
             · exact FloorIndex.rangeOK_at bl204 (by omega) (by omega)
             · by_cases h228 : i < 228
               · exact FloorIndex.rangeOK_at bl216 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl228 (by omega) (by omega)
     · by_cases h360 : i < 360
       · by_cases h300 : i < 300
         · by_cases h264 : i < 264
           · by_cases h252 : i < 252
             · exact FloorIndex.rangeOK_at bl240 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl252 (by omega) (by omega)
           · by_cases h276 : i < 276
             · exact FloorIndex.rangeOK_at bl264 (by omega) (by omega)
             · by_cases h288 : i < 288
               · exact FloorIndex.rangeOK_at bl276 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl288 (by omega) (by omega)
         · by_cases h324 : i < 324
           · by_cases h312 : i < 312
             · exact FloorIndex.rangeOK_at bl300 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl312 (by omega) (by omega)
           · by_cases h336 : i < 336
             · exact FloorIndex.rangeOK_at bl324 (by omega) (by omega)
             · by_cases h348 : i < 348
               · exact FloorIndex.rangeOK_at bl336 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl348 (by omega) (by omega)
       · by_cases h420 : i < 420
         · by_cases h384 : i < 384
           · by_cases h372 : i < 372
             · exact FloorIndex.rangeOK_at bl360 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl372 (by omega) (by omega)
           · by_cases h396 : i < 396
             · exact FloorIndex.rangeOK_at bl384 (by omega) (by omega)
             · by_cases h408 : i < 408
               · exact FloorIndex.rangeOK_at bl396 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl408 (by omega) (by omega)
         · by_cases h456 : i < 456
           · by_cases h432 : i < 432
             · exact FloorIndex.rangeOK_at bl420 (by omega) (by omega)
             · by_cases h444 : i < 444
               · exact FloorIndex.rangeOK_at bl432 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl444 (by omega) (by omega)
           · by_cases h468 : i < 468
             · exact FloorIndex.rangeOK_at bl456 (by omega) (by omega)
             · by_cases h480 : i < 480
               · exact FloorIndex.rangeOK_at bl468 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl480 (by omega) (by omega)
   · by_cases h732 : i < 732
     · by_cases h612 : i < 612
       · by_cases h552 : i < 552
         · by_cases h516 : i < 516
           · by_cases h504 : i < 504
             · exact FloorIndex.rangeOK_at bl492 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl504 (by omega) (by omega)
           · by_cases h528 : i < 528
             · exact FloorIndex.rangeOK_at bl516 (by omega) (by omega)
             · by_cases h540 : i < 540
               · exact FloorIndex.rangeOK_at bl528 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl540 (by omega) (by omega)
         · by_cases h576 : i < 576
           · by_cases h564 : i < 564
             · exact FloorIndex.rangeOK_at bl552 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl564 (by omega) (by omega)
           · by_cases h588 : i < 588
             · exact FloorIndex.rangeOK_at bl576 (by omega) (by omega)
             · by_cases h600 : i < 600
               · exact FloorIndex.rangeOK_at bl588 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl600 (by omega) (by omega)
       · by_cases h672 : i < 672
         · by_cases h636 : i < 636
           · by_cases h624 : i < 624
             · exact FloorIndex.rangeOK_at bl612 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl624 (by omega) (by omega)
           · by_cases h648 : i < 648
             · exact FloorIndex.rangeOK_at bl636 (by omega) (by omega)
             · by_cases h660 : i < 660
               · exact FloorIndex.rangeOK_at bl648 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl660 (by omega) (by omega)
         · by_cases h696 : i < 696
           · by_cases h684 : i < 684
             · exact FloorIndex.rangeOK_at bl672 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl684 (by omega) (by omega)
           · by_cases h708 : i < 708
             · exact FloorIndex.rangeOK_at bl696 (by omega) (by omega)
             · by_cases h720 : i < 720
               · exact FloorIndex.rangeOK_at bl708 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl720 (by omega) (by omega)
     · by_cases h852 : i < 852
       · by_cases h792 : i < 792
         · by_cases h756 : i < 756
           · by_cases h744 : i < 744
             · exact FloorIndex.rangeOK_at bl732 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl744 (by omega) (by omega)
           · by_cases h768 : i < 768
             · exact FloorIndex.rangeOK_at bl756 (by omega) (by omega)
             · by_cases h780 : i < 780
               · exact FloorIndex.rangeOK_at bl768 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl780 (by omega) (by omega)
         · by_cases h816 : i < 816
           · by_cases h804 : i < 804
             · exact FloorIndex.rangeOK_at bl792 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl804 (by omega) (by omega)
           · by_cases h828 : i < 828
             · exact FloorIndex.rangeOK_at bl816 (by omega) (by omega)
             · by_cases h840 : i < 840
               · exact FloorIndex.rangeOK_at bl828 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl840 (by omega) (by omega)
       · by_cases h912 : i < 912
         · by_cases h876 : i < 876
           · by_cases h864 : i < 864
             · exact FloorIndex.rangeOK_at bl852 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl864 (by omega) (by omega)
           · by_cases h888 : i < 888
             · exact FloorIndex.rangeOK_at bl876 (by omega) (by omega)
             · by_cases h900 : i < 900
               · exact FloorIndex.rangeOK_at bl888 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl900 (by omega) (by omega)
         · by_cases h948 : i < 948
           · by_cases h924 : i < 924
             · exact FloorIndex.rangeOK_at bl912 (by omega) (by omega)
             · by_cases h936 : i < 936
               · exact FloorIndex.rangeOK_at bl924 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl936 (by omega) (by omega)
           · by_cases h960 : i < 960
             · exact FloorIndex.rangeOK_at bl948 (by omega) (by omega)
             · by_cases h972 : i < 972
               · exact FloorIndex.rangeOK_at bl960 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl972 (by omega) (by omega)
 · by_cases h1476 : i < 1476
   · by_cases h1224 : i < 1224
     · by_cases h1104 : i < 1104
       · by_cases h1044 : i < 1044
         · by_cases h1008 : i < 1008
           · by_cases h996 : i < 996
             · exact FloorIndex.rangeOK_at bl984 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl996 (by omega) (by omega)
           · by_cases h1020 : i < 1020
             · exact FloorIndex.rangeOK_at bl1008 (by omega) (by omega)
             · by_cases h1032 : i < 1032
               · exact FloorIndex.rangeOK_at bl1020 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1032 (by omega) (by omega)
         · by_cases h1068 : i < 1068
           · by_cases h1056 : i < 1056
             · exact FloorIndex.rangeOK_at bl1044 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1056 (by omega) (by omega)
           · by_cases h1080 : i < 1080
             · exact FloorIndex.rangeOK_at bl1068 (by omega) (by omega)
             · by_cases h1092 : i < 1092
               · exact FloorIndex.rangeOK_at bl1080 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1092 (by omega) (by omega)
       · by_cases h1164 : i < 1164
         · by_cases h1128 : i < 1128
           · by_cases h1116 : i < 1116
             · exact FloorIndex.rangeOK_at bl1104 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1116 (by omega) (by omega)
           · by_cases h1140 : i < 1140
             · exact FloorIndex.rangeOK_at bl1128 (by omega) (by omega)
             · by_cases h1152 : i < 1152
               · exact FloorIndex.rangeOK_at bl1140 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1152 (by omega) (by omega)
         · by_cases h1188 : i < 1188
           · by_cases h1176 : i < 1176
             · exact FloorIndex.rangeOK_at bl1164 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1176 (by omega) (by omega)
           · by_cases h1200 : i < 1200
             · exact FloorIndex.rangeOK_at bl1188 (by omega) (by omega)
             · by_cases h1212 : i < 1212
               · exact FloorIndex.rangeOK_at bl1200 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1212 (by omega) (by omega)
     · by_cases h1344 : i < 1344
       · by_cases h1284 : i < 1284
         · by_cases h1248 : i < 1248
           · by_cases h1236 : i < 1236
             · exact FloorIndex.rangeOK_at bl1224 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1236 (by omega) (by omega)
           · by_cases h1260 : i < 1260
             · exact FloorIndex.rangeOK_at bl1248 (by omega) (by omega)
             · by_cases h1272 : i < 1272
               · exact FloorIndex.rangeOK_at bl1260 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1272 (by omega) (by omega)
         · by_cases h1308 : i < 1308
           · by_cases h1296 : i < 1296
             · exact FloorIndex.rangeOK_at bl1284 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1296 (by omega) (by omega)
           · by_cases h1320 : i < 1320
             · exact FloorIndex.rangeOK_at bl1308 (by omega) (by omega)
             · by_cases h1332 : i < 1332
               · exact FloorIndex.rangeOK_at bl1320 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1332 (by omega) (by omega)
       · by_cases h1404 : i < 1404
         · by_cases h1368 : i < 1368
           · by_cases h1356 : i < 1356
             · exact FloorIndex.rangeOK_at bl1344 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1356 (by omega) (by omega)
           · by_cases h1380 : i < 1380
             · exact FloorIndex.rangeOK_at bl1368 (by omega) (by omega)
             · by_cases h1392 : i < 1392
               · exact FloorIndex.rangeOK_at bl1380 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1392 (by omega) (by omega)
         · by_cases h1440 : i < 1440
           · by_cases h1416 : i < 1416
             · exact FloorIndex.rangeOK_at bl1404 (by omega) (by omega)
             · by_cases h1428 : i < 1428
               · exact FloorIndex.rangeOK_at bl1416 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1428 (by omega) (by omega)
           · by_cases h1452 : i < 1452
             · exact FloorIndex.rangeOK_at bl1440 (by omega) (by omega)
             · by_cases h1464 : i < 1464
               · exact FloorIndex.rangeOK_at bl1452 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1464 (by omega) (by omega)
   · by_cases h1728 : i < 1728
     · by_cases h1596 : i < 1596
       · by_cases h1536 : i < 1536
         · by_cases h1500 : i < 1500
           · by_cases h1488 : i < 1488
             · exact FloorIndex.rangeOK_at bl1476 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1488 (by omega) (by omega)
           · by_cases h1512 : i < 1512
             · exact FloorIndex.rangeOK_at bl1500 (by omega) (by omega)
             · by_cases h1524 : i < 1524
               · exact FloorIndex.rangeOK_at bl1512 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1524 (by omega) (by omega)
         · by_cases h1560 : i < 1560
           · by_cases h1548 : i < 1548
             · exact FloorIndex.rangeOK_at bl1536 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1548 (by omega) (by omega)
           · by_cases h1572 : i < 1572
             · exact FloorIndex.rangeOK_at bl1560 (by omega) (by omega)
             · by_cases h1584 : i < 1584
               · exact FloorIndex.rangeOK_at bl1572 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1584 (by omega) (by omega)
       · by_cases h1656 : i < 1656
         · by_cases h1620 : i < 1620
           · by_cases h1608 : i < 1608
             · exact FloorIndex.rangeOK_at bl1596 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1608 (by omega) (by omega)
           · by_cases h1632 : i < 1632
             · exact FloorIndex.rangeOK_at bl1620 (by omega) (by omega)
             · by_cases h1644 : i < 1644
               · exact FloorIndex.rangeOK_at bl1632 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1644 (by omega) (by omega)
         · by_cases h1692 : i < 1692
           · by_cases h1668 : i < 1668
             · exact FloorIndex.rangeOK_at bl1656 (by omega) (by omega)
             · by_cases h1680 : i < 1680
               · exact FloorIndex.rangeOK_at bl1668 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1680 (by omega) (by omega)
           · by_cases h1704 : i < 1704
             · exact FloorIndex.rangeOK_at bl1692 (by omega) (by omega)
             · by_cases h1716 : i < 1716
               · exact FloorIndex.rangeOK_at bl1704 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1716 (by omega) (by omega)
     · by_cases h1848 : i < 1848
       · by_cases h1788 : i < 1788
         · by_cases h1752 : i < 1752
           · by_cases h1740 : i < 1740
             · exact FloorIndex.rangeOK_at bl1728 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1740 (by omega) (by omega)
           · by_cases h1764 : i < 1764
             · exact FloorIndex.rangeOK_at bl1752 (by omega) (by omega)
             · by_cases h1776 : i < 1776
               · exact FloorIndex.rangeOK_at bl1764 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1776 (by omega) (by omega)
         · by_cases h1812 : i < 1812
           · by_cases h1800 : i < 1800
             · exact FloorIndex.rangeOK_at bl1788 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1800 (by omega) (by omega)
           · by_cases h1824 : i < 1824
             · exact FloorIndex.rangeOK_at bl1812 (by omega) (by omega)
             · by_cases h1836 : i < 1836
               · exact FloorIndex.rangeOK_at bl1824 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1836 (by omega) (by omega)
       · by_cases h1908 : i < 1908
         · by_cases h1872 : i < 1872
           · by_cases h1860 : i < 1860
             · exact FloorIndex.rangeOK_at bl1848 (by omega) (by omega)
             · exact FloorIndex.rangeOK_at bl1860 (by omega) (by omega)
           · by_cases h1884 : i < 1884
             · exact FloorIndex.rangeOK_at bl1872 (by omega) (by omega)
             · by_cases h1896 : i < 1896
               · exact FloorIndex.rangeOK_at bl1884 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1896 (by omega) (by omega)
         · by_cases h1944 : i < 1944
           · by_cases h1920 : i < 1920
             · exact FloorIndex.rangeOK_at bl1908 (by omega) (by omega)
             · by_cases h1932 : i < 1932
               · exact FloorIndex.rangeOK_at bl1920 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1932 (by omega) (by omega)
           · by_cases h1956 : i < 1956
             · exact FloorIndex.rangeOK_at bl1944 (by omega) (by omega)
             · by_cases h1968 : i < 1968
               · exact FloorIndex.rangeOK_at bl1956 (by omega) (by omega)
               · exact FloorIndex.rangeOK_at bl1968 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 1969
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e302902171894 := by
 intro he
 have hp : replay [[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] (call e302902171894 (.lam (.lam (.var 0))) (.lam (.lam (.var 0))) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R302902171894
