import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e301453212270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e301453212270 : Closed e301453212270 ∧ code e301453212270 = 1400964840046 := by decide
theorem cert_e301453212270 : check e301453212270 [[],[]] .three = true := by decide
def e301453212278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e301453212278 : Closed e301453212278 ∧ code e301453212278 = 1400964840054 := by decide
theorem cert_e301453212278 : check e301453212278 [[],[]] .three = true := by decide
def e301453212282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e301453212282 : Closed e301453212282 ∧ code e301453212282 = 1400964840058 := by decide
theorem cert_e301453212282 : check e301453212282 [[],[]] .three = true := by decide
def e301453212470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e301453212470 : Closed e301453212470 ∧ code e301453212470 = 1400964840246 := by decide
theorem cert_e301453212470 : check e301453212470 [[],[]] .three = true := by decide
def e301453212474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e301453212474 : Closed e301453212474 ∧ code e301453212474 = 1400964840250 := by decide
theorem cert_e301453212474 : check e301453212474 [[],[]] .three = true := by decide
def e301453212570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e301453212570 : Closed e301453212570 ∧ code e301453212570 = 1400964840346 := by decide
theorem cert_e301453212570 : check e301453212570 [[],[]] .three = true := by decide
def e301453216622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e301453216622 : Closed e301453216622 ∧ code e301453216622 = 1400964844398 := by decide
theorem cert_e301453216622 : check e301453216622 [[],[]] .smaller = true := by decide
def e301453216630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e301453216630 : Closed e301453216630 ∧ code e301453216630 = 1400964844406 := by decide
theorem cert_e301453216630 : check e301453216630 [[],[]] .smaller = true := by decide
def e301453216686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e301453216686 : Closed e301453216686 ∧ code e301453216686 = 1400964844462 := by decide
theorem cert_e301453216686 : check e301453216686 [[],[]] .smaller = true := by decide
def e301453216698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e301453216698 : Closed e301453216698 ∧ code e301453216698 = 1400964844474 := by decide
theorem cert_e301453216698 : check e301453216698 [[],[]] .smaller = true := by decide
def e301453216726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e301453216726 : Closed e301453216726 ∧ code e301453216726 = 1400964844502 := by decide
theorem cert_e301453216726 : check e301453216726 [[],[]] .smaller = true := by decide
def e301453216730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e301453216730 : Closed e301453216730 ∧ code e301453216730 = 1400964844506 := by decide
theorem cert_e301453216730 : check e301453216730 [[],[]] .smaller = true := by decide
def e301453217006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e301453217006 : Closed e301453217006 ∧ code e301453217006 = 1400964844782 := by decide
theorem cert_e301453217006 : check e301453217006 [[],[]] .smaller = true := by decide
def e301453217014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e301453217014 : Closed e301453217014 ∧ code e301453217014 = 1400964844790 := by decide
theorem cert_e301453217014 : check e301453217014 [[],[]] .smaller = true := by decide
def e301453217390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e301453217390 : Closed e301453217390 ∧ code e301453217390 = 1400964845166 := by decide
theorem cert_e301453217390 : check e301453217390 [[],[]] .smaller = true := by decide
def e301453217402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e301453217402 : Closed e301453217402 ∧ code e301453217402 = 1400964845178 := by decide
theorem cert_e301453217402 : check e301453217402 [[],[]] .smaller = true := by decide
def e301453217590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e301453217590 : Closed e301453217590 ∧ code e301453217590 = 1400964845366 := by decide
theorem cert_e301453217590 : check e301453217590 [[],[]] .smaller = true := by decide
def e301453217594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e301453217594 : Closed e301453217594 ∧ code e301453217594 = 1400964845370 := by decide
theorem cert_e301453217594 : check e301453217594 [[],[]] .smaller = true := by decide
def e301453225438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e301453225438 : Closed e301453225438 ∧ code e301453225438 = 1400964853214 := by decide
theorem cert_e301453225438 : check e301453225438 [[],[]] .three = true := by decide
def e301453225454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e301453225454 : Closed e301453225454 ∧ code e301453225454 = 1400964853230 := by decide
theorem cert_e301453225454 : check e301453225454 [[],[]] .three = true := by decide
def e301453225694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e301453225694 : Closed e301453225694 ∧ code e301453225694 = 1400964853470 := by decide
theorem cert_e301453225694 : check e301453225694 [[],[]] .three = true := by decide
def e301453225710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e301453225710 : Closed e301453225710 ∧ code e301453225710 = 1400964853486 := by decide
theorem cert_e301453225710 : check e301453225710 [[],[]] .smaller = true := by decide
def e301453225718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e301453225718 : Closed e301453225718 ∧ code e301453225718 = 1400964853494 := by decide
theorem cert_e301453225718 : check e301453225718 [[],[]] .three = true := by decide
def e301453225822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e301453225822 : Closed e301453225822 ∧ code e301453225822 = 1400964853598 := by decide
theorem cert_e301453225822 : check e301453225822 [[],[]] .three = true := by decide
def e301453225838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e301453225838 : Closed e301453225838 ∧ code e301453225838 = 1400964853614 := by decide
theorem cert_e301453225838 : check e301453225838 [[],[]] .smaller = true := by decide
def e301453225846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e301453225846 : Closed e301453225846 ∧ code e301453225846 = 1400964853622 := by decide
theorem cert_e301453225846 : check e301453225846 [[],[]] .smaller = true := by decide
def e301453225850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e301453225850 : Closed e301453225850 ∧ code e301453225850 = 1400964853626 := by decide
theorem cert_e301453225850 : check e301453225850 [[],[]] .three = true := by decide
def e301453225902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e301453225902 : Closed e301453225902 ∧ code e301453225902 = 1400964853678 := by decide
theorem cert_e301453225902 : check e301453225902 [[],[]] .three = true := by decide
def e301453225910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e301453225910 : Closed e301453225910 ∧ code e301453225910 = 1400964853686 := by decide
theorem cert_e301453225910 : check e301453225910 [[],[]] .three = true := by decide
def e301453225914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e301453225914 : Closed e301453225914 ∧ code e301453225914 = 1400964853690 := by decide
theorem cert_e301453225914 : check e301453225914 [[],[]] .three = true := by decide
def e301453226974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e301453226974 : Closed e301453226974 ∧ code e301453226974 = 1400964854750 := by decide
theorem cert_e301453226974 : check e301453226974 [[],[]] .three = true := by decide
def e301453226990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e301453226990 : Closed e301453226990 ∧ code e301453226990 = 1400964854766 := by decide
theorem cert_e301453226990 : check e301453226990 [[],[]] .three = true := by decide
def e301453228510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e301453228510 : Closed e301453228510 ∧ code e301453228510 = 1400964856286 := by decide
theorem cert_e301453228510 : check e301453228510 [[],[]] .three = true := by decide
def e301453228526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e301453228526 : Closed e301453228526 ∧ code e301453228526 = 1400964856302 := by decide
theorem cert_e301453228526 : check e301453228526 [[],[]] .smaller = true := by decide
def e301453228534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e301453228534 : Closed e301453228534 ∧ code e301453228534 = 1400964856310 := by decide
theorem cert_e301453228534 : check e301453228534 [[],[]] .three = true := by decide
def e301453229278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e301453229278 : Closed e301453229278 ∧ code e301453229278 = 1400964857054 := by decide
theorem cert_e301453229278 : check e301453229278 [[],[]] .three = true := by decide
def e301453229294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e301453229294 : Closed e301453229294 ∧ code e301453229294 = 1400964857070 := by decide
theorem cert_e301453229294 : check e301453229294 [[],[]] .smaller = true := by decide
def e301453229302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e301453229302 : Closed e301453229302 ∧ code e301453229302 = 1400964857078 := by decide
theorem cert_e301453229302 : check e301453229302 [[],[]] .smaller = true := by decide
def e301453229306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e301453229306 : Closed e301453229306 ∧ code e301453229306 = 1400964857082 := by decide
theorem cert_e301453229306 : check e301453229306 [[],[]] .three = true := by decide
def e301453229678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e301453229678 : Closed e301453229678 ∧ code e301453229678 = 1400964857454 := by decide
theorem cert_e301453229678 : check e301453229678 [[],[]] .three = true := by decide
def e301453229686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e301453229686 : Closed e301453229686 ∧ code e301453229686 = 1400964857462 := by decide
theorem cert_e301453229686 : check e301453229686 [[],[]] .three = true := by decide
def e301453229690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e301453229690 : Closed e301453229690 ∧ code e301453229690 = 1400964857466 := by decide
theorem cert_e301453229690 : check e301453229690 [[],[]] .three = true := by decide
def e301453252318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e301453252318 : Closed e301453252318 ∧ code e301453252318 = 1400964880094 := by decide
theorem cert_e301453252318 : check e301453252318 [[],[]] .three = true := by decide
def e301453252334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e301453252334 : Closed e301453252334 ∧ code e301453252334 = 1400964880110 := by decide
theorem cert_e301453252334 : check e301453252334 [[],[]] .smaller = true := by decide
def e301453252342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e301453252342 : Closed e301453252342 ∧ code e301453252342 = 1400964880118 := by decide
theorem cert_e301453252342 : check e301453252342 [[],[]] .three = true := by decide
def e301453252446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e301453252446 : Closed e301453252446 ∧ code e301453252446 = 1400964880222 := by decide
theorem cert_e301453252446 : check e301453252446 [[],[]] .three = true := by decide
def e301453252474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e301453252474 : Closed e301453252474 ∧ code e301453252474 = 1400964880250 := by decide
theorem cert_e301453252474 : check e301453252474 [[],[]] .three = true := by decide
def e301453252526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e301453252526 : Closed e301453252526 ∧ code e301453252526 = 1400964880302 := by decide
theorem cert_e301453252526 : check e301453252526 [[],[]] .smaller = true := by decide
def e301453252538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e301453252538 : Closed e301453252538 ∧ code e301453252538 = 1400964880314 := by decide
theorem cert_e301453252538 : check e301453252538 [[],[]] .smaller = true := by decide
def e301453252566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e301453252566 : Closed e301453252566 ∧ code e301453252566 = 1400964880342 := by decide
theorem cert_e301453252566 : check e301453252566 [[],[]] .three = true := by decide
def e301453252570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e301453252570 : Closed e301453252570 ∧ code e301453252570 = 1400964880346 := by decide
theorem cert_e301453252570 : check e301453252570 [[],[]] .three = true := by decide
def e301453253086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e301453253086 : Closed e301453253086 ∧ code e301453253086 = 1400964880862 := by decide
theorem cert_e301453253086 : check e301453253086 [[],[]] .three = true := by decide
def e301453253102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e301453253102 : Closed e301453253102 ∧ code e301453253102 = 1400964880878 := by decide
theorem cert_e301453253102 : check e301453253102 [[],[]] .smaller = true := by decide
def e301453253110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e301453253110 : Closed e301453253110 ∧ code e301453253110 = 1400964880886 := by decide
theorem cert_e301453253110 : check e301453253110 [[],[]] .three = true := by decide
def e301453253854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e301453253854 : Closed e301453253854 ∧ code e301453253854 = 1400964881630 := by decide
theorem cert_e301453253854 : check e301453253854 [[],[]] .three = true := by decide
def e301453253882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e301453253882 : Closed e301453253882 ∧ code e301453253882 = 1400964881658 := by decide
theorem cert_e301453253882 : check e301453253882 [[],[]] .three = true := by decide
def e301453254254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e301453254254 : Closed e301453254254 ∧ code e301453254254 = 1400964882030 := by decide
theorem cert_e301453254254 : check e301453254254 [[],[]] .smaller = true := by decide
def e301453254266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e301453254266 : Closed e301453254266 ∧ code e301453254266 = 1400964882042 := by decide
theorem cert_e301453254266 : check e301453254266 [[],[]] .smaller = true := by decide
def e301453254454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e301453254454 : Closed e301453254454 ∧ code e301453254454 = 1400964882230 := by decide
theorem cert_e301453254454 : check e301453254454 [[],[]] .three = true := by decide
def e301453254458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e301453254458 : Closed e301453254458 ∧ code e301453254458 = 1400964882234 := by decide
theorem cert_e301453254458 : check e301453254458 [[],[]] .three = true := by decide
def e301453265758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e301453265758 : Closed e301453265758 ∧ code e301453265758 = 1400964893534 := by decide
theorem cert_e301453265758 : check e301453265758 [[],[]] .three = true := by decide
def e301453265774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e301453265774 : Closed e301453265774 ∧ code e301453265774 = 1400964893550 := by decide
theorem cert_e301453265774 : check e301453265774 [[],[]] .smaller = true := by decide
def e301453265782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e301453265782 : Closed e301453265782 ∧ code e301453265782 = 1400964893558 := by decide
theorem cert_e301453265782 : check e301453265782 [[],[]] .smaller = true := by decide
def e301453265786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e301453265786 : Closed e301453265786 ∧ code e301453265786 = 1400964893562 := by decide
theorem cert_e301453265786 : check e301453265786 [[],[]] .three = true := by decide
def e301453265838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e301453265838 : Closed e301453265838 ∧ code e301453265838 = 1400964893614 := by decide
theorem cert_e301453265838 : check e301453265838 [[],[]] .smaller = true := by decide
def e301453265850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e301453265850 : Closed e301453265850 ∧ code e301453265850 = 1400964893626 := by decide
theorem cert_e301453265850 : check e301453265850 [[],[]] .smaller = true := by decide
def e301453265878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e301453265878 : Closed e301453265878 ∧ code e301453265878 = 1400964893654 := by decide
theorem cert_e301453265878 : check e301453265878 [[],[]] .smaller = true := by decide
def e301453265882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e301453265882 : Closed e301453265882 ∧ code e301453265882 = 1400964893658 := by decide
theorem cert_e301453265882 : check e301453265882 [[],[]] .smaller = true := by decide
def e301453265898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e301453265898 : Closed e301453265898 ∧ code e301453265898 = 1400964893674 := by decide
theorem cert_e301453265898 : check e301453265898 [[],[]] .three = true := by decide
def e301453266142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e301453266142 : Closed e301453266142 ∧ code e301453266142 = 1400964893918 := by decide
theorem cert_e301453266142 : check e301453266142 [[],[]] .three = true := by decide
def e301453266158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e301453266158 : Closed e301453266158 ∧ code e301453266158 = 1400964893934 := by decide
theorem cert_e301453266158 : check e301453266158 [[],[]] .smaller = true := by decide
def e301453266166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e301453266166 : Closed e301453266166 ∧ code e301453266166 = 1400964893942 := by decide
theorem cert_e301453266166 : check e301453266166 [[],[]] .smaller = true := by decide
def e301453266170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e301453266170 : Closed e301453266170 ∧ code e301453266170 = 1400964893946 := by decide
theorem cert_e301453266170 : check e301453266170 [[],[]] .three = true := by decide
def e301453266542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e301453266542 : Closed e301453266542 ∧ code e301453266542 = 1400964894318 := by decide
theorem cert_e301453266542 : check e301453266542 [[],[]] .smaller = true := by decide
def e301453266554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e301453266554 : Closed e301453266554 ∧ code e301453266554 = 1400964894330 := by decide
theorem cert_e301453266554 : check e301453266554 [[],[]] .smaller = true := by decide
def e301453266742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e301453266742 : Closed e301453266742 ∧ code e301453266742 = 1400964894518 := by decide
theorem cert_e301453266742 : check e301453266742 [[],[]] .smaller = true := by decide
def e301453266746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e301453266746 : Closed e301453266746 ∧ code e301453266746 = 1400964894522 := by decide
theorem cert_e301453266746 : check e301453266746 [[],[]] .smaller = true := by decide
def e301453266842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e301453266842 : Closed e301453266842 ∧ code e301453266842 = 1400964894618 := by decide
theorem cert_e301453266842 : check e301453266842 [[],[]] .three = true := by decide
def e301453272494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e301453272494 : Closed e301453272494 ∧ code e301453272494 = 1400964900270 := by decide
theorem cert_e301453272494 : check e301453272494 [[],[]] .three = true := by decide
def e301453272502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e301453272502 : Closed e301453272502 ∧ code e301453272502 = 1400964900278 := by decide
theorem cert_e301453272502 : check e301453272502 [[],[]] .three = true := by decide
def e301453272506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e301453272506 : Closed e301453272506 ∧ code e301453272506 = 1400964900282 := by decide
theorem cert_e301453272506 : check e301453272506 [[],[]] .three = true := by decide
def e301453272534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e301453272534 : Closed e301453272534 ∧ code e301453272534 = 1400964900310 := by decide
theorem cert_e301453272534 : check e301453272534 [[],[]] .three = true := by decide
def e301453272538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e301453272538 : Closed e301453272538 ∧ code e301453272538 = 1400964900314 := by decide
theorem cert_e301453272538 : check e301453272538 [[],[]] .three = true := by decide
def e301453272554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e301453272554 : Closed e301453272554 ∧ code e301453272554 = 1400964900330 := by decide
theorem cert_e301453272554 : check e301453272554 [[],[]] .three = true := by decide
def e301453272686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e301453272686 : Closed e301453272686 ∧ code e301453272686 = 1400964900462 := by decide
theorem cert_e301453272686 : check e301453272686 [[],[]] .three = true := by decide
def e301453272694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e301453272694 : Closed e301453272694 ∧ code e301453272694 = 1400964900470 := by decide
theorem cert_e301453272694 : check e301453272694 [[],[]] .three = true := by decide
def e301453272698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e301453272698 : Closed e301453272698 ∧ code e301453272698 = 1400964900474 := by decide
theorem cert_e301453272698 : check e301453272698 [[],[]] .three = true := by decide
def e301453272886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e301453272886 : Closed e301453272886 ∧ code e301453272886 = 1400964900662 := by decide
theorem cert_e301453272886 : check e301453272886 [[],[]] .three = true := by decide
def e301453272890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e301453272890 : Closed e301453272890 ∧ code e301453272890 = 1400964900666 := by decide
theorem cert_e301453272890 : check e301453272890 [[],[]] .three = true := by decide
def e301453272986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e301453272986 : Closed e301453272986 ∧ code e301453272986 = 1400964900762 := by decide
theorem cert_e301453272986 : check e301453272986 [[],[]] .three = true := by decide
def e301453718894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e301453718894 : Closed e301453718894 ∧ code e301453718894 = 1400965346670 := by decide
theorem cert_e301453718894 : check e301453718894 [[],[]] .chain = true := by decide
def e301453718902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e301453718902 : Closed e301453718902 ∧ code e301453718902 = 1400965346678 := by decide
theorem cert_e301453718902 : check e301453718902 [[],[]] .chain = true := by decide
def e301453718958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e301453718958 : Closed e301453718958 ∧ code e301453718958 = 1400965346734 := by decide
theorem cert_e301453718958 : check e301453718958 [[],[]] .chain = true := by decide
def e301453718970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e301453718970 : Closed e301453718970 ∧ code e301453718970 = 1400965346746 := by decide
theorem cert_e301453718970 : check e301453718970 [[],[]] .chain = true := by decide
def e301453718998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e301453718998 : Closed e301453718998 ∧ code e301453718998 = 1400965346774 := by decide
theorem cert_e301453718998 : check e301453718998 [[],[]] .chain = true := by decide
def e301453719002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e301453719002 : Closed e301453719002 ∧ code e301453719002 = 1400965346778 := by decide
theorem cert_e301453719002 : check e301453719002 [[],[]] .chain = true := by decide
def e301453719214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e301453719214 : Closed e301453719214 ∧ code e301453719214 = 1400965346990 := by decide
theorem cert_e301453719214 : check e301453719214 [[],[]] .chain = true := by decide
def e301453719226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e301453719226 : Closed e301453719226 ∧ code e301453719226 = 1400965347002 := by decide
theorem cert_e301453719226 : check e301453719226 [[],[]] .chain = true := by decide
def e301453719274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e301453719274 : Closed e301453719274 ∧ code e301453719274 = 1400965347050 := by decide
theorem cert_e301453719274 : check e301453719274 [[],[]] .chain = true := by decide
def e301453719382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e301453719382 : Closed e301453719382 ∧ code e301453719382 = 1400965347158 := by decide
theorem cert_e301453719382 : check e301453719382 [[],[]] .chain = true := by decide
def e301453719386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e301453719386 : Closed e301453719386 ∧ code e301453719386 = 1400965347162 := by decide
theorem cert_e301453719386 : check e301453719386 [[],[]] .chain = true := by decide
def e301453719402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e301453719402 : Closed e301453719402 ∧ code e301453719402 = 1400965347178 := by decide
theorem cert_e301453719402 : check e301453719402 [[],[]] .chain = true := by decide
def e301453720238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e301453720238 : Closed e301453720238 ∧ code e301453720238 = 1400965348014 := by decide
theorem cert_e301453720238 : check e301453720238 [[],[]] .chain = true := by decide
def e301453720250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e301453720250 : Closed e301453720250 ∧ code e301453720250 = 1400965348026 := by decide
theorem cert_e301453720250 : check e301453720250 [[],[]] .chain = true := by decide
def e301453720298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e301453720298 : Closed e301453720298 ∧ code e301453720298 = 1400965348074 := by decide
theorem cert_e301453720298 : check e301453720298 [[],[]] .chain = true := by decide
def e301453720490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e301453720490 : Closed e301453720490 ∧ code e301453720490 = 1400965348266 := by decide
theorem cert_e301453720490 : check e301453720490 [[],[]] .chain = true := by decide
def e301453720918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e301453720918 : Closed e301453720918 ∧ code e301453720918 = 1400965348694 := by decide
theorem cert_e301453720918 : check e301453720918 [[],[]] .chain = true := by decide
def e301453720922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e301453720922 : Closed e301453720922 ∧ code e301453720922 = 1400965348698 := by decide
theorem cert_e301453720922 : check e301453720922 [[],[]] .chain = true := by decide
def e301453720938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e301453720938 : Closed e301453720938 ∧ code e301453720938 = 1400965348714 := by decide
theorem cert_e301453720938 : check e301453720938 [[],[]] .chain = true := by decide
def e301453721002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e301453721002 : Closed e301453721002 ∧ code e301453721002 = 1400965348778 := by decide
theorem cert_e301453721002 : check e301453721002 [[],[]] .chain = true := by decide
def e301453723502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e301453723502 : Closed e301453723502 ∧ code e301453723502 = 1400965351278 := by decide
theorem cert_e301453723502 : check e301453723502 [[],[]] .chain = true := by decide
def e301453723510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e301453723510 : Closed e301453723510 ∧ code e301453723510 = 1400965351286 := by decide
theorem cert_e301453723510 : check e301453723510 [[],[]] .chain = true := by decide
def e301453723574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e301453723574 : Closed e301453723574 ∧ code e301453723574 = 1400965351350 := by decide
theorem cert_e301453723574 : check e301453723574 [[],[]] .chain = true := by decide
def e301453725038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e301453725038 : Closed e301453725038 ∧ code e301453725038 = 1400965352814 := by decide
theorem cert_e301453725038 : check e301453725038 [[],[]] .chain = true := by decide
def e301453725046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e301453725046 : Closed e301453725046 ∧ code e301453725046 = 1400965352822 := by decide
theorem cert_e301453725046 : check e301453725046 [[],[]] .chain = true := by decide
def e301453725102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e301453725102 : Closed e301453725102 ∧ code e301453725102 = 1400965352878 := by decide
theorem cert_e301453725102 : check e301453725102 [[],[]] .chain = true := by decide
def e301453725114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e301453725114 : Closed e301453725114 ∧ code e301453725114 = 1400965352890 := by decide
theorem cert_e301453725114 : check e301453725114 [[],[]] .chain = true := by decide
def e301453725142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e301453725142 : Closed e301453725142 ∧ code e301453725142 = 1400965352918 := by decide
theorem cert_e301453725142 : check e301453725142 [[],[]] .chain = true := by decide
def e301453725146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e301453725146 : Closed e301453725146 ∧ code e301453725146 = 1400965352922 := by decide
theorem cert_e301453725146 : check e301453725146 [[],[]] .chain = true := by decide
def e301453725358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e301453725358 : Closed e301453725358 ∧ code e301453725358 = 1400965353134 := by decide
theorem cert_e301453725358 : check e301453725358 [[],[]] .chain = true := by decide
def e301453725370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e301453725370 : Closed e301453725370 ∧ code e301453725370 = 1400965353146 := by decide
theorem cert_e301453725370 : check e301453725370 [[],[]] .chain = true := by decide
def e301453725418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e301453725418 : Closed e301453725418 ∧ code e301453725418 = 1400965353194 := by decide
theorem cert_e301453725418 : check e301453725418 [[],[]] .chain = true := by decide
def e301453725526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e301453725526 : Closed e301453725526 ∧ code e301453725526 = 1400965353302 := by decide
theorem cert_e301453725526 : check e301453725526 [[],[]] .chain = true := by decide
def e301453725530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e301453725530 : Closed e301453725530 ∧ code e301453725530 = 1400965353306 := by decide
theorem cert_e301453725530 : check e301453725530 [[],[]] .chain = true := by decide
def e301453725546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e301453725546 : Closed e301453725546 ∧ code e301453725546 = 1400965353322 := by decide
theorem cert_e301453725546 : check e301453725546 [[],[]] .chain = true := by decide
def e301453726574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e301453726574 : Closed e301453726574 ∧ code e301453726574 = 1400965354350 := by decide
theorem cert_e301453726574 : check e301453726574 [[],[]] .chain = true := by decide
def e301453726582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e301453726582 : Closed e301453726582 ∧ code e301453726582 = 1400965354358 := by decide
theorem cert_e301453726582 : check e301453726582 [[],[]] .chain = true := by decide
def e301453726638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e301453726638 : Closed e301453726638 ∧ code e301453726638 = 1400965354414 := by decide
theorem cert_e301453726638 : check e301453726638 [[],[]] .chain = true := by decide
def e301453726650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e301453726650 : Closed e301453726650 ∧ code e301453726650 = 1400965354426 := by decide
theorem cert_e301453726650 : check e301453726650 [[],[]] .chain = true := by decide
def e301453726678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e301453726678 : Closed e301453726678 ∧ code e301453726678 = 1400965354454 := by decide
theorem cert_e301453726678 : check e301453726678 [[],[]] .chain = true := by decide
def e301453726682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e301453726682 : Closed e301453726682 ∧ code e301453726682 = 1400965354458 := by decide
theorem cert_e301453726682 : check e301453726682 [[],[]] .chain = true := by decide
def e301453726958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e301453726958 : Closed e301453726958 ∧ code e301453726958 = 1400965354734 := by decide
theorem cert_e301453726958 : check e301453726958 [[],[]] .chain = true := by decide
def e301453726966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e301453726966 : Closed e301453726966 ∧ code e301453726966 = 1400965354742 := by decide
theorem cert_e301453726966 : check e301453726966 [[],[]] .chain = true := by decide
def e301453727342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e301453727342 : Closed e301453727342 ∧ code e301453727342 = 1400965355118 := by decide
theorem cert_e301453727342 : check e301453727342 [[],[]] .chain = true := by decide
def e301453727354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e301453727354 : Closed e301453727354 ∧ code e301453727354 = 1400965355130 := by decide
theorem cert_e301453727354 : check e301453727354 [[],[]] .chain = true := by decide
def e301453727542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e301453727542 : Closed e301453727542 ∧ code e301453727542 = 1400965355318 := by decide
theorem cert_e301453727542 : check e301453727542 [[],[]] .chain = true := by decide
def e301453727546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e301453727546 : Closed e301453727546 ∧ code e301453727546 = 1400965355322 := by decide
theorem cert_e301453727546 : check e301453727546 [[],[]] .chain = true := by decide
def e301453727982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e301453727982 : Closed e301453727982 ∧ code e301453727982 = 1400965355758 := by decide
theorem cert_e301453727982 : check e301453727982 [[],[]] .chain = true := by decide
def e301453727990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e301453727990 : Closed e301453727990 ∧ code e301453727990 = 1400965355766 := by decide
theorem cert_e301453727990 : check e301453727990 [[],[]] .chain = true := by decide
def e301453728174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e301453728174 : Closed e301453728174 ∧ code e301453728174 = 1400965355950 := by decide
theorem cert_e301453728174 : check e301453728174 [[],[]] .chain = true := by decide
def e301453728186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e301453728186 : Closed e301453728186 ∧ code e301453728186 = 1400965355962 := by decide
theorem cert_e301453728186 : check e301453728186 [[],[]] .chain = true := by decide
def e301453728234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e301453728234 : Closed e301453728234 ∧ code e301453728234 = 1400965356010 := by decide
theorem cert_e301453728234 : check e301453728234 [[],[]] .chain = true := by decide
def e301453728366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e301453728366 : Closed e301453728366 ∧ code e301453728366 = 1400965356142 := by decide
theorem cert_e301453728366 : check e301453728366 [[],[]] .chain = true := by decide
def e301453728378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e301453728378 : Closed e301453728378 ∧ code e301453728378 = 1400965356154 := by decide
theorem cert_e301453728378 : check e301453728378 [[],[]] .chain = true := by decide
def e301453728542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e301453728542 : Closed e301453728542 ∧ code e301453728542 = 1400965356318 := by decide
theorem cert_e301453728542 : check e301453728542 [[],[]] .chain = true := by decide
def e301453728654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e301453728654 : Closed e301453728654 ∧ code e301453728654 = 1400965356430 := by decide
theorem cert_e301453728654 : check e301453728654 [[],[]] .chain = true := by decide
def e301453728666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e301453728666 : Closed e301453728666 ∧ code e301453728666 = 1400965356442 := by decide
theorem cert_e301453728666 : check e301453728666 [[],[]] .chain = true := by decide
def e301453728886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e301453728886 : Closed e301453728886 ∧ code e301453728886 = 1400965356662 := by decide
theorem cert_e301453728886 : check e301453728886 [[],[]] .chain = true := by decide
def e301453728982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e301453728982 : Closed e301453728982 ∧ code e301453728982 = 1400965356758 := by decide
theorem cert_e301453728982 : check e301453728982 [[],[]] .chain = true := by decide
def e301453728986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e301453728986 : Closed e301453728986 ∧ code e301453728986 = 1400965356762 := by decide
theorem cert_e301453728986 : check e301453728986 [[],[]] .chain = true := by decide
def e301453729002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e301453729002 : Closed e301453729002 ∧ code e301453729002 = 1400965356778 := by decide
theorem cert_e301453729002 : check e301453729002 [[],[]] .chain = true := by decide
def e301453729078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e301453729078 : Closed e301453729078 ∧ code e301453729078 = 1400965356854 := by decide
theorem cert_e301453729078 : check e301453729078 [[],[]] .chain = true := by decide
def e301453729082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e301453729082 : Closed e301453729082 ∧ code e301453729082 = 1400965356858 := by decide
theorem cert_e301453729082 : check e301453729082 [[],[]] .chain = true := by decide
def e301453729166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e301453729166 : Closed e301453729166 ∧ code e301453729166 = 1400965356942 := by decide
theorem cert_e301453729166 : check e301453729166 [[],[]] .chain = true := by decide
def e301453729178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e301453729178 : Closed e301453729178 ∧ code e301453729178 = 1400965356954 := by decide
theorem cert_e301453729178 : check e301453729178 [[],[]] .chain = true := by decide
def e301453730670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e301453730670 : Closed e301453730670 ∧ code e301453730670 = 1400965358446 := by decide
theorem cert_e301453730670 : check e301453730670 [[],[]] .chain = true := by decide
def e301453730678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e301453730678 : Closed e301453730678 ∧ code e301453730678 = 1400965358454 := by decide
theorem cert_e301453730678 : check e301453730678 [[],[]] .chain = true := by decide
def e301453730734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e301453730734 : Closed e301453730734 ∧ code e301453730734 = 1400965358510 := by decide
theorem cert_e301453730734 : check e301453730734 [[],[]] .chain = true := by decide
def e301453730746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e301453730746 : Closed e301453730746 ∧ code e301453730746 = 1400965358522 := by decide
theorem cert_e301453730746 : check e301453730746 [[],[]] .chain = true := by decide
def e301453730774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e301453730774 : Closed e301453730774 ∧ code e301453730774 = 1400965358550 := by decide
theorem cert_e301453730774 : check e301453730774 [[],[]] .chain = true := by decide
end Blc.Floor40
