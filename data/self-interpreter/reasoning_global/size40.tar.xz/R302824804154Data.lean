import R302824804154V0
import R302824804154K0
import R302824804154st0
import R302824804154hs0
import CodeBridge
import Batch060
namespace Certgen.R302824804154
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 72,.app 2 63,.app 3 54,.app 4 25,.app 5 22,.app 6 10,.lam 7,.app 8 9,.var 0,.var 0,.lam 11,.lam 12,.app 13 14,.var 1,.lam 15,.app 16 17,.var 2,.app 18 19,.var 2,.app 20 21,.var 1,.var 0,.lam 23,.lam 24,.var 0,.lam 26,.app 27 32,.app 28 29,.var 0,.lam 30,.lam 31,.var 1,.lam 33,.app 34 39,.app 35 36,.var 0,.lam 37,.lam 38,.var 1,.lam 40,.app 41 46,.app 42 43,.var 0,.lam 44,.lam 45,.var 0,.lam 47,.app 48 53,.app 49 50,.var 0,.lam 51,.lam 52,.var 1,.opaque,.app 55 59,.lam 56,.app 57 58,.var 0,.var 0,.lam 60,.app 61 62,.var 0,.var 0,.app 64 68,.lam 65,.app 66 67,.var 0,.var 0,.lam 69,.app 70 71,.var 0,.var 0,.app 73 77,.lam 74,.app 75 76,.var 0,.var 0,.lam 78,.app 79 80,.var 0,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (V20[i-20]?.getD []))
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (if i < 40 then (K20[i-20]?.getD []) else (K40[i-40]?.getD [])))
def st (i : Nat) : AState := if i < 141 then (if i < 80 then (if i < 40 then (if i < 20 then (st0[i-0]?.getD entry) else (st20[i-20]?.getD entry)) else (if i < 60 then (st40[i-40]?.getD entry) else (st60[i-60]?.getD entry))) else (if i < 120 then (if i < 100 then (st80[i-80]?.getD entry) else (st100[i-100]?.getD entry)) else (if i < 140 then (st120[i-120]?.getD entry) else (st140[i-140]?.getD entry)))) else entry
def hs (i : Nat) : List Nat := (if i < 80 then (if i < 40 then (if i < 20 then (hs0[i-0]?.getD []) else (hs20[i-20]?.getD [])) else (if i < 60 then (hs40[i-40]?.getD []) else (hs60[i-60]?.getD []))) else (if i < 120 then (if i < 100 then (hs80[i-80]?.getD []) else (hs100[i-100]?.getD [])) else (if i < 140 then (hs120[i-120]?.getD []) else (hs140[i-140]?.getD []))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R302824804154
