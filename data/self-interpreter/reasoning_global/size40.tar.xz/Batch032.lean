import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302796607354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 3)) (.var 0)))))))
theorem wire_e302796607354 : Closed e302796607354 ∧ code e302796607354 = 1402308235130 := by decide
theorem cert_e302796607354 : check e302796607354 [[],[]] .three = true := by decide
def e302796607406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.var 2)))))))
theorem wire_e302796607406 : Closed e302796607406 ∧ code e302796607406 = 1402308235182 := by decide
theorem cert_e302796607406 : check e302796607406 [[],[]] .three = true := by decide
def e302796607414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.var 1)))))))
theorem wire_e302796607414 : Closed e302796607414 ∧ code e302796607414 = 1402308235190 := by decide
theorem cert_e302796607414 : check e302796607414 [[],[]] .three = true := by decide
def e302796607418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 2)) (.var 0)))))))
theorem wire_e302796607418 : Closed e302796607418 ∧ code e302796607418 = 1402308235194 := by decide
theorem cert_e302796607418 : check e302796607418 [[],[]] .three = true := by decide
def e302796610270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e302796610270 : Closed e302796610270 ∧ code e302796610270 = 1402308238046 := by decide
theorem cert_e302796610270 : check e302796610270 [[],[]] .three = true := by decide
def e302796610294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e302796610294 : Closed e302796610294 ∧ code e302796610294 = 1402308238070 := by decide
theorem cert_e302796610294 : check e302796610294 [[],[]] .three = true := by decide
def e302796610398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e302796610398 : Closed e302796610398 ∧ code e302796610398 = 1402308238174 := by decide
theorem cert_e302796610398 : check e302796610398 [[],[]] .three = true := by decide
def e302796610414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e302796610414 : Closed e302796610414 ∧ code e302796610414 = 1402308238190 := by decide
theorem cert_e302796610414 : check e302796610414 [[],[]] .smaller = true := by decide
def e302796610422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e302796610422 : Closed e302796610422 ∧ code e302796610422 = 1402308238198 := by decide
theorem cert_e302796610422 : check e302796610422 [[],[]] .smaller = true := by decide
def e302796610426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e302796610426 : Closed e302796610426 ∧ code e302796610426 = 1402308238202 := by decide
theorem cert_e302796610426 : check e302796610426 [[],[]] .three = true := by decide
def e302796610486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e302796610486 : Closed e302796610486 ∧ code e302796610486 = 1402308238262 := by decide
theorem cert_e302796610486 : check e302796610486 [[],[]] .smaller = true := by decide
def e302796610518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e302796610518 : Closed e302796610518 ∧ code e302796610518 = 1402308238294 := by decide
theorem cert_e302796610518 : check e302796610518 [[],[]] .three = true := by decide
def e302796610522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e302796610522 : Closed e302796610522 ∧ code e302796610522 = 1402308238298 := by decide
theorem cert_e302796610522 : check e302796610522 [[],[]] .three = true := by decide
def e302796610910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e302796610910 : Closed e302796610910 ∧ code e302796610910 = 1402308238686 := by decide
theorem cert_e302796610910 : check e302796610910 [[],[]] .three = true := by decide
def e302796610926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e302796610926 : Closed e302796610926 ∧ code e302796610926 = 1402308238702 := by decide
theorem cert_e302796610926 : check e302796610926 [[],[]] .smaller = true := by decide
def e302796610934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e302796610934 : Closed e302796610934 ∧ code e302796610934 = 1402308238710 := by decide
theorem cert_e302796610934 : check e302796610934 [[],[]] .smaller = true := by decide
def e302796610938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e302796610938 : Closed e302796610938 ∧ code e302796610938 = 1402308238714 := by decide
theorem cert_e302796610938 : check e302796610938 [[],[]] .three = true := by decide
def e302796610990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e302796610990 : Closed e302796610990 ∧ code e302796610990 = 1402308238766 := by decide
theorem cert_e302796610990 : check e302796610990 [[],[]] .smaller = true := by decide
def e302796611002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e302796611002 : Closed e302796611002 ∧ code e302796611002 = 1402308238778 := by decide
theorem cert_e302796611002 : check e302796611002 [[],[]] .smaller = true := by decide
def e302796611030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e302796611030 : Closed e302796611030 ∧ code e302796611030 = 1402308238806 := by decide
theorem cert_e302796611030 : check e302796611030 [[],[]] .smaller = true := by decide
def e302796611034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e302796611034 : Closed e302796611034 ∧ code e302796611034 = 1402308238810 := by decide
theorem cert_e302796611034 : check e302796611034 [[],[]] .smaller = true := by decide
def e302796611050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e302796611050 : Closed e302796611050 ∧ code e302796611050 = 1402308238826 := by decide
theorem cert_e302796611050 : check e302796611050 [[],[]] .three = true := by decide
def e302796611254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e302796611254 : Closed e302796611254 ∧ code e302796611254 = 1402308239030 := by decide
theorem cert_e302796611254 : check e302796611254 [[],[]] .smaller = true := by decide
def e302796611286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e302796611286 : Closed e302796611286 ∧ code e302796611286 = 1402308239062 := by decide
theorem cert_e302796611286 : check e302796611286 [[],[]] .smaller = true := by decide
def e302796611290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e302796611290 : Closed e302796611290 ∧ code e302796611290 = 1402308239066 := by decide
theorem cert_e302796611290 : check e302796611290 [[],[]] .smaller = true := by decide
def e302796611414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e302796611414 : Closed e302796611414 ∧ code e302796611414 = 1402308239190 := by decide
theorem cert_e302796611414 : check e302796611414 [[],[]] .three = true := by decide
def e302796611418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e302796611418 : Closed e302796611418 ∧ code e302796611418 = 1402308239194 := by decide
theorem cert_e302796611418 : check e302796611418 [[],[]] .three = true := by decide
def e302796611434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e302796611434 : Closed e302796611434 ∧ code e302796611434 = 1402308239210 := by decide
theorem cert_e302796611434 : check e302796611434 [[],[]] .three = true := by decide
def e302796612574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 3)))))))
theorem wire_e302796612574 : Closed e302796612574 ∧ code e302796612574 = 1402308240350 := by decide
theorem cert_e302796612574 : check e302796612574 [[],[]] .three = true := by decide
def e302796612590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 2)))))))
theorem wire_e302796612590 : Closed e302796612590 ∧ code e302796612590 = 1402308240366 := by decide
theorem cert_e302796612590 : check e302796612590 [[],[]] .three = true := by decide
def e302796613342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e302796613342 : Closed e302796613342 ∧ code e302796613342 = 1402308241118 := by decide
theorem cert_e302796613342 : check e302796613342 [[],[]] .three = true := by decide
def e302796613366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e302796613366 : Closed e302796613366 ∧ code e302796613366 = 1402308241142 := by decide
theorem cert_e302796613366 : check e302796613366 [[],[]] .three = true := by decide
def e302796613470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e302796613470 : Closed e302796613470 ∧ code e302796613470 = 1402308241246 := by decide
theorem cert_e302796613470 : check e302796613470 [[],[]] .three = true := by decide
def e302796613486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e302796613486 : Closed e302796613486 ∧ code e302796613486 = 1402308241262 := by decide
theorem cert_e302796613486 : check e302796613486 [[],[]] .smaller = true := by decide
def e302796613494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e302796613494 : Closed e302796613494 ∧ code e302796613494 = 1402308241270 := by decide
theorem cert_e302796613494 : check e302796613494 [[],[]] .smaller = true := by decide
def e302796613498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e302796613498 : Closed e302796613498 ∧ code e302796613498 = 1402308241274 := by decide
theorem cert_e302796613498 : check e302796613498 [[],[]] .three = true := by decide
def e302796613558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e302796613558 : Closed e302796613558 ∧ code e302796613558 = 1402308241334 := by decide
theorem cert_e302796613558 : check e302796613558 [[],[]] .smaller = true := by decide
def e302796613590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e302796613590 : Closed e302796613590 ∧ code e302796613590 = 1402308241366 := by decide
theorem cert_e302796613590 : check e302796613590 [[],[]] .three = true := by decide
def e302796613594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e302796613594 : Closed e302796613594 ∧ code e302796613594 = 1402308241370 := by decide
theorem cert_e302796613594 : check e302796613594 [[],[]] .three = true := by decide
def e302796614110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e302796614110 : Closed e302796614110 ∧ code e302796614110 = 1402308241886 := by decide
theorem cert_e302796614110 : check e302796614110 [[],[]] .three = true := by decide
def e302796614134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e302796614134 : Closed e302796614134 ∧ code e302796614134 = 1402308241910 := by decide
theorem cert_e302796614134 : check e302796614134 [[],[]] .three = true := by decide
def e302796614878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e302796614878 : Closed e302796614878 ∧ code e302796614878 = 1402308242654 := by decide
theorem cert_e302796614878 : check e302796614878 [[],[]] .three = true := by decide
def e302796614894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e302796614894 : Closed e302796614894 ∧ code e302796614894 = 1402308242670 := by decide
theorem cert_e302796614894 : check e302796614894 [[],[]] .smaller = true := by decide
def e302796614902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e302796614902 : Closed e302796614902 ∧ code e302796614902 = 1402308242678 := by decide
theorem cert_e302796614902 : check e302796614902 [[],[]] .smaller = true := by decide
def e302796614906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e302796614906 : Closed e302796614906 ∧ code e302796614906 = 1402308242682 := by decide
theorem cert_e302796614906 : check e302796614906 [[],[]] .three = true := by decide
def e302796615230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 4))))))))
theorem wire_e302796615230 : Closed e302796615230 ∧ code e302796615230 = 1402308243006 := by decide
theorem cert_e302796615230 : check e302796615230 [[],[]] .three = true := by decide
def e302796615286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e302796615286 : Closed e302796615286 ∧ code e302796615286 = 1402308243062 := by decide
theorem cert_e302796615286 : check e302796615286 [[],[]] .smaller = true := by decide
def e302796615454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 3))))))))
theorem wire_e302796615454 : Closed e302796615454 ∧ code e302796615454 = 1402308243230 := by decide
theorem cert_e302796615454 : check e302796615454 [[],[]] .three = true := by decide
def e302796615478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e302796615478 : Closed e302796615478 ∧ code e302796615478 = 1402308243254 := by decide
theorem cert_e302796615478 : check e302796615478 [[],[]] .three = true := by decide
def e302796615482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e302796615482 : Closed e302796615482 ∧ code e302796615482 = 1402308243258 := by decide
theorem cert_e302796615482 : check e302796615482 [[],[]] .three = true := by decide
def e302796616158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e302796616158 : Closed e302796616158 ∧ code e302796616158 = 1402308243934 := by decide
theorem cert_e302796616158 : check e302796616158 [[],[]] .three = true := by decide
def e302796616174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e302796616174 : Closed e302796616174 ∧ code e302796616174 = 1402308243950 := by decide
theorem cert_e302796616174 : check e302796616174 [[],[]] .smaller = true := by decide
def e302796616182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e302796616182 : Closed e302796616182 ∧ code e302796616182 = 1402308243958 := by decide
theorem cert_e302796616182 : check e302796616182 [[],[]] .three = true := by decide
def e302796616542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e302796616542 : Closed e302796616542 ∧ code e302796616542 = 1402308244318 := by decide
theorem cert_e302796616542 : check e302796616542 [[],[]] .three = true := by decide
def e302796616558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e302796616558 : Closed e302796616558 ∧ code e302796616558 = 1402308244334 := by decide
theorem cert_e302796616558 : check e302796616558 [[],[]] .smaller = true := by decide
def e302796616566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e302796616566 : Closed e302796616566 ∧ code e302796616566 = 1402308244342 := by decide
theorem cert_e302796616566 : check e302796616566 [[],[]] .smaller = true := by decide
def e302796616570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e302796616570 : Closed e302796616570 ∧ code e302796616570 = 1402308244346 := by decide
theorem cert_e302796616570 : check e302796616570 [[],[]] .three = true := by decide
def e302796616622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e302796616622 : Closed e302796616622 ∧ code e302796616622 = 1402308244398 := by decide
theorem cert_e302796616622 : check e302796616622 [[],[]] .smaller = true := by decide
def e302796616634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e302796616634 : Closed e302796616634 ∧ code e302796616634 = 1402308244410 := by decide
theorem cert_e302796616634 : check e302796616634 [[],[]] .smaller = true := by decide
def e302796616662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e302796616662 : Closed e302796616662 ∧ code e302796616662 = 1402308244438 := by decide
theorem cert_e302796616662 : check e302796616662 [[],[]] .smaller = true := by decide
def e302796616666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e302796616666 : Closed e302796616666 ∧ code e302796616666 = 1402308244442 := by decide
theorem cert_e302796616666 : check e302796616666 [[],[]] .smaller = true := by decide
def e302796616682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e302796616682 : Closed e302796616682 ∧ code e302796616682 = 1402308244458 := by decide
theorem cert_e302796616682 : check e302796616682 [[],[]] .three = true := by decide
def e302796616926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e302796616926 : Closed e302796616926 ∧ code e302796616926 = 1402308244702 := by decide
theorem cert_e302796616926 : check e302796616926 [[],[]] .three = true := by decide
def e302796616942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e302796616942 : Closed e302796616942 ∧ code e302796616942 = 1402308244718 := by decide
theorem cert_e302796616942 : check e302796616942 [[],[]] .smaller = true := by decide
def e302796616950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e302796616950 : Closed e302796616950 ∧ code e302796616950 = 1402308244726 := by decide
theorem cert_e302796616950 : check e302796616950 [[],[]] .smaller = true := by decide
def e302796616954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e302796616954 : Closed e302796616954 ∧ code e302796616954 = 1402308244730 := by decide
theorem cert_e302796616954 : check e302796616954 [[],[]] .three = true := by decide
def e302796617278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e302796617278 : Closed e302796617278 ∧ code e302796617278 = 1402308245054 := by decide
theorem cert_e302796617278 : check e302796617278 [[],[]] .three = true := by decide
def e302796617326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e302796617326 : Closed e302796617326 ∧ code e302796617326 = 1402308245102 := by decide
theorem cert_e302796617326 : check e302796617326 [[],[]] .smaller = true := by decide
def e302796617338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e302796617338 : Closed e302796617338 ∧ code e302796617338 = 1402308245114 := by decide
theorem cert_e302796617338 : check e302796617338 [[],[]] .smaller = true := by decide
def e302796617502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e302796617502 : Closed e302796617502 ∧ code e302796617502 = 1402308245278 := by decide
theorem cert_e302796617502 : check e302796617502 [[],[]] .smaller = true := by decide
def e302796617526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e302796617526 : Closed e302796617526 ∧ code e302796617526 = 1402308245302 := by decide
theorem cert_e302796617526 : check e302796617526 [[],[]] .smaller = true := by decide
def e302796617530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e302796617530 : Closed e302796617530 ∧ code e302796617530 = 1402308245306 := by decide
theorem cert_e302796617530 : check e302796617530 [[],[]] .smaller = true := by decide
def e302796617614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e302796617614 : Closed e302796617614 ∧ code e302796617614 = 1402308245390 := by decide
theorem cert_e302796617614 : check e302796617614 [[],[]] .three = true := by decide
def e302796617626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e302796617626 : Closed e302796617626 ∧ code e302796617626 = 1402308245402 := by decide
theorem cert_e302796617626 : check e302796617626 [[],[]] .three = true := by decide
def e302796617950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e302796617950 : Closed e302796617950 ∧ code e302796617950 = 1402308245726 := by decide
theorem cert_e302796617950 : check e302796617950 [[],[]] .three = true := by decide
def e302796617966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e302796617966 : Closed e302796617966 ∧ code e302796617966 = 1402308245742 := by decide
theorem cert_e302796617966 : check e302796617966 [[],[]] .smaller = true := by decide
def e302796617974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e302796617974 : Closed e302796617974 ∧ code e302796617974 = 1402308245750 := by decide
theorem cert_e302796617974 : check e302796617974 [[],[]] .smaller = true := by decide
def e302796617978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e302796617978 : Closed e302796617978 ∧ code e302796617978 = 1402308245754 := by decide
theorem cert_e302796617978 : check e302796617978 [[],[]] .three = true := by decide
def e302796618166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e302796618166 : Closed e302796618166 ∧ code e302796618166 = 1402308245942 := by decide
theorem cert_e302796618166 : check e302796618166 [[],[]] .smaller = true := by decide
def e302796618198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e302796618198 : Closed e302796618198 ∧ code e302796618198 = 1402308245974 := by decide
theorem cert_e302796618198 : check e302796618198 [[],[]] .smaller = true := by decide
def e302796618202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e302796618202 : Closed e302796618202 ∧ code e302796618202 = 1402308245978 := by decide
theorem cert_e302796618202 : check e302796618202 [[],[]] .smaller = true := by decide
def e302796618302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e302796618302 : Closed e302796618302 ∧ code e302796618302 = 1402308246078 := by decide
theorem cert_e302796618302 : check e302796618302 [[],[]] .three = true := by decide
def e302796618358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e302796618358 : Closed e302796618358 ∧ code e302796618358 = 1402308246134 := by decide
theorem cert_e302796618358 : check e302796618358 [[],[]] .smaller = true := by decide
def e302796618526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e302796618526 : Closed e302796618526 ∧ code e302796618526 = 1402308246302 := by decide
theorem cert_e302796618526 : check e302796618526 [[],[]] .smaller = true := by decide
def e302796618550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e302796618550 : Closed e302796618550 ∧ code e302796618550 = 1402308246326 := by decide
theorem cert_e302796618550 : check e302796618550 [[],[]] .smaller = true := by decide
def e302796618554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e302796618554 : Closed e302796618554 ∧ code e302796618554 = 1402308246330 := by decide
theorem cert_e302796618554 : check e302796618554 [[],[]] .smaller = true := by decide
def e302796618638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e302796618638 : Closed e302796618638 ∧ code e302796618638 = 1402308246414 := by decide
theorem cert_e302796618638 : check e302796618638 [[],[]] .smaller = true := by decide
def e302796618694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e302796618694 : Closed e302796618694 ∧ code e302796618694 = 1402308246470 := by decide
theorem cert_e302796618694 : check e302796618694 [[],[]] .three = true := by decide
def e302796618718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 3)))))))
theorem wire_e302796618718 : Closed e302796618718 ∧ code e302796618718 = 1402308246494 := by decide
theorem cert_e302796618718 : check e302796618718 [[],[]] .three = true := by decide
def e302796618862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302796618862 : Closed e302796618862 ∧ code e302796618862 = 1402308246638 := by decide
theorem cert_e302796618862 : check e302796618862 [[],[]] .three = true := by decide
def e302796618870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e302796618870 : Closed e302796618870 ∧ code e302796618870 = 1402308246646 := by decide
theorem cert_e302796618870 : check e302796618870 [[],[]] .three = true := by decide
def e302796618874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302796618874 : Closed e302796618874 ∧ code e302796618874 = 1402308246650 := by decide
theorem cert_e302796618874 : check e302796618874 [[],[]] .three = true := by decide
def e302796618966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e302796618966 : Closed e302796618966 ∧ code e302796618966 = 1402308246742 := by decide
theorem cert_e302796618966 : check e302796618966 [[],[]] .three = true := by decide
def e302796618970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e302796618970 : Closed e302796618970 ∧ code e302796618970 = 1402308246746 := by decide
theorem cert_e302796618970 : check e302796618970 [[],[]] .three = true := by decide
def e302796618986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e302796618986 : Closed e302796618986 ∧ code e302796618986 = 1402308246762 := by decide
theorem cert_e302796618986 : check e302796618986 [[],[]] .three = true := by decide
def e302796619038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302796619038 : Closed e302796619038 ∧ code e302796619038 = 1402308246814 := by decide
theorem cert_e302796619038 : check e302796619038 [[],[]] .three = true := by decide
def e302796619062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e302796619062 : Closed e302796619062 ∧ code e302796619062 = 1402308246838 := by decide
theorem cert_e302796619062 : check e302796619062 [[],[]] .three = true := by decide
def e302796619066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e302796619066 : Closed e302796619066 ∧ code e302796619066 = 1402308246842 := by decide
theorem cert_e302796619066 : check e302796619066 [[],[]] .three = true := by decide
def e302796619150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e302796619150 : Closed e302796619150 ∧ code e302796619150 = 1402308246926 := by decide
theorem cert_e302796619150 : check e302796619150 [[],[]] .three = true := by decide
def e302796619162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e302796619162 : Closed e302796619162 ∧ code e302796619162 = 1402308246938 := by decide
theorem cert_e302796619162 : check e302796619162 [[],[]] .three = true := by decide
def e302796619206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302796619206 : Closed e302796619206 ∧ code e302796619206 = 1402308246982 := by decide
theorem cert_e302796619206 : check e302796619206 [[],[]] .three = true := by decide
def e302796619230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 3)))))))
theorem wire_e302796619230 : Closed e302796619230 ∧ code e302796619230 = 1402308247006 := by decide
theorem cert_e302796619230 : check e302796619230 [[],[]] .three = true := by decide
def e302796619246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 2)))))))
theorem wire_e302796619246 : Closed e302796619246 ∧ code e302796619246 = 1402308247022 := by decide
theorem cert_e302796619246 : check e302796619246 [[],[]] .three = true := by decide
def e302796621534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e302796621534 : Closed e302796621534 ∧ code e302796621534 = 1402308249310 := by decide
theorem cert_e302796621534 : check e302796621534 [[],[]] .three = true := by decide
def e302796621550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2)))))))
theorem wire_e302796621550 : Closed e302796621550 ∧ code e302796621550 = 1402308249326 := by decide
theorem cert_e302796621550 : check e302796621550 [[],[]] .smaller = true := by decide
def e302796621558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e302796621558 : Closed e302796621558 ∧ code e302796621558 = 1402308249334 := by decide
theorem cert_e302796621558 : check e302796621558 [[],[]] .three = true := by decide
def e302796621662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e302796621662 : Closed e302796621662 ∧ code e302796621662 = 1402308249438 := by decide
theorem cert_e302796621662 : check e302796621662 [[],[]] .three = true := by decide
def e302796621690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e302796621690 : Closed e302796621690 ∧ code e302796621690 = 1402308249466 := by decide
theorem cert_e302796621690 : check e302796621690 [[],[]] .three = true := by decide
def e302796621742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e302796621742 : Closed e302796621742 ∧ code e302796621742 = 1402308249518 := by decide
theorem cert_e302796621742 : check e302796621742 [[],[]] .smaller = true := by decide
def e302796621754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e302796621754 : Closed e302796621754 ∧ code e302796621754 = 1402308249530 := by decide
theorem cert_e302796621754 : check e302796621754 [[],[]] .smaller = true := by decide
def e302796621782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.var 1)))))))
theorem wire_e302796621782 : Closed e302796621782 ∧ code e302796621782 = 1402308249558 := by decide
theorem cert_e302796621782 : check e302796621782 [[],[]] .three = true := by decide
def e302796621786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 1)) (.var 0)))))))
theorem wire_e302796621786 : Closed e302796621786 ∧ code e302796621786 = 1402308249562 := by decide
theorem cert_e302796621786 : check e302796621786 [[],[]] .three = true := by decide
def e302796623198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e302796623198 : Closed e302796623198 ∧ code e302796623198 = 1402308250974 := by decide
theorem cert_e302796623198 : check e302796623198 [[],[]] .three = true := by decide
def e302796623214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e302796623214 : Closed e302796623214 ∧ code e302796623214 = 1402308250990 := by decide
theorem cert_e302796623214 : check e302796623214 [[],[]] .smaller = true := by decide
def e302796623222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e302796623222 : Closed e302796623222 ∧ code e302796623222 = 1402308250998 := by decide
theorem cert_e302796623222 : check e302796623222 [[],[]] .smaller = true := by decide
def e302796623226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e302796623226 : Closed e302796623226 ∧ code e302796623226 = 1402308251002 := by decide
theorem cert_e302796623226 : check e302796623226 [[],[]] .three = true := by decide
def e302796623278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e302796623278 : Closed e302796623278 ∧ code e302796623278 = 1402308251054 := by decide
theorem cert_e302796623278 : check e302796623278 [[],[]] .smaller = true := by decide
def e302796623290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e302796623290 : Closed e302796623290 ∧ code e302796623290 = 1402308251066 := by decide
theorem cert_e302796623290 : check e302796623290 [[],[]] .smaller = true := by decide
def e302796623318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e302796623318 : Closed e302796623318 ∧ code e302796623318 = 1402308251094 := by decide
theorem cert_e302796623318 : check e302796623318 [[],[]] .smaller = true := by decide
def e302796623322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e302796623322 : Closed e302796623322 ∧ code e302796623322 = 1402308251098 := by decide
theorem cert_e302796623322 : check e302796623322 [[],[]] .smaller = true := by decide
def e302796623338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e302796623338 : Closed e302796623338 ∧ code e302796623338 = 1402308251114 := by decide
theorem cert_e302796623338 : check e302796623338 [[],[]] .three = true := by decide
def e302796623534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e302796623534 : Closed e302796623534 ∧ code e302796623534 = 1402308251310 := by decide
theorem cert_e302796623534 : check e302796623534 [[],[]] .smaller = true := by decide
def e302796623546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e302796623546 : Closed e302796623546 ∧ code e302796623546 = 1402308251322 := by decide
theorem cert_e302796623546 : check e302796623546 [[],[]] .smaller = true := by decide
def e302796623594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e302796623594 : Closed e302796623594 ∧ code e302796623594 = 1402308251370 := by decide
theorem cert_e302796623594 : check e302796623594 [[],[]] .smaller = true := by decide
def e302796623702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e302796623702 : Closed e302796623702 ∧ code e302796623702 = 1402308251478 := by decide
theorem cert_e302796623702 : check e302796623702 [[],[]] .smaller = true := by decide
def e302796623706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e302796623706 : Closed e302796623706 ∧ code e302796623706 = 1402308251482 := by decide
theorem cert_e302796623706 : check e302796623706 [[],[]] .smaller = true := by decide
def e302796623722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e302796623722 : Closed e302796623722 ∧ code e302796623722 = 1402308251498 := by decide
theorem cert_e302796623722 : check e302796623722 [[],[]] .smaller = true := by decide
def e302796623786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e302796623786 : Closed e302796623786 ∧ code e302796623786 = 1402308251562 := by decide
theorem cert_e302796623786 : check e302796623786 [[],[]] .three = true := by decide
def e302796624350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e302796624350 : Closed e302796624350 ∧ code e302796624350 = 1402308252126 := by decide
theorem cert_e302796624350 : check e302796624350 [[],[]] .three = true := by decide
def e302796624366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e302796624366 : Closed e302796624366 ∧ code e302796624366 = 1402308252142 := by decide
theorem cert_e302796624366 : check e302796624366 [[],[]] .smaller = true := by decide
def e302796624374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e302796624374 : Closed e302796624374 ∧ code e302796624374 = 1402308252150 := by decide
theorem cert_e302796624374 : check e302796624374 [[],[]] .three = true := by decide
def e302796624734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e302796624734 : Closed e302796624734 ∧ code e302796624734 = 1402308252510 := by decide
theorem cert_e302796624734 : check e302796624734 [[],[]] .three = true := by decide
def e302796624750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e302796624750 : Closed e302796624750 ∧ code e302796624750 = 1402308252526 := by decide
theorem cert_e302796624750 : check e302796624750 [[],[]] .smaller = true := by decide
def e302796624758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e302796624758 : Closed e302796624758 ∧ code e302796624758 = 1402308252534 := by decide
theorem cert_e302796624758 : check e302796624758 [[],[]] .smaller = true := by decide
def e302796624762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e302796624762 : Closed e302796624762 ∧ code e302796624762 = 1402308252538 := by decide
theorem cert_e302796624762 : check e302796624762 [[],[]] .three = true := by decide
def e302796624814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e302796624814 : Closed e302796624814 ∧ code e302796624814 = 1402308252590 := by decide
theorem cert_e302796624814 : check e302796624814 [[],[]] .smaller = true := by decide
def e302796624826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e302796624826 : Closed e302796624826 ∧ code e302796624826 = 1402308252602 := by decide
theorem cert_e302796624826 : check e302796624826 [[],[]] .smaller = true := by decide
def e302796624854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e302796624854 : Closed e302796624854 ∧ code e302796624854 = 1402308252630 := by decide
theorem cert_e302796624854 : check e302796624854 [[],[]] .smaller = true := by decide
def e302796624858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e302796624858 : Closed e302796624858 ∧ code e302796624858 = 1402308252634 := by decide
theorem cert_e302796624858 : check e302796624858 [[],[]] .smaller = true := by decide
def e302796624874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e302796624874 : Closed e302796624874 ∧ code e302796624874 = 1402308252650 := by decide
theorem cert_e302796624874 : check e302796624874 [[],[]] .three = true := by decide
def e302796625118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e302796625118 : Closed e302796625118 ∧ code e302796625118 = 1402308252894 := by decide
theorem cert_e302796625118 : check e302796625118 [[],[]] .three = true := by decide
def e302796625134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e302796625134 : Closed e302796625134 ∧ code e302796625134 = 1402308252910 := by decide
theorem cert_e302796625134 : check e302796625134 [[],[]] .smaller = true := by decide
def e302796625142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e302796625142 : Closed e302796625142 ∧ code e302796625142 = 1402308252918 := by decide
theorem cert_e302796625142 : check e302796625142 [[],[]] .smaller = true := by decide
def e302796625146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e302796625146 : Closed e302796625146 ∧ code e302796625146 = 1402308252922 := by decide
theorem cert_e302796625146 : check e302796625146 [[],[]] .three = true := by decide
def e302796625470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e302796625470 : Closed e302796625470 ∧ code e302796625470 = 1402308253246 := by decide
theorem cert_e302796625470 : check e302796625470 [[],[]] .three = true := by decide
def e302796625518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e302796625518 : Closed e302796625518 ∧ code e302796625518 = 1402308253294 := by decide
theorem cert_e302796625518 : check e302796625518 [[],[]] .smaller = true := by decide
def e302796625530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e302796625530 : Closed e302796625530 ∧ code e302796625530 = 1402308253306 := by decide
theorem cert_e302796625530 : check e302796625530 [[],[]] .smaller = true := by decide
def e302796625694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e302796625694 : Closed e302796625694 ∧ code e302796625694 = 1402308253470 := by decide
theorem cert_e302796625694 : check e302796625694 [[],[]] .smaller = true := by decide
def e302796625718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e302796625718 : Closed e302796625718 ∧ code e302796625718 = 1402308253494 := by decide
theorem cert_e302796625718 : check e302796625718 [[],[]] .smaller = true := by decide
def e302796625722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e302796625722 : Closed e302796625722 ∧ code e302796625722 = 1402308253498 := by decide
theorem cert_e302796625722 : check e302796625722 [[],[]] .smaller = true := by decide
def e302796625806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e302796625806 : Closed e302796625806 ∧ code e302796625806 = 1402308253582 := by decide
theorem cert_e302796625806 : check e302796625806 [[],[]] .three = true := by decide
def e302796625818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e302796625818 : Closed e302796625818 ∧ code e302796625818 = 1402308253594 := by decide
theorem cert_e302796625818 : check e302796625818 [[],[]] .three = true := by decide
def e302796626142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e302796626142 : Closed e302796626142 ∧ code e302796626142 = 1402308253918 := by decide
theorem cert_e302796626142 : check e302796626142 [[],[]] .three = true := by decide
def e302796626170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e302796626170 : Closed e302796626170 ∧ code e302796626170 = 1402308253946 := by decide
theorem cert_e302796626170 : check e302796626170 [[],[]] .three = true := by decide
def e302796626350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e302796626350 : Closed e302796626350 ∧ code e302796626350 = 1402308254126 := by decide
theorem cert_e302796626350 : check e302796626350 [[],[]] .smaller = true := by decide
def e302796626362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e302796626362 : Closed e302796626362 ∧ code e302796626362 = 1402308254138 := by decide
theorem cert_e302796626362 : check e302796626362 [[],[]] .smaller = true := by decide
def e302796626410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e302796626410 : Closed e302796626410 ∧ code e302796626410 = 1402308254186 := by decide
theorem cert_e302796626410 : check e302796626410 [[],[]] .smaller = true := by decide
def e302796626494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e302796626494 : Closed e302796626494 ∧ code e302796626494 = 1402308254270 := by decide
theorem cert_e302796626494 : check e302796626494 [[],[]] .three = true := by decide
def e302796626542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e302796626542 : Closed e302796626542 ∧ code e302796626542 = 1402308254318 := by decide
theorem cert_e302796626542 : check e302796626542 [[],[]] .smaller = true := by decide
def e302796626554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e302796626554 : Closed e302796626554 ∧ code e302796626554 = 1402308254330 := by decide
theorem cert_e302796626554 : check e302796626554 [[],[]] .smaller = true := by decide
end Blc.Floor40
