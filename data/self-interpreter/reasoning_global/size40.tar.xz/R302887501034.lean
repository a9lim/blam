import CodeBridge
import R302887501034Blk0
import R302887501034Blk6
import R302887501034Blk12
namespace Certgen.R302887501034
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit90 : Term := .var 0
def lit81 : Term := .var 1
def lit73 : Term := .lam lit90
def lit45 : Term := .var 3
def lit80 : Term := .lam lit81
def lit72 : Term := .lam lit73
def lit88 : Term := .app lit90 lit90
def lit46 : Term := .app lit81 lit90
def lit79 : Term := .lam lit80
def lit50 : Term := .lam lit72
def lit87 : Term := .lam lit88
def lit70 : Term := .app lit90 lit72
def lit77 : Term := .app lit90 lit79
def lit44 : Term := .app lit45 lit46
def lit43 : Term := .lam lit44
def lit42 : Term := .lam lit43
def lit82 : Term := .app lit87 lit87
def lit41 : Term := .lam lit42
def lit39 : Term := .app lit90 lit41
def lit38 : Term := .app lit39 lit90
def lit37 : Term := .lam lit38
def lit76 : Term := .app lit77 lit82
def lit75 : Term := .lam lit76
def lit20 : Term := .app lit37 lit46
def lit19 : Term := .lam lit20
def lit18 : Term := .lam lit19
def lit17 : Term := .lam lit18
def lit69 : Term := .app lit70 lit75
def lit68 : Term := .lam lit69
def lit62 : Term := .app lit77 lit68
def lit61 : Term := .lam lit62
def lit55 : Term := .app lit77 lit61
def lit3 : Term := .app lit37 lit17
def lit54 : Term := .lam lit55
def lit2 : Term := .app lit3 lit37
def lit1 : Term := .app lit2 lit50
def lit0 : Term := .app lit1 lit54
def filling : Nat → Term := fun p => Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub90 : model.term 90 = lit90 := model.var_eq 90 0 (by rfl)
theorem sub89 : model.term 89 = lit90 := model.var_eq 89 0 (by rfl)
theorem sub88 : model.term 88 = lit88 := by rw [model.app_eq 88 89 90 (by rfl), sub89, sub90]; rfl
theorem sub87 : model.term 87 = lit87 := by rw [model.lam_eq 87 88 (by rfl), sub88]; rfl
theorem sub86 : model.term 86 = lit90 := model.var_eq 86 0 (by rfl)
theorem sub85 : model.term 85 = lit90 := model.var_eq 85 0 (by rfl)
theorem sub84 : model.term 84 = lit88 := by rw [model.app_eq 84 85 86 (by rfl), sub85, sub86]; rfl
theorem sub83 : model.term 83 = lit87 := by rw [model.lam_eq 83 84 (by rfl), sub84]; rfl
theorem sub82 : model.term 82 = lit82 := by rw [model.app_eq 82 83 87 (by rfl), sub83, sub87]; rfl
theorem sub81 : model.term 81 = lit81 := model.var_eq 81 1 (by rfl)
theorem sub80 : model.term 80 = lit80 := by rw [model.lam_eq 80 81 (by rfl), sub81]; rfl
theorem sub79 : model.term 79 = lit79 := by rw [model.lam_eq 79 80 (by rfl), sub80]; rfl
theorem sub78 : model.term 78 = lit90 := model.var_eq 78 0 (by rfl)
theorem sub77 : model.term 77 = lit77 := by rw [model.app_eq 77 78 79 (by rfl), sub78, sub79]; rfl
theorem sub76 : model.term 76 = lit76 := by rw [model.app_eq 76 77 82 (by rfl), sub77, sub82]; rfl
theorem sub75 : model.term 75 = lit75 := by rw [model.lam_eq 75 76 (by rfl), sub76]; rfl
theorem sub74 : model.term 74 = lit90 := model.var_eq 74 0 (by rfl)
theorem sub73 : model.term 73 = lit73 := by rw [model.lam_eq 73 74 (by rfl), sub74]; rfl
theorem sub72 : model.term 72 = lit72 := by rw [model.lam_eq 72 73 (by rfl), sub73]; rfl
theorem sub71 : model.term 71 = lit90 := model.var_eq 71 0 (by rfl)
theorem sub70 : model.term 70 = lit70 := by rw [model.app_eq 70 71 72 (by rfl), sub71, sub72]; rfl
theorem sub69 : model.term 69 = lit69 := by rw [model.app_eq 69 70 75 (by rfl), sub70, sub75]; rfl
theorem sub68 : model.term 68 = lit68 := by rw [model.lam_eq 68 69 (by rfl), sub69]; rfl
theorem sub67 : model.term 67 = lit81 := model.var_eq 67 1 (by rfl)
theorem sub66 : model.term 66 = lit80 := by rw [model.lam_eq 66 67 (by rfl), sub67]; rfl
theorem sub65 : model.term 65 = lit79 := by rw [model.lam_eq 65 66 (by rfl), sub66]; rfl
theorem sub64 : model.term 64 = lit90 := model.var_eq 64 0 (by rfl)
theorem sub63 : model.term 63 = lit77 := by rw [model.app_eq 63 64 65 (by rfl), sub64, sub65]; rfl
theorem sub62 : model.term 62 = lit62 := by rw [model.app_eq 62 63 68 (by rfl), sub63, sub68]; rfl
theorem sub61 : model.term 61 = lit61 := by rw [model.lam_eq 61 62 (by rfl), sub62]; rfl
theorem sub60 : model.term 60 = lit81 := model.var_eq 60 1 (by rfl)
theorem sub59 : model.term 59 = lit80 := by rw [model.lam_eq 59 60 (by rfl), sub60]; rfl
theorem sub58 : model.term 58 = lit79 := by rw [model.lam_eq 58 59 (by rfl), sub59]; rfl
theorem sub57 : model.term 57 = lit90 := model.var_eq 57 0 (by rfl)
theorem sub56 : model.term 56 = lit77 := by rw [model.app_eq 56 57 58 (by rfl), sub57, sub58]; rfl
theorem sub55 : model.term 55 = lit55 := by rw [model.app_eq 55 56 61 (by rfl), sub56, sub61]; rfl
theorem sub54 : model.term 54 = lit54 := by rw [model.lam_eq 54 55 (by rfl), sub55]; rfl
theorem sub53 : model.term 53 = lit90 := model.var_eq 53 0 (by rfl)
theorem sub52 : model.term 52 = lit73 := by rw [model.lam_eq 52 53 (by rfl), sub53]; rfl
theorem sub51 : model.term 51 = lit72 := by rw [model.lam_eq 51 52 (by rfl), sub52]; rfl
theorem sub50 : model.term 50 = lit50 := by rw [model.lam_eq 50 51 (by rfl), sub51]; rfl
theorem sub49 : model.term 49 = lit90 := model.var_eq 49 0 (by rfl)
theorem sub48 : model.term 48 = lit90 := model.var_eq 48 0 (by rfl)
theorem sub47 : model.term 47 = lit81 := model.var_eq 47 1 (by rfl)
theorem sub46 : model.term 46 = lit46 := by rw [model.app_eq 46 47 48 (by rfl), sub47, sub48]; rfl
theorem sub45 : model.term 45 = lit45 := model.var_eq 45 3 (by rfl)
theorem sub44 : model.term 44 = lit44 := by rw [model.app_eq 44 45 46 (by rfl), sub45, sub46]; rfl
theorem sub43 : model.term 43 = lit43 := by rw [model.lam_eq 43 44 (by rfl), sub44]; rfl
theorem sub42 : model.term 42 = lit42 := by rw [model.lam_eq 42 43 (by rfl), sub43]; rfl
theorem sub41 : model.term 41 = lit41 := by rw [model.lam_eq 41 42 (by rfl), sub42]; rfl
theorem sub40 : model.term 40 = lit90 := model.var_eq 40 0 (by rfl)
theorem sub39 : model.term 39 = lit39 := by rw [model.app_eq 39 40 41 (by rfl), sub40, sub41]; rfl
theorem sub38 : model.term 38 = lit38 := by rw [model.app_eq 38 39 49 (by rfl), sub39, sub49]; rfl
theorem sub37 : model.term 37 = lit37 := by rw [model.lam_eq 37 38 (by rfl), sub38]; rfl
theorem sub36 : model.term 36 = lit90 := model.var_eq 36 0 (by rfl)
theorem sub35 : model.term 35 = lit81 := model.var_eq 35 1 (by rfl)
theorem sub34 : model.term 34 = lit46 := by rw [model.app_eq 34 35 36 (by rfl), sub35, sub36]; rfl
theorem sub33 : model.term 33 = lit90 := model.var_eq 33 0 (by rfl)
theorem sub32 : model.term 32 = lit90 := model.var_eq 32 0 (by rfl)
theorem sub31 : model.term 31 = lit81 := model.var_eq 31 1 (by rfl)
theorem sub30 : model.term 30 = lit46 := by rw [model.app_eq 30 31 32 (by rfl), sub31, sub32]; rfl
theorem sub29 : model.term 29 = lit45 := model.var_eq 29 3 (by rfl)
theorem sub28 : model.term 28 = lit44 := by rw [model.app_eq 28 29 30 (by rfl), sub29, sub30]; rfl
theorem sub27 : model.term 27 = lit43 := by rw [model.lam_eq 27 28 (by rfl), sub28]; rfl
theorem sub26 : model.term 26 = lit42 := by rw [model.lam_eq 26 27 (by rfl), sub27]; rfl
theorem sub25 : model.term 25 = lit41 := by rw [model.lam_eq 25 26 (by rfl), sub26]; rfl
theorem sub24 : model.term 24 = lit90 := model.var_eq 24 0 (by rfl)
theorem sub23 : model.term 23 = lit39 := by rw [model.app_eq 23 24 25 (by rfl), sub24, sub25]; rfl
theorem sub22 : model.term 22 = lit38 := by rw [model.app_eq 22 23 33 (by rfl), sub23, sub33]; rfl
theorem sub21 : model.term 21 = lit37 := by rw [model.lam_eq 21 22 (by rfl), sub22]; rfl
theorem sub20 : model.term 20 = lit20 := by rw [model.app_eq 20 21 34 (by rfl), sub21, sub34]; rfl
theorem sub19 : model.term 19 = lit19 := by rw [model.lam_eq 19 20 (by rfl), sub20]; rfl
theorem sub18 : model.term 18 = lit18 := by rw [model.lam_eq 18 19 (by rfl), sub19]; rfl
theorem sub17 : model.term 17 = lit17 := by rw [model.lam_eq 17 18 (by rfl), sub18]; rfl
theorem sub16 : model.term 16 = lit90 := model.var_eq 16 0 (by rfl)
theorem sub15 : model.term 15 = lit90 := model.var_eq 15 0 (by rfl)
theorem sub14 : model.term 14 = lit81 := model.var_eq 14 1 (by rfl)
theorem sub13 : model.term 13 = lit46 := by rw [model.app_eq 13 14 15 (by rfl), sub14, sub15]; rfl
theorem sub12 : model.term 12 = lit45 := model.var_eq 12 3 (by rfl)
theorem sub11 : model.term 11 = lit44 := by rw [model.app_eq 11 12 13 (by rfl), sub12, sub13]; rfl
theorem sub10 : model.term 10 = lit43 := by rw [model.lam_eq 10 11 (by rfl), sub11]; rfl
theorem sub9 : model.term 9 = lit42 := by rw [model.lam_eq 9 10 (by rfl), sub10]; rfl
theorem sub8 : model.term 8 = lit41 := by rw [model.lam_eq 8 9 (by rfl), sub9]; rfl
theorem sub7 : model.term 7 = lit90 := model.var_eq 7 0 (by rfl)
theorem sub6 : model.term 6 = lit39 := by rw [model.app_eq 6 7 8 (by rfl), sub7, sub8]; rfl
theorem sub5 : model.term 5 = lit38 := by rw [model.app_eq 5 6 16 (by rfl), sub6, sub16]; rfl
theorem sub4 : model.term 4 = lit37 := by rw [model.lam_eq 4 5 (by rfl), sub5]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 17 (by rfl), sub4, sub17]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 37 (by rfl), sub3, sub37]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 50 (by rfl), sub2, sub50]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 54 (by rfl), sub1, sub54]; rfl
theorem allValid (i : Nat) (h : i < 197) : validState i = true := by
 by_cases h96 : i < 96
 · by_cases h48 : i < 48
   · by_cases h24 : i < 24
     · by_cases h12 : i < 12
       · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
     · by_cases h36 : i < 36
       · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
   · by_cases h72 : i < 72
     · by_cases h60 : i < 60
       · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
     · by_cases h84 : i < 84
       · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
 · by_cases h144 : i < 144
   · by_cases h120 : i < 120
     · by_cases h108 : i < 108
       · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl108 (by omega) (by omega)
     · by_cases h132 : i < 132
       · exact FloorIndex.rangeOK_at bl120 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl132 (by omega) (by omega)
   · by_cases h168 : i < 168
     · by_cases h156 : i < 156
       · exact FloorIndex.rangeOK_at bl144 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl156 (by omega) (by omega)
     · by_cases h180 : i < 180
       · exact FloorIndex.rangeOK_at bl168 (by omega) (by omega)
       · by_cases h192 : i < 192
         · exact FloorIndex.rangeOK_at bl180 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl192 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 197
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e302887501034 := by
 intro he
 have hp : replay [[.left,.left],[.left,.left]] (call e302887501034 (.lam (.lam (.lam (.var 0)))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) []) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R302887501034
