import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302803150774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e302803150774 : Closed e302803150774 ∧ code e302803150774 = 1402314778550 := by decide
theorem cert_e302803150774 : check e302803150774 [[],[],[.under,.under]] .three = true := by decide
def e302803150958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e302803150958 : Closed e302803150958 ∧ code e302803150958 = 1402314778734 := by decide
theorem cert_e302803150958 : check e302803150958 [[],[]] .chain = true := by decide
def e302803150970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e302803150970 : Closed e302803150970 ∧ code e302803150970 = 1402314778746 := by decide
theorem cert_e302803150970 : check e302803150970 [[],[]] .chain = true := by decide
def e302803151246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302803151246 : Closed e302803151246 ∧ code e302803151246 = 1402314779022 := by decide
theorem cert_e302803151246 : check e302803151246 [[],[]] .chain = true := by decide
def e302803151302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302803151302 : Closed e302803151302 ∧ code e302803151302 = 1402314779078 := by decide
theorem cert_e302803151302 : check e302803151302 [[],[]] .chain = true := by decide
def e302803151902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 3)))))))))
theorem wire_e302803151902 : Closed e302803151902 ∧ code e302803151902 = 1402314779678 := by decide
theorem cert_e302803151902 : check e302803151902 [[],[]] .chain = true := by decide
def e302803151926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302803151926 : Closed e302803151926 ∧ code e302803151926 = 1402314779702 := by decide
theorem cert_e302803151926 : check e302803151926 [[],[]] .chain = true := by decide
def e302803151930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302803151930 : Closed e302803151930 ∧ code e302803151930 = 1402314779706 := by decide
theorem cert_e302803151930 : check e302803151930 [[],[]] .chain = true := by decide
def e302803152070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302803152070 : Closed e302803152070 ∧ code e302803152070 = 1402314779846 := by decide
theorem cert_e302803152070 : check e302803152070 [[],[]] .chain = true := by decide
def e302803152098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302803152098 : Closed e302803152098 ∧ code e302803152098 = 1402314779874 := by decide
theorem cert_e302803152098 : check e302803152098 [[],[]] .chain = true := by decide
def e302803152110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e302803152110 : Closed e302803152110 ∧ code e302803152110 = 1402314779886 := by decide
theorem cert_e302803152110 : check e302803152110 [[],[],[.under,.under]] .three = true := by decide
def e302803152118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e302803152118 : Closed e302803152118 ∧ code e302803152118 = 1402314779894 := by decide
theorem cert_e302803152118 : check e302803152118 [[],[],[.under,.under]] .three = true := by decide
def e302803152502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e302803152502 : Closed e302803152502 ∧ code e302803152502 = 1402314780278 := by decide
theorem cert_e302803152502 : check e302803152502 [[],[],[.under,.under]] .three = true := by decide
def e302803153014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e302803153014 : Closed e302803153014 ∧ code e302803153014 = 1402314780790 := by decide
theorem cert_e302803153014 : check e302803153014 [[],[]] .chain = true := by decide
def e302803153018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302803153018 : Closed e302803153018 ∧ code e302803153018 = 1402314780794 := by decide
theorem cert_e302803153018 : check e302803153018 [[],[]] .chain = true := by decide
def e302803153114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e302803153114 : Closed e302803153114 ∧ code e302803153114 = 1402314780890 := by decide
theorem cert_e302803153114 : check e302803153114 [[],[]] .chain = true := by decide
def e302803153130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e302803153130 : Closed e302803153130 ∧ code e302803153130 = 1402314780906 := by decide
theorem cert_e302803153130 : check e302803153130 [[],[]] .chain = true := by decide
def e302803153206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e302803153206 : Closed e302803153206 ∧ code e302803153206 = 1402314780982 := by decide
theorem cert_e302803153206 : check e302803153206 [[],[]] .chain = true := by decide
def e302803153210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e302803153210 : Closed e302803153210 ∧ code e302803153210 = 1402314780986 := by decide
theorem cert_e302803153210 : check e302803153210 [[],[]] .chain = true := by decide
def e302803153294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e302803153294 : Closed e302803153294 ∧ code e302803153294 = 1402314781070 := by decide
theorem cert_e302803153294 : check e302803153294 [[],[]] .chain = true := by decide
def e302803153306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e302803153306 : Closed e302803153306 ∧ code e302803153306 = 1402314781082 := by decide
theorem cert_e302803153306 : check e302803153306 [[],[]] .chain = true := by decide
def e302803153350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e302803153350 : Closed e302803153350 ∧ code e302803153350 = 1402314781126 := by decide
theorem cert_e302803153350 : check e302803153350 [[],[]] .chain = true := by decide
def e302803153686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e302803153686 : Closed e302803153686 ∧ code e302803153686 = 1402314781462 := by decide
theorem cert_e302803153686 : check e302803153686 [[],[]] .chain = true := by decide
def e302803153690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e302803153690 : Closed e302803153690 ∧ code e302803153690 = 1402314781466 := by decide
theorem cert_e302803153690 : check e302803153690 [[],[]] .chain = true := by decide
def e302803153734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 1))))))))
theorem wire_e302803153734 : Closed e302803153734 ∧ code e302803153734 = 1402314781510 := by decide
theorem cert_e302803153734 : check e302803153734 [[],[]] .chain = true := by decide
def e302803153762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e302803153762 : Closed e302803153762 ∧ code e302803153762 = 1402314781538 := by decide
theorem cert_e302803153762 : check e302803153762 [[],[]] .chain = true := by decide
def e302803153774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e302803153774 : Closed e302803153774 ∧ code e302803153774 = 1402314781550 := by decide
theorem cert_e302803153774 : check e302803153774 [[],[],[.under,.under]] .three = true := by decide
def e302803153782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e302803153782 : Closed e302803153782 ∧ code e302803153782 = 1402314781558 := by decide
theorem cert_e302803153782 : check e302803153782 [[],[],[.under,.under]] .three = true := by decide
def e302803153802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e302803153802 : Closed e302803153802 ∧ code e302803153802 = 1402314781578 := by decide
theorem cert_e302803153802 : check e302803153802 [[],[]] .chain = true := by decide
def e302803153826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e302803153826 : Closed e302803153826 ∧ code e302803153826 = 1402314781602 := by decide
theorem cert_e302803153826 : check e302803153826 [[],[]] .chain = true := by decide
def e302803153838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e302803153838 : Closed e302803153838 ∧ code e302803153838 = 1402314781614 := by decide
theorem cert_e302803153838 : check e302803153838 [[],[],[.under,.under]] .three = true := by decide
def e302803153850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e302803153850 : Closed e302803153850 ∧ code e302803153850 = 1402314781626 := by decide
theorem cert_e302803153850 : check e302803153850 [[],[],[.under,.under]] .three = true := by decide
def e302803153878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e302803153878 : Closed e302803153878 ∧ code e302803153878 = 1402314781654 := by decide
theorem cert_e302803153878 : check e302803153878 [[],[],[.under,.under]] .three = true := by decide
def e302803153882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e302803153882 : Closed e302803153882 ∧ code e302803153882 = 1402314781658 := by decide
theorem cert_e302803153882 : check e302803153882 [[],[],[.under,.under]] .three = true := by decide
def e302803153950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e302803153950 : Closed e302803153950 ∧ code e302803153950 = 1402314781726 := by decide
theorem cert_e302803153950 : check e302803153950 [[],[]] .chain = true := by decide
def e302803153974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302803153974 : Closed e302803153974 ∧ code e302803153974 = 1402314781750 := by decide
theorem cert_e302803153974 : check e302803153974 [[],[]] .chain = true := by decide
def e302803153978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302803153978 : Closed e302803153978 ∧ code e302803153978 = 1402314781754 := by decide
theorem cert_e302803153978 : check e302803153978 [[],[]] .chain = true := by decide
def e302803154118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302803154118 : Closed e302803154118 ∧ code e302803154118 = 1402314781894 := by decide
theorem cert_e302803154118 : check e302803154118 [[],[]] .chain = true := by decide
def e302803154146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302803154146 : Closed e302803154146 ∧ code e302803154146 = 1402314781922 := by decide
theorem cert_e302803154146 : check e302803154146 [[],[]] .chain = true := by decide
def e302803154158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e302803154158 : Closed e302803154158 ∧ code e302803154158 = 1402314781934 := by decide
theorem cert_e302803154158 : check e302803154158 [[],[],[.under,.under]] .three = true := by decide
def e302803154166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e302803154166 : Closed e302803154166 ∧ code e302803154166 = 1402314781942 := by decide
theorem cert_e302803154166 : check e302803154166 [[],[],[.under,.under]] .three = true := by decide
def e302803154446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e302803154446 : Closed e302803154446 ∧ code e302803154446 = 1402314782222 := by decide
theorem cert_e302803154446 : check e302803154446 [[],[]] .chain = true := by decide
def e302803154530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e302803154530 : Closed e302803154530 ∧ code e302803154530 = 1402314782306 := by decide
theorem cert_e302803154530 : check e302803154530 [[],[]] .chain = true := by decide
def e302803154542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e302803154542 : Closed e302803154542 ∧ code e302803154542 = 1402314782318 := by decide
theorem cert_e302803154542 : check e302803154542 [[],[],[.under,.under]] .three = true := by decide
def e302803154554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e302803154554 : Closed e302803154554 ∧ code e302803154554 = 1402314782330 := by decide
theorem cert_e302803154554 : check e302803154554 [[],[],[.under,.under]] .three = true := by decide
def e302803154742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e302803154742 : Closed e302803154742 ∧ code e302803154742 = 1402314782518 := by decide
theorem cert_e302803154742 : check e302803154742 [[],[],[.under,.under]] .three = true := by decide
def e302803154746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e302803154746 : Closed e302803154746 ∧ code e302803154746 = 1402314782522 := by decide
theorem cert_e302803154746 : check e302803154746 [[],[],[.under,.under]] .three = true := by decide
def e302803155382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e302803155382 : Closed e302803155382 ∧ code e302803155382 = 1402314783158 := by decide
theorem cert_e302803155382 : check e302803155382 [[],[],[.under,.under]] .three = true := by decide
def e302803155414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e302803155414 : Closed e302803155414 ∧ code e302803155414 = 1402314783190 := by decide
theorem cert_e302803155414 : check e302803155414 [[],[],[.under,.under]] .three = true := by decide
def e302803155418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e302803155418 : Closed e302803155418 ∧ code e302803155418 = 1402314783194 := by decide
theorem cert_e302803155418 : check e302803155418 [[],[],[.under,.under]] .three = true := by decide
def e302803155574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e302803155574 : Closed e302803155574 ∧ code e302803155574 = 1402314783350 := by decide
theorem cert_e302803155574 : check e302803155574 [[],[],[.under,.under]] .three = true := by decide
def e302803155766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e302803155766 : Closed e302803155766 ∧ code e302803155766 = 1402314783542 := by decide
theorem cert_e302803155766 : check e302803155766 [[],[],[.under,.under]] .three = true := by decide
def e302803155770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e302803155770 : Closed e302803155770 ∧ code e302803155770 = 1402314783546 := by decide
theorem cert_e302803155770 : check e302803155770 [[],[],[.under,.under]] .three = true := by decide
def e302803158446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e302803158446 : Closed e302803158446 ∧ code e302803158446 = 1402314786222 := by decide
theorem cert_e302803158446 : check e302803158446 [[],[],[.under,.under]] .three = true := by decide
def e302803158458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e302803158458 : Closed e302803158458 ∧ code e302803158458 = 1402314786234 := by decide
theorem cert_e302803158458 : check e302803158458 [[],[],[.under,.under]] .three = true := by decide
def e302803158506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e302803158506 : Closed e302803158506 ∧ code e302803158506 = 1402314786282 := by decide
theorem cert_e302803158506 : check e302803158506 [[],[],[.under,.under]] .three = true := by decide
def e302803158638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e302803158638 : Closed e302803158638 ∧ code e302803158638 = 1402314786414 := by decide
theorem cert_e302803158638 : check e302803158638 [[],[],[.under,.under]] .three = true := by decide
def e302803158650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e302803158650 : Closed e302803158650 ∧ code e302803158650 = 1402314786426 := by decide
theorem cert_e302803158650 : check e302803158650 [[],[],[.under,.under]] .three = true := by decide
def e302803158814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e302803158814 : Closed e302803158814 ∧ code e302803158814 = 1402314786590 := by decide
theorem cert_e302803158814 : check e302803158814 [[],[]] .chain = true := by decide
def e302803158926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e302803158926 : Closed e302803158926 ∧ code e302803158926 = 1402314786702 := by decide
theorem cert_e302803158926 : check e302803158926 [[],[]] .chain = true := by decide
def e302803158938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e302803158938 : Closed e302803158938 ∧ code e302803158938 = 1402314786714 := by decide
theorem cert_e302803158938 : check e302803158938 [[],[],[.under,.under]] .three = true := by decide
def e302803162678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302803162678 : Closed e302803162678 ∧ code e302803162678 = 1402314790454 := by decide
theorem cert_e302803162678 : check e302803162678 [[],[]] .chain = true := by decide
def e302803162682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302803162682 : Closed e302803162682 ∧ code e302803162682 = 1402314790458 := by decide
theorem cert_e302803162682 : check e302803162682 [[],[]] .chain = true := by decide
def e302803162766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302803162766 : Closed e302803162766 ∧ code e302803162766 = 1402314790542 := by decide
theorem cert_e302803162766 : check e302803162766 [[],[]] .chain = true := by decide
def e302803162822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302803162822 : Closed e302803162822 ∧ code e302803162822 = 1402314790598 := by decide
theorem cert_e302803162822 : check e302803162822 [[],[]] .chain = true := by decide
def e302803162902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))))))))
theorem wire_e302803162902 : Closed e302803162902 ∧ code e302803162902 = 1402314790678 := by decide
theorem cert_e302803162902 : check e302803162902 [[],[]] .chain = true := by decide
def e302803162906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302803162906 : Closed e302803162906 ∧ code e302803162906 = 1402314790682 := by decide
theorem cert_e302803162906 : check e302803162906 [[],[]] .chain = true := by decide
def e302803162950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302803162950 : Closed e302803162950 ∧ code e302803162950 = 1402314790726 := by decide
theorem cert_e302803162950 : check e302803162950 [[],[]] .chain = true := by decide
def e302803162978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e302803162978 : Closed e302803162978 ∧ code e302803162978 = 1402314790754 := by decide
theorem cert_e302803162978 : check e302803162978 [[],[]] .chain = true := by decide
def e302803162990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e302803162990 : Closed e302803162990 ∧ code e302803162990 = 1402314790766 := by decide
theorem cert_e302803162990 : check e302803162990 [[],[],[.under,.under]] .three = true := by decide
def e302803162998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e302803162998 : Closed e302803162998 ∧ code e302803162998 = 1402314790774 := by decide
theorem cert_e302803162998 : check e302803162998 [[],[],[.under,.under]] .three = true := by decide
def e302803163062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e302803163062 : Closed e302803163062 ∧ code e302803163062 = 1402314790838 := by decide
theorem cert_e302803163062 : check e302803163062 [[],[],[.under,.under]] .three = true := by decide
def e302803163246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e302803163246 : Closed e302803163246 ∧ code e302803163246 = 1402314791022 := by decide
theorem cert_e302803163246 : check e302803163246 [[],[]] .chain = true := by decide
def e302803163258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e302803163258 : Closed e302803163258 ∧ code e302803163258 = 1402314791034 := by decide
theorem cert_e302803163258 : check e302803163258 [[],[]] .chain = true := by decide
def e302803163534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302803163534 : Closed e302803163534 ∧ code e302803163534 = 1402314791310 := by decide
theorem cert_e302803163534 : check e302803163534 [[],[]] .chain = true := by decide
def e302803163590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302803163590 : Closed e302803163590 ∧ code e302803163590 = 1402314791366 := by decide
theorem cert_e302803163590 : check e302803163590 [[],[]] .chain = true := by decide
def e302803164190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 3))))))))))
theorem wire_e302803164190 : Closed e302803164190 ∧ code e302803164190 = 1402314791966 := by decide
theorem cert_e302803164190 : check e302803164190 [[],[]] .chain = true := by decide
def e302803164214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e302803164214 : Closed e302803164214 ∧ code e302803164214 = 1402314791990 := by decide
theorem cert_e302803164214 : check e302803164214 [[],[]] .chain = true := by decide
def e302803164218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e302803164218 : Closed e302803164218 ∧ code e302803164218 = 1402314791994 := by decide
theorem cert_e302803164218 : check e302803164218 [[],[]] .chain = true := by decide
def e302803164358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302803164358 : Closed e302803164358 ∧ code e302803164358 = 1402314792134 := by decide
theorem cert_e302803164358 : check e302803164358 [[],[]] .chain = true := by decide
def e302803164386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e302803164386 : Closed e302803164386 ∧ code e302803164386 = 1402314792162 := by decide
theorem cert_e302803164386 : check e302803164386 [[],[]] .chain = true := by decide
def e302803164398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e302803164398 : Closed e302803164398 ∧ code e302803164398 = 1402314792174 := by decide
theorem cert_e302803164398 : check e302803164398 [[],[],[.under,.under]] .three = true := by decide
def e302803164406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e302803164406 : Closed e302803164406 ∧ code e302803164406 = 1402314792182 := by decide
theorem cert_e302803164406 : check e302803164406 [[],[],[.under,.under]] .three = true := by decide
def e302803164790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e302803164790 : Closed e302803164790 ∧ code e302803164790 = 1402314792566 := by decide
theorem cert_e302803164790 : check e302803164790 [[],[],[.under,.under]] .three = true := by decide
def e302803174102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302803174102 : Closed e302803174102 ∧ code e302803174102 = 1402314801878 := by decide
theorem cert_e302803174102 : check e302803174102 [[],[],[.under,.under]] .three = true := by decide
def e302803174106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302803174106 : Closed e302803174106 ∧ code e302803174106 = 1402314801882 := by decide
theorem cert_e302803174106 : check e302803174106 [[],[],[.under,.under]] .three = true := by decide
def e302803174122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302803174122 : Closed e302803174122 ∧ code e302803174122 = 1402314801898 := by decide
theorem cert_e302803174122 : check e302803174122 [[],[],[.under,.under]] .three = true := by decide
def e302803174198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302803174198 : Closed e302803174198 ∧ code e302803174198 = 1402314801974 := by decide
theorem cert_e302803174198 : check e302803174198 [[],[],[.under,.under]] .three = true := by decide
def e302803174202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302803174202 : Closed e302803174202 ∧ code e302803174202 = 1402314801978 := by decide
theorem cert_e302803174202 : check e302803174202 [[],[],[.under,.under]] .three = true := by decide
def e302803174286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e302803174286 : Closed e302803174286 ∧ code e302803174286 = 1402314802062 := by decide
theorem cert_e302803174286 : check e302803174286 [[],[]] .chain = true := by decide
def e302803174298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302803174298 : Closed e302803174298 ∧ code e302803174298 = 1402314802074 := by decide
theorem cert_e302803174298 : check e302803174298 [[],[],[.under,.under]] .three = true := by decide
def e302803176214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e302803176214 : Closed e302803176214 ∧ code e302803176214 = 1402314803990 := by decide
theorem cert_e302803176214 : check e302803176214 [[],[]] .chain = true := by decide
def e302803176218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302803176218 : Closed e302803176218 ∧ code e302803176218 = 1402314803994 := by decide
theorem cert_e302803176218 : check e302803176218 [[],[]] .chain = true := by decide
def e302803176262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302803176262 : Closed e302803176262 ∧ code e302803176262 = 1402314804038 := by decide
theorem cert_e302803176262 : check e302803176262 [[],[]] .chain = true := by decide
def e302803176290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e302803176290 : Closed e302803176290 ∧ code e302803176290 = 1402314804066 := by decide
theorem cert_e302803176290 : check e302803176290 [[],[]] .chain = true := by decide
def e302803176302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302803176302 : Closed e302803176302 ∧ code e302803176302 = 1402314804078 := by decide
theorem cert_e302803176302 : check e302803176302 [[],[],[.under,.under]] .three = true := by decide
def e302803176310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302803176310 : Closed e302803176310 ∧ code e302803176310 = 1402314804086 := by decide
theorem cert_e302803176310 : check e302803176310 [[],[],[.under,.under]] .three = true := by decide
def e302803176330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e302803176330 : Closed e302803176330 ∧ code e302803176330 = 1402314804106 := by decide
theorem cert_e302803176330 : check e302803176330 [[],[]] .chain = true := by decide
def e302803176354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e302803176354 : Closed e302803176354 ∧ code e302803176354 = 1402314804130 := by decide
theorem cert_e302803176354 : check e302803176354 [[],[]] .chain = true := by decide
def e302803176366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302803176366 : Closed e302803176366 ∧ code e302803176366 = 1402314804142 := by decide
theorem cert_e302803176366 : check e302803176366 [[],[],[.under,.under]] .three = true := by decide
def e302803176378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302803176378 : Closed e302803176378 ∧ code e302803176378 = 1402314804154 := by decide
theorem cert_e302803176378 : check e302803176378 [[],[],[.under,.under]] .three = true := by decide
def e302803176406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302803176406 : Closed e302803176406 ∧ code e302803176406 = 1402314804182 := by decide
theorem cert_e302803176406 : check e302803176406 [[],[],[.under,.under]] .three = true := by decide
def e302803176410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302803176410 : Closed e302803176410 ∧ code e302803176410 = 1402314804186 := by decide
theorem cert_e302803176410 : check e302803176410 [[],[],[.under,.under]] .three = true := by decide
def e302803176478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e302803176478 : Closed e302803176478 ∧ code e302803176478 = 1402314804254 := by decide
theorem cert_e302803176478 : check e302803176478 [[],[]] .chain = true := by decide
def e302803176502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e302803176502 : Closed e302803176502 ∧ code e302803176502 = 1402314804278 := by decide
theorem cert_e302803176502 : check e302803176502 [[],[]] .chain = true := by decide
def e302803176506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e302803176506 : Closed e302803176506 ∧ code e302803176506 = 1402314804282 := by decide
theorem cert_e302803176506 : check e302803176506 [[],[]] .chain = true := by decide
def e302803176646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302803176646 : Closed e302803176646 ∧ code e302803176646 = 1402314804422 := by decide
theorem cert_e302803176646 : check e302803176646 [[],[]] .chain = true := by decide
def e302803176674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e302803176674 : Closed e302803176674 ∧ code e302803176674 = 1402314804450 := by decide
theorem cert_e302803176674 : check e302803176674 [[],[]] .chain = true := by decide
def e302803176686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302803176686 : Closed e302803176686 ∧ code e302803176686 = 1402314804462 := by decide
theorem cert_e302803176686 : check e302803176686 [[],[],[.under,.under]] .three = true := by decide
def e302803176694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302803176694 : Closed e302803176694 ∧ code e302803176694 = 1402314804470 := by decide
theorem cert_e302803176694 : check e302803176694 [[],[],[.under,.under]] .three = true := by decide
def e302803176974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e302803176974 : Closed e302803176974 ∧ code e302803176974 = 1402314804750 := by decide
theorem cert_e302803176974 : check e302803176974 [[],[]] .chain = true := by decide
def e302803177058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e302803177058 : Closed e302803177058 ∧ code e302803177058 = 1402314804834 := by decide
theorem cert_e302803177058 : check e302803177058 [[],[]] .chain = true := by decide
def e302803177070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302803177070 : Closed e302803177070 ∧ code e302803177070 = 1402314804846 := by decide
theorem cert_e302803177070 : check e302803177070 [[],[],[.under,.under]] .three = true := by decide
def e302803177082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302803177082 : Closed e302803177082 ∧ code e302803177082 = 1402314804858 := by decide
theorem cert_e302803177082 : check e302803177082 [[],[],[.under,.under]] .three = true := by decide
def e302803177270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302803177270 : Closed e302803177270 ∧ code e302803177270 = 1402314805046 := by decide
theorem cert_e302803177270 : check e302803177270 [[],[],[.under,.under]] .three = true := by decide
def e302803177274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302803177274 : Closed e302803177274 ∧ code e302803177274 = 1402314805050 := by decide
theorem cert_e302803177274 : check e302803177274 [[],[],[.under,.under]] .three = true := by decide
def e302803183030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e302803183030 : Closed e302803183030 ∧ code e302803183030 = 1402314810806 := by decide
theorem cert_e302803183030 : check e302803183030 [[],[],[.under,.under]] .three = true := by decide
def e302803183062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e302803183062 : Closed e302803183062 ∧ code e302803183062 = 1402314810838 := by decide
theorem cert_e302803183062 : check e302803183062 [[],[],[.under,.under]] .three = true := by decide
def e302803183066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e302803183066 : Closed e302803183066 ∧ code e302803183066 = 1402314810842 := by decide
theorem cert_e302803183066 : check e302803183066 [[],[],[.under,.under]] .three = true := by decide
def e302803183222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e302803183222 : Closed e302803183222 ∧ code e302803183222 = 1402314810998 := by decide
theorem cert_e302803183222 : check e302803183222 [[],[],[.under,.under]] .three = true := by decide
def e302803183414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e302803183414 : Closed e302803183414 ∧ code e302803183414 = 1402314811190 := by decide
theorem cert_e302803183414 : check e302803183414 [[],[],[.under,.under]] .three = true := by decide
def e302803183418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e302803183418 : Closed e302803183418 ∧ code e302803183418 = 1402314811194 := by decide
theorem cert_e302803183418 : check e302803183418 [[],[],[.under,.under]] .three = true := by decide
def e302818286454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 1)))))
theorem wire_e302818286454 : Closed e302818286454 ∧ code e302818286454 = 1402329914230 := by decide
theorem cert_e302818286454 : check e302818286454 [[],[]] .chain = true := by decide
def e302818286458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))) (.var 0)))))
theorem wire_e302818286458 : Closed e302818286458 ∧ code e302818286458 = 1402329914234 := by decide
theorem cert_e302818286458 : check e302818286458 [[],[]] .chain = true := by decide
def e302818286518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1)))))
theorem wire_e302818286518 : Closed e302818286518 ∧ code e302818286518 = 1402329914294 := by decide
theorem cert_e302818286518 : check e302818286518 [[],[]] .chain = true := by decide
def e302818286554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))) (.var 0)))))
theorem wire_e302818286554 : Closed e302818286554 ∧ code e302818286554 = 1402329914330 := by decide
theorem cert_e302818286554 : check e302818286554 [[],[]] .chain = true := by decide
def e302818286966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 1)))))
theorem wire_e302818286966 : Closed e302818286966 ∧ code e302818286966 = 1402329914742 := by decide
theorem cert_e302818286966 : check e302818286966 [[],[]] .chain = true := by decide
def e302818286970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))) (.var 0)))))
theorem wire_e302818286970 : Closed e302818286970 ∧ code e302818286970 = 1402329914746 := by decide
theorem cert_e302818286970 : check e302818286970 [[],[]] .chain = true := by decide
def e302818287062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1)))))
theorem wire_e302818287062 : Closed e302818287062 ∧ code e302818287062 = 1402329914838 := by decide
theorem cert_e302818287062 : check e302818287062 [[],[]] .chain = true := by decide
def e302818287082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))) (.var 0)))))
theorem wire_e302818287082 : Closed e302818287082 ∧ code e302818287082 = 1402329914858 := by decide
theorem cert_e302818287082 : check e302818287082 [[],[]] .chain = true := by decide
def e302818287286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1)))))
theorem wire_e302818287286 : Closed e302818287286 ∧ code e302818287286 = 1402329915062 := by decide
theorem cert_e302818287286 : check e302818287286 [[],[]] .chain = true := by decide
def e302818287318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1)))))
theorem wire_e302818287318 : Closed e302818287318 ∧ code e302818287318 = 1402329915094 := by decide
theorem cert_e302818287318 : check e302818287318 [[],[]] .chain = true := by decide
def e302818287450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e302818287450 : Closed e302818287450 ∧ code e302818287450 = 1402329915226 := by decide
theorem cert_e302818287450 : check e302818287450 [[],[]] .chain = true := by decide
def e302818287466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e302818287466 : Closed e302818287466 ∧ code e302818287466 = 1402329915242 := by decide
theorem cert_e302818287466 : check e302818287466 [[],[]] .chain = true := by decide
def e302818289526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 1)))))
theorem wire_e302818289526 : Closed e302818289526 ∧ code e302818289526 = 1402329917302 := by decide
theorem cert_e302818289526 : check e302818289526 [[],[]] .chain = true := by decide
def e302818289530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))) (.var 0)))))
theorem wire_e302818289530 : Closed e302818289530 ∧ code e302818289530 = 1402329917306 := by decide
theorem cert_e302818289530 : check e302818289530 [[],[]] .chain = true := by decide
def e302818289590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 1)))))
theorem wire_e302818289590 : Closed e302818289590 ∧ code e302818289590 = 1402329917366 := by decide
theorem cert_e302818289590 : check e302818289590 [[],[]] .chain = true := by decide
def e302818289626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))) (.var 0)))))
theorem wire_e302818289626 : Closed e302818289626 ∧ code e302818289626 = 1402329917402 := by decide
theorem cert_e302818289626 : check e302818289626 [[],[]] .chain = true := by decide
def e302818292598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 1)))))
theorem wire_e302818292598 : Closed e302818292598 ∧ code e302818292598 = 1402329920374 := by decide
theorem cert_e302818292598 : check e302818292598 [[],[]] .chain = true := by decide
def e302818292602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))) (.var 0)))))
theorem wire_e302818292602 : Closed e302818292602 ∧ code e302818292602 = 1402329920378 := by decide
theorem cert_e302818292602 : check e302818292602 [[],[]] .chain = true := by decide
def e302818292694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 1)))))
theorem wire_e302818292694 : Closed e302818292694 ∧ code e302818292694 = 1402329920470 := by decide
theorem cert_e302818292694 : check e302818292694 [[],[]] .chain = true := by decide
def e302818292714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))) (.var 0)))))
theorem wire_e302818292714 : Closed e302818292714 ∧ code e302818292714 = 1402329920490 := by decide
theorem cert_e302818292714 : check e302818292714 [[],[]] .chain = true := by decide
def e302818294198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 1)))))
theorem wire_e302818294198 : Closed e302818294198 ∧ code e302818294198 = 1402329921974 := by decide
theorem cert_e302818294198 : check e302818294198 [[],[]] .chain = true := by decide
def e302818294230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 1)))))
theorem wire_e302818294230 : Closed e302818294230 ∧ code e302818294230 = 1402329922006 := by decide
theorem cert_e302818294230 : check e302818294230 [[],[]] .chain = true := by decide
def e302818295002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e302818295002 : Closed e302818295002 ∧ code e302818295002 = 1402329922778 := by decide
theorem cert_e302818295002 : check e302818295002 [[],[]] .chain = true := by decide
def e302818295018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e302818295018 : Closed e302818295018 ∧ code e302818295018 = 1402329922794 := by decide
theorem cert_e302818295018 : check e302818295018 [[],[]] .chain = true := by decide
def e302818354106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))) (.var 0)))))
theorem wire_e302818354106 : Closed e302818354106 ∧ code e302818354106 = 1402329981882 := by decide
theorem cert_e302818354106 : check e302818354106 [[],[]] .chain = true := by decide
def e302818354138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))) (.var 0)))))
theorem wire_e302818354138 : Closed e302818354138 ∧ code e302818354138 = 1402329981914 := by decide
theorem cert_e302818354138 : check e302818354138 [[],[]] .chain = true := by decide
def e302818356346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))) (.var 0)))))
theorem wire_e302818356346 : Closed e302818356346 ∧ code e302818356346 = 1402329984122 := by decide
theorem cert_e302818356346 : check e302818356346 [[],[]] .chain = true := by decide
def e302818356678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 1))))))
theorem wire_e302818356678 : Closed e302818356678 ∧ code e302818356678 = 1402329984454 := by decide
theorem cert_e302818356678 : check e302818356678 [[],[]] .chain = true := by decide
def e302818356794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))) (.var 0)))))
theorem wire_e302818356794 : Closed e302818356794 ∧ code e302818356794 = 1402329984570 := by decide
theorem cert_e302818356794 : check e302818356794 [[],[]] .chain = true := by decide
def e302818356934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 1))))))
theorem wire_e302818356934 : Closed e302818356934 ∧ code e302818356934 = 1402329984710 := by decide
theorem cert_e302818356934 : check e302818356934 [[],[]] .chain = true := by decide
def e302818357690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))) (.var 0)))))
theorem wire_e302818357690 : Closed e302818357690 ∧ code e302818357690 = 1402329985466 := by decide
theorem cert_e302818357690 : check e302818357690 [[],[]] .chain = true := by decide
def e302818357738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))) (.var 0)))))
theorem wire_e302818357738 : Closed e302818357738 ∧ code e302818357738 = 1402329985514 := by decide
theorem cert_e302818357738 : check e302818357738 [[],[]] .chain = true := by decide
def e302818358394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))) (.var 0)))))
theorem wire_e302818358394 : Closed e302818358394 ∧ code e302818358394 = 1402329986170 := by decide
theorem cert_e302818358394 : check e302818358394 [[],[]] .chain = true := by decide
def e302818358726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 1))))))
theorem wire_e302818358726 : Closed e302818358726 ∧ code e302818358726 = 1402329986502 := by decide
theorem cert_e302818358726 : check e302818358726 [[],[]] .chain = true := by decide
def e302818359066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))) (.var 0)))))
theorem wire_e302818359066 : Closed e302818359066 ∧ code e302818359066 = 1402329986842 := by decide
theorem cert_e302818359066 : check e302818359066 [[],[]] .chain = true := by decide
def e302818359110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 1))))))
theorem wire_e302818359110 : Closed e302818359110 ∧ code e302818359110 = 1402329986886 := by decide
theorem cert_e302818359110 : check e302818359110 [[],[]] .chain = true := by decide
def e302818359514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))) (.var 0)))))
theorem wire_e302818359514 : Closed e302818359514 ∧ code e302818359514 = 1402329987290 := by decide
theorem cert_e302818359514 : check e302818359514 [[],[]] .chain = true := by decide
def e302818359530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))) (.var 0)))))
theorem wire_e302818359530 : Closed e302818359530 ∧ code e302818359530 = 1402329987306 := by decide
theorem cert_e302818359530 : check e302818359530 [[],[]] .chain = true := by decide
end Blc.Floor40
