"""Check coverage and match every certificate to its Lean declaration."""
from collections import Counter
import json
from pathlib import Path
import re

base=Path(__file__).resolve().parent
rows=json.loads((base/'ledger.json').read_text())
certs=json.loads((base/'certs.json').read_text())
wires=(base/'wires.txt').read_text().splitlines()
assert len(set(wires))==len(wires)==len(rows)==10284
assert set(wires)==set(certs)=={r['wire'] for r in rows}
assert {r['wire'] for r in rows if certs[r['wire']][0]=='open'}==set((base/'open.txt').read_text().split())
def paths(ps):
    return '['+','.join('['+','.join('.'+d for d in p)+']' for p in ps)+']'
def decode_at(s,p,d):
    if s[p]=='1':
        j=s.index('0',p)-p-1
        assert 0<=j<d
        return f'(.var {j})',p+j+2
    if s[p+1]=='0':
        x,q=decode_at(s,p+2,d+1)
        return f'(.lam {x})',q
    x,q=decode_at(s,p+2,d)
    y,r=decode_at(s,q,d)
    return f'(.app {x} {y})',r
batch_text=[(base/f'Batch{i:03}.lean').read_text() for i in range(65)]
for b,body in enumerate(batch_text):
    expected=sorted(wires)[b*160:(b+1)*160]
    assert re.findall(r'^def e(\d+) : Term',body,re.M)==[str(int(s,2)) for s in expected]
for i,r in enumerate(rows):
    s=r['wire'];n='e'+str(int(s,2));ast,end=decode_at(s,0,0)
    assert end==len(s)==40
    body=batch_text[i//160]
    assert f'def {n} : Term := {ast}\n' in body
    assert f'theorem wire_{n} : Closed {n} ∧ code {n} = {int("1"+s,2)} := by decide\n' in body
    k,*data=certs[s]
    if k=='open':
        assert r['strength']=='complete'
        continue
    ps=paths(data[0]); name='cert_'+n
    if k=='payload':
        tag=f'checkPay {n} {ps} {data[1]} {paths(data[2])} = true := by decide'
    elif k in ('Wsource','Widentity'):
        tag=f'¬ IsSelfInterpreter {n} :='
        assert f'(ps := {ps})' in body.split('theorem '+name+' : ',1)[1].split('\n',2)[1]
    else:
        tag=f'check {n} {ps} .{k} = true := by decide'
    assert k==r['kind'] and f'theorem {name} : {tag}\n' in body
print(len(rows),'closed wire identities and corresponding Lean declarations matched')
