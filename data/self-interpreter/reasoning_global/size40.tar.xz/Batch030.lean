import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302795547566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e302795547566 : Closed e302795547566 ∧ code e302795547566 = 1402307175342 := by decide
theorem cert_e302795547566 : check e302795547566 [[],[]] .smaller = true := by decide
def e302795547578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e302795547578 : Closed e302795547578 ∧ code e302795547578 = 1402307175354 := by decide
theorem cert_e302795547578 : check e302795547578 [[],[]] .smaller = true := by decide
def e302795547606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e302795547606 : Closed e302795547606 ∧ code e302795547606 = 1402307175382 := by decide
theorem cert_e302795547606 : check e302795547606 [[],[]] .smaller = true := by decide
def e302795547610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e302795547610 : Closed e302795547610 ∧ code e302795547610 = 1402307175386 := by decide
theorem cert_e302795547610 : check e302795547610 [[],[]] .smaller = true := by decide
def e302795548910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e302795548910 : Closed e302795548910 ∧ code e302795548910 = 1402307176686 := by decide
theorem cert_e302795548910 : check e302795548910 [[],[]] .smaller = true := by decide
def e302795548918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e302795548918 : Closed e302795548918 ∧ code e302795548918 = 1402307176694 := by decide
theorem cert_e302795548918 : check e302795548918 [[],[]] .smaller = true := by decide
def e302795549470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e302795549470 : Closed e302795549470 ∧ code e302795549470 = 1402307177246 := by decide
theorem cert_e302795549470 : check e302795549470 [[],[]] .smaller = true := by decide
def e302795549582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e302795549582 : Closed e302795549582 ∧ code e302795549582 = 1402307177358 := by decide
theorem cert_e302795549582 : check e302795549582 [[],[]] .smaller = true := by decide
def e302795549630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 4))))))))
theorem wire_e302795549630 : Closed e302795549630 ∧ code e302795549630 = 1402307177406 := by decide
theorem cert_e302795549630 : check e302795549630 [[],[]] .three = true := by decide
def e302795549678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 2))))))))
theorem wire_e302795549678 : Closed e302795549678 ∧ code e302795549678 = 1402307177454 := by decide
theorem cert_e302795549678 : check e302795549678 [[],[]] .three = true := by decide
def e302795549806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302795549806 : Closed e302795549806 ∧ code e302795549806 = 1402307177582 := by decide
theorem cert_e302795549806 : check e302795549806 [[],[]] .smaller = true := by decide
def e302795549818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302795549818 : Closed e302795549818 ∧ code e302795549818 = 1402307177594 := by decide
theorem cert_e302795549818 : check e302795549818 [[],[]] .smaller = true := by decide
def e302795549982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302795549982 : Closed e302795549982 ∧ code e302795549982 = 1402307177758 := by decide
theorem cert_e302795549982 : check e302795549982 [[],[]] .smaller = true := by decide
def e302795550142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 4))))))))
theorem wire_e302795550142 : Closed e302795550142 ∧ code e302795550142 = 1402307177918 := by decide
theorem cert_e302795550142 : check e302795550142 [[],[]] .three = true := by decide
def e302795550150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302795550150 : Closed e302795550150 ∧ code e302795550150 = 1402307177926 := by decide
theorem cert_e302795550150 : check e302795550150 [[],[]] .smaller = true := by decide
def e302795550198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.var 1))))))))
theorem wire_e302795550198 : Closed e302795550198 ∧ code e302795550198 = 1402307177974 := by decide
theorem cert_e302795550198 : check e302795550198 [[],[]] .three = true := by decide
def e302795550262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302795550262 : Closed e302795550262 ∧ code e302795550262 = 1402307178038 := by decide
theorem cert_e302795550262 : check e302795550262 [[],[]] .smaller = true := by decide
def e302795550266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302795550266 : Closed e302795550266 ∧ code e302795550266 = 1402307178042 := by decide
theorem cert_e302795550266 : check e302795550266 [[],[]] .smaller = true := by decide
def e302795550350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302795550350 : Closed e302795550350 ∧ code e302795550350 = 1402307178126 := by decide
theorem cert_e302795550350 : check e302795550350 [[],[]] .smaller = true := by decide
def e302795550398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 4))))))))
theorem wire_e302795550398 : Closed e302795550398 ∧ code e302795550398 = 1402307178174 := by decide
theorem cert_e302795550398 : check e302795550398 [[],[]] .three = true := by decide
def e302795550406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302795550406 : Closed e302795550406 ∧ code e302795550406 = 1402307178182 := by decide
theorem cert_e302795550406 : check e302795550406 [[],[]] .smaller = true := by decide
def e302795550458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 4)) (.var 0))))))))
theorem wire_e302795550458 : Closed e302795550458 ∧ code e302795550458 = 1402307178234 := by decide
theorem cert_e302795550458 : check e302795550458 [[],[]] .three = true := by decide
def e302795550638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 2))))))))
theorem wire_e302795550638 : Closed e302795550638 ∧ code e302795550638 = 1402307178414 := by decide
theorem cert_e302795550638 : check e302795550638 [[],[]] .three = true := by decide
def e302795550646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.var 1))))))))
theorem wire_e302795550646 : Closed e302795550646 ∧ code e302795550646 = 1402307178422 := by decide
theorem cert_e302795550646 : check e302795550646 [[],[]] .three = true := by decide
def e302795550650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 2)) (.var 0))))))))
theorem wire_e302795550650 : Closed e302795550650 ∧ code e302795550650 = 1402307178426 := by decide
theorem cert_e302795550650 : check e302795550650 [[],[]] .three = true := by decide
def e302795551150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e302795551150 : Closed e302795551150 ∧ code e302795551150 = 1402307178926 := by decide
theorem cert_e302795551150 : check e302795551150 [[],[]] .smaller = true := by decide
def e302795551162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e302795551162 : Closed e302795551162 ∧ code e302795551162 = 1402307178938 := by decide
theorem cert_e302795551162 : check e302795551162 [[],[]] .smaller = true := by decide
def e302795551210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e302795551210 : Closed e302795551210 ∧ code e302795551210 = 1402307178986 := by decide
theorem cert_e302795551210 : check e302795551210 [[],[]] .smaller = true := by decide
def e302795551854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302795551854 : Closed e302795551854 ∧ code e302795551854 = 1402307179630 := by decide
theorem cert_e302795551854 : check e302795551854 [[],[]] .smaller = true := by decide
def e302795551866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302795551866 : Closed e302795551866 ∧ code e302795551866 = 1402307179642 := by decide
theorem cert_e302795551866 : check e302795551866 [[],[]] .smaller = true := by decide
def e302795552030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302795552030 : Closed e302795552030 ∧ code e302795552030 = 1402307179806 := by decide
theorem cert_e302795552030 : check e302795552030 [[],[]] .smaller = true := by decide
def e302795552190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 4))))))))
theorem wire_e302795552190 : Closed e302795552190 ∧ code e302795552190 = 1402307179966 := by decide
theorem cert_e302795552190 : check e302795552190 [[],[]] .three = true := by decide
def e302795552198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302795552198 : Closed e302795552198 ∧ code e302795552198 = 1402307179974 := by decide
theorem cert_e302795552198 : check e302795552198 [[],[]] .smaller = true := by decide
def e302795552246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 1))))))))
theorem wire_e302795552246 : Closed e302795552246 ∧ code e302795552246 = 1402307180022 := by decide
theorem cert_e302795552246 : check e302795552246 [[],[]] .three = true := by decide
def e302795552446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 4))))))))
theorem wire_e302795552446 : Closed e302795552446 ∧ code e302795552446 = 1402307180222 := by decide
theorem cert_e302795552446 : check e302795552446 [[],[]] .three = true := by decide
def e302795552506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 4)) (.var 0))))))))
theorem wire_e302795552506 : Closed e302795552506 ∧ code e302795552506 = 1402307180282 := by decide
theorem cert_e302795552506 : check e302795552506 [[],[]] .three = true := by decide
def e302795552538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302795552538 : Closed e302795552538 ∧ code e302795552538 = 1402307180314 := by decide
theorem cert_e302795552538 : check e302795552538 [[],[]] .smaller = true := by decide
def e302795552582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302795552582 : Closed e302795552582 ∧ code e302795552582 = 1402307180358 := by decide
theorem cert_e302795552582 : check e302795552582 [[],[]] .smaller = true := by decide
def e302795552726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 1))))))))
theorem wire_e302795552726 : Closed e302795552726 ∧ code e302795552726 = 1402307180502 := by decide
theorem cert_e302795552726 : check e302795552726 [[],[]] .three = true := by decide
def e302795552730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 1)) (.var 0))))))))
theorem wire_e302795552730 : Closed e302795552730 ∧ code e302795552730 = 1402307180506 := by decide
theorem cert_e302795552730 : check e302795552730 [[],[]] .three = true := by decide
def e302795552982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e302795552982 : Closed e302795552982 ∧ code e302795552982 = 1402307180758 := by decide
theorem cert_e302795552982 : check e302795552982 [[],[]] .smaller = true := by decide
def e302795552986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e302795552986 : Closed e302795552986 ∧ code e302795552986 = 1402307180762 := by decide
theorem cert_e302795552986 : check e302795552986 [[],[]] .smaller = true := by decide
def e302795553002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e302795553002 : Closed e302795553002 ∧ code e302795553002 = 1402307180778 := by decide
theorem cert_e302795553002 : check e302795553002 [[],[]] .smaller = true := by decide
def e302795553334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302795553334 : Closed e302795553334 ∧ code e302795553334 = 1402307181110 := by decide
theorem cert_e302795553334 : check e302795553334 [[],[]] .smaller = true := by decide
def e302795553338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302795553338 : Closed e302795553338 ∧ code e302795553338 = 1402307181114 := by decide
theorem cert_e302795553338 : check e302795553338 [[],[]] .smaller = true := by decide
def e302795553422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302795553422 : Closed e302795553422 ∧ code e302795553422 = 1402307181198 := by decide
theorem cert_e302795553422 : check e302795553422 [[],[]] .smaller = true := by decide
def e302795553470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 4))))))))
theorem wire_e302795553470 : Closed e302795553470 ∧ code e302795553470 = 1402307181246 := by decide
theorem cert_e302795553470 : check e302795553470 [[],[]] .three = true := by decide
def e302795553478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302795553478 : Closed e302795553478 ∧ code e302795553478 = 1402307181254 := by decide
theorem cert_e302795553478 : check e302795553478 [[],[]] .smaller = true := by decide
def e302795553530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 4)) (.var 0))))))))
theorem wire_e302795553530 : Closed e302795553530 ∧ code e302795553530 = 1402307181306 := by decide
theorem cert_e302795553530 : check e302795553530 [[],[]] .three = true := by decide
def e302795553562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302795553562 : Closed e302795553562 ∧ code e302795553562 = 1402307181338 := by decide
theorem cert_e302795553562 : check e302795553562 [[],[]] .smaller = true := by decide
def e302795553606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302795553606 : Closed e302795553606 ∧ code e302795553606 = 1402307181382 := by decide
theorem cert_e302795553606 : check e302795553606 [[],[]] .smaller = true := by decide
def e302795553770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 4)) (.var 0)) (.var 0))))))))
theorem wire_e302795553770 : Closed e302795553770 ∧ code e302795553770 = 1402307181546 := by decide
theorem cert_e302795553770 : check e302795553770 [[],[]] .three = true := by decide
def e302795554478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e302795554478 : Closed e302795554478 ∧ code e302795554478 = 1402307182254 := by decide
theorem cert_e302795554478 : check e302795554478 [[],[]] .three = true := by decide
def e302795554486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e302795554486 : Closed e302795554486 ∧ code e302795554486 = 1402307182262 := by decide
theorem cert_e302795554486 : check e302795554486 [[],[]] .three = true := by decide
def e302795554490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e302795554490 : Closed e302795554490 ∧ code e302795554490 = 1402307182266 := by decide
theorem cert_e302795554490 : check e302795554490 [[],[]] .three = true := by decide
def e302795554518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e302795554518 : Closed e302795554518 ∧ code e302795554518 = 1402307182294 := by decide
theorem cert_e302795554518 : check e302795554518 [[],[]] .three = true := by decide
def e302795554522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e302795554522 : Closed e302795554522 ∧ code e302795554522 = 1402307182298 := by decide
theorem cert_e302795554522 : check e302795554522 [[],[]] .three = true := by decide
def e302795554538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e302795554538 : Closed e302795554538 ∧ code e302795554538 = 1402307182314 := by decide
theorem cert_e302795554538 : check e302795554538 [[],[]] .three = true := by decide
def e302795558126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e302795558126 : Closed e302795558126 ∧ code e302795558126 = 1402307185902 := by decide
theorem cert_e302795558126 : check e302795558126 [[],[]] .smaller = true := by decide
def e302795558134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e302795558134 : Closed e302795558134 ∧ code e302795558134 = 1402307185910 := by decide
theorem cert_e302795558134 : check e302795558134 [[],[]] .smaller = true := by decide
def e302795558510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e302795558510 : Closed e302795558510 ∧ code e302795558510 = 1402307186286 := by decide
theorem cert_e302795558510 : check e302795558510 [[],[]] .smaller = true := by decide
def e302795558522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e302795558522 : Closed e302795558522 ∧ code e302795558522 = 1402307186298 := by decide
theorem cert_e302795558522 : check e302795558522 [[],[]] .smaller = true := by decide
def e302795558710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e302795558710 : Closed e302795558710 ∧ code e302795558710 = 1402307186486 := by decide
theorem cert_e302795558710 : check e302795558710 [[],[]] .smaller = true := by decide
def e302795558714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e302795558714 : Closed e302795558714 ∧ code e302795558714 = 1402307186490 := by decide
theorem cert_e302795558714 : check e302795558714 [[],[]] .smaller = true := by decide
def e302795561198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e302795561198 : Closed e302795561198 ∧ code e302795561198 = 1402307188974 := by decide
theorem cert_e302795561198 : check e302795561198 [[],[]] .smaller = true := by decide
def e302795561206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e302795561206 : Closed e302795561206 ∧ code e302795561206 = 1402307188982 := by decide
theorem cert_e302795561206 : check e302795561206 [[],[]] .smaller = true := by decide
def e302795561758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e302795561758 : Closed e302795561758 ∧ code e302795561758 = 1402307189534 := by decide
theorem cert_e302795561758 : check e302795561758 [[],[]] .smaller = true := by decide
def e302795561870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e302795561870 : Closed e302795561870 ∧ code e302795561870 = 1402307189646 := by decide
theorem cert_e302795561870 : check e302795561870 [[],[]] .smaller = true := by decide
def e302795561918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 4))))))))
theorem wire_e302795561918 : Closed e302795561918 ∧ code e302795561918 = 1402307189694 := by decide
theorem cert_e302795561918 : check e302795561918 [[],[]] .three = true := by decide
def e302795561966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 2))))))))
theorem wire_e302795561966 : Closed e302795561966 ∧ code e302795561966 = 1402307189742 := by decide
theorem cert_e302795561966 : check e302795561966 [[],[]] .three = true := by decide
def e302795562094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e302795562094 : Closed e302795562094 ∧ code e302795562094 = 1402307189870 := by decide
theorem cert_e302795562094 : check e302795562094 [[],[]] .smaller = true := by decide
def e302795562106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e302795562106 : Closed e302795562106 ∧ code e302795562106 = 1402307189882 := by decide
theorem cert_e302795562106 : check e302795562106 [[],[]] .smaller = true := by decide
def e302795562270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e302795562270 : Closed e302795562270 ∧ code e302795562270 = 1402307190046 := by decide
theorem cert_e302795562270 : check e302795562270 [[],[]] .smaller = true := by decide
def e302795562430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 4))))))))
theorem wire_e302795562430 : Closed e302795562430 ∧ code e302795562430 = 1402307190206 := by decide
theorem cert_e302795562430 : check e302795562430 [[],[]] .three = true := by decide
def e302795562438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e302795562438 : Closed e302795562438 ∧ code e302795562438 = 1402307190214 := by decide
theorem cert_e302795562438 : check e302795562438 [[],[]] .smaller = true := by decide
def e302795562486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.var 1))))))))
theorem wire_e302795562486 : Closed e302795562486 ∧ code e302795562486 = 1402307190262 := by decide
theorem cert_e302795562486 : check e302795562486 [[],[]] .three = true := by decide
def e302795562550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e302795562550 : Closed e302795562550 ∧ code e302795562550 = 1402307190326 := by decide
theorem cert_e302795562550 : check e302795562550 [[],[]] .smaller = true := by decide
def e302795562554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e302795562554 : Closed e302795562554 ∧ code e302795562554 = 1402307190330 := by decide
theorem cert_e302795562554 : check e302795562554 [[],[]] .smaller = true := by decide
def e302795562638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e302795562638 : Closed e302795562638 ∧ code e302795562638 = 1402307190414 := by decide
theorem cert_e302795562638 : check e302795562638 [[],[]] .smaller = true := by decide
def e302795562686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 4))))))))
theorem wire_e302795562686 : Closed e302795562686 ∧ code e302795562686 = 1402307190462 := by decide
theorem cert_e302795562686 : check e302795562686 [[],[]] .three = true := by decide
def e302795562694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e302795562694 : Closed e302795562694 ∧ code e302795562694 = 1402307190470 := by decide
theorem cert_e302795562694 : check e302795562694 [[],[]] .smaller = true := by decide
def e302795562746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 4))) (.var 0))))))))
theorem wire_e302795562746 : Closed e302795562746 ∧ code e302795562746 = 1402307190522 := by decide
theorem cert_e302795562746 : check e302795562746 [[],[]] .three = true := by decide
def e302795562926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 2))))))))
theorem wire_e302795562926 : Closed e302795562926 ∧ code e302795562926 = 1402307190702 := by decide
theorem cert_e302795562926 : check e302795562926 [[],[]] .three = true := by decide
def e302795562934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.var 1))))))))
theorem wire_e302795562934 : Closed e302795562934 ∧ code e302795562934 = 1402307190710 := by decide
theorem cert_e302795562934 : check e302795562934 [[],[]] .three = true := by decide
def e302795562938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 2))) (.var 0))))))))
theorem wire_e302795562938 : Closed e302795562938 ∧ code e302795562938 = 1402307190714 := by decide
theorem cert_e302795562938 : check e302795562938 [[],[]] .three = true := by decide
def e302795564830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e302795564830 : Closed e302795564830 ∧ code e302795564830 = 1402307192606 := by decide
theorem cert_e302795564830 : check e302795564830 [[],[]] .smaller = true := by decide
def e302795564942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e302795564942 : Closed e302795564942 ∧ code e302795564942 = 1402307192718 := by decide
theorem cert_e302795564942 : check e302795564942 [[],[]] .smaller = true := by decide
def e302795564990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 4)))))))))
theorem wire_e302795564990 : Closed e302795564990 ∧ code e302795564990 = 1402307192766 := by decide
theorem cert_e302795564990 : check e302795564990 [[],[]] .three = true := by decide
def e302795565038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 2)))))))))
theorem wire_e302795565038 : Closed e302795565038 ∧ code e302795565038 = 1402307192814 := by decide
theorem cert_e302795565038 : check e302795565038 [[],[]] .three = true := by decide
def e302795567902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302795567902 : Closed e302795567902 ∧ code e302795567902 = 1402307195678 := by decide
theorem cert_e302795567902 : check e302795567902 [[],[]] .smaller = true := by decide
def e302795568062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 4)))))))))
theorem wire_e302795568062 : Closed e302795568062 ∧ code e302795568062 = 1402307195838 := by decide
theorem cert_e302795568062 : check e302795568062 [[],[]] .three = true := by decide
def e302795568070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302795568070 : Closed e302795568070 ∧ code e302795568070 = 1402307195846 := by decide
theorem cert_e302795568070 : check e302795568070 [[],[]] .smaller = true := by decide
def e302795568118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 1)))))))))
theorem wire_e302795568118 : Closed e302795568118 ∧ code e302795568118 = 1402307195894 := by decide
theorem cert_e302795568118 : check e302795568118 [[],[]] .three = true := by decide
def e302795569550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302795569550 : Closed e302795569550 ∧ code e302795569550 = 1402307197326 := by decide
theorem cert_e302795569550 : check e302795569550 [[],[]] .smaller = true := by decide
def e302795569598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 4)))))))))
theorem wire_e302795569598 : Closed e302795569598 ∧ code e302795569598 = 1402307197374 := by decide
theorem cert_e302795569598 : check e302795569598 [[],[]] .three = true := by decide
def e302795569606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302795569606 : Closed e302795569606 ∧ code e302795569606 = 1402307197382 := by decide
theorem cert_e302795569606 : check e302795569606 [[],[]] .smaller = true := by decide
def e302795569658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 4) (.var 0)))))))))
theorem wire_e302795569658 : Closed e302795569658 ∧ code e302795569658 = 1402307197434 := by decide
theorem cert_e302795569658 : check e302795569658 [[],[]] .three = true := by decide
def e302795570798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302795570798 : Closed e302795570798 ∧ code e302795570798 = 1402307198574 := by decide
theorem cert_e302795570798 : check e302795570798 [[],[]] .three = true := by decide
def e302795570806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.var 1)))))))))
theorem wire_e302795570806 : Closed e302795570806 ∧ code e302795570806 = 1402307198582 := by decide
theorem cert_e302795570806 : check e302795570806 [[],[]] .three = true := by decide
def e302795570810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302795570810 : Closed e302795570810 ∧ code e302795570810 = 1402307198586 := by decide
theorem cert_e302795570810 : check e302795570810 [[],[]] .three = true := by decide
def e302795572846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e302795572846 : Closed e302795572846 ∧ code e302795572846 = 1402307200622 := by decide
theorem cert_e302795572846 : check e302795572846 [[],[]] .smaller = true := by decide
def e302795572858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e302795572858 : Closed e302795572858 ∧ code e302795572858 = 1402307200634 := by decide
theorem cert_e302795572858 : check e302795572858 [[],[]] .smaller = true := by decide
def e302795573146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e302795573146 : Closed e302795573146 ∧ code e302795573146 = 1402307200922 := by decide
theorem cert_e302795573146 : check e302795573146 [[],[]] .smaller = true := by decide
def e302795574382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e302795574382 : Closed e302795574382 ∧ code e302795574382 = 1402307202158 := by decide
theorem cert_e302795574382 : check e302795574382 [[],[]] .smaller = true := by decide
def e302795574394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e302795574394 : Closed e302795574394 ∧ code e302795574394 = 1402307202170 := by decide
theorem cert_e302795574394 : check e302795574394 [[],[]] .smaller = true := by decide
def e302795574558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e302795574558 : Closed e302795574558 ∧ code e302795574558 = 1402307202334 := by decide
theorem cert_e302795574558 : check e302795574558 [[],[]] .smaller = true := by decide
def e302795574718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 4))))))))
theorem wire_e302795574718 : Closed e302795574718 ∧ code e302795574718 = 1402307202494 := by decide
theorem cert_e302795574718 : check e302795574718 [[],[]] .three = true := by decide
def e302795574726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e302795574726 : Closed e302795574726 ∧ code e302795574726 = 1402307202502 := by decide
theorem cert_e302795574726 : check e302795574726 [[],[]] .smaller = true := by decide
def e302795574774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.var 1))))))))
theorem wire_e302795574774 : Closed e302795574774 ∧ code e302795574774 = 1402307202550 := by decide
theorem cert_e302795574774 : check e302795574774 [[],[]] .three = true := by decide
def e302795574974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 4))))))))
theorem wire_e302795574974 : Closed e302795574974 ∧ code e302795574974 = 1402307202750 := by decide
theorem cert_e302795574974 : check e302795574974 [[],[]] .three = true := by decide
def e302795575034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 4))) (.var 0))))))))
theorem wire_e302795575034 : Closed e302795575034 ∧ code e302795575034 = 1402307202810 := by decide
theorem cert_e302795575034 : check e302795575034 [[],[]] .three = true := by decide
def e302795575066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e302795575066 : Closed e302795575066 ∧ code e302795575066 = 1402307202842 := by decide
theorem cert_e302795575066 : check e302795575066 [[],[]] .smaller = true := by decide
def e302795575110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e302795575110 : Closed e302795575110 ∧ code e302795575110 = 1402307202886 := by decide
theorem cert_e302795575110 : check e302795575110 [[],[]] .smaller = true := by decide
def e302795575254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.var 1))))))))
theorem wire_e302795575254 : Closed e302795575254 ∧ code e302795575254 = 1402307203030 := by decide
theorem cert_e302795575254 : check e302795575254 [[],[]] .three = true := by decide
def e302795575258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 1))) (.var 0))))))))
theorem wire_e302795575258 : Closed e302795575258 ∧ code e302795575258 = 1402307203034 := by decide
theorem cert_e302795575258 : check e302795575258 [[],[]] .three = true := by decide
def e302795576094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302795576094 : Closed e302795576094 ∧ code e302795576094 = 1402307203870 := by decide
theorem cert_e302795576094 : check e302795576094 [[],[]] .smaller = true := by decide
def e302795576254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 4)))))))))
theorem wire_e302795576254 : Closed e302795576254 ∧ code e302795576254 = 1402307204030 := by decide
theorem cert_e302795576254 : check e302795576254 [[],[]] .three = true := by decide
def e302795576262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302795576262 : Closed e302795576262 ∧ code e302795576262 = 1402307204038 := by decide
theorem cert_e302795576262 : check e302795576262 [[],[]] .smaller = true := by decide
def e302795576310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 1)))))))))
theorem wire_e302795576310 : Closed e302795576310 ∧ code e302795576310 = 1402307204086 := by decide
theorem cert_e302795576310 : check e302795576310 [[],[]] .three = true := by decide
def e302795577790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 4)))))))))
theorem wire_e302795577790 : Closed e302795577790 ∧ code e302795577790 = 1402307205566 := by decide
theorem cert_e302795577790 : check e302795577790 [[],[]] .three = true := by decide
def e302795577850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 4) (.var 0)))))))))
theorem wire_e302795577850 : Closed e302795577850 ∧ code e302795577850 = 1402307205626 := by decide
theorem cert_e302795577850 : check e302795577850 [[],[]] .three = true := by decide
def e302795578566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302795578566 : Closed e302795578566 ∧ code e302795578566 = 1402307206342 := by decide
theorem cert_e302795578566 : check e302795578566 [[],[]] .smaller = true := by decide
def e302795579190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302795579190 : Closed e302795579190 ∧ code e302795579190 = 1402307206966 := by decide
theorem cert_e302795579190 : check e302795579190 [[],[]] .three = true := by decide
def e302795579194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302795579194 : Closed e302795579194 ∧ code e302795579194 = 1402307206970 := by decide
theorem cert_e302795579194 : check e302795579194 [[],[]] .three = true := by decide
def e302795580214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e302795580214 : Closed e302795580214 ∧ code e302795580214 = 1402307207990 := by decide
theorem cert_e302795580214 : check e302795580214 [[],[]] .smaller = true := by decide
def e302795580218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e302795580218 : Closed e302795580218 ∧ code e302795580218 = 1402307207994 := by decide
theorem cert_e302795580218 : check e302795580218 [[],[]] .smaller = true := by decide
def e302795580314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e302795580314 : Closed e302795580314 ∧ code e302795580314 = 1402307208090 := by decide
theorem cert_e302795580314 : check e302795580314 [[],[]] .smaller = true := by decide
def e302795580982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e302795580982 : Closed e302795580982 ∧ code e302795580982 = 1402307208758 := by decide
theorem cert_e302795580982 : check e302795580982 [[],[]] .smaller = true := by decide
def e302795580986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e302795580986 : Closed e302795580986 ∧ code e302795580986 = 1402307208762 := by decide
theorem cert_e302795580986 : check e302795580986 [[],[]] .smaller = true := by decide
def e302795581070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e302795581070 : Closed e302795581070 ∧ code e302795581070 = 1402307208846 := by decide
theorem cert_e302795581070 : check e302795581070 [[],[]] .smaller = true := by decide
def e302795581118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 4))))))))
theorem wire_e302795581118 : Closed e302795581118 ∧ code e302795581118 = 1402307208894 := by decide
theorem cert_e302795581118 : check e302795581118 [[],[]] .three = true := by decide
def e302795581126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e302795581126 : Closed e302795581126 ∧ code e302795581126 = 1402307208902 := by decide
theorem cert_e302795581126 : check e302795581126 [[],[]] .smaller = true := by decide
def e302795581178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 4))) (.var 0))))))))
theorem wire_e302795581178 : Closed e302795581178 ∧ code e302795581178 = 1402307208954 := by decide
theorem cert_e302795581178 : check e302795581178 [[],[]] .three = true := by decide
def e302795581210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e302795581210 : Closed e302795581210 ∧ code e302795581210 = 1402307208986 := by decide
theorem cert_e302795581210 : check e302795581210 [[],[]] .smaller = true := by decide
def e302795581254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e302795581254 : Closed e302795581254 ∧ code e302795581254 = 1402307209030 := by decide
theorem cert_e302795581254 : check e302795581254 [[],[]] .smaller = true := by decide
def e302795581418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 4) (.var 0))) (.var 0))))))))
theorem wire_e302795581418 : Closed e302795581418 ∧ code e302795581418 = 1402307209194 := by decide
theorem cert_e302795581418 : check e302795581418 [[],[]] .three = true := by decide
def e302795581838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302795581838 : Closed e302795581838 ∧ code e302795581838 = 1402307209614 := by decide
theorem cert_e302795581838 : check e302795581838 [[],[]] .smaller = true := by decide
def e302795581886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 4)))))))))
theorem wire_e302795581886 : Closed e302795581886 ∧ code e302795581886 = 1402307209662 := by decide
theorem cert_e302795581886 : check e302795581886 [[],[]] .three = true := by decide
def e302795581894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302795581894 : Closed e302795581894 ∧ code e302795581894 = 1402307209670 := by decide
theorem cert_e302795581894 : check e302795581894 [[],[]] .smaller = true := by decide
def e302795581946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 4) (.var 0)))))))))
theorem wire_e302795581946 : Closed e302795581946 ∧ code e302795581946 = 1402307209722 := by decide
theorem cert_e302795581946 : check e302795581946 [[],[]] .three = true := by decide
def e302795582662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302795582662 : Closed e302795582662 ∧ code e302795582662 = 1402307210438 := by decide
theorem cert_e302795582662 : check e302795582662 [[],[]] .smaller = true := by decide
def e302795583386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302795583386 : Closed e302795583386 ∧ code e302795583386 = 1402307211162 := by decide
theorem cert_e302795583386 : check e302795583386 [[],[]] .three = true := by decide
def e302795585966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e302795585966 : Closed e302795585966 ∧ code e302795585966 = 1402307213742 := by decide
theorem cert_e302795585966 : check e302795585966 [[],[]] .three = true := by decide
def e302795585974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e302795585974 : Closed e302795585974 ∧ code e302795585974 = 1402307213750 := by decide
theorem cert_e302795585974 : check e302795585974 [[],[]] .three = true := by decide
def e302795585978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e302795585978 : Closed e302795585978 ∧ code e302795585978 = 1402307213754 := by decide
theorem cert_e302795585978 : check e302795585978 [[],[]] .three = true := by decide
def e302795586006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e302795586006 : Closed e302795586006 ∧ code e302795586006 = 1402307213782 := by decide
theorem cert_e302795586006 : check e302795586006 [[],[]] .three = true := by decide
def e302795586010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e302795586010 : Closed e302795586010 ∧ code e302795586010 = 1402307213786 := by decide
theorem cert_e302795586010 : check e302795586010 [[],[]] .three = true := by decide
def e302795586026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e302795586026 : Closed e302795586026 ∧ code e302795586026 = 1402307213802 := by decide
theorem cert_e302795586026 : check e302795586026 [[],[]] .three = true := by decide
def e302795586158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302795586158 : Closed e302795586158 ∧ code e302795586158 = 1402307213934 := by decide
theorem cert_e302795586158 : check e302795586158 [[],[]] .three = true := by decide
def e302795586166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e302795586166 : Closed e302795586166 ∧ code e302795586166 = 1402307213942 := by decide
theorem cert_e302795586166 : check e302795586166 [[],[]] .three = true := by decide
def e302795586170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302795586170 : Closed e302795586170 ∧ code e302795586170 = 1402307213946 := by decide
theorem cert_e302795586170 : check e302795586170 [[],[]] .three = true := by decide
def e302795586358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302795586358 : Closed e302795586358 ∧ code e302795586358 = 1402307214134 := by decide
theorem cert_e302795586358 : check e302795586358 [[],[]] .three = true := by decide
def e302795586362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302795586362 : Closed e302795586362 ∧ code e302795586362 = 1402307214138 := by decide
theorem cert_e302795586362 : check e302795586362 [[],[]] .three = true := by decide
def e302795586458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302795586458 : Closed e302795586458 ∧ code e302795586458 = 1402307214234 := by decide
theorem cert_e302795586458 : check e302795586458 [[],[]] .three = true := by decide
def e302795593438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e302795593438 : Closed e302795593438 ∧ code e302795593438 = 1402307221214 := by decide
theorem cert_e302795593438 : check e302795593438 [[],[]] .smaller = true := by decide
def e302795593462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e302795593462 : Closed e302795593462 ∧ code e302795593462 = 1402307221238 := by decide
theorem cert_e302795593462 : check e302795593462 [[],[]] .smaller = true := by decide
def e302795593566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e302795593566 : Closed e302795593566 ∧ code e302795593566 = 1402307221342 := by decide
theorem cert_e302795593566 : check e302795593566 [[],[]] .smaller = true := by decide
def e302795593594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e302795593594 : Closed e302795593594 ∧ code e302795593594 = 1402307221370 := by decide
theorem cert_e302795593594 : check e302795593594 [[],[]] .smaller = true := by decide
def e302795593686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e302795593686 : Closed e302795593686 ∧ code e302795593686 = 1402307221462 := by decide
theorem cert_e302795593686 : check e302795593686 [[],[]] .smaller = true := by decide
def e302795593690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e302795593690 : Closed e302795593690 ∧ code e302795593690 = 1402307221466 := by decide
theorem cert_e302795593690 : check e302795593690 [[],[]] .smaller = true := by decide
end Blc.Floor40
