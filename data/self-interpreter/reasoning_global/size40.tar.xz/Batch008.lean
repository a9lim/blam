import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e282443623962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443623962 : Closed e282443623962 ∧ code e282443623962 = 1381955251738 := by decide
theorem cert_e282443623962 : check e282443623962 [[]] .width = true := by decide
def e282443627034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443627034 : Closed e282443627034 ∧ code e282443627034 = 1381955254810 := by decide
theorem cert_e282443627034 : check e282443627034 [[]] .width = true := by decide
def e282443634202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443634202 : Closed e282443634202 ∧ code e282443634202 = 1381955261978 := by decide
private def t_e282443634202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282443634202 : ¬ IsSelfInterpreter e282443634202 :=
  wSource (t := t_e282443634202) (replay_sound (ps := []) (t := e282443634202) (by decide)) (by decide)
def e282443635226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443635226 : Closed e282443635226 ∧ code e282443635226 = 1381955263002 := by decide
theorem cert_e282443635226 : check e282443635226 [[]] .width = true := by decide
def e282443673798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e282443673798 : Closed e282443673798 ∧ code e282443673798 = 1381955301574 := by decide
theorem cert_e282443673798 : check e282443673798 [[]] .width = true := by decide
def e282443705882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443705882 : Closed e282443705882 ∧ code e282443705882 = 1381955333658 := by decide
private def t_e282443705882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282443705882 : ¬ IsSelfInterpreter e282443705882 :=
  wSource (t := t_e282443705882) (replay_sound (ps := []) (t := e282443705882) (by decide)) (by decide)
def e282443707930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443707930 : Closed e282443707930 ∧ code e282443707930 = 1381955335706 := by decide
private def t_e282443707930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282443707930 : ¬ IsSelfInterpreter e282443707930 :=
  wSource (t := t_e282443707930) (replay_sound (ps := []) (t := e282443707930) (by decide)) (by decide)
def e282443743258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282443743258 : Closed e282443743258 ∧ code e282443743258 = 1381955371034 := by decide
theorem cert_e282443743258 : check e282443743258 [[]] .width = true := by decide
def e282443743350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e282443743350 : Closed e282443743350 ∧ code e282443743350 = 1381955371126 := by decide
theorem cert_e282443743350 : check e282443743350 [[]] .width = true := by decide
def e282443743594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e282443743594 : Closed e282443743594 ∧ code e282443743594 = 1381955371370 := by decide
theorem cert_e282443743594 : check e282443743594 [[]] .width = true := by decide
def e282443743642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e282443743642 : Closed e282443743642 ∧ code e282443743642 = 1381955371418 := by decide
theorem cert_e282443743642 : check e282443743642 [[]] .width = true := by decide
def e282443744650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e282443744650 : Closed e282443744650 ∧ code e282443744650 = 1381955372426 := by decide
theorem cert_e282443744650 : check e282443744650 [[]] .width = true := by decide
def e282443744674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e282443744674 : Closed e282443744674 ∧ code e282443744674 = 1381955372450 := by decide
private def t_e282443744674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e282443744674 : ¬ IsSelfInterpreter e282443744674 :=
  wSource (t := t_e282443744674) (replay_sound (ps := []) (t := e282443744674) (by decide)) (by decide)
def e282443744782 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e282443744782 : Closed e282443744782 ∧ code e282443744782 = 1381955372558 := by decide
theorem cert_e282443744782 : check e282443744782 [[]] .width = true := by decide
def e282443744794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e282443744794 : Closed e282443744794 ∧ code e282443744794 = 1381955372570 := by decide
private def t_e282443744794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e282443744794 : ¬ IsSelfInterpreter e282443744794 :=
  wSource (t := t_e282443744794) (replay_sound (ps := []) (t := e282443744794) (by decide)) (by decide)
def e282443744866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e282443744866 : Closed e282443744866 ∧ code e282443744866 = 1381955372642 := by decide
theorem cert_e282443744866 : check e282443744866 [[]] .width = true := by decide
def e282443788486 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e282443788486 : Closed e282443788486 ∧ code e282443788486 = 1381955416262 := by decide
theorem cert_e282443788486 : check e282443788486 [[]] .width = true := by decide
def e282443804186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443804186 : Closed e282443804186 ∧ code e282443804186 = 1381955431962 := by decide
theorem cert_e282443804186 : check e282443804186 [[]] .width = true := by decide
def e282443807258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443807258 : Closed e282443807258 ∧ code e282443807258 = 1381955435034 := by decide
theorem cert_e282443807258 : check e282443807258 [[]] .width = true := by decide
def e282443808794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282443808794 : Closed e282443808794 ∧ code e282443808794 = 1381955436570 := by decide
theorem cert_e282443808794 : check e282443808794 [[]] .width = true := by decide
def e282443808886 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e282443808886 : Closed e282443808886 ∧ code e282443808886 = 1381955436662 := by decide
theorem cert_e282443808886 : check e282443808886 [[]] .width = true := by decide
def e282443809130 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e282443809130 : Closed e282443809130 ∧ code e282443809130 = 1381955436906 := by decide
theorem cert_e282443809130 : check e282443809130 [[]] .width = true := by decide
def e282443809178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e282443809178 : Closed e282443809178 ∧ code e282443809178 = 1381955436954 := by decide
theorem cert_e282443809178 : check e282443809178 [[]] .width = true := by decide
def e282443810186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e282443810186 : Closed e282443810186 ∧ code e282443810186 = 1381955437962 := by decide
theorem cert_e282443810186 : check e282443810186 [[]] .width = true := by decide
def e282443810210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e282443810210 : Closed e282443810210 ∧ code e282443810210 = 1381955437986 := by decide
theorem cert_e282443810210 : check e282443810210 [[]] .width = true := by decide
def e282443810318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e282443810318 : Closed e282443810318 ∧ code e282443810318 = 1381955438094 := by decide
theorem cert_e282443810318 : check e282443810318 [[]] .width = true := by decide
def e282443810330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e282443810330 : Closed e282443810330 ∧ code e282443810330 = 1381955438106 := by decide
theorem cert_e282443810330 : check e282443810330 [[]] .width = true := by decide
def e282443810402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e282443810402 : Closed e282443810402 ∧ code e282443810402 = 1381955438178 := by decide
theorem cert_e282443810402 : check e282443810402 [[]] .width = true := by decide
def e282443855386 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443855386 : Closed e282443855386 ∧ code e282443855386 = 1381955483162 := by decide
private def t_e282443855386 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282443855386 : ¬ IsSelfInterpreter e282443855386 :=
  wSource (t := t_e282443855386) (replay_sound (ps := []) (t := e282443855386) (by decide)) (by decide)
def e282443856410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443856410 : Closed e282443856410 ∧ code e282443856410 = 1381955484186 := by decide
private def t_e282443856410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282443856410 : ¬ IsSelfInterpreter e282443856410 :=
  wSource (t := t_e282443856410) (replay_sound (ps := []) (t := e282443856410) (by decide)) (by decide)
def e282447506970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282447506970 : Closed e282447506970 ∧ code e282447506970 = 1381959134746 := by decide
theorem cert_e282447506970 : check e282447506970 [[]] .width = true := by decide
def e282447539738 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282447539738 : Closed e282447539738 ∧ code e282447539738 = 1381959167514 := by decide
theorem cert_e282447539738 : check e282447539738 [[]] .width = true := by decide
def e282447541786 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282447541786 : Closed e282447541786 ∧ code e282447541786 = 1381959169562 := by decide
private def t_e282447541786 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282447541786 : ¬ IsSelfInterpreter e282447541786 :=
  wSource (t := t_e282447541786) (replay_sound (ps := []) (t := e282447541786) (by decide)) (by decide)
def e282448227866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282448227866 : Closed e282448227866 ∧ code e282448227866 = 1381959855642 := by decide
theorem cert_e282448227866 : check e282448227866 [[]] .width = true := by decide
def e282448330778 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282448330778 : Closed e282448330778 ∧ code e282448330778 = 1381959958554 := by decide
theorem cert_e282448330778 : check e282448330778 [[]] .width = true := by decide
def e282448330870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e282448330870 : Closed e282448330870 ∧ code e282448330870 = 1381959958646 := by decide
theorem cert_e282448330870 : check e282448330870 [[]] .width = true := by decide
def e282448331114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e282448331114 : Closed e282448331114 ∧ code e282448331114 = 1381959958890 := by decide
theorem cert_e282448331114 : check e282448331114 [[]] .width = true := by decide
def e282448331162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e282448331162 : Closed e282448331162 ∧ code e282448331162 = 1381959958938 := by decide
theorem cert_e282448331162 : check e282448331162 [[]] .width = true := by decide
def e282448332170 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e282448332170 : Closed e282448332170 ∧ code e282448332170 = 1381959959946 := by decide
theorem cert_e282448332170 : check e282448332170 [[]] .width = true := by decide
def e282448332194 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e282448332194 : Closed e282448332194 ∧ code e282448332194 = 1381959959970 := by decide
theorem cert_e282448332194 : check e282448332194 [[]] .width = true := by decide
def e282448332302 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e282448332302 : Closed e282448332302 ∧ code e282448332302 = 1381959960078 := by decide
theorem cert_e282448332302 : check e282448332302 [[]] .width = true := by decide
def e282448332314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e282448332314 : Closed e282448332314 ∧ code e282448332314 = 1381959960090 := by decide
theorem cert_e282448332314 : check e282448332314 [[]] .width = true := by decide
def e282448332386 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e282448332386 : Closed e282448332386 ∧ code e282448332386 = 1381959960162 := by decide
theorem cert_e282448332386 : check e282448332386 [[]] .width = true := by decide
def e282448392390 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e282448392390 : Closed e282448392390 ∧ code e282448392390 = 1381960020166 := by decide
theorem cert_e282448392390 : check e282448392390 [[]] .width = true := by decide
def e282448424474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282448424474 : Closed e282448424474 ∧ code e282448424474 = 1381960052250 := by decide
theorem cert_e282448424474 : check e282448424474 [[]] .width = true := by decide
def e282448426522 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282448426522 : Closed e282448426522 ∧ code e282448426522 = 1381960054298 := by decide
theorem cert_e282448426522 : check e282448426522 [[]] .width = true := by decide
def e282448461850 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282448461850 : Closed e282448461850 ∧ code e282448461850 = 1381960089626 := by decide
theorem cert_e282448461850 : check e282448461850 [[]] .width = true := by decide
def e282448461942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e282448461942 : Closed e282448461942 ∧ code e282448461942 = 1381960089718 := by decide
theorem cert_e282448461942 : check e282448461942 [[]] .width = true := by decide
def e282448462186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e282448462186 : Closed e282448462186 ∧ code e282448462186 = 1381960089962 := by decide
theorem cert_e282448462186 : check e282448462186 [[]] .width = true := by decide
def e282448462234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e282448462234 : Closed e282448462234 ∧ code e282448462234 = 1381960090010 := by decide
theorem cert_e282448462234 : check e282448462234 [[]] .width = true := by decide
def e282448463242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e282448463242 : Closed e282448463242 ∧ code e282448463242 = 1381960091018 := by decide
theorem cert_e282448463242 : check e282448463242 [[]] .width = true := by decide
def e282448463266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e282448463266 : Closed e282448463266 ∧ code e282448463266 = 1381960091042 := by decide
theorem cert_e282448463266 : check e282448463266 [[]] .width = true := by decide
def e282448463374 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e282448463374 : Closed e282448463374 ∧ code e282448463374 = 1381960091150 := by decide
theorem cert_e282448463374 : check e282448463374 [[]] .width = true := by decide
def e282448463386 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e282448463386 : Closed e282448463386 ∧ code e282448463386 = 1381960091162 := by decide
theorem cert_e282448463386 : check e282448463386 [[]] .width = true := by decide
def e282448463458 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e282448463458 : Closed e282448463458 ∧ code e282448463458 = 1381960091234 := by decide
theorem cert_e282448463458 : check e282448463458 [[]] .width = true := by decide
def e282454322714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282454322714 : Closed e282454322714 ∧ code e282454322714 = 1381965950490 := by decide
theorem cert_e282454322714 : check e282454322714 [[]] .width = true := by decide
def e282454371866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282454371866 : Closed e282454371866 ∧ code e282454371866 = 1381965999642 := by decide
theorem cert_e282454371866 : check e282454371866 [[]] .width = true := by decide
def e282454374938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282454374938 : Closed e282454374938 ∧ code e282454374938 = 1381966002714 := by decide
theorem cert_e282454374938 : check e282454374938 [[]] .width = true := by decide
def e282454519322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282454519322 : Closed e282454519322 ∧ code e282454519322 = 1381966147098 := by decide
theorem cert_e282454519322 : check e282454519322 [[]] .width = true := by decide
def e282454622234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282454622234 : Closed e282454622234 ∧ code e282454622234 = 1381966250010 := by decide
theorem cert_e282454622234 : check e282454622234 [[]] .width = true := by decide
def e282454622326 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e282454622326 : Closed e282454622326 ∧ code e282454622326 = 1381966250102 := by decide
theorem cert_e282454622326 : check e282454622326 [[]] .width = true := by decide
def e282454622570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e282454622570 : Closed e282454622570 ∧ code e282454622570 = 1381966250346 := by decide
theorem cert_e282454622570 : check e282454622570 [[]] .width = true := by decide
def e282454622618 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e282454622618 : Closed e282454622618 ∧ code e282454622618 = 1381966250394 := by decide
theorem cert_e282454622618 : check e282454622618 [[]] .width = true := by decide
def e282454623626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e282454623626 : Closed e282454623626 ∧ code e282454623626 = 1381966251402 := by decide
theorem cert_e282454623626 : check e282454623626 [[]] .width = true := by decide
def e282454623650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e282454623650 : Closed e282454623650 ∧ code e282454623650 = 1381966251426 := by decide
theorem cert_e282454623650 : check e282454623650 [[]] .width = true := by decide
def e282454623758 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e282454623758 : Closed e282454623758 ∧ code e282454623758 = 1381966251534 := by decide
theorem cert_e282454623758 : check e282454623758 [[]] .width = true := by decide
def e282454623770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e282454623770 : Closed e282454623770 ∧ code e282454623770 = 1381966251546 := by decide
theorem cert_e282454623770 : check e282454623770 [[]] .width = true := by decide
def e282454623842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e282454623842 : Closed e282454623842 ∧ code e282454623842 = 1381966251618 := by decide
theorem cert_e282454623842 : check e282454623842 [[]] .width = true := by decide
def e282454798534 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e282454798534 : Closed e282454798534 ∧ code e282454798534 = 1381966426310 := by decide
theorem cert_e282454798534 : check e282454798534 [[]] .width = true := by decide
def e282454814234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282454814234 : Closed e282454814234 ∧ code e282454814234 = 1381966442010 := by decide
theorem cert_e282454814234 : check e282454814234 [[]] .width = true := by decide
def e282454817306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282454817306 : Closed e282454817306 ∧ code e282454817306 = 1381966445082 := by decide
theorem cert_e282454817306 : check e282454817306 [[]] .width = true := by decide
def e282454818842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282454818842 : Closed e282454818842 ∧ code e282454818842 = 1381966446618 := by decide
theorem cert_e282454818842 : check e282454818842 [[]] .width = true := by decide
def e282454818934 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e282454818934 : Closed e282454818934 ∧ code e282454818934 = 1381966446710 := by decide
theorem cert_e282454818934 : check e282454818934 [[]] .width = true := by decide
def e282454819178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e282454819178 : Closed e282454819178 ∧ code e282454819178 = 1381966446954 := by decide
theorem cert_e282454819178 : check e282454819178 [[]] .width = true := by decide
def e282454819226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e282454819226 : Closed e282454819226 ∧ code e282454819226 = 1381966447002 := by decide
theorem cert_e282454819226 : check e282454819226 [[]] .width = true := by decide
def e282454820234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e282454820234 : Closed e282454820234 ∧ code e282454820234 = 1381966448010 := by decide
theorem cert_e282454820234 : check e282454820234 [[]] .width = true := by decide
def e282454820258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e282454820258 : Closed e282454820258 ∧ code e282454820258 = 1381966448034 := by decide
theorem cert_e282454820258 : check e282454820258 [[]] .width = true := by decide
def e282454820366 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e282454820366 : Closed e282454820366 ∧ code e282454820366 = 1381966448142 := by decide
theorem cert_e282454820366 : check e282454820366 [[]] .width = true := by decide
def e282454820378 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e282454820378 : Closed e282454820378 ∧ code e282454820378 = 1381966448154 := by decide
theorem cert_e282454820378 : check e282454820378 [[]] .width = true := by decide
def e282454820450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e282454820450 : Closed e282454820450 ∧ code e282454820450 = 1381966448226 := by decide
theorem cert_e282454820450 : check e282454820450 [[]] .width = true := by decide
def e282457763354 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282457763354 : Closed e282457763354 ∧ code e282457763354 = 1381969391130 := by decide
theorem cert_e282457763354 : check e282457763354 [[]] .width = true := by decide
def e282457765402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282457765402 : Closed e282457765402 ∧ code e282457765402 = 1381969393178 := by decide
private def t_e282457765402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282457765402 : ¬ IsSelfInterpreter e282457765402 :=
  wSource (t := t_e282457765402) (replay_sound (ps := []) (t := e282457765402) (by decide)) (by decide)
def e282457779738 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282457779738 : Closed e282457779738 ∧ code e282457779738 = 1381969407514 := by decide
theorem cert_e282457779738 : check e282457779738 [[]] .width = true := by decide
def e282457782810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282457782810 : Closed e282457782810 ∧ code e282457782810 = 1381969410586 := by decide
theorem cert_e282457782810 : check e282457782810 [[]] .width = true := by decide
def e282457789978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282457789978 : Closed e282457789978 ∧ code e282457789978 = 1381969417754 := by decide
private def t_e282457789978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282457789978 : ¬ IsSelfInterpreter e282457789978 :=
  wSource (t := t_e282457789978) (replay_sound (ps := []) (t := e282457789978) (by decide)) (by decide)
def e282457791002 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282457791002 : Closed e282457791002 ∧ code e282457791002 = 1381969418778 := by decide
theorem cert_e282457791002 : check e282457791002 [[]] .width = true := by decide
def e282457829574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e282457829574 : Closed e282457829574 ∧ code e282457829574 = 1381969457350 := by decide
theorem cert_e282457829574 : check e282457829574 [[]] .width = true := by decide
def e282457861658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282457861658 : Closed e282457861658 ∧ code e282457861658 = 1381969489434 := by decide
theorem cert_e282457861658 : check e282457861658 [[]] .width = true := by decide
def e282457863706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282457863706 : Closed e282457863706 ∧ code e282457863706 = 1381969491482 := by decide
theorem cert_e282457863706 : check e282457863706 [[]] .width = true := by decide
def e282457899034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282457899034 : Closed e282457899034 ∧ code e282457899034 = 1381969526810 := by decide
theorem cert_e282457899034 : check e282457899034 [[]] .width = true := by decide
def e282457899126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e282457899126 : Closed e282457899126 ∧ code e282457899126 = 1381969526902 := by decide
theorem cert_e282457899126 : check e282457899126 [[]] .width = true := by decide
def e282457899370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e282457899370 : Closed e282457899370 ∧ code e282457899370 = 1381969527146 := by decide
theorem cert_e282457899370 : check e282457899370 [[]] .width = true := by decide
def e282457899418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e282457899418 : Closed e282457899418 ∧ code e282457899418 = 1381969527194 := by decide
theorem cert_e282457899418 : check e282457899418 [[]] .width = true := by decide
def e282457900426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e282457900426 : Closed e282457900426 ∧ code e282457900426 = 1381969528202 := by decide
theorem cert_e282457900426 : check e282457900426 [[]] .width = true := by decide
def e282457900450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e282457900450 : Closed e282457900450 ∧ code e282457900450 = 1381969528226 := by decide
theorem cert_e282457900450 : check e282457900450 [[]] .width = true := by decide
def e282457900558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e282457900558 : Closed e282457900558 ∧ code e282457900558 = 1381969528334 := by decide
theorem cert_e282457900558 : check e282457900558 [[]] .width = true := by decide
def e282457900570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e282457900570 : Closed e282457900570 ∧ code e282457900570 = 1381969528346 := by decide
theorem cert_e282457900570 : check e282457900570 [[]] .width = true := by decide
def e282457900642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e282457900642 : Closed e282457900642 ∧ code e282457900642 = 1381969528418 := by decide
theorem cert_e282457900642 : check e282457900642 [[]] .width = true := by decide
def e282457944262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e282457944262 : Closed e282457944262 ∧ code e282457944262 = 1381969572038 := by decide
theorem cert_e282457944262 : check e282457944262 [[]] .width = true := by decide
def e282457959962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282457959962 : Closed e282457959962 ∧ code e282457959962 = 1381969587738 := by decide
theorem cert_e282457959962 : check e282457959962 [[]] .width = true := by decide
def e282457963034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282457963034 : Closed e282457963034 ∧ code e282457963034 = 1381969590810 := by decide
theorem cert_e282457963034 : check e282457963034 [[]] .width = true := by decide
def e282457964570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282457964570 : Closed e282457964570 ∧ code e282457964570 = 1381969592346 := by decide
theorem cert_e282457964570 : check e282457964570 [[]] .width = true := by decide
def e282457964662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e282457964662 : Closed e282457964662 ∧ code e282457964662 = 1381969592438 := by decide
theorem cert_e282457964662 : check e282457964662 [[]] .width = true := by decide
def e282457964906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e282457964906 : Closed e282457964906 ∧ code e282457964906 = 1381969592682 := by decide
theorem cert_e282457964906 : check e282457964906 [[]] .width = true := by decide
def e282457964954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e282457964954 : Closed e282457964954 ∧ code e282457964954 = 1381969592730 := by decide
theorem cert_e282457964954 : check e282457964954 [[]] .width = true := by decide
def e282457965962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e282457965962 : Closed e282457965962 ∧ code e282457965962 = 1381969593738 := by decide
theorem cert_e282457965962 : check e282457965962 [[]] .width = true := by decide
def e282457965986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e282457965986 : Closed e282457965986 ∧ code e282457965986 = 1381969593762 := by decide
theorem cert_e282457965986 : check e282457965986 [[]] .width = true := by decide
def e282457966094 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e282457966094 : Closed e282457966094 ∧ code e282457966094 = 1381969593870 := by decide
theorem cert_e282457966094 : check e282457966094 [[]] .width = true := by decide
def e282457966106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e282457966106 : Closed e282457966106 ∧ code e282457966106 = 1381969593882 := by decide
theorem cert_e282457966106 : check e282457966106 [[]] .width = true := by decide
def e282457966178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e282457966178 : Closed e282457966178 ∧ code e282457966178 = 1381969593954 := by decide
theorem cert_e282457966178 : check e282457966178 [[]] .width = true := by decide
def e282458011162 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282458011162 : Closed e282458011162 ∧ code e282458011162 = 1381969638938 := by decide
theorem cert_e282458011162 : check e282458011162 [[]] .width = true := by decide
def e282458012186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282458012186 : Closed e282458012186 ∧ code e282458012186 = 1381969639962 := by decide
theorem cert_e282458012186 : check e282458012186 [[]] .width = true := by decide
def e282511584622 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e282511584622 : Closed e282511584622 ∧ code e282511584622 = 1382023212398 := by decide
theorem cert_e282511584622 : check e282511584622 [[],[.under]] .three = true := by decide
def e282511584630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e282511584630 : Closed e282511584630 ∧ code e282511584630 = 1382023212406 := by decide
theorem cert_e282511584630 : check e282511584630 [[],[.under]] .three = true := by decide
def e282511584686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e282511584686 : Closed e282511584686 ∧ code e282511584686 = 1382023212462 := by decide
theorem cert_e282511584686 : check e282511584686 [[],[.under]] .three = true := by decide
def e282511584698 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e282511584698 : Closed e282511584698 ∧ code e282511584698 = 1382023212474 := by decide
theorem cert_e282511584698 : check e282511584698 [[],[.under]] .three = true := by decide
def e282511584726 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e282511584726 : Closed e282511584726 ∧ code e282511584726 = 1382023212502 := by decide
theorem cert_e282511584726 : check e282511584726 [[],[.under]] .three = true := by decide
def e282511584730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e282511584730 : Closed e282511584730 ∧ code e282511584730 = 1382023212506 := by decide
theorem cert_e282511584730 : check e282511584730 [[],[.under]] .three = true := by decide
def e282511584942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e282511584942 : Closed e282511584942 ∧ code e282511584942 = 1382023212718 := by decide
theorem cert_e282511584942 : check e282511584942 [[],[.under]] .three = true := by decide
def e282511584954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e282511584954 : Closed e282511584954 ∧ code e282511584954 = 1382023212730 := by decide
theorem cert_e282511584954 : check e282511584954 [[],[.under]] .three = true := by decide
def e282511585002 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e282511585002 : Closed e282511585002 ∧ code e282511585002 = 1382023212778 := by decide
theorem cert_e282511585002 : check e282511585002 [[],[.under]] .three = true := by decide
def e282511585110 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e282511585110 : Closed e282511585110 ∧ code e282511585110 = 1382023212886 := by decide
theorem cert_e282511585110 : check e282511585110 [[],[.under]] .three = true := by decide
def e282511585114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e282511585114 : Closed e282511585114 ∧ code e282511585114 = 1382023212890 := by decide
theorem cert_e282511585114 : check e282511585114 [[],[.under]] .three = true := by decide
def e282511585130 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e282511585130 : Closed e282511585130 ∧ code e282511585130 = 1382023212906 := by decide
theorem cert_e282511585130 : check e282511585130 [[],[.under]] .three = true := by decide
def e282511586158 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e282511586158 : Closed e282511586158 ∧ code e282511586158 = 1382023213934 := by decide
theorem cert_e282511586158 : check e282511586158 [[],[.under]] .three = true := by decide
def e282511586166 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e282511586166 : Closed e282511586166 ∧ code e282511586166 = 1382023213942 := by decide
theorem cert_e282511586166 : check e282511586166 [[],[.under]] .three = true := by decide
def e282511586222 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e282511586222 : Closed e282511586222 ∧ code e282511586222 = 1382023213998 := by decide
theorem cert_e282511586222 : check e282511586222 [[],[.under]] .three = true := by decide
def e282511586234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e282511586234 : Closed e282511586234 ∧ code e282511586234 = 1382023214010 := by decide
theorem cert_e282511586234 : check e282511586234 [[],[.under]] .three = true := by decide
def e282511586262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e282511586262 : Closed e282511586262 ∧ code e282511586262 = 1382023214038 := by decide
theorem cert_e282511586262 : check e282511586262 [[],[.under]] .three = true := by decide
def e282511586266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e282511586266 : Closed e282511586266 ∧ code e282511586266 = 1382023214042 := by decide
theorem cert_e282511586266 : check e282511586266 [[],[.under]] .three = true := by decide
def e282511586542 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e282511586542 : Closed e282511586542 ∧ code e282511586542 = 1382023214318 := by decide
theorem cert_e282511586542 : check e282511586542 [[],[.under]] .three = true := by decide
def e282511586550 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e282511586550 : Closed e282511586550 ∧ code e282511586550 = 1382023214326 := by decide
theorem cert_e282511586550 : check e282511586550 [[],[.under]] .three = true := by decide
def e282511586926 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e282511586926 : Closed e282511586926 ∧ code e282511586926 = 1382023214702 := by decide
theorem cert_e282511586926 : check e282511586926 [[],[.under]] .three = true := by decide
def e282511586938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e282511586938 : Closed e282511586938 ∧ code e282511586938 = 1382023214714 := by decide
theorem cert_e282511586938 : check e282511586938 [[],[.under]] .three = true := by decide
def e282511587126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e282511587126 : Closed e282511587126 ∧ code e282511587126 = 1382023214902 := by decide
theorem cert_e282511587126 : check e282511587126 [[],[.under]] .three = true := by decide
def e282511587130 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e282511587130 : Closed e282511587130 ∧ code e282511587130 = 1382023214906 := by decide
theorem cert_e282511587130 : check e282511587130 [[],[.under]] .three = true := by decide
def e282511587758 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e282511587758 : Closed e282511587758 ∧ code e282511587758 = 1382023215534 := by decide
theorem cert_e282511587758 : check e282511587758 [[],[.under]] .three = true := by decide
def e282511587770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e282511587770 : Closed e282511587770 ∧ code e282511587770 = 1382023215546 := by decide
theorem cert_e282511587770 : check e282511587770 [[],[.under]] .three = true := by decide
def e282511587818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e282511587818 : Closed e282511587818 ∧ code e282511587818 = 1382023215594 := by decide
theorem cert_e282511587818 : check e282511587818 [[],[.under]] .three = true := by decide
def e282511587950 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e282511587950 : Closed e282511587950 ∧ code e282511587950 = 1382023215726 := by decide
theorem cert_e282511587950 : check e282511587950 [[],[.under]] .three = true := by decide
def e282511587962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e282511587962 : Closed e282511587962 ∧ code e282511587962 = 1382023215738 := by decide
theorem cert_e282511587962 : check e282511587962 [[],[.under]] .three = true := by decide
def e282511588250 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e282511588250 : Closed e282511588250 ∧ code e282511588250 = 1382023216026 := by decide
theorem cert_e282511588250 : check e282511588250 [[],[.under]] .three = true := by decide
def e282511588566 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e282511588566 : Closed e282511588566 ∧ code e282511588566 = 1382023216342 := by decide
theorem cert_e282511588566 : check e282511588566 [[],[.under]] .three = true := by decide
def e282511588570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e282511588570 : Closed e282511588570 ∧ code e282511588570 = 1382023216346 := by decide
theorem cert_e282511588570 : check e282511588570 [[],[.under]] .three = true := by decide
def e282511588586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e282511588586 : Closed e282511588586 ∧ code e282511588586 = 1382023216362 := by decide
theorem cert_e282511588586 : check e282511588586 [[],[.under]] .three = true := by decide
def e282511588662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e282511588662 : Closed e282511588662 ∧ code e282511588662 = 1382023216438 := by decide
theorem cert_e282511588662 : check e282511588662 [[],[.under]] .three = true := by decide
def e282511588666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e282511588666 : Closed e282511588666 ∧ code e282511588666 = 1382023216442 := by decide
theorem cert_e282511588666 : check e282511588666 [[],[.under]] .three = true := by decide
def e282511588762 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e282511588762 : Closed e282511588762 ∧ code e282511588762 = 1382023216538 := by decide
theorem cert_e282511588762 : check e282511588762 [[],[.under]] .three = true := by decide
def e282511592302 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e282511592302 : Closed e282511592302 ∧ code e282511592302 = 1382023220078 := by decide
theorem cert_e282511592302 : check e282511592302 [[],[.under]] .three = true := by decide
def e282511592310 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e282511592310 : Closed e282511592310 ∧ code e282511592310 = 1382023220086 := by decide
theorem cert_e282511592310 : check e282511592310 [[],[.under]] .three = true := by decide
def e282511592366 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e282511592366 : Closed e282511592366 ∧ code e282511592366 = 1382023220142 := by decide
theorem cert_e282511592366 : check e282511592366 [[],[.under]] .three = true := by decide
def e282511592378 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e282511592378 : Closed e282511592378 ∧ code e282511592378 = 1382023220154 := by decide
theorem cert_e282511592378 : check e282511592378 [[],[.under]] .three = true := by decide
def e282511592406 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e282511592406 : Closed e282511592406 ∧ code e282511592406 = 1382023220182 := by decide
theorem cert_e282511592406 : check e282511592406 [[],[.under]] .three = true := by decide
def e282511592410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e282511592410 : Closed e282511592410 ∧ code e282511592410 = 1382023220186 := by decide
theorem cert_e282511592410 : check e282511592410 [[],[.under]] .three = true := by decide
def e282511592686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e282511592686 : Closed e282511592686 ∧ code e282511592686 = 1382023220462 := by decide
theorem cert_e282511592686 : check e282511592686 [[],[.under]] .three = true := by decide
def e282511592694 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e282511592694 : Closed e282511592694 ∧ code e282511592694 = 1382023220470 := by decide
theorem cert_e282511592694 : check e282511592694 [[],[.under]] .three = true := by decide
def e282511593070 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e282511593070 : Closed e282511593070 ∧ code e282511593070 = 1382023220846 := by decide
theorem cert_e282511593070 : check e282511593070 [[],[.under]] .three = true := by decide
def e282511593082 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e282511593082 : Closed e282511593082 ∧ code e282511593082 = 1382023220858 := by decide
theorem cert_e282511593082 : check e282511593082 [[],[.under]] .three = true := by decide
def e282511593270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e282511593270 : Closed e282511593270 ∧ code e282511593270 = 1382023221046 := by decide
theorem cert_e282511593270 : check e282511593270 [[],[.under]] .three = true := by decide
def e282511593274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e282511593274 : Closed e282511593274 ∧ code e282511593274 = 1382023221050 := by decide
theorem cert_e282511593274 : check e282511593274 [[],[.under]] .three = true := by decide
end Blc.Floor40
