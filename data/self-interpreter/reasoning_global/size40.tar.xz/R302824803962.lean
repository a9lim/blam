import CodeBridge
import Batch060
namespace Certgen.R302824803962
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 62,.app 2 53,.app 3 24,.app 4 21,.app 5 9,.lam 6,.app 7 8,.var 0,.var 0,.lam 10,.lam 11,.app 12 13,.var 1,.lam 14,.app 15 16,.var 2,.app 17 18,.var 1,.app 19 20,.var 2,.var 0,.lam 22,.lam 23,.var 0,.lam 25,.app 26 31,.app 27 28,.var 0,.lam 29,.lam 30,.var 1,.lam 32,.app 33 38,.app 34 35,.var 0,.lam 36,.lam 37,.var 1,.lam 39,.app 40 45,.app 41 42,.var 0,.lam 43,.lam 44,.var 0,.lam 46,.app 47 52,.app 48 49,.var 0,.lam 50,.lam 51,.var 1,.opaque,.app 54 58,.lam 55,.app 56 57,.var 0,.var 0,.lam 59,.app 60 61,.var 0,.var 0,.app 63 67,.lam 64,.app 65 66,.var 0,.var 0,.lam 68,.app 69 70,.var 0,.var 0]
def values : Array (List AClo) := #[[⟨53,[]⟩],[⟨24,[]⟩],[⟨21,[]⟩],[⟨62,[]⟩],[⟨13,[1,12]⟩],[⟨18,[4,2,14]⟩],[⟨13,[0,13]⟩],[⟨16,[3,0,13]⟩],[⟨9,[]⟩],[⟨58,[]⟩],[⟨57,[9]⟩],[⟨61,[10]⟩,⟨61,[11]⟩],[⟨13,[2,14]⟩],[⟨16,[4,2,14]⟩],[⟨8,[8]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨62,[]⟩,0⟩],[⟨⟨53,[]⟩,1⟩],[⟨⟨13,[0,13]⟩,1⟩],[⟨⟨13,[1,12]⟩,2⟩],[⟨⟨13,[2,14]⟩,11⟩],[⟨⟨16,[3,0,13]⟩,0⟩],[⟨⟨16,[4,2,14]⟩,2⟩],[⟨⟨18,[3,0,13]⟩,0⟩],[⟨⟨18,[4,2,14]⟩,3⟩],[⟨⟨18,[4,2,14]⟩,6⟩],[⟨⟨24,[]⟩,2⟩],[⟨⟨21,[]⟩,11⟩],[⟨⟨9,[]⟩,12⟩],[⟨⟨58,[]⟩,8⟩],[⟨⟨57,[9]⟩,8⟩],[⟨⟨61,[10]⟩,8⟩],[⟨⟨61,[11]⟩,8⟩],[⟨⟨8,[8]⟩,12⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[]⟩,2⟩,⟨⟨3,[]⟩,11⟩,⟨⟨4,[]⟩,12⟩,⟨⟨5,[]⟩,13⟩,⟨⟨6,[8]⟩,12⟩,⟨⟨7,[8]⟩,18⟩,⟨⟨8,[8]⟩,5⟩,⟨⟨8,[8]⟩,7⟩,⟨⟨9,[]⟩,5⟩,⟨⟨9,[]⟩,7⟩,⟨⟨9,[]⟩,18⟩,⟨⟨10,[12]⟩,11⟩,⟨⟨10,[13]⟩,2⟩,⟨⟨10,[14]⟩,12⟩,⟨⟨11,[0,13]⟩,1⟩,⟨⟨11,[1,12]⟩,2⟩,⟨⟨11,[2,14]⟩,11⟩,⟨⟨12,[0,13]⟩,3⟩,⟨⟨12,[1,12]⟩,4⟩,⟨⟨12,[2,14]⟩,5⟩,⟨⟨13,[0,13]⟩,1⟩,⟨⟨13,[2,14]⟩,4⟩,⟨⟨14,[3,0,13]⟩,0⟩,⟨⟨14,[4,2,14]⟩,2⟩,⟨⟨15,[3,0,13]⟩,6⟩,⟨⟨15,[4,2,14]⟩,7⟩,⟨⟨16,[3,0,13]⟩,0⟩,⟨⟨16,[4,2,14]⟩,3⟩,⟨⟨16,[4,2,14]⟩,6⟩,⟨⟨17,[3,0,13]⟩,8⟩,⟨⟨17,[4,2,14]⟩,9⟩,⟨⟨17,[4,2,14]⟩,10⟩,⟨⟨21,[]⟩,9⟩,⟨⟨21,[]⟩,10⟩,⟨⟨22,[5]⟩,3⟩,⟨⟨22,[5]⟩,6⟩,⟨⟨23,[6,5]⟩,1⟩,⟨⟨23,[7,5]⟩,0⟩,⟨⟨53,[]⟩,8⟩,⟨⟨54,[]⟩,14⟩,⟨⟨55,[9]⟩,8⟩,⟨⟨56,[9]⟩,15⟩,⟨⟨57,[9]⟩,16⟩,⟨⟨57,[9]⟩,17⟩,⟨⟨58,[]⟩,15⟩,⟨⟨58,[]⟩,16⟩,⟨⟨58,[]⟩,17⟩,⟨⟨59,[10]⟩,8⟩,⟨⟨59,[11]⟩,8⟩,⟨⟨60,[10]⟩,16⟩,⟨⟨60,[11]⟩,17⟩,⟨⟨61,[10]⟩,17⟩,⟨⟨61,[11]⟩,17⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[4],[5],[6],[7],[12],[10],[11],[13],[14],[15],[17],[16],[18],[19],[20],[21],[29],[23],[8],[24],[25],[26],[27],[30],[9],[31],[32],[33],[40],[34],[35],[36],[37],[38],[39],[22],[28],[41],[42],[43],[46],[47],[48],[49],[50],[50],[51],[52],[44],[53,54],[45],[53,54]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem block24 : checkRange P V K states hints 24 12=true := by decide
theorem block36 : checkRange P V K states hints 36 12=true := by decide
theorem block48 : checkRange P V K states hints 48 7=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<55 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 by_cases h12 : i<24
 · exact range_sound block12 i (by omega) h12 hi
 by_cases h24 : i<36
 · exact range_sound block24 i (by omega) h24 hi
 by_cases h36 : i<48
 · exact range_sound block36 i (by omega) h36 hi
 exact range_sound block48 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit70 : Term := .var 0
def lit51 : Term := .var 1
def lit19 : Term := .var 2
def lit43 : Term := .lam lit70
def lit50 : Term := .lam lit51
def lit68 : Term := .app lit70 lit70
def lit42 : Term := .lam lit43
def lit52 : Term := .var 4
def lit49 : Term := .lam lit50
def lit67 : Term := .lam lit68
def lit18 : Term := .app lit19 lit70
def lit40 : Term := .app lit70 lit42
def lit47 : Term := .app lit70 lit49
def lit16 : Term := .app lit51 lit18
def lit62 : Term := .app lit67 lit67
def lit14 : Term := .app lit19 lit16
def lit46 : Term := .app lit47 lit52
def lit13 : Term := .lam lit14
def lit45 : Term := .lam lit46
def lit11 : Term := .app lit51 lit13
def lit10 : Term := .lam lit11
def lit9 : Term := .lam lit10
def lit39 : Term := .app lit40 lit45
def lit38 : Term := .lam lit39
def lit4 : Term := .app lit67 lit9
def lit3 : Term := .app lit4 lit42
def lit32 : Term := .app lit47 lit38
def lit31 : Term := .lam lit32
def lit25 : Term := .app lit47 lit31
def lit24 : Term := .lam lit25
def lit2 : Term := .app lit3 lit24
def lit1 : Term := .app lit2 lit62
def lit0 : Term := .app lit1 lit62
def filling : Nat → Term := fun p => if p = 52 then Term.var 4 else Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub70 : model.term 70 = lit70 := model.var_eq 70 0 (by rfl)
theorem sub69 : model.term 69 = lit70 := model.var_eq 69 0 (by rfl)
theorem sub68 : model.term 68 = lit68 := by rw [model.app_eq 68 69 70 (by rfl), sub69, sub70]; rfl
theorem sub67 : model.term 67 = lit67 := by rw [model.lam_eq 67 68 (by rfl), sub68]; rfl
theorem sub66 : model.term 66 = lit70 := model.var_eq 66 0 (by rfl)
theorem sub65 : model.term 65 = lit70 := model.var_eq 65 0 (by rfl)
theorem sub64 : model.term 64 = lit68 := by rw [model.app_eq 64 65 66 (by rfl), sub65, sub66]; rfl
theorem sub63 : model.term 63 = lit67 := by rw [model.lam_eq 63 64 (by rfl), sub64]; rfl
theorem sub62 : model.term 62 = lit62 := by rw [model.app_eq 62 63 67 (by rfl), sub63, sub67]; rfl
theorem sub61 : model.term 61 = lit70 := model.var_eq 61 0 (by rfl)
theorem sub60 : model.term 60 = lit70 := model.var_eq 60 0 (by rfl)
theorem sub59 : model.term 59 = lit68 := by rw [model.app_eq 59 60 61 (by rfl), sub60, sub61]; rfl
theorem sub58 : model.term 58 = lit67 := by rw [model.lam_eq 58 59 (by rfl), sub59]; rfl
theorem sub57 : model.term 57 = lit70 := model.var_eq 57 0 (by rfl)
theorem sub56 : model.term 56 = lit70 := model.var_eq 56 0 (by rfl)
theorem sub55 : model.term 55 = lit68 := by rw [model.app_eq 55 56 57 (by rfl), sub56, sub57]; rfl
theorem sub54 : model.term 54 = lit67 := by rw [model.lam_eq 54 55 (by rfl), sub55]; rfl
theorem sub53 : model.term 53 = lit62 := by rw [model.app_eq 53 54 58 (by rfl), sub54, sub58]; rfl
theorem sub52 : model.term 52 = lit52 := (opaqueTerm (rankedCode code ordered_code) filling (p := 52) (by rfl)).trans (by rfl)
theorem sub51 : model.term 51 = lit51 := model.var_eq 51 1 (by rfl)
theorem sub50 : model.term 50 = lit50 := by rw [model.lam_eq 50 51 (by rfl), sub51]; rfl
theorem sub49 : model.term 49 = lit49 := by rw [model.lam_eq 49 50 (by rfl), sub50]; rfl
theorem sub48 : model.term 48 = lit70 := model.var_eq 48 0 (by rfl)
theorem sub47 : model.term 47 = lit47 := by rw [model.app_eq 47 48 49 (by rfl), sub48, sub49]; rfl
theorem sub46 : model.term 46 = lit46 := by rw [model.app_eq 46 47 52 (by rfl), sub47, sub52]; rfl
theorem sub45 : model.term 45 = lit45 := by rw [model.lam_eq 45 46 (by rfl), sub46]; rfl
theorem sub44 : model.term 44 = lit70 := model.var_eq 44 0 (by rfl)
theorem sub43 : model.term 43 = lit43 := by rw [model.lam_eq 43 44 (by rfl), sub44]; rfl
theorem sub42 : model.term 42 = lit42 := by rw [model.lam_eq 42 43 (by rfl), sub43]; rfl
theorem sub41 : model.term 41 = lit70 := model.var_eq 41 0 (by rfl)
theorem sub40 : model.term 40 = lit40 := by rw [model.app_eq 40 41 42 (by rfl), sub41, sub42]; rfl
theorem sub39 : model.term 39 = lit39 := by rw [model.app_eq 39 40 45 (by rfl), sub40, sub45]; rfl
theorem sub38 : model.term 38 = lit38 := by rw [model.lam_eq 38 39 (by rfl), sub39]; rfl
theorem sub37 : model.term 37 = lit51 := model.var_eq 37 1 (by rfl)
theorem sub36 : model.term 36 = lit50 := by rw [model.lam_eq 36 37 (by rfl), sub37]; rfl
theorem sub35 : model.term 35 = lit49 := by rw [model.lam_eq 35 36 (by rfl), sub36]; rfl
theorem sub34 : model.term 34 = lit70 := model.var_eq 34 0 (by rfl)
theorem sub33 : model.term 33 = lit47 := by rw [model.app_eq 33 34 35 (by rfl), sub34, sub35]; rfl
theorem sub32 : model.term 32 = lit32 := by rw [model.app_eq 32 33 38 (by rfl), sub33, sub38]; rfl
theorem sub31 : model.term 31 = lit31 := by rw [model.lam_eq 31 32 (by rfl), sub32]; rfl
theorem sub30 : model.term 30 = lit51 := model.var_eq 30 1 (by rfl)
theorem sub29 : model.term 29 = lit50 := by rw [model.lam_eq 29 30 (by rfl), sub30]; rfl
theorem sub28 : model.term 28 = lit49 := by rw [model.lam_eq 28 29 (by rfl), sub29]; rfl
theorem sub27 : model.term 27 = lit70 := model.var_eq 27 0 (by rfl)
theorem sub26 : model.term 26 = lit47 := by rw [model.app_eq 26 27 28 (by rfl), sub27, sub28]; rfl
theorem sub25 : model.term 25 = lit25 := by rw [model.app_eq 25 26 31 (by rfl), sub26, sub31]; rfl
theorem sub24 : model.term 24 = lit24 := by rw [model.lam_eq 24 25 (by rfl), sub25]; rfl
theorem sub23 : model.term 23 = lit70 := model.var_eq 23 0 (by rfl)
theorem sub22 : model.term 22 = lit43 := by rw [model.lam_eq 22 23 (by rfl), sub23]; rfl
theorem sub21 : model.term 21 = lit42 := by rw [model.lam_eq 21 22 (by rfl), sub22]; rfl
theorem sub20 : model.term 20 = lit70 := model.var_eq 20 0 (by rfl)
theorem sub19 : model.term 19 = lit19 := model.var_eq 19 2 (by rfl)
theorem sub18 : model.term 18 = lit18 := by rw [model.app_eq 18 19 20 (by rfl), sub19, sub20]; rfl
theorem sub17 : model.term 17 = lit51 := model.var_eq 17 1 (by rfl)
theorem sub16 : model.term 16 = lit16 := by rw [model.app_eq 16 17 18 (by rfl), sub17, sub18]; rfl
theorem sub15 : model.term 15 = lit19 := model.var_eq 15 2 (by rfl)
theorem sub14 : model.term 14 = lit14 := by rw [model.app_eq 14 15 16 (by rfl), sub15, sub16]; rfl
theorem sub13 : model.term 13 = lit13 := by rw [model.lam_eq 13 14 (by rfl), sub14]; rfl
theorem sub12 : model.term 12 = lit51 := model.var_eq 12 1 (by rfl)
theorem sub11 : model.term 11 = lit11 := by rw [model.app_eq 11 12 13 (by rfl), sub12, sub13]; rfl
theorem sub10 : model.term 10 = lit10 := by rw [model.lam_eq 10 11 (by rfl), sub11]; rfl
theorem sub9 : model.term 9 = lit9 := by rw [model.lam_eq 9 10 (by rfl), sub10]; rfl
theorem sub8 : model.term 8 = lit70 := model.var_eq 8 0 (by rfl)
theorem sub7 : model.term 7 = lit70 := model.var_eq 7 0 (by rfl)
theorem sub6 : model.term 6 = lit68 := by rw [model.app_eq 6 7 8 (by rfl), sub7, sub8]; rfl
theorem sub5 : model.term 5 = lit67 := by rw [model.lam_eq 5 6 (by rfl), sub6]; rfl
theorem sub4 : model.term 4 = lit4 := by rw [model.app_eq 4 5 9 (by rfl), sub5, sub9]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 21 (by rfl), sub4, sub21]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 24 (by rfl), sub3, sub24]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 53 (by rfl), sub2, sub53]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 62 (by rfl), sub1, sub62]; rfl
theorem excluded : ¬ IsSelfInterpreter e302824803962 := by
 intro he
 have hp : replay [] (call e302824803962 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R302824803962
