import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302796856246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e302796856246 : Closed e302796856246 ∧ code e302796856246 = 1402308484022 := by decide
theorem cert_e302796856246 : check e302796856246 [[],[]] .smaller = true := by decide
def e302796856278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e302796856278 : Closed e302796856278 ∧ code e302796856278 = 1402308484054 := by decide
theorem cert_e302796856278 : check e302796856278 [[],[]] .three = true := by decide
def e302796856282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e302796856282 : Closed e302796856282 ∧ code e302796856282 = 1402308484058 := by decide
theorem cert_e302796856282 : check e302796856282 [[],[]] .three = true := by decide
def e302796856670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e302796856670 : Closed e302796856670 ∧ code e302796856670 = 1402308484446 := by decide
theorem cert_e302796856670 : check e302796856670 [[],[]] .three = true := by decide
def e302796856686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302796856686 : Closed e302796856686 ∧ code e302796856686 = 1402308484462 := by decide
theorem cert_e302796856686 : check e302796856686 [[],[]] .smaller = true := by decide
def e302796856694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302796856694 : Closed e302796856694 ∧ code e302796856694 = 1402308484470 := by decide
theorem cert_e302796856694 : check e302796856694 [[],[]] .smaller = true := by decide
def e302796856698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e302796856698 : Closed e302796856698 ∧ code e302796856698 = 1402308484474 := by decide
theorem cert_e302796856698 : check e302796856698 [[],[]] .three = true := by decide
def e302796856750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302796856750 : Closed e302796856750 ∧ code e302796856750 = 1402308484526 := by decide
theorem cert_e302796856750 : check e302796856750 [[],[]] .smaller = true := by decide
def e302796856762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302796856762 : Closed e302796856762 ∧ code e302796856762 = 1402308484538 := by decide
theorem cert_e302796856762 : check e302796856762 [[],[]] .smaller = true := by decide
def e302796856790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302796856790 : Closed e302796856790 ∧ code e302796856790 = 1402308484566 := by decide
theorem cert_e302796856790 : check e302796856790 [[],[]] .smaller = true := by decide
def e302796856794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302796856794 : Closed e302796856794 ∧ code e302796856794 = 1402308484570 := by decide
theorem cert_e302796856794 : check e302796856794 [[],[]] .smaller = true := by decide
def e302796856810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e302796856810 : Closed e302796856810 ∧ code e302796856810 = 1402308484586 := by decide
theorem cert_e302796856810 : check e302796856810 [[],[]] .three = true := by decide
def e302796857014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e302796857014 : Closed e302796857014 ∧ code e302796857014 = 1402308484790 := by decide
theorem cert_e302796857014 : check e302796857014 [[],[]] .smaller = true := by decide
def e302796857046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e302796857046 : Closed e302796857046 ∧ code e302796857046 = 1402308484822 := by decide
theorem cert_e302796857046 : check e302796857046 [[],[]] .smaller = true := by decide
def e302796857050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e302796857050 : Closed e302796857050 ∧ code e302796857050 = 1402308484826 := by decide
theorem cert_e302796857050 : check e302796857050 [[],[]] .smaller = true := by decide
def e302796857174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e302796857174 : Closed e302796857174 ∧ code e302796857174 = 1402308484950 := by decide
theorem cert_e302796857174 : check e302796857174 [[],[]] .three = true := by decide
def e302796857178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e302796857178 : Closed e302796857178 ∧ code e302796857178 = 1402308484954 := by decide
theorem cert_e302796857178 : check e302796857178 [[],[]] .three = true := by decide
def e302796857194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e302796857194 : Closed e302796857194 ∧ code e302796857194 = 1402308484970 := by decide
theorem cert_e302796857194 : check e302796857194 [[],[]] .three = true := by decide
def e302796858334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 3))))))))
theorem wire_e302796858334 : Closed e302796858334 ∧ code e302796858334 = 1402308486110 := by decide
theorem cert_e302796858334 : check e302796858334 [[],[]] .three = true := by decide
def e302796858350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.var 2))))))))
theorem wire_e302796858350 : Closed e302796858350 ∧ code e302796858350 = 1402308486126 := by decide
theorem cert_e302796858350 : check e302796858350 [[],[]] .three = true := by decide
def e302796859102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e302796859102 : Closed e302796859102 ∧ code e302796859102 = 1402308486878 := by decide
theorem cert_e302796859102 : check e302796859102 [[],[]] .three = true := by decide
def e302796859126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e302796859126 : Closed e302796859126 ∧ code e302796859126 = 1402308486902 := by decide
theorem cert_e302796859126 : check e302796859126 [[],[]] .three = true := by decide
def e302796859230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e302796859230 : Closed e302796859230 ∧ code e302796859230 = 1402308487006 := by decide
theorem cert_e302796859230 : check e302796859230 [[],[]] .three = true := by decide
def e302796859246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e302796859246 : Closed e302796859246 ∧ code e302796859246 = 1402308487022 := by decide
theorem cert_e302796859246 : check e302796859246 [[],[]] .smaller = true := by decide
def e302796859254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e302796859254 : Closed e302796859254 ∧ code e302796859254 = 1402308487030 := by decide
theorem cert_e302796859254 : check e302796859254 [[],[]] .smaller = true := by decide
def e302796859258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e302796859258 : Closed e302796859258 ∧ code e302796859258 = 1402308487034 := by decide
theorem cert_e302796859258 : check e302796859258 [[],[]] .three = true := by decide
def e302796859318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e302796859318 : Closed e302796859318 ∧ code e302796859318 = 1402308487094 := by decide
theorem cert_e302796859318 : check e302796859318 [[],[]] .smaller = true := by decide
def e302796859350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e302796859350 : Closed e302796859350 ∧ code e302796859350 = 1402308487126 := by decide
theorem cert_e302796859350 : check e302796859350 [[],[]] .three = true := by decide
def e302796859354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e302796859354 : Closed e302796859354 ∧ code e302796859354 = 1402308487130 := by decide
theorem cert_e302796859354 : check e302796859354 [[],[]] .three = true := by decide
def e302796859870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e302796859870 : Closed e302796859870 ∧ code e302796859870 = 1402308487646 := by decide
theorem cert_e302796859870 : check e302796859870 [[],[]] .three = true := by decide
def e302796859894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e302796859894 : Closed e302796859894 ∧ code e302796859894 = 1402308487670 := by decide
theorem cert_e302796859894 : check e302796859894 [[],[]] .three = true := by decide
def e302796860638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302796860638 : Closed e302796860638 ∧ code e302796860638 = 1402308488414 := by decide
theorem cert_e302796860638 : check e302796860638 [[],[]] .three = true := by decide
def e302796860654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302796860654 : Closed e302796860654 ∧ code e302796860654 = 1402308488430 := by decide
theorem cert_e302796860654 : check e302796860654 [[],[]] .smaller = true := by decide
def e302796860662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302796860662 : Closed e302796860662 ∧ code e302796860662 = 1402308488438 := by decide
theorem cert_e302796860662 : check e302796860662 [[],[]] .smaller = true := by decide
def e302796860666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302796860666 : Closed e302796860666 ∧ code e302796860666 = 1402308488442 := by decide
theorem cert_e302796860666 : check e302796860666 [[],[]] .three = true := by decide
def e302796860990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e302796860990 : Closed e302796860990 ∧ code e302796860990 = 1402308488766 := by decide
theorem cert_e302796860990 : check e302796860990 [[],[]] .three = true := by decide
def e302796861046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e302796861046 : Closed e302796861046 ∧ code e302796861046 = 1402308488822 := by decide
theorem cert_e302796861046 : check e302796861046 [[],[]] .smaller = true := by decide
def e302796861214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e302796861214 : Closed e302796861214 ∧ code e302796861214 = 1402308488990 := by decide
theorem cert_e302796861214 : check e302796861214 [[],[]] .three = true := by decide
def e302796861238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302796861238 : Closed e302796861238 ∧ code e302796861238 = 1402308489014 := by decide
theorem cert_e302796861238 : check e302796861238 [[],[]] .three = true := by decide
def e302796861242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302796861242 : Closed e302796861242 ∧ code e302796861242 = 1402308489018 := by decide
theorem cert_e302796861242 : check e302796861242 [[],[]] .three = true := by decide
def e302796861918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 3))))))))
theorem wire_e302796861918 : Closed e302796861918 ∧ code e302796861918 = 1402308489694 := by decide
theorem cert_e302796861918 : check e302796861918 [[],[]] .three = true := by decide
def e302796861934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2))))))))
theorem wire_e302796861934 : Closed e302796861934 ∧ code e302796861934 = 1402308489710 := by decide
theorem cert_e302796861934 : check e302796861934 [[],[]] .smaller = true := by decide
def e302796861942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.var 1))))))))
theorem wire_e302796861942 : Closed e302796861942 ∧ code e302796861942 = 1402308489718 := by decide
theorem cert_e302796861942 : check e302796861942 [[],[]] .three = true := by decide
def e302796862302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e302796862302 : Closed e302796862302 ∧ code e302796862302 = 1402308490078 := by decide
theorem cert_e302796862302 : check e302796862302 [[],[]] .three = true := by decide
def e302796862318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302796862318 : Closed e302796862318 ∧ code e302796862318 = 1402308490094 := by decide
theorem cert_e302796862318 : check e302796862318 [[],[]] .smaller = true := by decide
def e302796862326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302796862326 : Closed e302796862326 ∧ code e302796862326 = 1402308490102 := by decide
theorem cert_e302796862326 : check e302796862326 [[],[]] .smaller = true := by decide
def e302796862330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e302796862330 : Closed e302796862330 ∧ code e302796862330 = 1402308490106 := by decide
theorem cert_e302796862330 : check e302796862330 [[],[]] .three = true := by decide
def e302796862382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302796862382 : Closed e302796862382 ∧ code e302796862382 = 1402308490158 := by decide
theorem cert_e302796862382 : check e302796862382 [[],[]] .smaller = true := by decide
def e302796862394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302796862394 : Closed e302796862394 ∧ code e302796862394 = 1402308490170 := by decide
theorem cert_e302796862394 : check e302796862394 [[],[]] .smaller = true := by decide
def e302796862422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302796862422 : Closed e302796862422 ∧ code e302796862422 = 1402308490198 := by decide
theorem cert_e302796862422 : check e302796862422 [[],[]] .smaller = true := by decide
def e302796862426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302796862426 : Closed e302796862426 ∧ code e302796862426 = 1402308490202 := by decide
theorem cert_e302796862426 : check e302796862426 [[],[]] .smaller = true := by decide
def e302796862442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e302796862442 : Closed e302796862442 ∧ code e302796862442 = 1402308490218 := by decide
theorem cert_e302796862442 : check e302796862442 [[],[]] .three = true := by decide
def e302796862686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302796862686 : Closed e302796862686 ∧ code e302796862686 = 1402308490462 := by decide
theorem cert_e302796862686 : check e302796862686 [[],[]] .three = true := by decide
def e302796862702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302796862702 : Closed e302796862702 ∧ code e302796862702 = 1402308490478 := by decide
theorem cert_e302796862702 : check e302796862702 [[],[]] .smaller = true := by decide
def e302796862710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302796862710 : Closed e302796862710 ∧ code e302796862710 = 1402308490486 := by decide
theorem cert_e302796862710 : check e302796862710 [[],[]] .smaller = true := by decide
def e302796862714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302796862714 : Closed e302796862714 ∧ code e302796862714 = 1402308490490 := by decide
theorem cert_e302796862714 : check e302796862714 [[],[]] .three = true := by decide
def e302796863038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e302796863038 : Closed e302796863038 ∧ code e302796863038 = 1402308490814 := by decide
theorem cert_e302796863038 : check e302796863038 [[],[]] .three = true := by decide
def e302796863086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302796863086 : Closed e302796863086 ∧ code e302796863086 = 1402308490862 := by decide
theorem cert_e302796863086 : check e302796863086 [[],[]] .smaller = true := by decide
def e302796863098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302796863098 : Closed e302796863098 ∧ code e302796863098 = 1402308490874 := by decide
theorem cert_e302796863098 : check e302796863098 [[],[]] .smaller = true := by decide
def e302796863262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e302796863262 : Closed e302796863262 ∧ code e302796863262 = 1402308491038 := by decide
theorem cert_e302796863262 : check e302796863262 [[],[]] .smaller = true := by decide
def e302796863286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302796863286 : Closed e302796863286 ∧ code e302796863286 = 1402308491062 := by decide
theorem cert_e302796863286 : check e302796863286 [[],[]] .smaller = true := by decide
def e302796863290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302796863290 : Closed e302796863290 ∧ code e302796863290 = 1402308491066 := by decide
theorem cert_e302796863290 : check e302796863290 [[],[]] .smaller = true := by decide
def e302796863374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e302796863374 : Closed e302796863374 ∧ code e302796863374 = 1402308491150 := by decide
theorem cert_e302796863374 : check e302796863374 [[],[]] .three = true := by decide
def e302796863386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302796863386 : Closed e302796863386 ∧ code e302796863386 = 1402308491162 := by decide
theorem cert_e302796863386 : check e302796863386 [[],[]] .three = true := by decide
def e302796863710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 3))))))))
theorem wire_e302796863710 : Closed e302796863710 ∧ code e302796863710 = 1402308491486 := by decide
theorem cert_e302796863710 : check e302796863710 [[],[]] .three = true := by decide
def e302796863726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2))))))))
theorem wire_e302796863726 : Closed e302796863726 ∧ code e302796863726 = 1402308491502 := by decide
theorem cert_e302796863726 : check e302796863726 [[],[]] .smaller = true := by decide
def e302796863734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1))))))))
theorem wire_e302796863734 : Closed e302796863734 ∧ code e302796863734 = 1402308491510 := by decide
theorem cert_e302796863734 : check e302796863734 [[],[]] .smaller = true := by decide
def e302796863738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 4))) (.var 0))))))))
theorem wire_e302796863738 : Closed e302796863738 ∧ code e302796863738 = 1402308491514 := by decide
theorem cert_e302796863738 : check e302796863738 [[],[]] .three = true := by decide
def e302796863926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e302796863926 : Closed e302796863926 ∧ code e302796863926 = 1402308491702 := by decide
theorem cert_e302796863926 : check e302796863926 [[],[]] .smaller = true := by decide
def e302796863958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e302796863958 : Closed e302796863958 ∧ code e302796863958 = 1402308491734 := by decide
theorem cert_e302796863958 : check e302796863958 [[],[]] .smaller = true := by decide
def e302796863962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e302796863962 : Closed e302796863962 ∧ code e302796863962 = 1402308491738 := by decide
theorem cert_e302796863962 : check e302796863962 [[],[]] .smaller = true := by decide
def e302796864062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e302796864062 : Closed e302796864062 ∧ code e302796864062 = 1402308491838 := by decide
theorem cert_e302796864062 : check e302796864062 [[],[]] .three = true := by decide
def e302796864118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e302796864118 : Closed e302796864118 ∧ code e302796864118 = 1402308491894 := by decide
theorem cert_e302796864118 : check e302796864118 [[],[]] .smaller = true := by decide
def e302796864286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e302796864286 : Closed e302796864286 ∧ code e302796864286 = 1402308492062 := by decide
theorem cert_e302796864286 : check e302796864286 [[],[]] .smaller = true := by decide
def e302796864310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302796864310 : Closed e302796864310 ∧ code e302796864310 = 1402308492086 := by decide
theorem cert_e302796864310 : check e302796864310 [[],[]] .smaller = true := by decide
def e302796864314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302796864314 : Closed e302796864314 ∧ code e302796864314 = 1402308492090 := by decide
theorem cert_e302796864314 : check e302796864314 [[],[]] .smaller = true := by decide
def e302796864398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e302796864398 : Closed e302796864398 ∧ code e302796864398 = 1402308492174 := by decide
theorem cert_e302796864398 : check e302796864398 [[],[]] .smaller = true := by decide
def e302796864454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e302796864454 : Closed e302796864454 ∧ code e302796864454 = 1402308492230 := by decide
theorem cert_e302796864454 : check e302796864454 [[],[]] .three = true := by decide
def e302796864478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 3))))))))
theorem wire_e302796864478 : Closed e302796864478 ∧ code e302796864478 = 1402308492254 := by decide
theorem cert_e302796864478 : check e302796864478 [[],[]] .three = true := by decide
def e302796864622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302796864622 : Closed e302796864622 ∧ code e302796864622 = 1402308492398 := by decide
theorem cert_e302796864622 : check e302796864622 [[],[]] .three = true := by decide
def e302796864630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.var 1))))))))
theorem wire_e302796864630 : Closed e302796864630 ∧ code e302796864630 = 1402308492406 := by decide
theorem cert_e302796864630 : check e302796864630 [[],[]] .three = true := by decide
def e302796864634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302796864634 : Closed e302796864634 ∧ code e302796864634 = 1402308492410 := by decide
theorem cert_e302796864634 : check e302796864634 [[],[]] .three = true := by decide
def e302796864726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e302796864726 : Closed e302796864726 ∧ code e302796864726 = 1402308492502 := by decide
theorem cert_e302796864726 : check e302796864726 [[],[]] .three = true := by decide
def e302796864730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e302796864730 : Closed e302796864730 ∧ code e302796864730 = 1402308492506 := by decide
theorem cert_e302796864730 : check e302796864730 [[],[]] .three = true := by decide
def e302796864746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e302796864746 : Closed e302796864746 ∧ code e302796864746 = 1402308492522 := by decide
theorem cert_e302796864746 : check e302796864746 [[],[]] .three = true := by decide
def e302796864798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302796864798 : Closed e302796864798 ∧ code e302796864798 = 1402308492574 := by decide
theorem cert_e302796864798 : check e302796864798 [[],[]] .three = true := by decide
def e302796864822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302796864822 : Closed e302796864822 ∧ code e302796864822 = 1402308492598 := by decide
theorem cert_e302796864822 : check e302796864822 [[],[]] .three = true := by decide
def e302796864826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302796864826 : Closed e302796864826 ∧ code e302796864826 = 1402308492602 := by decide
theorem cert_e302796864826 : check e302796864826 [[],[]] .three = true := by decide
def e302796864910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e302796864910 : Closed e302796864910 ∧ code e302796864910 = 1402308492686 := by decide
theorem cert_e302796864910 : check e302796864910 [[],[]] .three = true := by decide
def e302796864922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302796864922 : Closed e302796864922 ∧ code e302796864922 = 1402308492698 := by decide
theorem cert_e302796864922 : check e302796864922 [[],[]] .three = true := by decide
def e302796864966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302796864966 : Closed e302796864966 ∧ code e302796864966 = 1402308492742 := by decide
theorem cert_e302796864966 : check e302796864966 [[],[]] .three = true := by decide
def e302796864990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 3))))))))
theorem wire_e302796864990 : Closed e302796864990 ∧ code e302796864990 = 1402308492766 := by decide
theorem cert_e302796864990 : check e302796864990 [[],[]] .three = true := by decide
def e302796865006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 2))))))))
theorem wire_e302796865006 : Closed e302796865006 ∧ code e302796865006 = 1402308492782 := by decide
theorem cert_e302796865006 : check e302796865006 [[],[]] .three = true := by decide
def e302796867518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e302796867518 : Closed e302796867518 ∧ code e302796867518 = 1402308495294 := by decide
theorem cert_e302796867518 : check e302796867518 [[],[]] .three = true := by decide
def e302796867566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e302796867566 : Closed e302796867566 ∧ code e302796867566 = 1402308495342 := by decide
theorem cert_e302796867566 : check e302796867566 [[],[]] .three = true := by decide
def e302796871390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302796871390 : Closed e302796871390 ∧ code e302796871390 = 1402308499166 := by decide
theorem cert_e302796871390 : check e302796871390 [[],[]] .three = true := by decide
def e302796871414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302796871414 : Closed e302796871414 ∧ code e302796871414 = 1402308499190 := by decide
theorem cert_e302796871414 : check e302796871414 [[],[]] .three = true := by decide
def e302796871518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302796871518 : Closed e302796871518 ∧ code e302796871518 = 1402308499294 := by decide
theorem cert_e302796871518 : check e302796871518 [[],[]] .three = true := by decide
def e302796871534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e302796871534 : Closed e302796871534 ∧ code e302796871534 = 1402308499310 := by decide
theorem cert_e302796871534 : check e302796871534 [[],[]] .smaller = true := by decide
def e302796871542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e302796871542 : Closed e302796871542 ∧ code e302796871542 = 1402308499318 := by decide
theorem cert_e302796871542 : check e302796871542 [[],[]] .smaller = true := by decide
def e302796871546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302796871546 : Closed e302796871546 ∧ code e302796871546 = 1402308499322 := by decide
theorem cert_e302796871546 : check e302796871546 [[],[]] .three = true := by decide
def e302796871606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e302796871606 : Closed e302796871606 ∧ code e302796871606 = 1402308499382 := by decide
theorem cert_e302796871606 : check e302796871606 [[],[]] .smaller = true := by decide
def e302796871638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302796871638 : Closed e302796871638 ∧ code e302796871638 = 1402308499414 := by decide
theorem cert_e302796871638 : check e302796871638 [[],[]] .three = true := by decide
def e302796871642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302796871642 : Closed e302796871642 ∧ code e302796871642 = 1402308499418 := by decide
theorem cert_e302796871642 : check e302796871642 [[],[]] .three = true := by decide
def e302796872158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302796872158 : Closed e302796872158 ∧ code e302796872158 = 1402308499934 := by decide
theorem cert_e302796872158 : check e302796872158 [[],[]] .three = true := by decide
def e302796872182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302796872182 : Closed e302796872182 ∧ code e302796872182 = 1402308499958 := by decide
theorem cert_e302796872182 : check e302796872182 [[],[]] .three = true := by decide
def e302796872926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302796872926 : Closed e302796872926 ∧ code e302796872926 = 1402308500702 := by decide
theorem cert_e302796872926 : check e302796872926 [[],[]] .three = true := by decide
def e302796872942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e302796872942 : Closed e302796872942 ∧ code e302796872942 = 1402308500718 := by decide
theorem cert_e302796872942 : check e302796872942 [[],[]] .smaller = true := by decide
def e302796872950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e302796872950 : Closed e302796872950 ∧ code e302796872950 = 1402308500726 := by decide
theorem cert_e302796872950 : check e302796872950 [[],[]] .smaller = true := by decide
def e302796872954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302796872954 : Closed e302796872954 ∧ code e302796872954 = 1402308500730 := by decide
theorem cert_e302796872954 : check e302796872954 [[],[]] .three = true := by decide
def e302796873278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e302796873278 : Closed e302796873278 ∧ code e302796873278 = 1402308501054 := by decide
theorem cert_e302796873278 : check e302796873278 [[],[]] .three = true := by decide
def e302796873334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e302796873334 : Closed e302796873334 ∧ code e302796873334 = 1402308501110 := by decide
theorem cert_e302796873334 : check e302796873334 [[],[]] .smaller = true := by decide
def e302796873502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e302796873502 : Closed e302796873502 ∧ code e302796873502 = 1402308501278 := by decide
theorem cert_e302796873502 : check e302796873502 [[],[]] .three = true := by decide
def e302796873526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302796873526 : Closed e302796873526 ∧ code e302796873526 = 1402308501302 := by decide
theorem cert_e302796873526 : check e302796873526 [[],[]] .three = true := by decide
def e302796873530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302796873530 : Closed e302796873530 ∧ code e302796873530 = 1402308501306 := by decide
theorem cert_e302796873530 : check e302796873530 [[],[]] .three = true := by decide
def e302796882878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e302796882878 : Closed e302796882878 ∧ code e302796882878 = 1402308510654 := by decide
theorem cert_e302796882878 : check e302796882878 [[],[]] .three = true := by decide
def e302796882910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e302796882910 : Closed e302796882910 ∧ code e302796882910 = 1402308510686 := by decide
theorem cert_e302796882910 : check e302796882910 [[],[]] .smaller = true := by decide
def e302796882926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e302796882926 : Closed e302796882926 ∧ code e302796882926 = 1402308510702 := by decide
theorem cert_e302796882926 : check e302796882926 [[],[]] .smaller = true := by decide
def e302796882934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e302796882934 : Closed e302796882934 ∧ code e302796882934 = 1402308510710 := by decide
theorem cert_e302796882934 : check e302796882934 [[],[]] .three = true := by decide
def e302796884830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e302796884830 : Closed e302796884830 ∧ code e302796884830 = 1402308512606 := by decide
theorem cert_e302796884830 : check e302796884830 [[],[]] .three = true := by decide
def e302796884846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302796884846 : Closed e302796884846 ∧ code e302796884846 = 1402308512622 := by decide
theorem cert_e302796884846 : check e302796884846 [[],[]] .smaller = true := by decide
def e302796884854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302796884854 : Closed e302796884854 ∧ code e302796884854 = 1402308512630 := by decide
theorem cert_e302796884854 : check e302796884854 [[],[]] .smaller = true := by decide
def e302796884858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e302796884858 : Closed e302796884858 ∧ code e302796884858 = 1402308512634 := by decide
theorem cert_e302796884858 : check e302796884858 [[],[]] .three = true := by decide
def e302796884910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302796884910 : Closed e302796884910 ∧ code e302796884910 = 1402308512686 := by decide
theorem cert_e302796884910 : check e302796884910 [[],[]] .smaller = true := by decide
def e302796884922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302796884922 : Closed e302796884922 ∧ code e302796884922 = 1402308512698 := by decide
theorem cert_e302796884922 : check e302796884922 [[],[]] .smaller = true := by decide
def e302796884950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302796884950 : Closed e302796884950 ∧ code e302796884950 = 1402308512726 := by decide
theorem cert_e302796884950 : check e302796884950 [[],[]] .smaller = true := by decide
def e302796884954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302796884954 : Closed e302796884954 ∧ code e302796884954 = 1402308512730 := by decide
theorem cert_e302796884954 : check e302796884954 [[],[]] .smaller = true := by decide
def e302796884970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e302796884970 : Closed e302796884970 ∧ code e302796884970 = 1402308512746 := by decide
theorem cert_e302796884970 : check e302796884970 [[],[]] .three = true := by decide
def e302796885214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e302796885214 : Closed e302796885214 ∧ code e302796885214 = 1402308512990 := by decide
theorem cert_e302796885214 : check e302796885214 [[],[]] .three = true := by decide
def e302796885230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302796885230 : Closed e302796885230 ∧ code e302796885230 = 1402308513006 := by decide
theorem cert_e302796885230 : check e302796885230 [[],[]] .smaller = true := by decide
def e302796885238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302796885238 : Closed e302796885238 ∧ code e302796885238 = 1402308513014 := by decide
theorem cert_e302796885238 : check e302796885238 [[],[]] .smaller = true := by decide
def e302796885242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e302796885242 : Closed e302796885242 ∧ code e302796885242 = 1402308513018 := by decide
theorem cert_e302796885242 : check e302796885242 [[],[]] .three = true := by decide
def e302796885566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e302796885566 : Closed e302796885566 ∧ code e302796885566 = 1402308513342 := by decide
theorem cert_e302796885566 : check e302796885566 [[],[]] .three = true := by decide
def e302796885614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302796885614 : Closed e302796885614 ∧ code e302796885614 = 1402308513390 := by decide
theorem cert_e302796885614 : check e302796885614 [[],[]] .smaller = true := by decide
def e302796885626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302796885626 : Closed e302796885626 ∧ code e302796885626 = 1402308513402 := by decide
theorem cert_e302796885626 : check e302796885626 [[],[]] .smaller = true := by decide
def e302796885790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e302796885790 : Closed e302796885790 ∧ code e302796885790 = 1402308513566 := by decide
theorem cert_e302796885790 : check e302796885790 [[],[]] .smaller = true := by decide
def e302796885814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302796885814 : Closed e302796885814 ∧ code e302796885814 = 1402308513590 := by decide
theorem cert_e302796885814 : check e302796885814 [[],[]] .smaller = true := by decide
def e302796885818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302796885818 : Closed e302796885818 ∧ code e302796885818 = 1402308513594 := by decide
theorem cert_e302796885818 : check e302796885818 [[],[]] .smaller = true := by decide
def e302796885902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e302796885902 : Closed e302796885902 ∧ code e302796885902 = 1402308513678 := by decide
theorem cert_e302796885902 : check e302796885902 [[],[]] .three = true := by decide
def e302796885914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e302796885914 : Closed e302796885914 ∧ code e302796885914 = 1402308513690 := by decide
theorem cert_e302796885914 : check e302796885914 [[],[]] .three = true := by decide
def e302796890606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e302796890606 : Closed e302796890606 ∧ code e302796890606 = 1402308518382 := by decide
theorem cert_e302796890606 : check e302796890606 [[],[]] .smaller = true := by decide
def e302796891574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e302796891574 : Closed e302796891574 ∧ code e302796891574 = 1402308519350 := by decide
theorem cert_e302796891574 : check e302796891574 [[],[]] .smaller = true := by decide
def e302796891606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e302796891606 : Closed e302796891606 ∧ code e302796891606 = 1402308519382 := by decide
theorem cert_e302796891606 : check e302796891606 [[],[]] .smaller = true := by decide
def e302796891610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e302796891610 : Closed e302796891610 ∧ code e302796891610 = 1402308519386 := by decide
theorem cert_e302796891610 : check e302796891610 [[],[]] .smaller = true := by decide
def e302796891710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e302796891710 : Closed e302796891710 ∧ code e302796891710 = 1402308519486 := by decide
theorem cert_e302796891710 : check e302796891710 [[],[]] .three = true := by decide
def e302796891766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e302796891766 : Closed e302796891766 ∧ code e302796891766 = 1402308519542 := by decide
theorem cert_e302796891766 : check e302796891766 [[],[]] .smaller = true := by decide
def e302796891934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e302796891934 : Closed e302796891934 ∧ code e302796891934 = 1402308519710 := by decide
theorem cert_e302796891934 : check e302796891934 [[],[]] .smaller = true := by decide
def e302796891958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e302796891958 : Closed e302796891958 ∧ code e302796891958 = 1402308519734 := by decide
theorem cert_e302796891958 : check e302796891958 [[],[]] .smaller = true := by decide
def e302796891962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e302796891962 : Closed e302796891962 ∧ code e302796891962 = 1402308519738 := by decide
theorem cert_e302796891962 : check e302796891962 [[],[]] .smaller = true := by decide
def e302796892046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e302796892046 : Closed e302796892046 ∧ code e302796892046 = 1402308519822 := by decide
theorem cert_e302796892046 : check e302796892046 [[],[]] .smaller = true := by decide
def e302796892102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e302796892102 : Closed e302796892102 ∧ code e302796892102 = 1402308519878 := by decide
theorem cert_e302796892102 : check e302796892102 [[],[]] .three = true := by decide
def e302796892126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 3)))))))))
theorem wire_e302796892126 : Closed e302796892126 ∧ code e302796892126 = 1402308519902 := by decide
theorem cert_e302796892126 : check e302796892126 [[],[]] .three = true := by decide
def e302796894446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e302796894446 : Closed e302796894446 ∧ code e302796894446 = 1402308522222 := by decide
theorem cert_e302796894446 : check e302796894446 [[],[]] .three = true := by decide
def e302796894454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e302796894454 : Closed e302796894454 ∧ code e302796894454 = 1402308522230 := by decide
theorem cert_e302796894454 : check e302796894454 [[],[]] .three = true := by decide
def e302796894934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302796894934 : Closed e302796894934 ∧ code e302796894934 = 1402308522710 := by decide
theorem cert_e302796894934 : check e302796894934 [[],[]] .three = true := by decide
def e302796894938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302796894938 : Closed e302796894938 ∧ code e302796894938 = 1402308522714 := by decide
theorem cert_e302796894938 : check e302796894938 [[],[]] .three = true := by decide
def e302796894954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302796894954 : Closed e302796894954 ∧ code e302796894954 = 1402308522730 := by decide
theorem cert_e302796894954 : check e302796894954 [[],[]] .three = true := by decide
def e302796895006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302796895006 : Closed e302796895006 ∧ code e302796895006 = 1402308522782 := by decide
theorem cert_e302796895006 : check e302796895006 [[],[]] .three = true := by decide
def e302796895030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302796895030 : Closed e302796895030 ∧ code e302796895030 = 1402308522806 := by decide
theorem cert_e302796895030 : check e302796895030 [[],[]] .three = true := by decide
def e302796895034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302796895034 : Closed e302796895034 ∧ code e302796895034 = 1402308522810 := by decide
theorem cert_e302796895034 : check e302796895034 [[],[]] .three = true := by decide
end Blc.Floor40
