import R302824803182Blk0
import R302824803182Blk6
import R302824803182Blk12
import R302824803182Blk18
import R302824803182Blk24
import R302824803182Blk30
import R302824803182Blk36
import R302824803182Blk42
namespace Certgen.R302824803182
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def terms : Array Term := #[(.app (.app (.app (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))),(.app (.app (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))))))),(.app (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))) (.lam (.lam (.var 0)))),(.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))),(.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))),(.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))),(.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))),(.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))),(.var 1),(.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))),(.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))),(.var 2),(.app (.app (.var 0) (.var 1)) (.var 2)),(.app (.var 0) (.var 1)),(.var 0),(.var 1),(.var 2),(.lam (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))),(.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))),(.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))),(.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))),(.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))),(.var 1),(.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))),(.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))),(.var 2),(.app (.app (.var 0) (.var 1)) (.var 2)),(.app (.var 0) (.var 1)),(.var 0),(.var 1),(.var 2),(.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))),(.app (.var 0) (.var 1)),(.var 0),(.var 1),(.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))),(.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))),(.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))),(.var 1),(.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))),(.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))),(.var 2),(.app (.app (.var 0) (.var 1)) (.var 2)),(.app (.var 0) (.var 1)),(.var 0),(.var 1),(.var 2),(.lam (.lam (.var 0))),(.lam (.var 0)),(.var 0),(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))))))),(.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))))),(.app (.var 0) (.lam (.lam (.var 1)))),(.var 0),(.lam (.lam (.var 1))),(.lam (.var 1)),(.var 1),(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))))),(.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))),(.app (.var 0) (.lam (.lam (.var 1)))),(.var 0),(.lam (.lam (.var 1))),(.lam (.var 1)),(.var 1),(.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))),(.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))),(.app (.var 0) (.lam (.lam (.var 0)))),(.var 0),(.lam (.lam (.var 0))),(.lam (.var 0)),(.var 0),(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))),(.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)),(.app (.var 0) (.lam (.lam (.var 1)))),(.var 0),(.lam (.lam (.var 1))),(.lam (.var 1)),(.var 1),(.var 4),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0)]
def termAt (p : Nat) : Term := terms[p]?.getD (.var 0)
def aligns (p : Nat) : Bool := match P p with
 | .opaque => true
 | .var i => decide (termAt p = Term.var i)
 | .lam b => decide (termAt p = Term.lam (termAt b))
 | .app f a => decide (termAt p = Term.app (termAt f) (termAt a))
theorem valid : (List.range code.size).all aligns = true := by decide
theorem every (p : Nat) : aligns p = true := by
 by_cases hp : p < code.size
 · exact List.all_eq_true.mp valid p (List.mem_range.mpr hp)
 · have hz : code[p]? = none := Array.getElem?_eq_none (by omega)
   simp [aligns,P,hz]
def model : Model P where
 term := termAt
 var_eq := by intro p i h; simpa [aligns,h] using every p
 lam_eq := by intro p b h; simpa [aligns,h] using every p
 app_eq := by intro p f a h; simpa [aligns,h] using every p
theorem allValid (i : Nat) (h : i < 524) : validState i = true := by
 by_cases h264 : i < 264
 · by_cases h132 : i < 132
   · by_cases h60 : i < 60
     · by_cases h24 : i < 24
       · by_cases h12 : i < 12
         · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
       · by_cases h36 : i < 36
         · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
         · by_cases h48 : i < 48
           · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
     · by_cases h96 : i < 96
       · by_cases h72 : i < 72
         · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
         · by_cases h84 : i < 84
           · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
       · by_cases h108 : i < 108
         · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
         · by_cases h120 : i < 120
           · exact FloorIndex.rangeOK_at bl108 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl120 (by omega) (by omega)
   · by_cases h192 : i < 192
     · by_cases h156 : i < 156
       · by_cases h144 : i < 144
         · exact FloorIndex.rangeOK_at bl132 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl144 (by omega) (by omega)
       · by_cases h168 : i < 168
         · exact FloorIndex.rangeOK_at bl156 (by omega) (by omega)
         · by_cases h180 : i < 180
           · exact FloorIndex.rangeOK_at bl168 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl180 (by omega) (by omega)
     · by_cases h228 : i < 228
       · by_cases h204 : i < 204
         · exact FloorIndex.rangeOK_at bl192 (by omega) (by omega)
         · by_cases h216 : i < 216
           · exact FloorIndex.rangeOK_at bl204 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl216 (by omega) (by omega)
       · by_cases h240 : i < 240
         · exact FloorIndex.rangeOK_at bl228 (by omega) (by omega)
         · by_cases h252 : i < 252
           · exact FloorIndex.rangeOK_at bl240 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl252 (by omega) (by omega)
 · by_cases h396 : i < 396
   · by_cases h324 : i < 324
     · by_cases h288 : i < 288
       · by_cases h276 : i < 276
         · exact FloorIndex.rangeOK_at bl264 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl276 (by omega) (by omega)
       · by_cases h300 : i < 300
         · exact FloorIndex.rangeOK_at bl288 (by omega) (by omega)
         · by_cases h312 : i < 312
           · exact FloorIndex.rangeOK_at bl300 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl312 (by omega) (by omega)
     · by_cases h360 : i < 360
       · by_cases h336 : i < 336
         · exact FloorIndex.rangeOK_at bl324 (by omega) (by omega)
         · by_cases h348 : i < 348
           · exact FloorIndex.rangeOK_at bl336 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl348 (by omega) (by omega)
       · by_cases h372 : i < 372
         · exact FloorIndex.rangeOK_at bl360 (by omega) (by omega)
         · by_cases h384 : i < 384
           · exact FloorIndex.rangeOK_at bl372 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl384 (by omega) (by omega)
   · by_cases h456 : i < 456
     · by_cases h420 : i < 420
       · by_cases h408 : i < 408
         · exact FloorIndex.rangeOK_at bl396 (by omega) (by omega)
         · exact FloorIndex.rangeOK_at bl408 (by omega) (by omega)
       · by_cases h432 : i < 432
         · exact FloorIndex.rangeOK_at bl420 (by omega) (by omega)
         · by_cases h444 : i < 444
           · exact FloorIndex.rangeOK_at bl432 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl444 (by omega) (by omega)
     · by_cases h492 : i < 492
       · by_cases h468 : i < 468
         · exact FloorIndex.rangeOK_at bl456 (by omega) (by omega)
         · by_cases h480 : i < 480
           · exact FloorIndex.rangeOK_at bl468 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl480 (by omega) (by omega)
       · by_cases h504 : i < 504
         · exact FloorIndex.rangeOK_at bl492 (by omega) (by omega)
         · by_cases h516 : i < 516
           · exact FloorIndex.rangeOK_at bl504 (by omega) (by omega)
           · exact FloorIndex.rangeOK_at bl516 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 524
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e302824803182 := by
 intro he
 have hp : replay [[.left,.left,.left],[.left,.left,.left]] (call e302824803182 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R302824803182
