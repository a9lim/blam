import CodeBridge
import R302887562694Blk0
import R302887562694Blk6
import R302887562694Blk12
namespace Certgen.R302887562694
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit61 : Term := .var 0
def lit51 : Term := .var 1
def lit18 : Term := .var 2
def lit43 : Term := .lam lit61
def lit50 : Term := .lam lit51
def lit59 : Term := .app lit61 lit61
def lit42 : Term := .lam lit43
def lit52 : Term := .var 4
def lit15 : Term := .app lit61 lit51
def lit49 : Term := .lam lit50
def lit58 : Term := .lam lit59
def lit40 : Term := .app lit61 lit42
def lit47 : Term := .app lit61 lit49
def lit14 : Term := .app lit15 lit18
def lit13 : Term := .lam lit14
def lit12 : Term := .lam lit13
def lit53 : Term := .app lit58 lit58
def lit46 : Term := .app lit47 lit52
def lit10 : Term := .app lit61 lit12
def lit45 : Term := .lam lit46
def lit9 : Term := .app lit10 lit50
def lit8 : Term := .lam lit9
def lit39 : Term := .app lit40 lit45
def lit38 : Term := .lam lit39
def lit3 : Term := .app lit58 lit8
def lit2 : Term := .app lit3 lit42
def lit32 : Term := .app lit47 lit38
def lit31 : Term := .lam lit32
def lit25 : Term := .app lit47 lit31
def lit24 : Term := .lam lit25
def lit1 : Term := .app lit2 lit24
def lit0 : Term := .app lit1 lit53
def filling : Nat → Term := fun p => if p = 52 then Term.var 4 else Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub61 : model.term 61 = lit61 := model.var_eq 61 0 (by rfl)
theorem sub60 : model.term 60 = lit61 := model.var_eq 60 0 (by rfl)
theorem sub59 : model.term 59 = lit59 := by rw [model.app_eq 59 60 61 (by rfl), sub60, sub61]; rfl
theorem sub58 : model.term 58 = lit58 := by rw [model.lam_eq 58 59 (by rfl), sub59]; rfl
theorem sub57 : model.term 57 = lit61 := model.var_eq 57 0 (by rfl)
theorem sub56 : model.term 56 = lit61 := model.var_eq 56 0 (by rfl)
theorem sub55 : model.term 55 = lit59 := by rw [model.app_eq 55 56 57 (by rfl), sub56, sub57]; rfl
theorem sub54 : model.term 54 = lit58 := by rw [model.lam_eq 54 55 (by rfl), sub55]; rfl
theorem sub53 : model.term 53 = lit53 := by rw [model.app_eq 53 54 58 (by rfl), sub54, sub58]; rfl
theorem sub52 : model.term 52 = lit52 := (opaqueTerm (rankedCode code ordered_code) filling (p := 52) (by rfl)).trans (by rfl)
theorem sub51 : model.term 51 = lit51 := model.var_eq 51 1 (by rfl)
theorem sub50 : model.term 50 = lit50 := by rw [model.lam_eq 50 51 (by rfl), sub51]; rfl
theorem sub49 : model.term 49 = lit49 := by rw [model.lam_eq 49 50 (by rfl), sub50]; rfl
theorem sub48 : model.term 48 = lit61 := model.var_eq 48 0 (by rfl)
theorem sub47 : model.term 47 = lit47 := by rw [model.app_eq 47 48 49 (by rfl), sub48, sub49]; rfl
theorem sub46 : model.term 46 = lit46 := by rw [model.app_eq 46 47 52 (by rfl), sub47, sub52]; rfl
theorem sub45 : model.term 45 = lit45 := by rw [model.lam_eq 45 46 (by rfl), sub46]; rfl
theorem sub44 : model.term 44 = lit61 := model.var_eq 44 0 (by rfl)
theorem sub43 : model.term 43 = lit43 := by rw [model.lam_eq 43 44 (by rfl), sub44]; rfl
theorem sub42 : model.term 42 = lit42 := by rw [model.lam_eq 42 43 (by rfl), sub43]; rfl
theorem sub41 : model.term 41 = lit61 := model.var_eq 41 0 (by rfl)
theorem sub40 : model.term 40 = lit40 := by rw [model.app_eq 40 41 42 (by rfl), sub41, sub42]; rfl
theorem sub39 : model.term 39 = lit39 := by rw [model.app_eq 39 40 45 (by rfl), sub40, sub45]; rfl
theorem sub38 : model.term 38 = lit38 := by rw [model.lam_eq 38 39 (by rfl), sub39]; rfl
theorem sub37 : model.term 37 = lit51 := model.var_eq 37 1 (by rfl)
theorem sub36 : model.term 36 = lit50 := by rw [model.lam_eq 36 37 (by rfl), sub37]; rfl
theorem sub35 : model.term 35 = lit49 := by rw [model.lam_eq 35 36 (by rfl), sub36]; rfl
theorem sub34 : model.term 34 = lit61 := model.var_eq 34 0 (by rfl)
theorem sub33 : model.term 33 = lit47 := by rw [model.app_eq 33 34 35 (by rfl), sub34, sub35]; rfl
theorem sub32 : model.term 32 = lit32 := by rw [model.app_eq 32 33 38 (by rfl), sub33, sub38]; rfl
theorem sub31 : model.term 31 = lit31 := by rw [model.lam_eq 31 32 (by rfl), sub32]; rfl
theorem sub30 : model.term 30 = lit51 := model.var_eq 30 1 (by rfl)
theorem sub29 : model.term 29 = lit50 := by rw [model.lam_eq 29 30 (by rfl), sub30]; rfl
theorem sub28 : model.term 28 = lit49 := by rw [model.lam_eq 28 29 (by rfl), sub29]; rfl
theorem sub27 : model.term 27 = lit61 := model.var_eq 27 0 (by rfl)
theorem sub26 : model.term 26 = lit47 := by rw [model.app_eq 26 27 28 (by rfl), sub27, sub28]; rfl
theorem sub25 : model.term 25 = lit25 := by rw [model.app_eq 25 26 31 (by rfl), sub26, sub31]; rfl
theorem sub24 : model.term 24 = lit24 := by rw [model.lam_eq 24 25 (by rfl), sub25]; rfl
theorem sub23 : model.term 23 = lit61 := model.var_eq 23 0 (by rfl)
theorem sub22 : model.term 22 = lit43 := by rw [model.lam_eq 22 23 (by rfl), sub23]; rfl
theorem sub21 : model.term 21 = lit42 := by rw [model.lam_eq 21 22 (by rfl), sub22]; rfl
theorem sub20 : model.term 20 = lit51 := model.var_eq 20 1 (by rfl)
theorem sub19 : model.term 19 = lit50 := by rw [model.lam_eq 19 20 (by rfl), sub20]; rfl
theorem sub18 : model.term 18 = lit18 := model.var_eq 18 2 (by rfl)
theorem sub17 : model.term 17 = lit51 := model.var_eq 17 1 (by rfl)
theorem sub16 : model.term 16 = lit61 := model.var_eq 16 0 (by rfl)
theorem sub15 : model.term 15 = lit15 := by rw [model.app_eq 15 16 17 (by rfl), sub16, sub17]; rfl
theorem sub14 : model.term 14 = lit14 := by rw [model.app_eq 14 15 18 (by rfl), sub15, sub18]; rfl
theorem sub13 : model.term 13 = lit13 := by rw [model.lam_eq 13 14 (by rfl), sub14]; rfl
theorem sub12 : model.term 12 = lit12 := by rw [model.lam_eq 12 13 (by rfl), sub13]; rfl
theorem sub11 : model.term 11 = lit61 := model.var_eq 11 0 (by rfl)
theorem sub10 : model.term 10 = lit10 := by rw [model.app_eq 10 11 12 (by rfl), sub11, sub12]; rfl
theorem sub9 : model.term 9 = lit9 := by rw [model.app_eq 9 10 19 (by rfl), sub10, sub19]; rfl
theorem sub8 : model.term 8 = lit8 := by rw [model.lam_eq 8 9 (by rfl), sub9]; rfl
theorem sub7 : model.term 7 = lit61 := model.var_eq 7 0 (by rfl)
theorem sub6 : model.term 6 = lit61 := model.var_eq 6 0 (by rfl)
theorem sub5 : model.term 5 = lit59 := by rw [model.app_eq 5 6 7 (by rfl), sub6, sub7]; rfl
theorem sub4 : model.term 4 = lit58 := by rw [model.lam_eq 4 5 (by rfl), sub5]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 8 (by rfl), sub4, sub8]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 21 (by rfl), sub3, sub21]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 24 (by rfl), sub2, sub24]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 53 (by rfl), sub1, sub53]; rfl
theorem allValid (i : Nat) (h : i < 174) : validState i = true := by
 by_cases h84 : i < 84
 · by_cases h36 : i < 36
   · by_cases h12 : i < 12
     · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
     · by_cases h24 : i < 24
       · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
   · by_cases h60 : i < 60
     · by_cases h48 : i < 48
       · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
     · by_cases h72 : i < 72
       · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
 · by_cases h132 : i < 132
   · by_cases h108 : i < 108
     · by_cases h96 : i < 96
       · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
     · by_cases h120 : i < 120
       · exact FloorIndex.rangeOK_at bl108 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl120 (by omega) (by omega)
   · by_cases h156 : i < 156
     · by_cases h144 : i < 144
       · exact FloorIndex.rangeOK_at bl132 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl144 (by omega) (by omega)
     · by_cases h168 : i < 168
       · exact FloorIndex.rangeOK_at bl156 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl168 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 174
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e302887562694 := by
 intro he
 have hp : replay [] (call e302887562694 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R302887562694
