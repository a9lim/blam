import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e299070748470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e299070748470 : Closed e299070748470 ∧ code e299070748470 = 1398582376246 := by decide
theorem cert_e299070748470 : check e299070748470 [[],[.left]] .chain = true := by decide
def e299070748474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e299070748474 : Closed e299070748474 ∧ code e299070748474 = 1398582376250 := by decide
theorem cert_e299070748474 : check e299070748474 [[],[.left]] .chain = true := by decide
def e299070749110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e299070749110 : Closed e299070749110 ∧ code e299070749110 = 1398582376886 := by decide
theorem cert_e299070749110 : check e299070749110 [[],[.left]] .chain = true := by decide
def e299070749142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e299070749142 : Closed e299070749142 ∧ code e299070749142 = 1398582376918 := by decide
theorem cert_e299070749142 : check e299070749142 [[],[.left]] .chain = true := by decide
def e299070749146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e299070749146 : Closed e299070749146 ∧ code e299070749146 = 1398582376922 := by decide
theorem cert_e299070749146 : check e299070749146 [[],[.left]] .chain = true := by decide
def e299070749302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e299070749302 : Closed e299070749302 ∧ code e299070749302 = 1398582377078 := by decide
theorem cert_e299070749302 : check e299070749302 [[],[.left]] .chain = true := by decide
def e299070749494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e299070749494 : Closed e299070749494 ∧ code e299070749494 = 1398582377270 := by decide
theorem cert_e299070749494 : check e299070749494 [[],[.left]] .chain = true := by decide
def e299070749498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e299070749498 : Closed e299070749498 ∧ code e299070749498 = 1398582377274 := by decide
theorem cert_e299070749498 : check e299070749498 [[],[.left]] .chain = true := by decide
def e299070756718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e299070756718 : Closed e299070756718 ∧ code e299070756718 = 1398582384494 := by decide
theorem cert_e299070756718 : check e299070756718 [[],[.left]] .chain = true := by decide
def e299070756726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e299070756726 : Closed e299070756726 ∧ code e299070756726 = 1398582384502 := by decide
theorem cert_e299070756726 : check e299070756726 [[],[.left]] .chain = true := by decide
def e299070756790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e299070756790 : Closed e299070756790 ∧ code e299070756790 = 1398582384566 := by decide
theorem cert_e299070756790 : check e299070756790 [[],[.left]] .chain = true := by decide
def e299070758126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e299070758126 : Closed e299070758126 ∧ code e299070758126 = 1398582385902 := by decide
theorem cert_e299070758126 : check e299070758126 [[],[.left]] .chain = true := by decide
def e299070758134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e299070758134 : Closed e299070758134 ∧ code e299070758134 = 1398582385910 := by decide
theorem cert_e299070758134 : check e299070758134 [[],[.left]] .chain = true := by decide
def e299070758518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e299070758518 : Closed e299070758518 ∧ code e299070758518 = 1398582386294 := by decide
theorem cert_e299070758518 : check e299070758518 [[],[.left]] .chain = true := by decide
def e299070770030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e299070770030 : Closed e299070770030 ∧ code e299070770030 = 1398582397806 := by decide
theorem cert_e299070770030 : check e299070770030 [[],[.left]] .chain = true := by decide
def e299070770038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e299070770038 : Closed e299070770038 ∧ code e299070770038 = 1398582397814 := by decide
theorem cert_e299070770038 : check e299070770038 [[],[.left]] .chain = true := by decide
def e299070770094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e299070770094 : Closed e299070770094 ∧ code e299070770094 = 1398582397870 := by decide
theorem cert_e299070770094 : check e299070770094 [[],[.left]] .chain = true := by decide
def e299070770106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e299070770106 : Closed e299070770106 ∧ code e299070770106 = 1398582397882 := by decide
theorem cert_e299070770106 : check e299070770106 [[],[.left]] .chain = true := by decide
def e299070770134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e299070770134 : Closed e299070770134 ∧ code e299070770134 = 1398582397910 := by decide
theorem cert_e299070770134 : check e299070770134 [[],[.left]] .chain = true := by decide
def e299070770138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e299070770138 : Closed e299070770138 ∧ code e299070770138 = 1398582397914 := by decide
theorem cert_e299070770138 : check e299070770138 [[],[.left]] .chain = true := by decide
def e299070770414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e299070770414 : Closed e299070770414 ∧ code e299070770414 = 1398582398190 := by decide
theorem cert_e299070770414 : check e299070770414 [[],[.left]] .chain = true := by decide
def e299070770422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e299070770422 : Closed e299070770422 ∧ code e299070770422 = 1398582398198 := by decide
theorem cert_e299070770422 : check e299070770422 [[],[.left]] .chain = true := by decide
def e299070770798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e299070770798 : Closed e299070770798 ∧ code e299070770798 = 1398582398574 := by decide
theorem cert_e299070770798 : check e299070770798 [[],[.left]] .chain = true := by decide
def e299070770810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e299070770810 : Closed e299070770810 ∧ code e299070770810 = 1398582398586 := by decide
theorem cert_e299070770810 : check e299070770810 [[],[.left]] .chain = true := by decide
def e299070770998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e299070770998 : Closed e299070770998 ∧ code e299070770998 = 1398582398774 := by decide
theorem cert_e299070770998 : check e299070770998 [[],[.left]] .chain = true := by decide
def e299070771002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e299070771002 : Closed e299070771002 ∧ code e299070771002 = 1398582398778 := by decide
theorem cert_e299070771002 : check e299070771002 [[],[.left]] .chain = true := by decide
def e299070776758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e299070776758 : Closed e299070776758 ∧ code e299070776758 = 1398582404534 := by decide
theorem cert_e299070776758 : check e299070776758 [[],[.left]] .chain = true := by decide
def e299070776790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e299070776790 : Closed e299070776790 ∧ code e299070776790 = 1398582404566 := by decide
theorem cert_e299070776790 : check e299070776790 [[],[.left]] .chain = true := by decide
def e299070776794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e299070776794 : Closed e299070776794 ∧ code e299070776794 = 1398582404570 := by decide
theorem cert_e299070776794 : check e299070776794 [[],[.left]] .chain = true := by decide
def e299070776950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e299070776950 : Closed e299070776950 ∧ code e299070776950 = 1398582404726 := by decide
theorem cert_e299070776950 : check e299070776950 [[],[.left]] .chain = true := by decide
def e299070777142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e299070777142 : Closed e299070777142 ∧ code e299070777142 = 1398582404918 := by decide
theorem cert_e299070777142 : check e299070777142 [[],[.left]] .chain = true := by decide
def e299070777146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e299070777146 : Closed e299070777146 ∧ code e299070777146 = 1398582404922 := by decide
theorem cert_e299070777146 : check e299070777146 [[],[.left]] .chain = true := by decide
def e299071114094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e299071114094 : Closed e299071114094 ∧ code e299071114094 = 1398582741870 := by decide
theorem cert_e299071114094 : check e299071114094 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e299071114102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e299071114102 : Closed e299071114102 ∧ code e299071114102 = 1398582741878 := by decide
private def t_e299071114102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e299071114102 : ¬ IsSelfInterpreter e299071114102 :=
  wSource (t := t_e299071114102) (replay_sound (ps := []) (t := e299071114102) (by decide)) (by decide)
def e299071114158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e299071114158 : Closed e299071114158 ∧ code e299071114158 = 1398582741934 := by decide
theorem cert_e299071114158 : check e299071114158 [[],[.left],[],[],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e299071114170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e299071114170 : Closed e299071114170 ∧ code e299071114170 = 1398582741946 := by decide
theorem cert_e299071114170 : checkPay e299071114170 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[]] 0 [[.under,.left],[.under]] = true := by decide
def e299071114198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e299071114198 : Closed e299071114198 ∧ code e299071114198 = 1398582741974 := by decide
private def t_e299071114198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e299071114198 : ¬ IsSelfInterpreter e299071114198 :=
  wSource (t := t_e299071114198) (replay_sound (ps := []) (t := e299071114198) (by decide)) (by decide)
def e299071114202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e299071114202 : Closed e299071114202 ∧ code e299071114202 = 1398582741978 := by decide
theorem cert_e299071114202 : check e299071114202 [[],[.left],[],[],[.under],[.under,.left]] .chain = true := by decide
def e299071114478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e299071114478 : Closed e299071114478 ∧ code e299071114478 = 1398582742254 := by decide
theorem cert_e299071114478 : checkPay e299071114478 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left],[]] 0 [[.under,.right]] = true := by decide
def e299071114486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e299071114486 : Closed e299071114486 ∧ code e299071114486 = 1398582742262 := by decide
theorem cert_e299071114486 : check e299071114486 [[],[.left],[],[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e299071114862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e299071114862 : Closed e299071114862 ∧ code e299071114862 = 1398582742638 := by decide
theorem cert_e299071114862 : check e299071114862 [[],[.left],[],[],[.under],[.under],[.under]] .sourceHead = true := by decide
def e299071114874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e299071114874 : Closed e299071114874 ∧ code e299071114874 = 1398582742650 := by decide
theorem cert_e299071114874 : check e299071114874 [[],[.left],[],[],[.under],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e299071115062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e299071115062 : Closed e299071115062 ∧ code e299071115062 = 1398582742838 := by decide
theorem cert_e299071115062 : check e299071115062 [[],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e299071115066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e299071115066 : Closed e299071115066 ∧ code e299071115066 = 1398582742842 := by decide
theorem cert_e299071115066 : check e299071115066 [[],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e299087474030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e299087474030 : Closed e299087474030 ∧ code e299087474030 = 1398599101806 := by decide
theorem cert_e299087474030 : check e299087474030 [[],[.left],[]] .sourceHead = true := by decide
def e299087474038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e299087474038 : Closed e299087474038 ∧ code e299087474038 = 1398599101814 := by decide
theorem cert_e299087474038 : check e299087474038 [[],[.left],[]] .sourceHead = true := by decide
def e299087474094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e299087474094 : Closed e299087474094 ∧ code e299087474094 = 1398599101870 := by decide
theorem cert_e299087474094 : check e299087474094 [[],[.left],[]] .sourceHead = true := by decide
def e299087474106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e299087474106 : Closed e299087474106 ∧ code e299087474106 = 1398599101882 := by decide
theorem cert_e299087474106 : check e299087474106 [[],[.left],[]] .sourceHead = true := by decide
def e299087474134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e299087474134 : Closed e299087474134 ∧ code e299087474134 = 1398599101910 := by decide
theorem cert_e299087474134 : check e299087474134 [[],[.left],[]] .sourceHead = true := by decide
def e299087474138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e299087474138 : Closed e299087474138 ∧ code e299087474138 = 1398599101914 := by decide
theorem cert_e299087474138 : check e299087474138 [[],[.left],[]] .sourceHead = true := by decide
def e299087474350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e299087474350 : Closed e299087474350 ∧ code e299087474350 = 1398599102126 := by decide
theorem cert_e299087474350 : check e299087474350 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .chain = true := by decide
def e299087474362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e299087474362 : Closed e299087474362 ∧ code e299087474362 = 1398599102138 := by decide
theorem cert_e299087474362 : check e299087474362 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e299087474410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e299087474410 : Closed e299087474410 ∧ code e299087474410 = 1398599102186 := by decide
theorem cert_e299087474410 : check e299087474410 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e299087474518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e299087474518 : Closed e299087474518 ∧ code e299087474518 = 1398599102294 := by decide
theorem cert_e299087474518 : check e299087474518 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e299087474522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e299087474522 : Closed e299087474522 ∧ code e299087474522 = 1398599102298 := by decide
theorem cert_e299087474522 : check e299087474522 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e299087474538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e299087474538 : Closed e299087474538 ∧ code e299087474538 = 1398599102314 := by decide
theorem cert_e299087474538 : check e299087474538 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e299087475566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e299087475566 : Closed e299087475566 ∧ code e299087475566 = 1398599103342 := by decide
theorem cert_e299087475566 : check e299087475566 [[],[.left],[]] .sourceHead = true := by decide
def e299087475574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e299087475574 : Closed e299087475574 ∧ code e299087475574 = 1398599103350 := by decide
theorem cert_e299087475574 : check e299087475574 [[],[.left],[]] .sourceHead = true := by decide
def e299087475630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e299087475630 : Closed e299087475630 ∧ code e299087475630 = 1398599103406 := by decide
theorem cert_e299087475630 : check e299087475630 [[],[.left],[]] .sourceHead = true := by decide
def e299087475642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e299087475642 : Closed e299087475642 ∧ code e299087475642 = 1398599103418 := by decide
theorem cert_e299087475642 : check e299087475642 [[],[.left],[]] .sourceHead = true := by decide
def e299087475670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e299087475670 : Closed e299087475670 ∧ code e299087475670 = 1398599103446 := by decide
theorem cert_e299087475670 : check e299087475670 [[],[.left],[]] .sourceHead = true := by decide
def e299087475674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e299087475674 : Closed e299087475674 ∧ code e299087475674 = 1398599103450 := by decide
theorem cert_e299087475674 : check e299087475674 [[],[.left],[]] .sourceHead = true := by decide
def e299087475950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e299087475950 : Closed e299087475950 ∧ code e299087475950 = 1398599103726 := by decide
theorem cert_e299087475950 : check e299087475950 [[],[.left],[]] .sourceHead = true := by decide
def e299087475958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e299087475958 : Closed e299087475958 ∧ code e299087475958 = 1398599103734 := by decide
theorem cert_e299087475958 : check e299087475958 [[],[.left],[]] .sourceHead = true := by decide
def e299087476334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e299087476334 : Closed e299087476334 ∧ code e299087476334 = 1398599104110 := by decide
theorem cert_e299087476334 : check e299087476334 [[],[.left],[]] .sourceHead = true := by decide
def e299087476346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e299087476346 : Closed e299087476346 ∧ code e299087476346 = 1398599104122 := by decide
theorem cert_e299087476346 : check e299087476346 [[],[.left],[]] .sourceHead = true := by decide
def e299087476534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e299087476534 : Closed e299087476534 ∧ code e299087476534 = 1398599104310 := by decide
theorem cert_e299087476534 : check e299087476534 [[],[.left],[]] .sourceHead = true := by decide
def e299087476538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e299087476538 : Closed e299087476538 ∧ code e299087476538 = 1398599104314 := by decide
theorem cert_e299087476538 : check e299087476538 [[],[.left],[]] .sourceHead = true := by decide
def e299087477166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e299087477166 : Closed e299087477166 ∧ code e299087477166 = 1398599104942 := by decide
theorem cert_e299087477166 : check e299087477166 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e299087477178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e299087477178 : Closed e299087477178 ∧ code e299087477178 = 1398599104954 := by decide
theorem cert_e299087477178 : check e299087477178 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e299087477226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e299087477226 : Closed e299087477226 ∧ code e299087477226 = 1398599105002 := by decide
theorem cert_e299087477226 : check e299087477226 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e299087477358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e299087477358 : Closed e299087477358 ∧ code e299087477358 = 1398599105134 := by decide
theorem cert_e299087477358 : check e299087477358 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e299087477370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e299087477370 : Closed e299087477370 ∧ code e299087477370 = 1398599105146 := by decide
theorem cert_e299087477370 : check e299087477370 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e299087477658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e299087477658 : Closed e299087477658 ∧ code e299087477658 = 1398599105434 := by decide
theorem cert_e299087477658 : check e299087477658 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e299087477974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e299087477974 : Closed e299087477974 ∧ code e299087477974 = 1398599105750 := by decide
theorem cert_e299087477974 : check e299087477974 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299087477978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e299087477978 : Closed e299087477978 ∧ code e299087477978 = 1398599105754 := by decide
theorem cert_e299087477978 : check e299087477978 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299087477994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e299087477994 : Closed e299087477994 ∧ code e299087477994 = 1398599105770 := by decide
theorem cert_e299087477994 : check e299087477994 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299087478070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e299087478070 : Closed e299087478070 ∧ code e299087478070 = 1398599105846 := by decide
theorem cert_e299087478070 : check e299087478070 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299087478074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e299087478074 : Closed e299087478074 ∧ code e299087478074 = 1398599105850 := by decide
theorem cert_e299087478074 : check e299087478074 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299087478170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e299087478170 : Closed e299087478170 ∧ code e299087478170 = 1398599105946 := by decide
theorem cert_e299087478170 : check e299087478170 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299087481710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e299087481710 : Closed e299087481710 ∧ code e299087481710 = 1398599109486 := by decide
theorem cert_e299087481710 : check e299087481710 [[],[.left],[]] .sourceHead = true := by decide
def e299087481718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e299087481718 : Closed e299087481718 ∧ code e299087481718 = 1398599109494 := by decide
theorem cert_e299087481718 : check e299087481718 [[],[.left],[]] .sourceHead = true := by decide
def e299087481774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e299087481774 : Closed e299087481774 ∧ code e299087481774 = 1398599109550 := by decide
theorem cert_e299087481774 : check e299087481774 [[],[.left],[]] .sourceHead = true := by decide
def e299087481786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e299087481786 : Closed e299087481786 ∧ code e299087481786 = 1398599109562 := by decide
theorem cert_e299087481786 : check e299087481786 [[],[.left],[]] .sourceHead = true := by decide
def e299087481814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e299087481814 : Closed e299087481814 ∧ code e299087481814 = 1398599109590 := by decide
theorem cert_e299087481814 : check e299087481814 [[],[.left],[]] .sourceHead = true := by decide
def e299087481818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e299087481818 : Closed e299087481818 ∧ code e299087481818 = 1398599109594 := by decide
theorem cert_e299087481818 : check e299087481818 [[],[.left],[]] .sourceHead = true := by decide
def e299087482094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e299087482094 : Closed e299087482094 ∧ code e299087482094 = 1398599109870 := by decide
theorem cert_e299087482094 : check e299087482094 [[],[.left],[]] .sourceHead = true := by decide
def e299087482102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e299087482102 : Closed e299087482102 ∧ code e299087482102 = 1398599109878 := by decide
theorem cert_e299087482102 : check e299087482102 [[],[.left],[]] .sourceHead = true := by decide
def e299087482478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e299087482478 : Closed e299087482478 ∧ code e299087482478 = 1398599110254 := by decide
theorem cert_e299087482478 : check e299087482478 [[],[.left],[]] .sourceHead = true := by decide
def e299087482490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e299087482490 : Closed e299087482490 ∧ code e299087482490 = 1398599110266 := by decide
theorem cert_e299087482490 : check e299087482490 [[],[.left],[]] .sourceHead = true := by decide
def e299087482678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e299087482678 : Closed e299087482678 ∧ code e299087482678 = 1398599110454 := by decide
theorem cert_e299087482678 : check e299087482678 [[],[.left],[]] .sourceHead = true := by decide
def e299087482682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e299087482682 : Closed e299087482682 ∧ code e299087482682 = 1398599110458 := by decide
theorem cert_e299087482682 : check e299087482682 [[],[.left],[]] .sourceHead = true := by decide
def e299087488430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e299087488430 : Closed e299087488430 ∧ code e299087488430 = 1398599116206 := by decide
theorem cert_e299087488430 : check e299087488430 [[],[.left],[],[.under]] .smaller = true := by decide
def e299087488442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e299087488442 : Closed e299087488442 ∧ code e299087488442 = 1398599116218 := by decide
theorem cert_e299087488442 : check e299087488442 [[],[.left],[],[.under]] .smaller = true := by decide
def e299087488490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e299087488490 : Closed e299087488490 ∧ code e299087488490 = 1398599116266 := by decide
theorem cert_e299087488490 : check e299087488490 [[],[.left],[],[.under]] .smaller = true := by decide
def e299087488622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e299087488622 : Closed e299087488622 ∧ code e299087488622 = 1398599116398 := by decide
theorem cert_e299087488622 : check e299087488622 [[],[.left],[],[.under]] .smaller = true := by decide
def e299087488634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e299087488634 : Closed e299087488634 ∧ code e299087488634 = 1398599116410 := by decide
theorem cert_e299087488634 : check e299087488634 [[],[.left],[],[.under]] .smaller = true := by decide
def e299087488922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e299087488922 : Closed e299087488922 ∧ code e299087488922 = 1398599116698 := by decide
theorem cert_e299087488922 : check e299087488922 [[],[.left],[],[.under]] .smaller = true := by decide
def e299087491798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e299087491798 : Closed e299087491798 ∧ code e299087491798 = 1398599119574 := by decide
theorem cert_e299087491798 : check e299087491798 [[],[.left],[],[.under]] .three = true := by decide
def e299087491802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e299087491802 : Closed e299087491802 ∧ code e299087491802 = 1398599119578 := by decide
theorem cert_e299087491802 : check e299087491802 [[],[.left],[],[.under]] .three = true := by decide
def e299087491818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e299087491818 : Closed e299087491818 ∧ code e299087491818 = 1398599119594 := by decide
theorem cert_e299087491818 : check e299087491818 [[],[.left],[],[.under]] .three = true := by decide
def e299087491894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e299087491894 : Closed e299087491894 ∧ code e299087491894 = 1398599119670 := by decide
theorem cert_e299087491894 : check e299087491894 [[],[.left],[],[.under]] .three = true := by decide
def e299087491898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e299087491898 : Closed e299087491898 ∧ code e299087491898 = 1398599119674 := by decide
theorem cert_e299087491898 : check e299087491898 [[],[.left],[],[.under]] .three = true := by decide
def e299087491994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e299087491994 : Closed e299087491994 ∧ code e299087491994 = 1398599119770 := by decide
theorem cert_e299087491994 : check e299087491994 [[],[.left],[],[.under]] .three = true := by decide
def e299087629166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e299087629166 : Closed e299087629166 ∧ code e299087629166 = 1398599256942 := by decide
theorem cert_e299087629166 : check e299087629166 [[],[.left],[],[]] .smaller = true := by decide
def e299087629174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e299087629174 : Closed e299087629174 ∧ code e299087629174 = 1398599256950 := by decide
theorem cert_e299087629174 : check e299087629174 [[],[.left],[],[]] .smaller = true := by decide
def e299087629230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e299087629230 : Closed e299087629230 ∧ code e299087629230 = 1398599257006 := by decide
theorem cert_e299087629230 : check e299087629230 [[],[.left],[],[]] .smaller = true := by decide
def e299087629242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e299087629242 : Closed e299087629242 ∧ code e299087629242 = 1398599257018 := by decide
theorem cert_e299087629242 : check e299087629242 [[],[.left],[],[]] .smaller = true := by decide
def e299087629270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e299087629270 : Closed e299087629270 ∧ code e299087629270 = 1398599257046 := by decide
theorem cert_e299087629270 : check e299087629270 [[],[.left],[],[]] .smaller = true := by decide
def e299087629274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e299087629274 : Closed e299087629274 ∧ code e299087629274 = 1398599257050 := by decide
theorem cert_e299087629274 : check e299087629274 [[],[.left],[],[]] .smaller = true := by decide
def e299087629550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e299087629550 : Closed e299087629550 ∧ code e299087629550 = 1398599257326 := by decide
theorem cert_e299087629550 : check e299087629550 [[],[.left],[],[]] .smaller = true := by decide
def e299087629558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e299087629558 : Closed e299087629558 ∧ code e299087629558 = 1398599257334 := by decide
theorem cert_e299087629558 : check e299087629558 [[],[.left],[],[]] .smaller = true := by decide
def e299087629934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e299087629934 : Closed e299087629934 ∧ code e299087629934 = 1398599257710 := by decide
theorem cert_e299087629934 : check e299087629934 [[],[.left],[],[]] .smaller = true := by decide
def e299087629946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e299087629946 : Closed e299087629946 ∧ code e299087629946 = 1398599257722 := by decide
theorem cert_e299087629946 : check e299087629946 [[],[.left],[],[]] .smaller = true := by decide
def e299087630134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e299087630134 : Closed e299087630134 ∧ code e299087630134 = 1398599257910 := by decide
theorem cert_e299087630134 : check e299087630134 [[],[.left],[],[]] .smaller = true := by decide
def e299087630138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e299087630138 : Closed e299087630138 ∧ code e299087630138 = 1398599257914 := by decide
theorem cert_e299087630138 : check e299087630138 [[],[.left],[],[]] .smaller = true := by decide
def e299088218990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e299088218990 : Closed e299088218990 ∧ code e299088218990 = 1398599846766 := by decide
theorem cert_e299088218990 : check e299088218990 [[],[.left],[.left],[.left],[],[.left],[],[],[]] .sourceHead = true := by decide
def e299088218998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e299088218998 : Closed e299088218998 ∧ code e299088218998 = 1398599846774 := by decide
theorem cert_e299088218998 : check e299088218998 [[],[.left],[.left],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e299088219054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e299088219054 : Closed e299088219054 ∧ code e299088219054 = 1398599846830 := by decide
theorem cert_e299088219054 : check e299088219054 [[],[.left],[.left],[.left],[],[.left],[],[.left],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e299088219066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e299088219066 : Closed e299088219066 ∧ code e299088219066 = 1398599846842 := by decide
private def t_e299088219066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e299088219066 : ¬ IsSelfInterpreter e299088219066 :=
  wSource (t := t_e299088219066) (replay_sound (ps := []) (t := e299088219066) (by decide)) (by decide)
def e299088219094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e299088219094 : Closed e299088219094 ∧ code e299088219094 = 1398599846870 := by decide
theorem cert_e299088219094 : check e299088219094 [[],[.left],[.left],[.left],[],[.left],[.left],[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e299088219098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e299088219098 : Closed e299088219098 ∧ code e299088219098 = 1398599846874 := by decide
private def t_e299088219098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e299088219098 : ¬ IsSelfInterpreter e299088219098 :=
  wSource (t := t_e299088219098) (replay_sound (ps := []) (t := e299088219098) (by decide)) (by decide)
def e299088219374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e299088219374 : Closed e299088219374 ∧ code e299088219374 = 1398599847150 := by decide
theorem cert_e299088219374 : check e299088219374 [[],[.left],[.left],[.left],[],[]] .smaller = true := by decide
def e299088219382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e299088219382 : Closed e299088219382 ∧ code e299088219382 = 1398599847158 := by decide
theorem cert_e299088219382 : check e299088219382 [[],[.left],[.left],[.left],[],[]] .smaller = true := by decide
def e299088219758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e299088219758 : Closed e299088219758 ∧ code e299088219758 = 1398599847534 := by decide
theorem cert_e299088219758 : check e299088219758 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e299088219770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e299088219770 : Closed e299088219770 ∧ code e299088219770 = 1398599847546 := by decide
theorem cert_e299088219770 : check e299088219770 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e299088219958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e299088219958 : Closed e299088219958 ∧ code e299088219958 = 1398599847734 := by decide
theorem cert_e299088219958 : check e299088219958 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e299088219962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e299088219962 : Closed e299088219962 ∧ code e299088219962 = 1398599847738 := by decide
theorem cert_e299088219962 : check e299088219962 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e299171404510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e299171404510 : Closed e299171404510 ∧ code e299171404510 = 1398683032286 := by decide
theorem cert_e299171404510 : check e299171404510 [[],[.left],[]] .chain = true := by decide
def e299171404534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e299171404534 : Closed e299171404534 ∧ code e299171404534 = 1398683032310 := by decide
theorem cert_e299171404534 : check e299171404534 [[],[.left],[]] .chain = true := by decide
def e299171404638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e299171404638 : Closed e299171404638 ∧ code e299171404638 = 1398683032414 := by decide
theorem cert_e299171404638 : check e299171404638 [[],[.left],[]] .chain = true := by decide
def e299171404654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e299171404654 : Closed e299171404654 ∧ code e299171404654 = 1398683032430 := by decide
theorem cert_e299171404654 : check e299171404654 [[],[.left],[]] .chain = true := by decide
def e299171404662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e299171404662 : Closed e299171404662 ∧ code e299171404662 = 1398683032438 := by decide
theorem cert_e299171404662 : check e299171404662 [[],[.left],[]] .chain = true := by decide
def e299171404666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e299171404666 : Closed e299171404666 ∧ code e299171404666 = 1398683032442 := by decide
theorem cert_e299171404666 : check e299171404666 [[],[.left],[]] .chain = true := by decide
def e299171404726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e299171404726 : Closed e299171404726 ∧ code e299171404726 = 1398683032502 := by decide
theorem cert_e299171404726 : check e299171404726 [[],[.left],[]] .chain = true := by decide
def e299171404758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e299171404758 : Closed e299171404758 ∧ code e299171404758 = 1398683032534 := by decide
theorem cert_e299171404758 : check e299171404758 [[],[.left],[]] .chain = true := by decide
def e299171404762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e299171404762 : Closed e299171404762 ∧ code e299171404762 = 1398683032538 := by decide
theorem cert_e299171404762 : check e299171404762 [[],[.left],[]] .chain = true := by decide
def e299171405150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e299171405150 : Closed e299171405150 ∧ code e299171405150 = 1398683032926 := by decide
theorem cert_e299171405150 : check e299171405150 [[],[.left],[]] .chain = true := by decide
def e299171405166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e299171405166 : Closed e299171405166 ∧ code e299171405166 = 1398683032942 := by decide
theorem cert_e299171405166 : check e299171405166 [[],[.left],[]] .chain = true := by decide
def e299171405174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e299171405174 : Closed e299171405174 ∧ code e299171405174 = 1398683032950 := by decide
theorem cert_e299171405174 : check e299171405174 [[],[.left],[]] .chain = true := by decide
def e299171405178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e299171405178 : Closed e299171405178 ∧ code e299171405178 = 1398683032954 := by decide
theorem cert_e299171405178 : check e299171405178 [[],[.left],[]] .chain = true := by decide
def e299171405230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e299171405230 : Closed e299171405230 ∧ code e299171405230 = 1398683033006 := by decide
theorem cert_e299171405230 : check e299171405230 [[],[.left],[]] .chain = true := by decide
def e299171405242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e299171405242 : Closed e299171405242 ∧ code e299171405242 = 1398683033018 := by decide
theorem cert_e299171405242 : check e299171405242 [[],[.left],[]] .chain = true := by decide
def e299171405270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e299171405270 : Closed e299171405270 ∧ code e299171405270 = 1398683033046 := by decide
theorem cert_e299171405270 : check e299171405270 [[],[.left],[]] .chain = true := by decide
def e299171405274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e299171405274 : Closed e299171405274 ∧ code e299171405274 = 1398683033050 := by decide
theorem cert_e299171405274 : check e299171405274 [[],[.left],[]] .chain = true := by decide
def e299171405290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e299171405290 : Closed e299171405290 ∧ code e299171405290 = 1398683033066 := by decide
theorem cert_e299171405290 : check e299171405290 [[],[.left],[]] .chain = true := by decide
def e299171405494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e299171405494 : Closed e299171405494 ∧ code e299171405494 = 1398683033270 := by decide
theorem cert_e299171405494 : check e299171405494 [[],[.left],[]] .chain = true := by decide
def e299171405526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e299171405526 : Closed e299171405526 ∧ code e299171405526 = 1398683033302 := by decide
theorem cert_e299171405526 : check e299171405526 [[],[.left],[]] .chain = true := by decide
def e299171405530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e299171405530 : Closed e299171405530 ∧ code e299171405530 = 1398683033306 := by decide
theorem cert_e299171405530 : check e299171405530 [[],[.left],[]] .chain = true := by decide
def e299171405654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e299171405654 : Closed e299171405654 ∧ code e299171405654 = 1398683033430 := by decide
theorem cert_e299171405654 : check e299171405654 [[],[.left],[]] .chain = true := by decide
def e299171405658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e299171405658 : Closed e299171405658 ∧ code e299171405658 = 1398683033434 := by decide
theorem cert_e299171405658 : check e299171405658 [[],[.left],[]] .chain = true := by decide
def e299171405674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e299171405674 : Closed e299171405674 ∧ code e299171405674 = 1398683033450 := by decide
theorem cert_e299171405674 : check e299171405674 [[],[.left],[]] .chain = true := by decide
def e299171407582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e299171407582 : Closed e299171407582 ∧ code e299171407582 = 1398683035358 := by decide
theorem cert_e299171407582 : check e299171407582 [[],[.left],[]] .chain = true := by decide
def e299171407606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e299171407606 : Closed e299171407606 ∧ code e299171407606 = 1398683035382 := by decide
theorem cert_e299171407606 : check e299171407606 [[],[.left],[]] .chain = true := by decide
def e299171407710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e299171407710 : Closed e299171407710 ∧ code e299171407710 = 1398683035486 := by decide
theorem cert_e299171407710 : check e299171407710 [[],[.left],[]] .chain = true := by decide
def e299171407726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e299171407726 : Closed e299171407726 ∧ code e299171407726 = 1398683035502 := by decide
theorem cert_e299171407726 : check e299171407726 [[],[.left],[]] .chain = true := by decide
def e299171407734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e299171407734 : Closed e299171407734 ∧ code e299171407734 = 1398683035510 := by decide
theorem cert_e299171407734 : check e299171407734 [[],[.left],[]] .chain = true := by decide
def e299171407738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e299171407738 : Closed e299171407738 ∧ code e299171407738 = 1398683035514 := by decide
theorem cert_e299171407738 : check e299171407738 [[],[.left],[]] .chain = true := by decide
def e299171407798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e299171407798 : Closed e299171407798 ∧ code e299171407798 = 1398683035574 := by decide
theorem cert_e299171407798 : check e299171407798 [[],[.left],[]] .chain = true := by decide
def e299171407830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e299171407830 : Closed e299171407830 ∧ code e299171407830 = 1398683035606 := by decide
theorem cert_e299171407830 : check e299171407830 [[],[.left],[]] .chain = true := by decide
end Blc.Floor40
