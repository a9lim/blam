from probe_demand import *
from smart_probe import weak_path
for s in open('projection-rem.txt').read().split():
    e=lc.decode(s)[0];r=None
    for src in [I,L(I),L(L(V(1))),A(I,I)]:
        t=A(A(e,KI),lc.bitlist(lc.enc(src),V(0)))
        for j in range(20):
            if j in (0,1,2,3,5,8,13,19):
                for k in [0,1,2,3]:
                    z=analyze(t,k,1500)
                    if z is not None and (-1,()) not in z[0]:
                        r=(lc.enc(src),j,k,len(z[1]));break
            if r:break
            p=weak_path(t)
            if p is None:break
            t=bounded(t,p)
            if t is None:break
        if r:break
    print(s,r,flush=True)
