import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302802586586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302802586586 : Closed e302802586586 ∧ code e302802586586 = 1402314214362 := by decide
theorem cert_e302802586586 : check e302802586586 [[],[]] .smaller = true := by decide
def e302802586862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302802586862 : Closed e302802586862 ∧ code e302802586862 = 1402314214638 := by decide
theorem cert_e302802586862 : check e302802586862 [[],[]] .smaller = true := by decide
def e302802586870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302802586870 : Closed e302802586870 ∧ code e302802586870 = 1402314214646 := by decide
theorem cert_e302802586870 : check e302802586870 [[],[]] .smaller = true := by decide
def e302802587246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302802587246 : Closed e302802587246 ∧ code e302802587246 = 1402314215022 := by decide
theorem cert_e302802587246 : check e302802587246 [[],[]] .smaller = true := by decide
def e302802587258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302802587258 : Closed e302802587258 ∧ code e302802587258 = 1402314215034 := by decide
theorem cert_e302802587258 : check e302802587258 [[],[]] .smaller = true := by decide
def e302802587446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302802587446 : Closed e302802587446 ∧ code e302802587446 = 1402314215222 := by decide
theorem cert_e302802587446 : check e302802587446 [[],[]] .smaller = true := by decide
def e302802587450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302802587450 : Closed e302802587450 ∧ code e302802587450 = 1402314215226 := by decide
theorem cert_e302802587450 : check e302802587450 [[],[]] .smaller = true := by decide
def e302802592222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e302802592222 : Closed e302802592222 ∧ code e302802592222 = 1402314219998 := by decide
theorem cert_e302802592222 : check e302802592222 [[],[]] .smaller = true := by decide
def e302802592246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e302802592246 : Closed e302802592246 ∧ code e302802592246 = 1402314220022 := by decide
theorem cert_e302802592246 : check e302802592246 [[],[]] .smaller = true := by decide
def e302802593198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e302802593198 : Closed e302802593198 ∧ code e302802593198 = 1402314220974 := by decide
theorem cert_e302802593198 : check e302802593198 [[],[]] .smaller = true := by decide
def e302802593210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e302802593210 : Closed e302802593210 ∧ code e302802593210 = 1402314220986 := by decide
theorem cert_e302802593210 : check e302802593210 [[],[]] .smaller = true := by decide
def e302802593258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e302802593258 : Closed e302802593258 ∧ code e302802593258 = 1402314221034 := by decide
theorem cert_e302802593258 : check e302802593258 [[],[]] .smaller = true := by decide
def e302802593390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e302802593390 : Closed e302802593390 ∧ code e302802593390 = 1402314221166 := by decide
theorem cert_e302802593390 : check e302802593390 [[],[]] .smaller = true := by decide
def e302802593402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e302802593402 : Closed e302802593402 ∧ code e302802593402 = 1402314221178 := by decide
theorem cert_e302802593402 : check e302802593402 [[],[]] .smaller = true := by decide
def e302802593690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e302802593690 : Closed e302802593690 ∧ code e302802593690 = 1402314221466 := by decide
theorem cert_e302802593690 : check e302802593690 [[],[]] .smaller = true := by decide
def e302802593758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 3)))))))))
theorem wire_e302802593758 : Closed e302802593758 ∧ code e302802593758 = 1402314221534 := by decide
theorem cert_e302802593758 : check e302802593758 [[],[]] .sourceHead = true := by decide
def e302802596078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e302802596078 : Closed e302802596078 ∧ code e302802596078 = 1402314223854 := by decide
theorem cert_e302802596078 : check e302802596078 [[],[]] .smaller = true := by decide
def e302802596086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e302802596086 : Closed e302802596086 ∧ code e302802596086 = 1402314223862 := by decide
theorem cert_e302802596086 : check e302802596086 [[],[]] .smaller = true := by decide
def e302802596566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302802596566 : Closed e302802596566 ∧ code e302802596566 = 1402314224342 := by decide
theorem cert_e302802596566 : check e302802596566 [[],[]] .smaller = true := by decide
def e302802596570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302802596570 : Closed e302802596570 ∧ code e302802596570 = 1402314224346 := by decide
theorem cert_e302802596570 : check e302802596570 [[],[]] .smaller = true := by decide
def e302802596586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302802596586 : Closed e302802596586 ∧ code e302802596586 = 1402314224362 := by decide
theorem cert_e302802596586 : check e302802596586 [[],[]] .smaller = true := by decide
def e302802596662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302802596662 : Closed e302802596662 ∧ code e302802596662 = 1402314224438 := by decide
theorem cert_e302802596662 : check e302802596662 [[],[]] .smaller = true := by decide
def e302802596666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302802596666 : Closed e302802596666 ∧ code e302802596666 = 1402314224442 := by decide
theorem cert_e302802596666 : check e302802596666 [[],[]] .smaller = true := by decide
def e302802596762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302802596762 : Closed e302802596762 ∧ code e302802596762 = 1402314224538 := by decide
theorem cert_e302802596762 : check e302802596762 [[],[]] .smaller = true := by decide
def e302802598366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 3)))))))))
theorem wire_e302802598366 : Closed e302802598366 ∧ code e302802598366 = 1402314226142 := by decide
theorem cert_e302802598366 : check e302802598366 [[],[]] .sourceHead = true := by decide
def e302802598390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 3) (.var 1)))))))))
theorem wire_e302802598390 : Closed e302802598390 ∧ code e302802598390 = 1402314226166 := by decide
theorem cert_e302802598390 : check e302802598390 [[],[]] .sourceHead = true := by decide
def e302802710894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e302802710894 : Closed e302802710894 ∧ code e302802710894 = 1402314338670 := by decide
theorem cert_e302802710894 : check e302802710894 [[],[]] .chain = true := by decide
def e302802710902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e302802710902 : Closed e302802710902 ∧ code e302802710902 = 1402314338678 := by decide
theorem cert_e302802710902 : check e302802710902 [[],[]] .chain = true := by decide
def e302802710958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e302802710958 : Closed e302802710958 ∧ code e302802710958 = 1402314338734 := by decide
theorem cert_e302802710958 : check e302802710958 [[],[]] .chain = true := by decide
def e302802710970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e302802710970 : Closed e302802710970 ∧ code e302802710970 = 1402314338746 := by decide
theorem cert_e302802710970 : check e302802710970 [[],[]] .chain = true := by decide
def e302802711018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e302802711018 : Closed e302802711018 ∧ code e302802711018 = 1402314338794 := by decide
theorem cert_e302802711018 : check e302802711018 [[],[]] .chain = true := by decide
def e302802711662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302802711662 : Closed e302802711662 ∧ code e302802711662 = 1402314339438 := by decide
theorem cert_e302802711662 : check e302802711662 [[],[]] .chain = true := by decide
def e302802711674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302802711674 : Closed e302802711674 ∧ code e302802711674 = 1402314339450 := by decide
theorem cert_e302802711674 : check e302802711674 [[],[]] .chain = true := by decide
def e302802711838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302802711838 : Closed e302802711838 ∧ code e302802711838 = 1402314339614 := by decide
theorem cert_e302802711838 : check e302802711838 [[],[]] .chain = true := by decide
def e302802712006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302802712006 : Closed e302802712006 ∧ code e302802712006 = 1402314339782 := by decide
theorem cert_e302802712006 : check e302802712006 [[],[]] .chain = true := by decide
def e302802712110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e302802712110 : Closed e302802712110 ∧ code e302802712110 = 1402314339886 := by decide
theorem cert_e302802712110 : check e302802712110 [[],[]] .chain = true := by decide
def e302802712290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e302802712290 : Closed e302802712290 ∧ code e302802712290 = 1402314340066 := by decide
theorem cert_e302802712290 : check e302802712290 [[],[]] .chain = true := by decide
def e302802712302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e302802712302 : Closed e302802712302 ∧ code e302802712302 = 1402314340078 := by decide
theorem cert_e302802712302 : check e302802712302 [[],[]] .sourceHead = true := by decide
def e302802712342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302802712342 : Closed e302802712342 ∧ code e302802712342 = 1402314340118 := by decide
theorem cert_e302802712342 : check e302802712342 [[],[]] .chain = true := by decide
def e302802712346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302802712346 : Closed e302802712346 ∧ code e302802712346 = 1402314340122 := by decide
theorem cert_e302802712346 : check e302802712346 [[],[]] .chain = true := by decide
def e302802712390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302802712390 : Closed e302802712390 ∧ code e302802712390 = 1402314340166 := by decide
theorem cert_e302802712390 : check e302802712390 [[],[]] .chain = true := by decide
def e302802712418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302802712418 : Closed e302802712418 ∧ code e302802712418 = 1402314340194 := by decide
theorem cert_e302802712418 : check e302802712418 [[],[]] .chain = true := by decide
def e302802712430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e302802712430 : Closed e302802712430 ∧ code e302802712430 = 1402314340206 := by decide
theorem cert_e302802712430 : check e302802712430 [[],[]] .sourceHead = true := by decide
def e302802712438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e302802712438 : Closed e302802712438 ∧ code e302802712438 = 1402314340214 := by decide
theorem cert_e302802712438 : check e302802712438 [[],[]] .sourceHead = true := by decide
def e302802712750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e302802712750 : Closed e302802712750 ∧ code e302802712750 = 1402314340526 := by decide
theorem cert_e302802712750 : check e302802712750 [[],[]] .chain = true := by decide
def e302802712762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e302802712762 : Closed e302802712762 ∧ code e302802712762 = 1402314340538 := by decide
theorem cert_e302802712762 : check e302802712762 [[],[]] .chain = true := by decide
def e302802713134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e302802713134 : Closed e302802713134 ∧ code e302802713134 = 1402314340910 := by decide
theorem cert_e302802713134 : check e302802713134 [[],[]] .chain = true := by decide
def e302802713314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e302802713314 : Closed e302802713314 ∧ code e302802713314 = 1402314341090 := by decide
theorem cert_e302802713314 : check e302802713314 [[],[]] .chain = true := by decide
def e302802713326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e302802713326 : Closed e302802713326 ∧ code e302802713326 = 1402314341102 := by decide
theorem cert_e302802713326 : check e302802713326 [[],[]] .sourceHead = true := by decide
def e302802713482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e302802713482 : Closed e302802713482 ∧ code e302802713482 = 1402314341258 := by decide
theorem cert_e302802713482 : check e302802713482 [[],[]] .chain = true := by decide
def e302802713506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e302802713506 : Closed e302802713506 ∧ code e302802713506 = 1402314341282 := by decide
theorem cert_e302802713506 : check e302802713506 [[],[]] .chain = true := by decide
def e302802713518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e302802713518 : Closed e302802713518 ∧ code e302802713518 = 1402314341294 := by decide
theorem cert_e302802713518 : check e302802713518 [[],[]] .sourceHead = true := by decide
def e302802713530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e302802713530 : Closed e302802713530 ∧ code e302802713530 = 1402314341306 := by decide
theorem cert_e302802713530 : check e302802713530 [[],[]] .sourceHead = true := by decide
def e302802713686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e302802713686 : Closed e302802713686 ∧ code e302802713686 = 1402314341462 := by decide
theorem cert_e302802713686 : check e302802713686 [[],[]] .chain = true := by decide
def e302802713690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e302802713690 : Closed e302802713690 ∧ code e302802713690 = 1402314341466 := by decide
theorem cert_e302802713690 : check e302802713690 [[],[]] .chain = true := by decide
def e302802713706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e302802713706 : Closed e302802713706 ∧ code e302802713706 = 1402314341482 := by decide
theorem cert_e302802713706 : check e302802713706 [[],[]] .chain = true := by decide
def e302802713878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302802713878 : Closed e302802713878 ∧ code e302802713878 = 1402314341654 := by decide
theorem cert_e302802713878 : check e302802713878 [[],[]] .chain = true := by decide
def e302802713882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302802713882 : Closed e302802713882 ∧ code e302802713882 = 1402314341658 := by decide
theorem cert_e302802713882 : check e302802713882 [[],[]] .chain = true := by decide
def e302802713926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302802713926 : Closed e302802713926 ∧ code e302802713926 = 1402314341702 := by decide
theorem cert_e302802713926 : check e302802713926 [[],[]] .chain = true := by decide
def e302802713954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302802713954 : Closed e302802713954 ∧ code e302802713954 = 1402314341730 := by decide
theorem cert_e302802713954 : check e302802713954 [[],[]] .chain = true := by decide
def e302802713966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e302802713966 : Closed e302802713966 ∧ code e302802713966 = 1402314341742 := by decide
theorem cert_e302802713966 : check e302802713966 [[],[]] .sourceHead = true := by decide
def e302802713974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e302802713974 : Closed e302802713974 ∧ code e302802713974 = 1402314341750 := by decide
theorem cert_e302802713974 : check e302802713974 [[],[]] .sourceHead = true := by decide
def e302802713994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e302802713994 : Closed e302802713994 ∧ code e302802713994 = 1402314341770 := by decide
theorem cert_e302802713994 : check e302802713994 [[],[]] .chain = true := by decide
def e302802714018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e302802714018 : Closed e302802714018 ∧ code e302802714018 = 1402314341794 := by decide
theorem cert_e302802714018 : check e302802714018 [[],[]] .chain = true := by decide
def e302802714030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e302802714030 : Closed e302802714030 ∧ code e302802714030 = 1402314341806 := by decide
theorem cert_e302802714030 : check e302802714030 [[],[]] .sourceHead = true := by decide
def e302802714042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e302802714042 : Closed e302802714042 ∧ code e302802714042 = 1402314341818 := by decide
theorem cert_e302802714042 : check e302802714042 [[],[]] .sourceHead = true := by decide
def e302802714070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e302802714070 : Closed e302802714070 ∧ code e302802714070 = 1402314341846 := by decide
theorem cert_e302802714070 : check e302802714070 [[],[]] .sourceHead = true := by decide
def e302802714074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e302802714074 : Closed e302802714074 ∧ code e302802714074 = 1402314341850 := by decide
theorem cert_e302802714074 : check e302802714074 [[],[]] .sourceHead = true := by decide
def e302802715118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e302802715118 : Closed e302802715118 ∧ code e302802715118 = 1402314342894 := by decide
theorem cert_e302802715118 : check e302802715118 [[],[]] .chain = true := by decide
def e302802715126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e302802715126 : Closed e302802715126 ∧ code e302802715126 = 1402314342902 := by decide
theorem cert_e302802715126 : check e302802715126 [[],[]] .chain = true := by decide
def e302802715502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e302802715502 : Closed e302802715502 ∧ code e302802715502 = 1402314343278 := by decide
theorem cert_e302802715502 : check e302802715502 [[],[]] .chain = true := by decide
def e302802715514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e302802715514 : Closed e302802715514 ∧ code e302802715514 = 1402314343290 := by decide
theorem cert_e302802715514 : check e302802715514 [[],[]] .chain = true := by decide
def e302802715566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e302802715566 : Closed e302802715566 ∧ code e302802715566 = 1402314343342 := by decide
theorem cert_e302802715566 : check e302802715566 [[],[]] .chain = true := by decide
def e302802715626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e302802715626 : Closed e302802715626 ∧ code e302802715626 = 1402314343402 := by decide
theorem cert_e302802715626 : check e302802715626 [[],[]] .chain = true := by decide
def e302802715886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e302802715886 : Closed e302802715886 ∧ code e302802715886 = 1402314343662 := by decide
theorem cert_e302802715886 : check e302802715886 [[],[]] .chain = true := by decide
def e302802715894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e302802715894 : Closed e302802715894 ∧ code e302802715894 = 1402314343670 := by decide
theorem cert_e302802715894 : check e302802715894 [[],[]] .chain = true := by decide
def e302802716270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e302802716270 : Closed e302802716270 ∧ code e302802716270 = 1402314344046 := by decide
theorem cert_e302802716270 : check e302802716270 [[],[]] .chain = true := by decide
def e302802716282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e302802716282 : Closed e302802716282 ∧ code e302802716282 = 1402314344058 := by decide
theorem cert_e302802716282 : check e302802716282 [[],[]] .chain = true := by decide
def e302802716446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e302802716446 : Closed e302802716446 ∧ code e302802716446 = 1402314344222 := by decide
theorem cert_e302802716446 : check e302802716446 [[],[]] .chain = true := by decide
def e302802716558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e302802716558 : Closed e302802716558 ∧ code e302802716558 = 1402314344334 := by decide
theorem cert_e302802716558 : check e302802716558 [[],[]] .chain = true := by decide
def e302802716570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e302802716570 : Closed e302802716570 ∧ code e302802716570 = 1402314344346 := by decide
theorem cert_e302802716570 : check e302802716570 [[],[]] .chain = true := by decide
def e302802717806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e302802717806 : Closed e302802717806 ∧ code e302802717806 = 1402314345582 := by decide
theorem cert_e302802717806 : check e302802717806 [[],[]] .chain = true := by decide
def e302802717818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302802717818 : Closed e302802717818 ∧ code e302802717818 = 1402314345594 := by decide
theorem cert_e302802717818 : check e302802717818 [[],[]] .chain = true := by decide
def e302802717982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e302802717982 : Closed e302802717982 ∧ code e302802717982 = 1402314345758 := by decide
theorem cert_e302802717982 : check e302802717982 [[],[]] .chain = true := by decide
def e302802718150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e302802718150 : Closed e302802718150 ∧ code e302802718150 = 1402314345926 := by decide
theorem cert_e302802718150 : check e302802718150 [[],[]] .chain = true := by decide
def e302802718254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e302802718254 : Closed e302802718254 ∧ code e302802718254 = 1402314346030 := by decide
theorem cert_e302802718254 : check e302802718254 [[],[]] .chain = true := by decide
def e302802718434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e302802718434 : Closed e302802718434 ∧ code e302802718434 = 1402314346210 := by decide
theorem cert_e302802718434 : check e302802718434 [[],[]] .chain = true := by decide
def e302802718446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e302802718446 : Closed e302802718446 ∧ code e302802718446 = 1402314346222 := by decide
theorem cert_e302802718446 : check e302802718446 [[],[]] .sourceHead = true := by decide
def e302802718486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e302802718486 : Closed e302802718486 ∧ code e302802718486 = 1402314346262 := by decide
theorem cert_e302802718486 : check e302802718486 [[],[]] .chain = true := by decide
def e302802718490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e302802718490 : Closed e302802718490 ∧ code e302802718490 = 1402314346266 := by decide
theorem cert_e302802718490 : check e302802718490 [[],[]] .chain = true := by decide
def e302802718534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e302802718534 : Closed e302802718534 ∧ code e302802718534 = 1402314346310 := by decide
theorem cert_e302802718534 : check e302802718534 [[],[]] .chain = true := by decide
def e302802718562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e302802718562 : Closed e302802718562 ∧ code e302802718562 = 1402314346338 := by decide
theorem cert_e302802718562 : check e302802718562 [[],[]] .chain = true := by decide
def e302802718574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e302802718574 : Closed e302802718574 ∧ code e302802718574 = 1402314346350 := by decide
theorem cert_e302802718574 : check e302802718574 [[],[]] .sourceHead = true := by decide
def e302802718582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e302802718582 : Closed e302802718582 ∧ code e302802718582 = 1402314346358 := by decide
theorem cert_e302802718582 : check e302802718582 [[],[]] .sourceHead = true := by decide
def e302802718942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e302802718942 : Closed e302802718942 ∧ code e302802718942 = 1402314346718 := by decide
theorem cert_e302802718942 : check e302802718942 [[],[]] .chain = true := by decide
def e302802718970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e302802718970 : Closed e302802718970 ∧ code e302802718970 = 1402314346746 := by decide
theorem cert_e302802718970 : check e302802718970 [[],[]] .chain = true := by decide
def e302802719518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302802719518 : Closed e302802719518 ∧ code e302802719518 = 1402314347294 := by decide
theorem cert_e302802719518 : check e302802719518 [[],[]] .chain = true := by decide
def e302802719686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302802719686 : Closed e302802719686 ∧ code e302802719686 = 1402314347462 := by decide
theorem cert_e302802719686 : check e302802719686 [[],[]] .chain = true := by decide
def e302802720830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e302802720830 : Closed e302802720830 ∧ code e302802720830 = 1402314348606 := by decide
theorem cert_e302802720830 : check e302802720830 [[],[]] .chain = true := by decide
def e302802721250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e302802721250 : Closed e302802721250 ∧ code e302802721250 = 1402314349026 := by decide
theorem cert_e302802721250 : check e302802721250 [[],[]] .chain = true := by decide
def e302802721262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e302802721262 : Closed e302802721262 ∧ code e302802721262 = 1402314349038 := by decide
theorem cert_e302802721262 : check e302802721262 [[],[]] .sourceHead = true := by decide
def e302802721822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e302802721822 : Closed e302802721822 ∧ code e302802721822 = 1402314349598 := by decide
theorem cert_e302802721822 : check e302802721822 [[],[]] .chain = true := by decide
def e302802721846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302802721846 : Closed e302802721846 ∧ code e302802721846 = 1402314349622 := by decide
theorem cert_e302802721846 : check e302802721846 [[],[]] .chain = true := by decide
def e302802721850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302802721850 : Closed e302802721850 ∧ code e302802721850 = 1402314349626 := by decide
theorem cert_e302802721850 : check e302802721850 [[],[]] .chain = true := by decide
def e302802721990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302802721990 : Closed e302802721990 ∧ code e302802721990 = 1402314349766 := by decide
theorem cert_e302802721990 : check e302802721990 [[],[]] .chain = true := by decide
def e302802722018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302802722018 : Closed e302802722018 ∧ code e302802722018 = 1402314349794 := by decide
theorem cert_e302802722018 : check e302802722018 [[],[]] .chain = true := by decide
def e302802722030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e302802722030 : Closed e302802722030 ∧ code e302802722030 = 1402314349806 := by decide
theorem cert_e302802722030 : check e302802722030 [[],[]] .sourceHead = true := by decide
def e302802722038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e302802722038 : Closed e302802722038 ∧ code e302802722038 = 1402314349814 := by decide
theorem cert_e302802722038 : check e302802722038 [[],[]] .sourceHead = true := by decide
def e302802723054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e302802723054 : Closed e302802723054 ∧ code e302802723054 = 1402314350830 := by decide
theorem cert_e302802723054 : check e302802723054 [[],[]] .chain = true := by decide
def e302802723066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e302802723066 : Closed e302802723066 ∧ code e302802723066 = 1402314350842 := by decide
theorem cert_e302802723066 : check e302802723066 [[],[]] .chain = true := by decide
def e302802723438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e302802723438 : Closed e302802723438 ∧ code e302802723438 = 1402314351214 := by decide
theorem cert_e302802723438 : check e302802723438 [[],[]] .chain = true := by decide
def e302802723450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e302802723450 : Closed e302802723450 ∧ code e302802723450 = 1402314351226 := by decide
theorem cert_e302802723450 : check e302802723450 [[],[]] .chain = true := by decide
def e302802723614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e302802723614 : Closed e302802723614 ∧ code e302802723614 = 1402314351390 := by decide
theorem cert_e302802723614 : check e302802723614 [[],[]] .chain = true := by decide
def e302802723782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e302802723782 : Closed e302802723782 ∧ code e302802723782 = 1402314351558 := by decide
theorem cert_e302802723782 : check e302802723782 [[],[]] .chain = true := by decide
def e302802724398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e302802724398 : Closed e302802724398 ∧ code e302802724398 = 1402314352174 := by decide
theorem cert_e302802724398 : check e302802724398 [[],[]] .chain = true := by decide
def e302802724578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e302802724578 : Closed e302802724578 ∧ code e302802724578 = 1402314352354 := by decide
theorem cert_e302802724578 : check e302802724578 [[],[]] .chain = true := by decide
def e302802724590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e302802724590 : Closed e302802724590 ∧ code e302802724590 = 1402314352366 := by decide
theorem cert_e302802724590 : check e302802724590 [[],[]] .sourceHead = true := by decide
def e302802724746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e302802724746 : Closed e302802724746 ∧ code e302802724746 = 1402314352522 := by decide
theorem cert_e302802724746 : check e302802724746 [[],[]] .chain = true := by decide
def e302802724770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e302802724770 : Closed e302802724770 ∧ code e302802724770 = 1402314352546 := by decide
theorem cert_e302802724770 : check e302802724770 [[],[]] .chain = true := by decide
def e302802724782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e302802724782 : Closed e302802724782 ∧ code e302802724782 = 1402314352558 := by decide
theorem cert_e302802724782 : check e302802724782 [[],[]] .sourceHead = true := by decide
def e302802724794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e302802724794 : Closed e302802724794 ∧ code e302802724794 = 1402314352570 := by decide
theorem cert_e302802724794 : check e302802724794 [[],[]] .sourceHead = true := by decide
def e302802724926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e302802724926 : Closed e302802724926 ∧ code e302802724926 = 1402314352702 := by decide
theorem cert_e302802724926 : check e302802724926 [[],[]] .chain = true := by decide
def e302802725346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e302802725346 : Closed e302802725346 ∧ code e302802725346 = 1402314353122 := by decide
theorem cert_e302802725346 : check e302802725346 [[],[]] .chain = true := by decide
def e302802725358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e302802725358 : Closed e302802725358 ∧ code e302802725358 = 1402314353134 := by decide
theorem cert_e302802725358 : check e302802725358 [[],[]] .sourceHead = true := by decide
def e302802726414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e302802726414 : Closed e302802726414 ∧ code e302802726414 = 1402314354190 := by decide
theorem cert_e302802726414 : check e302802726414 [[],[]] .chain = true := by decide
def e302802726498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e302802726498 : Closed e302802726498 ∧ code e302802726498 = 1402314354274 := by decide
theorem cert_e302802726498 : check e302802726498 [[],[]] .chain = true := by decide
def e302802726510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e302802726510 : Closed e302802726510 ∧ code e302802726510 = 1402314354286 := by decide
theorem cert_e302802726510 : check e302802726510 [[],[]] .sourceHead = true := by decide
def e302802726522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e302802726522 : Closed e302802726522 ∧ code e302802726522 = 1402314354298 := by decide
theorem cert_e302802726522 : check e302802726522 [[],[]] .sourceHead = true := by decide
def e302802727030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e302802727030 : Closed e302802727030 ∧ code e302802727030 = 1402314354806 := by decide
theorem cert_e302802727030 : check e302802727030 [[],[]] .chain = true := by decide
def e302802727034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302802727034 : Closed e302802727034 ∧ code e302802727034 = 1402314354810 := by decide
theorem cert_e302802727034 : check e302802727034 [[],[]] .chain = true := by decide
def e302802727130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e302802727130 : Closed e302802727130 ∧ code e302802727130 = 1402314354906 := by decide
theorem cert_e302802727130 : check e302802727130 [[],[]] .chain = true := by decide
def e302802727146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e302802727146 : Closed e302802727146 ∧ code e302802727146 = 1402314354922 := by decide
theorem cert_e302802727146 : check e302802727146 [[],[]] .chain = true := by decide
def e302802727222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e302802727222 : Closed e302802727222 ∧ code e302802727222 = 1402314354998 := by decide
theorem cert_e302802727222 : check e302802727222 [[],[]] .chain = true := by decide
def e302802727226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e302802727226 : Closed e302802727226 ∧ code e302802727226 = 1402314355002 := by decide
theorem cert_e302802727226 : check e302802727226 [[],[]] .chain = true := by decide
def e302802727310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e302802727310 : Closed e302802727310 ∧ code e302802727310 = 1402314355086 := by decide
theorem cert_e302802727310 : check e302802727310 [[],[]] .chain = true := by decide
def e302802727322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e302802727322 : Closed e302802727322 ∧ code e302802727322 = 1402314355098 := by decide
theorem cert_e302802727322 : check e302802727322 [[],[]] .chain = true := by decide
def e302802727366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e302802727366 : Closed e302802727366 ∧ code e302802727366 = 1402314355142 := by decide
theorem cert_e302802727366 : check e302802727366 [[],[]] .chain = true := by decide
def e302802727702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e302802727702 : Closed e302802727702 ∧ code e302802727702 = 1402314355478 := by decide
theorem cert_e302802727702 : check e302802727702 [[],[]] .chain = true := by decide
def e302802727706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e302802727706 : Closed e302802727706 ∧ code e302802727706 = 1402314355482 := by decide
theorem cert_e302802727706 : check e302802727706 [[],[]] .chain = true := by decide
def e302802727750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 1))))))))
theorem wire_e302802727750 : Closed e302802727750 ∧ code e302802727750 = 1402314355526 := by decide
theorem cert_e302802727750 : check e302802727750 [[],[]] .chain = true := by decide
def e302802727778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e302802727778 : Closed e302802727778 ∧ code e302802727778 = 1402314355554 := by decide
theorem cert_e302802727778 : check e302802727778 [[],[]] .chain = true := by decide
def e302802727790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e302802727790 : Closed e302802727790 ∧ code e302802727790 = 1402314355566 := by decide
theorem cert_e302802727790 : check e302802727790 [[],[]] .sourceHead = true := by decide
def e302802727798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e302802727798 : Closed e302802727798 ∧ code e302802727798 = 1402314355574 := by decide
theorem cert_e302802727798 : check e302802727798 [[],[]] .sourceHead = true := by decide
def e302802727818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e302802727818 : Closed e302802727818 ∧ code e302802727818 = 1402314355594 := by decide
theorem cert_e302802727818 : check e302802727818 [[],[]] .chain = true := by decide
def e302802727842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e302802727842 : Closed e302802727842 ∧ code e302802727842 = 1402314355618 := by decide
theorem cert_e302802727842 : check e302802727842 [[],[]] .chain = true := by decide
def e302802727854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e302802727854 : Closed e302802727854 ∧ code e302802727854 = 1402314355630 := by decide
theorem cert_e302802727854 : check e302802727854 [[],[]] .sourceHead = true := by decide
def e302802727866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e302802727866 : Closed e302802727866 ∧ code e302802727866 = 1402314355642 := by decide
theorem cert_e302802727866 : check e302802727866 [[],[]] .sourceHead = true := by decide
def e302802727894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e302802727894 : Closed e302802727894 ∧ code e302802727894 = 1402314355670 := by decide
theorem cert_e302802727894 : check e302802727894 [[],[]] .sourceHead = true := by decide
def e302802727898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e302802727898 : Closed e302802727898 ∧ code e302802727898 = 1402314355674 := by decide
theorem cert_e302802727898 : check e302802727898 [[],[]] .sourceHead = true := by decide
def e302802727966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e302802727966 : Closed e302802727966 ∧ code e302802727966 = 1402314355742 := by decide
theorem cert_e302802727966 : check e302802727966 [[],[]] .chain = true := by decide
def e302802727990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302802727990 : Closed e302802727990 ∧ code e302802727990 = 1402314355766 := by decide
theorem cert_e302802727990 : check e302802727990 [[],[]] .chain = true := by decide
def e302802727994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302802727994 : Closed e302802727994 ∧ code e302802727994 = 1402314355770 := by decide
theorem cert_e302802727994 : check e302802727994 [[],[]] .chain = true := by decide
def e302802728134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302802728134 : Closed e302802728134 ∧ code e302802728134 = 1402314355910 := by decide
theorem cert_e302802728134 : check e302802728134 [[],[]] .chain = true := by decide
def e302802728162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302802728162 : Closed e302802728162 ∧ code e302802728162 = 1402314355938 := by decide
theorem cert_e302802728162 : check e302802728162 [[],[]] .chain = true := by decide
def e302802728174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e302802728174 : Closed e302802728174 ∧ code e302802728174 = 1402314355950 := by decide
theorem cert_e302802728174 : check e302802728174 [[],[]] .sourceHead = true := by decide
def e302802728182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e302802728182 : Closed e302802728182 ∧ code e302802728182 = 1402314355958 := by decide
theorem cert_e302802728182 : check e302802728182 [[],[]] .sourceHead = true := by decide
def e302802728462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e302802728462 : Closed e302802728462 ∧ code e302802728462 = 1402314356238 := by decide
theorem cert_e302802728462 : check e302802728462 [[],[]] .chain = true := by decide
def e302802728546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e302802728546 : Closed e302802728546 ∧ code e302802728546 = 1402314356322 := by decide
theorem cert_e302802728546 : check e302802728546 [[],[]] .chain = true := by decide
def e302802728558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e302802728558 : Closed e302802728558 ∧ code e302802728558 = 1402314356334 := by decide
theorem cert_e302802728558 : check e302802728558 [[],[]] .sourceHead = true := by decide
def e302802728570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e302802728570 : Closed e302802728570 ∧ code e302802728570 = 1402314356346 := by decide
theorem cert_e302802728570 : check e302802728570 [[],[]] .sourceHead = true := by decide
end Blc.Floor40
