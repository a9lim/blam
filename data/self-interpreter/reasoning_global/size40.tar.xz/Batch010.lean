import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e282797106134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e282797106134 : Closed e282797106134 ∧ code e282797106134 = 1382308733910 := by decide
theorem cert_e282797106134 : check e282797106134 [[],[.under]] .three = true := by decide
def e282797106138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e282797106138 : Closed e282797106138 ∧ code e282797106138 = 1382308733914 := by decide
theorem cert_e282797106138 : check e282797106138 [[],[.under]] .three = true := by decide
def e282797107438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e282797107438 : Closed e282797107438 ∧ code e282797107438 = 1382308735214 := by decide
theorem cert_e282797107438 : check e282797107438 [[],[.under]] .three = true := by decide
def e282797107446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e282797107446 : Closed e282797107446 ∧ code e282797107446 = 1382308735222 := by decide
theorem cert_e282797107446 : check e282797107446 [[],[.under]] .three = true := by decide
def e282797107998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e282797107998 : Closed e282797107998 ∧ code e282797107998 = 1382308735774 := by decide
theorem cert_e282797107998 : check e282797107998 [[],[.under]] .three = true := by decide
def e282797108110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e282797108110 : Closed e282797108110 ∧ code e282797108110 = 1382308735886 := by decide
theorem cert_e282797108110 : check e282797108110 [[],[.under]] .three = true := by decide
def e282797108334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e282797108334 : Closed e282797108334 ∧ code e282797108334 = 1382308736110 := by decide
theorem cert_e282797108334 : check e282797108334 [[],[.under]] .three = true := by decide
def e282797108346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e282797108346 : Closed e282797108346 ∧ code e282797108346 = 1382308736122 := by decide
theorem cert_e282797108346 : check e282797108346 [[],[.under]] .three = true := by decide
def e282797108510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e282797108510 : Closed e282797108510 ∧ code e282797108510 = 1382308736286 := by decide
theorem cert_e282797108510 : check e282797108510 [[],[.under]] .three = true := by decide
def e282797108678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e282797108678 : Closed e282797108678 ∧ code e282797108678 = 1382308736454 := by decide
theorem cert_e282797108678 : check e282797108678 [[],[.under]] .three = true := by decide
def e282797108790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e282797108790 : Closed e282797108790 ∧ code e282797108790 = 1382308736566 := by decide
theorem cert_e282797108790 : check e282797108790 [[],[.under]] .three = true := by decide
def e282797108794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e282797108794 : Closed e282797108794 ∧ code e282797108794 = 1382308736570 := by decide
theorem cert_e282797108794 : check e282797108794 [[],[.under]] .three = true := by decide
def e282797108878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e282797108878 : Closed e282797108878 ∧ code e282797108878 = 1382308736654 := by decide
theorem cert_e282797108878 : check e282797108878 [[],[.under]] .three = true := by decide
def e282797108934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e282797108934 : Closed e282797108934 ∧ code e282797108934 = 1382308736710 := by decide
theorem cert_e282797108934 : check e282797108934 [[],[.under]] .three = true := by decide
def e282797109678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e282797109678 : Closed e282797109678 ∧ code e282797109678 = 1382308737454 := by decide
theorem cert_e282797109678 : check e282797109678 [[],[.under]] .three = true := by decide
def e282797109690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e282797109690 : Closed e282797109690 ∧ code e282797109690 = 1382308737466 := by decide
theorem cert_e282797109690 : check e282797109690 [[],[.under]] .three = true := by decide
def e282797109738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e282797109738 : Closed e282797109738 ∧ code e282797109738 = 1382308737514 := by decide
theorem cert_e282797109738 : check e282797109738 [[],[.under]] .three = true := by decide
def e282797110382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e282797110382 : Closed e282797110382 ∧ code e282797110382 = 1382308738158 := by decide
theorem cert_e282797110382 : check e282797110382 [[],[.under]] .three = true := by decide
def e282797110394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e282797110394 : Closed e282797110394 ∧ code e282797110394 = 1382308738170 := by decide
theorem cert_e282797110394 : check e282797110394 [[],[.under]] .three = true := by decide
def e282797110558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e282797110558 : Closed e282797110558 ∧ code e282797110558 = 1382308738334 := by decide
theorem cert_e282797110558 : check e282797110558 [[],[.under]] .three = true := by decide
def e282797110726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e282797110726 : Closed e282797110726 ∧ code e282797110726 = 1382308738502 := by decide
theorem cert_e282797110726 : check e282797110726 [[],[.under]] .three = true := by decide
def e282797111066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e282797111066 : Closed e282797111066 ∧ code e282797111066 = 1382308738842 := by decide
theorem cert_e282797111066 : check e282797111066 [[],[.under]] .three = true := by decide
def e282797111110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e282797111110 : Closed e282797111110 ∧ code e282797111110 = 1382308738886 := by decide
theorem cert_e282797111110 : check e282797111110 [[],[.under]] .three = true := by decide
def e282797111510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e282797111510 : Closed e282797111510 ∧ code e282797111510 = 1382308739286 := by decide
theorem cert_e282797111510 : check e282797111510 [[],[.under]] .three = true := by decide
def e282797111514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e282797111514 : Closed e282797111514 ∧ code e282797111514 = 1382308739290 := by decide
theorem cert_e282797111514 : check e282797111514 [[],[.under]] .three = true := by decide
def e282797111530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e282797111530 : Closed e282797111530 ∧ code e282797111530 = 1382308739306 := by decide
theorem cert_e282797111530 : check e282797111530 [[],[.under]] .three = true := by decide
def e282797111862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e282797111862 : Closed e282797111862 ∧ code e282797111862 = 1382308739638 := by decide
theorem cert_e282797111862 : check e282797111862 [[],[.under]] .three = true := by decide
def e282797111866 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e282797111866 : Closed e282797111866 ∧ code e282797111866 = 1382308739642 := by decide
theorem cert_e282797111866 : check e282797111866 [[],[.under]] .three = true := by decide
def e282797111950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e282797111950 : Closed e282797111950 ∧ code e282797111950 = 1382308739726 := by decide
theorem cert_e282797111950 : check e282797111950 [[],[.under]] .three = true := by decide
def e282797112006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e282797112006 : Closed e282797112006 ∧ code e282797112006 = 1382308739782 := by decide
theorem cert_e282797112006 : check e282797112006 [[],[.under]] .three = true := by decide
def e282797112090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e282797112090 : Closed e282797112090 ∧ code e282797112090 = 1382308739866 := by decide
theorem cert_e282797112090 : check e282797112090 [[],[.under]] .three = true := by decide
def e282797112134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e282797112134 : Closed e282797112134 ∧ code e282797112134 = 1382308739910 := by decide
theorem cert_e282797112134 : check e282797112134 [[],[.under]] .three = true := by decide
def e282797116654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e282797116654 : Closed e282797116654 ∧ code e282797116654 = 1382308744430 := by decide
theorem cert_e282797116654 : check e282797116654 [[],[.under]] .three = true := by decide
def e282797116662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e282797116662 : Closed e282797116662 ∧ code e282797116662 = 1382308744438 := by decide
theorem cert_e282797116662 : check e282797116662 [[],[.under]] .three = true := by decide
def e282797117038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e282797117038 : Closed e282797117038 ∧ code e282797117038 = 1382308744814 := by decide
theorem cert_e282797117038 : check e282797117038 [[],[.under]] .three = true := by decide
def e282797117050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e282797117050 : Closed e282797117050 ∧ code e282797117050 = 1382308744826 := by decide
theorem cert_e282797117050 : check e282797117050 [[],[.under]] .three = true := by decide
def e282797117238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e282797117238 : Closed e282797117238 ∧ code e282797117238 = 1382308745014 := by decide
theorem cert_e282797117238 : check e282797117238 [[],[.under]] .three = true := by decide
def e282797117242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e282797117242 : Closed e282797117242 ∧ code e282797117242 = 1382308745018 := by decide
theorem cert_e282797117242 : check e282797117242 [[],[.under]] .three = true := by decide
def e282797119726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e282797119726 : Closed e282797119726 ∧ code e282797119726 = 1382308747502 := by decide
theorem cert_e282797119726 : check e282797119726 [[],[.under]] .three = true := by decide
def e282797119734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e282797119734 : Closed e282797119734 ∧ code e282797119734 = 1382308747510 := by decide
theorem cert_e282797119734 : check e282797119734 [[],[.under]] .three = true := by decide
def e282797120286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e282797120286 : Closed e282797120286 ∧ code e282797120286 = 1382308748062 := by decide
theorem cert_e282797120286 : check e282797120286 [[],[.under]] .three = true := by decide
def e282797120398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e282797120398 : Closed e282797120398 ∧ code e282797120398 = 1382308748174 := by decide
theorem cert_e282797120398 : check e282797120398 [[],[.under]] .three = true := by decide
def e282797120622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e282797120622 : Closed e282797120622 ∧ code e282797120622 = 1382308748398 := by decide
theorem cert_e282797120622 : check e282797120622 [[],[.under]] .three = true := by decide
def e282797120634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e282797120634 : Closed e282797120634 ∧ code e282797120634 = 1382308748410 := by decide
theorem cert_e282797120634 : check e282797120634 [[],[.under]] .three = true := by decide
def e282797120798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e282797120798 : Closed e282797120798 ∧ code e282797120798 = 1382308748574 := by decide
theorem cert_e282797120798 : check e282797120798 [[],[.under]] .three = true := by decide
def e282797120966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e282797120966 : Closed e282797120966 ∧ code e282797120966 = 1382308748742 := by decide
theorem cert_e282797120966 : check e282797120966 [[],[.under]] .three = true := by decide
def e282797121078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e282797121078 : Closed e282797121078 ∧ code e282797121078 = 1382308748854 := by decide
theorem cert_e282797121078 : check e282797121078 [[],[.under]] .three = true := by decide
def e282797121082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e282797121082 : Closed e282797121082 ∧ code e282797121082 = 1382308748858 := by decide
theorem cert_e282797121082 : check e282797121082 [[],[.under]] .three = true := by decide
def e282797121166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e282797121166 : Closed e282797121166 ∧ code e282797121166 = 1382308748942 := by decide
theorem cert_e282797121166 : check e282797121166 [[],[.under]] .three = true := by decide
def e282797121222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e282797121222 : Closed e282797121222 ∧ code e282797121222 = 1382308748998 := by decide
theorem cert_e282797121222 : check e282797121222 [[],[.under]] .three = true := by decide
def e282797123358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e282797123358 : Closed e282797123358 ∧ code e282797123358 = 1382308751134 := by decide
theorem cert_e282797123358 : check e282797123358 [[],[.under]] .three = true := by decide
def e282797123470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e282797123470 : Closed e282797123470 ∧ code e282797123470 = 1382308751246 := by decide
theorem cert_e282797123470 : check e282797123470 [[],[.under]] .three = true := by decide
def e282797126430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e282797126430 : Closed e282797126430 ∧ code e282797126430 = 1382308754206 := by decide
theorem cert_e282797126430 : check e282797126430 [[],[.under]] .three = true := by decide
def e282797126598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e282797126598 : Closed e282797126598 ∧ code e282797126598 = 1382308754374 := by decide
theorem cert_e282797126598 : check e282797126598 [[],[.under]] .three = true := by decide
def e282797128078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e282797128078 : Closed e282797128078 ∧ code e282797128078 = 1382308755854 := by decide
theorem cert_e282797128078 : check e282797128078 [[],[.under]] .three = true := by decide
def e282797128134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e282797128134 : Closed e282797128134 ∧ code e282797128134 = 1382308755910 := by decide
theorem cert_e282797128134 : check e282797128134 [[],[.under]] .three = true := by decide
def e282797131374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e282797131374 : Closed e282797131374 ∧ code e282797131374 = 1382308759150 := by decide
theorem cert_e282797131374 : check e282797131374 [[],[.under]] .three = true := by decide
def e282797131386 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e282797131386 : Closed e282797131386 ∧ code e282797131386 = 1382308759162 := by decide
theorem cert_e282797131386 : check e282797131386 [[],[.under]] .three = true := by decide
def e282797131674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e282797131674 : Closed e282797131674 ∧ code e282797131674 = 1382308759450 := by decide
theorem cert_e282797131674 : check e282797131674 [[],[.under]] .three = true := by decide
def e282797132910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e282797132910 : Closed e282797132910 ∧ code e282797132910 = 1382308760686 := by decide
theorem cert_e282797132910 : check e282797132910 [[],[.under]] .three = true := by decide
def e282797132922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e282797132922 : Closed e282797132922 ∧ code e282797132922 = 1382308760698 := by decide
theorem cert_e282797132922 : check e282797132922 [[],[.under]] .three = true := by decide
def e282797133086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e282797133086 : Closed e282797133086 ∧ code e282797133086 = 1382308760862 := by decide
theorem cert_e282797133086 : check e282797133086 [[],[.under]] .three = true := by decide
def e282797133254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e282797133254 : Closed e282797133254 ∧ code e282797133254 = 1382308761030 := by decide
theorem cert_e282797133254 : check e282797133254 [[],[.under]] .three = true := by decide
def e282797133594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e282797133594 : Closed e282797133594 ∧ code e282797133594 = 1382308761370 := by decide
theorem cert_e282797133594 : check e282797133594 [[],[.under]] .three = true := by decide
def e282797133638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e282797133638 : Closed e282797133638 ∧ code e282797133638 = 1382308761414 := by decide
theorem cert_e282797133638 : check e282797133638 [[],[.under]] .three = true := by decide
def e282797134622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e282797134622 : Closed e282797134622 ∧ code e282797134622 = 1382308762398 := by decide
theorem cert_e282797134622 : check e282797134622 [[],[.under]] .three = true := by decide
def e282797134790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e282797134790 : Closed e282797134790 ∧ code e282797134790 = 1382308762566 := by decide
theorem cert_e282797134790 : check e282797134790 [[],[.under]] .three = true := by decide
def e282797137094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e282797137094 : Closed e282797137094 ∧ code e282797137094 = 1382308764870 := by decide
theorem cert_e282797137094 : check e282797137094 [[],[.under]] .three = true := by decide
def e282797138742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e282797138742 : Closed e282797138742 ∧ code e282797138742 = 1382308766518 := by decide
theorem cert_e282797138742 : check e282797138742 [[],[.under]] .three = true := by decide
def e282797138746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e282797138746 : Closed e282797138746 ∧ code e282797138746 = 1382308766522 := by decide
theorem cert_e282797138746 : check e282797138746 [[],[.under]] .three = true := by decide
def e282797138842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e282797138842 : Closed e282797138842 ∧ code e282797138842 = 1382308766618 := by decide
theorem cert_e282797138842 : check e282797138842 [[],[.under]] .three = true := by decide
def e282797139510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e282797139510 : Closed e282797139510 ∧ code e282797139510 = 1382308767286 := by decide
theorem cert_e282797139510 : check e282797139510 [[],[.under]] .three = true := by decide
def e282797139514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e282797139514 : Closed e282797139514 ∧ code e282797139514 = 1382308767290 := by decide
theorem cert_e282797139514 : check e282797139514 [[],[.under]] .three = true := by decide
def e282797139598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e282797139598 : Closed e282797139598 ∧ code e282797139598 = 1382308767374 := by decide
theorem cert_e282797139598 : check e282797139598 [[],[.under]] .three = true := by decide
def e282797139654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e282797139654 : Closed e282797139654 ∧ code e282797139654 = 1382308767430 := by decide
theorem cert_e282797139654 : check e282797139654 [[],[.under]] .three = true := by decide
def e282797139738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e282797139738 : Closed e282797139738 ∧ code e282797139738 = 1382308767514 := by decide
theorem cert_e282797139738 : check e282797139738 [[],[.under]] .three = true := by decide
def e282797139782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e282797139782 : Closed e282797139782 ∧ code e282797139782 = 1382308767558 := by decide
theorem cert_e282797139782 : check e282797139782 [[],[.under]] .three = true := by decide
def e282797140366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e282797140366 : Closed e282797140366 ∧ code e282797140366 = 1382308768142 := by decide
theorem cert_e282797140366 : check e282797140366 [[],[.under]] .three = true := by decide
def e282797140422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e282797140422 : Closed e282797140422 ∧ code e282797140422 = 1382308768198 := by decide
theorem cert_e282797140422 : check e282797140422 [[],[.under]] .three = true := by decide
def e282797141190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e282797141190 : Closed e282797141190 ∧ code e282797141190 = 1382308768966 := by decide
theorem cert_e282797141190 : check e282797141190 [[],[.under]] .three = true := by decide
def e282797151966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e282797151966 : Closed e282797151966 ∧ code e282797151966 = 1382308779742 := by decide
theorem cert_e282797151966 : check e282797151966 [[],[.under]] .three = true := by decide
def e282797151990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e282797151990 : Closed e282797151990 ∧ code e282797151990 = 1382308779766 := by decide
theorem cert_e282797151990 : check e282797151990 [[],[.under]] .three = true := by decide
def e282797152094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e282797152094 : Closed e282797152094 ∧ code e282797152094 = 1382308779870 := by decide
theorem cert_e282797152094 : check e282797152094 [[],[.under]] .three = true := by decide
def e282797152122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e282797152122 : Closed e282797152122 ∧ code e282797152122 = 1382308779898 := by decide
theorem cert_e282797152122 : check e282797152122 [[],[.under]] .three = true := by decide
def e282797152214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e282797152214 : Closed e282797152214 ∧ code e282797152214 = 1382308779990 := by decide
theorem cert_e282797152214 : check e282797152214 [[],[.under]] .three = true := by decide
def e282797152218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e282797152218 : Closed e282797152218 ∧ code e282797152218 = 1382308779994 := by decide
theorem cert_e282797152218 : check e282797152218 [[],[.under]] .three = true := by decide
def e282797152734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e282797152734 : Closed e282797152734 ∧ code e282797152734 = 1382308780510 := by decide
theorem cert_e282797152734 : check e282797152734 [[],[.under]] .three = true := by decide
def e282797152758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e282797152758 : Closed e282797152758 ∧ code e282797152758 = 1382308780534 := by decide
theorem cert_e282797152758 : check e282797152758 [[],[.under]] .three = true := by decide
def e282797153502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e282797153502 : Closed e282797153502 ∧ code e282797153502 = 1382308781278 := by decide
theorem cert_e282797153502 : check e282797153502 [[],[.under]] .three = true := by decide
def e282797153530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e282797153530 : Closed e282797153530 ∧ code e282797153530 = 1382308781306 := by decide
theorem cert_e282797153530 : check e282797153530 [[],[.under]] .three = true := by decide
def e282797154102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e282797154102 : Closed e282797154102 ∧ code e282797154102 = 1382308781878 := by decide
theorem cert_e282797154102 : check e282797154102 [[],[.under]] .three = true := by decide
def e282797154106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e282797154106 : Closed e282797154106 ∧ code e282797154106 = 1382308781882 := by decide
theorem cert_e282797154106 : check e282797154106 [[],[.under]] .three = true := by decide
def e282797168878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e282797168878 : Closed e282797168878 ∧ code e282797168878 = 1382308796654 := by decide
theorem cert_e282797168878 : check e282797168878 [[],[.under]] .three = true := by decide
def e282797168886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e282797168886 : Closed e282797168886 ∧ code e282797168886 = 1382308796662 := by decide
theorem cert_e282797168886 : check e282797168886 [[],[.under]] .three = true := by decide
def e282797169438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e282797169438 : Closed e282797169438 ∧ code e282797169438 = 1382308797214 := by decide
theorem cert_e282797169438 : check e282797169438 [[],[.under]] .three = true := by decide
def e282797169550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e282797169550 : Closed e282797169550 ∧ code e282797169550 = 1382308797326 := by decide
theorem cert_e282797169550 : check e282797169550 [[],[.under]] .three = true := by decide
def e282797169774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e282797169774 : Closed e282797169774 ∧ code e282797169774 = 1382308797550 := by decide
theorem cert_e282797169774 : check e282797169774 [[],[.under]] .three = true := by decide
def e282797169786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e282797169786 : Closed e282797169786 ∧ code e282797169786 = 1382308797562 := by decide
theorem cert_e282797169786 : check e282797169786 [[],[.under]] .three = true := by decide
def e282797169950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e282797169950 : Closed e282797169950 ∧ code e282797169950 = 1382308797726 := by decide
theorem cert_e282797169950 : check e282797169950 [[],[.under]] .three = true := by decide
def e282797170118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e282797170118 : Closed e282797170118 ∧ code e282797170118 = 1382308797894 := by decide
theorem cert_e282797170118 : check e282797170118 [[],[.under]] .three = true := by decide
def e282797170230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e282797170230 : Closed e282797170230 ∧ code e282797170230 = 1382308798006 := by decide
theorem cert_e282797170230 : check e282797170230 [[],[.under]] .three = true := by decide
def e282797170234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e282797170234 : Closed e282797170234 ∧ code e282797170234 = 1382308798010 := by decide
theorem cert_e282797170234 : check e282797170234 [[],[.under]] .three = true := by decide
def e282797170318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e282797170318 : Closed e282797170318 ∧ code e282797170318 = 1382308798094 := by decide
theorem cert_e282797170318 : check e282797170318 [[],[.under]] .three = true := by decide
def e282797170374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e282797170374 : Closed e282797170374 ∧ code e282797170374 = 1382308798150 := by decide
theorem cert_e282797170374 : check e282797170374 [[],[.under]] .three = true := by decide
def e282797172510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e282797172510 : Closed e282797172510 ∧ code e282797172510 = 1382308800286 := by decide
theorem cert_e282797172510 : check e282797172510 [[],[.under]] .three = true := by decide
def e282797172622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e282797172622 : Closed e282797172622 ∧ code e282797172622 = 1382308800398 := by decide
theorem cert_e282797172622 : check e282797172622 [[],[.under]] .three = true := by decide
def e282797175582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e282797175582 : Closed e282797175582 ∧ code e282797175582 = 1382308803358 := by decide
theorem cert_e282797175582 : check e282797175582 [[],[.under]] .three = true := by decide
def e282797175750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e282797175750 : Closed e282797175750 ∧ code e282797175750 = 1382308803526 := by decide
theorem cert_e282797175750 : check e282797175750 [[],[.under]] .three = true := by decide
def e282797177230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e282797177230 : Closed e282797177230 ∧ code e282797177230 = 1382308805006 := by decide
theorem cert_e282797177230 : check e282797177230 [[],[.under]] .three = true := by decide
def e282797177286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e282797177286 : Closed e282797177286 ∧ code e282797177286 = 1382308805062 := by decide
theorem cert_e282797177286 : check e282797177286 [[],[.under]] .three = true := by decide
def e282797214574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e282797214574 : Closed e282797214574 ∧ code e282797214574 = 1382308842350 := by decide
theorem cert_e282797214574 : check e282797214574 [[],[.under]] .smaller = true := by decide
def e282797214582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e282797214582 : Closed e282797214582 ∧ code e282797214582 = 1382308842358 := by decide
theorem cert_e282797214582 : check e282797214582 [[],[.under]] .smaller = true := by decide
def e282797214638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e282797214638 : Closed e282797214638 ∧ code e282797214638 = 1382308842414 := by decide
theorem cert_e282797214638 : check e282797214638 [[],[.under]] .smaller = true := by decide
def e282797214650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e282797214650 : Closed e282797214650 ∧ code e282797214650 = 1382308842426 := by decide
theorem cert_e282797214650 : check e282797214650 [[],[.under]] .smaller = true := by decide
def e282797214678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e282797214678 : Closed e282797214678 ∧ code e282797214678 = 1382308842454 := by decide
theorem cert_e282797214678 : check e282797214678 [[],[.under]] .smaller = true := by decide
def e282797214682 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e282797214682 : Closed e282797214682 ∧ code e282797214682 = 1382308842458 := by decide
theorem cert_e282797214682 : check e282797214682 [[],[.under]] .smaller = true := by decide
def e282797214958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e282797214958 : Closed e282797214958 ∧ code e282797214958 = 1382308842734 := by decide
theorem cert_e282797214958 : check e282797214958 [[],[.under]] .smaller = true := by decide
def e282797214966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e282797214966 : Closed e282797214966 ∧ code e282797214966 = 1382308842742 := by decide
theorem cert_e282797214966 : check e282797214966 [[],[.under]] .smaller = true := by decide
def e282797215342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e282797215342 : Closed e282797215342 ∧ code e282797215342 = 1382308843118 := by decide
theorem cert_e282797215342 : check e282797215342 [[],[.under]] .smaller = true := by decide
def e282797215354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e282797215354 : Closed e282797215354 ∧ code e282797215354 = 1382308843130 := by decide
theorem cert_e282797215354 : check e282797215354 [[],[.under]] .smaller = true := by decide
def e282797215542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e282797215542 : Closed e282797215542 ∧ code e282797215542 = 1382308843318 := by decide
theorem cert_e282797215542 : check e282797215542 [[],[.under]] .smaller = true := by decide
def e282797215546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e282797215546 : Closed e282797215546 ∧ code e282797215546 = 1382308843322 := by decide
theorem cert_e282797215546 : check e282797215546 [[],[.under]] .smaller = true := by decide
def e282797223022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e282797223022 : Closed e282797223022 ∧ code e282797223022 = 1382308850798 := by decide
theorem cert_e282797223022 : check e282797223022 [[],[.under]] .three = true := by decide
def e282797223034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e282797223034 : Closed e282797223034 ∧ code e282797223034 = 1382308850810 := by decide
theorem cert_e282797223034 : check e282797223034 [[],[.under]] .three = true := by decide
def e282797223198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e282797223198 : Closed e282797223198 ∧ code e282797223198 = 1382308850974 := by decide
theorem cert_e282797223198 : check e282797223198 [[],[.under]] .three = true := by decide
def e282797223366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e282797223366 : Closed e282797223366 ∧ code e282797223366 = 1382308851142 := by decide
theorem cert_e282797223366 : check e282797223366 [[],[.under]] .three = true := by decide
def e282797223706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e282797223706 : Closed e282797223706 ∧ code e282797223706 = 1382308851482 := by decide
theorem cert_e282797223706 : check e282797223706 [[],[.under]] .three = true := by decide
def e282797223750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e282797223750 : Closed e282797223750 ∧ code e282797223750 = 1382308851526 := by decide
theorem cert_e282797223750 : check e282797223750 [[],[.under]] .three = true := by decide
def e282797224734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e282797224734 : Closed e282797224734 ∧ code e282797224734 = 1382308852510 := by decide
theorem cert_e282797224734 : check e282797224734 [[],[.under]] .three = true := by decide
def e282797224902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e282797224902 : Closed e282797224902 ∧ code e282797224902 = 1382308852678 := by decide
theorem cert_e282797224902 : check e282797224902 [[],[.under]] .three = true := by decide
def e282797227206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e282797227206 : Closed e282797227206 ∧ code e282797227206 = 1382308854982 := by decide
theorem cert_e282797227206 : check e282797227206 [[],[.under]] .three = true := by decide
def e282797250102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e282797250102 : Closed e282797250102 ∧ code e282797250102 = 1382308877878 := by decide
theorem cert_e282797250102 : check e282797250102 [[],[.under]] .three = true := by decide
def e282797250106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e282797250106 : Closed e282797250106 ∧ code e282797250106 = 1382308877882 := by decide
theorem cert_e282797250106 : check e282797250106 [[],[.under]] .three = true := by decide
def e282797250190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e282797250190 : Closed e282797250190 ∧ code e282797250190 = 1382308877966 := by decide
theorem cert_e282797250190 : check e282797250190 [[],[.under]] .three = true := by decide
def e282797250246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e282797250246 : Closed e282797250246 ∧ code e282797250246 = 1382308878022 := by decide
theorem cert_e282797250246 : check e282797250246 [[],[.under]] .three = true := by decide
def e282797250330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e282797250330 : Closed e282797250330 ∧ code e282797250330 = 1382308878106 := by decide
theorem cert_e282797250330 : check e282797250330 [[],[.under]] .three = true := by decide
def e282797250374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e282797250374 : Closed e282797250374 ∧ code e282797250374 = 1382308878150 := by decide
theorem cert_e282797250374 : check e282797250374 [[],[.under]] .three = true := by decide
def e282797250958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e282797250958 : Closed e282797250958 ∧ code e282797250958 = 1382308878734 := by decide
theorem cert_e282797250958 : check e282797250958 [[],[.under]] .three = true := by decide
def e282797251014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e282797251014 : Closed e282797251014 ∧ code e282797251014 = 1382308878790 := by decide
theorem cert_e282797251014 : check e282797251014 [[],[.under]] .three = true := by decide
def e282797251782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e282797251782 : Closed e282797251782 ∧ code e282797251782 = 1382308879558 := by decide
theorem cert_e282797251782 : check e282797251782 [[],[.under]] .three = true := by decide
def e282798348526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e282798348526 : Closed e282798348526 ∧ code e282798348526 = 1382309976302 := by decide
theorem cert_e282798348526 : check e282798348526 [[],[.under]] .chain = true := by decide
def e282798348534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e282798348534 : Closed e282798348534 ∧ code e282798348534 = 1382309976310 := by decide
theorem cert_e282798348534 : check e282798348534 [[],[.under]] .chain = true := by decide
def e282798349086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e282798349086 : Closed e282798349086 ∧ code e282798349086 = 1382309976862 := by decide
theorem cert_e282798349086 : check e282798349086 [[],[.under]] .chain = true := by decide
def e282798349198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e282798349198 : Closed e282798349198 ∧ code e282798349198 = 1382309976974 := by decide
theorem cert_e282798349198 : check e282798349198 [[],[.under]] .chain = true := by decide
def e282798349422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e282798349422 : Closed e282798349422 ∧ code e282798349422 = 1382309977198 := by decide
theorem cert_e282798349422 : check e282798349422 [[],[.under]] .chain = true := by decide
def e282798349434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e282798349434 : Closed e282798349434 ∧ code e282798349434 = 1382309977210 := by decide
theorem cert_e282798349434 : check e282798349434 [[],[.under]] .chain = true := by decide
def e282798349598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e282798349598 : Closed e282798349598 ∧ code e282798349598 = 1382309977374 := by decide
theorem cert_e282798349598 : check e282798349598 [[],[.under]] .chain = true := by decide
def e282798349766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e282798349766 : Closed e282798349766 ∧ code e282798349766 = 1382309977542 := by decide
theorem cert_e282798349766 : check e282798349766 [[],[.under]] .chain = true := by decide
def e282798349878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e282798349878 : Closed e282798349878 ∧ code e282798349878 = 1382309977654 := by decide
theorem cert_e282798349878 : check e282798349878 [[],[.under]] .chain = true := by decide
def e282798349882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e282798349882 : Closed e282798349882 ∧ code e282798349882 = 1382309977658 := by decide
theorem cert_e282798349882 : check e282798349882 [[],[.under]] .chain = true := by decide
def e282798349966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e282798349966 : Closed e282798349966 ∧ code e282798349966 = 1382309977742 := by decide
theorem cert_e282798349966 : check e282798349966 [[],[.under]] .chain = true := by decide
def e282798350022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e282798350022 : Closed e282798350022 ∧ code e282798350022 = 1382309977798 := by decide
theorem cert_e282798350022 : check e282798350022 [[],[.under]] .chain = true := by decide
def e282798352158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e282798352158 : Closed e282798352158 ∧ code e282798352158 = 1382309979934 := by decide
theorem cert_e282798352158 : check e282798352158 [[],[.under]] .chain = true := by decide
def e282798352270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e282798352270 : Closed e282798352270 ∧ code e282798352270 = 1382309980046 := by decide
theorem cert_e282798352270 : check e282798352270 [[],[.under]] .chain = true := by decide
def e282798355230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e282798355230 : Closed e282798355230 ∧ code e282798355230 = 1382309983006 := by decide
theorem cert_e282798355230 : check e282798355230 [[],[.under]] .chain = true := by decide
def e282798355398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e282798355398 : Closed e282798355398 ∧ code e282798355398 = 1382309983174 := by decide
theorem cert_e282798355398 : check e282798355398 [[],[.under]] .chain = true := by decide
def e282798356878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e282798356878 : Closed e282798356878 ∧ code e282798356878 = 1382309984654 := by decide
theorem cert_e282798356878 : check e282798356878 [[],[.under]] .chain = true := by decide
def e282798356934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e282798356934 : Closed e282798356934 ∧ code e282798356934 = 1382309984710 := by decide
theorem cert_e282798356934 : check e282798356934 [[],[.under]] .chain = true := by decide
def e282803050206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e282803050206 : Closed e282803050206 ∧ code e282803050206 = 1382314677982 := by decide
theorem cert_e282803050206 : check e282803050206 [[],[.under],[.under],[.under]] .three = true := by decide
def e282803050230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e282803050230 : Closed e282803050230 ∧ code e282803050230 = 1382314678006 := by decide
theorem cert_e282803050230 : check e282803050230 [[],[.under],[.under],[.under]] .three = true := by decide
end Blc.Floor40
