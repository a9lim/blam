import RegularBase
import Batch025
namespace Certgen.R301464816502
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 6,.lam 2,.app 3 4,.var 0,.lam 5,.var 1,.lam 7,.app 8 11,.app 9 10,.var 0,.var 0,.lam 12,.lam 13,.app 14 17,.app 15 16,.var 0,.var 2,.var 1]
def values : Array (List AClo) := #[[⟨6,[]⟩],[⟨10,[3]⟩,⟨16,[2,1,3]⟩],[⟨11,[3]⟩,⟨17,[2,1,3]⟩],[⟨4,[0]⟩,⟨11,[3]⟩,⟨17,[2,1,3]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨6,[]⟩,0⟩],[⟨⟨17,[2,1,3]⟩,0⟩],[⟨⟨16,[2,1,3]⟩,2⟩],[⟨⟨4,[0]⟩,0⟩],[⟨⟨11,[3]⟩,0⟩],[⟨⟨10,[3]⟩,5⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[0]⟩,0⟩,⟨⟨3,[0]⟩,4⟩,⟨⟨4,[0]⟩,3⟩,⟨⟨4,[0]⟩,6⟩,⟨⟨5,[1,0]⟩,2⟩,⟨⟨5,[1,0]⟩,5⟩,⟨⟨6,[]⟩,2⟩,⟨⟨6,[]⟩,4⟩,⟨⟨6,[]⟩,5⟩,⟨⟨7,[3]⟩,0⟩,⟨⟨8,[3]⟩,5⟩,⟨⟨9,[3]⟩,6⟩,⟨⟨10,[3]⟩,3⟩,⟨⟨10,[3]⟩,6⟩,⟨⟨11,[3]⟩,3⟩,⟨⟨11,[3]⟩,6⟩,⟨⟨12,[1,3]⟩,2⟩,⟨⟨12,[1,3]⟩,5⟩,⟨⟨13,[2,1,3]⟩,0⟩,⟨⟨14,[2,1,3]⟩,2⟩,⟨⟨15,[2,1,3]⟩,3⟩,⟨⟨16,[2,1,3]⟩,3⟩,⟨⟨16,[2,1,3]⟩,6⟩,⟨⟨17,[2,1,3]⟩,3⟩,⟨⟨17,[2,1,3]⟩,6⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[9],[6],[7],[8],[10],[11],[11],[11],[12],[13],[5,17,26],[4,16,25],[5,17,26],[18],[19],[20],[20],[21],[22],[16,25],[4,16,25],[5,17,26],[14,23],[15,24]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem block24 : checkRange P V K states hints 24 3=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<27 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 by_cases h12 : i<24
 · exact range_sound block12 i (by omega) h12 hi
 exact range_sound block24 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def terms : Array Term := #[(.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))),(.lam (.app (.var 0) (.lam (.var 1)))),(.app (.var 0) (.lam (.var 1))),(.var 0),(.lam (.var 1)),(.var 1),(.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))),(.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))),(.app (.var 0) (.var 0)),(.var 0),(.var 0),(.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))),(.lam (.app (.app (.var 0) (.var 2)) (.var 1))),(.app (.app (.var 0) (.var 2)) (.var 1)),(.app (.var 0) (.var 2)),(.var 0),(.var 2),(.var 1)]
def termAt (p : Nat) : Term := terms[p]?.getD (.var 0)
def aligns (p : Nat) : Bool := match P p with
 | .opaque => true
 | .var i => decide (termAt p = Term.var i)
 | .lam b => decide (termAt p = Term.lam (termAt b))
 | .app f a => decide (termAt p = Term.app (termAt f) (termAt a))
theorem valid : (List.range code.size).all aligns = true := by decide
theorem every (p : Nat) : aligns p = true := by
 by_cases hp : p < code.size
 · exact List.all_eq_true.mp valid p (List.mem_range.mpr hp)
 · have hz : code[p]? = none := Array.getElem?_eq_none (by omega)
   simp [aligns,P,hz]
def model : Model P where
 term := termAt
 var_eq := by intro p i h; simpa [aligns,h] using every p
 lam_eq := by intro p b h; simpa [aligns,h] using every p
 app_eq := by intro p f a h; simpa [aligns,h] using every p
theorem excluded : ¬ IsSelfInterpreter e301464816502 := by
 intro he
 have hp : replay [] e301464816502 = some (model.term 0) := by decide
 obtain ⟨h,hh⟩ := clocks_replay (rawCount he) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R301464816502
