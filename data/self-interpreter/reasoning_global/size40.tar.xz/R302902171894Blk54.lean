import R302902171894Data
namespace Certgen.R302902171894
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl648 : FloorIndex.rangeOK validState 648 12 = true := by decide +kernel
theorem bl660 : FloorIndex.rangeOK validState 660 12 = true := by decide +kernel
theorem bl672 : FloorIndex.rangeOK validState 672 12 = true := by decide +kernel
theorem bl684 : FloorIndex.rangeOK validState 684 12 = true := by decide +kernel
theorem bl696 : FloorIndex.rangeOK validState 696 12 = true := by decide +kernel
theorem bl708 : FloorIndex.rangeOK validState 708 12 = true := by decide +kernel
end Certgen.R302902171894
