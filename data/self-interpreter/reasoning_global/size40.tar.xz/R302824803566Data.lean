import R302824803566V0
import R302824803566K0
import R302824803566st0
import R302824803566hs0
import CodeBridge
import Batch060
namespace Certgen.R302824803566
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 142,.app 2 133,.app 3 35,.lam 4,.app 5 17,.lam 6,.lam 7,.app 8 9,.var 1,.lam 10,.app 11 12,.var 2,.app 13 14,.var 0,.app 15 16,.var 1,.var 2,.app 18 19,.var 0,.app 20 23,.lam 21,.lam 22,.var 0,.lam 24,.lam 25,.app 26 27,.var 1,.lam 28,.app 29 30,.var 2,.app 31 32,.var 0,.app 33 34,.var 1,.var 2,.lam 36,.app 37 69,.lam 38,.app 39 51,.lam 40,.lam 41,.app 42 43,.var 1,.lam 44,.app 45 46,.var 2,.app 47 48,.var 0,.app 49 50,.var 1,.var 2,.app 52 53,.var 0,.app 54 57,.lam 55,.lam 56,.var 0,.lam 58,.lam 59,.app 60 61,.var 1,.lam 62,.app 63 64,.var 2,.app 65 66,.var 0,.app 67 68,.var 1,.var 2,.app 70 71,.var 0,.app 72 101,.lam 73,.app 74 79,.app 75 76,.var 0,.lam 77,.lam 78,.var 1,.lam 80,.app 81 86,.app 82 83,.var 0,.lam 84,.lam 85,.var 1,.lam 87,.app 88 93,.app 89 90,.var 0,.lam 91,.lam 92,.var 0,.lam 94,.app 95 100,.app 96 97,.var 0,.lam 98,.lam 99,.var 1,.opaque,.lam 102,.app 103 115,.lam 104,.lam 105,.app 106 107,.var 1,.lam 108,.app 109 110,.var 2,.app 111 112,.var 0,.app 113 114,.var 1,.var 2,.app 116 117,.var 0,.app 118 121,.lam 119,.lam 120,.var 0,.lam 122,.lam 123,.app 124 125,.var 1,.lam 126,.app 127 128,.var 2,.app 129 130,.var 0,.app 131 132,.var 1,.var 2,.app 134 138,.lam 135,.app 136 137,.var 0,.var 0,.lam 139,.app 140 141,.var 0,.var 0,.app 143 147,.lam 144,.app 145 146,.var 0,.var 0,.lam 148,.app 149 150,.var 0,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (V20[i-20]?.getD []))
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD []))
def st (i : Nat) : AState := if i < 89 then (if i < 40 then (if i < 20 then (st0[i-0]?.getD entry) else (st20[i-20]?.getD entry)) else (if i < 60 then (st40[i-40]?.getD entry) else (if i < 80 then (st60[i-60]?.getD entry) else (st80[i-80]?.getD entry)))) else entry
def hs (i : Nat) : List Nat := (if i < 40 then (if i < 20 then (hs0[i-0]?.getD []) else (hs20[i-20]?.getD [])) else (if i < 60 then (hs40[i-40]?.getD []) else (if i < 80 then (hs60[i-60]?.getD []) else (hs80[i-80]?.getD []))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R302824803566
