import RegularBase
import Batch060
namespace Certgen.R302824747950
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 52,.app 2 23,.app 3 20,.app 4 8,.lam 5,.app 6 7,.var 0,.var 0,.lam 9,.lam 10,.app 11 12,.var 1,.lam 13,.app 14 19,.app 15 16,.var 2,.app 17 18,.var 1,.var 0,.var 2,.lam 21,.lam 22,.var 0,.lam 24,.app 25 30,.app 26 27,.var 0,.lam 28,.lam 29,.var 1,.lam 31,.app 32 37,.app 33 34,.var 0,.lam 35,.lam 36,.var 1,.lam 38,.app 39 44,.app 40 41,.var 0,.lam 42,.lam 43,.var 0,.lam 45,.app 46 51,.app 47 48,.var 0,.lam 49,.lam 50,.var 1,.opaque,.app 53 57,.lam 54,.app 55 56,.var 0,.var 0,.lam 58,.app 59 60,.var 0,.var 0]
def values : Array (List AClo) := #[[⟨52,[]⟩],[⟨12,[13,10]⟩],[⟨18,[1,15,12]⟩],[⟨12,[14,11]⟩],[⟨16,[0,14,11]⟩],[⟨18,[0,14,11]⟩],[⟨8,[]⟩],[⟨57,[]⟩],[⟨56,[7]⟩],[⟨60,[8]⟩,⟨60,[9]⟩],[⟨12,[15,12]⟩],[⟨16,[1,15,12]⟩],[⟨7,[6]⟩],[⟨23,[]⟩],[⟨19,[0,14,11]⟩,⟨19,[1,15,12]⟩],[⟨20,[]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨52,[]⟩,0⟩],[⟨⟨23,[]⟩,1⟩],[⟨⟨12,[13,10]⟩,1⟩],[⟨⟨12,[14,11]⟩,1⟩],[⟨⟨12,[14,5]⟩,0⟩],[⟨⟨12,[15,12]⟩,2⟩],[⟨⟨19,[0,14,11]⟩,0⟩],[⟨⟨19,[1,15,12]⟩,1⟩],[⟨⟨16,[0,14,11]⟩,7⟩],[⟨⟨16,[1,15,12]⟩,8⟩],[⟨⟨18,[0,14,11]⟩,7⟩],[⟨⟨18,[1,15,12]⟩,9⟩],[⟨⟨18,[1,15,12]⟩,11⟩],[⟨⟨18,[1,15,12]⟩,4⟩],[⟨⟨20,[]⟩,2⟩],[⟨⟨8,[]⟩,15⟩],[⟨⟨7,[6]⟩,15⟩],[⟨⟨57,[]⟩,7⟩],[⟨⟨57,[]⟩,5⟩],[⟨⟨56,[7]⟩,5⟩,⟨⟨56,[7]⟩,7⟩],[⟨⟨60,[8]⟩,5⟩,⟨⟨60,[8]⟩,7⟩],[⟨⟨60,[9]⟩,5⟩,⟨⟨60,[9]⟩,7⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[]⟩,2⟩,⟨⟨3,[]⟩,15⟩,⟨⟨4,[]⟩,16⟩,⟨⟨5,[6]⟩,15⟩,⟨⟨6,[6]⟩,17⟩,⟨⟨7,[6]⟩,6⟩,⟨⟨7,[6]⟩,10⟩,⟨⟨7,[6]⟩,11⟩,⟨⟨8,[]⟩,6⟩,⟨⟨8,[]⟩,10⟩,⟨⟨8,[]⟩,11⟩,⟨⟨8,[]⟩,17⟩,⟨⟨9,[5]⟩,7⟩,⟨⟨9,[10]⟩,2⟩,⟨⟨9,[11]⟩,8⟩,⟨⟨9,[12]⟩,15⟩,⟨⟨10,[13,10]⟩,1⟩,⟨⟨10,[14,5]⟩,0⟩,⟨⟨10,[14,11]⟩,1⟩,⟨⟨10,[15,12]⟩,2⟩,⟨⟨11,[13,10]⟩,3⟩,⟨⟨11,[14,5]⟩,5⟩,⟨⟨11,[14,11]⟩,4⟩,⟨⟨11,[15,12]⟩,6⟩,⟨⟨12,[14,11]⟩,1⟩,⟨⟨12,[15,12]⟩,3⟩,⟨⟨13,[0,14,11]⟩,0⟩,⟨⟨13,[1,15,12]⟩,1⟩,⟨⟨14,[0,14,11]⟩,7⟩,⟨⟨14,[1,15,12]⟩,8⟩,⟨⟨15,[0,14,11]⟩,9⟩,⟨⟨15,[1,15,12]⟩,10⟩,⟨⟨16,[0,14,11]⟩,7⟩,⟨⟨16,[1,15,12]⟩,4⟩,⟨⟨16,[1,15,12]⟩,9⟩,⟨⟨16,[1,15,12]⟩,11⟩,⟨⟨17,[0,14,11]⟩,11⟩,⟨⟨17,[1,15,12]⟩,12⟩,⟨⟨17,[1,15,12]⟩,13⟩,⟨⟨17,[1,15,12]⟩,14⟩,⟨⟨18,[0,14,11]⟩,5⟩,⟨⟨18,[0,14,11]⟩,7⟩,⟨⟨19,[0,14,11]⟩,11⟩,⟨⟨19,[1,15,12]⟩,11⟩,⟨⟨20,[]⟩,12⟩,⟨⟨20,[]⟩,13⟩,⟨⟨20,[]⟩,14⟩,⟨⟨21,[2]⟩,4⟩,⟨⟨21,[2]⟩,9⟩,⟨⟨21,[2]⟩,11⟩,⟨⟨22,[3,2]⟩,1⟩,⟨⟨22,[4,2]⟩,7⟩,⟨⟨22,[5,2]⟩,7⟩,⟨⟨52,[]⟩,5⟩,⟨⟨52,[]⟩,7⟩,⟨⟨53,[]⟩,18⟩,⟨⟨53,[]⟩,19⟩,⟨⟨54,[7]⟩,5⟩,⟨⟨54,[7]⟩,7⟩,⟨⟨55,[7]⟩,20⟩,⟨⟨56,[7]⟩,21⟩,⟨⟨56,[7]⟩,22⟩,⟨⟨57,[]⟩,20⟩,⟨⟨57,[]⟩,21⟩,⟨⟨57,[]⟩,22⟩,⟨⟨58,[8]⟩,5⟩,⟨⟨58,[8]⟩,7⟩,⟨⟨58,[9]⟩,5⟩,⟨⟨58,[9]⟩,7⟩,⟨⟨59,[8]⟩,21⟩,⟨⟨59,[9]⟩,22⟩,⟨⟨60,[8]⟩,22⟩,⟨⟨60,[9]⟩,22⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[4],[5],[6],[13],[10],[11],[12],[15],[16],[14],[17],[19],[18],[20],[21],[22],[23],[24],[25],[27],[42],[35],[7],[28],[29],[30],[31],[32],[33],[36],[8],[38],[41],[39],[40],[44,45],[46],[47],[48],[55],[56],[37],[9],[50],[51],[49],[52],[53],[54],[26],[34],[43],[58],[57],[60],[59],[61],[61],[64],[65],[66],[67,68],[69,70],[69,70],[71],[71],[72],[72],[62],[73,74],[63],[73,74]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem block24 : checkRange P V K states hints 24 12=true := by decide
theorem block36 : checkRange P V K states hints 36 12=true := by decide
theorem block48 : checkRange P V K states hints 48 12=true := by decide
theorem block60 : checkRange P V K states hints 60 12=true := by decide
theorem block72 : checkRange P V K states hints 72 3=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<75 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 by_cases h12 : i<24
 · exact range_sound block12 i (by omega) h12 hi
 by_cases h24 : i<36
 · exact range_sound block24 i (by omega) h24 hi
 by_cases h36 : i<48
 · exact range_sound block36 i (by omega) h36 hi
 by_cases h48 : i<60
 · exact range_sound block48 i (by omega) h48 hi
 by_cases h60 : i<72
 · exact range_sound block60 i (by omega) h60 hi
 exact range_sound block72 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def terms : Array Term := #[(.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))),(.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))))))),(.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.lam (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0),(.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))),(.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))),(.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))),(.var 1),(.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))),(.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)),(.app (.var 2) (.app (.var 1) (.var 0))),(.var 2),(.app (.var 1) (.var 0)),(.var 1),(.var 0),(.var 2),(.lam (.lam (.var 0))),(.lam (.var 0)),(.var 0),(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))))))),(.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))))),(.app (.var 0) (.lam (.lam (.var 1)))),(.var 0),(.lam (.lam (.var 1))),(.lam (.var 1)),(.var 1),(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))))),(.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))),(.app (.var 0) (.lam (.lam (.var 1)))),(.var 0),(.lam (.lam (.var 1))),(.lam (.var 1)),(.var 1),(.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))),(.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))),(.app (.var 0) (.lam (.lam (.var 0)))),(.var 0),(.lam (.lam (.var 0))),(.lam (.var 0)),(.var 0),(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))),(.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)),(.app (.var 0) (.lam (.lam (.var 1)))),(.var 0),(.lam (.lam (.var 1))),(.lam (.var 1)),(.var 1),(.var 4),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0)]
def termAt (p : Nat) : Term := terms[p]?.getD (.var 0)
def aligns (p : Nat) : Bool := match P p with
 | .opaque => true
 | .var i => decide (termAt p = Term.var i)
 | .lam b => decide (termAt p = Term.lam (termAt b))
 | .app f a => decide (termAt p = Term.app (termAt f) (termAt a))
theorem valid : (List.range code.size).all aligns = true := by decide
theorem every (p : Nat) : aligns p = true := by
 by_cases hp : p < code.size
 · exact List.all_eq_true.mp valid p (List.mem_range.mpr hp)
 · have hz : code[p]? = none := Array.getElem?_eq_none (by omega)
   simp [aligns,P,hz]
def model : Model P where
 term := termAt
 var_eq := by intro p i h; simpa [aligns,h] using every p
 lam_eq := by intro p b h; simpa [aligns,h] using every p
 app_eq := by intro p f a h; simpa [aligns,h] using every p
theorem excluded : ¬ IsSelfInterpreter e302824747950 := by
 intro he
 have hp : replay [] (call e302824747950 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R302824747950
