import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302796895118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e302796895118 : Closed e302796895118 ∧ code e302796895118 = 1402308522894 := by decide
theorem cert_e302796895118 : check e302796895118 [[],[]] .three = true := by decide
def e302796895130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302796895130 : Closed e302796895130 ∧ code e302796895130 = 1402308522906 := by decide
theorem cert_e302796895130 : check e302796895130 [[],[]] .three = true := by decide
def e302796895174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302796895174 : Closed e302796895174 ∧ code e302796895174 = 1402308522950 := by decide
theorem cert_e302796895174 : check e302796895174 [[],[]] .three = true := by decide
def e302796895198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 3)))))))))
theorem wire_e302796895198 : Closed e302796895198 ∧ code e302796895198 = 1402308522974 := by decide
theorem cert_e302796895198 : check e302796895198 [[],[]] .three = true := by decide
def e302796895214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 2)))))))))
theorem wire_e302796895214 : Closed e302796895214 ∧ code e302796895214 = 1402308522990 := by decide
theorem cert_e302796895214 : check e302796895214 [[],[]] .three = true := by decide
def e302797041118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e302797041118 : Closed e302797041118 ∧ code e302797041118 = 1402308668894 := by decide
theorem cert_e302797041118 : check e302797041118 [[],[]] .smaller = true := by decide
def e302797041134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e302797041134 : Closed e302797041134 ∧ code e302797041134 = 1402308668910 := by decide
theorem cert_e302797041134 : check e302797041134 [[],[]] .smaller = true := by decide
def e302797041374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e302797041374 : Closed e302797041374 ∧ code e302797041374 = 1402308669150 := by decide
theorem cert_e302797041374 : check e302797041374 [[],[]] .smaller = true := by decide
def e302797041398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e302797041398 : Closed e302797041398 ∧ code e302797041398 = 1402308669174 := by decide
theorem cert_e302797041398 : check e302797041398 [[],[]] .smaller = true := by decide
def e302797041502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e302797041502 : Closed e302797041502 ∧ code e302797041502 = 1402308669278 := by decide
theorem cert_e302797041502 : check e302797041502 [[],[]] .smaller = true := by decide
def e302797041530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e302797041530 : Closed e302797041530 ∧ code e302797041530 = 1402308669306 := by decide
theorem cert_e302797041530 : check e302797041530 [[],[]] .smaller = true := by decide
def e302797041582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e302797041582 : Closed e302797041582 ∧ code e302797041582 = 1402308669358 := by decide
theorem cert_e302797041582 : check e302797041582 [[],[]] .smaller = true := by decide
def e302797041590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e302797041590 : Closed e302797041590 ∧ code e302797041590 = 1402308669366 := by decide
theorem cert_e302797041590 : check e302797041590 [[],[]] .smaller = true := by decide
def e302797041594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e302797041594 : Closed e302797041594 ∧ code e302797041594 = 1402308669370 := by decide
theorem cert_e302797041594 : check e302797041594 [[],[]] .smaller = true := by decide
def e302797042654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e302797042654 : Closed e302797042654 ∧ code e302797042654 = 1402308670430 := by decide
theorem cert_e302797042654 : check e302797042654 [[],[]] .smaller = true := by decide
def e302797042670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e302797042670 : Closed e302797042670 ∧ code e302797042670 = 1402308670446 := by decide
theorem cert_e302797042670 : check e302797042670 [[],[]] .smaller = true := by decide
def e302797044190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e302797044190 : Closed e302797044190 ∧ code e302797044190 = 1402308671966 := by decide
theorem cert_e302797044190 : check e302797044190 [[],[]] .smaller = true := by decide
def e302797044214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e302797044214 : Closed e302797044214 ∧ code e302797044214 = 1402308671990 := by decide
theorem cert_e302797044214 : check e302797044214 [[],[]] .smaller = true := by decide
def e302797044958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e302797044958 : Closed e302797044958 ∧ code e302797044958 = 1402308672734 := by decide
theorem cert_e302797044958 : check e302797044958 [[],[]] .smaller = true := by decide
def e302797044986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e302797044986 : Closed e302797044986 ∧ code e302797044986 = 1402308672762 := by decide
theorem cert_e302797044986 : check e302797044986 [[],[]] .smaller = true := by decide
def e302797045358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e302797045358 : Closed e302797045358 ∧ code e302797045358 = 1402308673134 := by decide
theorem cert_e302797045358 : check e302797045358 [[],[]] .smaller = true := by decide
def e302797045366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e302797045366 : Closed e302797045366 ∧ code e302797045366 = 1402308673142 := by decide
theorem cert_e302797045366 : check e302797045366 [[],[]] .smaller = true := by decide
def e302797045370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e302797045370 : Closed e302797045370 ∧ code e302797045370 = 1402308673146 := by decide
theorem cert_e302797045370 : check e302797045370 [[],[]] .smaller = true := by decide
def e302797073758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e302797073758 : Closed e302797073758 ∧ code e302797073758 = 1402308701534 := by decide
theorem cert_e302797073758 : check e302797073758 [[],[]] .three = true := by decide
def e302797073774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302797073774 : Closed e302797073774 ∧ code e302797073774 = 1402308701550 := by decide
theorem cert_e302797073774 : check e302797073774 [[],[]] .smaller = true := by decide
def e302797073782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302797073782 : Closed e302797073782 ∧ code e302797073782 = 1402308701558 := by decide
theorem cert_e302797073782 : check e302797073782 [[],[]] .smaller = true := by decide
def e302797073786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e302797073786 : Closed e302797073786 ∧ code e302797073786 = 1402308701562 := by decide
theorem cert_e302797073786 : check e302797073786 [[],[]] .three = true := by decide
def e302797073838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302797073838 : Closed e302797073838 ∧ code e302797073838 = 1402308701614 := by decide
theorem cert_e302797073838 : check e302797073838 [[],[]] .smaller = true := by decide
def e302797073850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302797073850 : Closed e302797073850 ∧ code e302797073850 = 1402308701626 := by decide
theorem cert_e302797073850 : check e302797073850 [[],[]] .smaller = true := by decide
def e302797073878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302797073878 : Closed e302797073878 ∧ code e302797073878 = 1402308701654 := by decide
theorem cert_e302797073878 : check e302797073878 [[],[]] .smaller = true := by decide
def e302797073882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302797073882 : Closed e302797073882 ∧ code e302797073882 = 1402308701658 := by decide
theorem cert_e302797073882 : check e302797073882 [[],[]] .smaller = true := by decide
def e302797073898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e302797073898 : Closed e302797073898 ∧ code e302797073898 = 1402308701674 := by decide
theorem cert_e302797073898 : check e302797073898 [[],[]] .three = true := by decide
def e302797074094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e302797074094 : Closed e302797074094 ∧ code e302797074094 = 1402308701870 := by decide
theorem cert_e302797074094 : check e302797074094 [[],[]] .smaller = true := by decide
def e302797074106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e302797074106 : Closed e302797074106 ∧ code e302797074106 = 1402308701882 := by decide
theorem cert_e302797074106 : check e302797074106 [[],[]] .smaller = true := by decide
def e302797074154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e302797074154 : Closed e302797074154 ∧ code e302797074154 = 1402308701930 := by decide
theorem cert_e302797074154 : check e302797074154 [[],[]] .smaller = true := by decide
def e302797074262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e302797074262 : Closed e302797074262 ∧ code e302797074262 = 1402308702038 := by decide
theorem cert_e302797074262 : check e302797074262 [[],[]] .smaller = true := by decide
def e302797074266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e302797074266 : Closed e302797074266 ∧ code e302797074266 = 1402308702042 := by decide
theorem cert_e302797074266 : check e302797074266 [[],[]] .smaller = true := by decide
def e302797074282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e302797074282 : Closed e302797074282 ∧ code e302797074282 = 1402308702058 := by decide
theorem cert_e302797074282 : check e302797074282 [[],[]] .smaller = true := by decide
def e302797074346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e302797074346 : Closed e302797074346 ∧ code e302797074346 = 1402308702122 := by decide
theorem cert_e302797074346 : check e302797074346 [[],[]] .three = true := by decide
def e302797074910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e302797074910 : Closed e302797074910 ∧ code e302797074910 = 1402308702686 := by decide
theorem cert_e302797074910 : check e302797074910 [[],[]] .three = true := by decide
def e302797074926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2))))))))
theorem wire_e302797074926 : Closed e302797074926 ∧ code e302797074926 = 1402308702702 := by decide
theorem cert_e302797074926 : check e302797074926 [[],[]] .smaller = true := by decide
def e302797074934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e302797074934 : Closed e302797074934 ∧ code e302797074934 = 1402308702710 := by decide
theorem cert_e302797074934 : check e302797074934 [[],[]] .three = true := by decide
def e302797075294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e302797075294 : Closed e302797075294 ∧ code e302797075294 = 1402308703070 := by decide
theorem cert_e302797075294 : check e302797075294 [[],[]] .three = true := by decide
def e302797075310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302797075310 : Closed e302797075310 ∧ code e302797075310 = 1402308703086 := by decide
theorem cert_e302797075310 : check e302797075310 [[],[]] .smaller = true := by decide
def e302797075318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302797075318 : Closed e302797075318 ∧ code e302797075318 = 1402308703094 := by decide
theorem cert_e302797075318 : check e302797075318 [[],[]] .smaller = true := by decide
def e302797075322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e302797075322 : Closed e302797075322 ∧ code e302797075322 = 1402308703098 := by decide
theorem cert_e302797075322 : check e302797075322 [[],[]] .three = true := by decide
def e302797075374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302797075374 : Closed e302797075374 ∧ code e302797075374 = 1402308703150 := by decide
theorem cert_e302797075374 : check e302797075374 [[],[]] .smaller = true := by decide
def e302797075386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302797075386 : Closed e302797075386 ∧ code e302797075386 = 1402308703162 := by decide
theorem cert_e302797075386 : check e302797075386 [[],[]] .smaller = true := by decide
def e302797075414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302797075414 : Closed e302797075414 ∧ code e302797075414 = 1402308703190 := by decide
theorem cert_e302797075414 : check e302797075414 [[],[]] .smaller = true := by decide
def e302797075418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302797075418 : Closed e302797075418 ∧ code e302797075418 = 1402308703194 := by decide
theorem cert_e302797075418 : check e302797075418 [[],[]] .smaller = true := by decide
def e302797075434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e302797075434 : Closed e302797075434 ∧ code e302797075434 = 1402308703210 := by decide
theorem cert_e302797075434 : check e302797075434 [[],[]] .three = true := by decide
def e302797075678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302797075678 : Closed e302797075678 ∧ code e302797075678 = 1402308703454 := by decide
theorem cert_e302797075678 : check e302797075678 [[],[]] .three = true := by decide
def e302797075694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302797075694 : Closed e302797075694 ∧ code e302797075694 = 1402308703470 := by decide
theorem cert_e302797075694 : check e302797075694 [[],[]] .smaller = true := by decide
def e302797075702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302797075702 : Closed e302797075702 ∧ code e302797075702 = 1402308703478 := by decide
theorem cert_e302797075702 : check e302797075702 [[],[]] .smaller = true := by decide
def e302797075706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302797075706 : Closed e302797075706 ∧ code e302797075706 = 1402308703482 := by decide
theorem cert_e302797075706 : check e302797075706 [[],[]] .three = true := by decide
def e302797076030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e302797076030 : Closed e302797076030 ∧ code e302797076030 = 1402308703806 := by decide
theorem cert_e302797076030 : check e302797076030 [[],[]] .three = true := by decide
def e302797076078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302797076078 : Closed e302797076078 ∧ code e302797076078 = 1402308703854 := by decide
theorem cert_e302797076078 : check e302797076078 [[],[]] .smaller = true := by decide
def e302797076090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302797076090 : Closed e302797076090 ∧ code e302797076090 = 1402308703866 := by decide
theorem cert_e302797076090 : check e302797076090 [[],[]] .smaller = true := by decide
def e302797076254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e302797076254 : Closed e302797076254 ∧ code e302797076254 = 1402308704030 := by decide
theorem cert_e302797076254 : check e302797076254 [[],[]] .smaller = true := by decide
def e302797076278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302797076278 : Closed e302797076278 ∧ code e302797076278 = 1402308704054 := by decide
theorem cert_e302797076278 : check e302797076278 [[],[]] .smaller = true := by decide
def e302797076282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302797076282 : Closed e302797076282 ∧ code e302797076282 = 1402308704058 := by decide
theorem cert_e302797076282 : check e302797076282 [[],[]] .smaller = true := by decide
def e302797076366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e302797076366 : Closed e302797076366 ∧ code e302797076366 = 1402308704142 := by decide
theorem cert_e302797076366 : check e302797076366 [[],[]] .three = true := by decide
def e302797076378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302797076378 : Closed e302797076378 ∧ code e302797076378 = 1402308704154 := by decide
theorem cert_e302797076378 : check e302797076378 [[],[]] .three = true := by decide
def e302797076702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e302797076702 : Closed e302797076702 ∧ code e302797076702 = 1402308704478 := by decide
theorem cert_e302797076702 : check e302797076702 [[],[]] .three = true := by decide
def e302797076730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e302797076730 : Closed e302797076730 ∧ code e302797076730 = 1402308704506 := by decide
theorem cert_e302797076730 : check e302797076730 [[],[]] .three = true := by decide
def e302797076910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e302797076910 : Closed e302797076910 ∧ code e302797076910 = 1402308704686 := by decide
theorem cert_e302797076910 : check e302797076910 [[],[]] .smaller = true := by decide
def e302797076922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e302797076922 : Closed e302797076922 ∧ code e302797076922 = 1402308704698 := by decide
theorem cert_e302797076922 : check e302797076922 [[],[]] .smaller = true := by decide
def e302797076970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e302797076970 : Closed e302797076970 ∧ code e302797076970 = 1402308704746 := by decide
theorem cert_e302797076970 : check e302797076970 [[],[]] .smaller = true := by decide
def e302797077054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e302797077054 : Closed e302797077054 ∧ code e302797077054 = 1402308704830 := by decide
theorem cert_e302797077054 : check e302797077054 [[],[]] .three = true := by decide
def e302797077102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302797077102 : Closed e302797077102 ∧ code e302797077102 = 1402308704878 := by decide
theorem cert_e302797077102 : check e302797077102 [[],[]] .smaller = true := by decide
def e302797077114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302797077114 : Closed e302797077114 ∧ code e302797077114 = 1402308704890 := by decide
theorem cert_e302797077114 : check e302797077114 [[],[]] .smaller = true := by decide
def e302797077402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302797077402 : Closed e302797077402 ∧ code e302797077402 = 1402308705178 := by decide
theorem cert_e302797077402 : check e302797077402 [[],[]] .smaller = true := by decide
def e302797077446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e302797077446 : Closed e302797077446 ∧ code e302797077446 = 1402308705222 := by decide
theorem cert_e302797077446 : check e302797077446 [[],[]] .three = true := by decide
def e302797077614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302797077614 : Closed e302797077614 ∧ code e302797077614 = 1402308705390 := by decide
theorem cert_e302797077614 : check e302797077614 [[],[]] .smaller = true := by decide
def e302797077626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302797077626 : Closed e302797077626 ∧ code e302797077626 = 1402308705402 := by decide
theorem cert_e302797077626 : check e302797077626 [[],[]] .smaller = true := by decide
def e302797077718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e302797077718 : Closed e302797077718 ∧ code e302797077718 = 1402308705494 := by decide
theorem cert_e302797077718 : check e302797077718 [[],[]] .smaller = true := by decide
def e302797077722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e302797077722 : Closed e302797077722 ∧ code e302797077722 = 1402308705498 := by decide
theorem cert_e302797077722 : check e302797077722 [[],[]] .smaller = true := by decide
def e302797077738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e302797077738 : Closed e302797077738 ∧ code e302797077738 = 1402308705514 := by decide
theorem cert_e302797077738 : check e302797077738 [[],[]] .smaller = true := by decide
def e302797077790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302797077790 : Closed e302797077790 ∧ code e302797077790 = 1402308705566 := by decide
theorem cert_e302797077790 : check e302797077790 [[],[]] .smaller = true := by decide
def e302797077814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302797077814 : Closed e302797077814 ∧ code e302797077814 = 1402308705590 := by decide
theorem cert_e302797077814 : check e302797077814 [[],[]] .smaller = true := by decide
def e302797077818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302797077818 : Closed e302797077818 ∧ code e302797077818 = 1402308705594 := by decide
theorem cert_e302797077818 : check e302797077818 [[],[]] .smaller = true := by decide
def e302797077914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302797077914 : Closed e302797077914 ∧ code e302797077914 = 1402308705690 := by decide
theorem cert_e302797077914 : check e302797077914 [[],[]] .smaller = true := by decide
def e302797077958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302797077958 : Closed e302797077958 ∧ code e302797077958 = 1402308705734 := by decide
theorem cert_e302797077958 : check e302797077958 [[],[]] .smaller = true := by decide
def e302797077982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 3))))))))
theorem wire_e302797077982 : Closed e302797077982 ∧ code e302797077982 = 1402308705758 := by decide
theorem cert_e302797077982 : check e302797077982 [[],[]] .three = true := by decide
def e302797077998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 2))))))))
theorem wire_e302797077998 : Closed e302797077998 ∧ code e302797077998 = 1402308705774 := by decide
theorem cert_e302797077998 : check e302797077998 [[],[]] .three = true := by decide
def e302797078070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302797078070 : Closed e302797078070 ∧ code e302797078070 = 1402308705846 := by decide
theorem cert_e302797078070 : check e302797078070 [[],[]] .three = true := by decide
def e302797078074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302797078074 : Closed e302797078074 ∧ code e302797078074 = 1402308705850 := by decide
theorem cert_e302797078074 : check e302797078074 [[],[]] .three = true := by decide
def e302797078122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e302797078122 : Closed e302797078122 ∧ code e302797078122 = 1402308705898 := by decide
theorem cert_e302797078122 : check e302797078122 [[],[]] .three = true := by decide
def e302797078158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302797078158 : Closed e302797078158 ∧ code e302797078158 = 1402308705934 := by decide
theorem cert_e302797078158 : check e302797078158 [[],[]] .three = true := by decide
def e302797078170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302797078170 : Closed e302797078170 ∧ code e302797078170 = 1402308705946 := by decide
theorem cert_e302797078170 : check e302797078170 [[],[]] .three = true := by decide
def e302797078214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302797078214 : Closed e302797078214 ∧ code e302797078214 = 1402308705990 := by decide
theorem cert_e302797078214 : check e302797078214 [[],[]] .three = true := by decide
def e302797078254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 2))))))))
theorem wire_e302797078254 : Closed e302797078254 ∧ code e302797078254 = 1402308706030 := by decide
theorem cert_e302797078254 : check e302797078254 [[],[]] .three = true := by decide
def e302797079486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e302797079486 : Closed e302797079486 ∧ code e302797079486 = 1402308707262 := by decide
theorem cert_e302797079486 : check e302797079486 [[],[]] .three = true := by decide
def e302797079518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e302797079518 : Closed e302797079518 ∧ code e302797079518 = 1402308707294 := by decide
theorem cert_e302797079518 : check e302797079518 [[],[]] .smaller = true := by decide
def e302797079534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e302797079534 : Closed e302797079534 ∧ code e302797079534 = 1402308707310 := by decide
theorem cert_e302797079534 : check e302797079534 [[],[]] .smaller = true := by decide
def e302797079542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e302797079542 : Closed e302797079542 ∧ code e302797079542 = 1402308707318 := by decide
theorem cert_e302797079542 : check e302797079542 [[],[]] .three = true := by decide
def e302797081438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e302797081438 : Closed e302797081438 ∧ code e302797081438 = 1402308709214 := by decide
theorem cert_e302797081438 : check e302797081438 [[],[]] .three = true := by decide
def e302797081454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302797081454 : Closed e302797081454 ∧ code e302797081454 = 1402308709230 := by decide
theorem cert_e302797081454 : check e302797081454 [[],[]] .smaller = true := by decide
def e302797081462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302797081462 : Closed e302797081462 ∧ code e302797081462 = 1402308709238 := by decide
theorem cert_e302797081462 : check e302797081462 [[],[]] .smaller = true := by decide
def e302797081466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e302797081466 : Closed e302797081466 ∧ code e302797081466 = 1402308709242 := by decide
theorem cert_e302797081466 : check e302797081466 [[],[]] .three = true := by decide
def e302797081518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302797081518 : Closed e302797081518 ∧ code e302797081518 = 1402308709294 := by decide
theorem cert_e302797081518 : check e302797081518 [[],[]] .smaller = true := by decide
def e302797081530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302797081530 : Closed e302797081530 ∧ code e302797081530 = 1402308709306 := by decide
theorem cert_e302797081530 : check e302797081530 [[],[]] .smaller = true := by decide
def e302797081558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302797081558 : Closed e302797081558 ∧ code e302797081558 = 1402308709334 := by decide
theorem cert_e302797081558 : check e302797081558 [[],[]] .smaller = true := by decide
def e302797081562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302797081562 : Closed e302797081562 ∧ code e302797081562 = 1402308709338 := by decide
theorem cert_e302797081562 : check e302797081562 [[],[]] .smaller = true := by decide
def e302797081578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e302797081578 : Closed e302797081578 ∧ code e302797081578 = 1402308709354 := by decide
theorem cert_e302797081578 : check e302797081578 [[],[]] .three = true := by decide
def e302797081822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e302797081822 : Closed e302797081822 ∧ code e302797081822 = 1402308709598 := by decide
theorem cert_e302797081822 : check e302797081822 [[],[]] .three = true := by decide
def e302797081838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302797081838 : Closed e302797081838 ∧ code e302797081838 = 1402308709614 := by decide
theorem cert_e302797081838 : check e302797081838 [[],[]] .smaller = true := by decide
def e302797081846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302797081846 : Closed e302797081846 ∧ code e302797081846 = 1402308709622 := by decide
theorem cert_e302797081846 : check e302797081846 [[],[]] .smaller = true := by decide
def e302797081850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e302797081850 : Closed e302797081850 ∧ code e302797081850 = 1402308709626 := by decide
theorem cert_e302797081850 : check e302797081850 [[],[]] .three = true := by decide
def e302797082174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e302797082174 : Closed e302797082174 ∧ code e302797082174 = 1402308709950 := by decide
theorem cert_e302797082174 : check e302797082174 [[],[]] .three = true := by decide
def e302797082222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302797082222 : Closed e302797082222 ∧ code e302797082222 = 1402308709998 := by decide
theorem cert_e302797082222 : check e302797082222 [[],[]] .smaller = true := by decide
def e302797082234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302797082234 : Closed e302797082234 ∧ code e302797082234 = 1402308710010 := by decide
theorem cert_e302797082234 : check e302797082234 [[],[]] .smaller = true := by decide
def e302797082398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e302797082398 : Closed e302797082398 ∧ code e302797082398 = 1402308710174 := by decide
theorem cert_e302797082398 : check e302797082398 [[],[]] .smaller = true := by decide
def e302797082422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302797082422 : Closed e302797082422 ∧ code e302797082422 = 1402308710198 := by decide
theorem cert_e302797082422 : check e302797082422 [[],[]] .smaller = true := by decide
def e302797082426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302797082426 : Closed e302797082426 ∧ code e302797082426 = 1402308710202 := by decide
theorem cert_e302797082426 : check e302797082426 [[],[]] .smaller = true := by decide
def e302797082510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e302797082510 : Closed e302797082510 ∧ code e302797082510 = 1402308710286 := by decide
theorem cert_e302797082510 : check e302797082510 [[],[]] .three = true := by decide
def e302797082522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e302797082522 : Closed e302797082522 ∧ code e302797082522 = 1402308710298 := by decide
theorem cert_e302797082522 : check e302797082522 [[],[]] .three = true := by decide
def e302797087198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e302797087198 : Closed e302797087198 ∧ code e302797087198 = 1402308714974 := by decide
theorem cert_e302797087198 : check e302797087198 [[],[]] .smaller = true := by decide
def e302797087222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e302797087222 : Closed e302797087222 ∧ code e302797087222 = 1402308714998 := by decide
theorem cert_e302797087222 : check e302797087222 [[],[]] .smaller = true := by decide
def e302797088174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e302797088174 : Closed e302797088174 ∧ code e302797088174 = 1402308715950 := by decide
theorem cert_e302797088174 : check e302797088174 [[],[]] .smaller = true := by decide
def e302797088186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e302797088186 : Closed e302797088186 ∧ code e302797088186 = 1402308715962 := by decide
theorem cert_e302797088186 : check e302797088186 [[],[]] .smaller = true := by decide
def e302797088234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e302797088234 : Closed e302797088234 ∧ code e302797088234 = 1402308716010 := by decide
theorem cert_e302797088234 : check e302797088234 [[],[]] .smaller = true := by decide
def e302797088318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e302797088318 : Closed e302797088318 ∧ code e302797088318 = 1402308716094 := by decide
theorem cert_e302797088318 : check e302797088318 [[],[]] .three = true := by decide
def e302797088366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e302797088366 : Closed e302797088366 ∧ code e302797088366 = 1402308716142 := by decide
theorem cert_e302797088366 : check e302797088366 [[],[]] .smaller = true := by decide
def e302797088378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e302797088378 : Closed e302797088378 ∧ code e302797088378 = 1402308716154 := by decide
theorem cert_e302797088378 : check e302797088378 [[],[]] .smaller = true := by decide
def e302797088666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e302797088666 : Closed e302797088666 ∧ code e302797088666 = 1402308716442 := by decide
theorem cert_e302797088666 : check e302797088666 [[],[]] .smaller = true := by decide
def e302797088710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e302797088710 : Closed e302797088710 ∧ code e302797088710 = 1402308716486 := by decide
theorem cert_e302797088710 : check e302797088710 [[],[]] .three = true := by decide
def e302797091054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e302797091054 : Closed e302797091054 ∧ code e302797091054 = 1402308718830 := by decide
theorem cert_e302797091054 : check e302797091054 [[],[]] .smaller = true := by decide
def e302797091062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e302797091062 : Closed e302797091062 ∧ code e302797091062 = 1402308718838 := by decide
theorem cert_e302797091062 : check e302797091062 [[],[]] .smaller = true := by decide
def e302797091542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302797091542 : Closed e302797091542 ∧ code e302797091542 = 1402308719318 := by decide
theorem cert_e302797091542 : check e302797091542 [[],[]] .smaller = true := by decide
def e302797091546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302797091546 : Closed e302797091546 ∧ code e302797091546 = 1402308719322 := by decide
theorem cert_e302797091546 : check e302797091546 [[],[]] .smaller = true := by decide
def e302797091562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302797091562 : Closed e302797091562 ∧ code e302797091562 = 1402308719338 := by decide
theorem cert_e302797091562 : check e302797091562 [[],[]] .smaller = true := by decide
def e302797091614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302797091614 : Closed e302797091614 ∧ code e302797091614 = 1402308719390 := by decide
theorem cert_e302797091614 : check e302797091614 [[],[]] .smaller = true := by decide
def e302797091638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302797091638 : Closed e302797091638 ∧ code e302797091638 = 1402308719414 := by decide
theorem cert_e302797091638 : check e302797091638 [[],[]] .smaller = true := by decide
def e302797091642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302797091642 : Closed e302797091642 ∧ code e302797091642 = 1402308719418 := by decide
theorem cert_e302797091642 : check e302797091642 [[],[]] .smaller = true := by decide
def e302797091738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302797091738 : Closed e302797091738 ∧ code e302797091738 = 1402308719514 := by decide
theorem cert_e302797091738 : check e302797091738 [[],[]] .smaller = true := by decide
def e302797091782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302797091782 : Closed e302797091782 ∧ code e302797091782 = 1402308719558 := by decide
theorem cert_e302797091782 : check e302797091782 [[],[]] .smaller = true := by decide
def e302797091806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 3)))))))))
theorem wire_e302797091806 : Closed e302797091806 ∧ code e302797091806 = 1402308719582 := by decide
theorem cert_e302797091806 : check e302797091806 [[],[]] .three = true := by decide
def e302797091822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 2)))))))))
theorem wire_e302797091822 : Closed e302797091822 ∧ code e302797091822 = 1402308719598 := by decide
theorem cert_e302797091822 : check e302797091822 [[],[]] .three = true := by decide
def e302797092982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e302797092982 : Closed e302797092982 ∧ code e302797092982 = 1402308720758 := by decide
theorem cert_e302797092982 : check e302797092982 [[],[]] .three = true := by decide
def e302797093226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e302797093226 : Closed e302797093226 ∧ code e302797093226 = 1402308721002 := by decide
theorem cert_e302797093226 : check e302797093226 [[],[]] .three = true := by decide
def e302797093262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302797093262 : Closed e302797093262 ∧ code e302797093262 = 1402308721038 := by decide
theorem cert_e302797093262 : check e302797093262 [[],[]] .three = true := by decide
def e302797093274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e302797093274 : Closed e302797093274 ∧ code e302797093274 = 1402308721050 := by decide
theorem cert_e302797093274 : check e302797093274 [[],[]] .three = true := by decide
def e302797093318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302797093318 : Closed e302797093318 ∧ code e302797093318 = 1402308721094 := by decide
theorem cert_e302797093318 : check e302797093318 [[],[]] .three = true := by decide
def e302797093358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 2)))))))))
theorem wire_e302797093358 : Closed e302797093358 ∧ code e302797093358 = 1402308721134 := by decide
theorem cert_e302797093358 : check e302797093358 [[],[]] .three = true := by decide
def e302797166302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302797166302 : Closed e302797166302 ∧ code e302797166302 = 1402308794078 := by decide
theorem cert_e302797166302 : check e302797166302 [[],[]] .smaller = true := by decide
def e302797166326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302797166326 : Closed e302797166326 ∧ code e302797166326 = 1402308794102 := by decide
theorem cert_e302797166326 : check e302797166326 [[],[]] .smaller = true := by decide
def e302797166430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302797166430 : Closed e302797166430 ∧ code e302797166430 = 1402308794206 := by decide
theorem cert_e302797166430 : check e302797166430 [[],[]] .smaller = true := by decide
def e302797166446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e302797166446 : Closed e302797166446 ∧ code e302797166446 = 1402308794222 := by decide
theorem cert_e302797166446 : check e302797166446 [[],[]] .smaller = true := by decide
def e302797166454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e302797166454 : Closed e302797166454 ∧ code e302797166454 = 1402308794230 := by decide
theorem cert_e302797166454 : check e302797166454 [[],[]] .smaller = true := by decide
def e302797166458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302797166458 : Closed e302797166458 ∧ code e302797166458 = 1402308794234 := by decide
theorem cert_e302797166458 : check e302797166458 [[],[]] .smaller = true := by decide
def e302797166518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e302797166518 : Closed e302797166518 ∧ code e302797166518 = 1402308794294 := by decide
theorem cert_e302797166518 : check e302797166518 [[],[]] .smaller = true := by decide
def e302797166550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302797166550 : Closed e302797166550 ∧ code e302797166550 = 1402308794326 := by decide
theorem cert_e302797166550 : check e302797166550 [[],[]] .smaller = true := by decide
def e302797166554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302797166554 : Closed e302797166554 ∧ code e302797166554 = 1402308794330 := by decide
theorem cert_e302797166554 : check e302797166554 [[],[]] .smaller = true := by decide
def e302797167070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302797167070 : Closed e302797167070 ∧ code e302797167070 = 1402308794846 := by decide
theorem cert_e302797167070 : check e302797167070 [[],[]] .smaller = true := by decide
def e302797167094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302797167094 : Closed e302797167094 ∧ code e302797167094 = 1402308794870 := by decide
theorem cert_e302797167094 : check e302797167094 [[],[]] .smaller = true := by decide
def e302797167838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302797167838 : Closed e302797167838 ∧ code e302797167838 = 1402308795614 := by decide
theorem cert_e302797167838 : check e302797167838 [[],[]] .smaller = true := by decide
def e302797167854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e302797167854 : Closed e302797167854 ∧ code e302797167854 = 1402308795630 := by decide
theorem cert_e302797167854 : check e302797167854 [[],[]] .smaller = true := by decide
def e302797167862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e302797167862 : Closed e302797167862 ∧ code e302797167862 = 1402308795638 := by decide
theorem cert_e302797167862 : check e302797167862 [[],[]] .smaller = true := by decide
def e302797167866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302797167866 : Closed e302797167866 ∧ code e302797167866 = 1402308795642 := by decide
theorem cert_e302797167866 : check e302797167866 [[],[]] .smaller = true := by decide
end Blc.Floor40
