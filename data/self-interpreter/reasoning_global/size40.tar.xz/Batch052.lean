import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302801887030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302801887030 : Closed e302801887030 ∧ code e302801887030 = 1402313514806 := by decide
theorem cert_e302801887030 : check e302801887030 [[],[]] .chain = true := by decide
def e302801887034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302801887034 : Closed e302801887034 ∧ code e302801887034 = 1402313514810 := by decide
theorem cert_e302801887034 : check e302801887034 [[],[]] .chain = true := by decide
def e302801901806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e302801901806 : Closed e302801901806 ∧ code e302801901806 = 1402313529582 := by decide
theorem cert_e302801901806 : check e302801901806 [[],[]] .chain = true := by decide
def e302801901814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e302801901814 : Closed e302801901814 ∧ code e302801901814 = 1402313529590 := by decide
theorem cert_e302801901814 : check e302801901814 [[],[]] .chain = true := by decide
def e302801902366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e302801902366 : Closed e302801902366 ∧ code e302801902366 = 1402313530142 := by decide
theorem cert_e302801902366 : check e302801902366 [[],[]] .chain = true := by decide
def e302801902478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e302801902478 : Closed e302801902478 ∧ code e302801902478 = 1402313530254 := by decide
theorem cert_e302801902478 : check e302801902478 [[],[]] .chain = true := by decide
def e302801902702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302801902702 : Closed e302801902702 ∧ code e302801902702 = 1402313530478 := by decide
theorem cert_e302801902702 : check e302801902702 [[],[]] .chain = true := by decide
def e302801902714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302801902714 : Closed e302801902714 ∧ code e302801902714 = 1402313530490 := by decide
theorem cert_e302801902714 : check e302801902714 [[],[]] .chain = true := by decide
def e302801902878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302801902878 : Closed e302801902878 ∧ code e302801902878 = 1402313530654 := by decide
theorem cert_e302801902878 : check e302801902878 [[],[]] .chain = true := by decide
def e302801903046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302801903046 : Closed e302801903046 ∧ code e302801903046 = 1402313530822 := by decide
theorem cert_e302801903046 : check e302801903046 [[],[]] .chain = true := by decide
def e302801903158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302801903158 : Closed e302801903158 ∧ code e302801903158 = 1402313530934 := by decide
theorem cert_e302801903158 : check e302801903158 [[],[]] .chain = true := by decide
def e302801903162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302801903162 : Closed e302801903162 ∧ code e302801903162 = 1402313530938 := by decide
theorem cert_e302801903162 : check e302801903162 [[],[]] .chain = true := by decide
def e302801903246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302801903246 : Closed e302801903246 ∧ code e302801903246 = 1402313531022 := by decide
theorem cert_e302801903246 : check e302801903246 [[],[]] .chain = true := by decide
def e302801903302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302801903302 : Closed e302801903302 ∧ code e302801903302 = 1402313531078 := by decide
theorem cert_e302801903302 : check e302801903302 [[],[]] .chain = true := by decide
def e302801905438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e302801905438 : Closed e302801905438 ∧ code e302801905438 = 1402313533214 := by decide
theorem cert_e302801905438 : check e302801905438 [[],[]] .chain = true := by decide
def e302801905550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e302801905550 : Closed e302801905550 ∧ code e302801905550 = 1402313533326 := by decide
theorem cert_e302801905550 : check e302801905550 [[],[]] .chain = true := by decide
def e302801907934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e302801907934 : Closed e302801907934 ∧ code e302801907934 = 1402313535710 := by decide
theorem cert_e302801907934 : check e302801907934 [[],[]] .chain = true := by decide
def e302801907962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e302801907962 : Closed e302801907962 ∧ code e302801907962 = 1402313535738 := by decide
theorem cert_e302801907962 : check e302801907962 [[],[]] .chain = true := by decide
def e302801908510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302801908510 : Closed e302801908510 ∧ code e302801908510 = 1402313536286 := by decide
theorem cert_e302801908510 : check e302801908510 [[],[]] .chain = true := by decide
def e302801908678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302801908678 : Closed e302801908678 ∧ code e302801908678 = 1402313536454 := by decide
theorem cert_e302801908678 : check e302801908678 [[],[]] .chain = true := by decide
def e302801909870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e302801909870 : Closed e302801909870 ∧ code e302801909870 = 1402313537646 := by decide
theorem cert_e302801909870 : check e302801909870 [[],[]] .chain = true := by decide
def e302801909882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e302801909882 : Closed e302801909882 ∧ code e302801909882 = 1402313537658 := by decide
theorem cert_e302801909882 : check e302801909882 [[],[]] .chain = true := by decide
def e302801910158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302801910158 : Closed e302801910158 ∧ code e302801910158 = 1402313537934 := by decide
theorem cert_e302801910158 : check e302801910158 [[],[]] .chain = true := by decide
def e302801910214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302801910214 : Closed e302801910214 ∧ code e302801910214 = 1402313537990 := by decide
theorem cert_e302801910214 : check e302801910214 [[],[]] .chain = true := by decide
def e302801947486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e302801947486 : Closed e302801947486 ∧ code e302801947486 = 1402313575262 := by decide
theorem cert_e302801947486 : check e302801947486 [[],[]] .chain = true := by decide
def e302801947502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302801947502 : Closed e302801947502 ∧ code e302801947502 = 1402313575278 := by decide
theorem cert_e302801947502 : check e302801947502 [[],[]] .smaller = true := by decide
def e302801947510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302801947510 : Closed e302801947510 ∧ code e302801947510 = 1402313575286 := by decide
theorem cert_e302801947510 : check e302801947510 [[],[]] .smaller = true := by decide
def e302801947514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e302801947514 : Closed e302801947514 ∧ code e302801947514 = 1402313575290 := by decide
theorem cert_e302801947514 : check e302801947514 [[],[]] .chain = true := by decide
def e302801947566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302801947566 : Closed e302801947566 ∧ code e302801947566 = 1402313575342 := by decide
theorem cert_e302801947566 : check e302801947566 [[],[]] .smaller = true := by decide
def e302801947578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302801947578 : Closed e302801947578 ∧ code e302801947578 = 1402313575354 := by decide
theorem cert_e302801947578 : check e302801947578 [[],[]] .smaller = true := by decide
def e302801947606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302801947606 : Closed e302801947606 ∧ code e302801947606 = 1402313575382 := by decide
theorem cert_e302801947606 : check e302801947606 [[],[]] .smaller = true := by decide
def e302801947610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302801947610 : Closed e302801947610 ∧ code e302801947610 = 1402313575386 := by decide
theorem cert_e302801947610 : check e302801947610 [[],[]] .smaller = true := by decide
def e302801947626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e302801947626 : Closed e302801947626 ∧ code e302801947626 = 1402313575402 := by decide
theorem cert_e302801947626 : check e302801947626 [[],[]] .chain = true := by decide
def e302801947870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e302801947870 : Closed e302801947870 ∧ code e302801947870 = 1402313575646 := by decide
theorem cert_e302801947870 : check e302801947870 [[],[]] .chain = true := by decide
def e302801947886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302801947886 : Closed e302801947886 ∧ code e302801947886 = 1402313575662 := by decide
theorem cert_e302801947886 : check e302801947886 [[],[]] .smaller = true := by decide
def e302801947894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302801947894 : Closed e302801947894 ∧ code e302801947894 = 1402313575670 := by decide
theorem cert_e302801947894 : check e302801947894 [[],[]] .smaller = true := by decide
def e302801947898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e302801947898 : Closed e302801947898 ∧ code e302801947898 = 1402313575674 := by decide
theorem cert_e302801947898 : check e302801947898 [[],[]] .chain = true := by decide
def e302801948222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e302801948222 : Closed e302801948222 ∧ code e302801948222 = 1402313575998 := by decide
theorem cert_e302801948222 : check e302801948222 [[],[]] .chain = true := by decide
def e302801948270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302801948270 : Closed e302801948270 ∧ code e302801948270 = 1402313576046 := by decide
theorem cert_e302801948270 : check e302801948270 [[],[]] .smaller = true := by decide
def e302801948282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302801948282 : Closed e302801948282 ∧ code e302801948282 = 1402313576058 := by decide
theorem cert_e302801948282 : check e302801948282 [[],[]] .smaller = true := by decide
def e302801948470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302801948470 : Closed e302801948470 ∧ code e302801948470 = 1402313576246 := by decide
theorem cert_e302801948470 : check e302801948470 [[],[]] .smaller = true := by decide
def e302801948474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302801948474 : Closed e302801948474 ∧ code e302801948474 = 1402313576250 := by decide
theorem cert_e302801948474 : check e302801948474 [[],[]] .smaller = true := by decide
def e302801948558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e302801948558 : Closed e302801948558 ∧ code e302801948558 = 1402313576334 := by decide
theorem cert_e302801948558 : check e302801948558 [[],[]] .chain = true := by decide
def e302801948570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e302801948570 : Closed e302801948570 ∧ code e302801948570 = 1402313576346 := by decide
theorem cert_e302801948570 : check e302801948570 [[],[]] .chain = true := by decide
def e302801955950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302801955950 : Closed e302801955950 ∧ code e302801955950 = 1402313583726 := by decide
theorem cert_e302801955950 : check e302801955950 [[],[]] .chain = true := by decide
def e302801955962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302801955962 : Closed e302801955962 ∧ code e302801955962 = 1402313583738 := by decide
theorem cert_e302801955962 : check e302801955962 [[],[]] .chain = true := by decide
def e302801956126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302801956126 : Closed e302801956126 ∧ code e302801956126 = 1402313583902 := by decide
theorem cert_e302801956126 : check e302801956126 [[],[]] .chain = true := by decide
def e302801956294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302801956294 : Closed e302801956294 ∧ code e302801956294 = 1402313584070 := by decide
theorem cert_e302801956294 : check e302801956294 [[],[]] .chain = true := by decide
def e302801956398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e302801956398 : Closed e302801956398 ∧ code e302801956398 = 1402313584174 := by decide
theorem cert_e302801956398 : check e302801956398 [[],[]] .chain = true := by decide
def e302801956578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e302801956578 : Closed e302801956578 ∧ code e302801956578 = 1402313584354 := by decide
theorem cert_e302801956578 : check e302801956578 [[],[]] .chain = true := by decide
def e302801956590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e302801956590 : Closed e302801956590 ∧ code e302801956590 = 1402313584366 := by decide
theorem cert_e302801956590 : check e302801956590 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801956630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e302801956630 : Closed e302801956630 ∧ code e302801956630 = 1402313584406 := by decide
theorem cert_e302801956630 : check e302801956630 [[],[]] .chain = true := by decide
def e302801956634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302801956634 : Closed e302801956634 ∧ code e302801956634 = 1402313584410 := by decide
theorem cert_e302801956634 : check e302801956634 [[],[]] .chain = true := by decide
def e302801956678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302801956678 : Closed e302801956678 ∧ code e302801956678 = 1402313584454 := by decide
theorem cert_e302801956678 : check e302801956678 [[],[]] .chain = true := by decide
def e302801956706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e302801956706 : Closed e302801956706 ∧ code e302801956706 = 1402313584482 := by decide
theorem cert_e302801956706 : check e302801956706 [[],[]] .chain = true := by decide
def e302801956718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e302801956718 : Closed e302801956718 ∧ code e302801956718 = 1402313584494 := by decide
theorem cert_e302801956718 : check e302801956718 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801956726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e302801956726 : Closed e302801956726 ∧ code e302801956726 = 1402313584502 := by decide
theorem cert_e302801956726 : check e302801956726 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801957086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e302801957086 : Closed e302801957086 ∧ code e302801957086 = 1402313584862 := by decide
theorem cert_e302801957086 : check e302801957086 [[],[]] .chain = true := by decide
def e302801957114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e302801957114 : Closed e302801957114 ∧ code e302801957114 = 1402313584890 := by decide
theorem cert_e302801957114 : check e302801957114 [[],[]] .chain = true := by decide
def e302801957662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302801957662 : Closed e302801957662 ∧ code e302801957662 = 1402313585438 := by decide
theorem cert_e302801957662 : check e302801957662 [[],[]] .chain = true := by decide
def e302801957830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302801957830 : Closed e302801957830 ∧ code e302801957830 = 1402313585606 := by decide
theorem cert_e302801957830 : check e302801957830 [[],[]] .chain = true := by decide
def e302801958974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e302801958974 : Closed e302801958974 ∧ code e302801958974 = 1402313586750 := by decide
theorem cert_e302801958974 : check e302801958974 [[],[]] .chain = true := by decide
def e302801959394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e302801959394 : Closed e302801959394 ∧ code e302801959394 = 1402313587170 := by decide
theorem cert_e302801959394 : check e302801959394 [[],[]] .chain = true := by decide
def e302801959406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e302801959406 : Closed e302801959406 ∧ code e302801959406 = 1402313587182 := by decide
theorem cert_e302801959406 : check e302801959406 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801959966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e302801959966 : Closed e302801959966 ∧ code e302801959966 = 1402313587742 := by decide
theorem cert_e302801959966 : check e302801959966 [[],[]] .chain = true := by decide
def e302801959990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e302801959990 : Closed e302801959990 ∧ code e302801959990 = 1402313587766 := by decide
theorem cert_e302801959990 : check e302801959990 [[],[]] .chain = true := by decide
def e302801959994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e302801959994 : Closed e302801959994 ∧ code e302801959994 = 1402313587770 := by decide
theorem cert_e302801959994 : check e302801959994 [[],[]] .chain = true := by decide
def e302801960134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302801960134 : Closed e302801960134 ∧ code e302801960134 = 1402313587910 := by decide
theorem cert_e302801960134 : check e302801960134 [[],[]] .chain = true := by decide
def e302801960162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e302801960162 : Closed e302801960162 ∧ code e302801960162 = 1402313587938 := by decide
theorem cert_e302801960162 : check e302801960162 [[],[]] .chain = true := by decide
def e302801960174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e302801960174 : Closed e302801960174 ∧ code e302801960174 = 1402313587950 := by decide
theorem cert_e302801960174 : check e302801960174 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801960182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e302801960182 : Closed e302801960182 ∧ code e302801960182 = 1402313587958 := by decide
theorem cert_e302801960182 : check e302801960182 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801978798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e302801978798 : Closed e302801978798 ∧ code e302801978798 = 1402313606574 := by decide
private def t_e302801978798 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2))))))
theorem cert_e302801978798 : ¬ IsSelfInterpreter e302801978798 :=
  wIdentity (t := t_e302801978798) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]]) (t := (inv e302801978798)) (by decide)) (by decide)
def e302801978810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e302801978810 : Closed e302801978810 ∧ code e302801978810 = 1402313606586 := by decide
theorem cert_e302801978810 : check e302801978810 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e302801978858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e302801978858 : Closed e302801978858 ∧ code e302801978858 = 1402313606634 := by decide
theorem cert_e302801978858 : check e302801978858 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e302801978990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e302801978990 : Closed e302801978990 ∧ code e302801978990 = 1402313606766 := by decide
theorem cert_e302801978990 : check e302801978990 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e302801979002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e302801979002 : Closed e302801979002 ∧ code e302801979002 = 1402313606778 := by decide
theorem cert_e302801979002 : check e302801979002 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left]] .identityHead = true := by decide
def e302801979166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e302801979166 : Closed e302801979166 ∧ code e302801979166 = 1402313606942 := by decide
theorem cert_e302801979166 : check e302801979166 [[],[]] .chain = true := by decide
def e302801979278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e302801979278 : Closed e302801979278 ∧ code e302801979278 = 1402313607054 := by decide
theorem cert_e302801979278 : check e302801979278 [[],[]] .chain = true := by decide
def e302801979290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e302801979290 : Closed e302801979290 ∧ code e302801979290 = 1402313607066 := by decide
theorem cert_e302801979290 : check e302801979290 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e302801983030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302801983030 : Closed e302801983030 ∧ code e302801983030 = 1402313610806 := by decide
theorem cert_e302801983030 : check e302801983030 [[],[]] .chain = true := by decide
def e302801983034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302801983034 : Closed e302801983034 ∧ code e302801983034 = 1402313610810 := by decide
theorem cert_e302801983034 : check e302801983034 [[],[]] .chain = true := by decide
def e302801983118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302801983118 : Closed e302801983118 ∧ code e302801983118 = 1402313610894 := by decide
theorem cert_e302801983118 : check e302801983118 [[],[]] .chain = true := by decide
def e302801983174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302801983174 : Closed e302801983174 ∧ code e302801983174 = 1402313610950 := by decide
theorem cert_e302801983174 : check e302801983174 [[],[]] .chain = true := by decide
def e302801983254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))))))))
theorem wire_e302801983254 : Closed e302801983254 ∧ code e302801983254 = 1402313611030 := by decide
theorem cert_e302801983254 : check e302801983254 [[],[]] .chain = true := by decide
def e302801983258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e302801983258 : Closed e302801983258 ∧ code e302801983258 = 1402313611034 := by decide
theorem cert_e302801983258 : check e302801983258 [[],[]] .chain = true := by decide
def e302801983302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e302801983302 : Closed e302801983302 ∧ code e302801983302 = 1402313611078 := by decide
theorem cert_e302801983302 : check e302801983302 [[],[]] .chain = true := by decide
def e302801983330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e302801983330 : Closed e302801983330 ∧ code e302801983330 = 1402313611106 := by decide
theorem cert_e302801983330 : check e302801983330 [[],[]] .chain = true := by decide
def e302801983342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e302801983342 : Closed e302801983342 ∧ code e302801983342 = 1402313611118 := by decide
theorem cert_e302801983342 : check e302801983342 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801983350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e302801983350 : Closed e302801983350 ∧ code e302801983350 = 1402313611126 := by decide
theorem cert_e302801983350 : check e302801983350 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801983414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e302801983414 : Closed e302801983414 ∧ code e302801983414 = 1402313611190 := by decide
theorem cert_e302801983414 : check e302801983414 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e302801983598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e302801983598 : Closed e302801983598 ∧ code e302801983598 = 1402313611374 := by decide
theorem cert_e302801983598 : check e302801983598 [[],[]] .chain = true := by decide
def e302801983610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e302801983610 : Closed e302801983610 ∧ code e302801983610 = 1402313611386 := by decide
theorem cert_e302801983610 : check e302801983610 [[],[]] .chain = true := by decide
def e302801983886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302801983886 : Closed e302801983886 ∧ code e302801983886 = 1402313611662 := by decide
theorem cert_e302801983886 : check e302801983886 [[],[]] .chain = true := by decide
def e302801983942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302801983942 : Closed e302801983942 ∧ code e302801983942 = 1402313611718 := by decide
theorem cert_e302801983942 : check e302801983942 [[],[]] .chain = true := by decide
def e302801984542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 3))))))))))
theorem wire_e302801984542 : Closed e302801984542 ∧ code e302801984542 = 1402313612318 := by decide
theorem cert_e302801984542 : check e302801984542 [[],[]] .chain = true := by decide
def e302801984566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e302801984566 : Closed e302801984566 ∧ code e302801984566 = 1402313612342 := by decide
theorem cert_e302801984566 : check e302801984566 [[],[]] .chain = true := by decide
def e302801984570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e302801984570 : Closed e302801984570 ∧ code e302801984570 = 1402313612346 := by decide
theorem cert_e302801984570 : check e302801984570 [[],[]] .chain = true := by decide
def e302801984710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e302801984710 : Closed e302801984710 ∧ code e302801984710 = 1402313612486 := by decide
theorem cert_e302801984710 : check e302801984710 [[],[]] .chain = true := by decide
def e302801984738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e302801984738 : Closed e302801984738 ∧ code e302801984738 = 1402313612514 := by decide
theorem cert_e302801984738 : check e302801984738 [[],[]] .chain = true := by decide
def e302801984750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e302801984750 : Closed e302801984750 ∧ code e302801984750 = 1402313612526 := by decide
theorem cert_e302801984750 : check e302801984750 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801984758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e302801984758 : Closed e302801984758 ∧ code e302801984758 = 1402313612534 := by decide
theorem cert_e302801984758 : check e302801984758 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302801985142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e302801985142 : Closed e302801985142 ∧ code e302801985142 = 1402313612918 := by decide
theorem cert_e302801985142 : checkPay e302801985142 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e302802546142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e302802546142 : Closed e302802546142 ∧ code e302802546142 = 1402314173918 := by decide
theorem cert_e302802546142 : check e302802546142 [[],[]] .smaller = true := by decide
def e302802546158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e302802546158 : Closed e302802546158 ∧ code e302802546158 = 1402314173934 := by decide
theorem cert_e302802546158 : check e302802546158 [[],[]] .smaller = true := by decide
def e302802546526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e302802546526 : Closed e302802546526 ∧ code e302802546526 = 1402314174302 := by decide
theorem cert_e302802546526 : check e302802546526 [[],[]] .smaller = true := by decide
def e302802546554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e302802546554 : Closed e302802546554 ∧ code e302802546554 = 1402314174330 := by decide
theorem cert_e302802546554 : check e302802546554 [[],[]] .smaller = true := by decide
def e302802546606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e302802546606 : Closed e302802546606 ∧ code e302802546606 = 1402314174382 := by decide
theorem cert_e302802546606 : check e302802546606 [[],[]] .smaller = true := by decide
def e302802546618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e302802546618 : Closed e302802546618 ∧ code e302802546618 = 1402314174394 := by decide
theorem cert_e302802546618 : check e302802546618 [[],[]] .smaller = true := by decide
def e302802547678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e302802547678 : Closed e302802547678 ∧ code e302802547678 = 1402314175454 := by decide
theorem cert_e302802547678 : check e302802547678 [[],[]] .smaller = true := by decide
def e302802547694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e302802547694 : Closed e302802547694 ∧ code e302802547694 = 1402314175470 := by decide
theorem cert_e302802547694 : check e302802547694 [[],[]] .smaller = true := by decide
def e302802549982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e302802549982 : Closed e302802549982 ∧ code e302802549982 = 1402314177758 := by decide
theorem cert_e302802549982 : check e302802549982 [[],[]] .smaller = true := by decide
def e302802550010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e302802550010 : Closed e302802550010 ∧ code e302802550010 = 1402314177786 := by decide
theorem cert_e302802550010 : check e302802550010 [[],[]] .smaller = true := by decide
def e302802550382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e302802550382 : Closed e302802550382 ∧ code e302802550382 = 1402314178158 := by decide
theorem cert_e302802550382 : check e302802550382 [[],[]] .smaller = true := by decide
def e302802550394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e302802550394 : Closed e302802550394 ∧ code e302802550394 = 1402314178170 := by decide
theorem cert_e302802550394 : check e302802550394 [[],[]] .smaller = true := by decide
def e302802578798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302802578798 : Closed e302802578798 ∧ code e302802578798 = 1402314206574 := by decide
theorem cert_e302802578798 : check e302802578798 [[],[]] .smaller = true := by decide
def e302802578806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302802578806 : Closed e302802578806 ∧ code e302802578806 = 1402314206582 := by decide
theorem cert_e302802578806 : check e302802578806 [[],[]] .smaller = true := by decide
def e302802578862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302802578862 : Closed e302802578862 ∧ code e302802578862 = 1402314206638 := by decide
theorem cert_e302802578862 : check e302802578862 [[],[]] .smaller = true := by decide
def e302802578874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302802578874 : Closed e302802578874 ∧ code e302802578874 = 1402314206650 := by decide
theorem cert_e302802578874 : check e302802578874 [[],[]] .smaller = true := by decide
def e302802578902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302802578902 : Closed e302802578902 ∧ code e302802578902 = 1402314206678 := by decide
theorem cert_e302802578902 : check e302802578902 [[],[]] .smaller = true := by decide
def e302802578906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302802578906 : Closed e302802578906 ∧ code e302802578906 = 1402314206682 := by decide
theorem cert_e302802578906 : check e302802578906 [[],[]] .smaller = true := by decide
def e302802579118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e302802579118 : Closed e302802579118 ∧ code e302802579118 = 1402314206894 := by decide
theorem cert_e302802579118 : check e302802579118 [[],[]] .smaller = true := by decide
def e302802579130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e302802579130 : Closed e302802579130 ∧ code e302802579130 = 1402314206906 := by decide
theorem cert_e302802579130 : check e302802579130 [[],[]] .smaller = true := by decide
def e302802579178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e302802579178 : Closed e302802579178 ∧ code e302802579178 = 1402314206954 := by decide
theorem cert_e302802579178 : check e302802579178 [[],[]] .smaller = true := by decide
def e302802579286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e302802579286 : Closed e302802579286 ∧ code e302802579286 = 1402314207062 := by decide
theorem cert_e302802579286 : check e302802579286 [[],[]] .smaller = true := by decide
def e302802579290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e302802579290 : Closed e302802579290 ∧ code e302802579290 = 1402314207066 := by decide
theorem cert_e302802579290 : check e302802579290 [[],[]] .smaller = true := by decide
def e302802579306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e302802579306 : Closed e302802579306 ∧ code e302802579306 = 1402314207082 := by decide
theorem cert_e302802579306 : check e302802579306 [[],[]] .smaller = true := by decide
def e302802580334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302802580334 : Closed e302802580334 ∧ code e302802580334 = 1402314208110 := by decide
theorem cert_e302802580334 : check e302802580334 [[],[]] .smaller = true := by decide
def e302802580342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302802580342 : Closed e302802580342 ∧ code e302802580342 = 1402314208118 := by decide
theorem cert_e302802580342 : check e302802580342 [[],[]] .smaller = true := by decide
def e302802580398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302802580398 : Closed e302802580398 ∧ code e302802580398 = 1402314208174 := by decide
theorem cert_e302802580398 : check e302802580398 [[],[]] .smaller = true := by decide
def e302802580410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302802580410 : Closed e302802580410 ∧ code e302802580410 = 1402314208186 := by decide
theorem cert_e302802580410 : check e302802580410 [[],[]] .smaller = true := by decide
def e302802580438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302802580438 : Closed e302802580438 ∧ code e302802580438 = 1402314208214 := by decide
theorem cert_e302802580438 : check e302802580438 [[],[]] .smaller = true := by decide
def e302802580442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302802580442 : Closed e302802580442 ∧ code e302802580442 = 1402314208218 := by decide
theorem cert_e302802580442 : check e302802580442 [[],[]] .smaller = true := by decide
def e302802580718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302802580718 : Closed e302802580718 ∧ code e302802580718 = 1402314208494 := by decide
theorem cert_e302802580718 : check e302802580718 [[],[]] .smaller = true := by decide
def e302802580726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302802580726 : Closed e302802580726 ∧ code e302802580726 = 1402314208502 := by decide
theorem cert_e302802580726 : check e302802580726 [[],[]] .smaller = true := by decide
def e302802581102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302802581102 : Closed e302802581102 ∧ code e302802581102 = 1402314208878 := by decide
theorem cert_e302802581102 : check e302802581102 [[],[]] .smaller = true := by decide
def e302802581114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302802581114 : Closed e302802581114 ∧ code e302802581114 = 1402314208890 := by decide
theorem cert_e302802581114 : check e302802581114 [[],[]] .smaller = true := by decide
def e302802581302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302802581302 : Closed e302802581302 ∧ code e302802581302 = 1402314209078 := by decide
theorem cert_e302802581302 : check e302802581302 [[],[]] .smaller = true := by decide
def e302802581306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302802581306 : Closed e302802581306 ∧ code e302802581306 = 1402314209082 := by decide
theorem cert_e302802581306 : check e302802581306 [[],[]] .smaller = true := by decide
def e302802581934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e302802581934 : Closed e302802581934 ∧ code e302802581934 = 1402314209710 := by decide
theorem cert_e302802581934 : check e302802581934 [[],[]] .smaller = true := by decide
def e302802581946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e302802581946 : Closed e302802581946 ∧ code e302802581946 = 1402314209722 := by decide
theorem cert_e302802581946 : check e302802581946 [[],[]] .smaller = true := by decide
def e302802581994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e302802581994 : Closed e302802581994 ∧ code e302802581994 = 1402314209770 := by decide
theorem cert_e302802581994 : check e302802581994 [[],[]] .smaller = true := by decide
def e302802582126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302802582126 : Closed e302802582126 ∧ code e302802582126 = 1402314209902 := by decide
theorem cert_e302802582126 : check e302802582126 [[],[]] .smaller = true := by decide
def e302802582138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302802582138 : Closed e302802582138 ∧ code e302802582138 = 1402314209914 := by decide
theorem cert_e302802582138 : check e302802582138 [[],[]] .smaller = true := by decide
def e302802582426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302802582426 : Closed e302802582426 ∧ code e302802582426 = 1402314210202 := by decide
theorem cert_e302802582426 : check e302802582426 [[],[]] .smaller = true := by decide
def e302802582494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 3))))))))
theorem wire_e302802582494 : Closed e302802582494 ∧ code e302802582494 = 1402314210270 := by decide
theorem cert_e302802582494 : check e302802582494 [[],[]] .sourceHead = true := by decide
def e302802582742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e302802582742 : Closed e302802582742 ∧ code e302802582742 = 1402314210518 := by decide
theorem cert_e302802582742 : check e302802582742 [[],[]] .smaller = true := by decide
def e302802582746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e302802582746 : Closed e302802582746 ∧ code e302802582746 = 1402314210522 := by decide
theorem cert_e302802582746 : check e302802582746 [[],[]] .smaller = true := by decide
def e302802582762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e302802582762 : Closed e302802582762 ∧ code e302802582762 = 1402314210538 := by decide
theorem cert_e302802582762 : check e302802582762 [[],[]] .smaller = true := by decide
def e302802582838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302802582838 : Closed e302802582838 ∧ code e302802582838 = 1402314210614 := by decide
theorem cert_e302802582838 : check e302802582838 [[],[]] .smaller = true := by decide
def e302802582842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302802582842 : Closed e302802582842 ∧ code e302802582842 = 1402314210618 := by decide
theorem cert_e302802582842 : check e302802582842 [[],[]] .smaller = true := by decide
def e302802582938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302802582938 : Closed e302802582938 ∧ code e302802582938 = 1402314210714 := by decide
theorem cert_e302802582938 : check e302802582938 [[],[]] .smaller = true := by decide
def e302802583262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 3))))))))
theorem wire_e302802583262 : Closed e302802583262 ∧ code e302802583262 = 1402314211038 := by decide
theorem cert_e302802583262 : check e302802583262 [[],[]] .sourceHead = true := by decide
def e302802583286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 3)) (.var 1))))))))
theorem wire_e302802583286 : Closed e302802583286 ∧ code e302802583286 = 1402314211062 := by decide
theorem cert_e302802583286 : check e302802583286 [[],[]] .sourceHead = true := by decide
def e302802584542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e302802584542 : Closed e302802584542 ∧ code e302802584542 = 1402314212318 := by decide
theorem cert_e302802584542 : check e302802584542 [[],[]] .smaller = true := by decide
def e302802584558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e302802584558 : Closed e302802584558 ∧ code e302802584558 = 1402314212334 := by decide
theorem cert_e302802584558 : check e302802584558 [[],[]] .smaller = true := by decide
def e302802586478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302802586478 : Closed e302802586478 ∧ code e302802586478 = 1402314214254 := by decide
theorem cert_e302802586478 : check e302802586478 [[],[]] .smaller = true := by decide
def e302802586486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302802586486 : Closed e302802586486 ∧ code e302802586486 = 1402314214262 := by decide
theorem cert_e302802586486 : check e302802586486 [[],[]] .smaller = true := by decide
def e302802586542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302802586542 : Closed e302802586542 ∧ code e302802586542 = 1402314214318 := by decide
theorem cert_e302802586542 : check e302802586542 [[],[]] .smaller = true := by decide
def e302802586554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302802586554 : Closed e302802586554 ∧ code e302802586554 = 1402314214330 := by decide
theorem cert_e302802586554 : check e302802586554 [[],[]] .smaller = true := by decide
def e302802586582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302802586582 : Closed e302802586582 ∧ code e302802586582 = 1402314214358 := by decide
theorem cert_e302802586582 : check e302802586582 [[],[]] .smaller = true := by decide
end Blc.Floor40
