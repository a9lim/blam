import R302887562694Data
namespace Certgen.R302887562694
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl144 : FloorIndex.rangeOK validState 144 12 = true := by decide +kernel
theorem bl156 : FloorIndex.rangeOK validState 156 12 = true := by decide +kernel
theorem bl168 : FloorIndex.rangeOK validState 168 6 = true := by decide +kernel
end Certgen.R302887562694
