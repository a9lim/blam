import R302824803246V0
import R302824803246K0
import R302824803246st0
import R302824803246hs0
import RegularBase
import Batch060
namespace Certgen.R302824803246
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 70,.app 2 61,.app 3 24,.app 4 21,.app 5 9,.lam 6,.app 7 8,.var 0,.var 0,.lam 10,.lam 11,.app 12 13,.var 1,.lam 14,.app 15 16,.var 2,.app 17 20,.app 18 19,.var 1,.var 0,.var 2,.lam 22,.lam 23,.var 1,.lam 25,.app 26 31,.app 27 28,.var 0,.lam 29,.lam 30,.var 1,.lam 32,.app 33 38,.app 34 35,.var 0,.lam 36,.lam 37,.var 1,.lam 39,.app 40 45,.app 41 42,.var 0,.lam 43,.lam 44,.var 0,.lam 46,.app 47 52,.app 48 49,.var 0,.lam 50,.lam 51,.var 1,.app 53 57,.lam 54,.app 55 56,.var 0,.var 0,.lam 58,.app 59 60,.var 0,.var 0,.app 62 66,.lam 63,.app 64 65,.var 0,.var 0,.lam 67,.app 68 69,.var 0,.var 0,.lam 71,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (V20[i-20]?.getD []))
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (if i < 40 then (K20[i-20]?.getD []) else (K40[i-40]?.getD [])))
def st (i : Nat) : AState := if i < 132 then (if i < 60 then (if i < 20 then (st0[i-0]?.getD entry) else (if i < 40 then (st20[i-20]?.getD entry) else (st40[i-40]?.getD entry))) else (if i < 100 then (if i < 80 then (st60[i-60]?.getD entry) else (st80[i-80]?.getD entry)) else (if i < 120 then (st100[i-100]?.getD entry) else (st120[i-120]?.getD entry)))) else entry
def hs (i : Nat) : List Nat := (if i < 60 then (if i < 20 then (hs0[i-0]?.getD []) else (if i < 40 then (hs20[i-20]?.getD []) else (hs40[i-40]?.getD []))) else (if i < 100 then (if i < 80 then (hs60[i-60]?.getD []) else (hs80[i-80]?.getD [])) else (if i < 120 then (hs100[i-100]?.getD []) else (hs120[i-120]?.getD []))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R302824803246
