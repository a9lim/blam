import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e301466389462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e301466389462 : Closed e301466389462 ∧ code e301466389462 = 1400978017238 := by decide
theorem cert_e301466389462 : check e301466389462 [[],[],[]] .smaller = true := by decide
def e301466389466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e301466389466 : Closed e301466389466 ∧ code e301466389466 = 1400978017242 := by decide
theorem cert_e301466389466 : check e301466389466 [[],[],[]] .smaller = true := by decide
def e301466389742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e301466389742 : Closed e301466389742 ∧ code e301466389742 = 1400978017518 := by decide
theorem cert_e301466389742 : check e301466389742 [[],[],[]] .smaller = true := by decide
def e301466389750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e301466389750 : Closed e301466389750 ∧ code e301466389750 = 1400978017526 := by decide
theorem cert_e301466389750 : check e301466389750 [[],[],[]] .smaller = true := by decide
def e301466390126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e301466390126 : Closed e301466390126 ∧ code e301466390126 = 1400978017902 := by decide
theorem cert_e301466390126 : check e301466390126 [[],[],[]] .smaller = true := by decide
def e301466390138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e301466390138 : Closed e301466390138 ∧ code e301466390138 = 1400978017914 := by decide
theorem cert_e301466390138 : check e301466390138 [[],[],[]] .smaller = true := by decide
def e301466390326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e301466390326 : Closed e301466390326 ∧ code e301466390326 = 1400978018102 := by decide
theorem cert_e301466390326 : check e301466390326 [[],[],[]] .smaller = true := by decide
def e301466390330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e301466390330 : Closed e301466390330 ∧ code e301466390330 = 1400978018106 := by decide
theorem cert_e301466390330 : check e301466390330 [[],[],[]] .smaller = true := by decide
def e302259822106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302259822106 : Closed e302259822106 ∧ code e302259822106 = 1401771449882 := by decide
theorem cert_e302259822106 : check e302259822106 [[]] .width = true := by decide
def e302259828250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302259828250 : Closed e302259828250 ∧ code e302259828250 = 1401771456026 := by decide
theorem cert_e302259828250 : check e302259828250 [[]] .width = true := by decide
def e302259854874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302259854874 : Closed e302259854874 ∧ code e302259854874 = 1401771482650 := by decide
theorem cert_e302259854874 : check e302259854874 [[]] .width = true := by decide
def e302259862042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302259862042 : Closed e302259862042 ∧ code e302259862042 = 1401771489818 := by decide
theorem cert_e302259862042 : check e302259862042 [[]] .width = true := by decide
def e302259885594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302259885594 : Closed e302259885594 ∧ code e302259885594 = 1401771513370 := by decide
theorem cert_e302259885594 : check e302259885594 [[]] .width = true := by decide
def e302259886618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302259886618 : Closed e302259886618 ∧ code e302259886618 = 1401771514394 := by decide
theorem cert_e302259886618 : check e302259886618 [[]] .width = true := by decide
def e302260018714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302260018714 : Closed e302260018714 ∧ code e302260018714 = 1401771646490 := by decide
theorem cert_e302260018714 : check e302260018714 [[]] .width = true := by decide
def e302260024858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302260024858 : Closed e302260024858 ∧ code e302260024858 = 1401771652634 := by decide
theorem cert_e302260024858 : check e302260024858 [[]] .width = true := by decide
def e302260215322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302260215322 : Closed e302260215322 ∧ code e302260215322 = 1401771843098 := by decide
theorem cert_e302260215322 : check e302260215322 [[]] .width = true := by decide
def e302260222490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302260222490 : Closed e302260222490 ∧ code e302260222490 = 1401771850266 := by decide
theorem cert_e302260222490 : check e302260222490 [[]] .width = true := by decide
def e302260368922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302260368922 : Closed e302260368922 ∧ code e302260368922 = 1401771996698 := by decide
theorem cert_e302260368922 : check e302260368922 [[]] .width = true := by decide
def e302260369946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302260369946 : Closed e302260369946 ∧ code e302260369946 = 1401771997722 := by decide
theorem cert_e302260369946 : check e302260369946 [[]] .width = true := by decide
def e302264151578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302264151578 : Closed e302264151578 ∧ code e302264151578 = 1401775779354 := by decide
theorem cert_e302264151578 : check e302264151578 [[]] .width = true := by decide
def e302264153626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302264153626 : Closed e302264153626 ∧ code e302264153626 = 1401775781402 := by decide
theorem cert_e302264153626 : check e302264153626 [[]] .width = true := by decide
def e302264294938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302264294938 : Closed e302264294938 ∧ code e302264294938 = 1401775922714 := by decide
theorem cert_e302264294938 : check e302264294938 [[]] .width = true := by decide
def e302264316102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e302264316102 : Closed e302264316102 ∧ code e302264316102 = 1401775943878 := by decide
theorem cert_e302264316102 : check e302264316102 [[]] .width = true := by decide
def e302264323610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302264323610 : Closed e302264323610 ∧ code e302264323610 = 1401775951386 := by decide
theorem cert_e302264323610 : check e302264323610 [[]] .width = true := by decide
def e302264332486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e302264332486 : Closed e302264332486 ∧ code e302264332486 = 1401775960262 := by decide
theorem cert_e302264332486 : check e302264332486 [[]] .width = true := by decide
def e302264380954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302264380954 : Closed e302264380954 ∧ code e302264380954 = 1401776008730 := by decide
theorem cert_e302264380954 : check e302264380954 [[]] .width = true := by decide
def e302264384026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302264384026 : Closed e302264384026 ∧ code e302264384026 = 1401776011802 := by decide
theorem cert_e302264384026 : check e302264384026 [[]] .width = true := by decide
def e302264426010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302264426010 : Closed e302264426010 ∧ code e302264426010 = 1401776053786 := by decide
theorem cert_e302264426010 : check e302264426010 [[]] .width = true := by decide
def e302264447174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e302264447174 : Closed e302264447174 ∧ code e302264447174 = 1401776074950 := by decide
theorem cert_e302264447174 : check e302264447174 [[]] .width = true := by decide
def e302264469018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302264469018 : Closed e302264469018 ∧ code e302264469018 = 1401776096794 := by decide
private def t_e302264469018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e302264469018 : ¬ IsSelfInterpreter e302264469018 :=
  wSource (t := t_e302264469018) (replay_sound (ps := []) (t := e302264469018) (by decide)) (by decide)
def e302264471750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e302264471750 : Closed e302264471750 ∧ code e302264471750 = 1401776099526 := by decide
theorem cert_e302264471750 : check e302264471750 [[]] .width = true := by decide
def e302264497690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302264497690 : Closed e302264497690 ∧ code e302264497690 = 1401776125466 := by decide
theorem cert_e302264497690 : check e302264497690 [[]] .width = true := by decide
def e302264498714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302264498714 : Closed e302264498714 ∧ code e302264498714 = 1401776126490 := by decide
theorem cert_e302264498714 : check e302264498714 [[]] .width = true := by decide
def e302264520218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302264520218 : Closed e302264520218 ∧ code e302264520218 = 1401776147994 := by decide
theorem cert_e302264520218 : check e302264520218 [[]] .width = true := by decide
def e302264529094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e302264529094 : Closed e302264529094 ∧ code e302264529094 = 1401776156870 := by decide
theorem cert_e302264529094 : check e302264529094 [[]] .width = true := by decide
def e302264534554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302264534554 : Closed e302264534554 ∧ code e302264534554 = 1401776162330 := by decide
private def t_e302264534554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e302264534554 : ¬ IsSelfInterpreter e302264534554 :=
  wSource (t := t_e302264534554) (replay_sound (ps := []) (t := e302264534554) (by decide)) (by decide)
def e302264537286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e302264537286 : Closed e302264537286 ∧ code e302264537286 = 1401776165062 := by decide
theorem cert_e302264537286 : check e302264537286 [[]] .width = true := by decide
def e302265081370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302265081370 : Closed e302265081370 ∧ code e302265081370 = 1401776709146 := by decide
theorem cert_e302265081370 : check e302265081370 [[]] .width = true := by decide
def e302265102534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e302265102534 : Closed e302265102534 ∧ code e302265102534 = 1401776730310 := by decide
theorem cert_e302265102534 : check e302265102534 [[]] .width = true := by decide
def e302265110042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302265110042 : Closed e302265110042 ∧ code e302265110042 = 1401776737818 := by decide
theorem cert_e302265110042 : check e302265110042 [[]] .width = true := by decide
def e302265118918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e302265118918 : Closed e302265118918 ∧ code e302265118918 = 1401776746694 := by decide
theorem cert_e302265118918 : check e302265118918 [[]] .width = true := by decide
def e302265867802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302265867802 : Closed e302265867802 ∧ code e302265867802 = 1401777495578 := by decide
theorem cert_e302265867802 : check e302265867802 [[]] .width = true := by decide
def e302265888966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e302265888966 : Closed e302265888966 ∧ code e302265888966 = 1401777516742 := by decide
theorem cert_e302265888966 : check e302265888966 [[]] .width = true := by decide
def e302265910810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302265910810 : Closed e302265910810 ∧ code e302265910810 = 1401777538586 := by decide
theorem cert_e302265910810 : check e302265910810 [[]] .width = true := by decide
def e302265913542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e302265913542 : Closed e302265913542 ∧ code e302265913542 = 1401777541318 := by decide
theorem cert_e302265913542 : check e302265913542 [[]] .width = true := by decide
def e302266289690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302266289690 : Closed e302266289690 ∧ code e302266289690 = 1401777917466 := by decide
theorem cert_e302266289690 : check e302266289690 [[]] .width = true := by decide
def e302266298566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e302266298566 : Closed e302266298566 ∧ code e302266298566 = 1401777926342 := by decide
theorem cert_e302266298566 : check e302266298566 [[]] .width = true := by decide
def e302266304026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e302266304026 : Closed e302266304026 ∧ code e302266304026 = 1401777931802 := by decide
theorem cert_e302266304026 : check e302266304026 [[]] .width = true := by decide
def e302266306758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e302266306758 : Closed e302266306758 ∧ code e302266306758 = 1401777934534 := by decide
theorem cert_e302266306758 : check e302266306758 [[]] .width = true := by decide
def e302291966830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e302291966830 : Closed e302291966830 ∧ code e302291966830 = 1401803594606 := by decide
theorem cert_e302291966830 : check e302291966830 [[],[]] .chain = true := by decide
def e302291966838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e302291966838 : Closed e302291966838 ∧ code e302291966838 = 1401803594614 := by decide
theorem cert_e302291966838 : check e302291966838 [[],[]] .chain = true := by decide
def e302291966902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e302291966902 : Closed e302291966902 ∧ code e302291966902 = 1401803594678 := by decide
theorem cert_e302291966902 : check e302291966902 [[],[]] .chain = true := by decide
def e302291967342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e302291967342 : Closed e302291967342 ∧ code e302291967342 = 1401803595118 := by decide
theorem cert_e302291967342 : check e302291967342 [[],[]] .chain = true := by decide
def e302291967350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e302291967350 : Closed e302291967350 ∧ code e302291967350 = 1401803595126 := by decide
theorem cert_e302291967350 : check e302291967350 [[],[]] .chain = true := by decide
def e302291967406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e302291967406 : Closed e302291967406 ∧ code e302291967406 = 1401803595182 := by decide
theorem cert_e302291967406 : check e302291967406 [[],[]] .chain = true := by decide
def e302291967418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e302291967418 : Closed e302291967418 ∧ code e302291967418 = 1401803595194 := by decide
theorem cert_e302291967418 : check e302291967418 [[],[]] .chain = true := by decide
def e302291967446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e302291967446 : Closed e302291967446 ∧ code e302291967446 = 1401803595222 := by decide
theorem cert_e302291967446 : check e302291967446 [[],[]] .chain = true := by decide
def e302291967450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e302291967450 : Closed e302291967450 ∧ code e302291967450 = 1401803595226 := by decide
theorem cert_e302291967450 : check e302291967450 [[],[]] .chain = true := by decide
def e302291967670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e302291967670 : Closed e302291967670 ∧ code e302291967670 = 1401803595446 := by decide
theorem cert_e302291967670 : check e302291967670 [[],[]] .chain = true := by decide
def e302291967702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e302291967702 : Closed e302291967702 ∧ code e302291967702 = 1401803595478 := by decide
theorem cert_e302291967702 : check e302291967702 [[],[]] .chain = true := by decide
def e302291967706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e302291967706 : Closed e302291967706 ∧ code e302291967706 = 1401803595482 := by decide
theorem cert_e302291967706 : check e302291967706 [[],[]] .chain = true := by decide
def e302291969902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e302291969902 : Closed e302291969902 ∧ code e302291969902 = 1401803597678 := by decide
theorem cert_e302291969902 : check e302291969902 [[],[]] .chain = true := by decide
def e302291969910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e302291969910 : Closed e302291969910 ∧ code e302291969910 = 1401803597686 := by decide
theorem cert_e302291969910 : check e302291969910 [[],[]] .chain = true := by decide
def e302291969974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e302291969974 : Closed e302291969974 ∧ code e302291969974 = 1401803597750 := by decide
theorem cert_e302291969974 : check e302291969974 [[],[]] .chain = true := by decide
def e302291971310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e302291971310 : Closed e302291971310 ∧ code e302291971310 = 1401803599086 := by decide
theorem cert_e302291971310 : check e302291971310 [[],[]] .chain = true := by decide
def e302291971318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e302291971318 : Closed e302291971318 ∧ code e302291971318 = 1401803599094 := by decide
theorem cert_e302291971318 : check e302291971318 [[],[]] .chain = true := by decide
def e302291971702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e302291971702 : Closed e302291971702 ∧ code e302291971702 = 1401803599478 := by decide
theorem cert_e302291971702 : check e302291971702 [[],[]] .chain = true := by decide
def e302291972974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e302291972974 : Closed e302291972974 ∧ code e302291972974 = 1401803600750 := by decide
theorem cert_e302291972974 : check e302291972974 [[],[]] .chain = true := by decide
def e302291972982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e302291972982 : Closed e302291972982 ∧ code e302291972982 = 1401803600758 := by decide
theorem cert_e302291972982 : check e302291972982 [[],[]] .chain = true := by decide
def e302291973038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e302291973038 : Closed e302291973038 ∧ code e302291973038 = 1401803600814 := by decide
theorem cert_e302291973038 : check e302291973038 [[],[]] .chain = true := by decide
def e302291973050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e302291973050 : Closed e302291973050 ∧ code e302291973050 = 1401803600826 := by decide
theorem cert_e302291973050 : check e302291973050 [[],[]] .chain = true := by decide
def e302291973078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e302291973078 : Closed e302291973078 ∧ code e302291973078 = 1401803600854 := by decide
theorem cert_e302291973078 : check e302291973078 [[],[]] .chain = true := by decide
def e302291973082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e302291973082 : Closed e302291973082 ∧ code e302291973082 = 1401803600858 := by decide
theorem cert_e302291973082 : check e302291973082 [[],[]] .chain = true := by decide
def e302291973358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e302291973358 : Closed e302291973358 ∧ code e302291973358 = 1401803601134 := by decide
theorem cert_e302291973358 : check e302291973358 [[],[]] .chain = true := by decide
def e302291973366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e302291973366 : Closed e302291973366 ∧ code e302291973366 = 1401803601142 := by decide
theorem cert_e302291973366 : check e302291973366 [[],[]] .chain = true := by decide
def e302291973742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e302291973742 : Closed e302291973742 ∧ code e302291973742 = 1401803601518 := by decide
theorem cert_e302291973742 : check e302291973742 [[],[]] .chain = true := by decide
def e302291973754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e302291973754 : Closed e302291973754 ∧ code e302291973754 = 1401803601530 := by decide
theorem cert_e302291973754 : check e302291973754 [[],[]] .chain = true := by decide
def e302291973942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e302291973942 : Closed e302291973942 ∧ code e302291973942 = 1401803601718 := by decide
theorem cert_e302291973942 : check e302291973942 [[],[]] .chain = true := by decide
def e302291973946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e302291973946 : Closed e302291973946 ∧ code e302291973946 = 1401803601722 := by decide
theorem cert_e302291973946 : check e302291973946 [[],[]] .chain = true := by decide
def e302291974582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e302291974582 : Closed e302291974582 ∧ code e302291974582 = 1401803602358 := by decide
theorem cert_e302291974582 : check e302291974582 [[],[]] .chain = true := by decide
def e302291974614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e302291974614 : Closed e302291974614 ∧ code e302291974614 = 1401803602390 := by decide
theorem cert_e302291974614 : check e302291974614 [[],[]] .chain = true := by decide
def e302291974618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e302291974618 : Closed e302291974618 ∧ code e302291974618 = 1401803602394 := by decide
theorem cert_e302291974618 : check e302291974618 [[],[]] .chain = true := by decide
def e302291974774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e302291974774 : Closed e302291974774 ∧ code e302291974774 = 1401803602550 := by decide
theorem cert_e302291974774 : check e302291974774 [[],[]] .chain = true := by decide
def e302291974966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e302291974966 : Closed e302291974966 ∧ code e302291974966 = 1401803602742 := by decide
theorem cert_e302291974966 : check e302291974966 [[],[]] .chain = true := by decide
def e302291974970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e302291974970 : Closed e302291974970 ∧ code e302291974970 = 1401803602746 := by decide
theorem cert_e302291974970 : check e302291974970 [[],[]] .chain = true := by decide
def e302291982190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e302291982190 : Closed e302291982190 ∧ code e302291982190 = 1401803609966 := by decide
theorem cert_e302291982190 : check e302291982190 [[],[]] .chain = true := by decide
def e302291982198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e302291982198 : Closed e302291982198 ∧ code e302291982198 = 1401803609974 := by decide
theorem cert_e302291982198 : check e302291982198 [[],[]] .chain = true := by decide
def e302291982262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e302291982262 : Closed e302291982262 ∧ code e302291982262 = 1401803610038 := by decide
theorem cert_e302291982262 : check e302291982262 [[],[]] .chain = true := by decide
def e302291983598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e302291983598 : Closed e302291983598 ∧ code e302291983598 = 1401803611374 := by decide
theorem cert_e302291983598 : check e302291983598 [[],[]] .chain = true := by decide
def e302291983606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e302291983606 : Closed e302291983606 ∧ code e302291983606 = 1401803611382 := by decide
theorem cert_e302291983606 : check e302291983606 [[],[]] .chain = true := by decide
def e302291983990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e302291983990 : Closed e302291983990 ∧ code e302291983990 = 1401803611766 := by decide
theorem cert_e302291983990 : check e302291983990 [[],[]] .chain = true := by decide
def e302291995502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e302291995502 : Closed e302291995502 ∧ code e302291995502 = 1401803623278 := by decide
theorem cert_e302291995502 : check e302291995502 [[],[]] .chain = true := by decide
def e302291995510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e302291995510 : Closed e302291995510 ∧ code e302291995510 = 1401803623286 := by decide
theorem cert_e302291995510 : check e302291995510 [[],[]] .chain = true := by decide
def e302291995566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e302291995566 : Closed e302291995566 ∧ code e302291995566 = 1401803623342 := by decide
theorem cert_e302291995566 : check e302291995566 [[],[]] .chain = true := by decide
def e302291995578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e302291995578 : Closed e302291995578 ∧ code e302291995578 = 1401803623354 := by decide
theorem cert_e302291995578 : check e302291995578 [[],[]] .chain = true := by decide
def e302291995606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e302291995606 : Closed e302291995606 ∧ code e302291995606 = 1401803623382 := by decide
theorem cert_e302291995606 : check e302291995606 [[],[]] .chain = true := by decide
def e302291995610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e302291995610 : Closed e302291995610 ∧ code e302291995610 = 1401803623386 := by decide
theorem cert_e302291995610 : check e302291995610 [[],[]] .chain = true := by decide
def e302291995886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e302291995886 : Closed e302291995886 ∧ code e302291995886 = 1401803623662 := by decide
theorem cert_e302291995886 : check e302291995886 [[],[]] .chain = true := by decide
def e302291995894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e302291995894 : Closed e302291995894 ∧ code e302291995894 = 1401803623670 := by decide
theorem cert_e302291995894 : check e302291995894 [[],[]] .chain = true := by decide
def e302291996270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e302291996270 : Closed e302291996270 ∧ code e302291996270 = 1401803624046 := by decide
theorem cert_e302291996270 : check e302291996270 [[],[]] .chain = true := by decide
def e302291996282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e302291996282 : Closed e302291996282 ∧ code e302291996282 = 1401803624058 := by decide
theorem cert_e302291996282 : check e302291996282 [[],[]] .chain = true := by decide
def e302291996470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e302291996470 : Closed e302291996470 ∧ code e302291996470 = 1401803624246 := by decide
theorem cert_e302291996470 : check e302291996470 [[],[]] .chain = true := by decide
def e302291996474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e302291996474 : Closed e302291996474 ∧ code e302291996474 = 1401803624250 := by decide
theorem cert_e302291996474 : check e302291996474 [[],[]] .chain = true := by decide
def e302292002230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e302292002230 : Closed e302292002230 ∧ code e302292002230 = 1401803630006 := by decide
theorem cert_e302292002230 : check e302292002230 [[],[]] .chain = true := by decide
def e302292002262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e302292002262 : Closed e302292002262 ∧ code e302292002262 = 1401803630038 := by decide
theorem cert_e302292002262 : check e302292002262 [[],[]] .chain = true := by decide
def e302292002266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e302292002266 : Closed e302292002266 ∧ code e302292002266 = 1401803630042 := by decide
theorem cert_e302292002266 : check e302292002266 [[],[]] .chain = true := by decide
def e302292002422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e302292002422 : Closed e302292002422 ∧ code e302292002422 = 1401803630198 := by decide
theorem cert_e302292002422 : check e302292002422 [[],[]] .chain = true := by decide
def e302292002614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e302292002614 : Closed e302292002614 ∧ code e302292002614 = 1401803630390 := by decide
theorem cert_e302292002614 : check e302292002614 [[],[]] .chain = true := by decide
def e302292002618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e302292002618 : Closed e302292002618 ∧ code e302292002618 = 1401803630394 := by decide
theorem cert_e302292002618 : check e302292002618 [[],[]] .chain = true := by decide
def e302292339566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e302292339566 : Closed e302292339566 ∧ code e302292339566 = 1401803967342 := by decide
theorem cert_e302292339566 : check e302292339566 [[],[],[.under,.left]] .chain = true := by decide
def e302292339574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e302292339574 : Closed e302292339574 ∧ code e302292339574 = 1401803967350 := by decide
theorem cert_e302292339574 : check e302292339574 [[],[],[.under,.left]] .chain = true := by decide
def e302292339630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e302292339630 : Closed e302292339630 ∧ code e302292339630 = 1401803967406 := by decide
theorem cert_e302292339630 : check e302292339630 [[],[],[.under,.left]] .chain = true := by decide
def e302292339642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e302292339642 : Closed e302292339642 ∧ code e302292339642 = 1401803967418 := by decide
theorem cert_e302292339642 : check e302292339642 [[],[],[.under,.left]] .chain = true := by decide
def e302292339670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e302292339670 : Closed e302292339670 ∧ code e302292339670 = 1401803967446 := by decide
theorem cert_e302292339670 : check e302292339670 [[],[],[.under,.left]] .chain = true := by decide
def e302292339674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e302292339674 : Closed e302292339674 ∧ code e302292339674 = 1401803967450 := by decide
theorem cert_e302292339674 : check e302292339674 [[],[],[.under,.left]] .chain = true := by decide
def e302292339950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e302292339950 : Closed e302292339950 ∧ code e302292339950 = 1401803967726 := by decide
theorem cert_e302292339950 : check e302292339950 [[],[],[.under,.left]] .chain = true := by decide
def e302292339958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e302292339958 : Closed e302292339958 ∧ code e302292339958 = 1401803967734 := by decide
theorem cert_e302292339958 : check e302292339958 [[],[],[.under,.left]] .chain = true := by decide
def e302292340334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e302292340334 : Closed e302292340334 ∧ code e302292340334 = 1401803968110 := by decide
theorem cert_e302292340334 : check e302292340334 [[],[],[.under,.left]] .chain = true := by decide
def e302292340346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e302292340346 : Closed e302292340346 ∧ code e302292340346 = 1401803968122 := by decide
theorem cert_e302292340346 : check e302292340346 [[],[],[.under,.left]] .chain = true := by decide
def e302292340534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e302292340534 : Closed e302292340534 ∧ code e302292340534 = 1401803968310 := by decide
theorem cert_e302292340534 : check e302292340534 [[],[],[.under,.left]] .chain = true := by decide
def e302292340538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e302292340538 : Closed e302292340538 ∧ code e302292340538 = 1401803968314 := by decide
theorem cert_e302292340538 : check e302292340538 [[],[],[.under,.left]] .chain = true := by decide
def e302308699502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e302308699502 : Closed e302308699502 ∧ code e302308699502 = 1401820327278 := by decide
theorem cert_e302308699502 : check e302308699502 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e302308699510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e302308699510 : Closed e302308699510 ∧ code e302308699510 = 1401820327286 := by decide
theorem cert_e302308699510 : checkPay e302308699510 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302308699566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e302308699566 : Closed e302308699566 ∧ code e302308699566 = 1401820327342 := by decide
theorem cert_e302308699566 : check e302308699566 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302308699578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e302308699578 : Closed e302308699578 ∧ code e302308699578 = 1401820327354 := by decide
theorem cert_e302308699578 : check e302308699578 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302308699606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e302308699606 : Closed e302308699606 ∧ code e302308699606 = 1401820327382 := by decide
theorem cert_e302308699606 : check e302308699606 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e302308699610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e302308699610 : Closed e302308699610 ∧ code e302308699610 = 1401820327386 := by decide
theorem cert_e302308699610 : check e302308699610 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302308699822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e302308699822 : Closed e302308699822 ∧ code e302308699822 = 1401820327598 := by decide
theorem cert_e302308699822 : check e302308699822 [[],[]] .sourceHead = true := by decide
def e302308699834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e302308699834 : Closed e302308699834 ∧ code e302308699834 = 1401820327610 := by decide
theorem cert_e302308699834 : check e302308699834 [[],[]] .sourceHead = true := by decide
def e302308699882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e302308699882 : Closed e302308699882 ∧ code e302308699882 = 1401820327658 := by decide
theorem cert_e302308699882 : check e302308699882 [[],[]] .sourceHead = true := by decide
def e302308699990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e302308699990 : Closed e302308699990 ∧ code e302308699990 = 1401820327766 := by decide
theorem cert_e302308699990 : check e302308699990 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302308699994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e302308699994 : Closed e302308699994 ∧ code e302308699994 = 1401820327770 := by decide
theorem cert_e302308699994 : check e302308699994 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302308700010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e302308700010 : Closed e302308700010 ∧ code e302308700010 = 1401820327786 := by decide
theorem cert_e302308700010 : check e302308700010 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302308701038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e302308701038 : Closed e302308701038 ∧ code e302308701038 = 1401820328814 := by decide
theorem cert_e302308701038 : check e302308701038 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e302308701046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e302308701046 : Closed e302308701046 ∧ code e302308701046 = 1401820328822 := by decide
theorem cert_e302308701046 : check e302308701046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e302308701102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e302308701102 : Closed e302308701102 ∧ code e302308701102 = 1401820328878 := by decide
theorem cert_e302308701102 : check e302308701102 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302308701114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e302308701114 : Closed e302308701114 ∧ code e302308701114 = 1401820328890 := by decide
theorem cert_e302308701114 : check e302308701114 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302308701142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e302308701142 : Closed e302308701142 ∧ code e302308701142 = 1401820328918 := by decide
theorem cert_e302308701142 : check e302308701142 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302308701146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e302308701146 : Closed e302308701146 ∧ code e302308701146 = 1401820328922 := by decide
theorem cert_e302308701146 : check e302308701146 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302308701422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e302308701422 : Closed e302308701422 ∧ code e302308701422 = 1401820329198 := by decide
theorem cert_e302308701422 : check e302308701422 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302308701430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e302308701430 : Closed e302308701430 ∧ code e302308701430 = 1401820329206 := by decide
theorem cert_e302308701430 : check e302308701430 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302308701806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e302308701806 : Closed e302308701806 ∧ code e302308701806 = 1401820329582 := by decide
theorem cert_e302308701806 : check e302308701806 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302308701818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e302308701818 : Closed e302308701818 ∧ code e302308701818 = 1401820329594 := by decide
theorem cert_e302308701818 : check e302308701818 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302308702006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e302308702006 : Closed e302308702006 ∧ code e302308702006 = 1401820329782 := by decide
theorem cert_e302308702006 : check e302308702006 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302308702010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e302308702010 : Closed e302308702010 ∧ code e302308702010 = 1401820329786 := by decide
theorem cert_e302308702010 : check e302308702010 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302308702638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e302308702638 : Closed e302308702638 ∧ code e302308702638 = 1401820330414 := by decide
theorem cert_e302308702638 : checkPay e302308702638 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e302308702650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e302308702650 : Closed e302308702650 ∧ code e302308702650 = 1401820330426 := by decide
theorem cert_e302308702650 : checkPay e302308702650 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[]] = true := by decide
def e302308702698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e302308702698 : Closed e302308702698 ∧ code e302308702698 = 1401820330474 := by decide
theorem cert_e302308702698 : checkPay e302308702698 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left]] = true := by decide
def e302308702830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e302308702830 : Closed e302308702830 ∧ code e302308702830 = 1401820330606 := by decide
theorem cert_e302308702830 : checkPay e302308702830 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302308702842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e302308702842 : Closed e302308702842 ∧ code e302308702842 = 1401820330618 := by decide
theorem cert_e302308702842 : checkPay e302308702842 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302308703130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e302308703130 : Closed e302308703130 ∧ code e302308703130 = 1401820330906 := by decide
theorem cert_e302308703130 : checkPay e302308703130 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e302308703446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e302308703446 : Closed e302308703446 ∧ code e302308703446 = 1401820331222 := by decide
theorem cert_e302308703446 : check e302308703446 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302308703450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e302308703450 : Closed e302308703450 ∧ code e302308703450 = 1401820331226 := by decide
theorem cert_e302308703450 : check e302308703450 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302308703466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e302308703466 : Closed e302308703466 ∧ code e302308703466 = 1401820331242 := by decide
theorem cert_e302308703466 : check e302308703466 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302308703542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e302308703542 : Closed e302308703542 ∧ code e302308703542 = 1401820331318 := by decide
theorem cert_e302308703542 : check e302308703542 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302308703546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e302308703546 : Closed e302308703546 ∧ code e302308703546 = 1401820331322 := by decide
theorem cert_e302308703546 : check e302308703546 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302308703642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e302308703642 : Closed e302308703642 ∧ code e302308703642 = 1401820331418 := by decide
theorem cert_e302308703642 : check e302308703642 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e302308707182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e302308707182 : Closed e302308707182 ∧ code e302308707182 = 1401820334958 := by decide
theorem cert_e302308707182 : check e302308707182 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e302308707190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e302308707190 : Closed e302308707190 ∧ code e302308707190 = 1401820334966 := by decide
theorem cert_e302308707190 : check e302308707190 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
end Blc.Floor40
