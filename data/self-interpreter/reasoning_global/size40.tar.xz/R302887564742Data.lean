import R302887564742V0
import R302887564742K0
import R302887564742st0
import R302887564742hs0
import CodeBridge
import Batch060
namespace Certgen.R302887564742
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 5,.lam 2,.app 3 4,.var 0,.var 0,.lam 6,.app 7 16,.app 8 9,.var 0,.lam 10,.lam 11,.app 12 15,.app 13 14,.var 1,.var 0,.var 2,.lam 17,.var 1]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (V0[i-0]?.getD [])
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD []))
def st (i : Nat) : AState := if i < 107 then (if i < 60 then (if i < 20 then (st0[i-0]?.getD entry) else (if i < 40 then (st20[i-20]?.getD entry) else (st40[i-40]?.getD entry))) else (if i < 80 then (st60[i-60]?.getD entry) else (if i < 100 then (st80[i-80]?.getD entry) else (st100[i-100]?.getD entry)))) else entry
def hs (i : Nat) : List Nat := (if i < 60 then (if i < 20 then (hs0[i-0]?.getD []) else (if i < 40 then (hs20[i-20]?.getD []) else (hs40[i-40]?.getD []))) else (if i < 80 then (hs60[i-60]?.getD []) else (if i < 100 then (hs80[i-80]?.getD []) else (hs100[i-100]?.getD []))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R302887564742
