import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302888258518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e302888258518 : Closed e302888258518 ∧ code e302888258518 = 1402399886294 := by decide
theorem cert_e302888258518 : check e302888258518 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302888258522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e302888258522 : Closed e302888258522 ∧ code e302888258522 = 1402399886298 := by decide
def e302888258798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e302888258798 : Closed e302888258798 ∧ code e302888258798 = 1402399886574 := by decide
theorem cert_e302888258798 : check e302888258798 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e302888258806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e302888258806 : Closed e302888258806 ∧ code e302888258806 = 1402399886582 := by decide
theorem cert_e302888258806 : check e302888258806 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e302888259182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e302888259182 : Closed e302888259182 ∧ code e302888259182 = 1402399886958 := by decide
theorem cert_e302888259182 : checkPay e302888259182 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e302888259194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e302888259194 : Closed e302888259194 ∧ code e302888259194 = 1402399886970 := by decide
theorem cert_e302888259194 : check e302888259194 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302888259382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e302888259382 : Closed e302888259382 ∧ code e302888259382 = 1402399887158 := by decide
def e302888259386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e302888259386 : Closed e302888259386 ∧ code e302888259386 = 1402399887162 := by decide
def e302889572062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e302889572062 : Closed e302889572062 ∧ code e302889572062 = 1402401199838 := by decide
private def t_e302889572062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem cert_e302889572062 : ¬ IsSelfInterpreter e302889572062 :=
  wSource (t := t_e302889572062) (replay_sound (ps := []) (t := e302889572062) (by decide)) (by decide)
def e302889572086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e302889572086 : Closed e302889572086 ∧ code e302889572086 = 1402401199862 := by decide
private def t_e302889572086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem cert_e302889572086 : ¬ IsSelfInterpreter e302889572086 :=
  wSource (t := t_e302889572086) (replay_sound (ps := []) (t := e302889572086) (by decide)) (by decide)
def e302889572190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e302889572190 : Closed e302889572190 ∧ code e302889572190 = 1402401199966 := by decide
private def t_e302889572190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem cert_e302889572190 : ¬ IsSelfInterpreter e302889572190 :=
  wSource (t := t_e302889572190) (replay_sound (ps := []) (t := e302889572190) (by decide)) (by decide)
def e302889572218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e302889572218 : Closed e302889572218 ∧ code e302889572218 = 1402401199994 := by decide
private def t_e302889572218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem cert_e302889572218 : ¬ IsSelfInterpreter e302889572218 :=
  wSource (t := t_e302889572218) (replay_sound (ps := []) (t := e302889572218) (by decide)) (by decide)
def e302889572310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e302889572310 : Closed e302889572310 ∧ code e302889572310 = 1402401200086 := by decide
private def t_e302889572310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem cert_e302889572310 : ¬ IsSelfInterpreter e302889572310 :=
  wSource (t := t_e302889572310) (replay_sound (ps := []) (t := e302889572310) (by decide)) (by decide)
def e302889572314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e302889572314 : Closed e302889572314 ∧ code e302889572314 = 1402401200090 := by decide
private def t_e302889572314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem cert_e302889572314 : ¬ IsSelfInterpreter e302889572314 :=
  wSource (t := t_e302889572314) (replay_sound (ps := []) (t := e302889572314) (by decide)) (by decide)
def e302889572830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e302889572830 : Closed e302889572830 ∧ code e302889572830 = 1402401200606 := by decide
private def t_e302889572830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem cert_e302889572830 : ¬ IsSelfInterpreter e302889572830 :=
  wSource (t := t_e302889572830) (replay_sound (ps := []) (t := e302889572830) (by decide)) (by decide)
def e302889572854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e302889572854 : Closed e302889572854 ∧ code e302889572854 = 1402401200630 := by decide
private def t_e302889572854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem cert_e302889572854 : ¬ IsSelfInterpreter e302889572854 :=
  wSource (t := t_e302889572854) (replay_sound (ps := []) (t := e302889572854) (by decide)) (by decide)
def e302889573598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e302889573598 : Closed e302889573598 ∧ code e302889573598 = 1402401201374 := by decide
private def t_e302889573598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem cert_e302889573598 : ¬ IsSelfInterpreter e302889573598 :=
  wSource (t := t_e302889573598) (replay_sound (ps := []) (t := e302889573598) (by decide)) (by decide)
def e302889573626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e302889573626 : Closed e302889573626 ∧ code e302889573626 = 1402401201402 := by decide
private def t_e302889573626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem cert_e302889573626 : ¬ IsSelfInterpreter e302889573626 :=
  wSource (t := t_e302889573626) (replay_sound (ps := []) (t := e302889573626) (by decide)) (by decide)
def e302889574198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e302889574198 : Closed e302889574198 ∧ code e302889574198 = 1402401201974 := by decide
private def t_e302889574198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem cert_e302889574198 : ¬ IsSelfInterpreter e302889574198 :=
  wSource (t := t_e302889574198) (replay_sound (ps := []) (t := e302889574198) (by decide)) (by decide)
def e302889574202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e302889574202 : Closed e302889574202 ∧ code e302889574202 = 1402401201978 := by decide
private def t_e302889574202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem cert_e302889574202 : ¬ IsSelfInterpreter e302889574202 :=
  wSource (t := t_e302889574202) (replay_sound (ps := []) (t := e302889574202) (by decide)) (by decide)
def e302889588974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e302889588974 : Closed e302889588974 ∧ code e302889588974 = 1402401216750 := by decide
private def t_e302889588974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem cert_e302889588974 : ¬ IsSelfInterpreter e302889588974 :=
  wSource (t := t_e302889588974) (replay_sound (ps := []) (t := e302889588974) (by decide)) (by decide)
def e302889588982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e302889588982 : Closed e302889588982 ∧ code e302889588982 = 1402401216758 := by decide
private def t_e302889588982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem cert_e302889588982 : ¬ IsSelfInterpreter e302889588982 :=
  wSource (t := t_e302889588982) (replay_sound (ps := []) (t := e302889588982) (by decide)) (by decide)
def e302889589534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e302889589534 : Closed e302889589534 ∧ code e302889589534 = 1402401217310 := by decide
private def t_e302889589534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem cert_e302889589534 : ¬ IsSelfInterpreter e302889589534 :=
  wSource (t := t_e302889589534) (replay_sound (ps := []) (t := e302889589534) (by decide)) (by decide)
def e302889589646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e302889589646 : Closed e302889589646 ∧ code e302889589646 = 1402401217422 := by decide
private def t_e302889589646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem cert_e302889589646 : ¬ IsSelfInterpreter e302889589646 :=
  wSource (t := t_e302889589646) (replay_sound (ps := []) (t := e302889589646) (by decide)) (by decide)
def e302889589870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302889589870 : Closed e302889589870 ∧ code e302889589870 = 1402401217646 := by decide
private def t_e302889589870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem cert_e302889589870 : ¬ IsSelfInterpreter e302889589870 :=
  wSource (t := t_e302889589870) (replay_sound (ps := []) (t := e302889589870) (by decide)) (by decide)
def e302889589882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302889589882 : Closed e302889589882 ∧ code e302889589882 = 1402401217658 := by decide
private def t_e302889589882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem cert_e302889589882 : ¬ IsSelfInterpreter e302889589882 :=
  wSource (t := t_e302889589882) (replay_sound (ps := []) (t := e302889589882) (by decide)) (by decide)
def e302889590046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302889590046 : Closed e302889590046 ∧ code e302889590046 = 1402401217822 := by decide
private def t_e302889590046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem cert_e302889590046 : ¬ IsSelfInterpreter e302889590046 :=
  wSource (t := t_e302889590046) (replay_sound (ps := []) (t := e302889590046) (by decide)) (by decide)
def e302889590214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302889590214 : Closed e302889590214 ∧ code e302889590214 = 1402401217990 := by decide
private def t_e302889590214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem cert_e302889590214 : ¬ IsSelfInterpreter e302889590214 :=
  wSource (t := t_e302889590214) (replay_sound (ps := []) (t := e302889590214) (by decide)) (by decide)
def e302889590326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302889590326 : Closed e302889590326 ∧ code e302889590326 = 1402401218102 := by decide
private def t_e302889590326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem cert_e302889590326 : ¬ IsSelfInterpreter e302889590326 :=
  wSource (t := t_e302889590326) (replay_sound (ps := []) (t := e302889590326) (by decide)) (by decide)
def e302889590330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302889590330 : Closed e302889590330 ∧ code e302889590330 = 1402401218106 := by decide
private def t_e302889590330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem cert_e302889590330 : ¬ IsSelfInterpreter e302889590330 :=
  wSource (t := t_e302889590330) (replay_sound (ps := []) (t := e302889590330) (by decide)) (by decide)
def e302889590414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302889590414 : Closed e302889590414 ∧ code e302889590414 = 1402401218190 := by decide
private def t_e302889590414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem cert_e302889590414 : ¬ IsSelfInterpreter e302889590414 :=
  wSource (t := t_e302889590414) (replay_sound (ps := []) (t := e302889590414) (by decide)) (by decide)
def e302889590470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302889590470 : Closed e302889590470 ∧ code e302889590470 = 1402401218246 := by decide
private def t_e302889590470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem cert_e302889590470 : ¬ IsSelfInterpreter e302889590470 :=
  wSource (t := t_e302889590470) (replay_sound (ps := []) (t := e302889590470) (by decide)) (by decide)
def e302889592606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e302889592606 : Closed e302889592606 ∧ code e302889592606 = 1402401220382 := by decide
private def t_e302889592606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem cert_e302889592606 : ¬ IsSelfInterpreter e302889592606 :=
  wSource (t := t_e302889592606) (replay_sound (ps := []) (t := e302889592606) (by decide)) (by decide)
def e302889592718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e302889592718 : Closed e302889592718 ∧ code e302889592718 = 1402401220494 := by decide
private def t_e302889592718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem cert_e302889592718 : ¬ IsSelfInterpreter e302889592718 :=
  wSource (t := t_e302889592718) (replay_sound (ps := []) (t := e302889592718) (by decide)) (by decide)
def e302889595678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302889595678 : Closed e302889595678 ∧ code e302889595678 = 1402401223454 := by decide
private def t_e302889595678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem cert_e302889595678 : ¬ IsSelfInterpreter e302889595678 :=
  wSource (t := t_e302889595678) (replay_sound (ps := []) (t := e302889595678) (by decide)) (by decide)
def e302889595846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302889595846 : Closed e302889595846 ∧ code e302889595846 = 1402401223622 := by decide
private def t_e302889595846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem cert_e302889595846 : ¬ IsSelfInterpreter e302889595846 :=
  wSource (t := t_e302889595846) (replay_sound (ps := []) (t := e302889595846) (by decide)) (by decide)
def e302889597326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302889597326 : Closed e302889597326 ∧ code e302889597326 = 1402401225102 := by decide
private def t_e302889597326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem cert_e302889597326 : ¬ IsSelfInterpreter e302889597326 :=
  wSource (t := t_e302889597326) (replay_sound (ps := []) (t := e302889597326) (by decide)) (by decide)
def e302889597382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302889597382 : Closed e302889597382 ∧ code e302889597382 = 1402401225158 := by decide
private def t_e302889597382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem cert_e302889597382 : ¬ IsSelfInterpreter e302889597382 :=
  wSource (t := t_e302889597382) (replay_sound (ps := []) (t := e302889597382) (by decide)) (by decide)
def e302895881150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 4)))))))))
theorem wire_e302895881150 : Closed e302895881150 ∧ code e302895881150 = 1402407508926 := by decide
theorem cert_e302895881150 : check e302895881150 [[],[],[],[]] .three = true := by decide
def e302895881198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 2)))))))))
theorem wire_e302895881198 : Closed e302895881198 ∧ code e302895881198 = 1402407508974 := by decide
theorem cert_e302895881198 : check e302895881198 [[],[],[],[]] .three = true := by decide
def e302895881918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 4)))))))))
theorem wire_e302895881918 : Closed e302895881918 ∧ code e302895881918 = 1402407509694 := by decide
theorem cert_e302895881918 : check e302895881918 [[],[],[],[]] .three = true := by decide
def e302895881978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 0)))))))))
theorem wire_e302895881978 : Closed e302895881978 ∧ code e302895881978 = 1402407509754 := by decide
theorem cert_e302895881978 : check e302895881978 [[],[],[],[]] .three = true := by decide
def e302895882158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 2)))))))))
theorem wire_e302895882158 : Closed e302895882158 ∧ code e302895882158 = 1402407509934 := by decide
theorem cert_e302895882158 : check e302895882158 [[],[],[],[]] .three = true := by decide
def e302895882170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 0)))))))))
theorem wire_e302895882170 : Closed e302895882170 ∧ code e302895882170 = 1402407509946 := by decide
theorem cert_e302895882170 : check e302895882170 [[],[],[],[]] .three = true := by decide
def e302895884222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 4))))))))))
theorem wire_e302895884222 : Closed e302895884222 ∧ code e302895884222 = 1402407511998 := by decide
theorem cert_e302895884222 : check e302895884222 [[],[],[],[]] .three = true := by decide
def e302895884270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 2))))))))))
theorem wire_e302895884270 : Closed e302895884270 ∧ code e302895884270 = 1402407512046 := by decide
theorem cert_e302895884270 : check e302895884270 [[],[],[],[]] .three = true := by decide
def e302895888830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 4))))))))))
theorem wire_e302895888830 : Closed e302895888830 ∧ code e302895888830 = 1402407516606 := by decide
theorem cert_e302895888830 : check e302895888830 [[],[],[],[]] .three = true := by decide
def e302895888890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.var 0))))))))))
theorem wire_e302895888890 : Closed e302895888890 ∧ code e302895888890 = 1402407516666 := by decide
theorem cert_e302895888890 : check e302895888890 [[],[],[],[]] .three = true := by decide
def e302895890030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 2))))))))))
theorem wire_e302895890030 : Closed e302895890030 ∧ code e302895890030 = 1402407517806 := by decide
theorem cert_e302895890030 : check e302895890030 [[],[],[],[]] .three = true := by decide
def e302895890042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.var 0))))))))))
theorem wire_e302895890042 : Closed e302895890042 ∧ code e302895890042 = 1402407517818 := by decide
theorem cert_e302895890042 : check e302895890042 [[],[],[],[]] .three = true := by decide
def e302895946462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e302895946462 : Closed e302895946462 ∧ code e302895946462 = 1402407574238 := by decide
theorem cert_e302895946462 : check e302895946462 [[],[],[],[]] .chain = true := by decide
def e302895946486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e302895946486 : Closed e302895946486 ∧ code e302895946486 = 1402407574262 := by decide
theorem cert_e302895946486 : check e302895946486 [[],[],[],[]] .chain = true := by decide
def e302895946590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e302895946590 : Closed e302895946590 ∧ code e302895946590 = 1402407574366 := by decide
theorem cert_e302895946590 : check e302895946590 [[],[],[],[]] .chain = true := by decide
def e302895946606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e302895946606 : Closed e302895946606 ∧ code e302895946606 = 1402407574382 := by decide
theorem cert_e302895946606 : check e302895946606 [[],[],[],[]] .chain = true := by decide
def e302895946614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e302895946614 : Closed e302895946614 ∧ code e302895946614 = 1402407574390 := by decide
theorem cert_e302895946614 : check e302895946614 [[],[],[],[]] .chain = true := by decide
def e302895946618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e302895946618 : Closed e302895946618 ∧ code e302895946618 = 1402407574394 := by decide
theorem cert_e302895946618 : check e302895946618 [[],[],[],[]] .chain = true := by decide
def e302895946678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e302895946678 : Closed e302895946678 ∧ code e302895946678 = 1402407574454 := by decide
theorem cert_e302895946678 : check e302895946678 [[],[],[],[]] .chain = true := by decide
def e302895946710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e302895946710 : Closed e302895946710 ∧ code e302895946710 = 1402407574486 := by decide
theorem cert_e302895946710 : check e302895946710 [[],[],[],[]] .chain = true := by decide
def e302895946714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e302895946714 : Closed e302895946714 ∧ code e302895946714 = 1402407574490 := by decide
theorem cert_e302895946714 : check e302895946714 [[],[],[],[]] .chain = true := by decide
def e302895947102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e302895947102 : Closed e302895947102 ∧ code e302895947102 = 1402407574878 := by decide
theorem cert_e302895947102 : check e302895947102 [[],[],[],[]] .chain = true := by decide
def e302895947118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302895947118 : Closed e302895947118 ∧ code e302895947118 = 1402407574894 := by decide
theorem cert_e302895947118 : check e302895947118 [[],[],[],[]] .chain = true := by decide
def e302895947126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302895947126 : Closed e302895947126 ∧ code e302895947126 = 1402407574902 := by decide
theorem cert_e302895947126 : check e302895947126 [[],[],[],[]] .chain = true := by decide
def e302895947130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e302895947130 : Closed e302895947130 ∧ code e302895947130 = 1402407574906 := by decide
theorem cert_e302895947130 : check e302895947130 [[],[],[],[]] .chain = true := by decide
def e302895947182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302895947182 : Closed e302895947182 ∧ code e302895947182 = 1402407574958 := by decide
theorem cert_e302895947182 : check e302895947182 [[],[],[],[]] .chain = true := by decide
def e302895947194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302895947194 : Closed e302895947194 ∧ code e302895947194 = 1402407574970 := by decide
theorem cert_e302895947194 : check e302895947194 [[],[],[],[]] .chain = true := by decide
def e302895947222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302895947222 : Closed e302895947222 ∧ code e302895947222 = 1402407574998 := by decide
theorem cert_e302895947222 : check e302895947222 [[],[],[],[]] .chain = true := by decide
def e302895947226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302895947226 : Closed e302895947226 ∧ code e302895947226 = 1402407575002 := by decide
theorem cert_e302895947226 : check e302895947226 [[],[],[],[]] .chain = true := by decide
def e302895947242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e302895947242 : Closed e302895947242 ∧ code e302895947242 = 1402407575018 := by decide
theorem cert_e302895947242 : check e302895947242 [[],[],[],[]] .chain = true := by decide
def e302895947446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e302895947446 : Closed e302895947446 ∧ code e302895947446 = 1402407575222 := by decide
theorem cert_e302895947446 : check e302895947446 [[],[],[],[]] .chain = true := by decide
def e302895947478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e302895947478 : Closed e302895947478 ∧ code e302895947478 = 1402407575254 := by decide
theorem cert_e302895947478 : check e302895947478 [[],[],[],[]] .chain = true := by decide
def e302895947482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e302895947482 : Closed e302895947482 ∧ code e302895947482 = 1402407575258 := by decide
theorem cert_e302895947482 : check e302895947482 [[],[],[],[]] .chain = true := by decide
def e302895947606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e302895947606 : Closed e302895947606 ∧ code e302895947606 = 1402407575382 := by decide
theorem cert_e302895947606 : check e302895947606 [[],[],[],[]] .chain = true := by decide
def e302895947610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e302895947610 : Closed e302895947610 ∧ code e302895947610 = 1402407575386 := by decide
theorem cert_e302895947610 : check e302895947610 [[],[],[],[]] .chain = true := by decide
def e302895947626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e302895947626 : Closed e302895947626 ∧ code e302895947626 = 1402407575402 := by decide
theorem cert_e302895947626 : check e302895947626 [[],[],[],[]] .chain = true := by decide
def e302895948766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 3))))))))
theorem wire_e302895948766 : Closed e302895948766 ∧ code e302895948766 = 1402407576542 := by decide
theorem cert_e302895948766 : check e302895948766 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302895948782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 2))))))))
theorem wire_e302895948782 : Closed e302895948782 ∧ code e302895948782 = 1402407576558 := by decide
theorem cert_e302895948782 : check e302895948782 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e302895949534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e302895949534 : Closed e302895949534 ∧ code e302895949534 = 1402407577310 := by decide
theorem cert_e302895949534 : check e302895949534 [[],[],[],[]] .chain = true := by decide
def e302895949558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e302895949558 : Closed e302895949558 ∧ code e302895949558 = 1402407577334 := by decide
theorem cert_e302895949558 : check e302895949558 [[],[],[],[]] .chain = true := by decide
def e302895949662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e302895949662 : Closed e302895949662 ∧ code e302895949662 = 1402407577438 := by decide
theorem cert_e302895949662 : check e302895949662 [[],[],[],[]] .chain = true := by decide
def e302895949678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e302895949678 : Closed e302895949678 ∧ code e302895949678 = 1402407577454 := by decide
theorem cert_e302895949678 : check e302895949678 [[],[],[],[]] .chain = true := by decide
def e302895949686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e302895949686 : Closed e302895949686 ∧ code e302895949686 = 1402407577462 := by decide
theorem cert_e302895949686 : check e302895949686 [[],[],[],[]] .chain = true := by decide
def e302895949690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e302895949690 : Closed e302895949690 ∧ code e302895949690 = 1402407577466 := by decide
theorem cert_e302895949690 : check e302895949690 [[],[],[],[]] .chain = true := by decide
def e302895949750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e302895949750 : Closed e302895949750 ∧ code e302895949750 = 1402407577526 := by decide
theorem cert_e302895949750 : check e302895949750 [[],[],[],[]] .chain = true := by decide
def e302895949782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e302895949782 : Closed e302895949782 ∧ code e302895949782 = 1402407577558 := by decide
theorem cert_e302895949782 : check e302895949782 [[],[],[],[]] .chain = true := by decide
def e302895949786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e302895949786 : Closed e302895949786 ∧ code e302895949786 = 1402407577562 := by decide
theorem cert_e302895949786 : check e302895949786 [[],[],[],[]] .chain = true := by decide
def e302895950302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e302895950302 : Closed e302895950302 ∧ code e302895950302 = 1402407578078 := by decide
theorem cert_e302895950302 : check e302895950302 [[],[],[],[]] .chain = true := by decide
def e302895950326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e302895950326 : Closed e302895950326 ∧ code e302895950326 = 1402407578102 := by decide
theorem cert_e302895950326 : check e302895950326 [[],[],[],[]] .chain = true := by decide
def e302895951070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302895951070 : Closed e302895951070 ∧ code e302895951070 = 1402407578846 := by decide
theorem cert_e302895951070 : check e302895951070 [[],[],[],[]] .chain = true := by decide
def e302895951086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302895951086 : Closed e302895951086 ∧ code e302895951086 = 1402407578862 := by decide
theorem cert_e302895951086 : check e302895951086 [[],[],[],[]] .chain = true := by decide
def e302895951094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302895951094 : Closed e302895951094 ∧ code e302895951094 = 1402407578870 := by decide
theorem cert_e302895951094 : check e302895951094 [[],[],[],[]] .chain = true := by decide
def e302895951098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302895951098 : Closed e302895951098 ∧ code e302895951098 = 1402407578874 := by decide
theorem cert_e302895951098 : check e302895951098 [[],[],[],[]] .chain = true := by decide
def e302895951422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e302895951422 : Closed e302895951422 ∧ code e302895951422 = 1402407579198 := by decide
theorem cert_e302895951422 : check e302895951422 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[],[]] .identityHead = true := by decide
def e302895951478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e302895951478 : Closed e302895951478 ∧ code e302895951478 = 1402407579254 := by decide
theorem cert_e302895951478 : check e302895951478 [[],[],[],[]] .chain = true := by decide
def e302895951646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e302895951646 : Closed e302895951646 ∧ code e302895951646 = 1402407579422 := by decide
theorem cert_e302895951646 : check e302895951646 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302895951670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302895951670 : Closed e302895951670 ∧ code e302895951670 = 1402407579446 := by decide
theorem cert_e302895951670 : check e302895951670 [[],[],[],[]] .chain = true := by decide
def e302895951674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302895951674 : Closed e302895951674 ∧ code e302895951674 = 1402407579450 := by decide
theorem cert_e302895951674 : check e302895951674 [[],[],[],[]] .chain = true := by decide
def e302895952734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e302895952734 : Closed e302895952734 ∧ code e302895952734 = 1402407580510 := by decide
theorem cert_e302895952734 : check e302895952734 [[],[],[],[]] .chain = true := by decide
def e302895952750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302895952750 : Closed e302895952750 ∧ code e302895952750 = 1402407580526 := by decide
theorem cert_e302895952750 : check e302895952750 [[],[],[],[]] .chain = true := by decide
def e302895952758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302895952758 : Closed e302895952758 ∧ code e302895952758 = 1402407580534 := by decide
theorem cert_e302895952758 : check e302895952758 [[],[],[],[]] .chain = true := by decide
def e302895952762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e302895952762 : Closed e302895952762 ∧ code e302895952762 = 1402407580538 := by decide
theorem cert_e302895952762 : check e302895952762 [[],[],[],[]] .chain = true := by decide
def e302895952814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302895952814 : Closed e302895952814 ∧ code e302895952814 = 1402407580590 := by decide
theorem cert_e302895952814 : check e302895952814 [[],[],[],[]] .chain = true := by decide
def e302895952826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302895952826 : Closed e302895952826 ∧ code e302895952826 = 1402407580602 := by decide
theorem cert_e302895952826 : check e302895952826 [[],[],[],[]] .chain = true := by decide
def e302895952854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302895952854 : Closed e302895952854 ∧ code e302895952854 = 1402407580630 := by decide
theorem cert_e302895952854 : check e302895952854 [[],[],[],[]] .chain = true := by decide
def e302895952858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302895952858 : Closed e302895952858 ∧ code e302895952858 = 1402407580634 := by decide
theorem cert_e302895952858 : check e302895952858 [[],[],[],[]] .chain = true := by decide
def e302895952874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e302895952874 : Closed e302895952874 ∧ code e302895952874 = 1402407580650 := by decide
theorem cert_e302895952874 : check e302895952874 [[],[],[],[]] .chain = true := by decide
def e302895953118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302895953118 : Closed e302895953118 ∧ code e302895953118 = 1402407580894 := by decide
theorem cert_e302895953118 : check e302895953118 [[],[],[],[]] .chain = true := by decide
def e302895953134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302895953134 : Closed e302895953134 ∧ code e302895953134 = 1402407580910 := by decide
theorem cert_e302895953134 : check e302895953134 [[],[],[],[]] .chain = true := by decide
def e302895953142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302895953142 : Closed e302895953142 ∧ code e302895953142 = 1402407580918 := by decide
theorem cert_e302895953142 : check e302895953142 [[],[],[],[]] .chain = true := by decide
def e302895953146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302895953146 : Closed e302895953146 ∧ code e302895953146 = 1402407580922 := by decide
theorem cert_e302895953146 : check e302895953146 [[],[],[],[]] .chain = true := by decide
def e302895953518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302895953518 : Closed e302895953518 ∧ code e302895953518 = 1402407581294 := by decide
theorem cert_e302895953518 : check e302895953518 [[],[],[],[]] .chain = true := by decide
def e302895953530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302895953530 : Closed e302895953530 ∧ code e302895953530 = 1402407581306 := by decide
theorem cert_e302895953530 : check e302895953530 [[],[],[],[]] .chain = true := by decide
def e302895953718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302895953718 : Closed e302895953718 ∧ code e302895953718 = 1402407581494 := by decide
theorem cert_e302895953718 : check e302895953718 [[],[],[],[]] .chain = true := by decide
def e302895953722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302895953722 : Closed e302895953722 ∧ code e302895953722 = 1402407581498 := by decide
theorem cert_e302895953722 : check e302895953722 [[],[],[],[]] .chain = true := by decide
def e302895953818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302895953818 : Closed e302895953818 ∧ code e302895953818 = 1402407581594 := by decide
theorem cert_e302895953818 : check e302895953818 [[],[],[],[]] .chain = true := by decide
def e302895954142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 3))))))))
theorem wire_e302895954142 : Closed e302895954142 ∧ code e302895954142 = 1402407581918 := by decide
theorem cert_e302895954142 : check e302895954142 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302895954170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 0))))))))
theorem wire_e302895954170 : Closed e302895954170 ∧ code e302895954170 = 1402407581946 := by decide
theorem cert_e302895954170 : check e302895954170 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302895954358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e302895954358 : Closed e302895954358 ∧ code e302895954358 = 1402407582134 := by decide
theorem cert_e302895954358 : check e302895954358 [[],[],[],[]] .chain = true := by decide
def e302895954390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e302895954390 : Closed e302895954390 ∧ code e302895954390 = 1402407582166 := by decide
theorem cert_e302895954390 : check e302895954390 [[],[],[],[]] .chain = true := by decide
def e302895954394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e302895954394 : Closed e302895954394 ∧ code e302895954394 = 1402407582170 := by decide
theorem cert_e302895954394 : check e302895954394 [[],[],[],[]] .chain = true := by decide
def e302895954494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e302895954494 : Closed e302895954494 ∧ code e302895954494 = 1402407582270 := by decide
theorem cert_e302895954494 : check e302895954494 [[],[],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302895954550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e302895954550 : Closed e302895954550 ∧ code e302895954550 = 1402407582326 := by decide
theorem cert_e302895954550 : check e302895954550 [[],[],[],[]] .chain = true := by decide
def e302895954742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302895954742 : Closed e302895954742 ∧ code e302895954742 = 1402407582518 := by decide
theorem cert_e302895954742 : check e302895954742 [[],[],[],[]] .chain = true := by decide
def e302895954746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302895954746 : Closed e302895954746 ∧ code e302895954746 = 1402407582522 := by decide
theorem cert_e302895954746 : check e302895954746 [[],[],[],[]] .chain = true := by decide
def e302895954886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e302895954886 : Closed e302895954886 ∧ code e302895954886 = 1402407582662 := by decide
private def t_e302895954886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 1)))))))))
theorem cert_e302895954886 : ¬ IsSelfInterpreter e302895954886 :=
  wSource (t := t_e302895954886) (replay_sound (ps := []) (t := e302895954886) (by decide)) (by decide)
def e302895955054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302895955054 : Closed e302895955054 ∧ code e302895955054 = 1402407582830 := by decide
theorem cert_e302895955054 : check e302895955054 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e302895955066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302895955066 : Closed e302895955066 ∧ code e302895955066 = 1402407582842 := by decide
theorem cert_e302895955066 : check e302895955066 [[],[],[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e302895955158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e302895955158 : Closed e302895955158 ∧ code e302895955158 = 1402407582934 := by decide
theorem cert_e302895955158 : check e302895955158 [[],[],[],[]] .chain = true := by decide
def e302895955162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e302895955162 : Closed e302895955162 ∧ code e302895955162 = 1402407582938 := by decide
theorem cert_e302895955162 : check e302895955162 [[],[],[],[]] .chain = true := by decide
def e302895955178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e302895955178 : Closed e302895955178 ∧ code e302895955178 = 1402407582954 := by decide
theorem cert_e302895955178 : check e302895955178 [[],[],[],[]] .chain = true := by decide
def e302895955230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302895955230 : Closed e302895955230 ∧ code e302895955230 = 1402407583006 := by decide
theorem cert_e302895955230 : check e302895955230 [[],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e302895955254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302895955254 : Closed e302895955254 ∧ code e302895955254 = 1402407583030 := by decide
theorem cert_e302895955254 : check e302895955254 [[],[],[],[]] .chain = true := by decide
def e302895955258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302895955258 : Closed e302895955258 ∧ code e302895955258 = 1402407583034 := by decide
theorem cert_e302895955258 : check e302895955258 [[],[],[],[]] .chain = true := by decide
def e302895955354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302895955354 : Closed e302895955354 ∧ code e302895955354 = 1402407583130 := by decide
theorem cert_e302895955354 : check e302895955354 [[],[],[],[]] .chain = true := by decide
def e302895955398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302895955398 : Closed e302895955398 ∧ code e302895955398 = 1402407583174 := by decide
private def t_e302895955398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 1)))))))))
theorem cert_e302895955398 : ¬ IsSelfInterpreter e302895955398 :=
  wSource (t := t_e302895955398) (replay_sound (ps := []) (t := e302895955398) (by decide)) (by decide)
def e302895957950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e302895957950 : Closed e302895957950 ∧ code e302895957950 = 1402407585726 := by decide
theorem cert_e302895957950 : check e302895957950 [[],[],[],[]] .chain = true := by decide
def e302895957998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e302895957998 : Closed e302895957998 ∧ code e302895957998 = 1402407585774 := by decide
theorem cert_e302895957998 : check e302895957998 [[],[],[],[]] .chain = true := by decide
def e302895961822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302895961822 : Closed e302895961822 ∧ code e302895961822 = 1402407589598 := by decide
theorem cert_e302895961822 : check e302895961822 [[],[],[],[]] .chain = true := by decide
def e302895961846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302895961846 : Closed e302895961846 ∧ code e302895961846 = 1402407589622 := by decide
theorem cert_e302895961846 : check e302895961846 [[],[],[],[]] .chain = true := by decide
def e302895961950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302895961950 : Closed e302895961950 ∧ code e302895961950 = 1402407589726 := by decide
theorem cert_e302895961950 : check e302895961950 [[],[],[],[]] .chain = true := by decide
def e302895961966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e302895961966 : Closed e302895961966 ∧ code e302895961966 = 1402407589742 := by decide
theorem cert_e302895961966 : check e302895961966 [[],[],[],[]] .chain = true := by decide
def e302895961974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e302895961974 : Closed e302895961974 ∧ code e302895961974 = 1402407589750 := by decide
theorem cert_e302895961974 : check e302895961974 [[],[],[],[]] .chain = true := by decide
def e302895961978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302895961978 : Closed e302895961978 ∧ code e302895961978 = 1402407589754 := by decide
theorem cert_e302895961978 : check e302895961978 [[],[],[],[]] .chain = true := by decide
def e302895962038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e302895962038 : Closed e302895962038 ∧ code e302895962038 = 1402407589814 := by decide
theorem cert_e302895962038 : check e302895962038 [[],[],[],[]] .chain = true := by decide
def e302895962070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302895962070 : Closed e302895962070 ∧ code e302895962070 = 1402407589846 := by decide
theorem cert_e302895962070 : check e302895962070 [[],[],[],[]] .chain = true := by decide
def e302895962074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302895962074 : Closed e302895962074 ∧ code e302895962074 = 1402407589850 := by decide
theorem cert_e302895962074 : check e302895962074 [[],[],[],[]] .chain = true := by decide
def e302895962590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302895962590 : Closed e302895962590 ∧ code e302895962590 = 1402407590366 := by decide
theorem cert_e302895962590 : check e302895962590 [[],[],[],[]] .chain = true := by decide
def e302895962614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302895962614 : Closed e302895962614 ∧ code e302895962614 = 1402407590390 := by decide
theorem cert_e302895962614 : check e302895962614 [[],[],[],[]] .chain = true := by decide
def e302895963358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302895963358 : Closed e302895963358 ∧ code e302895963358 = 1402407591134 := by decide
theorem cert_e302895963358 : check e302895963358 [[],[],[],[]] .chain = true := by decide
def e302895963374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e302895963374 : Closed e302895963374 ∧ code e302895963374 = 1402407591150 := by decide
theorem cert_e302895963374 : check e302895963374 [[],[],[],[]] .chain = true := by decide
def e302895963382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e302895963382 : Closed e302895963382 ∧ code e302895963382 = 1402407591158 := by decide
theorem cert_e302895963382 : check e302895963382 [[],[],[],[]] .chain = true := by decide
def e302895963386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302895963386 : Closed e302895963386 ∧ code e302895963386 = 1402407591162 := by decide
theorem cert_e302895963386 : check e302895963386 [[],[],[],[]] .chain = true := by decide
def e302895963710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e302895963710 : Closed e302895963710 ∧ code e302895963710 = 1402407591486 := by decide
theorem cert_e302895963710 : check e302895963710 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e302895963766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e302895963766 : Closed e302895963766 ∧ code e302895963766 = 1402407591542 := by decide
theorem cert_e302895963766 : check e302895963766 [[],[],[],[]] .chain = true := by decide
def e302895963934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e302895963934 : Closed e302895963934 ∧ code e302895963934 = 1402407591710 := by decide
theorem cert_e302895963934 : check e302895963934 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302895963958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302895963958 : Closed e302895963958 ∧ code e302895963958 = 1402407591734 := by decide
theorem cert_e302895963958 : check e302895963958 [[],[],[],[]] .chain = true := by decide
def e302895963962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302895963962 : Closed e302895963962 ∧ code e302895963962 = 1402407591738 := by decide
theorem cert_e302895963962 : check e302895963962 [[],[],[],[]] .chain = true := by decide
def e302895973310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e302895973310 : Closed e302895973310 ∧ code e302895973310 = 1402407601086 := by decide
theorem cert_e302895973310 : check e302895973310 [[],[],[],[]] .chain = true := by decide
def e302895973366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e302895973366 : Closed e302895973366 ∧ code e302895973366 = 1402407601142 := by decide
theorem cert_e302895973366 : check e302895973366 [[],[],[],[]] .chain = true := by decide
def e302895975262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e302895975262 : Closed e302895975262 ∧ code e302895975262 = 1402407603038 := by decide
theorem cert_e302895975262 : check e302895975262 [[],[],[],[]] .chain = true := by decide
def e302895975278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302895975278 : Closed e302895975278 ∧ code e302895975278 = 1402407603054 := by decide
theorem cert_e302895975278 : check e302895975278 [[],[],[],[]] .chain = true := by decide
end Blc.Floor40
