"""Demand-driven weak-head evaluation; finite closure addresses are call strings."""
from candidates import *
def analyze(t,k,cap=3000):
    # For testing a closed source alone. Free variables can optionally act as rigid heads.
    code=[]
    def tree(t):
        p=len(code);code.append(None)
        code[p]=(t[0],t[1]) if t[0]=='V' else (t[0],*(tree(x) for x in t[1:]))
        return p
    tree(t)
    # Dynamic settings: an abstract closure is code and its lexical address environment.
    # Trim unneeded environment suffix for efficiency.
    depths=[0]*len(code)
    for p,branch in reversed(list(enumerate(code))):
        if branch[0]=='V':depths[p]=branch[1]+1
        elif branch[0]=='A':depths[p]=max(depths[branch[1]],depths[branch[2]])
        else:depths[p]=max(0,depths[branch[1]]-1)
    states={};bind={}
    def demand(p,env,ctx):
        key=(p,env[:depths[p]],ctx)
        if key not in states:states[key]=set()
        return key
    top=demand(0,(),())
    for _ in range(200):
        old=(len(states),sum(map(len,states.values())),sum(map(len,bind.values())))
        if sum(old)>cap:return
        for (p,env,ctx),vs in list(states.items()):
            br=code[p]
            if br[0]=='L':vs.add((p,env))
            if br[0]=='V':
                if br[1]>=len(env):vs.add((-1,()))
                else:
                    for key in bind.get(env[br[1]],()):
                        vs.update(states[demand(key[0],key[1],ctx)])
            if br[0]=='A':
                f,a=br[1:];ff=demand(f,env,ctx)
                for l,le in list(states[ff]):
                    if l<0:vs.add((-1,()));continue
                    cx=(p,*ctx)[:k];addr=(l,cx)
                    bind.setdefault(addr,set()).add((a,env[:depths[a]]))
                    body=demand(code[l][1],(addr,)+le,cx)
                    vs.update(states[body])
        new=(len(states),sum(map(len,states.values())),sum(map(len,bind.values())))
        if old==new:return states[top],states,bind,code,depths
if __name__=='__main__':
    for k in range(3):
        missing=[]; stats=Counter()
        for line in (HERE/'open.txt').read_text().split():
            e=lc.decode(line)[0]
            z=analyze(e,k)
            if z is None or z[0]:missing.append(line)
            else:stats[len(z[1])]+=1
        print(k,'unresolved',len(missing),'states',stats,flush=True)
        (HERE/f'demand-rem{k}.txt').write_text('\n'.join(missing))
