from ranktest import *
from hard import variant
from genlean import expr, paths
def analyze(s):
    e=lc.decode(s)[0];best=None
    for kind,q in [('raw',e),('delta',A(e,om[1]))]:
        for style in [0,1]:
            t=q;ps=[]
            for j in range(14):
                for c in [1,2,3,4]:
                    n,m,ok=profile(t,c)
                    if ok and n==0 and (not best or len(ps)<len(best[2])):
                        best=(c,kind,ps,lc.enc(t))
                if best and len(best[2])<=len(ps)+1:break
                p=variant(t,style)
                if p is None:break
                t=bounded(t,p)
                if t is None:break
                ps=ps+[p]
    return best
def main():
    rows={s:r for s in open('open.txt').read().split() if (r:=analyze(s))}
    print(Counter((r[0],r[1]) for r in rows.values()))
    print('remaining without regular or weighted:')
    for s in open('open.txt').read().split():
        p=HERE/('r'+str(int(s,2))+'.json')
        if s not in rows and (not p.exists() or json.loads(p.read_text())[1]=='bottom1') and not (HERE/('h'+str(int(s,2))+'.json')).exists():print(s)
    (HERE/'weighted.json').write_text(json.dumps(rows))
    wires=sorted((HERE/'wires.txt').read_text().split())
    imports=sorted(set('Batch%03d'%(wires.index(s)//160) for s in rows))
    out=['import Weighted',*['import '+m for m in imports],'namespace Blc.Floor40.WeightedRows','open Term SelfintSharp WeakHeadClock Round3Floor38',
         'def diag := Term.lam (.app (.var 0) (.var 0))',
         '''theorem deltaCount {e : Term} (he : IsSelfInterpreter e) : ∃ n, Count (.app e diag) n := by
  obtain ⟨k,h⟩ := inputCount (e := e) (c := diag) (m := SelfintControl.identity) (r := .var 0)
    (args := []) (k := 3) he (by decide) (by decide)
  obtain ⟨m,_,hm⟩ := count_app_left h
  exact ⟨m,hm⟩''']
    for s,(c,k,ps,t) in rows.items():
        nm='e'+str(int(s,2));start=nm if k=='raw' else '(.app '+nm+' diag)'
        call='rawCount' if k=='raw' else 'deltaCount'
        u='t'+nm
        out += [f'private def {u} : Term := {expr(lc.decode(t)[0])}',f'''theorem ex_{nm} : ¬ IsSelfInterpreter {nm} := by
  intro he
  have run : replay {paths(ps)} {start} = some {u} := by decide
  obtain ⟨_,h⟩ := clocks_replay ({call} he) run
  exact Weighted.no_clock {c} (by decide : Closed {u}) (by decide) (by decide) h
#print axioms ex_{nm}''']
    out.append('end Blc.Floor40.WeightedRows')
    (HERE/'WeightedRows.lean').write_text('\n'.join(out)+'\n')
if __name__=='__main__':main()
