import R302902171894Data
namespace Certgen.R302902171894
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl1224 : FloorIndex.rangeOK validState 1224 12 = true := by decide +kernel
theorem bl1236 : FloorIndex.rangeOK validState 1236 12 = true := by decide +kernel
theorem bl1248 : FloorIndex.rangeOK validState 1248 12 = true := by decide +kernel
theorem bl1260 : FloorIndex.rangeOK validState 1260 12 = true := by decide +kernel
theorem bl1272 : FloorIndex.rangeOK validState 1272 12 = true := by decide +kernel
theorem bl1284 : FloorIndex.rangeOK validState 1284 12 = true := by decide +kernel
end Certgen.R302902171894
