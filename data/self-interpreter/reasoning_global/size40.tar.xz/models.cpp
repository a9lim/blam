// Enumerate coordinatewise monotone application tables on finite chains.
#include <cstdio>
#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <map>
#include <array>
using namespace std;
const int K=9;
int n,ap[K][K],env[50],hole[K],tableId;
struct T{int kind,v,f,a;};
vector<T> nodes;map<array<int,4>,int> tab;
int add(int k,int v,int f,int a){array<int,4> key={k,v,f,a}; if(tab.count(key))return tab[key];int i=nodes.size();nodes.push_back({k,v,f,a});return tab[key]=i;}
int parse(const string &s,int &p){if(s[p]=='1'){int v=0;while(s[++p]=='1')v++;p++;return add(0,v,0,0);}p++;if(s[p++]=='0')return add(1,0,parse(s,p),0);
int f=parse(s,p),a=parse(s,p);return add(2,0,f,a);}
int top=0;
int fv[20000];
vector<vector<int>> cache;
int eval(int p,int env){int &hit=cache[p][env];if(hit>=0)return hit;auto [k,v,f,a]=nodes[p];
 if(k==0){int b=env;for(int i=0;i<v;i++)b/=n;return hit=b%n;}
 if(k==2){return hit=ap[eval(f,env%fv[f])][eval(a,env%fv[a])];}
 int r=1;
 for(int x=0;x<n;x++){int value=eval(f,(env*n+x)%fv[f]);while(ap[r][x]<value)r++;}
 return hit=r;
}
vector<pair<string,int>> todo;
void search(){
 tableId++;
 for(auto &vs:cache)fill(vs.begin(),vs.end(),-1);
 auto it=todo.begin();
 while(it!=todo.end()){
  int r=eval(it->second,0);
  if(r==0){cout<<it->first<<" "<<n<<" ";for(int i=0;i<n;i++)for(int j=0;j<n;j++)cout<<ap[i][j];cout<<"\n";it=todo.erase(it);}
  else ++it;
 }
}
void gen(int i, int j){
 if(i==n-1){search();return;}
 int lo=max(i?ap[i-1][j]:0,j?ap[i][j-1]:0);
 for(int v=lo;v<n;v++){ap[i][j]=v;if(j==n-1)gen(i+1,0);else gen(i,j+1);}
}
int main(int argc,char**argv){
 string s;while(cin>>s){int p=0;todo.emplace_back(s,parse(s,p));}
 for(n=2;n<=atoi(argv[1]);n++){
  cache.clear();for(int i=0;i<(int)nodes.size();i++){auto [k,v,f,a]=nodes[i];int m=1;
   if(k==0){for(int j=0;j<=v;j++)m*=n;}else if(k==2)m=max(fv[f],fv[a]);else m=max(1,fv[f]/n);
   fv[i]=m;cache.emplace_back(m,-1);}
  fill(ap[n-1],ap[n-1]+n,n-1);tableId=0;gen(0,0);
  cerr<<"n="<<n<<" tables="<<tableId<<" remaining="<<todo.size()<<"\n";
 }
}
