import Parity
import R298668088686
import R298668088794
import R301464563162
import R301464563546
import R301464566202
import R301464566250
import R301464816502
import R301464816558
import R301464816570
import R301464816598
import R301464817274
import R302398863758
import R302398863814
import R302824744890
import R302824745454
import R302824747950
import R302824765934
import R302824803182
import R302824803246
import R302824803258
import R302824803290
import R302824803566
import R302824803574
import R302824803950
import R302824803962
import R302824804150
import R302824804154
import R302887492570
import R302887493466
import R302887501018
import R302887501034
import R302887560122
import R302887560154
import R302887562694
import R302887564410
import R302887564742
import R302887565882
import R302887593670
import R302887593798
import R302888259382
import R302888259386
import R302902155102
import R302902157114
import R302902171894
import R302902173238
import R302902173326
import R302902178590
import R302902178758
import R302902180238
import WeightedRows
namespace Blc.Floor40
def residuals : List Term := [e298668088686,e298668088794,e301464563130,e301464563162,e301464563386,e301464563434,e301464563546,e301464563562,e301464564666,e301464564698,e301464566202,e301464566250,e301464567002,e301464567018,e301464816494,e301464816502,e301464816558,e301464816570,e301464816598,e301464816602,e301464817274,e302309444538,e302309444570,e302398863758,e302398863814,e302824744890,e302824745454,e302824747950,e302824765934,e302824803182,e302824803246,e302824803258,e302824803290,e302824803566,e302824803574,e302824803950,e302824803962,e302824804150,e302824804154,e302887492474,e302887492570,e302887493098,e302887493466,e302887493482,e302887501018,e302887501034,e302887560122,e302887560154,e302887562362,e302887562694,e302887563706,e302887563754,e302887564410,e302887564742,e302887565882,e302887566022,e302887574650,e302887593530,e302887593670,e302887593754,e302887593798,e302888258414,e302888258490,e302888258522,e302888259382,e302888259386,e302897453294,e302897453302,e302897454190,e302897454202,e302897454646,e302897454650,e302897456926,e302897457038,e302897459998,e302897460166,e302897461646,e302897461702,e302902155102,e302902155130,e302902155226,e302902157114,e302902171894,e302902172782,e302902172794,e302902173238,e302902173326,e302902175518,e302902178590,e302902178758,e302902180238,e302902180294]
private def rs91 := e302902180294 :: []
private theorem reject91 (t : Term) (h : t ∈ rs91) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302902180294
  · simp at h
private def rs90 := e302902180238 :: rs91
private theorem reject90 (t : Term) (h : t ∈ rs90) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302902180238.excluded
  · exact reject91 _ h
private def rs89 := e302902178758 :: rs90
private theorem reject89 (t : Term) (h : t ∈ rs89) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302902178758.excluded
  · exact reject90 _ h
private def rs88 := e302902178590 :: rs89
private theorem reject88 (t : Term) (h : t ∈ rs88) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302902178590.excluded
  · exact reject89 _ h
private def rs87 := e302902175518 :: rs88
private theorem reject87 (t : Term) (h : t ∈ rs87) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302902175518
  · exact reject88 _ h
private def rs86 := e302902173326 :: rs87
private theorem reject86 (t : Term) (h : t ∈ rs86) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302902173326.excluded
  · exact reject87 _ h
private def rs85 := e302902173238 :: rs86
private theorem reject85 (t : Term) (h : t ∈ rs85) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302902173238.excluded
  · exact reject86 _ h
private def rs84 := e302902172794 :: rs85
private theorem reject84 (t : Term) (h : t ∈ rs84) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302902172794
  · exact reject85 _ h
private def rs83 := e302902172782 :: rs84
private theorem reject83 (t : Term) (h : t ∈ rs83) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302902172782
  · exact reject84 _ h
private def rs82 := e302902171894 :: rs83
private theorem reject82 (t : Term) (h : t ∈ rs82) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302902171894.excluded
  · exact reject83 _ h
private def rs81 := e302902157114 :: rs82
private theorem reject81 (t : Term) (h : t ∈ rs81) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302902157114.excluded
  · exact reject82 _ h
private def rs80 := e302902155226 :: rs81
private theorem reject80 (t : Term) (h : t ∈ rs80) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302902155226
  · exact reject81 _ h
private def rs79 := e302902155130 :: rs80
private theorem reject79 (t : Term) (h : t ∈ rs79) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302902155130
  · exact reject80 _ h
private def rs78 := e302902155102 :: rs79
private theorem reject78 (t : Term) (h : t ∈ rs78) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302902155102.excluded
  · exact reject79 _ h
private def rs77 := e302897461702 :: rs78
private theorem reject77 (t : Term) (h : t ∈ rs77) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302897461702
  · exact reject78 _ h
private def rs76 := e302897461646 :: rs77
private theorem reject76 (t : Term) (h : t ∈ rs76) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302897461646
  · exact reject77 _ h
private def rs75 := e302897460166 :: rs76
private theorem reject75 (t : Term) (h : t ∈ rs75) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302897460166
  · exact reject76 _ h
private def rs74 := e302897459998 :: rs75
private theorem reject74 (t : Term) (h : t ∈ rs74) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302897459998
  · exact reject75 _ h
private def rs73 := e302897457038 :: rs74
private theorem reject73 (t : Term) (h : t ∈ rs73) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302897457038
  · exact reject74 _ h
private def rs72 := e302897456926 :: rs73
private theorem reject72 (t : Term) (h : t ∈ rs72) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302897456926
  · exact reject73 _ h
private def rs71 := e302897454650 :: rs72
private theorem reject71 (t : Term) (h : t ∈ rs71) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302897454650
  · exact reject72 _ h
private def rs70 := e302897454646 :: rs71
private theorem reject70 (t : Term) (h : t ∈ rs70) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302897454646
  · exact reject71 _ h
private def rs69 := e302897454202 :: rs70
private theorem reject69 (t : Term) (h : t ∈ rs69) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302897454202
  · exact reject70 _ h
private def rs68 := e302897454190 :: rs69
private theorem reject68 (t : Term) (h : t ∈ rs68) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302897454190
  · exact reject69 _ h
private def rs67 := e302897453302 :: rs68
private theorem reject67 (t : Term) (h : t ∈ rs67) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302897453302
  · exact reject68 _ h
private def rs66 := e302897453294 :: rs67
private theorem reject66 (t : Term) (h : t ∈ rs66) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302897453294
  · exact reject67 _ h
private def rs65 := e302888259386 :: rs66
private theorem reject65 (t : Term) (h : t ∈ rs65) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302888259386.excluded
  · exact reject66 _ h
private def rs64 := e302888259382 :: rs65
private theorem reject64 (t : Term) (h : t ∈ rs64) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302888259382.excluded
  · exact reject65 _ h
private def rs63 := e302888258522 :: rs64
private theorem reject63 (t : Term) (h : t ∈ rs63) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302888258522
  · exact reject64 _ h
private def rs62 := e302888258490 :: rs63
private theorem reject62 (t : Term) (h : t ∈ rs62) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302888258490
  · exact reject63 _ h
private def rs61 := e302888258414 :: rs62
private theorem reject61 (t : Term) (h : t ∈ rs61) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302888258414
  · exact reject62 _ h
private def rs60 := e302887593798 :: rs61
private theorem reject60 (t : Term) (h : t ∈ rs60) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302887593798.excluded
  · exact reject61 _ h
private def rs59 := e302887593754 :: rs60
private theorem reject59 (t : Term) (h : t ∈ rs59) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302887593754
  · exact reject60 _ h
private def rs58 := e302887593670 :: rs59
private theorem reject58 (t : Term) (h : t ∈ rs58) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302887593670.excluded
  · exact reject59 _ h
private def rs57 := e302887593530 :: rs58
private theorem reject57 (t : Term) (h : t ∈ rs57) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302887593530
  · exact reject58 _ h
private def rs56 := e302887574650 :: rs57
private theorem reject56 (t : Term) (h : t ∈ rs56) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302887574650
  · exact reject57 _ h
private def rs55 := e302887566022 :: rs56
private theorem reject55 (t : Term) (h : t ∈ rs55) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.Parity.excluded
  · exact reject56 _ h
private def rs54 := e302887565882 :: rs55
private theorem reject54 (t : Term) (h : t ∈ rs54) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302887565882.excluded
  · exact reject55 _ h
private def rs53 := e302887564742 :: rs54
private theorem reject53 (t : Term) (h : t ∈ rs53) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302887564742.excluded
  · exact reject54 _ h
private def rs52 := e302887564410 :: rs53
private theorem reject52 (t : Term) (h : t ∈ rs52) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302887564410.excluded
  · exact reject53 _ h
private def rs51 := e302887563754 :: rs52
private theorem reject51 (t : Term) (h : t ∈ rs51) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302887563754
  · exact reject52 _ h
private def rs50 := e302887563706 :: rs51
private theorem reject50 (t : Term) (h : t ∈ rs50) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302887563706
  · exact reject51 _ h
private def rs49 := e302887562694 :: rs50
private theorem reject49 (t : Term) (h : t ∈ rs49) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302887562694.excluded
  · exact reject50 _ h
private def rs48 := e302887562362 :: rs49
private theorem reject48 (t : Term) (h : t ∈ rs48) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302887562362
  · exact reject49 _ h
private def rs47 := e302887560154 :: rs48
private theorem reject47 (t : Term) (h : t ∈ rs47) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302887560154.excluded
  · exact reject48 _ h
private def rs46 := e302887560122 :: rs47
private theorem reject46 (t : Term) (h : t ∈ rs46) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302887560122.excluded
  · exact reject47 _ h
private def rs45 := e302887501034 :: rs46
private theorem reject45 (t : Term) (h : t ∈ rs45) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302887501034.excluded
  · exact reject46 _ h
private def rs44 := e302887501018 :: rs45
private theorem reject44 (t : Term) (h : t ∈ rs44) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302887501018.excluded
  · exact reject45 _ h
private def rs43 := e302887493482 :: rs44
private theorem reject43 (t : Term) (h : t ∈ rs43) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302887493482
  · exact reject44 _ h
private def rs42 := e302887493466 :: rs43
private theorem reject42 (t : Term) (h : t ∈ rs42) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302887493466.excluded
  · exact reject43 _ h
private def rs41 := e302887493098 :: rs42
private theorem reject41 (t : Term) (h : t ∈ rs41) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302887493098
  · exact reject42 _ h
private def rs40 := e302887492570 :: rs41
private theorem reject40 (t : Term) (h : t ∈ rs40) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302887492570.excluded
  · exact reject41 _ h
private def rs39 := e302887492474 :: rs40
private theorem reject39 (t : Term) (h : t ∈ rs39) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302887492474
  · exact reject40 _ h
private def rs38 := e302824804154 :: rs39
private theorem reject38 (t : Term) (h : t ∈ rs38) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824804154.excluded
  · exact reject39 _ h
private def rs37 := e302824804150 :: rs38
private theorem reject37 (t : Term) (h : t ∈ rs37) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824804150.excluded
  · exact reject38 _ h
private def rs36 := e302824803962 :: rs37
private theorem reject36 (t : Term) (h : t ∈ rs36) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824803962.excluded
  · exact reject37 _ h
private def rs35 := e302824803950 :: rs36
private theorem reject35 (t : Term) (h : t ∈ rs35) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824803950.excluded
  · exact reject36 _ h
private def rs34 := e302824803574 :: rs35
private theorem reject34 (t : Term) (h : t ∈ rs34) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824803574.excluded
  · exact reject35 _ h
private def rs33 := e302824803566 :: rs34
private theorem reject33 (t : Term) (h : t ∈ rs33) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824803566.excluded
  · exact reject34 _ h
private def rs32 := e302824803290 :: rs33
private theorem reject32 (t : Term) (h : t ∈ rs32) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824803290.excluded
  · exact reject33 _ h
private def rs31 := e302824803258 :: rs32
private theorem reject31 (t : Term) (h : t ∈ rs31) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824803258.excluded
  · exact reject32 _ h
private def rs30 := e302824803246 :: rs31
private theorem reject30 (t : Term) (h : t ∈ rs30) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824803246.excluded
  · exact reject31 _ h
private def rs29 := e302824803182 :: rs30
private theorem reject29 (t : Term) (h : t ∈ rs29) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824803182.excluded
  · exact reject30 _ h
private def rs28 := e302824765934 :: rs29
private theorem reject28 (t : Term) (h : t ∈ rs28) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824765934.excluded
  · exact reject29 _ h
private def rs27 := e302824747950 :: rs28
private theorem reject27 (t : Term) (h : t ∈ rs27) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824747950.excluded
  · exact reject28 _ h
private def rs26 := e302824745454 :: rs27
private theorem reject26 (t : Term) (h : t ∈ rs26) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824745454.excluded
  · exact reject27 _ h
private def rs25 := e302824744890 :: rs26
private theorem reject25 (t : Term) (h : t ∈ rs25) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302824744890.excluded
  · exact reject26 _ h
private def rs24 := e302398863814 :: rs25
private theorem reject24 (t : Term) (h : t ∈ rs24) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302398863814.excluded
  · exact reject25 _ h
private def rs23 := e302398863758 :: rs24
private theorem reject23 (t : Term) (h : t ∈ rs23) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R302398863758.excluded
  · exact reject24 _ h
private def rs22 := e302309444570 :: rs23
private theorem reject22 (t : Term) (h : t ∈ rs22) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302309444570
  · exact reject23 _ h
private def rs21 := e302309444538 :: rs22
private theorem reject21 (t : Term) (h : t ∈ rs21) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e302309444538
  · exact reject22 _ h
private def rs20 := e301464817274 :: rs21
private theorem reject20 (t : Term) (h : t ∈ rs20) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R301464817274.excluded
  · exact reject21 _ h
private def rs19 := e301464816602 :: rs20
private theorem reject19 (t : Term) (h : t ∈ rs19) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e301464816602
  · exact reject20 _ h
private def rs18 := e301464816598 :: rs19
private theorem reject18 (t : Term) (h : t ∈ rs18) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R301464816598.excluded
  · exact reject19 _ h
private def rs17 := e301464816570 :: rs18
private theorem reject17 (t : Term) (h : t ∈ rs17) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R301464816570.excluded
  · exact reject18 _ h
private def rs16 := e301464816558 :: rs17
private theorem reject16 (t : Term) (h : t ∈ rs16) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R301464816558.excluded
  · exact reject17 _ h
private def rs15 := e301464816502 :: rs16
private theorem reject15 (t : Term) (h : t ∈ rs15) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R301464816502.excluded
  · exact reject16 _ h
private def rs14 := e301464816494 :: rs15
private theorem reject14 (t : Term) (h : t ∈ rs14) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e301464816494
  · exact reject15 _ h
private def rs13 := e301464567018 :: rs14
private theorem reject13 (t : Term) (h : t ∈ rs13) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e301464567018
  · exact reject14 _ h
private def rs12 := e301464567002 :: rs13
private theorem reject12 (t : Term) (h : t ∈ rs12) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e301464567002
  · exact reject13 _ h
private def rs11 := e301464566250 :: rs12
private theorem reject11 (t : Term) (h : t ∈ rs11) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R301464566250.excluded
  · exact reject12 _ h
private def rs10 := e301464566202 :: rs11
private theorem reject10 (t : Term) (h : t ∈ rs10) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R301464566202.excluded
  · exact reject11 _ h
private def rs9 := e301464564698 :: rs10
private theorem reject9 (t : Term) (h : t ∈ rs9) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e301464564698
  · exact reject10 _ h
private def rs8 := e301464564666 :: rs9
private theorem reject8 (t : Term) (h : t ∈ rs8) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e301464564666
  · exact reject9 _ h
private def rs7 := e301464563562 :: rs8
private theorem reject7 (t : Term) (h : t ∈ rs7) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e301464563562
  · exact reject8 _ h
private def rs6 := e301464563546 :: rs7
private theorem reject6 (t : Term) (h : t ∈ rs6) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R301464563546.excluded
  · exact reject7 _ h
private def rs5 := e301464563434 :: rs6
private theorem reject5 (t : Term) (h : t ∈ rs5) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e301464563434
  · exact reject6 _ h
private def rs4 := e301464563386 :: rs5
private theorem reject4 (t : Term) (h : t ∈ rs4) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e301464563386
  · exact reject5 _ h
private def rs3 := e301464563162 :: rs4
private theorem reject3 (t : Term) (h : t ∈ rs3) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R301464563162.excluded
  · exact reject4 _ h
private def rs2 := e301464563130 :: rs3
private theorem reject2 (t : Term) (h : t ∈ rs2) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Blc.Floor40.WeightedRows.ex_e301464563130
  · exact reject3 _ h
private def rs1 := e298668088794 :: rs2
private theorem reject1 (t : Term) (h : t ∈ rs1) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R298668088794.excluded
  · exact reject2 _ h
private def rs0 := e298668088686 :: rs1
private theorem reject0 (t : Term) (h : t ∈ rs0) : ¬ IsSelfInterpreter t := by
  rcases List.mem_cons.mp h with rfl | h
  · exact Certgen.R298668088686.excluded
  · exact reject1 _ h
theorem residuals_excluded (t : Term) (h : t ∈ residuals) : ¬ IsSelfInterpreter t := reject0 t h
#print axioms residuals_excluded
end Blc.Floor40
