import RegularBase
import Batch025
namespace Certgen.R301464563546
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 6,.lam 2,.app 3 4,.var 0,.lam 5,.var 1,.lam 7,.app 8 17,.app 9 10,.var 0,.lam 11,.lam 12,.app 13 16,.app 14 15,.var 2,.var 0,.var 1,.var 0]
def values : Array (List AClo) := #[[⟨6,[]⟩],[⟨10,[2]⟩],[⟨4,[0]⟩,⟨17,[2]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨6,[]⟩,0⟩],[⟨⟨4,[0]⟩,0⟩],[⟨⟨17,[2]⟩,0⟩],[⟨⟨10,[2]⟩,3⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[0]⟩,0⟩,⟨⟨3,[0]⟩,2⟩,⟨⟨4,[0]⟩,4⟩,⟨⟨5,[1,0]⟩,3⟩,⟨⟨6,[]⟩,2⟩,⟨⟨6,[]⟩,3⟩,⟨⟨7,[2]⟩,0⟩,⟨⟨8,[2]⟩,3⟩,⟨⟨9,[2]⟩,4⟩,⟨⟨17,[2]⟩,4⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[6],[5],[7],[8],[8],[9],[10],[4,11],[4,11]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<12 := hi
 exact range_sound block0 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def terms : Array Term := #[(.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))),(.lam (.app (.var 0) (.lam (.var 1)))),(.app (.var 0) (.lam (.var 1))),(.var 0),(.lam (.var 1)),(.var 1),(.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))),(.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)),(.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))),(.var 0),(.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))),(.lam (.app (.app (.var 2) (.var 0)) (.var 1))),(.app (.app (.var 2) (.var 0)) (.var 1)),(.app (.var 2) (.var 0)),(.var 2),(.var 0),(.var 1),(.var 0)]
def termAt (p : Nat) : Term := terms[p]?.getD (.var 0)
def aligns (p : Nat) : Bool := match P p with
 | .opaque => true
 | .var i => decide (termAt p = Term.var i)
 | .lam b => decide (termAt p = Term.lam (termAt b))
 | .app f a => decide (termAt p = Term.app (termAt f) (termAt a))
theorem valid : (List.range code.size).all aligns = true := by decide
theorem every (p : Nat) : aligns p = true := by
 by_cases hp : p < code.size
 · exact List.all_eq_true.mp valid p (List.mem_range.mpr hp)
 · have hz : code[p]? = none := Array.getElem?_eq_none (by omega)
   simp [aligns,P,hz]
def model : Model P where
 term := termAt
 var_eq := by intro p i h; simpa [aligns,h] using every p
 lam_eq := by intro p b h; simpa [aligns,h] using every p
 app_eq := by intro p f a h; simpa [aligns,h] using every p
theorem excluded : ¬ IsSelfInterpreter e301464563546 := by
 intro he
 have hp : replay [] e301464563546 = some (model.term 0) := by decide
 obtain ⟨h,hh⟩ := clocks_replay (rawCount he) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R301464563546
