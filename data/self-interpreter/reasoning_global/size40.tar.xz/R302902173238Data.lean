import R302902173238V0
import R302902173238K0
import R302902173238st0
import R302902173238hs0
import CodeBridge
import Batch063
namespace Certgen.R302902173238
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 101,.app 2 92,.app 3 55,.app 4 52,.app 5 18,.lam 6,.app 7 8,.var 0,.app 9 10,.var 0,.lam 11,.lam 12,.app 13 17,.app 14 15,.var 2,.lam 16,.var 1,.var 1,.app 19 32,.lam 20,.app 21 22,.var 0,.app 23 24,.var 0,.lam 25,.lam 26,.app 27 31,.app 28 29,.var 2,.lam 30,.var 1,.var 1,.lam 33,.lam 34,.app 35 51,.app 36 49,.lam 37,.app 38 39,.var 0,.app 40 41,.var 0,.lam 42,.lam 43,.app 44 48,.app 45 46,.var 2,.lam 47,.var 1,.var 1,.lam 50,.var 1,.var 1,.lam 53,.lam 54,.var 1,.lam 56,.app 57 62,.app 58 59,.var 0,.lam 60,.lam 61,.var 1,.lam 63,.app 64 69,.app 65 66,.var 0,.lam 67,.lam 68,.var 1,.lam 70,.app 71 76,.app 72 73,.var 0,.lam 74,.lam 75,.var 0,.lam 77,.app 78 83,.app 79 80,.var 0,.lam 81,.lam 82,.var 1,.app 84 88,.lam 85,.app 86 87,.var 0,.var 0,.lam 89,.app 90 91,.var 0,.var 0,.app 93 97,.lam 94,.app 95 96,.var 0,.var 0,.lam 98,.app 99 100,.var 0,.var 0,.lam 102,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (if i < 40 then (V20[i-20]?.getD []) else (V40[i-40]?.getD [])))
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (if i < 40 then (K20[i-20]?.getD []) else (K40[i-40]?.getD [])))
def st (i : Nat) : AState := if i < 143 then (if i < 80 then (if i < 40 then (if i < 20 then (st0[i-0]?.getD entry) else (st20[i-20]?.getD entry)) else (if i < 60 then (st40[i-40]?.getD entry) else (st60[i-60]?.getD entry))) else (if i < 120 then (if i < 100 then (st80[i-80]?.getD entry) else (st100[i-100]?.getD entry)) else (if i < 140 then (st120[i-120]?.getD entry) else (st140[i-140]?.getD entry)))) else entry
def hs (i : Nat) : List Nat := (if i < 80 then (if i < 40 then (if i < 20 then (hs0[i-0]?.getD []) else (hs20[i-20]?.getD [])) else (if i < 60 then (hs40[i-40]?.getD []) else (hs60[i-60]?.getD []))) else (if i < 120 then (if i < 100 then (hs80[i-80]?.getD []) else (hs100[i-100]?.getD [])) else (if i < 140 then (hs120[i-120]?.getD []) else (hs140[i-140]?.getD []))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R302902173238
