import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e107810495734 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e107810495734 : Closed e107810495734 ∧ code e107810495734 = 1207322123510 := by decide
theorem cert_e107810495734 : check e107810495734 [] .sourceHead = true := by decide
def e107810496118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e107810496118 : Closed e107810496118 ∧ code e107810496118 = 1207322123894 := by decide
theorem cert_e107810496118 : check e107810496118 [] .sourceHead = true := by decide
def e107810507630 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e107810507630 : Closed e107810507630 ∧ code e107810507630 = 1207322135406 := by decide
theorem cert_e107810507630 : check e107810507630 [] .sourceHead = true := by decide
def e107810507638 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e107810507638 : Closed e107810507638 ∧ code e107810507638 = 1207322135414 := by decide
theorem cert_e107810507638 : check e107810507638 [] .sourceHead = true := by decide
def e107810507694 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e107810507694 : Closed e107810507694 ∧ code e107810507694 = 1207322135470 := by decide
theorem cert_e107810507694 : check e107810507694 [] .sourceHead = true := by decide
def e107810507706 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e107810507706 : Closed e107810507706 ∧ code e107810507706 = 1207322135482 := by decide
theorem cert_e107810507706 : check e107810507706 [] .sourceHead = true := by decide
def e107810507734 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e107810507734 : Closed e107810507734 ∧ code e107810507734 = 1207322135510 := by decide
theorem cert_e107810507734 : check e107810507734 [] .sourceHead = true := by decide
def e107810507738 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e107810507738 : Closed e107810507738 ∧ code e107810507738 = 1207322135514 := by decide
theorem cert_e107810507738 : check e107810507738 [] .sourceHead = true := by decide
def e107810508014 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e107810508014 : Closed e107810508014 ∧ code e107810508014 = 1207322135790 := by decide
theorem cert_e107810508014 : check e107810508014 [] .sourceHead = true := by decide
def e107810508022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e107810508022 : Closed e107810508022 ∧ code e107810508022 = 1207322135798 := by decide
theorem cert_e107810508022 : check e107810508022 [] .sourceHead = true := by decide
def e107810508398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e107810508398 : Closed e107810508398 ∧ code e107810508398 = 1207322136174 := by decide
theorem cert_e107810508398 : check e107810508398 [] .sourceHead = true := by decide
def e107810508410 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e107810508410 : Closed e107810508410 ∧ code e107810508410 = 1207322136186 := by decide
theorem cert_e107810508410 : check e107810508410 [] .sourceHead = true := by decide
def e107810508598 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e107810508598 : Closed e107810508598 ∧ code e107810508598 = 1207322136374 := by decide
theorem cert_e107810508598 : check e107810508598 [] .sourceHead = true := by decide
def e107810508602 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e107810508602 : Closed e107810508602 ∧ code e107810508602 = 1207322136378 := by decide
theorem cert_e107810508602 : check e107810508602 [] .sourceHead = true := by decide
def e107810514358 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e107810514358 : Closed e107810514358 ∧ code e107810514358 = 1207322142134 := by decide
theorem cert_e107810514358 : check e107810514358 [] .sourceHead = true := by decide
def e107810514390 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e107810514390 : Closed e107810514390 ∧ code e107810514390 = 1207322142166 := by decide
theorem cert_e107810514390 : check e107810514390 [] .sourceHead = true := by decide
def e107810514394 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e107810514394 : Closed e107810514394 ∧ code e107810514394 = 1207322142170 := by decide
theorem cert_e107810514394 : check e107810514394 [] .sourceHead = true := by decide
def e107810514550 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e107810514550 : Closed e107810514550 ∧ code e107810514550 = 1207322142326 := by decide
theorem cert_e107810514550 : check e107810514550 [] .sourceHead = true := by decide
def e107810514742 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e107810514742 : Closed e107810514742 ∧ code e107810514742 = 1207322142518 := by decide
theorem cert_e107810514742 : check e107810514742 [] .sourceHead = true := by decide
def e107810514746 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e107810514746 : Closed e107810514746 ∧ code e107810514746 = 1207322142522 := by decide
theorem cert_e107810514746 : check e107810514746 [] .sourceHead = true := by decide
def e107810851694 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e107810851694 : Closed e107810851694 ∧ code e107810851694 = 1207322479470 := by decide
theorem cert_e107810851694 : check e107810851694 [] .sourceHead = true := by decide
def e107810851702 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e107810851702 : Closed e107810851702 ∧ code e107810851702 = 1207322479478 := by decide
theorem cert_e107810851702 : check e107810851702 [] .sourceHead = true := by decide
def e107810851758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e107810851758 : Closed e107810851758 ∧ code e107810851758 = 1207322479534 := by decide
theorem cert_e107810851758 : check e107810851758 [] .sourceHead = true := by decide
def e107810851770 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e107810851770 : Closed e107810851770 ∧ code e107810851770 = 1207322479546 := by decide
theorem cert_e107810851770 : check e107810851770 [] .sourceHead = true := by decide
def e107810851798 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e107810851798 : Closed e107810851798 ∧ code e107810851798 = 1207322479574 := by decide
theorem cert_e107810851798 : check e107810851798 [] .sourceHead = true := by decide
def e107810851802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e107810851802 : Closed e107810851802 ∧ code e107810851802 = 1207322479578 := by decide
theorem cert_e107810851802 : check e107810851802 [] .sourceHead = true := by decide
def e107810852078 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e107810852078 : Closed e107810852078 ∧ code e107810852078 = 1207322479854 := by decide
theorem cert_e107810852078 : check e107810852078 [] .sourceHead = true := by decide
def e107810852086 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e107810852086 : Closed e107810852086 ∧ code e107810852086 = 1207322479862 := by decide
theorem cert_e107810852086 : check e107810852086 [] .sourceHead = true := by decide
def e107810852462 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e107810852462 : Closed e107810852462 ∧ code e107810852462 = 1207322480238 := by decide
theorem cert_e107810852462 : check e107810852462 [] .sourceHead = true := by decide
def e107810852474 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e107810852474 : Closed e107810852474 ∧ code e107810852474 = 1207322480250 := by decide
theorem cert_e107810852474 : check e107810852474 [] .sourceHead = true := by decide
def e107810852662 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e107810852662 : Closed e107810852662 ∧ code e107810852662 = 1207322480438 := by decide
theorem cert_e107810852662 : check e107810852662 [] .sourceHead = true := by decide
def e107810852666 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e107810852666 : Closed e107810852666 ∧ code e107810852666 = 1207322480442 := by decide
theorem cert_e107810852666 : check e107810852666 [] .sourceHead = true := by decide
def e276335280326 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276335280326 : Closed e276335280326 ∧ code e276335280326 = 1375846908102 := by decide
theorem cert_e276335280326 : check e276335280326 [[]] .width = true := by decide
def e276336328902 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276336328902 : Closed e276336328902 ∧ code e276336328902 = 1375847956678 := by decide
theorem cert_e276336328902 : check e276336328902 [[]] .width = true := by decide
def e276336394438 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276336394438 : Closed e276336394438 ∧ code e276336394438 = 1375848022214 := by decide
theorem cert_e276336394438 : check e276336394438 [[]] .width = true := by decide
def e276343668934 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276343668934 : Closed e276343668934 ∧ code e276343668934 = 1375855296710 := by decide
theorem cert_e276343668934 : check e276343668934 [[]] .width = true := by decide
def e276345241798 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276345241798 : Closed e276345241798 ∧ code e276345241798 = 1375856869574 := by decide
theorem cert_e276345241798 : check e276345241798 [[]] .width = true := by decide
def e276345340102 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276345340102 : Closed e276345340102 ∧ code e276345340102 = 1375856967878 := by decide
theorem cert_e276345340102 : check e276345340102 [[]] .width = true := by decide
def e276348911814 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276348911814 : Closed e276348911814 ∧ code e276348911814 = 1375860539590 := by decide
theorem cert_e276348911814 : check e276348911814 [[]] .width = true := by decide
def e276348977350 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276348977350 : Closed e276348977350 ∧ code e276348977350 = 1375860605126 := by decide
theorem cert_e276348977350 : check e276348977350 [[]] .width = true := by decide
def e276349436102 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276349436102 : Closed e276349436102 ∧ code e276349436102 = 1375861063878 := by decide
theorem cert_e276349436102 : check e276349436102 [[]] .width = true := by decide
def e276349534406 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276349534406 : Closed e276349534406 ∧ code e276349534406 = 1375861162182 := by decide
theorem cert_e276349534406 : check e276349534406 [[]] .width = true := by decide
def e276349763782 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276349763782 : Closed e276349763782 ∧ code e276349763782 = 1375861391558 := by decide
theorem cert_e276349763782 : check e276349763782 [[]] .width = true := by decide
def e276349796550 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276349796550 : Closed e276349796550 ∧ code e276349796550 = 1375861424326 := by decide
theorem cert_e276349796550 : check e276349796550 [[]] .width = true := by decide
def e276385611974 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276385611974 : Closed e276385611974 ∧ code e276385611974 = 1375897239750 := by decide
theorem cert_e276385611974 : check e276385611974 [[]] .width = true := by decide
def e276386660550 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276386660550 : Closed e276386660550 ∧ code e276386660550 = 1375898288326 := by decide
theorem cert_e276386660550 : check e276386660550 [[]] .width = true := by decide
def e276386726086 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276386726086 : Closed e276386726086 ∧ code e276386726086 = 1375898353862 := by decide
theorem cert_e276386726086 : check e276386726086 [[]] .width = true := by decide
def e276408680646 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276408680646 : Closed e276408680646 ∧ code e276408680646 = 1375920308422 := by decide
theorem cert_e276408680646 : check e276408680646 [[]] .width = true := by decide
def e276414972102 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276414972102 : Closed e276414972102 ∧ code e276414972102 = 1375926599878 := by decide
theorem cert_e276414972102 : check e276414972102 [[]] .width = true := by decide
def e276415037638 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276415037638 : Closed e276415037638 ∧ code e276415037638 = 1375926665414 := by decide
theorem cert_e276415037638 : check e276415037638 [[]] .width = true := by decide
def e276435943622 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276435943622 : Closed e276435943622 ∧ code e276435943622 = 1375947571398 := by decide
theorem cert_e276435943622 : check e276435943622 [[]] .width = true := by decide
def e276437516486 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276437516486 : Closed e276437516486 ∧ code e276437516486 = 1375949144262 := by decide
theorem cert_e276437516486 : check e276437516486 [[]] .width = true := by decide
def e276437614790 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276437614790 : Closed e276437614790 ∧ code e276437614790 = 1375949242566 := by decide
theorem cert_e276437614790 : check e276437614790 [[]] .width = true := by decide
def e276442235078 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276442235078 : Closed e276442235078 ∧ code e276442235078 = 1375953862854 := by decide
theorem cert_e276442235078 : check e276442235078 [[]] .width = true := by decide
def e276451672262 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276451672262 : Closed e276451672262 ∧ code e276451672262 = 1375963300038 := by decide
theorem cert_e276451672262 : check e276451672262 [[]] .width = true := by decide
def e276451770566 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276451770566 : Closed e276451770566 ∧ code e276451770566 = 1375963398342 := by decide
theorem cert_e276451770566 : check e276451770566 [[]] .width = true := by decide
def e276462158022 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276462158022 : Closed e276462158022 ∧ code e276462158022 = 1375973785798 := by decide
theorem cert_e276462158022 : check e276462158022 [[]] .width = true := by decide
def e276462223558 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276462223558 : Closed e276462223558 ∧ code e276462223558 = 1375973851334 := by decide
theorem cert_e276462223558 : check e276462223558 [[]] .width = true := by decide
def e276462682310 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276462682310 : Closed e276462682310 ∧ code e276462682310 = 1375974310086 := by decide
theorem cert_e276462682310 : check e276462682310 [[]] .width = true := by decide
def e276462780614 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276462780614 : Closed e276462780614 ∧ code e276462780614 = 1375974408390 := by decide
theorem cert_e276462780614 : check e276462780614 [[]] .width = true := by decide
def e276463009990 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276463009990 : Closed e276463009990 ∧ code e276463009990 = 1375974637766 := by decide
theorem cert_e276463009990 : check e276463009990 [[]] .width = true := by decide
def e276463042758 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276463042758 : Closed e276463042758 ∧ code e276463042758 = 1375974670534 := by decide
theorem cert_e276463042758 : check e276463042758 [[]] .width = true := by decide
def e276465303750 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276465303750 : Closed e276465303750 ∧ code e276465303750 = 1375976931526 := by decide
theorem cert_e276465303750 : check e276465303750 [[]] .width = true := by decide
def e276465369286 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276465369286 : Closed e276465369286 ∧ code e276465369286 = 1375976997062 := by decide
theorem cert_e276465369286 : check e276465369286 [[]] .width = true := by decide
def e276468449478 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276468449478 : Closed e276468449478 ∧ code e276468449478 = 1375980077254 := by decide
theorem cert_e276468449478 : check e276468449478 [[]] .width = true := by decide
def e276468547782 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276468547782 : Closed e276468547782 ∧ code e276468547782 = 1375980175558 := by decide
theorem cert_e276468547782 : check e276468547782 [[]] .width = true := by decide
def e276470087878 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276470087878 : Closed e276470087878 ∧ code e276470087878 = 1375981715654 := by decide
theorem cert_e276470087878 : check e276470087878 [[]] .width = true := by decide
def e276470120646 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276470120646 : Closed e276470120646 ∧ code e276470120646 = 1375981748422 := by decide
theorem cert_e276470120646 : check e276470120646 [[]] .width = true := by decide
def e276586938566 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276586938566 : Closed e276586938566 ∧ code e276586938566 = 1376098566342 := by decide
theorem cert_e276586938566 : check e276586938566 [[]] .width = true := by decide
def e276587987142 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276587987142 : Closed e276587987142 ∧ code e276587987142 = 1376099614918 := by decide
theorem cert_e276587987142 : check e276587987142 [[]] .width = true := by decide
def e276588052678 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276588052678 : Closed e276588052678 ∧ code e276588052678 = 1376099680454 := by decide
theorem cert_e276588052678 : check e276588052678 [[]] .width = true := by decide
def e276610007238 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276610007238 : Closed e276610007238 ∧ code e276610007238 = 1376121635014 := by decide
theorem cert_e276610007238 : check e276610007238 [[]] .width = true := by decide
def e276616298694 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276616298694 : Closed e276616298694 ∧ code e276616298694 = 1376127926470 := by decide
theorem cert_e276616298694 : check e276616298694 [[]] .width = true := by decide
def e276616364230 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276616364230 : Closed e276616364230 ∧ code e276616364230 = 1376127992006 := by decide
theorem cert_e276616364230 : check e276616364230 [[]] .width = true := by decide
def e276805042374 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276805042374 : Closed e276805042374 ∧ code e276805042374 = 1376316670150 := by decide
theorem cert_e276805042374 : check e276805042374 [[]] .width = true := by decide
def e276806615238 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276806615238 : Closed e276806615238 ∧ code e276806615238 = 1376318243014 := by decide
theorem cert_e276806615238 : check e276806615238 [[]] .width = true := by decide
def e276806713542 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276806713542 : Closed e276806713542 ∧ code e276806713542 = 1376318341318 := by decide
theorem cert_e276806713542 : check e276806713542 [[]] .width = true := by decide
def e276811333830 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276811333830 : Closed e276811333830 ∧ code e276811333830 = 1376322961606 := by decide
theorem cert_e276811333830 : check e276811333830 [[]] .width = true := by decide
def e276820771014 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276820771014 : Closed e276820771014 ∧ code e276820771014 = 1376332398790 := by decide
theorem cert_e276820771014 : check e276820771014 [[]] .width = true := by decide
def e276820869318 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276820869318 : Closed e276820869318 ∧ code e276820869318 = 1376332497094 := by decide
theorem cert_e276820869318 : check e276820869318 [[]] .width = true := by decide
def e276915142854 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276915142854 : Closed e276915142854 ∧ code e276915142854 = 1376426770630 := by decide
theorem cert_e276915142854 : check e276915142854 [[]] .width = true := by decide
def e276915208390 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276915208390 : Closed e276915208390 ∧ code e276915208390 = 1376426836166 := by decide
theorem cert_e276915208390 : check e276915208390 [[]] .width = true := by decide
def e276915667142 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276915667142 : Closed e276915667142 ∧ code e276915667142 = 1376427294918 := by decide
theorem cert_e276915667142 : check e276915667142 [[]] .width = true := by decide
def e276915765446 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276915765446 : Closed e276915765446 ∧ code e276915765446 = 1376427393222 := by decide
theorem cert_e276915765446 : check e276915765446 [[]] .width = true := by decide
def e276915994822 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276915994822 : Closed e276915994822 ∧ code e276915994822 = 1376427622598 := by decide
theorem cert_e276915994822 : check e276915994822 [[]] .width = true := by decide
def e276916027590 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276916027590 : Closed e276916027590 ∧ code e276916027590 = 1376427655366 := by decide
theorem cert_e276916027590 : check e276916027590 [[]] .width = true := by decide
def e276918288582 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276918288582 : Closed e276918288582 ∧ code e276918288582 = 1376429916358 := by decide
theorem cert_e276918288582 : check e276918288582 [[]] .width = true := by decide
def e276918354118 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276918354118 : Closed e276918354118 ∧ code e276918354118 = 1376429981894 := by decide
theorem cert_e276918354118 : check e276918354118 [[]] .width = true := by decide
def e276921434310 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276921434310 : Closed e276921434310 ∧ code e276921434310 = 1376433062086 := by decide
theorem cert_e276921434310 : check e276921434310 [[]] .width = true := by decide
def e276921532614 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276921532614 : Closed e276921532614 ∧ code e276921532614 = 1376433160390 := by decide
theorem cert_e276921532614 : check e276921532614 [[]] .width = true := by decide
def e276923072710 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276923072710 : Closed e276923072710 ∧ code e276923072710 = 1376434700486 := by decide
theorem cert_e276923072710 : check e276923072710 [[]] .width = true := by decide
def e276923105478 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e276923105478 : Closed e276923105478 ∧ code e276923105478 = 1376434733254 := by decide
theorem cert_e276923105478 : check e276923105478 [[]] .width = true := by decide
def e282439642650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282439642650 : Closed e282439642650 ∧ code e282439642650 = 1381951270426 := by decide
theorem cert_e282439642650 : check e282439642650 [[]] .width = true := by decide
def e282439675418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282439675418 : Closed e282439675418 ∧ code e282439675418 = 1381951303194 := by decide
private def t_e282439675418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282439675418 : ¬ IsSelfInterpreter e282439675418 :=
  wSource (t := t_e282439675418) (replay_sound (ps := []) (t := e282439675418) (by decide)) (by decide)
def e282439677466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282439677466 : Closed e282439677466 ∧ code e282439677466 = 1381951305242 := by decide
private def t_e282439677466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282439677466 : ¬ IsSelfInterpreter e282439677466 :=
  wSource (t := t_e282439677466) (replay_sound (ps := []) (t := e282439677466) (by decide)) (by decide)
def e282439904794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282439904794 : Closed e282439904794 ∧ code e282439904794 = 1381951532570 := by decide
theorem cert_e282439904794 : check e282439904794 [[]] .width = true := by decide
def e282439953946 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282439953946 : Closed e282439953946 ∧ code e282439953946 = 1381951581722 := by decide
theorem cert_e282439953946 : check e282439953946 [[]] .width = true := by decide
def e282439957018 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282439957018 : Closed e282439957018 ∧ code e282439957018 = 1381951584794 := by decide
theorem cert_e282439957018 : check e282439957018 [[]] .width = true := by decide
def e282440068634 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282440068634 : Closed e282440068634 ∧ code e282440068634 = 1381951696410 := by decide
private def t_e282440068634 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282440068634 : ¬ IsSelfInterpreter e282440068634 :=
  wSource (t := t_e282440068634) (replay_sound (ps := []) (t := e282440068634) (by decide)) (by decide)
def e282440070682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282440070682 : Closed e282440070682 ∧ code e282440070682 = 1381951698458 := by decide
private def t_e282440070682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282440070682 : ¬ IsSelfInterpreter e282440070682 :=
  wSource (t := t_e282440070682) (replay_sound (ps := []) (t := e282440070682) (by decide)) (by decide)
def e282440085018 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282440085018 : Closed e282440085018 ∧ code e282440085018 = 1381951712794 := by decide
theorem cert_e282440085018 : check e282440085018 [[]] .width = true := by decide
def e282440088090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282440088090 : Closed e282440088090 ∧ code e282440088090 = 1381951715866 := by decide
theorem cert_e282440088090 : check e282440088090 [[]] .width = true := by decide
def e282440095258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282440095258 : Closed e282440095258 ∧ code e282440095258 = 1381951723034 := by decide
private def t_e282440095258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282440095258 : ¬ IsSelfInterpreter e282440095258 :=
  wSource (t := t_e282440095258) (replay_sound (ps := []) (t := e282440095258) (by decide)) (by decide)
def e282440096282 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282440096282 : Closed e282440096282 ∧ code e282440096282 = 1381951724058 := by decide
private def t_e282440096282 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282440096282 : ¬ IsSelfInterpreter e282440096282 :=
  wSource (t := t_e282440096282) (replay_sound (ps := []) (t := e282440096282) (by decide)) (by decide)
def e282440724678 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e282440724678 : Closed e282440724678 ∧ code e282440724678 = 1381952352454 := by decide
theorem cert_e282440724678 : check e282440724678 [[]] .width = true := by decide
def e282441215514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282441215514 : Closed e282441215514 ∧ code e282441215514 = 1381952843290 := by decide
theorem cert_e282441215514 : check e282441215514 [[]] .width = true := by decide
def e282441248282 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282441248282 : Closed e282441248282 ∧ code e282441248282 = 1381952876058 := by decide
theorem cert_e282441248282 : check e282441248282 [[]] .width = true := by decide
def e282441250330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282441250330 : Closed e282441250330 ∧ code e282441250330 = 1381952878106 := by decide
private def t_e282441250330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282441250330 : ¬ IsSelfInterpreter e282441250330 :=
  wSource (t := t_e282441250330) (replay_sound (ps := []) (t := e282441250330) (by decide)) (by decide)
def e282441936410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282441936410 : Closed e282441936410 ∧ code e282441936410 = 1381953564186 := by decide
theorem cert_e282441936410 : check e282441936410 [[]] .width = true := by decide
def e282442039322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282442039322 : Closed e282442039322 ∧ code e282442039322 = 1381953667098 := by decide
theorem cert_e282442039322 : check e282442039322 [[]] .width = true := by decide
def e282442039414 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e282442039414 : Closed e282442039414 ∧ code e282442039414 = 1381953667190 := by decide
theorem cert_e282442039414 : check e282442039414 [[]] .width = true := by decide
def e282442039658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e282442039658 : Closed e282442039658 ∧ code e282442039658 = 1381953667434 := by decide
theorem cert_e282442039658 : check e282442039658 [[]] .width = true := by decide
def e282442039706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e282442039706 : Closed e282442039706 ∧ code e282442039706 = 1381953667482 := by decide
theorem cert_e282442039706 : check e282442039706 [[]] .width = true := by decide
def e282442040714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e282442040714 : Closed e282442040714 ∧ code e282442040714 = 1381953668490 := by decide
theorem cert_e282442040714 : check e282442040714 [[]] .width = true := by decide
def e282442040738 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e282442040738 : Closed e282442040738 ∧ code e282442040738 = 1381953668514 := by decide
theorem cert_e282442040738 : check e282442040738 [[]] .width = true := by decide
def e282442040846 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e282442040846 : Closed e282442040846 ∧ code e282442040846 = 1381953668622 := by decide
theorem cert_e282442040846 : check e282442040846 [[]] .width = true := by decide
def e282442040858 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e282442040858 : Closed e282442040858 ∧ code e282442040858 = 1381953668634 := by decide
theorem cert_e282442040858 : check e282442040858 [[]] .width = true := by decide
def e282442040930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e282442040930 : Closed e282442040930 ∧ code e282442040930 = 1381953668706 := by decide
theorem cert_e282442040930 : check e282442040930 [[]] .width = true := by decide
def e282442100934 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e282442100934 : Closed e282442100934 ∧ code e282442100934 = 1381953728710 := by decide
theorem cert_e282442100934 : check e282442100934 [[]] .width = true := by decide
def e282442133018 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282442133018 : Closed e282442133018 ∧ code e282442133018 = 1381953760794 := by decide
private def t_e282442133018 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282442133018 : ¬ IsSelfInterpreter e282442133018 :=
  wSource (t := t_e282442133018) (replay_sound (ps := []) (t := e282442133018) (by decide)) (by decide)
def e282442135066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282442135066 : Closed e282442135066 ∧ code e282442135066 = 1381953762842 := by decide
private def t_e282442135066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282442135066 : ¬ IsSelfInterpreter e282442135066 :=
  wSource (t := t_e282442135066) (replay_sound (ps := []) (t := e282442135066) (by decide)) (by decide)
def e282442170394 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282442170394 : Closed e282442170394 ∧ code e282442170394 = 1381953798170 := by decide
theorem cert_e282442170394 : check e282442170394 [[]] .width = true := by decide
def e282442170486 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e282442170486 : Closed e282442170486 ∧ code e282442170486 = 1381953798262 := by decide
theorem cert_e282442170486 : check e282442170486 [[]] .width = true := by decide
def e282442170730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e282442170730 : Closed e282442170730 ∧ code e282442170730 = 1381953798506 := by decide
theorem cert_e282442170730 : check e282442170730 [[]] .width = true := by decide
def e282442170778 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e282442170778 : Closed e282442170778 ∧ code e282442170778 = 1381953798554 := by decide
theorem cert_e282442170778 : check e282442170778 [[]] .width = true := by decide
def e282442171786 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e282442171786 : Closed e282442171786 ∧ code e282442171786 = 1381953799562 := by decide
theorem cert_e282442171786 : check e282442171786 [[]] .width = true := by decide
def e282442171810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e282442171810 : Closed e282442171810 ∧ code e282442171810 = 1381953799586 := by decide
private def t_e282442171810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e282442171810 : ¬ IsSelfInterpreter e282442171810 :=
  wSource (t := t_e282442171810) (replay_sound (ps := []) (t := e282442171810) (by decide)) (by decide)
def e282442171918 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e282442171918 : Closed e282442171918 ∧ code e282442171918 = 1381953799694 := by decide
theorem cert_e282442171918 : check e282442171918 [[]] .width = true := by decide
def e282442171930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e282442171930 : Closed e282442171930 ∧ code e282442171930 = 1381953799706 := by decide
private def t_e282442171930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e282442171930 : ¬ IsSelfInterpreter e282442171930 :=
  wSource (t := t_e282442171930) (replay_sound (ps := []) (t := e282442171930) (by decide)) (by decide)
def e282442172002 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e282442172002 : Closed e282442172002 ∧ code e282442172002 = 1381953799778 := by decide
theorem cert_e282442172002 : check e282442172002 [[]] .width = true := by decide
def e282442559686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e282442559686 : Closed e282442559686 ∧ code e282442559686 = 1381954187462 := by decide
theorem cert_e282442559686 : check e282442559686 [[]] .width = true := by decide
def e282442788378 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282442788378 : Closed e282442788378 ∧ code e282442788378 = 1381954416154 := by decide
theorem cert_e282442788378 : check e282442788378 [[]] .width = true := by decide
def e282442837530 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282442837530 : Closed e282442837530 ∧ code e282442837530 = 1381954465306 := by decide
theorem cert_e282442837530 : check e282442837530 [[]] .width = true := by decide
def e282442840602 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282442840602 : Closed e282442840602 ∧ code e282442840602 = 1381954468378 := by decide
theorem cert_e282442840602 : check e282442840602 [[]] .width = true := by decide
def e282442984986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282442984986 : Closed e282442984986 ∧ code e282442984986 = 1381954612762 := by decide
theorem cert_e282442984986 : check e282442984986 [[]] .width = true := by decide
def e282443087898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282443087898 : Closed e282443087898 ∧ code e282443087898 = 1381954715674 := by decide
theorem cert_e282443087898 : check e282443087898 [[]] .width = true := by decide
def e282443087990 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e282443087990 : Closed e282443087990 ∧ code e282443087990 = 1381954715766 := by decide
theorem cert_e282443087990 : check e282443087990 [[]] .width = true := by decide
def e282443088234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e282443088234 : Closed e282443088234 ∧ code e282443088234 = 1381954716010 := by decide
theorem cert_e282443088234 : check e282443088234 [[]] .width = true := by decide
def e282443088282 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e282443088282 : Closed e282443088282 ∧ code e282443088282 = 1381954716058 := by decide
theorem cert_e282443088282 : check e282443088282 [[]] .width = true := by decide
def e282443089290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e282443089290 : Closed e282443089290 ∧ code e282443089290 = 1381954717066 := by decide
theorem cert_e282443089290 : check e282443089290 [[]] .width = true := by decide
def e282443089314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e282443089314 : Closed e282443089314 ∧ code e282443089314 = 1381954717090 := by decide
theorem cert_e282443089314 : check e282443089314 [[]] .width = true := by decide
def e282443089422 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e282443089422 : Closed e282443089422 ∧ code e282443089422 = 1381954717198 := by decide
theorem cert_e282443089422 : check e282443089422 [[]] .width = true := by decide
def e282443089434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e282443089434 : Closed e282443089434 ∧ code e282443089434 = 1381954717210 := by decide
theorem cert_e282443089434 : check e282443089434 [[]] .width = true := by decide
def e282443089506 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e282443089506 : Closed e282443089506 ∧ code e282443089506 = 1381954717282 := by decide
theorem cert_e282443089506 : check e282443089506 [[]] .width = true := by decide
def e282443264198 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e282443264198 : Closed e282443264198 ∧ code e282443264198 = 1381954891974 := by decide
theorem cert_e282443264198 : check e282443264198 [[]] .width = true := by decide
def e282443279898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443279898 : Closed e282443279898 ∧ code e282443279898 = 1381954907674 := by decide
theorem cert_e282443279898 : check e282443279898 [[]] .width = true := by decide
def e282443282970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443282970 : Closed e282443282970 ∧ code e282443282970 = 1381954910746 := by decide
theorem cert_e282443282970 : check e282443282970 [[]] .width = true := by decide
def e282443284506 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e282443284506 : Closed e282443284506 ∧ code e282443284506 = 1381954912282 := by decide
theorem cert_e282443284506 : check e282443284506 [[]] .width = true := by decide
def e282443284598 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e282443284598 : Closed e282443284598 ∧ code e282443284598 = 1381954912374 := by decide
theorem cert_e282443284598 : check e282443284598 [[]] .width = true := by decide
def e282443284842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e282443284842 : Closed e282443284842 ∧ code e282443284842 = 1381954912618 := by decide
theorem cert_e282443284842 : check e282443284842 [[]] .width = true := by decide
def e282443284890 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e282443284890 : Closed e282443284890 ∧ code e282443284890 = 1381954912666 := by decide
theorem cert_e282443284890 : check e282443284890 [[]] .width = true := by decide
def e282443285898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e282443285898 : Closed e282443285898 ∧ code e282443285898 = 1381954913674 := by decide
theorem cert_e282443285898 : check e282443285898 [[]] .width = true := by decide
def e282443285922 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e282443285922 : Closed e282443285922 ∧ code e282443285922 = 1381954913698 := by decide
theorem cert_e282443285922 : check e282443285922 [[]] .width = true := by decide
def e282443286030 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e282443286030 : Closed e282443286030 ∧ code e282443286030 = 1381954913806 := by decide
theorem cert_e282443286030 : check e282443286030 [[]] .width = true := by decide
def e282443286042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e282443286042 : Closed e282443286042 ∧ code e282443286042 = 1381954913818 := by decide
theorem cert_e282443286042 : check e282443286042 [[]] .width = true := by decide
def e282443286114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e282443286114 : Closed e282443286114 ∧ code e282443286114 = 1381954913890 := by decide
theorem cert_e282443286114 : check e282443286114 [[]] .width = true := by decide
def e282443493574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e282443493574 : Closed e282443493574 ∧ code e282443493574 = 1381955121350 := by decide
theorem cert_e282443493574 : check e282443493574 [[]] .width = true := by decide
def e282443501766 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e282443501766 : Closed e282443501766 ∧ code e282443501766 = 1381955129542 := by decide
theorem cert_e282443501766 : check e282443501766 [[]] .width = true := by decide
def e282443607578 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443607578 : Closed e282443607578 ∧ code e282443607578 = 1381955235354 := by decide
theorem cert_e282443607578 : check e282443607578 [[]] .width = true := by decide
def e282443609626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e282443609626 : Closed e282443609626 ∧ code e282443609626 = 1381955237402 := by decide
private def t_e282443609626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e282443609626 : ¬ IsSelfInterpreter e282443609626 :=
  wSource (t := t_e282443609626) (replay_sound (ps := []) (t := e282443609626) (by decide)) (by decide)
end Blc.Floor40
