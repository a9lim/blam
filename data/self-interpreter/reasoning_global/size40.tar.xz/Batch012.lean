import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e298702401050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298702401050 : Closed e298702401050 ∧ code e298702401050 = 1398214028826 := by decide
theorem cert_e298702401050 : check e298702401050 [[]] .width = true := by decide
def e298702403098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298702403098 : Closed e298702403098 ∧ code e298702403098 = 1398214030874 := by decide
theorem cert_e298702403098 : check e298702403098 [[]] .width = true := by decide
def e298702499354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298702499354 : Closed e298702499354 ∧ code e298702499354 = 1398214127130 := by decide
theorem cert_e298702499354 : check e298702499354 [[]] .width = true := by decide
def e298702502426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298702502426 : Closed e298702502426 ∧ code e298702502426 = 1398214130202 := by decide
theorem cert_e298702502426 : check e298702502426 [[]] .width = true := by decide
def e298702550554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298702550554 : Closed e298702550554 ∧ code e298702550554 = 1398214178330 := by decide
theorem cert_e298702550554 : check e298702550554 [[]] .width = true := by decide
def e298702551578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298702551578 : Closed e298702551578 ∧ code e298702551578 = 1398214179354 := by decide
theorem cert_e298702551578 : check e298702551578 [[]] .width = true := by decide
def e298718375278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e298718375278 : Closed e298718375278 ∧ code e298718375278 = 1398230003054 := by decide
theorem cert_e298718375278 : check e298718375278 [[],[.left],[]] .sourceHead = true := by decide
def e298718375286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e298718375286 : Closed e298718375286 ∧ code e298718375286 = 1398230003062 := by decide
theorem cert_e298718375286 : check e298718375286 [[],[.left],[]] .sourceHead = true := by decide
def e298718375342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e298718375342 : Closed e298718375342 ∧ code e298718375342 = 1398230003118 := by decide
theorem cert_e298718375342 : check e298718375342 [[],[.left],[]] .sourceHead = true := by decide
def e298718375354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e298718375354 : Closed e298718375354 ∧ code e298718375354 = 1398230003130 := by decide
theorem cert_e298718375354 : check e298718375354 [[],[.left],[]] .sourceHead = true := by decide
def e298718375382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e298718375382 : Closed e298718375382 ∧ code e298718375382 = 1398230003158 := by decide
theorem cert_e298718375382 : check e298718375382 [[],[.left],[]] .sourceHead = true := by decide
def e298718375386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e298718375386 : Closed e298718375386 ∧ code e298718375386 = 1398230003162 := by decide
theorem cert_e298718375386 : check e298718375386 [[],[.left],[]] .sourceHead = true := by decide
def e298718375598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e298718375598 : Closed e298718375598 ∧ code e298718375598 = 1398230003374 := by decide
theorem cert_e298718375598 : check e298718375598 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e298718375610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e298718375610 : Closed e298718375610 ∧ code e298718375610 = 1398230003386 := by decide
theorem cert_e298718375610 : check e298718375610 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e298718375658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e298718375658 : Closed e298718375658 ∧ code e298718375658 = 1398230003434 := by decide
theorem cert_e298718375658 : check e298718375658 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e298718375766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e298718375766 : Closed e298718375766 ∧ code e298718375766 = 1398230003542 := by decide
theorem cert_e298718375766 : check e298718375766 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .chain = true := by decide
def e298718375770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e298718375770 : Closed e298718375770 ∧ code e298718375770 = 1398230003546 := by decide
theorem cert_e298718375770 : check e298718375770 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e298718375786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e298718375786 : Closed e298718375786 ∧ code e298718375786 = 1398230003562 := by decide
theorem cert_e298718375786 : check e298718375786 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e298718376814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e298718376814 : Closed e298718376814 ∧ code e298718376814 = 1398230004590 := by decide
theorem cert_e298718376814 : check e298718376814 [[],[.left],[]] .sourceHead = true := by decide
def e298718376822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e298718376822 : Closed e298718376822 ∧ code e298718376822 = 1398230004598 := by decide
theorem cert_e298718376822 : check e298718376822 [[],[.left],[]] .sourceHead = true := by decide
def e298718376878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e298718376878 : Closed e298718376878 ∧ code e298718376878 = 1398230004654 := by decide
theorem cert_e298718376878 : check e298718376878 [[],[.left],[]] .sourceHead = true := by decide
def e298718376890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e298718376890 : Closed e298718376890 ∧ code e298718376890 = 1398230004666 := by decide
theorem cert_e298718376890 : check e298718376890 [[],[.left],[]] .sourceHead = true := by decide
def e298718376918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e298718376918 : Closed e298718376918 ∧ code e298718376918 = 1398230004694 := by decide
theorem cert_e298718376918 : check e298718376918 [[],[.left],[]] .sourceHead = true := by decide
def e298718376922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e298718376922 : Closed e298718376922 ∧ code e298718376922 = 1398230004698 := by decide
theorem cert_e298718376922 : check e298718376922 [[],[.left],[]] .sourceHead = true := by decide
def e298718377198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e298718377198 : Closed e298718377198 ∧ code e298718377198 = 1398230004974 := by decide
theorem cert_e298718377198 : check e298718377198 [[],[.left],[]] .sourceHead = true := by decide
def e298718377206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e298718377206 : Closed e298718377206 ∧ code e298718377206 = 1398230004982 := by decide
theorem cert_e298718377206 : check e298718377206 [[],[.left],[]] .sourceHead = true := by decide
def e298718377582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e298718377582 : Closed e298718377582 ∧ code e298718377582 = 1398230005358 := by decide
theorem cert_e298718377582 : check e298718377582 [[],[.left],[]] .sourceHead = true := by decide
def e298718377594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e298718377594 : Closed e298718377594 ∧ code e298718377594 = 1398230005370 := by decide
theorem cert_e298718377594 : check e298718377594 [[],[.left],[]] .sourceHead = true := by decide
def e298718377782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e298718377782 : Closed e298718377782 ∧ code e298718377782 = 1398230005558 := by decide
theorem cert_e298718377782 : check e298718377782 [[],[.left],[]] .sourceHead = true := by decide
def e298718377786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e298718377786 : Closed e298718377786 ∧ code e298718377786 = 1398230005562 := by decide
theorem cert_e298718377786 : check e298718377786 [[],[.left],[]] .sourceHead = true := by decide
def e298718378414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e298718378414 : Closed e298718378414 ∧ code e298718378414 = 1398230006190 := by decide
theorem cert_e298718378414 : check e298718378414 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e298718378426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e298718378426 : Closed e298718378426 ∧ code e298718378426 = 1398230006202 := by decide
theorem cert_e298718378426 : check e298718378426 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e298718378474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e298718378474 : Closed e298718378474 ∧ code e298718378474 = 1398230006250 := by decide
theorem cert_e298718378474 : check e298718378474 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e298718378606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e298718378606 : Closed e298718378606 ∧ code e298718378606 = 1398230006382 := by decide
theorem cert_e298718378606 : check e298718378606 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e298718378618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e298718378618 : Closed e298718378618 ∧ code e298718378618 = 1398230006394 := by decide
theorem cert_e298718378618 : check e298718378618 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e298718378906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e298718378906 : Closed e298718378906 ∧ code e298718378906 = 1398230006682 := by decide
theorem cert_e298718378906 : check e298718378906 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e298718379222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e298718379222 : Closed e298718379222 ∧ code e298718379222 = 1398230006998 := by decide
theorem cert_e298718379222 : check e298718379222 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e298718379226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e298718379226 : Closed e298718379226 ∧ code e298718379226 = 1398230007002 := by decide
theorem cert_e298718379226 : check e298718379226 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e298718379242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e298718379242 : Closed e298718379242 ∧ code e298718379242 = 1398230007018 := by decide
theorem cert_e298718379242 : check e298718379242 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e298718379318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e298718379318 : Closed e298718379318 ∧ code e298718379318 = 1398230007094 := by decide
theorem cert_e298718379318 : check e298718379318 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e298718379322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e298718379322 : Closed e298718379322 ∧ code e298718379322 = 1398230007098 := by decide
theorem cert_e298718379322 : check e298718379322 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e298718379418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e298718379418 : Closed e298718379418 ∧ code e298718379418 = 1398230007194 := by decide
theorem cert_e298718379418 : check e298718379418 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e298718382958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e298718382958 : Closed e298718382958 ∧ code e298718382958 = 1398230010734 := by decide
theorem cert_e298718382958 : check e298718382958 [[],[.left],[]] .sourceHead = true := by decide
def e298718382966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e298718382966 : Closed e298718382966 ∧ code e298718382966 = 1398230010742 := by decide
theorem cert_e298718382966 : check e298718382966 [[],[.left],[]] .sourceHead = true := by decide
def e298718383022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e298718383022 : Closed e298718383022 ∧ code e298718383022 = 1398230010798 := by decide
theorem cert_e298718383022 : check e298718383022 [[],[.left],[]] .sourceHead = true := by decide
def e298718383034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e298718383034 : Closed e298718383034 ∧ code e298718383034 = 1398230010810 := by decide
theorem cert_e298718383034 : check e298718383034 [[],[.left],[]] .sourceHead = true := by decide
def e298718383062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e298718383062 : Closed e298718383062 ∧ code e298718383062 = 1398230010838 := by decide
theorem cert_e298718383062 : check e298718383062 [[],[.left],[]] .sourceHead = true := by decide
def e298718383066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e298718383066 : Closed e298718383066 ∧ code e298718383066 = 1398230010842 := by decide
theorem cert_e298718383066 : check e298718383066 [[],[.left],[]] .sourceHead = true := by decide
def e298718383342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e298718383342 : Closed e298718383342 ∧ code e298718383342 = 1398230011118 := by decide
theorem cert_e298718383342 : check e298718383342 [[],[.left],[]] .sourceHead = true := by decide
def e298718383350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e298718383350 : Closed e298718383350 ∧ code e298718383350 = 1398230011126 := by decide
theorem cert_e298718383350 : check e298718383350 [[],[.left],[]] .sourceHead = true := by decide
def e298718383726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e298718383726 : Closed e298718383726 ∧ code e298718383726 = 1398230011502 := by decide
theorem cert_e298718383726 : check e298718383726 [[],[.left],[]] .sourceHead = true := by decide
def e298718383738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e298718383738 : Closed e298718383738 ∧ code e298718383738 = 1398230011514 := by decide
theorem cert_e298718383738 : check e298718383738 [[],[.left],[]] .sourceHead = true := by decide
def e298718383926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e298718383926 : Closed e298718383926 ∧ code e298718383926 = 1398230011702 := by decide
theorem cert_e298718383926 : check e298718383926 [[],[.left],[]] .sourceHead = true := by decide
def e298718383930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e298718383930 : Closed e298718383930 ∧ code e298718383930 = 1398230011706 := by decide
theorem cert_e298718383930 : check e298718383930 [[],[.left],[]] .sourceHead = true := by decide
def e298718389678 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e298718389678 : Closed e298718389678 ∧ code e298718389678 = 1398230017454 := by decide
theorem cert_e298718389678 : check e298718389678 [[],[.left],[],[.under]] .three = true := by decide
def e298718389690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e298718389690 : Closed e298718389690 ∧ code e298718389690 = 1398230017466 := by decide
theorem cert_e298718389690 : check e298718389690 [[],[.left],[],[.under]] .three = true := by decide
def e298718389738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e298718389738 : Closed e298718389738 ∧ code e298718389738 = 1398230017514 := by decide
theorem cert_e298718389738 : check e298718389738 [[],[.left],[],[.under]] .three = true := by decide
def e298718389870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e298718389870 : Closed e298718389870 ∧ code e298718389870 = 1398230017646 := by decide
theorem cert_e298718389870 : check e298718389870 [[],[.left],[],[.under]] .three = true := by decide
def e298718389882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e298718389882 : Closed e298718389882 ∧ code e298718389882 = 1398230017658 := by decide
theorem cert_e298718389882 : check e298718389882 [[],[.left],[],[.under]] .three = true := by decide
def e298718390170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e298718390170 : Closed e298718390170 ∧ code e298718390170 = 1398230017946 := by decide
theorem cert_e298718390170 : check e298718390170 [[],[.left],[],[.under]] .three = true := by decide
def e298718393046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e298718393046 : Closed e298718393046 ∧ code e298718393046 = 1398230020822 := by decide
theorem cert_e298718393046 : check e298718393046 [[],[.left],[],[.under]] .smaller = true := by decide
def e298718393050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e298718393050 : Closed e298718393050 ∧ code e298718393050 = 1398230020826 := by decide
theorem cert_e298718393050 : check e298718393050 [[],[.left],[],[.under]] .smaller = true := by decide
def e298718393066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e298718393066 : Closed e298718393066 ∧ code e298718393066 = 1398230020842 := by decide
theorem cert_e298718393066 : check e298718393066 [[],[.left],[],[.under]] .smaller = true := by decide
def e298718393142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e298718393142 : Closed e298718393142 ∧ code e298718393142 = 1398230020918 := by decide
theorem cert_e298718393142 : check e298718393142 [[],[.left],[],[.under]] .smaller = true := by decide
def e298718393146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e298718393146 : Closed e298718393146 ∧ code e298718393146 = 1398230020922 := by decide
theorem cert_e298718393146 : check e298718393146 [[],[.left],[],[.under]] .smaller = true := by decide
def e298718393242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e298718393242 : Closed e298718393242 ∧ code e298718393242 = 1398230021018 := by decide
theorem cert_e298718393242 : check e298718393242 [[],[.left],[],[.under]] .smaller = true := by decide
def e298718530414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e298718530414 : Closed e298718530414 ∧ code e298718530414 = 1398230158190 := by decide
theorem cert_e298718530414 : check e298718530414 [[],[.left],[],[]] .sourceHead = true := by decide
def e298718530422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e298718530422 : Closed e298718530422 ∧ code e298718530422 = 1398230158198 := by decide
theorem cert_e298718530422 : check e298718530422 [[],[.left],[],[]] .sourceHead = true := by decide
def e298718530478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e298718530478 : Closed e298718530478 ∧ code e298718530478 = 1398230158254 := by decide
theorem cert_e298718530478 : check e298718530478 [[],[.left],[],[]] .sourceHead = true := by decide
def e298718530490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e298718530490 : Closed e298718530490 ∧ code e298718530490 = 1398230158266 := by decide
theorem cert_e298718530490 : check e298718530490 [[],[.left],[],[]] .sourceHead = true := by decide
def e298718530518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e298718530518 : Closed e298718530518 ∧ code e298718530518 = 1398230158294 := by decide
theorem cert_e298718530518 : check e298718530518 [[],[.left],[],[]] .sourceHead = true := by decide
def e298718530522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e298718530522 : Closed e298718530522 ∧ code e298718530522 = 1398230158298 := by decide
theorem cert_e298718530522 : check e298718530522 [[],[.left],[],[]] .sourceHead = true := by decide
def e298718530798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e298718530798 : Closed e298718530798 ∧ code e298718530798 = 1398230158574 := by decide
theorem cert_e298718530798 : check e298718530798 [[],[.left],[],[]] .sourceHead = true := by decide
def e298718530806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e298718530806 : Closed e298718530806 ∧ code e298718530806 = 1398230158582 := by decide
theorem cert_e298718530806 : check e298718530806 [[],[.left],[],[]] .sourceHead = true := by decide
def e298718531182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e298718531182 : Closed e298718531182 ∧ code e298718531182 = 1398230158958 := by decide
theorem cert_e298718531182 : check e298718531182 [[],[.left],[],[]] .sourceHead = true := by decide
def e298718531194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e298718531194 : Closed e298718531194 ∧ code e298718531194 = 1398230158970 := by decide
theorem cert_e298718531194 : check e298718531194 [[],[.left],[],[]] .sourceHead = true := by decide
def e298718531382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e298718531382 : Closed e298718531382 ∧ code e298718531382 = 1398230159158 := by decide
theorem cert_e298718531382 : check e298718531382 [[],[.left],[],[]] .sourceHead = true := by decide
def e298718531386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e298718531386 : Closed e298718531386 ∧ code e298718531386 = 1398230159162 := by decide
theorem cert_e298718531386 : check e298718531386 [[],[.left],[],[]] .sourceHead = true := by decide
def e298719120238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e298719120238 : Closed e298719120238 ∧ code e298719120238 = 1398230748014 := by decide
theorem cert_e298719120238 : check e298719120238 [[],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e298719120246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e298719120246 : Closed e298719120246 ∧ code e298719120246 = 1398230748022 := by decide
theorem cert_e298719120246 : check e298719120246 [[],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e298719120302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e298719120302 : Closed e298719120302 ∧ code e298719120302 = 1398230748078 := by decide
theorem cert_e298719120302 : check e298719120302 [[],[.left],[.left],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e298719120314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e298719120314 : Closed e298719120314 ∧ code e298719120314 = 1398230748090 := by decide
private def t_e298719120314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e298719120314 : ¬ IsSelfInterpreter e298719120314 :=
  wSource (t := t_e298719120314) (replay_sound (ps := [[],[.left],[.left]]) (t := e298719120314) (by decide)) (by decide)
def e298719120342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e298719120342 : Closed e298719120342 ∧ code e298719120342 = 1398230748118 := by decide
theorem cert_e298719120342 : check e298719120342 [[],[.left],[.left],[],[],[],[.under,.left]] .chain = true := by decide
def e298719120346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e298719120346 : Closed e298719120346 ∧ code e298719120346 = 1398230748122 := by decide
private def t_e298719120346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e298719120346 : ¬ IsSelfInterpreter e298719120346 :=
  wSource (t := t_e298719120346) (replay_sound (ps := [[],[.left],[.left]]) (t := e298719120346) (by decide)) (by decide)
def e298719120622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e298719120622 : Closed e298719120622 ∧ code e298719120622 = 1398230748398 := by decide
theorem cert_e298719120622 : check e298719120622 [[],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e298719120630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e298719120630 : Closed e298719120630 ∧ code e298719120630 = 1398230748406 := by decide
theorem cert_e298719120630 : check e298719120630 [[],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e298719121006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e298719121006 : Closed e298719121006 ∧ code e298719121006 = 1398230748782 := by decide
theorem cert_e298719121006 : checkPay e298719121006 [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e298719121018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e298719121018 : Closed e298719121018 ∧ code e298719121018 = 1398230748794 := by decide
theorem cert_e298719121018 : check e298719121018 [[],[.left],[.left],[],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e298719121206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e298719121206 : Closed e298719121206 ∧ code e298719121206 = 1398230748982 := by decide
theorem cert_e298719121206 : check e298719121206 [[],[.left],[.left],[],[],[],[.under]] .sourceHead = true := by decide
def e298719121210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e298719121210 : Closed e298719121210 ∧ code e298719121210 = 1398230748986 := by decide
theorem cert_e298719121210 : check e298719121210 [[],[.left],[.left],[],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e299038596634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299038596634 : Closed e299038596634 ∧ code e299038596634 = 1398550224410 := by decide
private def t_e299038596634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299038596634 : ¬ IsSelfInterpreter e299038596634 :=
  wSource (t := t_e299038596634) (replay_sound (ps := []) (t := e299038596634) (by decide)) (by decide)
def e299038602778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299038602778 : Closed e299038602778 ∧ code e299038602778 = 1398550230554 := by decide
private def t_e299038602778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299038602778 : ¬ IsSelfInterpreter e299038602778 :=
  wSource (t := t_e299038602778) (replay_sound (ps := []) (t := e299038602778) (by decide)) (by decide)
def e299038629402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299038629402 : Closed e299038629402 ∧ code e299038629402 = 1398550257178 := by decide
private def t_e299038629402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299038629402 : ¬ IsSelfInterpreter e299038629402 :=
  wSource (t := t_e299038629402) (replay_sound (ps := []) (t := e299038629402) (by decide)) (by decide)
def e299038636570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299038636570 : Closed e299038636570 ∧ code e299038636570 = 1398550264346 := by decide
private def t_e299038636570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299038636570 : ¬ IsSelfInterpreter e299038636570 :=
  wSource (t := t_e299038636570) (replay_sound (ps := []) (t := e299038636570) (by decide)) (by decide)
def e299038660122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299038660122 : Closed e299038660122 ∧ code e299038660122 = 1398550287898 := by decide
private def t_e299038660122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299038660122 : ¬ IsSelfInterpreter e299038660122 :=
  wSource (t := t_e299038660122) (replay_sound (ps := []) (t := e299038660122) (by decide)) (by decide)
def e299038661146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299038661146 : Closed e299038661146 ∧ code e299038661146 = 1398550288922 := by decide
private def t_e299038661146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299038661146 : ¬ IsSelfInterpreter e299038661146 :=
  wSource (t := t_e299038661146) (replay_sound (ps := []) (t := e299038661146) (by decide)) (by decide)
def e299038793242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299038793242 : Closed e299038793242 ∧ code e299038793242 = 1398550421018 := by decide
private def t_e299038793242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299038793242 : ¬ IsSelfInterpreter e299038793242 :=
  wSource (t := t_e299038793242) (replay_sound (ps := []) (t := e299038793242) (by decide)) (by decide)
def e299038799386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299038799386 : Closed e299038799386 ∧ code e299038799386 = 1398550427162 := by decide
private def t_e299038799386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299038799386 : ¬ IsSelfInterpreter e299038799386 :=
  wSource (t := t_e299038799386) (replay_sound (ps := []) (t := e299038799386) (by decide)) (by decide)
def e299038989850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299038989850 : Closed e299038989850 ∧ code e299038989850 = 1398550617626 := by decide
private def t_e299038989850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299038989850 : ¬ IsSelfInterpreter e299038989850 :=
  wSource (t := t_e299038989850) (replay_sound (ps := []) (t := e299038989850) (by decide)) (by decide)
def e299038997018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299038997018 : Closed e299038997018 ∧ code e299038997018 = 1398550624794 := by decide
private def t_e299038997018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299038997018 : ¬ IsSelfInterpreter e299038997018 :=
  wSource (t := t_e299038997018) (replay_sound (ps := []) (t := e299038997018) (by decide)) (by decide)
def e299039143450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299039143450 : Closed e299039143450 ∧ code e299039143450 = 1398550771226 := by decide
private def t_e299039143450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299039143450 : ¬ IsSelfInterpreter e299039143450 :=
  wSource (t := t_e299039143450) (replay_sound (ps := []) (t := e299039143450) (by decide)) (by decide)
def e299039144474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299039144474 : Closed e299039144474 ∧ code e299039144474 = 1398550772250 := by decide
private def t_e299039144474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299039144474 : ¬ IsSelfInterpreter e299039144474 :=
  wSource (t := t_e299039144474) (replay_sound (ps := []) (t := e299039144474) (by decide)) (by decide)
def e299042926106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299042926106 : Closed e299042926106 ∧ code e299042926106 = 1398554553882 := by decide
private def t_e299042926106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299042926106 : ¬ IsSelfInterpreter e299042926106 :=
  wSource (t := t_e299042926106) (replay_sound (ps := []) (t := e299042926106) (by decide)) (by decide)
def e299042928154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299042928154 : Closed e299042928154 ∧ code e299042928154 = 1398554555930 := by decide
private def t_e299042928154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299042928154 : ¬ IsSelfInterpreter e299042928154 :=
  wSource (t := t_e299042928154) (replay_sound (ps := []) (t := e299042928154) (by decide)) (by decide)
def e299043069466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299043069466 : Closed e299043069466 ∧ code e299043069466 = 1398554697242 := by decide
private def t_e299043069466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299043069466 : ¬ IsSelfInterpreter e299043069466 :=
  wSource (t := t_e299043069466) (replay_sound (ps := []) (t := e299043069466) (by decide)) (by decide)
def e299043090630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e299043090630 : Closed e299043090630 ∧ code e299043090630 = 1398554718406 := by decide
theorem cert_e299043090630 : check e299043090630 [[]] .width = true := by decide
def e299043098138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299043098138 : Closed e299043098138 ∧ code e299043098138 = 1398554725914 := by decide
private def t_e299043098138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299043098138 : ¬ IsSelfInterpreter e299043098138 :=
  wSource (t := t_e299043098138) (replay_sound (ps := []) (t := e299043098138) (by decide)) (by decide)
def e299043107014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e299043107014 : Closed e299043107014 ∧ code e299043107014 = 1398554734790 := by decide
theorem cert_e299043107014 : check e299043107014 [[]] .width = true := by decide
def e299043155482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299043155482 : Closed e299043155482 ∧ code e299043155482 = 1398554783258 := by decide
private def t_e299043155482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299043155482 : ¬ IsSelfInterpreter e299043155482 :=
  wSource (t := t_e299043155482) (replay_sound (ps := []) (t := e299043155482) (by decide)) (by decide)
def e299043158554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299043158554 : Closed e299043158554 ∧ code e299043158554 = 1398554786330 := by decide
private def t_e299043158554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299043158554 : ¬ IsSelfInterpreter e299043158554 :=
  wSource (t := t_e299043158554) (replay_sound (ps := []) (t := e299043158554) (by decide)) (by decide)
def e299043200538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299043200538 : Closed e299043200538 ∧ code e299043200538 = 1398554828314 := by decide
private def t_e299043200538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299043200538 : ¬ IsSelfInterpreter e299043200538 :=
  wSource (t := t_e299043200538) (replay_sound (ps := []) (t := e299043200538) (by decide)) (by decide)
def e299043221702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e299043221702 : Closed e299043221702 ∧ code e299043221702 = 1398554849478 := by decide
theorem cert_e299043221702 : check e299043221702 [[]] .width = true := by decide
def e299043243546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299043243546 : Closed e299043243546 ∧ code e299043243546 = 1398554871322 := by decide
private def t_e299043243546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299043243546 : ¬ IsSelfInterpreter e299043243546 :=
  wSource (t := t_e299043243546) (replay_sound (ps := []) (t := e299043243546) (by decide)) (by decide)
def e299043246278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e299043246278 : Closed e299043246278 ∧ code e299043246278 = 1398554874054 := by decide
theorem cert_e299043246278 : check e299043246278 [[]] .width = true := by decide
def e299043272218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299043272218 : Closed e299043272218 ∧ code e299043272218 = 1398554899994 := by decide
private def t_e299043272218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299043272218 : ¬ IsSelfInterpreter e299043272218 :=
  wSource (t := t_e299043272218) (replay_sound (ps := []) (t := e299043272218) (by decide)) (by decide)
def e299043273242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299043273242 : Closed e299043273242 ∧ code e299043273242 = 1398554901018 := by decide
private def t_e299043273242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299043273242 : ¬ IsSelfInterpreter e299043273242 :=
  wSource (t := t_e299043273242) (replay_sound (ps := []) (t := e299043273242) (by decide)) (by decide)
def e299043294746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299043294746 : Closed e299043294746 ∧ code e299043294746 = 1398554922522 := by decide
private def t_e299043294746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299043294746 : ¬ IsSelfInterpreter e299043294746 :=
  wSource (t := t_e299043294746) (replay_sound (ps := []) (t := e299043294746) (by decide)) (by decide)
def e299043303622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e299043303622 : Closed e299043303622 ∧ code e299043303622 = 1398554931398 := by decide
theorem cert_e299043303622 : check e299043303622 [[]] .width = true := by decide
def e299043309082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299043309082 : Closed e299043309082 ∧ code e299043309082 = 1398554936858 := by decide
private def t_e299043309082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299043309082 : ¬ IsSelfInterpreter e299043309082 :=
  wSource (t := t_e299043309082) (replay_sound (ps := []) (t := e299043309082) (by decide)) (by decide)
def e299043311814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e299043311814 : Closed e299043311814 ∧ code e299043311814 = 1398554939590 := by decide
theorem cert_e299043311814 : check e299043311814 [[]] .width = true := by decide
def e299043855898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299043855898 : Closed e299043855898 ∧ code e299043855898 = 1398555483674 := by decide
private def t_e299043855898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299043855898 : ¬ IsSelfInterpreter e299043855898 :=
  wSource (t := t_e299043855898) (replay_sound (ps := []) (t := e299043855898) (by decide)) (by decide)
def e299043877062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e299043877062 : Closed e299043877062 ∧ code e299043877062 = 1398555504838 := by decide
theorem cert_e299043877062 : check e299043877062 [[]] .width = true := by decide
def e299043884570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299043884570 : Closed e299043884570 ∧ code e299043884570 = 1398555512346 := by decide
private def t_e299043884570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299043884570 : ¬ IsSelfInterpreter e299043884570 :=
  wSource (t := t_e299043884570) (replay_sound (ps := []) (t := e299043884570) (by decide)) (by decide)
def e299043893446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e299043893446 : Closed e299043893446 ∧ code e299043893446 = 1398555521222 := by decide
theorem cert_e299043893446 : check e299043893446 [[]] .width = true := by decide
def e299044642330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299044642330 : Closed e299044642330 ∧ code e299044642330 = 1398556270106 := by decide
private def t_e299044642330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299044642330 : ¬ IsSelfInterpreter e299044642330 :=
  wSource (t := t_e299044642330) (replay_sound (ps := []) (t := e299044642330) (by decide)) (by decide)
def e299044663494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e299044663494 : Closed e299044663494 ∧ code e299044663494 = 1398556291270 := by decide
theorem cert_e299044663494 : check e299044663494 [[]] .width = true := by decide
def e299044685338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299044685338 : Closed e299044685338 ∧ code e299044685338 = 1398556313114 := by decide
private def t_e299044685338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299044685338 : ¬ IsSelfInterpreter e299044685338 :=
  wSource (t := t_e299044685338) (replay_sound (ps := []) (t := e299044685338) (by decide)) (by decide)
def e299044688070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e299044688070 : Closed e299044688070 ∧ code e299044688070 = 1398556315846 := by decide
theorem cert_e299044688070 : check e299044688070 [[]] .width = true := by decide
def e299045064218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299045064218 : Closed e299045064218 ∧ code e299045064218 = 1398556691994 := by decide
private def t_e299045064218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299045064218 : ¬ IsSelfInterpreter e299045064218 :=
  wSource (t := t_e299045064218) (replay_sound (ps := []) (t := e299045064218) (by decide)) (by decide)
def e299045073094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e299045073094 : Closed e299045073094 ∧ code e299045073094 = 1398556700870 := by decide
theorem cert_e299045073094 : check e299045073094 [[]] .width = true := by decide
def e299045078554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e299045078554 : Closed e299045078554 ∧ code e299045078554 = 1398556706330 := by decide
private def t_e299045078554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e299045078554 : ¬ IsSelfInterpreter e299045078554 :=
  wSource (t := t_e299045078554) (replay_sound (ps := []) (t := e299045078554) (by decide)) (by decide)
def e299045081286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e299045081286 : Closed e299045081286 ∧ code e299045081286 = 1398556709062 := by decide
theorem cert_e299045081286 : check e299045081286 [[]] .width = true := by decide
def e299070741358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e299070741358 : Closed e299070741358 ∧ code e299070741358 = 1398582369134 := by decide
theorem cert_e299070741358 : check e299070741358 [[],[.left]] .chain = true := by decide
def e299070741366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e299070741366 : Closed e299070741366 ∧ code e299070741366 = 1398582369142 := by decide
theorem cert_e299070741366 : check e299070741366 [[],[.left]] .chain = true := by decide
def e299070741430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e299070741430 : Closed e299070741430 ∧ code e299070741430 = 1398582369206 := by decide
theorem cert_e299070741430 : check e299070741430 [[],[.left]] .chain = true := by decide
def e299070741870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e299070741870 : Closed e299070741870 ∧ code e299070741870 = 1398582369646 := by decide
theorem cert_e299070741870 : check e299070741870 [[],[.left]] .chain = true := by decide
def e299070741878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e299070741878 : Closed e299070741878 ∧ code e299070741878 = 1398582369654 := by decide
theorem cert_e299070741878 : check e299070741878 [[],[.left]] .chain = true := by decide
def e299070741934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e299070741934 : Closed e299070741934 ∧ code e299070741934 = 1398582369710 := by decide
theorem cert_e299070741934 : check e299070741934 [[],[.left]] .chain = true := by decide
def e299070741946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e299070741946 : Closed e299070741946 ∧ code e299070741946 = 1398582369722 := by decide
theorem cert_e299070741946 : check e299070741946 [[],[.left]] .chain = true := by decide
def e299070741974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e299070741974 : Closed e299070741974 ∧ code e299070741974 = 1398582369750 := by decide
theorem cert_e299070741974 : check e299070741974 [[],[.left]] .chain = true := by decide
def e299070741978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e299070741978 : Closed e299070741978 ∧ code e299070741978 = 1398582369754 := by decide
theorem cert_e299070741978 : check e299070741978 [[],[.left]] .chain = true := by decide
def e299070742198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e299070742198 : Closed e299070742198 ∧ code e299070742198 = 1398582369974 := by decide
theorem cert_e299070742198 : check e299070742198 [[],[.left]] .chain = true := by decide
def e299070742230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e299070742230 : Closed e299070742230 ∧ code e299070742230 = 1398582370006 := by decide
theorem cert_e299070742230 : check e299070742230 [[],[.left]] .chain = true := by decide
def e299070742234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e299070742234 : Closed e299070742234 ∧ code e299070742234 = 1398582370010 := by decide
theorem cert_e299070742234 : check e299070742234 [[],[.left]] .chain = true := by decide
def e299070744430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e299070744430 : Closed e299070744430 ∧ code e299070744430 = 1398582372206 := by decide
theorem cert_e299070744430 : check e299070744430 [[],[.left]] .chain = true := by decide
def e299070744438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e299070744438 : Closed e299070744438 ∧ code e299070744438 = 1398582372214 := by decide
theorem cert_e299070744438 : check e299070744438 [[],[.left]] .chain = true := by decide
def e299070744502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e299070744502 : Closed e299070744502 ∧ code e299070744502 = 1398582372278 := by decide
theorem cert_e299070744502 : check e299070744502 [[],[.left]] .chain = true := by decide
def e299070745838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e299070745838 : Closed e299070745838 ∧ code e299070745838 = 1398582373614 := by decide
theorem cert_e299070745838 : check e299070745838 [[],[.left]] .chain = true := by decide
def e299070745846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e299070745846 : Closed e299070745846 ∧ code e299070745846 = 1398582373622 := by decide
theorem cert_e299070745846 : check e299070745846 [[],[.left]] .chain = true := by decide
def e299070746230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e299070746230 : Closed e299070746230 ∧ code e299070746230 = 1398582374006 := by decide
theorem cert_e299070746230 : check e299070746230 [[],[.left]] .chain = true := by decide
def e299070747502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e299070747502 : Closed e299070747502 ∧ code e299070747502 = 1398582375278 := by decide
theorem cert_e299070747502 : check e299070747502 [[],[.left]] .chain = true := by decide
def e299070747510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e299070747510 : Closed e299070747510 ∧ code e299070747510 = 1398582375286 := by decide
theorem cert_e299070747510 : check e299070747510 [[],[.left]] .chain = true := by decide
def e299070747566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e299070747566 : Closed e299070747566 ∧ code e299070747566 = 1398582375342 := by decide
theorem cert_e299070747566 : check e299070747566 [[],[.left]] .chain = true := by decide
def e299070747578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e299070747578 : Closed e299070747578 ∧ code e299070747578 = 1398582375354 := by decide
theorem cert_e299070747578 : check e299070747578 [[],[.left]] .chain = true := by decide
def e299070747606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e299070747606 : Closed e299070747606 ∧ code e299070747606 = 1398582375382 := by decide
theorem cert_e299070747606 : check e299070747606 [[],[.left]] .chain = true := by decide
def e299070747610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e299070747610 : Closed e299070747610 ∧ code e299070747610 = 1398582375386 := by decide
theorem cert_e299070747610 : check e299070747610 [[],[.left]] .chain = true := by decide
def e299070747886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e299070747886 : Closed e299070747886 ∧ code e299070747886 = 1398582375662 := by decide
theorem cert_e299070747886 : check e299070747886 [[],[.left]] .chain = true := by decide
def e299070747894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e299070747894 : Closed e299070747894 ∧ code e299070747894 = 1398582375670 := by decide
theorem cert_e299070747894 : check e299070747894 [[],[.left]] .chain = true := by decide
def e299070748270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e299070748270 : Closed e299070748270 ∧ code e299070748270 = 1398582376046 := by decide
theorem cert_e299070748270 : check e299070748270 [[],[.left]] .chain = true := by decide
def e299070748282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e299070748282 : Closed e299070748282 ∧ code e299070748282 = 1398582376058 := by decide
theorem cert_e299070748282 : check e299070748282 [[],[.left]] .chain = true := by decide
end Blc.Floor40
