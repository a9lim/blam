import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302800941510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e302800941510 : Closed e302800941510 ∧ code e302800941510 = 1402312569286 := by decide
theorem cert_e302800941510 : check e302800941510 [[],[]] .chain = true := by decide
def e302800941846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e302800941846 : Closed e302800941846 ∧ code e302800941846 = 1402312569622 := by decide
theorem cert_e302800941846 : check e302800941846 [[],[]] .chain = true := by decide
def e302800941850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302800941850 : Closed e302800941850 ∧ code e302800941850 = 1402312569626 := by decide
theorem cert_e302800941850 : check e302800941850 [[],[]] .chain = true := by decide
def e302800941894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302800941894 : Closed e302800941894 ∧ code e302800941894 = 1402312569670 := by decide
theorem cert_e302800941894 : check e302800941894 [[],[]] .chain = true := by decide
def e302800941922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e302800941922 : Closed e302800941922 ∧ code e302800941922 = 1402312569698 := by decide
theorem cert_e302800941922 : check e302800941922 [[],[]] .chain = true := by decide
def e302800941934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e302800941934 : Closed e302800941934 ∧ code e302800941934 = 1402312569710 := by decide
theorem cert_e302800941934 : check e302800941934 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e302800941942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e302800941942 : Closed e302800941942 ∧ code e302800941942 = 1402312569718 := by decide
theorem cert_e302800941942 : check e302800941942 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302800941962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e302800941962 : Closed e302800941962 ∧ code e302800941962 = 1402312569738 := by decide
theorem cert_e302800941962 : check e302800941962 [[],[]] .chain = true := by decide
def e302800941986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e302800941986 : Closed e302800941986 ∧ code e302800941986 = 1402312569762 := by decide
theorem cert_e302800941986 : check e302800941986 [[],[]] .chain = true := by decide
def e302800941998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e302800941998 : Closed e302800941998 ∧ code e302800941998 = 1402312569774 := by decide
theorem cert_e302800941998 : check e302800941998 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e302800942010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e302800942010 : Closed e302800942010 ∧ code e302800942010 = 1402312569786 := by decide
theorem cert_e302800942010 : check e302800942010 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302800942038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e302800942038 : Closed e302800942038 ∧ code e302800942038 = 1402312569814 := by decide
theorem cert_e302800942038 : check e302800942038 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302800942042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e302800942042 : Closed e302800942042 ∧ code e302800942042 = 1402312569818 := by decide
theorem cert_e302800942042 : check e302800942042 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302800942110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e302800942110 : Closed e302800942110 ∧ code e302800942110 = 1402312569886 := by decide
theorem cert_e302800942110 : check e302800942110 [[],[]] .chain = true := by decide
def e302800942134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e302800942134 : Closed e302800942134 ∧ code e302800942134 = 1402312569910 := by decide
theorem cert_e302800942134 : check e302800942134 [[],[]] .chain = true := by decide
def e302800942138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e302800942138 : Closed e302800942138 ∧ code e302800942138 = 1402312569914 := by decide
theorem cert_e302800942138 : check e302800942138 [[],[]] .chain = true := by decide
def e302800942278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302800942278 : Closed e302800942278 ∧ code e302800942278 = 1402312570054 := by decide
theorem cert_e302800942278 : check e302800942278 [[],[]] .chain = true := by decide
def e302800942306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e302800942306 : Closed e302800942306 ∧ code e302800942306 = 1402312570082 := by decide
theorem cert_e302800942306 : check e302800942306 [[],[]] .chain = true := by decide
def e302800942318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e302800942318 : Closed e302800942318 ∧ code e302800942318 = 1402312570094 := by decide
theorem cert_e302800942318 : check e302800942318 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e302800942326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e302800942326 : Closed e302800942326 ∧ code e302800942326 = 1402312570102 := by decide
theorem cert_e302800942326 : check e302800942326 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e302800942606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e302800942606 : Closed e302800942606 ∧ code e302800942606 = 1402312570382 := by decide
theorem cert_e302800942606 : check e302800942606 [[],[]] .chain = true := by decide
def e302800942690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e302800942690 : Closed e302800942690 ∧ code e302800942690 = 1402312570466 := by decide
theorem cert_e302800942690 : check e302800942690 [[],[]] .chain = true := by decide
def e302800942702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e302800942702 : Closed e302800942702 ∧ code e302800942702 = 1402312570478 := by decide
theorem cert_e302800942702 : check e302800942702 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e302800942714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e302800942714 : Closed e302800942714 ∧ code e302800942714 = 1402312570490 := by decide
theorem cert_e302800942714 : check e302800942714 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e302800942902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e302800942902 : Closed e302800942902 ∧ code e302800942902 = 1402312570678 := by decide
theorem cert_e302800942902 : check e302800942902 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302800942906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e302800942906 : Closed e302800942906 ∧ code e302800942906 = 1402312570682 := by decide
theorem cert_e302800942906 : check e302800942906 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302800943542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e302800943542 : Closed e302800943542 ∧ code e302800943542 = 1402312571318 := by decide
private def t_e302800943542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem cert_e302800943542 : ¬ IsSelfInterpreter e302800943542 :=
  wSource (t := t_e302800943542) (replay_sound (ps := []) (t := e302800943542) (by decide)) (by decide)
def e302800943574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e302800943574 : Closed e302800943574 ∧ code e302800943574 = 1402312571350 := by decide
private def t_e302800943574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem cert_e302800943574 : ¬ IsSelfInterpreter e302800943574 :=
  wSource (t := t_e302800943574) (replay_sound (ps := []) (t := e302800943574) (by decide)) (by decide)
def e302800943578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e302800943578 : Closed e302800943578 ∧ code e302800943578 = 1402312571354 := by decide
private def t_e302800943578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem cert_e302800943578 : ¬ IsSelfInterpreter e302800943578 :=
  wSource (t := t_e302800943578) (replay_sound (ps := []) (t := e302800943578) (by decide)) (by decide)
def e302800943734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e302800943734 : Closed e302800943734 ∧ code e302800943734 = 1402312571510 := by decide
private def t_e302800943734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem cert_e302800943734 : ¬ IsSelfInterpreter e302800943734 :=
  wSource (t := t_e302800943734) (replay_sound (ps := []) (t := e302800943734) (by decide)) (by decide)
def e302800943926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e302800943926 : Closed e302800943926 ∧ code e302800943926 = 1402312571702 := by decide
private def t_e302800943926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem cert_e302800943926 : ¬ IsSelfInterpreter e302800943926 :=
  wSource (t := t_e302800943926) (replay_sound (ps := []) (t := e302800943926) (by decide)) (by decide)
def e302800943930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e302800943930 : Closed e302800943930 ∧ code e302800943930 = 1402312571706 := by decide
private def t_e302800943930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem cert_e302800943930 : ¬ IsSelfInterpreter e302800943930 :=
  wSource (t := t_e302800943930) (replay_sound (ps := []) (t := e302800943930) (by decide)) (by decide)
def e302800977134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 1) (.var 2)))))))
theorem wire_e302800977134 : Closed e302800977134 ∧ code e302800977134 = 1402312604910 := by decide
theorem cert_e302800977134 : check e302800977134 [[],[]] .chain = true := by decide
def e302800977142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 1)))))))
theorem wire_e302800977142 : Closed e302800977142 ∧ code e302800977142 = 1402312604918 := by decide
theorem cert_e302800977142 : check e302800977142 [[],[]] .chain = true := by decide
def e302800977526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 1)))))))
theorem wire_e302800977526 : Closed e302800977526 ∧ code e302800977526 = 1402312605302 := by decide
theorem cert_e302800977526 : check e302800977526 [[],[]] .chain = true := by decide
def e302800984814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 2))))))
theorem wire_e302800984814 : Closed e302800984814 ∧ code e302800984814 = 1402312612590 := by decide
theorem cert_e302800984814 : check e302800984814 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302800984822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))) (.var 1))))))
theorem wire_e302800984822 : Closed e302800984822 ∧ code e302800984822 = 1402312612598 := by decide
theorem cert_e302800984822 : check e302800984822 [[],[]] .chain = true := by decide
def e302800984950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))))
theorem wire_e302800984950 : Closed e302800984950 ∧ code e302800984950 = 1402312612726 := by decide
theorem cert_e302800984950 : check e302800984950 [[],[]] .smaller = true := by decide
def e302800984954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))) (.var 0))))))
theorem wire_e302800984954 : Closed e302800984954 ∧ code e302800984954 = 1402312612730 := by decide
theorem cert_e302800984954 : check e302800984954 [[],[]] .chain = true := by decide
def e302800985006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 2))))))
theorem wire_e302800985006 : Closed e302800985006 ∧ code e302800985006 = 1402312612782 := by decide
theorem cert_e302800985006 : checkPay e302800985006 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e302800985014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))))
theorem wire_e302800985014 : Closed e302800985014 ∧ code e302800985014 = 1402312612790 := by decide
theorem cert_e302800985014 : check e302800985014 [[],[]] .smaller = true := by decide
def e302800985046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 0)))) (.var 1))))))
theorem wire_e302800985046 : Closed e302800985046 ∧ code e302800985046 = 1402312612822 := by decide
theorem cert_e302800985046 : check e302800985046 [[],[]] .chain = true := by decide
def e302800985050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))) (.var 0))))))
theorem wire_e302800985050 : Closed e302800985050 ∧ code e302800985050 = 1402312612826 := by decide
theorem cert_e302800985050 : check e302800985050 [[],[]] .chain = true := by decide
def e302800985462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e302800985462 : Closed e302800985462 ∧ code e302800985462 = 1402312613238 := by decide
theorem cert_e302800985462 : check e302800985462 [[],[]] .smaller = true := by decide
def e302800985466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))) (.var 0))))))
theorem wire_e302800985466 : Closed e302800985466 ∧ code e302800985466 = 1402312613242 := by decide
theorem cert_e302800985466 : check e302800985466 [[],[]] .chain = true := by decide
def e302800985558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e302800985558 : Closed e302800985558 ∧ code e302800985558 = 1402312613334 := by decide
theorem cert_e302800985558 : check e302800985558 [[],[]] .smaller = true := by decide
def e302800985578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))) (.var 0))))))
theorem wire_e302800985578 : Closed e302800985578 ∧ code e302800985578 = 1402312613354 := by decide
theorem cert_e302800985578 : check e302800985578 [[],[]] .chain = true := by decide
def e302800985774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e302800985774 : Closed e302800985774 ∧ code e302800985774 = 1402312613550 := by decide
theorem cert_e302800985774 : check e302800985774 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e302800985782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e302800985782 : Closed e302800985782 ∧ code e302800985782 = 1402312613558 := by decide
theorem cert_e302800985782 : check e302800985782 [[],[]] .smaller = true := by decide
def e302800985814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e302800985814 : Closed e302800985814 ∧ code e302800985814 = 1402312613590 := by decide
theorem cert_e302800985814 : check e302800985814 [[],[]] .smaller = true := by decide
def e302800985942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e302800985942 : Closed e302800985942 ∧ code e302800985942 = 1402312613718 := by decide
theorem cert_e302800985942 : check e302800985942 [[],[]] .chain = true := by decide
def e302800985946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e302800985946 : Closed e302800985946 ∧ code e302800985946 = 1402312613722 := by decide
theorem cert_e302800985946 : check e302800985946 [[],[]] .chain = true := by decide
def e302800985962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e302800985962 : Closed e302800985962 ∧ code e302800985962 = 1402312613738 := by decide
theorem cert_e302800985962 : check e302800985962 [[],[]] .chain = true := by decide
def e302800987886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e302800987886 : Closed e302800987886 ∧ code e302800987886 = 1402312615662 := by decide
theorem cert_e302800987886 : check e302800987886 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e302800987894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 3))))) (.var 1))))))
theorem wire_e302800987894 : Closed e302800987894 ∧ code e302800987894 = 1402312615670 := by decide
theorem cert_e302800987894 : check e302800987894 [[],[]] .chain = true := by decide
def e302800988022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))))
theorem wire_e302800988022 : Closed e302800988022 ∧ code e302800988022 = 1402312615798 := by decide
theorem cert_e302800988022 : check e302800988022 [[],[]] .smaller = true := by decide
def e302800988026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))) (.var 0))))))
theorem wire_e302800988026 : Closed e302800988026 ∧ code e302800988026 = 1402312615802 := by decide
theorem cert_e302800988026 : check e302800988026 [[],[]] .chain = true := by decide
def e302800988078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e302800988078 : Closed e302800988078 ∧ code e302800988078 = 1402312615854 := by decide
theorem cert_e302800988078 : checkPay e302800988078 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left]] 0 [] = true := by decide
def e302800988086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))))
theorem wire_e302800988086 : Closed e302800988086 ∧ code e302800988086 = 1402312615862 := by decide
theorem cert_e302800988086 : check e302800988086 [[],[]] .smaller = true := by decide
def e302800988118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 0))))) (.var 1))))))
theorem wire_e302800988118 : Closed e302800988118 ∧ code e302800988118 = 1402312615894 := by decide
theorem cert_e302800988118 : check e302800988118 [[],[]] .chain = true := by decide
def e302800988122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))) (.var 0))))))
theorem wire_e302800988122 : Closed e302800988122 ∧ code e302800988122 = 1402312615898 := by decide
theorem cert_e302800988122 : check e302800988122 [[],[]] .chain = true := by decide
def e302800989422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e302800989422 : Closed e302800989422 ∧ code e302800989422 = 1402312617198 := by decide
theorem cert_e302800989422 : check e302800989422 [[],[]] .chain = true := by decide
def e302800989430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e302800989430 : Closed e302800989430 ∧ code e302800989430 = 1402312617206 := by decide
theorem cert_e302800989430 : check e302800989430 [[],[]] .chain = true := by decide
def e302800989806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e302800989806 : Closed e302800989806 ∧ code e302800989806 = 1402312617582 := by decide
theorem cert_e302800989806 : check e302800989806 [[],[]] .chain = true := by decide
def e302800989818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e302800989818 : Closed e302800989818 ∧ code e302800989818 = 1402312617594 := by decide
theorem cert_e302800989818 : check e302800989818 [[],[]] .chain = true := by decide
def e302800990006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e302800990006 : Closed e302800990006 ∧ code e302800990006 = 1402312617782 := by decide
theorem cert_e302800990006 : check e302800990006 [[],[]] .chain = true := by decide
def e302800990010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e302800990010 : Closed e302800990010 ∧ code e302800990010 = 1402312617786 := by decide
theorem cert_e302800990010 : check e302800990010 [[],[]] .chain = true := by decide
def e302800990702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 2))))))
theorem wire_e302800990702 : Closed e302800990702 ∧ code e302800990702 = 1402312618478 := by decide
theorem cert_e302800990702 : check e302800990702 [[],[]] .chain = true := by decide
def e302800990710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 4))))) (.var 1))))))
theorem wire_e302800990710 : Closed e302800990710 ∧ code e302800990710 = 1402312618486 := by decide
theorem cert_e302800990710 : check e302800990710 [[],[]] .chain = true := by decide
def e302800991094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e302800991094 : Closed e302800991094 ∧ code e302800991094 = 1402312618870 := by decide
theorem cert_e302800991094 : check e302800991094 [[],[]] .smaller = true := by decide
def e302800991098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e302800991098 : Closed e302800991098 ∧ code e302800991098 = 1402312618874 := by decide
theorem cert_e302800991098 : check e302800991098 [[],[]] .chain = true := by decide
def e302800991190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e302800991190 : Closed e302800991190 ∧ code e302800991190 = 1402312618966 := by decide
theorem cert_e302800991190 : check e302800991190 [[],[]] .smaller = true := by decide
def e302800991210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e302800991210 : Closed e302800991210 ∧ code e302800991210 = 1402312618986 := by decide
theorem cert_e302800991210 : check e302800991210 [[],[]] .chain = true := by decide
def e302800991470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e302800991470 : Closed e302800991470 ∧ code e302800991470 = 1402312619246 := by decide
theorem cert_e302800991470 : check e302800991470 [[],[]] .chain = true := by decide
def e302800991478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e302800991478 : Closed e302800991478 ∧ code e302800991478 = 1402312619254 := by decide
theorem cert_e302800991478 : check e302800991478 [[],[]] .chain = true := by decide
def e302800992030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 3)))))))
theorem wire_e302800992030 : Closed e302800992030 ∧ code e302800992030 = 1402312619806 := by decide
theorem cert_e302800992030 : check e302800992030 [[],[]] .chain = true := by decide
def e302800992142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 2)))))))
theorem wire_e302800992142 : Closed e302800992142 ∧ code e302800992142 = 1402312619918 := by decide
theorem cert_e302800992142 : check e302800992142 [[],[]] .chain = true := by decide
def e302800992494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 2))))) (.var 2))))))
theorem wire_e302800992494 : Closed e302800992494 ∧ code e302800992494 = 1402312620270 := by decide
theorem cert_e302800992494 : check e302800992494 [[],[]] .chain = true := by decide
def e302800992506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))) (.var 0))))))
theorem wire_e302800992506 : Closed e302800992506 ∧ code e302800992506 = 1402312620282 := by decide
theorem cert_e302800992506 : check e302800992506 [[],[]] .chain = true := by decide
def e302800992686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e302800992686 : Closed e302800992686 ∧ code e302800992686 = 1402312620462 := by decide
theorem cert_e302800992686 : check e302800992686 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e302800992694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e302800992694 : Closed e302800992694 ∧ code e302800992694 = 1402312620470 := by decide
theorem cert_e302800992694 : check e302800992694 [[],[]] .smaller = true := by decide
def e302800992726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e302800992726 : Closed e302800992726 ∧ code e302800992726 = 1402312620502 := by decide
theorem cert_e302800992726 : check e302800992726 [[],[]] .smaller = true := by decide
def e302800992878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e302800992878 : Closed e302800992878 ∧ code e302800992878 = 1402312620654 := by decide
theorem cert_e302800992878 : check e302800992878 [[],[]] .chain = true := by decide
def e302800992890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e302800992890 : Closed e302800992890 ∧ code e302800992890 = 1402312620666 := by decide
theorem cert_e302800992890 : check e302800992890 [[],[]] .chain = true := by decide
def e302800993054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e302800993054 : Closed e302800993054 ∧ code e302800993054 = 1402312620830 := by decide
theorem cert_e302800993054 : check e302800993054 [[],[]] .chain = true := by decide
def e302800993222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.lam (.var 1)))))))
theorem wire_e302800993222 : Closed e302800993222 ∧ code e302800993222 = 1402312620998 := by decide
theorem cert_e302800993222 : check e302800993222 [[],[]] .chain = true := by decide
def e302800993398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 2))))) (.var 1))))))
theorem wire_e302800993398 : Closed e302800993398 ∧ code e302800993398 = 1402312621174 := by decide
theorem cert_e302800993398 : check e302800993398 [[],[]] .chain = true := by decide
def e302800993402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))) (.var 0))))))
theorem wire_e302800993402 : Closed e302800993402 ∧ code e302800993402 = 1402312621178 := by decide
theorem cert_e302800993402 : check e302800993402 [[],[]] .chain = true := by decide
def e302800993494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e302800993494 : Closed e302800993494 ∧ code e302800993494 = 1402312621270 := by decide
theorem cert_e302800993494 : check e302800993494 [[],[]] .chain = true := by decide
def e302800993498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e302800993498 : Closed e302800993498 ∧ code e302800993498 = 1402312621274 := by decide
theorem cert_e302800993498 : check e302800993498 [[],[]] .chain = true := by decide
def e302800993514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e302800993514 : Closed e302800993514 ∧ code e302800993514 = 1402312621290 := by decide
theorem cert_e302800993514 : check e302800993514 [[],[]] .chain = true := by decide
def e302800993590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e302800993590 : Closed e302800993590 ∧ code e302800993590 = 1402312621366 := by decide
theorem cert_e302800993590 : check e302800993590 [[],[]] .chain = true := by decide
def e302800993594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e302800993594 : Closed e302800993594 ∧ code e302800993594 = 1402312621370 := by decide
theorem cert_e302800993594 : check e302800993594 [[],[]] .chain = true := by decide
def e302800993678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e302800993678 : Closed e302800993678 ∧ code e302800993678 = 1402312621454 := by decide
theorem cert_e302800993678 : check e302800993678 [[],[]] .chain = true := by decide
def e302800993734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e302800993734 : Closed e302800993734 ∧ code e302800993734 = 1402312621510 := by decide
theorem cert_e302800993734 : check e302800993734 [[],[]] .chain = true := by decide
def e302801000302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e302801000302 : Closed e302801000302 ∧ code e302801000302 = 1402312628078 := by decide
theorem cert_e302801000302 : check e302801000302 [[],[]] .chain = true := by decide
def e302801000310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e302801000310 : Closed e302801000310 ∧ code e302801000310 = 1402312628086 := by decide
theorem cert_e302801000310 : check e302801000310 [[],[]] .chain = true := by decide
def e302801000374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e302801000374 : Closed e302801000374 ∧ code e302801000374 = 1402312628150 := by decide
theorem cert_e302801000374 : check e302801000374 [[],[]] .chain = true := by decide
def e302801001710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e302801001710 : Closed e302801001710 ∧ code e302801001710 = 1402312629486 := by decide
theorem cert_e302801001710 : check e302801001710 [[],[]] .chain = true := by decide
def e302801001718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e302801001718 : Closed e302801001718 ∧ code e302801001718 = 1402312629494 := by decide
theorem cert_e302801001718 : check e302801001718 [[],[]] .chain = true := by decide
def e302801002102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e302801002102 : Closed e302801002102 ∧ code e302801002102 = 1402312629878 := by decide
theorem cert_e302801002102 : check e302801002102 [[],[]] .chain = true := by decide
def e302801011678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e302801011678 : Closed e302801011678 ∧ code e302801011678 = 1402312639454 := by decide
theorem cert_e302801011678 : check e302801011678 [[],[]] .chain = true := by decide
def e302801011694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e302801011694 : Closed e302801011694 ∧ code e302801011694 = 1402312639470 := by decide
theorem cert_e302801011694 : check e302801011694 [[],[]] .chain = true := by decide
def e302801013614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e302801013614 : Closed e302801013614 ∧ code e302801013614 = 1402312641390 := by decide
theorem cert_e302801013614 : check e302801013614 [[],[]] .chain = true := by decide
def e302801013622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e302801013622 : Closed e302801013622 ∧ code e302801013622 = 1402312641398 := by decide
theorem cert_e302801013622 : check e302801013622 [[],[]] .chain = true := by decide
def e302801013678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e302801013678 : Closed e302801013678 ∧ code e302801013678 = 1402312641454 := by decide
theorem cert_e302801013678 : check e302801013678 [[],[]] .chain = true := by decide
def e302801013690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e302801013690 : Closed e302801013690 ∧ code e302801013690 = 1402312641466 := by decide
theorem cert_e302801013690 : check e302801013690 [[],[]] .chain = true := by decide
def e302801013718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e302801013718 : Closed e302801013718 ∧ code e302801013718 = 1402312641494 := by decide
theorem cert_e302801013718 : check e302801013718 [[],[]] .chain = true := by decide
def e302801013722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e302801013722 : Closed e302801013722 ∧ code e302801013722 = 1402312641498 := by decide
theorem cert_e302801013722 : check e302801013722 [[],[]] .chain = true := by decide
def e302801013998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e302801013998 : Closed e302801013998 ∧ code e302801013998 = 1402312641774 := by decide
theorem cert_e302801013998 : check e302801013998 [[],[]] .chain = true := by decide
def e302801014006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e302801014006 : Closed e302801014006 ∧ code e302801014006 = 1402312641782 := by decide
theorem cert_e302801014006 : check e302801014006 [[],[]] .chain = true := by decide
def e302801014382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e302801014382 : Closed e302801014382 ∧ code e302801014382 = 1402312642158 := by decide
theorem cert_e302801014382 : check e302801014382 [[],[]] .chain = true := by decide
def e302801014394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e302801014394 : Closed e302801014394 ∧ code e302801014394 = 1402312642170 := by decide
theorem cert_e302801014394 : check e302801014394 [[],[]] .chain = true := by decide
def e302801014582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e302801014582 : Closed e302801014582 ∧ code e302801014582 = 1402312642358 := by decide
theorem cert_e302801014582 : check e302801014582 [[],[]] .chain = true := by decide
def e302801014586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e302801014586 : Closed e302801014586 ∧ code e302801014586 = 1402312642362 := by decide
theorem cert_e302801014586 : check e302801014586 [[],[]] .chain = true := by decide
def e302801019358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e302801019358 : Closed e302801019358 ∧ code e302801019358 = 1402312647134 := by decide
theorem cert_e302801019358 : check e302801019358 [[],[]] .chain = true := by decide
def e302801019382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e302801019382 : Closed e302801019382 ∧ code e302801019382 = 1402312647158 := by decide
theorem cert_e302801019382 : check e302801019382 [[],[]] .chain = true := by decide
def e302801020334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e302801020334 : Closed e302801020334 ∧ code e302801020334 = 1402312648110 := by decide
theorem cert_e302801020334 : check e302801020334 [[],[]] .chain = true := by decide
def e302801020346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e302801020346 : Closed e302801020346 ∧ code e302801020346 = 1402312648122 := by decide
theorem cert_e302801020346 : check e302801020346 [[],[]] .chain = true := by decide
def e302801020394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e302801020394 : Closed e302801020394 ∧ code e302801020394 = 1402312648170 := by decide
theorem cert_e302801020394 : check e302801020394 [[],[]] .chain = true := by decide
def e302801020526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e302801020526 : Closed e302801020526 ∧ code e302801020526 = 1402312648302 := by decide
theorem cert_e302801020526 : check e302801020526 [[],[]] .chain = true := by decide
def e302801020538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e302801020538 : Closed e302801020538 ∧ code e302801020538 = 1402312648314 := by decide
theorem cert_e302801020538 : check e302801020538 [[],[]] .chain = true := by decide
def e302801020702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e302801020702 : Closed e302801020702 ∧ code e302801020702 = 1402312648478 := by decide
theorem cert_e302801020702 : check e302801020702 [[],[]] .chain = true := by decide
def e302801020814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e302801020814 : Closed e302801020814 ∧ code e302801020814 = 1402312648590 := by decide
theorem cert_e302801020814 : check e302801020814 [[],[]] .chain = true := by decide
def e302801020826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e302801020826 : Closed e302801020826 ∧ code e302801020826 = 1402312648602 := by decide
theorem cert_e302801020826 : check e302801020826 [[],[]] .chain = true := by decide
def e302801023214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e302801023214 : Closed e302801023214 ∧ code e302801023214 = 1402312650990 := by decide
theorem cert_e302801023214 : check e302801023214 [[],[]] .chain = true := by decide
def e302801023222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e302801023222 : Closed e302801023222 ∧ code e302801023222 = 1402312650998 := by decide
theorem cert_e302801023222 : check e302801023222 [[],[]] .chain = true := by decide
def e302801023702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e302801023702 : Closed e302801023702 ∧ code e302801023702 = 1402312651478 := by decide
theorem cert_e302801023702 : check e302801023702 [[],[]] .chain = true := by decide
def e302801023706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e302801023706 : Closed e302801023706 ∧ code e302801023706 = 1402312651482 := by decide
theorem cert_e302801023706 : check e302801023706 [[],[]] .chain = true := by decide
def e302801023722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e302801023722 : Closed e302801023722 ∧ code e302801023722 = 1402312651498 := by decide
theorem cert_e302801023722 : check e302801023722 [[],[]] .chain = true := by decide
def e302801023798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e302801023798 : Closed e302801023798 ∧ code e302801023798 = 1402312651574 := by decide
theorem cert_e302801023798 : check e302801023798 [[],[]] .chain = true := by decide
def e302801023802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e302801023802 : Closed e302801023802 ∧ code e302801023802 = 1402312651578 := by decide
theorem cert_e302801023802 : check e302801023802 [[],[]] .chain = true := by decide
def e302801023886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e302801023886 : Closed e302801023886 ∧ code e302801023886 = 1402312651662 := by decide
theorem cert_e302801023886 : check e302801023886 [[],[]] .chain = true := by decide
def e302801023898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e302801023898 : Closed e302801023898 ∧ code e302801023898 = 1402312651674 := by decide
theorem cert_e302801023898 : check e302801023898 [[],[]] .chain = true := by decide
def e302801052526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.var 2))))))
theorem wire_e302801052526 : Closed e302801052526 ∧ code e302801052526 = 1402312680302 := by decide
theorem cert_e302801052526 : check e302801052526 [[],[]] .chain = true := by decide
def e302801052534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.var 1))))))
theorem wire_e302801052534 : Closed e302801052534 ∧ code e302801052534 = 1402312680310 := by decide
theorem cert_e302801052534 : check e302801052534 [[],[]] .chain = true := by decide
def e302801052590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.var 2))))))
theorem wire_e302801052590 : Closed e302801052590 ∧ code e302801052590 = 1402312680366 := by decide
theorem cert_e302801052590 : check e302801052590 [[],[]] .chain = true := by decide
def e302801052602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))) (.var 0))))))
theorem wire_e302801052602 : Closed e302801052602 ∧ code e302801052602 = 1402312680378 := by decide
theorem cert_e302801052602 : check e302801052602 [[],[]] .chain = true := by decide
def e302801052630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))) (.var 1))))))
theorem wire_e302801052630 : Closed e302801052630 ∧ code e302801052630 = 1402312680406 := by decide
theorem cert_e302801052630 : check e302801052630 [[],[]] .chain = true := by decide
def e302801052634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))) (.var 0))))))
theorem wire_e302801052634 : Closed e302801052634 ∧ code e302801052634 = 1402312680410 := by decide
theorem cert_e302801052634 : check e302801052634 [[],[]] .chain = true := by decide
def e302801053934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.var 2))))))
theorem wire_e302801053934 : Closed e302801053934 ∧ code e302801053934 = 1402312681710 := by decide
theorem cert_e302801053934 : check e302801053934 [[],[]] .chain = true := by decide
def e302801053942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))) (.var 1))))))
theorem wire_e302801053942 : Closed e302801053942 ∧ code e302801053942 = 1402312681718 := by decide
theorem cert_e302801053942 : check e302801053942 [[],[]] .chain = true := by decide
def e302801054494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 3)))))))
theorem wire_e302801054494 : Closed e302801054494 ∧ code e302801054494 = 1402312682270 := by decide
theorem cert_e302801054494 : check e302801054494 [[],[]] .chain = true := by decide
def e302801054606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 2)))))))
theorem wire_e302801054606 : Closed e302801054606 ∧ code e302801054606 = 1402312682382 := by decide
theorem cert_e302801054606 : check e302801054606 [[],[]] .chain = true := by decide
def e302801054830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e302801054830 : Closed e302801054830 ∧ code e302801054830 = 1402312682606 := by decide
theorem cert_e302801054830 : check e302801054830 [[],[]] .chain = true := by decide
def e302801054842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e302801054842 : Closed e302801054842 ∧ code e302801054842 = 1402312682618 := by decide
theorem cert_e302801054842 : check e302801054842 [[],[]] .chain = true := by decide
def e302801055006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e302801055006 : Closed e302801055006 ∧ code e302801055006 = 1402312682782 := by decide
theorem cert_e302801055006 : check e302801055006 [[],[]] .chain = true := by decide
def e302801055174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e302801055174 : Closed e302801055174 ∧ code e302801055174 = 1402312682950 := by decide
theorem cert_e302801055174 : check e302801055174 [[],[]] .chain = true := by decide
def e302801055286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e302801055286 : Closed e302801055286 ∧ code e302801055286 = 1402312683062 := by decide
theorem cert_e302801055286 : check e302801055286 [[],[]] .chain = true := by decide
def e302801055290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e302801055290 : Closed e302801055290 ∧ code e302801055290 = 1402312683066 := by decide
theorem cert_e302801055290 : check e302801055290 [[],[]] .chain = true := by decide
def e302801055374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e302801055374 : Closed e302801055374 ∧ code e302801055374 = 1402312683150 := by decide
theorem cert_e302801055374 : check e302801055374 [[],[]] .chain = true := by decide
def e302801055430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e302801055430 : Closed e302801055430 ∧ code e302801055430 = 1402312683206 := by decide
theorem cert_e302801055430 : check e302801055430 [[],[]] .chain = true := by decide
def e302801056110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e302801056110 : Closed e302801056110 ∧ code e302801056110 = 1402312683886 := by decide
theorem cert_e302801056110 : check e302801056110 [[],[]] .chain = true := by decide
def e302801056118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e302801056118 : Closed e302801056118 ∧ code e302801056118 = 1402312683894 := by decide
theorem cert_e302801056118 : check e302801056118 [[],[]] .chain = true := by decide
def e302801056174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e302801056174 : Closed e302801056174 ∧ code e302801056174 = 1402312683950 := by decide
theorem cert_e302801056174 : check e302801056174 [[],[]] .chain = true := by decide
def e302801056186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e302801056186 : Closed e302801056186 ∧ code e302801056186 = 1402312683962 := by decide
theorem cert_e302801056186 : check e302801056186 [[],[]] .chain = true := by decide
def e302801056234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))) (.var 0))))))
theorem wire_e302801056234 : Closed e302801056234 ∧ code e302801056234 = 1402312684010 := by decide
theorem cert_e302801056234 : check e302801056234 [[],[]] .chain = true := by decide
def e302801056878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e302801056878 : Closed e302801056878 ∧ code e302801056878 = 1402312684654 := by decide
theorem cert_e302801056878 : check e302801056878 [[],[]] .chain = true := by decide
def e302801056890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e302801056890 : Closed e302801056890 ∧ code e302801056890 = 1402312684666 := by decide
theorem cert_e302801056890 : check e302801056890 [[],[]] .chain = true := by decide
def e302801057054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e302801057054 : Closed e302801057054 ∧ code e302801057054 = 1402312684830 := by decide
theorem cert_e302801057054 : check e302801057054 [[],[]] .chain = true := by decide
end Blc.Floor40
