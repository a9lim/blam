import CodeBridge
import R302824804154Blk0
import R302824804154Blk6
namespace Certgen.R302824804154
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit80 : Term := .var 0
def lit52 : Term := .var 1
def lit18 : Term := .var 2
def lit44 : Term := .lam lit80
def lit51 : Term := .lam lit52
def lit78 : Term := .app lit80 lit80
def lit43 : Term := .lam lit44
def lit53 : Term := .var 4
def lit19 : Term := .app lit52 lit80
def lit50 : Term := .lam lit51
def lit77 : Term := .lam lit78
def lit41 : Term := .app lit80 lit43
def lit48 : Term := .app lit80 lit50
def lit17 : Term := .app lit18 lit19
def lit72 : Term := .app lit77 lit77
def lit15 : Term := .app lit18 lit17
def lit47 : Term := .app lit48 lit53
def lit14 : Term := .lam lit15
def lit46 : Term := .lam lit47
def lit12 : Term := .app lit52 lit14
def lit11 : Term := .lam lit12
def lit10 : Term := .lam lit11
def lit40 : Term := .app lit41 lit46
def lit39 : Term := .lam lit40
def lit5 : Term := .app lit77 lit10
def lit4 : Term := .app lit5 lit43
def lit33 : Term := .app lit48 lit39
def lit32 : Term := .lam lit33
def lit26 : Term := .app lit48 lit32
def lit25 : Term := .lam lit26
def lit3 : Term := .app lit4 lit25
def lit2 : Term := .app lit3 lit72
def lit1 : Term := .app lit2 lit72
def lit0 : Term := .app lit1 lit72
def filling : Nat → Term := fun p => if p = 53 then Term.var 4 else Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub80 : model.term 80 = lit80 := model.var_eq 80 0 (by rfl)
theorem sub79 : model.term 79 = lit80 := model.var_eq 79 0 (by rfl)
theorem sub78 : model.term 78 = lit78 := by rw [model.app_eq 78 79 80 (by rfl), sub79, sub80]; rfl
theorem sub77 : model.term 77 = lit77 := by rw [model.lam_eq 77 78 (by rfl), sub78]; rfl
theorem sub76 : model.term 76 = lit80 := model.var_eq 76 0 (by rfl)
theorem sub75 : model.term 75 = lit80 := model.var_eq 75 0 (by rfl)
theorem sub74 : model.term 74 = lit78 := by rw [model.app_eq 74 75 76 (by rfl), sub75, sub76]; rfl
theorem sub73 : model.term 73 = lit77 := by rw [model.lam_eq 73 74 (by rfl), sub74]; rfl
theorem sub72 : model.term 72 = lit72 := by rw [model.app_eq 72 73 77 (by rfl), sub73, sub77]; rfl
theorem sub71 : model.term 71 = lit80 := model.var_eq 71 0 (by rfl)
theorem sub70 : model.term 70 = lit80 := model.var_eq 70 0 (by rfl)
theorem sub69 : model.term 69 = lit78 := by rw [model.app_eq 69 70 71 (by rfl), sub70, sub71]; rfl
theorem sub68 : model.term 68 = lit77 := by rw [model.lam_eq 68 69 (by rfl), sub69]; rfl
theorem sub67 : model.term 67 = lit80 := model.var_eq 67 0 (by rfl)
theorem sub66 : model.term 66 = lit80 := model.var_eq 66 0 (by rfl)
theorem sub65 : model.term 65 = lit78 := by rw [model.app_eq 65 66 67 (by rfl), sub66, sub67]; rfl
theorem sub64 : model.term 64 = lit77 := by rw [model.lam_eq 64 65 (by rfl), sub65]; rfl
theorem sub63 : model.term 63 = lit72 := by rw [model.app_eq 63 64 68 (by rfl), sub64, sub68]; rfl
theorem sub62 : model.term 62 = lit80 := model.var_eq 62 0 (by rfl)
theorem sub61 : model.term 61 = lit80 := model.var_eq 61 0 (by rfl)
theorem sub60 : model.term 60 = lit78 := by rw [model.app_eq 60 61 62 (by rfl), sub61, sub62]; rfl
theorem sub59 : model.term 59 = lit77 := by rw [model.lam_eq 59 60 (by rfl), sub60]; rfl
theorem sub58 : model.term 58 = lit80 := model.var_eq 58 0 (by rfl)
theorem sub57 : model.term 57 = lit80 := model.var_eq 57 0 (by rfl)
theorem sub56 : model.term 56 = lit78 := by rw [model.app_eq 56 57 58 (by rfl), sub57, sub58]; rfl
theorem sub55 : model.term 55 = lit77 := by rw [model.lam_eq 55 56 (by rfl), sub56]; rfl
theorem sub54 : model.term 54 = lit72 := by rw [model.app_eq 54 55 59 (by rfl), sub55, sub59]; rfl
theorem sub53 : model.term 53 = lit53 := (opaqueTerm (rankedCode code ordered_code) filling (p := 53) (by rfl)).trans (by rfl)
theorem sub52 : model.term 52 = lit52 := model.var_eq 52 1 (by rfl)
theorem sub51 : model.term 51 = lit51 := by rw [model.lam_eq 51 52 (by rfl), sub52]; rfl
theorem sub50 : model.term 50 = lit50 := by rw [model.lam_eq 50 51 (by rfl), sub51]; rfl
theorem sub49 : model.term 49 = lit80 := model.var_eq 49 0 (by rfl)
theorem sub48 : model.term 48 = lit48 := by rw [model.app_eq 48 49 50 (by rfl), sub49, sub50]; rfl
theorem sub47 : model.term 47 = lit47 := by rw [model.app_eq 47 48 53 (by rfl), sub48, sub53]; rfl
theorem sub46 : model.term 46 = lit46 := by rw [model.lam_eq 46 47 (by rfl), sub47]; rfl
theorem sub45 : model.term 45 = lit80 := model.var_eq 45 0 (by rfl)
theorem sub44 : model.term 44 = lit44 := by rw [model.lam_eq 44 45 (by rfl), sub45]; rfl
theorem sub43 : model.term 43 = lit43 := by rw [model.lam_eq 43 44 (by rfl), sub44]; rfl
theorem sub42 : model.term 42 = lit80 := model.var_eq 42 0 (by rfl)
theorem sub41 : model.term 41 = lit41 := by rw [model.app_eq 41 42 43 (by rfl), sub42, sub43]; rfl
theorem sub40 : model.term 40 = lit40 := by rw [model.app_eq 40 41 46 (by rfl), sub41, sub46]; rfl
theorem sub39 : model.term 39 = lit39 := by rw [model.lam_eq 39 40 (by rfl), sub40]; rfl
theorem sub38 : model.term 38 = lit52 := model.var_eq 38 1 (by rfl)
theorem sub37 : model.term 37 = lit51 := by rw [model.lam_eq 37 38 (by rfl), sub38]; rfl
theorem sub36 : model.term 36 = lit50 := by rw [model.lam_eq 36 37 (by rfl), sub37]; rfl
theorem sub35 : model.term 35 = lit80 := model.var_eq 35 0 (by rfl)
theorem sub34 : model.term 34 = lit48 := by rw [model.app_eq 34 35 36 (by rfl), sub35, sub36]; rfl
theorem sub33 : model.term 33 = lit33 := by rw [model.app_eq 33 34 39 (by rfl), sub34, sub39]; rfl
theorem sub32 : model.term 32 = lit32 := by rw [model.lam_eq 32 33 (by rfl), sub33]; rfl
theorem sub31 : model.term 31 = lit52 := model.var_eq 31 1 (by rfl)
theorem sub30 : model.term 30 = lit51 := by rw [model.lam_eq 30 31 (by rfl), sub31]; rfl
theorem sub29 : model.term 29 = lit50 := by rw [model.lam_eq 29 30 (by rfl), sub30]; rfl
theorem sub28 : model.term 28 = lit80 := model.var_eq 28 0 (by rfl)
theorem sub27 : model.term 27 = lit48 := by rw [model.app_eq 27 28 29 (by rfl), sub28, sub29]; rfl
theorem sub26 : model.term 26 = lit26 := by rw [model.app_eq 26 27 32 (by rfl), sub27, sub32]; rfl
theorem sub25 : model.term 25 = lit25 := by rw [model.lam_eq 25 26 (by rfl), sub26]; rfl
theorem sub24 : model.term 24 = lit80 := model.var_eq 24 0 (by rfl)
theorem sub23 : model.term 23 = lit44 := by rw [model.lam_eq 23 24 (by rfl), sub24]; rfl
theorem sub22 : model.term 22 = lit43 := by rw [model.lam_eq 22 23 (by rfl), sub23]; rfl
theorem sub21 : model.term 21 = lit80 := model.var_eq 21 0 (by rfl)
theorem sub20 : model.term 20 = lit52 := model.var_eq 20 1 (by rfl)
theorem sub19 : model.term 19 = lit19 := by rw [model.app_eq 19 20 21 (by rfl), sub20, sub21]; rfl
theorem sub18 : model.term 18 = lit18 := model.var_eq 18 2 (by rfl)
theorem sub17 : model.term 17 = lit17 := by rw [model.app_eq 17 18 19 (by rfl), sub18, sub19]; rfl
theorem sub16 : model.term 16 = lit18 := model.var_eq 16 2 (by rfl)
theorem sub15 : model.term 15 = lit15 := by rw [model.app_eq 15 16 17 (by rfl), sub16, sub17]; rfl
theorem sub14 : model.term 14 = lit14 := by rw [model.lam_eq 14 15 (by rfl), sub15]; rfl
theorem sub13 : model.term 13 = lit52 := model.var_eq 13 1 (by rfl)
theorem sub12 : model.term 12 = lit12 := by rw [model.app_eq 12 13 14 (by rfl), sub13, sub14]; rfl
theorem sub11 : model.term 11 = lit11 := by rw [model.lam_eq 11 12 (by rfl), sub12]; rfl
theorem sub10 : model.term 10 = lit10 := by rw [model.lam_eq 10 11 (by rfl), sub11]; rfl
theorem sub9 : model.term 9 = lit80 := model.var_eq 9 0 (by rfl)
theorem sub8 : model.term 8 = lit80 := model.var_eq 8 0 (by rfl)
theorem sub7 : model.term 7 = lit78 := by rw [model.app_eq 7 8 9 (by rfl), sub8, sub9]; rfl
theorem sub6 : model.term 6 = lit77 := by rw [model.lam_eq 6 7 (by rfl), sub7]; rfl
theorem sub5 : model.term 5 = lit5 := by rw [model.app_eq 5 6 10 (by rfl), sub6, sub10]; rfl
theorem sub4 : model.term 4 = lit4 := by rw [model.app_eq 4 5 22 (by rfl), sub5, sub22]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 25 (by rfl), sub4, sub25]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 54 (by rfl), sub3, sub54]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 63 (by rfl), sub2, sub63]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 72 (by rfl), sub1, sub72]; rfl
theorem allValid (i : Nat) (h : i < 141) : validState i = true := by
 by_cases h72 : i < 72
 · by_cases h36 : i < 36
   · by_cases h12 : i < 12
     · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
     · by_cases h24 : i < 24
       · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
   · by_cases h48 : i < 48
     · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
     · by_cases h60 : i < 60
       · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
 · by_cases h108 : i < 108
   · by_cases h84 : i < 84
     · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
     · by_cases h96 : i < 96
       · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
   · by_cases h120 : i < 120
     · exact FloorIndex.rangeOK_at bl108 (by omega) (by omega)
     · by_cases h132 : i < 132
       · exact FloorIndex.rangeOK_at bl120 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl132 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 141
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e302824804154 := by
 intro he
 have hp : replay [] (call e302824804154 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R302824804154
