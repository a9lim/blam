import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302796741754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302796741754 : Closed e302796741754 ∧ code e302796741754 = 1402308369530 := by decide
theorem cert_e302796741754 : check e302796741754 [[],[]] .smaller = true := by decide
def e302796741846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e302796741846 : Closed e302796741846 ∧ code e302796741846 = 1402308369622 := by decide
theorem cert_e302796741846 : check e302796741846 [[],[]] .smaller = true := by decide
def e302796741850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e302796741850 : Closed e302796741850 ∧ code e302796741850 = 1402308369626 := by decide
theorem cert_e302796741850 : check e302796741850 [[],[]] .smaller = true := by decide
def e302796741866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e302796741866 : Closed e302796741866 ∧ code e302796741866 = 1402308369642 := by decide
theorem cert_e302796741866 : check e302796741866 [[],[]] .smaller = true := by decide
def e302796741918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e302796741918 : Closed e302796741918 ∧ code e302796741918 = 1402308369694 := by decide
theorem cert_e302796741918 : check e302796741918 [[],[]] .smaller = true := by decide
def e302796741942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e302796741942 : Closed e302796741942 ∧ code e302796741942 = 1402308369718 := by decide
theorem cert_e302796741942 : check e302796741942 [[],[]] .smaller = true := by decide
def e302796741946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e302796741946 : Closed e302796741946 ∧ code e302796741946 = 1402308369722 := by decide
theorem cert_e302796741946 : check e302796741946 [[],[]] .smaller = true := by decide
def e302796742042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e302796742042 : Closed e302796742042 ∧ code e302796742042 = 1402308369818 := by decide
theorem cert_e302796742042 : check e302796742042 [[],[]] .smaller = true := by decide
def e302796742086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e302796742086 : Closed e302796742086 ∧ code e302796742086 = 1402308369862 := by decide
theorem cert_e302796742086 : check e302796742086 [[],[]] .smaller = true := by decide
def e302796742110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 3)))))))
theorem wire_e302796742110 : Closed e302796742110 ∧ code e302796742110 = 1402308369886 := by decide
theorem cert_e302796742110 : check e302796742110 [[],[]] .three = true := by decide
def e302796742126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 2)))))))
theorem wire_e302796742126 : Closed e302796742126 ∧ code e302796742126 = 1402308369902 := by decide
theorem cert_e302796742126 : check e302796742126 [[],[]] .three = true := by decide
def e302796742198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e302796742198 : Closed e302796742198 ∧ code e302796742198 = 1402308369974 := by decide
theorem cert_e302796742198 : check e302796742198 [[],[]] .smaller = true := by decide
def e302796742202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e302796742202 : Closed e302796742202 ∧ code e302796742202 = 1402308369978 := by decide
theorem cert_e302796742202 : check e302796742202 [[],[]] .smaller = true := by decide
def e302796742286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e302796742286 : Closed e302796742286 ∧ code e302796742286 = 1402308370062 := by decide
theorem cert_e302796742286 : check e302796742286 [[],[]] .smaller = true := by decide
def e302796742342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e302796742342 : Closed e302796742342 ∧ code e302796742342 = 1402308370118 := by decide
theorem cert_e302796742342 : check e302796742342 [[],[]] .smaller = true := by decide
def e302796742366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 3)))))))
theorem wire_e302796742366 : Closed e302796742366 ∧ code e302796742366 = 1402308370142 := by decide
theorem cert_e302796742366 : check e302796742366 [[],[]] .three = true := by decide
def e302796742390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.var 1)))))))
theorem wire_e302796742390 : Closed e302796742390 ∧ code e302796742390 = 1402308370166 := by decide
theorem cert_e302796742390 : check e302796742390 [[],[]] .three = true := by decide
def e302796742426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e302796742426 : Closed e302796742426 ∧ code e302796742426 = 1402308370202 := by decide
theorem cert_e302796742426 : check e302796742426 [[],[]] .three = true := by decide
def e302796742470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.lam (.var 1))))))))
theorem wire_e302796742470 : Closed e302796742470 ∧ code e302796742470 = 1402308370246 := by decide
theorem cert_e302796742470 : check e302796742470 [[],[]] .three = true := by decide
def e302796742494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 3)))))))
theorem wire_e302796742494 : Closed e302796742494 ∧ code e302796742494 = 1402308370270 := by decide
theorem cert_e302796742494 : check e302796742494 [[],[]] .three = true := by decide
def e302796742510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 2)))))))
theorem wire_e302796742510 : Closed e302796742510 ∧ code e302796742510 = 1402308370286 := by decide
theorem cert_e302796742510 : check e302796742510 [[],[]] .three = true := by decide
def e302796742518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.var 1)))))))
theorem wire_e302796742518 : Closed e302796742518 ∧ code e302796742518 = 1402308370294 := by decide
theorem cert_e302796742518 : check e302796742518 [[],[]] .three = true := by decide
def e302796742522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 3))) (.var 0)))))))
theorem wire_e302796742522 : Closed e302796742522 ∧ code e302796742522 = 1402308370298 := by decide
theorem cert_e302796742522 : check e302796742522 [[],[]] .three = true := by decide
def e302796743150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e302796743150 : Closed e302796743150 ∧ code e302796743150 = 1402308370926 := by decide
theorem cert_e302796743150 : check e302796743150 [[],[]] .smaller = true := by decide
def e302796744118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e302796744118 : Closed e302796744118 ∧ code e302796744118 = 1402308371894 := by decide
theorem cert_e302796744118 : check e302796744118 [[],[]] .smaller = true := by decide
def e302796744150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e302796744150 : Closed e302796744150 ∧ code e302796744150 = 1402308371926 := by decide
theorem cert_e302796744150 : check e302796744150 [[],[]] .smaller = true := by decide
def e302796744154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e302796744154 : Closed e302796744154 ∧ code e302796744154 = 1402308371930 := by decide
theorem cert_e302796744154 : check e302796744154 [[],[]] .smaller = true := by decide
def e302796744254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e302796744254 : Closed e302796744254 ∧ code e302796744254 = 1402308372030 := by decide
theorem cert_e302796744254 : check e302796744254 [[],[]] .three = true := by decide
def e302796744310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e302796744310 : Closed e302796744310 ∧ code e302796744310 = 1402308372086 := by decide
theorem cert_e302796744310 : check e302796744310 [[],[]] .smaller = true := by decide
def e302796744478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e302796744478 : Closed e302796744478 ∧ code e302796744478 = 1402308372254 := by decide
theorem cert_e302796744478 : check e302796744478 [[],[]] .smaller = true := by decide
def e302796744502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e302796744502 : Closed e302796744502 ∧ code e302796744502 = 1402308372278 := by decide
theorem cert_e302796744502 : check e302796744502 [[],[]] .smaller = true := by decide
def e302796744506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e302796744506 : Closed e302796744506 ∧ code e302796744506 = 1402308372282 := by decide
theorem cert_e302796744506 : check e302796744506 [[],[]] .smaller = true := by decide
def e302796744590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e302796744590 : Closed e302796744590 ∧ code e302796744590 = 1402308372366 := by decide
theorem cert_e302796744590 : check e302796744590 [[],[]] .smaller = true := by decide
def e302796744646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e302796744646 : Closed e302796744646 ∧ code e302796744646 = 1402308372422 := by decide
theorem cert_e302796744646 : check e302796744646 [[],[]] .three = true := by decide
def e302796744670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 3))))))))
theorem wire_e302796744670 : Closed e302796744670 ∧ code e302796744670 = 1402308372446 := by decide
theorem cert_e302796744670 : check e302796744670 [[],[]] .three = true := by decide
def e302796746990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e302796746990 : Closed e302796746990 ∧ code e302796746990 = 1402308374766 := by decide
theorem cert_e302796746990 : check e302796746990 [[],[]] .smaller = true := by decide
def e302796746998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e302796746998 : Closed e302796746998 ∧ code e302796746998 = 1402308374774 := by decide
theorem cert_e302796746998 : check e302796746998 [[],[]] .smaller = true := by decide
def e302796747478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e302796747478 : Closed e302796747478 ∧ code e302796747478 = 1402308375254 := by decide
theorem cert_e302796747478 : check e302796747478 [[],[]] .smaller = true := by decide
def e302796747482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e302796747482 : Closed e302796747482 ∧ code e302796747482 = 1402308375258 := by decide
theorem cert_e302796747482 : check e302796747482 [[],[]] .smaller = true := by decide
def e302796747498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e302796747498 : Closed e302796747498 ∧ code e302796747498 = 1402308375274 := by decide
theorem cert_e302796747498 : check e302796747498 [[],[]] .smaller = true := by decide
def e302796747550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302796747550 : Closed e302796747550 ∧ code e302796747550 = 1402308375326 := by decide
theorem cert_e302796747550 : check e302796747550 [[],[]] .smaller = true := by decide
def e302796747574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e302796747574 : Closed e302796747574 ∧ code e302796747574 = 1402308375350 := by decide
theorem cert_e302796747574 : check e302796747574 [[],[]] .smaller = true := by decide
def e302796747578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e302796747578 : Closed e302796747578 ∧ code e302796747578 = 1402308375354 := by decide
theorem cert_e302796747578 : check e302796747578 [[],[]] .smaller = true := by decide
def e302796747674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e302796747674 : Closed e302796747674 ∧ code e302796747674 = 1402308375450 := by decide
theorem cert_e302796747674 : check e302796747674 [[],[]] .smaller = true := by decide
def e302796747718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302796747718 : Closed e302796747718 ∧ code e302796747718 = 1402308375494 := by decide
theorem cert_e302796747718 : check e302796747718 [[],[]] .smaller = true := by decide
def e302796747742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 3))))))))
theorem wire_e302796747742 : Closed e302796747742 ∧ code e302796747742 = 1402308375518 := by decide
theorem cert_e302796747742 : check e302796747742 [[],[]] .three = true := by decide
def e302796747758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 2))))))))
theorem wire_e302796747758 : Closed e302796747758 ∧ code e302796747758 = 1402308375534 := by decide
theorem cert_e302796747758 : check e302796747758 [[],[]] .three = true := by decide
def e302796749198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302796749198 : Closed e302796749198 ∧ code e302796749198 = 1402308376974 := by decide
theorem cert_e302796749198 : check e302796749198 [[],[]] .smaller = true := by decide
def e302796749254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302796749254 : Closed e302796749254 ∧ code e302796749254 = 1402308377030 := by decide
theorem cert_e302796749254 : check e302796749254 [[],[]] .smaller = true := by decide
def e302796749278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 3))))))))
theorem wire_e302796749278 : Closed e302796749278 ∧ code e302796749278 = 1402308377054 := by decide
theorem cert_e302796749278 : check e302796749278 [[],[]] .three = true := by decide
def e302796749302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.var 1))))))))
theorem wire_e302796749302 : Closed e302796749302 ∧ code e302796749302 = 1402308377078 := by decide
theorem cert_e302796749302 : check e302796749302 [[],[]] .three = true := by decide
def e302796750022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302796750022 : Closed e302796750022 ∧ code e302796750022 = 1402308377798 := by decide
theorem cert_e302796750022 : check e302796750022 [[],[]] .three = true := by decide
def e302796750046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 3))))))))
theorem wire_e302796750046 : Closed e302796750046 ∧ code e302796750046 = 1402308377822 := by decide
theorem cert_e302796750046 : check e302796750046 [[],[]] .three = true := by decide
def e302796750062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem wire_e302796750062 : Closed e302796750062 ∧ code e302796750062 = 1402308377838 := by decide
theorem cert_e302796750062 : check e302796750062 [[],[]] .three = true := by decide
def e302796750070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem wire_e302796750070 : Closed e302796750070 ∧ code e302796750070 = 1402308377846 := by decide
theorem cert_e302796750070 : check e302796750070 [[],[]] .three = true := by decide
def e302796750074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 3) (.var 0))))))))
theorem wire_e302796750074 : Closed e302796750074 ∧ code e302796750074 = 1402308377850 := by decide
theorem cert_e302796750074 : check e302796750074 [[],[]] .three = true := by decide
def e302796751798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e302796751798 : Closed e302796751798 ∧ code e302796751798 = 1402308379574 := by decide
theorem cert_e302796751798 : check e302796751798 [[],[]] .three = true := by decide
def e302796751802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e302796751802 : Closed e302796751802 ∧ code e302796751802 = 1402308379578 := by decide
theorem cert_e302796751802 : check e302796751802 [[],[]] .three = true := by decide
def e302796751834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e302796751834 : Closed e302796751834 ∧ code e302796751834 = 1402308379610 := by decide
theorem cert_e302796751834 : check e302796751834 [[],[]] .three = true := by decide
def e302796752494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e302796752494 : Closed e302796752494 ∧ code e302796752494 = 1402308380270 := by decide
theorem cert_e302796752494 : check e302796752494 [[],[]] .three = true := by decide
def e302796752502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e302796752502 : Closed e302796752502 ∧ code e302796752502 = 1402308380278 := by decide
theorem cert_e302796752502 : check e302796752502 [[],[]] .three = true := by decide
def e302796752506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e302796752506 : Closed e302796752506 ∧ code e302796752506 = 1402308380282 := by decide
theorem cert_e302796752506 : check e302796752506 [[],[]] .three = true := by decide
def e302796752694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e302796752694 : Closed e302796752694 ∧ code e302796752694 = 1402308380470 := by decide
theorem cert_e302796752694 : check e302796752694 [[],[]] .three = true := by decide
def e302796752698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e302796752698 : Closed e302796752698 ∧ code e302796752698 = 1402308380474 := by decide
theorem cert_e302796752698 : check e302796752698 [[],[]] .three = true := by decide
def e302796752794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e302796752794 : Closed e302796752794 ∧ code e302796752794 = 1402308380570 := by decide
theorem cert_e302796752794 : check e302796752794 [[],[]] .three = true := by decide
def e302796753750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e302796753750 : Closed e302796753750 ∧ code e302796753750 = 1402308381526 := by decide
theorem cert_e302796753750 : check e302796753750 [[],[]] .three = true := by decide
def e302796753754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e302796753754 : Closed e302796753754 ∧ code e302796753754 = 1402308381530 := by decide
theorem cert_e302796753754 : check e302796753754 [[],[]] .three = true := by decide
def e302796753770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e302796753770 : Closed e302796753770 ∧ code e302796753770 = 1402308381546 := by decide
theorem cert_e302796753770 : check e302796753770 [[],[]] .three = true := by decide
def e302796753834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e302796753834 : Closed e302796753834 ∧ code e302796753834 = 1402308381610 := by decide
theorem cert_e302796753834 : check e302796753834 [[],[]] .three = true := by decide
def e302796754030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e302796754030 : Closed e302796754030 ∧ code e302796754030 = 1402308381806 := by decide
theorem cert_e302796754030 : check e302796754030 [[],[]] .three = true := by decide
def e302796754038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e302796754038 : Closed e302796754038 ∧ code e302796754038 = 1402308381814 := by decide
theorem cert_e302796754038 : check e302796754038 [[],[]] .three = true := by decide
def e302796754042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302796754042 : Closed e302796754042 ∧ code e302796754042 = 1402308381818 := by decide
theorem cert_e302796754042 : check e302796754042 [[],[]] .three = true := by decide
def e302796754134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e302796754134 : Closed e302796754134 ∧ code e302796754134 = 1402308381910 := by decide
theorem cert_e302796754134 : check e302796754134 [[],[]] .three = true := by decide
def e302796754138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e302796754138 : Closed e302796754138 ∧ code e302796754138 = 1402308381914 := by decide
theorem cert_e302796754138 : check e302796754138 [[],[]] .three = true := by decide
def e302796754154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e302796754154 : Closed e302796754154 ∧ code e302796754154 = 1402308381930 := by decide
theorem cert_e302796754154 : check e302796754154 [[],[]] .three = true := by decide
def e302796754206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e302796754206 : Closed e302796754206 ∧ code e302796754206 = 1402308381982 := by decide
theorem cert_e302796754206 : check e302796754206 [[],[]] .three = true := by decide
def e302796754230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e302796754230 : Closed e302796754230 ∧ code e302796754230 = 1402308382006 := by decide
theorem cert_e302796754230 : check e302796754230 [[],[]] .three = true := by decide
def e302796754234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e302796754234 : Closed e302796754234 ∧ code e302796754234 = 1402308382010 := by decide
theorem cert_e302796754234 : check e302796754234 [[],[]] .three = true := by decide
def e302796754318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e302796754318 : Closed e302796754318 ∧ code e302796754318 = 1402308382094 := by decide
theorem cert_e302796754318 : check e302796754318 [[],[]] .three = true := by decide
def e302796754330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e302796754330 : Closed e302796754330 ∧ code e302796754330 = 1402308382106 := by decide
theorem cert_e302796754330 : check e302796754330 [[],[]] .three = true := by decide
def e302796754374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e302796754374 : Closed e302796754374 ∧ code e302796754374 = 1402308382150 := by decide
theorem cert_e302796754374 : check e302796754374 [[],[]] .three = true := by decide
def e302796754398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e302796754398 : Closed e302796754398 ∧ code e302796754398 = 1402308382174 := by decide
theorem cert_e302796754398 : check e302796754398 [[],[]] .three = true := by decide
def e302796754414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e302796754414 : Closed e302796754414 ∧ code e302796754414 = 1402308382190 := by decide
theorem cert_e302796754414 : check e302796754414 [[],[]] .three = true := by decide
def e302796754486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e302796754486 : Closed e302796754486 ∧ code e302796754486 = 1402308382262 := by decide
theorem cert_e302796754486 : check e302796754486 [[],[]] .three = true := by decide
def e302796754490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e302796754490 : Closed e302796754490 ∧ code e302796754490 = 1402308382266 := by decide
theorem cert_e302796754490 : check e302796754490 [[],[]] .three = true := by decide
def e302796754538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e302796754538 : Closed e302796754538 ∧ code e302796754538 = 1402308382314 := by decide
theorem cert_e302796754538 : check e302796754538 [[],[]] .three = true := by decide
def e302796754574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e302796754574 : Closed e302796754574 ∧ code e302796754574 = 1402308382350 := by decide
theorem cert_e302796754574 : check e302796754574 [[],[]] .three = true := by decide
def e302796754586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e302796754586 : Closed e302796754586 ∧ code e302796754586 = 1402308382362 := by decide
theorem cert_e302796754586 : check e302796754586 [[],[]] .three = true := by decide
def e302796754630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e302796754630 : Closed e302796754630 ∧ code e302796754630 = 1402308382406 := by decide
theorem cert_e302796754630 : check e302796754630 [[],[]] .three = true := by decide
def e302796754670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e302796754670 : Closed e302796754670 ∧ code e302796754670 = 1402308382446 := by decide
theorem cert_e302796754670 : check e302796754670 [[],[]] .three = true := by decide
def e302796754714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e302796754714 : Closed e302796754714 ∧ code e302796754714 = 1402308382490 := by decide
theorem cert_e302796754714 : check e302796754714 [[],[]] .three = true := by decide
def e302796754758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e302796754758 : Closed e302796754758 ∧ code e302796754758 = 1402308382534 := by decide
theorem cert_e302796754758 : check e302796754758 [[],[]] .three = true := by decide
def e302796754782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e302796754782 : Closed e302796754782 ∧ code e302796754782 = 1402308382558 := by decide
theorem cert_e302796754782 : check e302796754782 [[],[]] .three = true := by decide
def e302796754798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e302796754798 : Closed e302796754798 ∧ code e302796754798 = 1402308382574 := by decide
theorem cert_e302796754798 : check e302796754798 [[],[]] .three = true := by decide
def e302796754806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e302796754806 : Closed e302796754806 ∧ code e302796754806 = 1402308382582 := by decide
theorem cert_e302796754806 : check e302796754806 [[],[]] .three = true := by decide
def e302796754810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e302796754810 : Closed e302796754810 ∧ code e302796754810 = 1402308382586 := by decide
theorem cert_e302796754810 : check e302796754810 [[],[]] .three = true := by decide
def e302796754862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e302796754862 : Closed e302796754862 ∧ code e302796754862 = 1402308382638 := by decide
theorem cert_e302796754862 : check e302796754862 [[],[]] .three = true := by decide
def e302796754874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e302796754874 : Closed e302796754874 ∧ code e302796754874 = 1402308382650 := by decide
theorem cert_e302796754874 : check e302796754874 [[],[]] .three = true := by decide
def e302796755182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e302796755182 : Closed e302796755182 ∧ code e302796755182 = 1402308382958 := by decide
theorem cert_e302796755182 : check e302796755182 [[],[]] .three = true := by decide
def e302796755190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e302796755190 : Closed e302796755190 ∧ code e302796755190 = 1402308382966 := by decide
theorem cert_e302796755190 : check e302796755190 [[],[]] .three = true := by decide
def e302796755670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e302796755670 : Closed e302796755670 ∧ code e302796755670 = 1402308383446 := by decide
theorem cert_e302796755670 : check e302796755670 [[],[]] .three = true := by decide
def e302796755674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e302796755674 : Closed e302796755674 ∧ code e302796755674 = 1402308383450 := by decide
theorem cert_e302796755674 : check e302796755674 [[],[]] .three = true := by decide
def e302796755690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e302796755690 : Closed e302796755690 ∧ code e302796755690 = 1402308383466 := by decide
theorem cert_e302796755690 : check e302796755690 [[],[]] .three = true := by decide
def e302796755742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302796755742 : Closed e302796755742 ∧ code e302796755742 = 1402308383518 := by decide
theorem cert_e302796755742 : check e302796755742 [[],[]] .three = true := by decide
def e302796755766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e302796755766 : Closed e302796755766 ∧ code e302796755766 = 1402308383542 := by decide
theorem cert_e302796755766 : check e302796755766 [[],[]] .three = true := by decide
def e302796755770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e302796755770 : Closed e302796755770 ∧ code e302796755770 = 1402308383546 := by decide
theorem cert_e302796755770 : check e302796755770 [[],[]] .three = true := by decide
def e302796755854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e302796755854 : Closed e302796755854 ∧ code e302796755854 = 1402308383630 := by decide
theorem cert_e302796755854 : check e302796755854 [[],[]] .three = true := by decide
def e302796755866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e302796755866 : Closed e302796755866 ∧ code e302796755866 = 1402308383642 := by decide
theorem cert_e302796755866 : check e302796755866 [[],[]] .three = true := by decide
def e302796755910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302796755910 : Closed e302796755910 ∧ code e302796755910 = 1402308383686 := by decide
theorem cert_e302796755910 : check e302796755910 [[],[]] .three = true := by decide
def e302796755934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e302796755934 : Closed e302796755934 ∧ code e302796755934 = 1402308383710 := by decide
theorem cert_e302796755934 : check e302796755934 [[],[]] .three = true := by decide
def e302796755950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e302796755950 : Closed e302796755950 ∧ code e302796755950 = 1402308383726 := by decide
theorem cert_e302796755950 : check e302796755950 [[],[]] .three = true := by decide
def e302796757110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e302796757110 : Closed e302796757110 ∧ code e302796757110 = 1402308384886 := by decide
theorem cert_e302796757110 : check e302796757110 [[],[]] .three = true := by decide
def e302796757354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e302796757354 : Closed e302796757354 ∧ code e302796757354 = 1402308385130 := by decide
theorem cert_e302796757354 : check e302796757354 [[],[]] .three = true := by decide
def e302796757390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302796757390 : Closed e302796757390 ∧ code e302796757390 = 1402308385166 := by decide
theorem cert_e302796757390 : check e302796757390 [[],[]] .three = true := by decide
def e302796757402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e302796757402 : Closed e302796757402 ∧ code e302796757402 = 1402308385178 := by decide
theorem cert_e302796757402 : check e302796757402 [[],[]] .three = true := by decide
def e302796757446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302796757446 : Closed e302796757446 ∧ code e302796757446 = 1402308385222 := by decide
theorem cert_e302796757446 : check e302796757446 [[],[]] .three = true := by decide
def e302796757486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e302796757486 : Closed e302796757486 ∧ code e302796757486 = 1402308385262 := by decide
theorem cert_e302796757486 : check e302796757486 [[],[]] .three = true := by decide
def e302796758214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302796758214 : Closed e302796758214 ∧ code e302796758214 = 1402308385990 := by decide
theorem cert_e302796758214 : check e302796758214 [[],[]] .three = true := by decide
def e302796758238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e302796758238 : Closed e302796758238 ∧ code e302796758238 = 1402308386014 := by decide
theorem cert_e302796758238 : check e302796758238 [[],[]] .three = true := by decide
def e302796758254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e302796758254 : Closed e302796758254 ∧ code e302796758254 = 1402308386030 := by decide
theorem cert_e302796758254 : check e302796758254 [[],[]] .three = true := by decide
def e302796758262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e302796758262 : Closed e302796758262 ∧ code e302796758262 = 1402308386038 := by decide
theorem cert_e302796758262 : check e302796758262 [[],[]] .three = true := by decide
def e302796758266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e302796758266 : Closed e302796758266 ∧ code e302796758266 = 1402308386042 := by decide
theorem cert_e302796758266 : check e302796758266 [[],[]] .three = true := by decide
def e302796758638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e302796758638 : Closed e302796758638 ∧ code e302796758638 = 1402308386414 := by decide
private def t_e302796758638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem cert_e302796758638 : ¬ IsSelfInterpreter e302796758638 :=
  wSource (t := t_e302796758638) (replay_sound (ps := []) (t := e302796758638) (by decide)) (by decide)
def e302796758650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e302796758650 : Closed e302796758650 ∧ code e302796758650 = 1402308386426 := by decide
private def t_e302796758650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem cert_e302796758650 : ¬ IsSelfInterpreter e302796758650 :=
  wSource (t := t_e302796758650) (replay_sound (ps := []) (t := e302796758650) (by decide)) (by decide)
def e302796789998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e302796789998 : Closed e302796789998 ∧ code e302796789998 = 1402308417774 := by decide
theorem cert_e302796789998 : check e302796789998 [[],[]] .smaller = true := by decide
def e302796790006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e302796790006 : Closed e302796790006 ∧ code e302796790006 = 1402308417782 := by decide
theorem cert_e302796790006 : check e302796790006 [[],[]] .smaller = true := by decide
def e302796790558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e302796790558 : Closed e302796790558 ∧ code e302796790558 = 1402308418334 := by decide
theorem cert_e302796790558 : check e302796790558 [[],[]] .smaller = true := by decide
def e302796790670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e302796790670 : Closed e302796790670 ∧ code e302796790670 = 1402308418446 := by decide
theorem cert_e302796790670 : check e302796790670 [[],[]] .smaller = true := by decide
def e302796790894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e302796790894 : Closed e302796790894 ∧ code e302796790894 = 1402308418670 := by decide
theorem cert_e302796790894 : check e302796790894 [[],[]] .smaller = true := by decide
def e302796790906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e302796790906 : Closed e302796790906 ∧ code e302796790906 = 1402308418682 := by decide
theorem cert_e302796790906 : check e302796790906 [[],[]] .smaller = true := by decide
def e302796791070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e302796791070 : Closed e302796791070 ∧ code e302796791070 = 1402308418846 := by decide
theorem cert_e302796791070 : check e302796791070 [[],[]] .smaller = true := by decide
def e302796791238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e302796791238 : Closed e302796791238 ∧ code e302796791238 = 1402308419014 := by decide
theorem cert_e302796791238 : check e302796791238 [[],[]] .smaller = true := by decide
def e302796791262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e302796791262 : Closed e302796791262 ∧ code e302796791262 = 1402308419038 := by decide
theorem cert_e302796791262 : check e302796791262 [[],[]] .smaller = true := by decide
def e302796791278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e302796791278 : Closed e302796791278 ∧ code e302796791278 = 1402308419054 := by decide
theorem cert_e302796791278 : check e302796791278 [[],[]] .smaller = true := by decide
def e302796791350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e302796791350 : Closed e302796791350 ∧ code e302796791350 = 1402308419126 := by decide
theorem cert_e302796791350 : check e302796791350 [[],[]] .smaller = true := by decide
def e302796791354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e302796791354 : Closed e302796791354 ∧ code e302796791354 = 1402308419130 := by decide
theorem cert_e302796791354 : check e302796791354 [[],[]] .smaller = true := by decide
def e302796791438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e302796791438 : Closed e302796791438 ∧ code e302796791438 = 1402308419214 := by decide
theorem cert_e302796791438 : check e302796791438 [[],[]] .smaller = true := by decide
def e302796791494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e302796791494 : Closed e302796791494 ∧ code e302796791494 = 1402308419270 := by decide
theorem cert_e302796791494 : check e302796791494 [[],[]] .smaller = true := by decide
def e302796791518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e302796791518 : Closed e302796791518 ∧ code e302796791518 = 1402308419294 := by decide
theorem cert_e302796791518 : check e302796791518 [[],[]] .smaller = true := by decide
def e302796791542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e302796791542 : Closed e302796791542 ∧ code e302796791542 = 1402308419318 := by decide
theorem cert_e302796791542 : check e302796791542 [[],[]] .smaller = true := by decide
def e302796791662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e302796791662 : Closed e302796791662 ∧ code e302796791662 = 1402308419438 := by decide
theorem cert_e302796791662 : check e302796791662 [[],[]] .smaller = true := by decide
def e302796791670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e302796791670 : Closed e302796791670 ∧ code e302796791670 = 1402308419446 := by decide
theorem cert_e302796791670 : check e302796791670 [[],[]] .smaller = true := by decide
def e302796793630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e302796793630 : Closed e302796793630 ∧ code e302796793630 = 1402308421406 := by decide
theorem cert_e302796793630 : check e302796793630 [[],[]] .smaller = true := by decide
def e302796793742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e302796793742 : Closed e302796793742 ∧ code e302796793742 = 1402308421518 := by decide
theorem cert_e302796793742 : check e302796793742 [[],[]] .smaller = true := by decide
def e302796796702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e302796796702 : Closed e302796796702 ∧ code e302796796702 = 1402308424478 := by decide
theorem cert_e302796796702 : check e302796796702 [[],[]] .smaller = true := by decide
def e302796796870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e302796796870 : Closed e302796796870 ∧ code e302796796870 = 1402308424646 := by decide
theorem cert_e302796796870 : check e302796796870 [[],[]] .smaller = true := by decide
def e302796796894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e302796796894 : Closed e302796796894 ∧ code e302796796894 = 1402308424670 := by decide
theorem cert_e302796796894 : check e302796796894 [[],[]] .smaller = true := by decide
def e302796796910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e302796796910 : Closed e302796796910 ∧ code e302796796910 = 1402308424686 := by decide
theorem cert_e302796796910 : check e302796796910 [[],[]] .smaller = true := by decide
def e302796798350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e302796798350 : Closed e302796798350 ∧ code e302796798350 = 1402308426126 := by decide
theorem cert_e302796798350 : check e302796798350 [[],[]] .smaller = true := by decide
def e302796798406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e302796798406 : Closed e302796798406 ∧ code e302796798406 = 1402308426182 := by decide
theorem cert_e302796798406 : check e302796798406 [[],[]] .smaller = true := by decide
def e302796798430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e302796798430 : Closed e302796798430 ∧ code e302796798430 = 1402308426206 := by decide
theorem cert_e302796798430 : check e302796798430 [[],[]] .smaller = true := by decide
def e302796798454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e302796798454 : Closed e302796798454 ∧ code e302796798454 = 1402308426230 := by decide
theorem cert_e302796798454 : check e302796798454 [[],[]] .smaller = true := by decide
def e302796799214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e302796799214 : Closed e302796799214 ∧ code e302796799214 = 1402308426990 := by decide
theorem cert_e302796799214 : check e302796799214 [[],[]] .smaller = true := by decide
def e302796799222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e302796799222 : Closed e302796799222 ∧ code e302796799222 = 1402308426998 := by decide
theorem cert_e302796799222 : check e302796799222 [[],[]] .smaller = true := by decide
def e302796856030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e302796856030 : Closed e302796856030 ∧ code e302796856030 = 1402308483806 := by decide
theorem cert_e302796856030 : check e302796856030 [[],[]] .three = true := by decide
def e302796856054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e302796856054 : Closed e302796856054 ∧ code e302796856054 = 1402308483830 := by decide
theorem cert_e302796856054 : check e302796856054 [[],[]] .three = true := by decide
def e302796856158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e302796856158 : Closed e302796856158 ∧ code e302796856158 = 1402308483934 := by decide
theorem cert_e302796856158 : check e302796856158 [[],[]] .three = true := by decide
def e302796856174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e302796856174 : Closed e302796856174 ∧ code e302796856174 = 1402308483950 := by decide
theorem cert_e302796856174 : check e302796856174 [[],[]] .smaller = true := by decide
def e302796856182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e302796856182 : Closed e302796856182 ∧ code e302796856182 = 1402308483958 := by decide
theorem cert_e302796856182 : check e302796856182 [[],[]] .smaller = true := by decide
def e302796856186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e302796856186 : Closed e302796856186 ∧ code e302796856186 = 1402308483962 := by decide
theorem cert_e302796856186 : check e302796856186 [[],[]] .three = true := by decide
end Blc.Floor40
