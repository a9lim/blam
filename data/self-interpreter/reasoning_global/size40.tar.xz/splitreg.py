from candidates import *
from emitreg import emit
def split(p):
    s=p.read_text();name=p.stem;ns='Certgen.'+name
    a=s.index('theorem block0');b=s.index('theorem closedAt')
    lines=s[a:b].splitlines()
    if len(lines)<8:return [name]
    head=s[:a];(HERE/(name+'Data.lean')).write_text(head+'\nend '+ns+'\n')
    mods=[name+'Data']
    for j in range(0,len(lines),4):
        mod=name+'C'+str(j)
        (HERE/(mod+'.lean')).write_text('import '+mods[0]+f'\nnamespace {ns}\nset_option maxRecDepth 30000\nset_option maxHeartbeats 12000000\n'+'\n'.join(lines[j:j+4]).replace('by decide','by decide +kernel')+'\nend '+ns+'\n')
        mods.append(mod)
    n=sum(int(x.split('=true')[0].split()[-1]) for x in lines)
    bounds=[int(x.split('=true')[0].split()[-2]) for x in lines]
    def dispatch(js,depth):
        if len(js)==1:return 'exact range_sound block'+str(js[0])+' i (by omega) (by omega) hi'
        t=len(js)//2;x=js[t]
        return f'by_cases h{x} : i < {x}\n'+' '*depth+'· '+dispatch(js[:t],depth+2)+'\n'+' '*depth+'· '+dispatch(js[t:],depth+2)
    s=s[b:]
    h=s.index('theorem closed :')
    s=f'theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by\n have hh : i < {n} := hi\n '+dispatch(bounds,1)+'\n'+s[h:]
    p.write_text(''.join(f'import {m}\n' for m in mods[1:])+f'namespace {ns}\nset_option maxRecDepth 30000\nset_option maxHeartbeats 12000000\n'+s)
    return mods+[name]
if __name__=='__main__':
    import subprocess
    for p in sorted(HERE.glob('r[0-9]*.json')):
        name=p.stem[1:]
        if (HERE/('R'+name+'.olean')).exists():continue
        r=json.loads(p.read_text())
        if r[1]=='bottom1':continue
        emit(f'{int(name):040b}',r)
        mods=split(HERE/('R'+name+'.lean'))
        subprocess.run([sys.executable,'build.py',*mods],check=True,timeout=240)
