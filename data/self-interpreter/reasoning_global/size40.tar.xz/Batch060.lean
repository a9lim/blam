import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302824743710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e302824743710 : Closed e302824743710 ∧ code e302824743710 = 1402336371486 := by decide
theorem cert_e302824743710 : checkPay e302824743710 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.under,.left],[.under,.under,.left,.left]] = true := by decide
def e302824743878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e302824743878 : Closed e302824743878 ∧ code e302824743878 = 1402336371654 := by decide
theorem cert_e302824743878 : checkPay e302824743878 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e302824744494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e302824744494 : Closed e302824744494 ∧ code e302824744494 = 1402336372270 := by decide
theorem cert_e302824744494 : checkPay e302824744494 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e302824744674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e302824744674 : Closed e302824744674 ∧ code e302824744674 = 1402336372450 := by decide
theorem cert_e302824744674 : checkPay e302824744674 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [] = true := by decide
def e302824744686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e302824744686 : Closed e302824744686 ∧ code e302824744686 = 1402336372462 := by decide
theorem cert_e302824744686 : checkPay e302824744686 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [] = true := by decide
def e302824744842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e302824744842 : Closed e302824744842 ∧ code e302824744842 = 1402336372618 := by decide
theorem cert_e302824744842 : checkPay e302824744842 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[],[.under],[.under,.under,.left,.right]] = true := by decide
def e302824744866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e302824744866 : Closed e302824744866 ∧ code e302824744866 = 1402336372642 := by decide
theorem cert_e302824744866 : checkPay e302824744866 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [] = true := by decide
def e302824744878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e302824744878 : Closed e302824744878 ∧ code e302824744878 = 1402336372654 := by decide
theorem cert_e302824744878 : checkPay e302824744878 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 1 [] = true := by decide
def e302824744890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e302824744890 : Closed e302824744890 ∧ code e302824744890 = 1402336372666 := by decide
def e302824745022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e302824745022 : Closed e302824745022 ∧ code e302824745022 = 1402336372798 := by decide
theorem cert_e302824745022 : checkPay e302824745022 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left]] = true := by decide
def e302824745442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e302824745442 : Closed e302824745442 ∧ code e302824745442 = 1402336373218 := by decide
theorem cert_e302824745442 : checkPay e302824745442 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left],[.under,.right],[.under,.right,.right],[.under,.right,.right,.under],[.under,.right,.right,.under,.under,.right]] = true := by decide
def e302824745454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e302824745454 : Closed e302824745454 ∧ code e302824745454 = 1402336373230 := by decide
def e302824746510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e302824746510 : Closed e302824746510 ∧ code e302824746510 = 1402336374286 := by decide
theorem cert_e302824746510 : checkPay e302824746510 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e302824746594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e302824746594 : Closed e302824746594 ∧ code e302824746594 = 1402336374370 := by decide
theorem cert_e302824746594 : checkPay e302824746594 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e302824746606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e302824746606 : Closed e302824746606 ∧ code e302824746606 = 1402336374382 := by decide
theorem cert_e302824746606 : checkPay e302824746606 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e302824746618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e302824746618 : Closed e302824746618 ∧ code e302824746618 = 1402336374394 := by decide
theorem cert_e302824746618 : checkPay e302824746618 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e302824747126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e302824747126 : Closed e302824747126 ∧ code e302824747126 = 1402336374902 := by decide
theorem cert_e302824747126 : check e302824747126 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e302824747130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302824747130 : Closed e302824747130 ∧ code e302824747130 = 1402336374906 := by decide
theorem cert_e302824747130 : check e302824747130 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e302824747318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e302824747318 : Closed e302824747318 ∧ code e302824747318 = 1402336375094 := by decide
theorem cert_e302824747318 : check e302824747318 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e302824747322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e302824747322 : Closed e302824747322 ∧ code e302824747322 = 1402336375098 := by decide
theorem cert_e302824747322 : check e302824747322 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e302824747406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e302824747406 : Closed e302824747406 ∧ code e302824747406 = 1402336375182 := by decide
theorem cert_e302824747406 : check e302824747406 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e302824747462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e302824747462 : Closed e302824747462 ∧ code e302824747462 = 1402336375238 := by decide
theorem cert_e302824747462 : check e302824747462 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e302824747798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e302824747798 : Closed e302824747798 ∧ code e302824747798 = 1402336375574 := by decide
theorem cert_e302824747798 : check e302824747798 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302824747874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e302824747874 : Closed e302824747874 ∧ code e302824747874 = 1402336375650 := by decide
theorem cert_e302824747874 : check e302824747874 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302824747886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e302824747886 : Closed e302824747886 ∧ code e302824747886 = 1402336375662 := by decide
theorem cert_e302824747886 : check e302824747886 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e302824747894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e302824747894 : Closed e302824747894 ∧ code e302824747894 = 1402336375670 := by decide
private def t_e302824747894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem cert_e302824747894 : ¬ IsSelfInterpreter e302824747894 :=
  wSource (t := t_e302824747894) (replay_sound (ps := []) (t := e302824747894) (by decide)) (by decide)
def e302824747914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e302824747914 : Closed e302824747914 ∧ code e302824747914 = 1402336375690 := by decide
theorem cert_e302824747914 : check e302824747914 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e302824747938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e302824747938 : Closed e302824747938 ∧ code e302824747938 = 1402336375714 := by decide
theorem cert_e302824747938 : checkPay e302824747938 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[]] 0 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.right],[.under,.left,.right,.under,.left,.left,.right],[.under,.left,.right,.under,.left,.right]] = true := by decide
def e302824747950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e302824747950 : Closed e302824747950 ∧ code e302824747950 = 1402336375726 := by decide
def e302824747962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e302824747962 : Closed e302824747962 ∧ code e302824747962 = 1402336375738 := by decide
theorem cert_e302824747962 : checkPay e302824747962 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[]] 0 [] = true := by decide
def e302824747990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e302824747990 : Closed e302824747990 ∧ code e302824747990 = 1402336375766 := by decide
private def t_e302824747990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem cert_e302824747990 : ¬ IsSelfInterpreter e302824747990 :=
  wSource (t := t_e302824747990) (replay_sound (ps := []) (t := e302824747990) (by decide)) (by decide)
def e302824747994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e302824747994 : Closed e302824747994 ∧ code e302824747994 = 1402336375770 := by decide
theorem cert_e302824747994 : check e302824747994 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302824748062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e302824748062 : Closed e302824748062 ∧ code e302824748062 = 1402336375838 := by decide
private def t_e302824748062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem cert_e302824748062 : ¬ IsSelfInterpreter e302824748062 :=
  wSource (t := t_e302824748062) (replay_sound (ps := []) (t := e302824748062) (by decide)) (by decide)
def e302824748258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302824748258 : Closed e302824748258 ∧ code e302824748258 = 1402336376034 := by decide
private def t_e302824748258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem cert_e302824748258 : ¬ IsSelfInterpreter e302824748258 :=
  wSource (t := t_e302824748258) (replay_sound (ps := []) (t := e302824748258) (by decide)) (by decide)
def e302824748270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e302824748270 : Closed e302824748270 ∧ code e302824748270 = 1402336376046 := by decide
private def t_e302824748270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem cert_e302824748270 : ¬ IsSelfInterpreter e302824748270 :=
  wSource (t := t_e302824748270) (replay_sound (ps := []) (t := e302824748270) (by decide)) (by decide)
def e302824748278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e302824748278 : Closed e302824748278 ∧ code e302824748278 = 1402336376054 := by decide
private def t_e302824748278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem cert_e302824748278 : ¬ IsSelfInterpreter e302824748278 :=
  wSource (t := t_e302824748278) (replay_sound (ps := []) (t := e302824748278) (by decide)) (by decide)
def e302824748558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e302824748558 : Closed e302824748558 ∧ code e302824748558 = 1402336376334 := by decide
theorem cert_e302824748558 : check e302824748558 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e302824748642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e302824748642 : Closed e302824748642 ∧ code e302824748642 = 1402336376418 := by decide
theorem cert_e302824748642 : check e302824748642 [[],[],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e302824748654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e302824748654 : Closed e302824748654 ∧ code e302824748654 = 1402336376430 := by decide
theorem cert_e302824748654 : check e302824748654 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302824748666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e302824748666 : Closed e302824748666 ∧ code e302824748666 = 1402336376442 := by decide
theorem cert_e302824748666 : check e302824748666 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302824748854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e302824748854 : Closed e302824748854 ∧ code e302824748854 = 1402336376630 := by decide
private def t_e302824748854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e302824748854 : ¬ IsSelfInterpreter e302824748854 :=
  wSource (t := t_e302824748854) (replay_sound (ps := []) (t := e302824748854) (by decide)) (by decide)
def e302824748858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e302824748858 : Closed e302824748858 ∧ code e302824748858 = 1402336376634 := by decide
private def t_e302824748858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e302824748858 : ¬ IsSelfInterpreter e302824748858 :=
  wSource (t := t_e302824748858) (replay_sound (ps := []) (t := e302824748858) (by decide)) (by decide)
def e302824754030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302824754030 : Closed e302824754030 ∧ code e302824754030 = 1402336381806 := by decide
private def t_e302824754030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem cert_e302824754030 : ¬ IsSelfInterpreter e302824754030 :=
  wSource (t := t_e302824754030) (replay_sound (ps := []) (t := e302824754030) (by decide)) (by decide)
def e302824754038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302824754038 : Closed e302824754038 ∧ code e302824754038 = 1402336381814 := by decide
theorem cert_e302824754038 : check e302824754038 [[],[],[.under]] .width = true := by decide
def e302824754094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302824754094 : Closed e302824754094 ∧ code e302824754094 = 1402336381870 := by decide
private def t_e302824754094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem cert_e302824754094 : ¬ IsSelfInterpreter e302824754094 :=
  wSource (t := t_e302824754094) (replay_sound (ps := []) (t := e302824754094) (by decide)) (by decide)
def e302824754106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302824754106 : Closed e302824754106 ∧ code e302824754106 = 1402336381882 := by decide
theorem cert_e302824754106 : check e302824754106 [[],[],[.under]] .width = true := by decide
def e302824754134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302824754134 : Closed e302824754134 ∧ code e302824754134 = 1402336381910 := by decide
theorem cert_e302824754134 : check e302824754134 [[],[],[.under]] .width = true := by decide
def e302824754138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302824754138 : Closed e302824754138 ∧ code e302824754138 = 1402336381914 := by decide
theorem cert_e302824754138 : check e302824754138 [[],[],[.under]] .width = true := by decide
def e302824754414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302824754414 : Closed e302824754414 ∧ code e302824754414 = 1402336382190 := by decide
theorem cert_e302824754414 : check e302824754414 [[],[],[.under]] .width = true := by decide
def e302824754422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302824754422 : Closed e302824754422 ∧ code e302824754422 = 1402336382198 := by decide
theorem cert_e302824754422 : check e302824754422 [[],[],[.under]] .width = true := by decide
def e302824754798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302824754798 : Closed e302824754798 ∧ code e302824754798 = 1402336382574 := by decide
theorem cert_e302824754798 : check e302824754798 [[],[],[.under]] .width = true := by decide
def e302824754810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302824754810 : Closed e302824754810 ∧ code e302824754810 = 1402336382586 := by decide
theorem cert_e302824754810 : check e302824754810 [[],[],[.under]] .width = true := by decide
def e302824754998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302824754998 : Closed e302824754998 ∧ code e302824754998 = 1402336382774 := by decide
theorem cert_e302824754998 : check e302824754998 [[],[],[.under]] .width = true := by decide
def e302824755002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302824755002 : Closed e302824755002 ∧ code e302824755002 = 1402336382778 := by decide
theorem cert_e302824755002 : check e302824755002 [[],[],[.under]] .width = true := by decide
def e302824762926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e302824762926 : Closed e302824762926 ∧ code e302824762926 = 1402336390702 := by decide
theorem cert_e302824762926 : check e302824762926 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e302824763106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e302824763106 : Closed e302824763106 ∧ code e302824763106 = 1402336390882 := by decide
theorem cert_e302824763106 : check e302824763106 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e302824763118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e302824763118 : Closed e302824763118 ∧ code e302824763118 = 1402336390894 := by decide
theorem cert_e302824763118 : check e302824763118 [[],[],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e302824763158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e302824763158 : Closed e302824763158 ∧ code e302824763158 = 1402336390934 := by decide
theorem cert_e302824763158 : check e302824763158 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e302824763234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e302824763234 : Closed e302824763234 ∧ code e302824763234 = 1402336391010 := by decide
theorem cert_e302824763234 : check e302824763234 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e302824763246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e302824763246 : Closed e302824763246 ∧ code e302824763246 = 1402336391022 := by decide
theorem cert_e302824763246 : checkPay e302824763246 [[.left,.left],[.left,.left],[.left],[.left],[],[],[],[.left,.left],[.left]] 0 [] = true := by decide
def e302824763254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e302824763254 : Closed e302824763254 ∧ code e302824763254 = 1402336391030 := by decide
private def t_e302824763254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem cert_e302824763254 : ¬ IsSelfInterpreter e302824763254 :=
  wSource (t := t_e302824763254) (replay_sound (ps := []) (t := e302824763254) (by decide)) (by decide)
def e302824765502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e302824765502 : Closed e302824765502 ∧ code e302824765502 = 1402336393278 := by decide
theorem cert_e302824765502 : checkPay e302824765502 [[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 0 [] = true := by decide
def e302824765922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e302824765922 : Closed e302824765922 ∧ code e302824765922 = 1402336393698 := by decide
theorem cert_e302824765922 : checkPay e302824765922 [[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 0 [[],[.under],[.under,.under,.right,.right]] = true := by decide
def e302824765934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e302824765934 : Closed e302824765934 ∧ code e302824765934 = 1402336393710 := by decide
def e302824766494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e302824766494 : Closed e302824766494 ∧ code e302824766494 = 1402336394270 := by decide
theorem cert_e302824766494 : check e302824766494 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e302824766690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e302824766690 : Closed e302824766690 ∧ code e302824766690 = 1402336394466 := by decide
theorem cert_e302824766690 : check e302824766690 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e302824766702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e302824766702 : Closed e302824766702 ∧ code e302824766702 = 1402336394478 := by decide
theorem cert_e302824766702 : checkPay e302824766702 [[.left,.left],[.left,.left],[.left],[.left],[],[],[],[.left],[]] 0 [] = true := by decide
def e302824766710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e302824766710 : Closed e302824766710 ∧ code e302824766710 = 1402336394486 := by decide
theorem cert_e302824766710 : check e302824766710 [[],[],[.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302824789550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e302824789550 : Closed e302824789550 ∧ code e302824789550 = 1402336417326 := by decide
theorem cert_e302824789550 : check e302824789550 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824789730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e302824789730 : Closed e302824789730 ∧ code e302824789730 = 1402336417506 := by decide
theorem cert_e302824789730 : check e302824789730 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824789742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e302824789742 : Closed e302824789742 ∧ code e302824789742 = 1402336417518 := by decide
theorem cert_e302824789742 : check e302824789742 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824789898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e302824789898 : Closed e302824789898 ∧ code e302824789898 = 1402336417674 := by decide
theorem cert_e302824789898 : check e302824789898 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824789922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e302824789922 : Closed e302824789922 ∧ code e302824789922 = 1402336417698 := by decide
theorem cert_e302824789922 : check e302824789922 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824789934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e302824789934 : Closed e302824789934 ∧ code e302824789934 = 1402336417710 := by decide
theorem cert_e302824789934 : check e302824789934 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824789946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e302824789946 : Closed e302824789946 ∧ code e302824789946 = 1402336417722 := by decide
theorem cert_e302824789946 : check e302824789946 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824790078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e302824790078 : Closed e302824790078 ∧ code e302824790078 = 1402336417854 := by decide
theorem cert_e302824790078 : check e302824790078 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824790498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e302824790498 : Closed e302824790498 ∧ code e302824790498 = 1402336418274 := by decide
theorem cert_e302824790498 : check e302824790498 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824790510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e302824790510 : Closed e302824790510 ∧ code e302824790510 = 1402336418286 := by decide
theorem cert_e302824790510 : check e302824790510 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824791566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e302824791566 : Closed e302824791566 ∧ code e302824791566 = 1402336419342 := by decide
theorem cert_e302824791566 : check e302824791566 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824791650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e302824791650 : Closed e302824791650 ∧ code e302824791650 = 1402336419426 := by decide
theorem cert_e302824791650 : check e302824791650 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824791662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e302824791662 : Closed e302824791662 ∧ code e302824791662 = 1402336419438 := by decide
theorem cert_e302824791662 : check e302824791662 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824791674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e302824791674 : Closed e302824791674 ∧ code e302824791674 = 1402336419450 := by decide
theorem cert_e302824791674 : check e302824791674 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824803094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e302824803094 : Closed e302824803094 ∧ code e302824803094 = 1402336430870 := by decide
theorem cert_e302824803094 : check e302824803094 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e302824803170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e302824803170 : Closed e302824803170 ∧ code e302824803170 = 1402336430946 := by decide
theorem cert_e302824803170 : check e302824803170 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e302824803182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302824803182 : Closed e302824803182 ∧ code e302824803182 = 1402336430958 := by decide
def e302824803190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302824803190 : Closed e302824803190 ∧ code e302824803190 = 1402336430966 := by decide
private def t_e302824803190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e302824803190 : ¬ IsSelfInterpreter e302824803190 :=
  wSource (t := t_e302824803190) (replay_sound (ps := []) (t := e302824803190) (by decide)) (by decide)
def e302824803210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e302824803210 : Closed e302824803210 ∧ code e302824803210 = 1402336430986 := by decide
theorem cert_e302824803210 : check e302824803210 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e302824803234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e302824803234 : Closed e302824803234 ∧ code e302824803234 = 1402336431010 := by decide
theorem cert_e302824803234 : check e302824803234 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e302824803246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302824803246 : Closed e302824803246 ∧ code e302824803246 = 1402336431022 := by decide
def e302824803258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302824803258 : Closed e302824803258 ∧ code e302824803258 = 1402336431034 := by decide
def e302824803286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302824803286 : Closed e302824803286 ∧ code e302824803286 = 1402336431062 := by decide
private def t_e302824803286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e302824803286 : ¬ IsSelfInterpreter e302824803286 :=
  wSource (t := t_e302824803286) (replay_sound (ps := []) (t := e302824803286) (by decide)) (by decide)
def e302824803290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302824803290 : Closed e302824803290 ∧ code e302824803290 = 1402336431066 := by decide
def e302824803358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e302824803358 : Closed e302824803358 ∧ code e302824803358 = 1402336431134 := by decide
theorem cert_e302824803358 : check e302824803358 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e302824803554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e302824803554 : Closed e302824803554 ∧ code e302824803554 = 1402336431330 := by decide
theorem cert_e302824803554 : check e302824803554 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e302824803566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302824803566 : Closed e302824803566 ∧ code e302824803566 = 1402336431342 := by decide
def e302824803574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302824803574 : Closed e302824803574 ∧ code e302824803574 = 1402336431350 := by decide
def e302824803854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e302824803854 : Closed e302824803854 ∧ code e302824803854 = 1402336431630 := by decide
theorem cert_e302824803854 : check e302824803854 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e302824803938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e302824803938 : Closed e302824803938 ∧ code e302824803938 = 1402336431714 := by decide
theorem cert_e302824803938 : check e302824803938 [[],[],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e302824803950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302824803950 : Closed e302824803950 ∧ code e302824803950 = 1402336431726 := by decide
def e302824803962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302824803962 : Closed e302824803962 ∧ code e302824803962 = 1402336431738 := by decide
def e302824804150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302824804150 : Closed e302824804150 ∧ code e302824804150 = 1402336431926 := by decide
def e302824804154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302824804154 : Closed e302824804154 ∧ code e302824804154 = 1402336431930 := by decide
def e302825343854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302825343854 : Closed e302825343854 ∧ code e302825343854 = 1402336971630 := by decide
theorem cert_e302825343854 : check e302825343854 [[],[]] .chain = true := by decide
def e302825343862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302825343862 : Closed e302825343862 ∧ code e302825343862 = 1402336971638 := by decide
theorem cert_e302825343862 : check e302825343862 [[],[]] .chain = true := by decide
def e302825343918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302825343918 : Closed e302825343918 ∧ code e302825343918 = 1402336971694 := by decide
theorem cert_e302825343918 : check e302825343918 [[],[]] .chain = true := by decide
def e302825343930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302825343930 : Closed e302825343930 ∧ code e302825343930 = 1402336971706 := by decide
theorem cert_e302825343930 : check e302825343930 [[],[]] .chain = true := by decide
def e302825343958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302825343958 : Closed e302825343958 ∧ code e302825343958 = 1402336971734 := by decide
theorem cert_e302825343958 : check e302825343958 [[],[]] .chain = true := by decide
def e302825343962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302825343962 : Closed e302825343962 ∧ code e302825343962 = 1402336971738 := by decide
theorem cert_e302825343962 : check e302825343962 [[],[]] .chain = true := by decide
def e302825344238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302825344238 : Closed e302825344238 ∧ code e302825344238 = 1402336972014 := by decide
theorem cert_e302825344238 : check e302825344238 [[],[]] .chain = true := by decide
def e302825344246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302825344246 : Closed e302825344246 ∧ code e302825344246 = 1402336972022 := by decide
theorem cert_e302825344246 : check e302825344246 [[],[]] .chain = true := by decide
def e302825344622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302825344622 : Closed e302825344622 ∧ code e302825344622 = 1402336972398 := by decide
theorem cert_e302825344622 : check e302825344622 [[],[]] .chain = true := by decide
def e302825344634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302825344634 : Closed e302825344634 ∧ code e302825344634 = 1402336972410 := by decide
theorem cert_e302825344634 : check e302825344634 [[],[]] .chain = true := by decide
def e302825344822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302825344822 : Closed e302825344822 ∧ code e302825344822 = 1402336972598 := by decide
theorem cert_e302825344822 : check e302825344822 [[],[]] .chain = true := by decide
def e302825344826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302825344826 : Closed e302825344826 ∧ code e302825344826 = 1402336972602 := by decide
theorem cert_e302825344826 : check e302825344826 [[],[]] .chain = true := by decide
def e302887492474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))) (.var 0))))
theorem wire_e302887492474 : Closed e302887492474 ∧ code e302887492474 = 1402399120250 := by decide
def e302887492570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))) (.var 0))))
theorem wire_e302887492570 : Closed e302887492570 ∧ code e302887492570 = 1402399120346 := by decide
def e302887492986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))) (.var 0))))
theorem wire_e302887492986 : Closed e302887492986 ∧ code e302887492986 = 1402399120762 := by decide
theorem cert_e302887492986 : check e302887492986 [[],[],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left]] .chain = true := by decide
def e302887493098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))) (.var 0))))
theorem wire_e302887493098 : Closed e302887493098 ∧ code e302887493098 = 1402399120874 := by decide
def e302887493466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e302887493466 : Closed e302887493466 ∧ code e302887493466 = 1402399121242 := by decide
def e302887493482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e302887493482 : Closed e302887493482 ∧ code e302887493482 = 1402399121258 := by decide
def e302887495546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))) (.var 0))))
theorem wire_e302887495546 : Closed e302887495546 ∧ code e302887495546 = 1402399123322 := by decide
theorem cert_e302887495546 : check e302887495546 [[],[],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e302887495642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))) (.var 0))))
theorem wire_e302887495642 : Closed e302887495642 ∧ code e302887495642 = 1402399123418 := by decide
theorem cert_e302887495642 : check e302887495642 [[],[],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .sourceHead = true := by decide
def e302887498618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))) (.var 0))))
theorem wire_e302887498618 : Closed e302887498618 ∧ code e302887498618 = 1402399126394 := by decide
theorem cert_e302887498618 : check e302887498618 [[],[],[.left],[.left,.left],[.left],[],[]] .chain = true := by decide
def e302887498730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))) (.var 0))))
theorem wire_e302887498730 : Closed e302887498730 ∧ code e302887498730 = 1402399126506 := by decide
theorem cert_e302887498730 : check e302887498730 [[],[],[.left],[.left,.left],[.left],[],[]] .chain = true := by decide
def e302887501018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e302887501018 : Closed e302887501018 ∧ code e302887501018 = 1402399128794 := by decide
def e302887501034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e302887501034 : Closed e302887501034 ∧ code e302887501034 = 1402399128810 := by decide
def e302887560122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))) (.var 0))))
theorem wire_e302887560122 : Closed e302887560122 ∧ code e302887560122 = 1402399187898 := by decide
def e302887560154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))) (.var 0))))
theorem wire_e302887560154 : Closed e302887560154 ∧ code e302887560154 = 1402399187930 := by decide
def e302887562362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))) (.var 0))))
theorem wire_e302887562362 : Closed e302887562362 ∧ code e302887562362 = 1402399190138 := by decide
def e302887562694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 1)))))
theorem wire_e302887562694 : Closed e302887562694 ∧ code e302887562694 = 1402399190470 := by decide
def e302887562810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))) (.var 0))))
theorem wire_e302887562810 : Closed e302887562810 ∧ code e302887562810 = 1402399190586 := by decide
theorem cert_e302887562810 : check e302887562810 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[]] .smaller = true := by decide
def e302887562950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 1)))))
theorem wire_e302887562950 : Closed e302887562950 ∧ code e302887562950 = 1402399190726 := by decide
theorem cert_e302887562950 : check e302887562950 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e302887563706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))) (.var 0))))
theorem wire_e302887563706 : Closed e302887563706 ∧ code e302887563706 = 1402399191482 := by decide
def e302887563754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))) (.var 0))))
theorem wire_e302887563754 : Closed e302887563754 ∧ code e302887563754 = 1402399191530 := by decide
def e302887564410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))) (.var 0))))
theorem wire_e302887564410 : Closed e302887564410 ∧ code e302887564410 = 1402399192186 := by decide
def e302887564742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 1)))))
theorem wire_e302887564742 : Closed e302887564742 ∧ code e302887564742 = 1402399192518 := by decide
def e302887565082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.var 0))))
theorem wire_e302887565082 : Closed e302887565082 ∧ code e302887565082 = 1402399192858 := by decide
private def t_e302887565082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.var 0))))
theorem cert_e302887565082 : ¬ IsSelfInterpreter e302887565082 :=
  wSource (t := t_e302887565082) (replay_sound (ps := []) (t := e302887565082) (by decide)) (by decide)
def e302887565126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 1)))))
theorem wire_e302887565126 : Closed e302887565126 ∧ code e302887565126 = 1402399192902 := by decide
private def t_e302887565126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 1)))))
theorem cert_e302887565126 : ¬ IsSelfInterpreter e302887565126 :=
  wSource (t := t_e302887565126) (replay_sound (ps := []) (t := e302887565126) (by decide)) (by decide)
def e302887565530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))) (.var 0))))
theorem wire_e302887565530 : Closed e302887565530 ∧ code e302887565530 = 1402399193306 := by decide
theorem cert_e302887565530 : check e302887565530 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[]] .chain = true := by decide
def e302887565546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))) (.var 0))))
theorem wire_e302887565546 : Closed e302887565546 ∧ code e302887565546 = 1402399193322 := by decide
theorem cert_e302887565546 : check e302887565546 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .smaller = true := by decide
def e302887565882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))) (.var 0))))
theorem wire_e302887565882 : Closed e302887565882 ∧ code e302887565882 = 1402399193658 := by decide
def e302887566022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 1)))))
theorem wire_e302887566022 : Closed e302887566022 ∧ code e302887566022 = 1402399193798 := by decide
def e302887566106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.var 0))))
theorem wire_e302887566106 : Closed e302887566106 ∧ code e302887566106 = 1402399193882 := by decide
private def t_e302887566106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.var 0))))
theorem cert_e302887566106 : ¬ IsSelfInterpreter e302887566106 :=
  wSource (t := t_e302887566106) (replay_sound (ps := []) (t := e302887566106) (by decide)) (by decide)
def e302887566150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 1)))))
theorem wire_e302887566150 : Closed e302887566150 ∧ code e302887566150 = 1402399193926 := by decide
private def t_e302887566150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 1)))))
theorem cert_e302887566150 : ¬ IsSelfInterpreter e302887566150 :=
  wSource (t := t_e302887566150) (replay_sound (ps := []) (t := e302887566150) (by decide)) (by decide)
def e302887574650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))) (.var 0))))
theorem wire_e302887574650 : Closed e302887574650 ∧ code e302887574650 = 1402399202426 := by decide
def e302887574982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 1)))))
theorem wire_e302887574982 : Closed e302887574982 ∧ code e302887574982 = 1402399202758 := by decide
theorem cert_e302887574982 : check e302887574982 [[],[],[.left],[.left,.left],[.left],[.left],[]] .sourceHead = true := by decide
def e302887575098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))) (.var 0))))
theorem wire_e302887575098 : Closed e302887575098 ∧ code e302887575098 = 1402399202874 := by decide
theorem cert_e302887575098 : check e302887575098 [[],[],[.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[]] .chain = true := by decide
def e302887575238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 1)))))
theorem wire_e302887575238 : Closed e302887575238 ∧ code e302887575238 = 1402399203014 := by decide
theorem cert_e302887575238 : check e302887575238 [[],[],[.left],[.left,.left],[.left],[.left],[]] .sourceHead = true := by decide
def e302887586938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))) (.var 0))))
theorem wire_e302887586938 : Closed e302887586938 ∧ code e302887586938 = 1402399214714 := by decide
theorem cert_e302887586938 : check e302887586938 [[],[],[.left],[.left,.left],[.left],[.left],[],[.left],[],[]] .smaller = true := by decide
def e302887587270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 1)))))
theorem wire_e302887587270 : Closed e302887587270 ∧ code e302887587270 = 1402399215046 := by decide
theorem cert_e302887587270 : check e302887587270 [[],[],[.left],[.left,.left],[.left],[.left],[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e302887587610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))) (.var 0))))
theorem wire_e302887587610 : Closed e302887587610 ∧ code e302887587610 = 1402399215386 := by decide
theorem cert_e302887587610 : check e302887587610 [[],[],[.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[],[]] .chain = true := by decide
def e302887587654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 1)))))
theorem wire_e302887587654 : Closed e302887587654 ∧ code e302887587654 = 1402399215430 := by decide
theorem cert_e302887587654 : check e302887587654 [[],[],[.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[],[]] .three = true := by decide
def e302887593530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))) (.var 0))))
theorem wire_e302887593530 : Closed e302887593530 ∧ code e302887593530 = 1402399221306 := by decide
def e302887593670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 1)))))
theorem wire_e302887593670 : Closed e302887593670 ∧ code e302887593670 = 1402399221446 := by decide
def e302887593754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))) (.var 0))))
theorem wire_e302887593754 : Closed e302887593754 ∧ code e302887593754 = 1402399221530 := by decide
def e302887593798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 1)))))
theorem wire_e302887593798 : Closed e302887593798 ∧ code e302887593798 = 1402399221574 := by decide
def e302888258414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e302888258414 : Closed e302888258414 ∧ code e302888258414 = 1402399886190 := by decide
def e302888258422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e302888258422 : Closed e302888258422 ∧ code e302888258422 = 1402399886198 := by decide
theorem cert_e302888258422 : check e302888258422 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.left],[],[.left],[],[.left],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e302888258478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e302888258478 : Closed e302888258478 ∧ code e302888258478 = 1402399886254 := by decide
theorem cert_e302888258478 : check e302888258478 [[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.left],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302888258490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e302888258490 : Closed e302888258490 ∧ code e302888258490 = 1402399886266 := by decide
end Blc.Floor40
