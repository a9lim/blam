from emitreg import *
from glob import glob
import subprocess
def nums(xs):return '['+','.join(map(str,xs))+']'
def clo(x):return f'⟨{x[0]},{nums(x[1])}⟩'
def state(x):return f'⟨⟨{x[0]},{nums(x[1])}⟩,{x[2]}⟩'
def fr(x):return f'⟨{clo(x[0])},{x[1]}⟩'
def balanced(xs,fn):
    if len(xs)==1:return fn(xs[0])
    j=len(xs)//2
    return f'(if i < {xs[j]} then {balanced(xs[:j],fn)} else {balanced(xs[j:],fn)})'
def partition(xs,depth=1):
    if len(xs)==1:return f'exact FloorIndex.rangeOK_at bl{xs[0]} (by omega) (by omega)'
    j=len(xs)//2
    sp=' '*depth
    return f'by_cases h{xs[j]} : i < {xs[j]}\n{sp}· {partition(xs[:j],depth+2)}\n{sp}· {partition(xs[j:],depth+2)}'
def emitindex(s,r,alt=None):
    name='R'+str(int(s,2));n,kind,j,k,mode,ps,c=r;emit(s,r,alt)
    src=(HERE/(name+'.lean')).read_text()
    mods=[]
    def put(suffix,imports,body):
        mod=name+suffix;txt=''.join('import '+m+'\n' for m in imports)+f'namespace Certgen.{name}\nset_option maxRecDepth 30000\nset_option maxHeartbeats 12000000\n'+body+f'\nend Certgen.{name}\n'
        (HERE/(mod+'.lean')).write_text(txt)
        mods.append(mod);return mod
    look=[];groups=[]
    for key,ty,rs,de in [('V','List AClo',[nums(map(clo,x)) for x in c['values']],'[]'),('K','List Frame',[nums(map(fr,x)) for x in c['konts']],'[]'),('st','AState',list(map(state,c['states'])),'entry'),('hs','List Nat',list(map(nums,c['hints'])),'[]')]:
        starts=list(range(0,len(rs),20));defs=[f'def {key}{x} : Array ({ty}) := #{nums(rs[x:x+20])}' for x in starts]
        for x in range(0,len(defs),12):groups.append(put(key+str(x),['Indexed'],'\n'.join(defs[x:x+12])))
        val=balanced(starts,lambda x:f'({key}{x}[i-{x}]?.getD {de})') if starts else de
        if key=='st':val=f'if i < {n} then {val} else entry'
        look.append(f'def {key} (i : Nat) : {ty} := {val}')
    code=next(x for x in src.splitlines() if x.startswith('def code :'))
    data=put('Data',groups+[x.split()[1] for x in src.splitlines() if x.startswith('import ')],code+'\ndef P (i : Nat) := code[i]?.getD .opaque\n'+'\n'.join(look)+'\ndef validState (i : Nat) := FloorIndex.check P V K st i (hs i)')
    starts=list(range(0,n,12))
    ds=[f'theorem bl{x} : FloorIndex.rangeOK validState {x} {min(12,n-x)} = true := by decide +kernel' for x in starts]
    parts=[put('Blk'+str(x),[data],'\n'.join(ds[x:x+6])) for x in range(0,len(ds),6)]
    body=src[src.index('open Blc Blc.Floor40'):src.index('theorem excluded')]
    body+=f'theorem allValid (i : Nat) (h : i < {n}) : validState i = true := by\n '+partition(starts)+'\n'
    body+=f'''theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < {n}
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
'''
    body+=src[src.index('theorem excluded'):src.rindex('end Certgen.')].replace('regular_no_clock model closed root h hh','noClock h hh')
    put('',['CodeBridge',*parts],body);return mods
def run():
    if not (HERE/'Indexed.olean').exists():subprocess.run([sys.executable,'build.py','Indexed'],check=True)
    for p in sorted(HERE.glob('r[0-9]*.json')):
        name=p.stem[1:]
        if (HERE/('R'+name+'.olean')).exists():continue
        r=json.loads(p.read_text())
        if r[1]=='bottom1':continue
        s=f'{int(name):040b}';m='R'+name
        if r[0]<85:emit(s,r);mods=[m]
        else:mods=emitindex(s,r)
        subprocess.run([sys.executable,'build.py',*[m for m in mods if not (HERE/(m+'.olean')).exists()]],timeout=230,check=True)
if __name__=='__main__':run()
