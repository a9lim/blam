from demand import *
def probe(e,k,src=I):
    return analyze(A(A(e,KI),lc.bitlist(lc.enc(src),V(0))),k,12000)
if __name__=='__main__':
    miss=[]
    for line in (HERE/'open.txt').read_text().split():
        e=lc.decode(line)[0]
        for k in range(3):
            z=probe(e,k)
            if z is not None and (-1,()) not in z[0]:break
        else:
            miss.append(line);continue
        print(line,k,len(z[1]),flush=True)
    print(len(miss),'unresolved')
    (HERE/'projection-rem.txt').write_text('\n'.join(miss))
