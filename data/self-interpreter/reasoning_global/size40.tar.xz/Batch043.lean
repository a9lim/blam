import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302800919778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e302800919778 : Closed e302800919778 ∧ code e302800919778 = 1402312547554 := by decide
theorem cert_e302800919778 : check e302800919778 [[],[]] .chain = true := by decide
def e302800919790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e302800919790 : Closed e302800919790 ∧ code e302800919790 = 1402312547566 := by decide
theorem cert_e302800919790 : check e302800919790 [[],[]] .sourceHead = true := by decide
def e302800919798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e302800919798 : Closed e302800919798 ∧ code e302800919798 = 1402312547574 := by decide
theorem cert_e302800919798 : check e302800919798 [[],[]] .sourceHead = true := by decide
def e302800920814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e302800920814 : Closed e302800920814 ∧ code e302800920814 = 1402312548590 := by decide
theorem cert_e302800920814 : check e302800920814 [[],[]] .chain = true := by decide
def e302800920826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e302800920826 : Closed e302800920826 ∧ code e302800920826 = 1402312548602 := by decide
theorem cert_e302800920826 : check e302800920826 [[],[]] .chain = true := by decide
def e302800921198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e302800921198 : Closed e302800921198 ∧ code e302800921198 = 1402312548974 := by decide
theorem cert_e302800921198 : check e302800921198 [[],[]] .chain = true := by decide
def e302800921210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e302800921210 : Closed e302800921210 ∧ code e302800921210 = 1402312548986 := by decide
theorem cert_e302800921210 : check e302800921210 [[],[]] .chain = true := by decide
def e302800921374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e302800921374 : Closed e302800921374 ∧ code e302800921374 = 1402312549150 := by decide
theorem cert_e302800921374 : check e302800921374 [[],[]] .chain = true := by decide
def e302800921542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e302800921542 : Closed e302800921542 ∧ code e302800921542 = 1402312549318 := by decide
theorem cert_e302800921542 : check e302800921542 [[],[]] .chain = true := by decide
def e302800922158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e302800922158 : Closed e302800922158 ∧ code e302800922158 = 1402312549934 := by decide
theorem cert_e302800922158 : check e302800922158 [[],[]] .chain = true := by decide
def e302800922338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e302800922338 : Closed e302800922338 ∧ code e302800922338 = 1402312550114 := by decide
theorem cert_e302800922338 : check e302800922338 [[],[]] .chain = true := by decide
def e302800922350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e302800922350 : Closed e302800922350 ∧ code e302800922350 = 1402312550126 := by decide
theorem cert_e302800922350 : check e302800922350 [[],[]] .sourceHead = true := by decide
def e302800922506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e302800922506 : Closed e302800922506 ∧ code e302800922506 = 1402312550282 := by decide
theorem cert_e302800922506 : check e302800922506 [[],[]] .chain = true := by decide
def e302800922530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e302800922530 : Closed e302800922530 ∧ code e302800922530 = 1402312550306 := by decide
theorem cert_e302800922530 : check e302800922530 [[],[]] .chain = true := by decide
def e302800922542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e302800922542 : Closed e302800922542 ∧ code e302800922542 = 1402312550318 := by decide
theorem cert_e302800922542 : check e302800922542 [[],[]] .sourceHead = true := by decide
def e302800922554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e302800922554 : Closed e302800922554 ∧ code e302800922554 = 1402312550330 := by decide
theorem cert_e302800922554 : check e302800922554 [[],[]] .sourceHead = true := by decide
def e302800922686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e302800922686 : Closed e302800922686 ∧ code e302800922686 = 1402312550462 := by decide
theorem cert_e302800922686 : check e302800922686 [[],[]] .chain = true := by decide
def e302800923106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e302800923106 : Closed e302800923106 ∧ code e302800923106 = 1402312550882 := by decide
theorem cert_e302800923106 : check e302800923106 [[],[]] .chain = true := by decide
def e302800923118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e302800923118 : Closed e302800923118 ∧ code e302800923118 = 1402312550894 := by decide
theorem cert_e302800923118 : check e302800923118 [[],[]] .sourceHead = true := by decide
def e302800924174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e302800924174 : Closed e302800924174 ∧ code e302800924174 = 1402312551950 := by decide
theorem cert_e302800924174 : check e302800924174 [[],[]] .chain = true := by decide
def e302800924258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e302800924258 : Closed e302800924258 ∧ code e302800924258 = 1402312552034 := by decide
theorem cert_e302800924258 : check e302800924258 [[],[]] .chain = true := by decide
def e302800924270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e302800924270 : Closed e302800924270 ∧ code e302800924270 = 1402312552046 := by decide
theorem cert_e302800924270 : check e302800924270 [[],[]] .sourceHead = true := by decide
def e302800924282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e302800924282 : Closed e302800924282 ∧ code e302800924282 = 1402312552058 := by decide
theorem cert_e302800924282 : check e302800924282 [[],[]] .sourceHead = true := by decide
def e302800924790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e302800924790 : Closed e302800924790 ∧ code e302800924790 = 1402312552566 := by decide
theorem cert_e302800924790 : check e302800924790 [[],[]] .chain = true := by decide
def e302800924794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e302800924794 : Closed e302800924794 ∧ code e302800924794 = 1402312552570 := by decide
theorem cert_e302800924794 : check e302800924794 [[],[]] .chain = true := by decide
def e302800924890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e302800924890 : Closed e302800924890 ∧ code e302800924890 = 1402312552666 := by decide
theorem cert_e302800924890 : check e302800924890 [[],[]] .chain = true := by decide
def e302800924906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e302800924906 : Closed e302800924906 ∧ code e302800924906 = 1402312552682 := by decide
theorem cert_e302800924906 : check e302800924906 [[],[]] .chain = true := by decide
def e302800924982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e302800924982 : Closed e302800924982 ∧ code e302800924982 = 1402312552758 := by decide
theorem cert_e302800924982 : check e302800924982 [[],[]] .chain = true := by decide
def e302800924986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e302800924986 : Closed e302800924986 ∧ code e302800924986 = 1402312552762 := by decide
theorem cert_e302800924986 : check e302800924986 [[],[]] .chain = true := by decide
def e302800925070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e302800925070 : Closed e302800925070 ∧ code e302800925070 = 1402312552846 := by decide
theorem cert_e302800925070 : check e302800925070 [[],[]] .chain = true := by decide
def e302800925082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e302800925082 : Closed e302800925082 ∧ code e302800925082 = 1402312552858 := by decide
theorem cert_e302800925082 : check e302800925082 [[],[]] .chain = true := by decide
def e302800925126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e302800925126 : Closed e302800925126 ∧ code e302800925126 = 1402312552902 := by decide
theorem cert_e302800925126 : check e302800925126 [[],[]] .chain = true := by decide
def e302800925462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e302800925462 : Closed e302800925462 ∧ code e302800925462 = 1402312553238 := by decide
theorem cert_e302800925462 : check e302800925462 [[],[]] .chain = true := by decide
def e302800925466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302800925466 : Closed e302800925466 ∧ code e302800925466 = 1402312553242 := by decide
theorem cert_e302800925466 : check e302800925466 [[],[]] .chain = true := by decide
def e302800925510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302800925510 : Closed e302800925510 ∧ code e302800925510 = 1402312553286 := by decide
theorem cert_e302800925510 : check e302800925510 [[],[]] .chain = true := by decide
def e302800925538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e302800925538 : Closed e302800925538 ∧ code e302800925538 = 1402312553314 := by decide
theorem cert_e302800925538 : check e302800925538 [[],[]] .chain = true := by decide
def e302800925550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e302800925550 : Closed e302800925550 ∧ code e302800925550 = 1402312553326 := by decide
theorem cert_e302800925550 : check e302800925550 [[],[]] .sourceHead = true := by decide
def e302800925558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e302800925558 : Closed e302800925558 ∧ code e302800925558 = 1402312553334 := by decide
theorem cert_e302800925558 : check e302800925558 [[],[]] .sourceHead = true := by decide
def e302800925578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e302800925578 : Closed e302800925578 ∧ code e302800925578 = 1402312553354 := by decide
theorem cert_e302800925578 : check e302800925578 [[],[]] .chain = true := by decide
def e302800925602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e302800925602 : Closed e302800925602 ∧ code e302800925602 = 1402312553378 := by decide
theorem cert_e302800925602 : check e302800925602 [[],[]] .chain = true := by decide
def e302800925614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e302800925614 : Closed e302800925614 ∧ code e302800925614 = 1402312553390 := by decide
theorem cert_e302800925614 : check e302800925614 [[],[]] .sourceHead = true := by decide
def e302800925626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e302800925626 : Closed e302800925626 ∧ code e302800925626 = 1402312553402 := by decide
theorem cert_e302800925626 : check e302800925626 [[],[]] .sourceHead = true := by decide
def e302800925654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e302800925654 : Closed e302800925654 ∧ code e302800925654 = 1402312553430 := by decide
theorem cert_e302800925654 : check e302800925654 [[],[]] .sourceHead = true := by decide
def e302800925658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e302800925658 : Closed e302800925658 ∧ code e302800925658 = 1402312553434 := by decide
theorem cert_e302800925658 : check e302800925658 [[],[]] .sourceHead = true := by decide
def e302800925726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e302800925726 : Closed e302800925726 ∧ code e302800925726 = 1402312553502 := by decide
theorem cert_e302800925726 : check e302800925726 [[],[]] .chain = true := by decide
def e302800925750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e302800925750 : Closed e302800925750 ∧ code e302800925750 = 1402312553526 := by decide
theorem cert_e302800925750 : check e302800925750 [[],[]] .chain = true := by decide
def e302800925754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e302800925754 : Closed e302800925754 ∧ code e302800925754 = 1402312553530 := by decide
theorem cert_e302800925754 : check e302800925754 [[],[]] .chain = true := by decide
def e302800925894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302800925894 : Closed e302800925894 ∧ code e302800925894 = 1402312553670 := by decide
theorem cert_e302800925894 : check e302800925894 [[],[]] .chain = true := by decide
def e302800925922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e302800925922 : Closed e302800925922 ∧ code e302800925922 = 1402312553698 := by decide
theorem cert_e302800925922 : check e302800925922 [[],[]] .chain = true := by decide
def e302800925934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e302800925934 : Closed e302800925934 ∧ code e302800925934 = 1402312553710 := by decide
theorem cert_e302800925934 : check e302800925934 [[],[]] .sourceHead = true := by decide
def e302800925942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e302800925942 : Closed e302800925942 ∧ code e302800925942 = 1402312553718 := by decide
theorem cert_e302800925942 : check e302800925942 [[],[]] .sourceHead = true := by decide
def e302800926222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e302800926222 : Closed e302800926222 ∧ code e302800926222 = 1402312553998 := by decide
theorem cert_e302800926222 : check e302800926222 [[],[]] .chain = true := by decide
def e302800926306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e302800926306 : Closed e302800926306 ∧ code e302800926306 = 1402312554082 := by decide
theorem cert_e302800926306 : check e302800926306 [[],[]] .chain = true := by decide
def e302800926318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e302800926318 : Closed e302800926318 ∧ code e302800926318 = 1402312554094 := by decide
theorem cert_e302800926318 : check e302800926318 [[],[]] .sourceHead = true := by decide
def e302800926330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e302800926330 : Closed e302800926330 ∧ code e302800926330 = 1402312554106 := by decide
theorem cert_e302800926330 : check e302800926330 [[],[]] .sourceHead = true := by decide
def e302800926518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e302800926518 : Closed e302800926518 ∧ code e302800926518 = 1402312554294 := by decide
theorem cert_e302800926518 : check e302800926518 [[],[]] .sourceHead = true := by decide
def e302800926522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e302800926522 : Closed e302800926522 ∧ code e302800926522 = 1402312554298 := by decide
theorem cert_e302800926522 : check e302800926522 [[],[]] .sourceHead = true := by decide
def e302800929718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.var 1))))))
theorem wire_e302800929718 : Closed e302800929718 ∧ code e302800929718 = 1402312557494 := by decide
theorem cert_e302800929718 : check e302800929718 [[],[]] .chain = true := by decide
def e302800929750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e302800929750 : Closed e302800929750 ∧ code e302800929750 = 1402312557526 := by decide
theorem cert_e302800929750 : check e302800929750 [[],[]] .chain = true := by decide
def e302800929754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e302800929754 : Closed e302800929754 ∧ code e302800929754 = 1402312557530 := by decide
theorem cert_e302800929754 : check e302800929754 [[],[]] .chain = true := by decide
def e302800930518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e302800930518 : Closed e302800930518 ∧ code e302800930518 = 1402312558294 := by decide
theorem cert_e302800930518 : check e302800930518 [[],[]] .chain = true := by decide
def e302800930522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e302800930522 : Closed e302800930522 ∧ code e302800930522 = 1402312558298 := by decide
theorem cert_e302800930522 : check e302800930522 [[],[]] .chain = true := by decide
def e302800930538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e302800930538 : Closed e302800930538 ∧ code e302800930538 = 1402312558314 := by decide
theorem cert_e302800930538 : check e302800930538 [[],[]] .chain = true := by decide
def e302800930646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e302800930646 : Closed e302800930646 ∧ code e302800930646 = 1402312558422 := by decide
theorem cert_e302800930646 : check e302800930646 [[],[]] .chain = true := by decide
def e302800930650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e302800930650 : Closed e302800930650 ∧ code e302800930650 = 1402312558426 := by decide
theorem cert_e302800930650 : check e302800930650 [[],[]] .chain = true := by decide
def e302800930730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e302800930730 : Closed e302800930730 ∧ code e302800930730 = 1402312558506 := by decide
theorem cert_e302800930730 : check e302800930730 [[],[]] .chain = true := by decide
def e302800931254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e302800931254 : Closed e302800931254 ∧ code e302800931254 = 1402312559030 := by decide
theorem cert_e302800931254 : check e302800931254 [[],[]] .chain = true := by decide
def e302800931286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e302800931286 : Closed e302800931286 ∧ code e302800931286 = 1402312559062 := by decide
theorem cert_e302800931286 : check e302800931286 [[],[]] .chain = true := by decide
def e302800931290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e302800931290 : Closed e302800931290 ∧ code e302800931290 = 1402312559066 := by decide
theorem cert_e302800931290 : check e302800931290 [[],[]] .chain = true := by decide
def e302800931446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e302800931446 : Closed e302800931446 ∧ code e302800931446 = 1402312559222 := by decide
theorem cert_e302800931446 : check e302800931446 [[],[]] .chain = true := by decide
def e302800931638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e302800931638 : Closed e302800931638 ∧ code e302800931638 = 1402312559414 := by decide
theorem cert_e302800931638 : check e302800931638 [[],[]] .chain = true := by decide
def e302800931642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e302800931642 : Closed e302800931642 ∧ code e302800931642 = 1402312559418 := by decide
theorem cert_e302800931642 : check e302800931642 [[],[]] .chain = true := by decide
def e302800931958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.var 1))))))
theorem wire_e302800931958 : Closed e302800931958 ∧ code e302800931958 = 1402312559734 := by decide
theorem cert_e302800931958 : check e302800931958 [[],[]] .chain = true := by decide
def e302800932054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e302800932054 : Closed e302800932054 ∧ code e302800932054 = 1402312559830 := by decide
theorem cert_e302800932054 : check e302800932054 [[],[]] .chain = true := by decide
def e302800932058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e302800932058 : Closed e302800932058 ∧ code e302800932058 = 1402312559834 := by decide
theorem cert_e302800932058 : check e302800932058 [[],[]] .chain = true := by decide
def e302800932074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e302800932074 : Closed e302800932074 ∧ code e302800932074 = 1402312559850 := by decide
theorem cert_e302800932074 : check e302800932074 [[],[]] .chain = true := by decide
def e302800932150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e302800932150 : Closed e302800932150 ∧ code e302800932150 = 1402312559926 := by decide
theorem cert_e302800932150 : check e302800932150 [[],[]] .chain = true := by decide
def e302800932154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e302800932154 : Closed e302800932154 ∧ code e302800932154 = 1402312559930 := by decide
theorem cert_e302800932154 : check e302800932154 [[],[]] .chain = true := by decide
def e302800932238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e302800932238 : Closed e302800932238 ∧ code e302800932238 = 1402312560014 := by decide
theorem cert_e302800932238 : check e302800932238 [[],[]] .chain = true := by decide
def e302800932250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e302800932250 : Closed e302800932250 ∧ code e302800932250 = 1402312560026 := by decide
theorem cert_e302800932250 : check e302800932250 [[],[]] .chain = true := by decide
def e302800932406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.var 1))))))
theorem wire_e302800932406 : Closed e302800932406 ∧ code e302800932406 = 1402312560182 := by decide
theorem cert_e302800932406 : check e302800932406 [[],[]] .chain = true := by decide
def e302800932410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 2))) (.var 0))))))
theorem wire_e302800932410 : Closed e302800932410 ∧ code e302800932410 = 1402312560186 := by decide
theorem cert_e302800932410 : check e302800932410 [[],[]] .chain = true := by decide
def e302800932458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e302800932458 : Closed e302800932458 ∧ code e302800932458 = 1402312560234 := by decide
theorem cert_e302800932458 : check e302800932458 [[],[]] .chain = true := by decide
def e302800932494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e302800932494 : Closed e302800932494 ∧ code e302800932494 = 1402312560270 := by decide
theorem cert_e302800932494 : check e302800932494 [[],[]] .chain = true := by decide
def e302800932506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e302800932506 : Closed e302800932506 ∧ code e302800932506 = 1402312560282 := by decide
theorem cert_e302800932506 : check e302800932506 [[],[]] .chain = true := by decide
def e302800932550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e302800932550 : Closed e302800932550 ∧ code e302800932550 = 1402312560326 := by decide
theorem cert_e302800932550 : check e302800932550 [[],[]] .chain = true := by decide
def e302800935094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e302800935094 : Closed e302800935094 ∧ code e302800935094 = 1402312562870 := by decide
theorem cert_e302800935094 : check e302800935094 [[],[]] .chain = true := by decide
def e302800935126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e302800935126 : Closed e302800935126 ∧ code e302800935126 = 1402312562902 := by decide
theorem cert_e302800935126 : check e302800935126 [[],[]] .chain = true := by decide
def e302800935130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e302800935130 : Closed e302800935130 ∧ code e302800935130 = 1402312562906 := by decide
theorem cert_e302800935130 : check e302800935130 [[],[]] .chain = true := by decide
def e302800935146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e302800935146 : Closed e302800935146 ∧ code e302800935146 = 1402312562922 := by decide
theorem cert_e302800935146 : check e302800935146 [[],[]] .chain = true := by decide
def e302800935478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 1))) (.var 1))))))
theorem wire_e302800935478 : Closed e302800935478 ∧ code e302800935478 = 1402312563254 := by decide
theorem cert_e302800935478 : check e302800935478 [[],[]] .chain = true := by decide
def e302800935482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.var 0))))))
theorem wire_e302800935482 : Closed e302800935482 ∧ code e302800935482 = 1402312563258 := by decide
theorem cert_e302800935482 : check e302800935482 [[],[]] .chain = true := by decide
def e302800935566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e302800935566 : Closed e302800935566 ∧ code e302800935566 = 1402312563342 := by decide
theorem cert_e302800935566 : check e302800935566 [[],[]] .chain = true := by decide
def e302800935622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e302800935622 : Closed e302800935622 ∧ code e302800935622 = 1402312563398 := by decide
theorem cert_e302800935622 : check e302800935622 [[],[]] .chain = true := by decide
def e302800935702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 1))))))
theorem wire_e302800935702 : Closed e302800935702 ∧ code e302800935702 = 1402312563478 := by decide
theorem cert_e302800935702 : check e302800935702 [[],[]] .chain = true := by decide
def e302800935706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.var 0))))))
theorem wire_e302800935706 : Closed e302800935706 ∧ code e302800935706 = 1402312563482 := by decide
theorem cert_e302800935706 : check e302800935706 [[],[]] .chain = true := by decide
def e302800935750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302800935750 : Closed e302800935750 ∧ code e302800935750 = 1402312563526 := by decide
theorem cert_e302800935750 : check e302800935750 [[],[]] .chain = true := by decide
def e302800935778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e302800935778 : Closed e302800935778 ∧ code e302800935778 = 1402312563554 := by decide
theorem cert_e302800935778 : check e302800935778 [[],[]] .chain = true := by decide
def e302800935790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e302800935790 : Closed e302800935790 ∧ code e302800935790 = 1402312563566 := by decide
theorem cert_e302800935790 : check e302800935790 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e302800935798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e302800935798 : Closed e302800935798 ∧ code e302800935798 = 1402312563574 := by decide
theorem cert_e302800935798 : check e302800935798 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e302800935862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e302800935862 : Closed e302800935862 ∧ code e302800935862 = 1402312563638 := by decide
theorem cert_e302800935862 : check e302800935862 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e302800936022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e302800936022 : Closed e302800936022 ∧ code e302800936022 = 1402312563798 := by decide
theorem cert_e302800936022 : check e302800936022 [[],[]] .chain = true := by decide
def e302800936026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e302800936026 : Closed e302800936026 ∧ code e302800936026 = 1402312563802 := by decide
theorem cert_e302800936026 : check e302800936026 [[],[]] .chain = true := by decide
def e302800936042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e302800936042 : Closed e302800936042 ∧ code e302800936042 = 1402312563818 := by decide
theorem cert_e302800936042 : check e302800936042 [[],[]] .chain = true := by decide
def e302800936214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e302800936214 : Closed e302800936214 ∧ code e302800936214 = 1402312563990 := by decide
theorem cert_e302800936214 : check e302800936214 [[],[]] .chain = true := by decide
def e302800936218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.var 0))))))
theorem wire_e302800936218 : Closed e302800936218 ∧ code e302800936218 = 1402312563994 := by decide
theorem cert_e302800936218 : check e302800936218 [[],[]] .chain = true := by decide
def e302800936262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302800936262 : Closed e302800936262 ∧ code e302800936262 = 1402312564038 := by decide
theorem cert_e302800936262 : check e302800936262 [[],[]] .chain = true := by decide
def e302800936290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e302800936290 : Closed e302800936290 ∧ code e302800936290 = 1402312564066 := by decide
theorem cert_e302800936290 : check e302800936290 [[],[]] .chain = true := by decide
def e302800936302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e302800936302 : Closed e302800936302 ∧ code e302800936302 = 1402312564078 := by decide
theorem cert_e302800936302 : check e302800936302 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e302800936310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e302800936310 : Closed e302800936310 ∧ code e302800936310 = 1402312564086 := by decide
theorem cert_e302800936310 : check e302800936310 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302800936330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e302800936330 : Closed e302800936330 ∧ code e302800936330 = 1402312564106 := by decide
theorem cert_e302800936330 : check e302800936330 [[],[]] .chain = true := by decide
def e302800936354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e302800936354 : Closed e302800936354 ∧ code e302800936354 = 1402312564130 := by decide
theorem cert_e302800936354 : check e302800936354 [[],[]] .chain = true := by decide
def e302800936366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e302800936366 : Closed e302800936366 ∧ code e302800936366 = 1402312564142 := by decide
theorem cert_e302800936366 : check e302800936366 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e302800936378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e302800936378 : Closed e302800936378 ∧ code e302800936378 = 1402312564154 := by decide
theorem cert_e302800936378 : check e302800936378 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302800936406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e302800936406 : Closed e302800936406 ∧ code e302800936406 = 1402312564182 := by decide
theorem cert_e302800936406 : check e302800936406 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302800936410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e302800936410 : Closed e302800936410 ∧ code e302800936410 = 1402312564186 := by decide
theorem cert_e302800936410 : check e302800936410 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302800936630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e302800936630 : Closed e302800936630 ∧ code e302800936630 = 1402312564406 := by decide
theorem cert_e302800936630 : check e302800936630 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e302800936662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e302800936662 : Closed e302800936662 ∧ code e302800936662 = 1402312564438 := by decide
theorem cert_e302800936662 : check e302800936662 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e302800936666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e302800936666 : Closed e302800936666 ∧ code e302800936666 = 1402312564442 := by decide
theorem cert_e302800936666 : check e302800936666 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e302800937206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.var 1))))))
theorem wire_e302800937206 : Closed e302800937206 ∧ code e302800937206 = 1402312564982 := by decide
theorem cert_e302800937206 : check e302800937206 [[],[]] .chain = true := by decide
def e302800937398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e302800937398 : Closed e302800937398 ∧ code e302800937398 = 1402312565174 := by decide
theorem cert_e302800937398 : check e302800937398 [[],[]] .chain = true := by decide
def e302800937402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e302800937402 : Closed e302800937402 ∧ code e302800937402 = 1402312565178 := by decide
theorem cert_e302800937402 : check e302800937402 [[],[]] .chain = true := by decide
def e302800937430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e302800937430 : Closed e302800937430 ∧ code e302800937430 = 1402312565206 := by decide
theorem cert_e302800937430 : check e302800937430 [[],[]] .chain = true := by decide
def e302800937450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e302800937450 : Closed e302800937450 ∧ code e302800937450 = 1402312565226 := by decide
theorem cert_e302800937450 : check e302800937450 [[],[]] .chain = true := by decide
def e302800937590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e302800937590 : Closed e302800937590 ∧ code e302800937590 = 1402312565366 := by decide
theorem cert_e302800937590 : check e302800937590 [[],[]] .chain = true := by decide
def e302800937782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e302800937782 : Closed e302800937782 ∧ code e302800937782 = 1402312565558 := by decide
theorem cert_e302800937782 : check e302800937782 [[],[]] .chain = true := by decide
def e302800937786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e302800937786 : Closed e302800937786 ∧ code e302800937786 = 1402312565562 := by decide
theorem cert_e302800937786 : check e302800937786 [[],[]] .chain = true := by decide
def e302800937870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 2)))))))
theorem wire_e302800937870 : Closed e302800937870 ∧ code e302800937870 = 1402312565646 := by decide
theorem cert_e302800937870 : check e302800937870 [[],[]] .chain = true := by decide
def e302800937882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e302800937882 : Closed e302800937882 ∧ code e302800937882 = 1402312565658 := by decide
theorem cert_e302800937882 : check e302800937882 [[],[]] .chain = true := by decide
def e302800938550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e302800938550 : Closed e302800938550 ∧ code e302800938550 = 1402312566326 := by decide
theorem cert_e302800938550 : check e302800938550 [[],[]] .chain = true := by decide
def e302800938554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e302800938554 : Closed e302800938554 ∧ code e302800938554 = 1402312566330 := by decide
theorem cert_e302800938554 : check e302800938554 [[],[]] .chain = true := by decide
def e302800938638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e302800938638 : Closed e302800938638 ∧ code e302800938638 = 1402312566414 := by decide
theorem cert_e302800938638 : check e302800938638 [[],[]] .chain = true := by decide
def e302800938694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e302800938694 : Closed e302800938694 ∧ code e302800938694 = 1402312566470 := by decide
theorem cert_e302800938694 : check e302800938694 [[],[]] .chain = true := by decide
def e302800938774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 1))))))
theorem wire_e302800938774 : Closed e302800938774 ∧ code e302800938774 = 1402312566550 := by decide
theorem cert_e302800938774 : check e302800938774 [[],[]] .chain = true := by decide
def e302800938778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302800938778 : Closed e302800938778 ∧ code e302800938778 = 1402312566554 := by decide
theorem cert_e302800938778 : check e302800938778 [[],[]] .chain = true := by decide
def e302800938822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302800938822 : Closed e302800938822 ∧ code e302800938822 = 1402312566598 := by decide
theorem cert_e302800938822 : check e302800938822 [[],[]] .chain = true := by decide
def e302800938850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.lam (.var 0)))))))
theorem wire_e302800938850 : Closed e302800938850 ∧ code e302800938850 = 1402312566626 := by decide
theorem cert_e302800938850 : check e302800938850 [[],[]] .chain = true := by decide
def e302800938862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e302800938862 : Closed e302800938862 ∧ code e302800938862 = 1402312566638 := by decide
theorem cert_e302800938862 : check e302800938862 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e302800938870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e302800938870 : Closed e302800938870 ∧ code e302800938870 = 1402312566646 := by decide
theorem cert_e302800938870 : check e302800938870 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302800938934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e302800938934 : Closed e302800938934 ∧ code e302800938934 = 1402312566710 := by decide
theorem cert_e302800938934 : check e302800938934 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302800939118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e302800939118 : Closed e302800939118 ∧ code e302800939118 = 1402312566894 := by decide
theorem cert_e302800939118 : check e302800939118 [[],[]] .chain = true := by decide
def e302800939130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e302800939130 : Closed e302800939130 ∧ code e302800939130 = 1402312566906 := by decide
theorem cert_e302800939130 : check e302800939130 [[],[]] .chain = true := by decide
def e302800939406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e302800939406 : Closed e302800939406 ∧ code e302800939406 = 1402312567182 := by decide
theorem cert_e302800939406 : check e302800939406 [[],[]] .chain = true := by decide
def e302800939462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e302800939462 : Closed e302800939462 ∧ code e302800939462 = 1402312567238 := by decide
theorem cert_e302800939462 : check e302800939462 [[],[]] .chain = true := by decide
def e302800940062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 3))))))))
theorem wire_e302800940062 : Closed e302800940062 ∧ code e302800940062 = 1402312567838 := by decide
theorem cert_e302800940062 : check e302800940062 [[],[]] .chain = true := by decide
def e302800940086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e302800940086 : Closed e302800940086 ∧ code e302800940086 = 1402312567862 := by decide
theorem cert_e302800940086 : check e302800940086 [[],[]] .chain = true := by decide
def e302800940090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e302800940090 : Closed e302800940090 ∧ code e302800940090 = 1402312567866 := by decide
theorem cert_e302800940090 : check e302800940090 [[],[]] .chain = true := by decide
def e302800940230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302800940230 : Closed e302800940230 ∧ code e302800940230 = 1402312568006 := by decide
theorem cert_e302800940230 : check e302800940230 [[],[]] .chain = true := by decide
def e302800940258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e302800940258 : Closed e302800940258 ∧ code e302800940258 = 1402312568034 := by decide
theorem cert_e302800940258 : check e302800940258 [[],[]] .chain = true := by decide
def e302800940270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e302800940270 : Closed e302800940270 ∧ code e302800940270 = 1402312568046 := by decide
theorem cert_e302800940270 : check e302800940270 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e302800940278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e302800940278 : Closed e302800940278 ∧ code e302800940278 = 1402312568054 := by decide
theorem cert_e302800940278 : check e302800940278 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e302800940662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e302800940662 : Closed e302800940662 ∧ code e302800940662 = 1402312568438 := by decide
theorem cert_e302800940662 : check e302800940662 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302800941174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e302800941174 : Closed e302800941174 ∧ code e302800941174 = 1402312568950 := by decide
theorem cert_e302800941174 : check e302800941174 [[],[]] .chain = true := by decide
def e302800941178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e302800941178 : Closed e302800941178 ∧ code e302800941178 = 1402312568954 := by decide
theorem cert_e302800941178 : check e302800941178 [[],[]] .chain = true := by decide
def e302800941274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e302800941274 : Closed e302800941274 ∧ code e302800941274 = 1402312569050 := by decide
theorem cert_e302800941274 : check e302800941274 [[],[]] .chain = true := by decide
def e302800941290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e302800941290 : Closed e302800941290 ∧ code e302800941290 = 1402312569066 := by decide
theorem cert_e302800941290 : check e302800941290 [[],[]] .chain = true := by decide
def e302800941366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e302800941366 : Closed e302800941366 ∧ code e302800941366 = 1402312569142 := by decide
theorem cert_e302800941366 : check e302800941366 [[],[]] .chain = true := by decide
def e302800941370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e302800941370 : Closed e302800941370 ∧ code e302800941370 = 1402312569146 := by decide
theorem cert_e302800941370 : check e302800941370 [[],[]] .chain = true := by decide
def e302800941454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e302800941454 : Closed e302800941454 ∧ code e302800941454 = 1402312569230 := by decide
theorem cert_e302800941454 : check e302800941454 [[],[]] .chain = true := by decide
def e302800941466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e302800941466 : Closed e302800941466 ∧ code e302800941466 = 1402312569242 := by decide
theorem cert_e302800941466 : check e302800941466 [[],[]] .chain = true := by decide
end Blc.Floor40
