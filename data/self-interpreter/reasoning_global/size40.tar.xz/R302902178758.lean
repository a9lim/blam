import CodeBridge
import R302902178758Blk0
import R302902178758Blk6
namespace Certgen.R302902178758
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit174 : Term := .var 0
def lit146 : Term := .var 1
def lit109 : Term := .var 2
def lit138 : Term := .lam lit174
def lit145 : Term := .lam lit146
def lit137 : Term := .lam lit138
def lit147 : Term := .var 4
def lit172 : Term := .app lit174 lit174
def lit144 : Term := .lam lit145
def lit171 : Term := .lam lit172
def lit135 : Term := .app lit174 lit137
def lit108 : Term := .app lit109 lit145
def lit142 : Term := .app lit174 lit144
def lit106 : Term := .app lit146 lit108
def lit105 : Term := .lam lit106
def lit166 : Term := .app lit171 lit171
def lit141 : Term := .app lit142 lit147
def lit104 : Term := .lam lit105
def lit140 : Term := .lam lit141
def lit102 : Term := .app lit174 lit104
def lit100 : Term := .app lit174 lit102
def lit99 : Term := .lam lit100
def lit134 : Term := .app lit135 lit140
def lit133 : Term := .lam lit134
def lit98 : Term := .app lit99 lit145
def lit96 : Term := .app lit146 lit98
def lit95 : Term := .lam lit96
def lit94 : Term := .lam lit95
def lit127 : Term := .app lit142 lit133
def lit126 : Term := .lam lit127
def lit120 : Term := .app lit142 lit126
def lit119 : Term := .lam lit120
def lit80 : Term := .app lit99 lit94
def lit79 : Term := .app lit80 lit145
def lit77 : Term := .app lit146 lit79
def lit76 : Term := .lam lit77
def lit75 : Term := .lam lit76
def lit40 : Term := .app lit80 lit75
def lit5 : Term := .app lit80 lit40
def lit4 : Term := .app lit5 lit137
def lit3 : Term := .app lit4 lit119
def lit2 : Term := .app lit3 lit166
def lit1 : Term := .app lit2 lit166
def lit0 : Term := .app lit1 lit166
def filling : Nat → Term := fun p => if p = 147 then Term.var 4 else Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub174 : model.term 174 = lit174 := model.var_eq 174 0 (by rfl)
theorem sub173 : model.term 173 = lit174 := model.var_eq 173 0 (by rfl)
theorem sub172 : model.term 172 = lit172 := by rw [model.app_eq 172 173 174 (by rfl), sub173, sub174]; rfl
theorem sub171 : model.term 171 = lit171 := by rw [model.lam_eq 171 172 (by rfl), sub172]; rfl
theorem sub170 : model.term 170 = lit174 := model.var_eq 170 0 (by rfl)
theorem sub169 : model.term 169 = lit174 := model.var_eq 169 0 (by rfl)
theorem sub168 : model.term 168 = lit172 := by rw [model.app_eq 168 169 170 (by rfl), sub169, sub170]; rfl
theorem sub167 : model.term 167 = lit171 := by rw [model.lam_eq 167 168 (by rfl), sub168]; rfl
theorem sub166 : model.term 166 = lit166 := by rw [model.app_eq 166 167 171 (by rfl), sub167, sub171]; rfl
theorem sub165 : model.term 165 = lit174 := model.var_eq 165 0 (by rfl)
theorem sub164 : model.term 164 = lit174 := model.var_eq 164 0 (by rfl)
theorem sub163 : model.term 163 = lit172 := by rw [model.app_eq 163 164 165 (by rfl), sub164, sub165]; rfl
theorem sub162 : model.term 162 = lit171 := by rw [model.lam_eq 162 163 (by rfl), sub163]; rfl
theorem sub161 : model.term 161 = lit174 := model.var_eq 161 0 (by rfl)
theorem sub160 : model.term 160 = lit174 := model.var_eq 160 0 (by rfl)
theorem sub159 : model.term 159 = lit172 := by rw [model.app_eq 159 160 161 (by rfl), sub160, sub161]; rfl
theorem sub158 : model.term 158 = lit171 := by rw [model.lam_eq 158 159 (by rfl), sub159]; rfl
theorem sub157 : model.term 157 = lit166 := by rw [model.app_eq 157 158 162 (by rfl), sub158, sub162]; rfl
theorem sub156 : model.term 156 = lit174 := model.var_eq 156 0 (by rfl)
theorem sub155 : model.term 155 = lit174 := model.var_eq 155 0 (by rfl)
theorem sub154 : model.term 154 = lit172 := by rw [model.app_eq 154 155 156 (by rfl), sub155, sub156]; rfl
theorem sub153 : model.term 153 = lit171 := by rw [model.lam_eq 153 154 (by rfl), sub154]; rfl
theorem sub152 : model.term 152 = lit174 := model.var_eq 152 0 (by rfl)
theorem sub151 : model.term 151 = lit174 := model.var_eq 151 0 (by rfl)
theorem sub150 : model.term 150 = lit172 := by rw [model.app_eq 150 151 152 (by rfl), sub151, sub152]; rfl
theorem sub149 : model.term 149 = lit171 := by rw [model.lam_eq 149 150 (by rfl), sub150]; rfl
theorem sub148 : model.term 148 = lit166 := by rw [model.app_eq 148 149 153 (by rfl), sub149, sub153]; rfl
theorem sub147 : model.term 147 = lit147 := (opaqueTerm (rankedCode code ordered_code) filling (p := 147) (by rfl)).trans (by rfl)
theorem sub146 : model.term 146 = lit146 := model.var_eq 146 1 (by rfl)
theorem sub145 : model.term 145 = lit145 := by rw [model.lam_eq 145 146 (by rfl), sub146]; rfl
theorem sub144 : model.term 144 = lit144 := by rw [model.lam_eq 144 145 (by rfl), sub145]; rfl
theorem sub143 : model.term 143 = lit174 := model.var_eq 143 0 (by rfl)
theorem sub142 : model.term 142 = lit142 := by rw [model.app_eq 142 143 144 (by rfl), sub143, sub144]; rfl
theorem sub141 : model.term 141 = lit141 := by rw [model.app_eq 141 142 147 (by rfl), sub142, sub147]; rfl
theorem sub140 : model.term 140 = lit140 := by rw [model.lam_eq 140 141 (by rfl), sub141]; rfl
theorem sub139 : model.term 139 = lit174 := model.var_eq 139 0 (by rfl)
theorem sub138 : model.term 138 = lit138 := by rw [model.lam_eq 138 139 (by rfl), sub139]; rfl
theorem sub137 : model.term 137 = lit137 := by rw [model.lam_eq 137 138 (by rfl), sub138]; rfl
theorem sub136 : model.term 136 = lit174 := model.var_eq 136 0 (by rfl)
theorem sub135 : model.term 135 = lit135 := by rw [model.app_eq 135 136 137 (by rfl), sub136, sub137]; rfl
theorem sub134 : model.term 134 = lit134 := by rw [model.app_eq 134 135 140 (by rfl), sub135, sub140]; rfl
theorem sub133 : model.term 133 = lit133 := by rw [model.lam_eq 133 134 (by rfl), sub134]; rfl
theorem sub132 : model.term 132 = lit146 := model.var_eq 132 1 (by rfl)
theorem sub131 : model.term 131 = lit145 := by rw [model.lam_eq 131 132 (by rfl), sub132]; rfl
theorem sub130 : model.term 130 = lit144 := by rw [model.lam_eq 130 131 (by rfl), sub131]; rfl
theorem sub129 : model.term 129 = lit174 := model.var_eq 129 0 (by rfl)
theorem sub128 : model.term 128 = lit142 := by rw [model.app_eq 128 129 130 (by rfl), sub129, sub130]; rfl
theorem sub127 : model.term 127 = lit127 := by rw [model.app_eq 127 128 133 (by rfl), sub128, sub133]; rfl
theorem sub126 : model.term 126 = lit126 := by rw [model.lam_eq 126 127 (by rfl), sub127]; rfl
theorem sub125 : model.term 125 = lit146 := model.var_eq 125 1 (by rfl)
theorem sub124 : model.term 124 = lit145 := by rw [model.lam_eq 124 125 (by rfl), sub125]; rfl
theorem sub123 : model.term 123 = lit144 := by rw [model.lam_eq 123 124 (by rfl), sub124]; rfl
theorem sub122 : model.term 122 = lit174 := model.var_eq 122 0 (by rfl)
theorem sub121 : model.term 121 = lit142 := by rw [model.app_eq 121 122 123 (by rfl), sub122, sub123]; rfl
theorem sub120 : model.term 120 = lit120 := by rw [model.app_eq 120 121 126 (by rfl), sub121, sub126]; rfl
theorem sub119 : model.term 119 = lit119 := by rw [model.lam_eq 119 120 (by rfl), sub120]; rfl
theorem sub118 : model.term 118 = lit174 := model.var_eq 118 0 (by rfl)
theorem sub117 : model.term 117 = lit138 := by rw [model.lam_eq 117 118 (by rfl), sub118]; rfl
theorem sub116 : model.term 116 = lit137 := by rw [model.lam_eq 116 117 (by rfl), sub117]; rfl
theorem sub115 : model.term 115 = lit146 := model.var_eq 115 1 (by rfl)
theorem sub114 : model.term 114 = lit145 := by rw [model.lam_eq 114 115 (by rfl), sub115]; rfl
theorem sub113 : model.term 113 = lit146 := model.var_eq 113 1 (by rfl)
theorem sub112 : model.term 112 = lit145 := by rw [model.lam_eq 112 113 (by rfl), sub113]; rfl
theorem sub111 : model.term 111 = lit146 := model.var_eq 111 1 (by rfl)
theorem sub110 : model.term 110 = lit145 := by rw [model.lam_eq 110 111 (by rfl), sub111]; rfl
theorem sub109 : model.term 109 = lit109 := model.var_eq 109 2 (by rfl)
theorem sub108 : model.term 108 = lit108 := by rw [model.app_eq 108 109 110 (by rfl), sub109, sub110]; rfl
theorem sub107 : model.term 107 = lit146 := model.var_eq 107 1 (by rfl)
theorem sub106 : model.term 106 = lit106 := by rw [model.app_eq 106 107 108 (by rfl), sub107, sub108]; rfl
theorem sub105 : model.term 105 = lit105 := by rw [model.lam_eq 105 106 (by rfl), sub106]; rfl
theorem sub104 : model.term 104 = lit104 := by rw [model.lam_eq 104 105 (by rfl), sub105]; rfl
theorem sub103 : model.term 103 = lit174 := model.var_eq 103 0 (by rfl)
theorem sub102 : model.term 102 = lit102 := by rw [model.app_eq 102 103 104 (by rfl), sub103, sub104]; rfl
theorem sub101 : model.term 101 = lit174 := model.var_eq 101 0 (by rfl)
theorem sub100 : model.term 100 = lit100 := by rw [model.app_eq 100 101 102 (by rfl), sub101, sub102]; rfl
theorem sub99 : model.term 99 = lit99 := by rw [model.lam_eq 99 100 (by rfl), sub100]; rfl
theorem sub98 : model.term 98 = lit98 := by rw [model.app_eq 98 99 112 (by rfl), sub99, sub112]; rfl
theorem sub97 : model.term 97 = lit146 := model.var_eq 97 1 (by rfl)
theorem sub96 : model.term 96 = lit96 := by rw [model.app_eq 96 97 98 (by rfl), sub97, sub98]; rfl
theorem sub95 : model.term 95 = lit95 := by rw [model.lam_eq 95 96 (by rfl), sub96]; rfl
theorem sub94 : model.term 94 = lit94 := by rw [model.lam_eq 94 95 (by rfl), sub95]; rfl
theorem sub93 : model.term 93 = lit146 := model.var_eq 93 1 (by rfl)
theorem sub92 : model.term 92 = lit145 := by rw [model.lam_eq 92 93 (by rfl), sub93]; rfl
theorem sub91 : model.term 91 = lit109 := model.var_eq 91 2 (by rfl)
theorem sub90 : model.term 90 = lit108 := by rw [model.app_eq 90 91 92 (by rfl), sub91, sub92]; rfl
theorem sub89 : model.term 89 = lit146 := model.var_eq 89 1 (by rfl)
theorem sub88 : model.term 88 = lit106 := by rw [model.app_eq 88 89 90 (by rfl), sub89, sub90]; rfl
theorem sub87 : model.term 87 = lit105 := by rw [model.lam_eq 87 88 (by rfl), sub88]; rfl
theorem sub86 : model.term 86 = lit104 := by rw [model.lam_eq 86 87 (by rfl), sub87]; rfl
theorem sub85 : model.term 85 = lit174 := model.var_eq 85 0 (by rfl)
theorem sub84 : model.term 84 = lit102 := by rw [model.app_eq 84 85 86 (by rfl), sub85, sub86]; rfl
theorem sub83 : model.term 83 = lit174 := model.var_eq 83 0 (by rfl)
theorem sub82 : model.term 82 = lit100 := by rw [model.app_eq 82 83 84 (by rfl), sub83, sub84]; rfl
theorem sub81 : model.term 81 = lit99 := by rw [model.lam_eq 81 82 (by rfl), sub82]; rfl
theorem sub80 : model.term 80 = lit80 := by rw [model.app_eq 80 81 94 (by rfl), sub81, sub94]; rfl
theorem sub79 : model.term 79 = lit79 := by rw [model.app_eq 79 80 114 (by rfl), sub80, sub114]; rfl
theorem sub78 : model.term 78 = lit146 := model.var_eq 78 1 (by rfl)
theorem sub77 : model.term 77 = lit77 := by rw [model.app_eq 77 78 79 (by rfl), sub78, sub79]; rfl
theorem sub76 : model.term 76 = lit76 := by rw [model.lam_eq 76 77 (by rfl), sub77]; rfl
theorem sub75 : model.term 75 = lit75 := by rw [model.lam_eq 75 76 (by rfl), sub76]; rfl
theorem sub74 : model.term 74 = lit146 := model.var_eq 74 1 (by rfl)
theorem sub73 : model.term 73 = lit145 := by rw [model.lam_eq 73 74 (by rfl), sub74]; rfl
theorem sub72 : model.term 72 = lit146 := model.var_eq 72 1 (by rfl)
theorem sub71 : model.term 71 = lit145 := by rw [model.lam_eq 71 72 (by rfl), sub72]; rfl
theorem sub70 : model.term 70 = lit109 := model.var_eq 70 2 (by rfl)
theorem sub69 : model.term 69 = lit108 := by rw [model.app_eq 69 70 71 (by rfl), sub70, sub71]; rfl
theorem sub68 : model.term 68 = lit146 := model.var_eq 68 1 (by rfl)
theorem sub67 : model.term 67 = lit106 := by rw [model.app_eq 67 68 69 (by rfl), sub68, sub69]; rfl
theorem sub66 : model.term 66 = lit105 := by rw [model.lam_eq 66 67 (by rfl), sub67]; rfl
theorem sub65 : model.term 65 = lit104 := by rw [model.lam_eq 65 66 (by rfl), sub66]; rfl
theorem sub64 : model.term 64 = lit174 := model.var_eq 64 0 (by rfl)
theorem sub63 : model.term 63 = lit102 := by rw [model.app_eq 63 64 65 (by rfl), sub64, sub65]; rfl
theorem sub62 : model.term 62 = lit174 := model.var_eq 62 0 (by rfl)
theorem sub61 : model.term 61 = lit100 := by rw [model.app_eq 61 62 63 (by rfl), sub62, sub63]; rfl
theorem sub60 : model.term 60 = lit99 := by rw [model.lam_eq 60 61 (by rfl), sub61]; rfl
theorem sub59 : model.term 59 = lit98 := by rw [model.app_eq 59 60 73 (by rfl), sub60, sub73]; rfl
theorem sub58 : model.term 58 = lit146 := model.var_eq 58 1 (by rfl)
theorem sub57 : model.term 57 = lit96 := by rw [model.app_eq 57 58 59 (by rfl), sub58, sub59]; rfl
theorem sub56 : model.term 56 = lit95 := by rw [model.lam_eq 56 57 (by rfl), sub57]; rfl
theorem sub55 : model.term 55 = lit94 := by rw [model.lam_eq 55 56 (by rfl), sub56]; rfl
theorem sub54 : model.term 54 = lit146 := model.var_eq 54 1 (by rfl)
theorem sub53 : model.term 53 = lit145 := by rw [model.lam_eq 53 54 (by rfl), sub54]; rfl
theorem sub52 : model.term 52 = lit109 := model.var_eq 52 2 (by rfl)
theorem sub51 : model.term 51 = lit108 := by rw [model.app_eq 51 52 53 (by rfl), sub52, sub53]; rfl
theorem sub50 : model.term 50 = lit146 := model.var_eq 50 1 (by rfl)
theorem sub49 : model.term 49 = lit106 := by rw [model.app_eq 49 50 51 (by rfl), sub50, sub51]; rfl
theorem sub48 : model.term 48 = lit105 := by rw [model.lam_eq 48 49 (by rfl), sub49]; rfl
theorem sub47 : model.term 47 = lit104 := by rw [model.lam_eq 47 48 (by rfl), sub48]; rfl
theorem sub46 : model.term 46 = lit174 := model.var_eq 46 0 (by rfl)
theorem sub45 : model.term 45 = lit102 := by rw [model.app_eq 45 46 47 (by rfl), sub46, sub47]; rfl
theorem sub44 : model.term 44 = lit174 := model.var_eq 44 0 (by rfl)
theorem sub43 : model.term 43 = lit100 := by rw [model.app_eq 43 44 45 (by rfl), sub44, sub45]; rfl
theorem sub42 : model.term 42 = lit99 := by rw [model.lam_eq 42 43 (by rfl), sub43]; rfl
theorem sub41 : model.term 41 = lit80 := by rw [model.app_eq 41 42 55 (by rfl), sub42, sub55]; rfl
theorem sub40 : model.term 40 = lit40 := by rw [model.app_eq 40 41 75 (by rfl), sub41, sub75]; rfl
theorem sub39 : model.term 39 = lit146 := model.var_eq 39 1 (by rfl)
theorem sub38 : model.term 38 = lit145 := by rw [model.lam_eq 38 39 (by rfl), sub39]; rfl
theorem sub37 : model.term 37 = lit146 := model.var_eq 37 1 (by rfl)
theorem sub36 : model.term 36 = lit145 := by rw [model.lam_eq 36 37 (by rfl), sub37]; rfl
theorem sub35 : model.term 35 = lit109 := model.var_eq 35 2 (by rfl)
theorem sub34 : model.term 34 = lit108 := by rw [model.app_eq 34 35 36 (by rfl), sub35, sub36]; rfl
theorem sub33 : model.term 33 = lit146 := model.var_eq 33 1 (by rfl)
theorem sub32 : model.term 32 = lit106 := by rw [model.app_eq 32 33 34 (by rfl), sub33, sub34]; rfl
theorem sub31 : model.term 31 = lit105 := by rw [model.lam_eq 31 32 (by rfl), sub32]; rfl
theorem sub30 : model.term 30 = lit104 := by rw [model.lam_eq 30 31 (by rfl), sub31]; rfl
theorem sub29 : model.term 29 = lit174 := model.var_eq 29 0 (by rfl)
theorem sub28 : model.term 28 = lit102 := by rw [model.app_eq 28 29 30 (by rfl), sub29, sub30]; rfl
theorem sub27 : model.term 27 = lit174 := model.var_eq 27 0 (by rfl)
theorem sub26 : model.term 26 = lit100 := by rw [model.app_eq 26 27 28 (by rfl), sub27, sub28]; rfl
theorem sub25 : model.term 25 = lit99 := by rw [model.lam_eq 25 26 (by rfl), sub26]; rfl
theorem sub24 : model.term 24 = lit98 := by rw [model.app_eq 24 25 38 (by rfl), sub25, sub38]; rfl
theorem sub23 : model.term 23 = lit146 := model.var_eq 23 1 (by rfl)
theorem sub22 : model.term 22 = lit96 := by rw [model.app_eq 22 23 24 (by rfl), sub23, sub24]; rfl
theorem sub21 : model.term 21 = lit95 := by rw [model.lam_eq 21 22 (by rfl), sub22]; rfl
theorem sub20 : model.term 20 = lit94 := by rw [model.lam_eq 20 21 (by rfl), sub21]; rfl
theorem sub19 : model.term 19 = lit146 := model.var_eq 19 1 (by rfl)
theorem sub18 : model.term 18 = lit145 := by rw [model.lam_eq 18 19 (by rfl), sub19]; rfl
theorem sub17 : model.term 17 = lit109 := model.var_eq 17 2 (by rfl)
theorem sub16 : model.term 16 = lit108 := by rw [model.app_eq 16 17 18 (by rfl), sub17, sub18]; rfl
theorem sub15 : model.term 15 = lit146 := model.var_eq 15 1 (by rfl)
theorem sub14 : model.term 14 = lit106 := by rw [model.app_eq 14 15 16 (by rfl), sub15, sub16]; rfl
theorem sub13 : model.term 13 = lit105 := by rw [model.lam_eq 13 14 (by rfl), sub14]; rfl
theorem sub12 : model.term 12 = lit104 := by rw [model.lam_eq 12 13 (by rfl), sub13]; rfl
theorem sub11 : model.term 11 = lit174 := model.var_eq 11 0 (by rfl)
theorem sub10 : model.term 10 = lit102 := by rw [model.app_eq 10 11 12 (by rfl), sub11, sub12]; rfl
theorem sub9 : model.term 9 = lit174 := model.var_eq 9 0 (by rfl)
theorem sub8 : model.term 8 = lit100 := by rw [model.app_eq 8 9 10 (by rfl), sub9, sub10]; rfl
theorem sub7 : model.term 7 = lit99 := by rw [model.lam_eq 7 8 (by rfl), sub8]; rfl
theorem sub6 : model.term 6 = lit80 := by rw [model.app_eq 6 7 20 (by rfl), sub7, sub20]; rfl
theorem sub5 : model.term 5 = lit5 := by rw [model.app_eq 5 6 40 (by rfl), sub6, sub40]; rfl
theorem sub4 : model.term 4 = lit4 := by rw [model.app_eq 4 5 116 (by rfl), sub5, sub116]; rfl
theorem sub3 : model.term 3 = lit3 := by rw [model.app_eq 3 4 119 (by rfl), sub4, sub119]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 148 (by rfl), sub3, sub148]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 157 (by rfl), sub2, sub157]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 166 (by rfl), sub1, sub166]; rfl
theorem allValid (i : Nat) (h : i < 109) : validState i = true := by
 by_cases h60 : i < 60
 · by_cases h24 : i < 24
   · by_cases h12 : i < 12
     · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
   · by_cases h36 : i < 36
     · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
     · by_cases h48 : i < 48
       · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
 · by_cases h84 : i < 84
   · by_cases h72 : i < 72
     · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
   · by_cases h96 : i < 96
     · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
     · by_cases h108 : i < 108
       · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl108 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 109
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e302902178758 := by
 intro he
 have hp : replay [[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] (call e302902178758 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R302902178758
