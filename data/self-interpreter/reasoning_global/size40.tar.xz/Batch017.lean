import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e300746083142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e300746083142 : Closed e300746083142 ∧ code e300746083142 = 1400257710918 := by decide
private def t_e300746083142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem cert_e300746083142 : ¬ IsSelfInterpreter e300746083142 :=
  wSource (t := t_e300746083142) (replay_sound (ps := []) (t := e300746083142) (by decide)) (by decide)
def e300746083382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e300746083382 : Closed e300746083382 ∧ code e300746083382 = 1400257711158 := by decide
private def t_e300746083382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem cert_e300746083382 : ¬ IsSelfInterpreter e300746083382 :=
  wSource (t := t_e300746083382) (replay_sound (ps := []) (t := e300746083382) (by decide)) (by decide)
def e300746083386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e300746083386 : Closed e300746083386 ∧ code e300746083386 = 1400257711162 := by decide
private def t_e300746083386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem cert_e300746083386 : ¬ IsSelfInterpreter e300746083386 :=
  wSource (t := t_e300746083386) (replay_sound (ps := []) (t := e300746083386) (by decide)) (by decide)
def e300746083526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e300746083526 : Closed e300746083526 ∧ code e300746083526 = 1400257711302 := by decide
theorem cert_e300746083526 : check e300746083526 [[]] .width = true := by decide
def e300746498074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300746498074 : Closed e300746498074 ∧ code e300746498074 = 1400258125850 := by decide
theorem cert_e300746498074 : check e300746498074 [[]] .width = true := by decide
def e300746498166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300746498166 : Closed e300746498166 ∧ code e300746498166 = 1400258125942 := by decide
theorem cert_e300746498166 : check e300746498166 [[]] .width = true := by decide
def e300746498410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300746498410 : Closed e300746498410 ∧ code e300746498410 = 1400258126186 := by decide
theorem cert_e300746498410 : check e300746498410 [[]] .width = true := by decide
def e300746498458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300746498458 : Closed e300746498458 ∧ code e300746498458 = 1400258126234 := by decide
theorem cert_e300746498458 : check e300746498458 [[]] .width = true := by decide
def e300746514458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300746514458 : Closed e300746514458 ∧ code e300746514458 = 1400258142234 := by decide
theorem cert_e300746514458 : check e300746514458 [[]] .width = true := by decide
def e300746514550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300746514550 : Closed e300746514550 ∧ code e300746514550 = 1400258142326 := by decide
theorem cert_e300746514550 : check e300746514550 [[]] .width = true := by decide
def e300746514794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300746514794 : Closed e300746514794 ∧ code e300746514794 = 1400258142570 := by decide
theorem cert_e300746514794 : check e300746514794 [[]] .width = true := by decide
def e300746514842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300746514842 : Closed e300746514842 ∧ code e300746514842 = 1400258142618 := by decide
theorem cert_e300746514842 : check e300746514842 [[]] .width = true := by decide
def e300746715334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300746715334 : Closed e300746715334 ∧ code e300746715334 = 1400258343110 := by decide
theorem cert_e300746715334 : check e300746715334 [[]] .width = true := by decide
def e300746723526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300746723526 : Closed e300746723526 ∧ code e300746723526 = 1400258351302 := by decide
theorem cert_e300746723526 : check e300746723526 [[]] .width = true := by decide
def e300746725402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300746725402 : Closed e300746725402 ∧ code e300746725402 = 1400258353178 := by decide
theorem cert_e300746725402 : check e300746725402 [[]] .width = true := by decide
def e300746756294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300746756294 : Closed e300746756294 ∧ code e300746756294 = 1400258384070 := by decide
theorem cert_e300746756294 : check e300746756294 [[]] .width = true := by decide
def e300746758170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300746758170 : Closed e300746758170 ∧ code e300746758170 = 1400258385946 := by decide
theorem cert_e300746758170 : check e300746758170 [[]] .width = true := by decide
def e300746762266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300746762266 : Closed e300746762266 ∧ code e300746762266 = 1400258390042 := by decide
theorem cert_e300746762266 : check e300746762266 [[]] .width = true := by decide
def e300746858522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300746858522 : Closed e300746858522 ∧ code e300746858522 = 1400258486298 := by decide
theorem cert_e300746858522 : check e300746858522 [[]] .width = true := by decide
def e300746858614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300746858614 : Closed e300746858614 ∧ code e300746858614 = 1400258486390 := by decide
theorem cert_e300746858614 : check e300746858614 [[]] .width = true := by decide
def e300746858858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300746858858 : Closed e300746858858 ∧ code e300746858858 = 1400258486634 := by decide
theorem cert_e300746858858 : check e300746858858 [[]] .width = true := by decide
def e300746858906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300746858906 : Closed e300746858906 ∧ code e300746858906 = 1400258486682 := by decide
theorem cert_e300746858906 : check e300746858906 [[]] .width = true := by decide
def e300746911942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300746911942 : Closed e300746911942 ∧ code e300746911942 = 1400258539718 := by decide
theorem cert_e300746911942 : check e300746911942 [[]] .width = true := by decide
def e300746920134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300746920134 : Closed e300746920134 ∧ code e300746920134 = 1400258547910 := by decide
theorem cert_e300746920134 : check e300746920134 [[]] .width = true := by decide
def e300746922010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300746922010 : Closed e300746922010 ∧ code e300746922010 = 1400258549786 := by decide
theorem cert_e300746922010 : check e300746922010 [[]] .width = true := by decide
def e300746997958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300746997958 : Closed e300746997958 ∧ code e300746997958 = 1400258625734 := by decide
theorem cert_e300746997958 : check e300746997958 [[]] .width = true := by decide
def e300746998486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e300746998486 : Closed e300746998486 ∧ code e300746998486 = 1400258626262 := by decide
theorem cert_e300746998486 : check e300746998486 [[]] .width = true := by decide
def e300746998490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e300746998490 : Closed e300746998490 ∧ code e300746998490 = 1400258626266 := by decide
theorem cert_e300746998490 : check e300746998490 [[]] .width = true := by decide
def e300746998506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e300746998506 : Closed e300746998506 ∧ code e300746998506 = 1400258626282 := by decide
theorem cert_e300746998506 : check e300746998506 [[]] .width = true := by decide
def e300746998582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e300746998582 : Closed e300746998582 ∧ code e300746998582 = 1400258626358 := by decide
theorem cert_e300746998582 : check e300746998582 [[]] .width = true := by decide
def e300746998586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e300746998586 : Closed e300746998586 ∧ code e300746998586 = 1400258626362 := by decide
theorem cert_e300746998586 : check e300746998586 [[]] .width = true := by decide
def e300746998670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e300746998670 : Closed e300746998670 ∧ code e300746998670 = 1400258626446 := by decide
theorem cert_e300746998670 : check e300746998670 [[]] .width = true := by decide
def e300746998682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e300746998682 : Closed e300746998682 ∧ code e300746998682 = 1400258626458 := by decide
theorem cert_e300746998682 : check e300746998682 [[]] .width = true := by decide
def e300747000602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e300747000602 : Closed e300747000602 ∧ code e300747000602 = 1400258628378 := by decide
theorem cert_e300747000602 : check e300747000602 [[]] .width = true := by decide
def e300747000646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e300747000646 : Closed e300747000646 ∧ code e300747000646 = 1400258628422 := by decide
theorem cert_e300747000646 : check e300747000646 [[]] .width = true := by decide
def e300747000886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e300747000886 : Closed e300747000886 ∧ code e300747000886 = 1400258628662 := by decide
theorem cert_e300747000886 : check e300747000886 [[]] .width = true := by decide
def e300747000890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e300747000890 : Closed e300747000890 ∧ code e300747000890 = 1400258628666 := by decide
theorem cert_e300747000890 : check e300747000890 [[]] .width = true := by decide
def e300747001030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e300747001030 : Closed e300747001030 ∧ code e300747001030 = 1400258628806 := by decide
theorem cert_e300747001030 : check e300747001030 [[]] .width = true := by decide
def e300747087898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300747087898 : Closed e300747087898 ∧ code e300747087898 = 1400258715674 := by decide
theorem cert_e300747087898 : check e300747087898 [[]] .width = true := by decide
def e300747087990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300747087990 : Closed e300747087990 ∧ code e300747087990 = 1400258715766 := by decide
private def t_e300747087990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e300747087990 : ¬ IsSelfInterpreter e300747087990 :=
  wSource (t := t_e300747087990) (replay_sound (ps := []) (t := e300747087990) (by decide)) (by decide)
def e300747088234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300747088234 : Closed e300747088234 ∧ code e300747088234 = 1400258716010 := by decide
private def t_e300747088234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e300747088234 : ¬ IsSelfInterpreter e300747088234 :=
  wSource (t := t_e300747088234) (replay_sound (ps := []) (t := e300747088234) (by decide)) (by decide)
def e300747088282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300747088282 : Closed e300747088282 ∧ code e300747088282 = 1400258716058 := by decide
private def t_e300747088282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e300747088282 : ¬ IsSelfInterpreter e300747088282 :=
  wSource (t := t_e300747088282) (replay_sound (ps := []) (t := e300747088282) (by decide)) (by decide)
def e300747116742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300747116742 : Closed e300747116742 ∧ code e300747116742 = 1400258744518 := by decide
theorem cert_e300747116742 : check e300747116742 [[]] .width = true := by decide
def e300747118618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300747118618 : Closed e300747118618 ∧ code e300747118618 = 1400258746394 := by decide
theorem cert_e300747118618 : check e300747118618 [[]] .width = true := by decide
def e300747122714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300747122714 : Closed e300747122714 ∧ code e300747122714 = 1400258750490 := by decide
theorem cert_e300747122714 : check e300747122714 [[]] .width = true := by decide
def e300747129030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300747129030 : Closed e300747129030 ∧ code e300747129030 = 1400258756806 := by decide
theorem cert_e300747129030 : check e300747129030 [[]] .width = true := by decide
def e300747129558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e300747129558 : Closed e300747129558 ∧ code e300747129558 = 1400258757334 := by decide
theorem cert_e300747129558 : check e300747129558 [[]] .width = true := by decide
def e300747129562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e300747129562 : Closed e300747129562 ∧ code e300747129562 = 1400258757338 := by decide
theorem cert_e300747129562 : check e300747129562 [[]] .width = true := by decide
def e300747129578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e300747129578 : Closed e300747129578 ∧ code e300747129578 = 1400258757354 := by decide
theorem cert_e300747129578 : check e300747129578 [[]] .width = true := by decide
def e300747129654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e300747129654 : Closed e300747129654 ∧ code e300747129654 = 1400258757430 := by decide
theorem cert_e300747129654 : check e300747129654 [[]] .width = true := by decide
def e300747129658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e300747129658 : Closed e300747129658 ∧ code e300747129658 = 1400258757434 := by decide
theorem cert_e300747129658 : check e300747129658 [[]] .width = true := by decide
def e300747129742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e300747129742 : Closed e300747129742 ∧ code e300747129742 = 1400258757518 := by decide
theorem cert_e300747129742 : check e300747129742 [[]] .width = true := by decide
def e300747129754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e300747129754 : Closed e300747129754 ∧ code e300747129754 = 1400258757530 := by decide
theorem cert_e300747129754 : check e300747129754 [[]] .width = true := by decide
def e300747131674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e300747131674 : Closed e300747131674 ∧ code e300747131674 = 1400258759450 := by decide
theorem cert_e300747131674 : check e300747131674 [[]] .width = true := by decide
def e300747131718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e300747131718 : Closed e300747131718 ∧ code e300747131718 = 1400258759494 := by decide
private def t_e300747131718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem cert_e300747131718 : ¬ IsSelfInterpreter e300747131718 :=
  wSource (t := t_e300747131718) (replay_sound (ps := []) (t := e300747131718) (by decide)) (by decide)
def e300747131958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e300747131958 : Closed e300747131958 ∧ code e300747131958 = 1400258759734 := by decide
private def t_e300747131958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem cert_e300747131958 : ¬ IsSelfInterpreter e300747131958 :=
  wSource (t := t_e300747131958) (replay_sound (ps := []) (t := e300747131958) (by decide)) (by decide)
def e300747131962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e300747131962 : Closed e300747131962 ∧ code e300747131962 = 1400258759738 := by decide
private def t_e300747131962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem cert_e300747131962 : ¬ IsSelfInterpreter e300747131962 :=
  wSource (t := t_e300747131962) (replay_sound (ps := []) (t := e300747131962) (by decide)) (by decide)
def e300747132102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e300747132102 : Closed e300747132102 ∧ code e300747132102 = 1400258759878 := by decide
theorem cert_e300747132102 : check e300747132102 [[]] .width = true := by decide
def e300750401734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300750401734 : Closed e300750401734 ∧ code e300750401734 = 1400262029510 := by decide
theorem cert_e300750401734 : check e300750401734 [[]] .width = true := by decide
def e300750434502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300750434502 : Closed e300750434502 ∧ code e300750434502 = 1400262062278 := by decide
theorem cert_e300750434502 : check e300750434502 [[]] .width = true := by decide
def e300754366662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300754366662 : Closed e300754366662 ∧ code e300754366662 = 1400265994438 := by decide
theorem cert_e300754366662 : check e300754366662 [[]] .width = true := by decide
def e300754383046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300754383046 : Closed e300754383046 ∧ code e300754383046 = 1400266010822 := by decide
theorem cert_e300754383046 : check e300754383046 [[]] .width = true := by decide
def e300754497734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300754497734 : Closed e300754497734 ∧ code e300754497734 = 1400266125510 := by decide
theorem cert_e300754497734 : check e300754497734 [[]] .width = true := by decide
def e300754515994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300754515994 : Closed e300754515994 ∧ code e300754515994 = 1400266143770 := by decide
theorem cert_e300754515994 : check e300754515994 [[]] .width = true := by decide
def e300754522310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300754522310 : Closed e300754522310 ∧ code e300754522310 = 1400266150086 := by decide
theorem cert_e300754522310 : check e300754522310 [[]] .width = true := by decide
def e300754524186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300754524186 : Closed e300754524186 ∧ code e300754524186 = 1400266151962 := by decide
theorem cert_e300754524186 : check e300754524186 [[]] .width = true := by decide
def e300754579654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300754579654 : Closed e300754579654 ∧ code e300754579654 = 1400266207430 := by decide
theorem cert_e300754579654 : check e300754579654 [[]] .width = true := by decide
def e300754587846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300754587846 : Closed e300754587846 ∧ code e300754587846 = 1400266215622 := by decide
theorem cert_e300754587846 : check e300754587846 [[]] .width = true := by decide
def e300754589722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300754589722 : Closed e300754589722 ∧ code e300754589722 = 1400266217498 := by decide
theorem cert_e300754589722 : check e300754589722 [[]] .width = true := by decide
def e300755153094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300755153094 : Closed e300755153094 ∧ code e300755153094 = 1400266780870 := by decide
theorem cert_e300755153094 : check e300755153094 [[]] .width = true := by decide
def e300755169478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300755169478 : Closed e300755169478 ∧ code e300755169478 = 1400266797254 := by decide
theorem cert_e300755169478 : check e300755169478 [[]] .width = true := by decide
def e300755836954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300755836954 : Closed e300755836954 ∧ code e300755836954 = 1400267464730 := by decide
theorem cert_e300755836954 : check e300755836954 [[]] .width = true := by decide
def e300755837046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300755837046 : Closed e300755837046 ∧ code e300755837046 = 1400267464822 := by decide
theorem cert_e300755837046 : check e300755837046 [[]] .width = true := by decide
def e300755837290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300755837290 : Closed e300755837290 ∧ code e300755837290 = 1400267465066 := by decide
theorem cert_e300755837290 : check e300755837290 [[]] .width = true := by decide
def e300755837338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300755837338 : Closed e300755837338 ∧ code e300755837338 = 1400267465114 := by decide
theorem cert_e300755837338 : check e300755837338 [[]] .width = true := by decide
def e300755939526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300755939526 : Closed e300755939526 ∧ code e300755939526 = 1400267567302 := by decide
theorem cert_e300755939526 : check e300755939526 [[]] .width = true := by decide
def e300755957786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300755957786 : Closed e300755957786 ∧ code e300755957786 = 1400267585562 := by decide
theorem cert_e300755957786 : check e300755957786 [[]] .width = true := by decide
def e300755964102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300755964102 : Closed e300755964102 ∧ code e300755964102 = 1400267591878 := by decide
theorem cert_e300755964102 : check e300755964102 [[]] .width = true := by decide
def e300755965978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300755965978 : Closed e300755965978 ∧ code e300755965978 = 1400267593754 := by decide
theorem cert_e300755965978 : check e300755965978 [[]] .width = true := by decide
def e300756172998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300756172998 : Closed e300756172998 ∧ code e300756172998 = 1400267800774 := by decide
theorem cert_e300756172998 : check e300756172998 [[]] .width = true := by decide
def e300756173526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e300756173526 : Closed e300756173526 ∧ code e300756173526 = 1400267801302 := by decide
theorem cert_e300756173526 : check e300756173526 [[]] .width = true := by decide
def e300756173530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e300756173530 : Closed e300756173530 ∧ code e300756173530 = 1400267801306 := by decide
theorem cert_e300756173530 : check e300756173530 [[]] .width = true := by decide
def e300756173546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e300756173546 : Closed e300756173546 ∧ code e300756173546 = 1400267801322 := by decide
theorem cert_e300756173546 : check e300756173546 [[]] .width = true := by decide
def e300756173622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e300756173622 : Closed e300756173622 ∧ code e300756173622 = 1400267801398 := by decide
theorem cert_e300756173622 : check e300756173622 [[]] .width = true := by decide
def e300756173626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e300756173626 : Closed e300756173626 ∧ code e300756173626 = 1400267801402 := by decide
theorem cert_e300756173626 : check e300756173626 [[]] .width = true := by decide
def e300756173710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e300756173710 : Closed e300756173710 ∧ code e300756173710 = 1400267801486 := by decide
theorem cert_e300756173710 : check e300756173710 [[]] .width = true := by decide
def e300756173722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e300756173722 : Closed e300756173722 ∧ code e300756173722 = 1400267801498 := by decide
theorem cert_e300756173722 : check e300756173722 [[]] .width = true := by decide
def e300756175642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e300756175642 : Closed e300756175642 ∧ code e300756175642 = 1400267803418 := by decide
theorem cert_e300756175642 : check e300756175642 [[]] .width = true := by decide
def e300756175686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e300756175686 : Closed e300756175686 ∧ code e300756175686 = 1400267803462 := by decide
theorem cert_e300756175686 : check e300756175686 [[]] .width = true := by decide
def e300756175926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e300756175926 : Closed e300756175926 ∧ code e300756175926 = 1400267803702 := by decide
theorem cert_e300756175926 : check e300756175926 [[]] .width = true := by decide
def e300756175930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e300756175930 : Closed e300756175930 ∧ code e300756175930 = 1400267803706 := by decide
theorem cert_e300756175930 : check e300756175930 [[]] .width = true := by decide
def e300756176070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e300756176070 : Closed e300756176070 ∧ code e300756176070 = 1400267803846 := by decide
theorem cert_e300756176070 : check e300756176070 [[]] .width = true := by decide
def e300756295706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300756295706 : Closed e300756295706 ∧ code e300756295706 = 1400267923482 := by decide
theorem cert_e300756295706 : check e300756295706 [[]] .width = true := by decide
def e300756295798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300756295798 : Closed e300756295798 ∧ code e300756295798 = 1400267923574 := by decide
theorem cert_e300756295798 : check e300756295798 [[]] .width = true := by decide
def e300756296042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300756296042 : Closed e300756296042 ∧ code e300756296042 = 1400267923818 := by decide
theorem cert_e300756296042 : check e300756296042 [[]] .width = true := by decide
def e300756296090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300756296090 : Closed e300756296090 ∧ code e300756296090 = 1400267923866 := by decide
theorem cert_e300756296090 : check e300756296090 [[]] .width = true := by decide
def e300756349126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300756349126 : Closed e300756349126 ∧ code e300756349126 = 1400267976902 := by decide
theorem cert_e300756349126 : check e300756349126 [[]] .width = true := by decide
def e300756357318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300756357318 : Closed e300756357318 ∧ code e300756357318 = 1400267985094 := by decide
theorem cert_e300756357318 : check e300756357318 [[]] .width = true := by decide
def e300756359194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300756359194 : Closed e300756359194 ∧ code e300756359194 = 1400267986970 := by decide
theorem cert_e300756359194 : check e300756359194 [[]] .width = true := by decide
def e300756435142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300756435142 : Closed e300756435142 ∧ code e300756435142 = 1400268062918 := by decide
theorem cert_e300756435142 : check e300756435142 [[]] .width = true := by decide
def e300756435670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e300756435670 : Closed e300756435670 ∧ code e300756435670 = 1400268063446 := by decide
theorem cert_e300756435670 : check e300756435670 [[]] .width = true := by decide
def e300756435674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e300756435674 : Closed e300756435674 ∧ code e300756435674 = 1400268063450 := by decide
theorem cert_e300756435674 : check e300756435674 [[]] .width = true := by decide
def e300756435690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e300756435690 : Closed e300756435690 ∧ code e300756435690 = 1400268063466 := by decide
theorem cert_e300756435690 : check e300756435690 [[]] .width = true := by decide
def e300756435766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e300756435766 : Closed e300756435766 ∧ code e300756435766 = 1400268063542 := by decide
theorem cert_e300756435766 : check e300756435766 [[]] .width = true := by decide
def e300756435770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e300756435770 : Closed e300756435770 ∧ code e300756435770 = 1400268063546 := by decide
theorem cert_e300756435770 : check e300756435770 [[]] .width = true := by decide
def e300756435854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e300756435854 : Closed e300756435854 ∧ code e300756435854 = 1400268063630 := by decide
theorem cert_e300756435854 : check e300756435854 [[]] .width = true := by decide
def e300756435866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e300756435866 : Closed e300756435866 ∧ code e300756435866 = 1400268063642 := by decide
theorem cert_e300756435866 : check e300756435866 [[]] .width = true := by decide
def e300756437786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e300756437786 : Closed e300756437786 ∧ code e300756437786 = 1400268065562 := by decide
theorem cert_e300756437786 : check e300756437786 [[]] .width = true := by decide
def e300756437830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e300756437830 : Closed e300756437830 ∧ code e300756437830 = 1400268065606 := by decide
theorem cert_e300756437830 : check e300756437830 [[]] .width = true := by decide
def e300756438070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e300756438070 : Closed e300756438070 ∧ code e300756438070 = 1400268065846 := by decide
theorem cert_e300756438070 : check e300756438070 [[]] .width = true := by decide
def e300756438074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e300756438074 : Closed e300756438074 ∧ code e300756438074 = 1400268065850 := by decide
theorem cert_e300756438074 : check e300756438074 [[]] .width = true := by decide
def e300756438214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e300756438214 : Closed e300756438214 ∧ code e300756438214 = 1400268065990 := by decide
theorem cert_e300756438214 : check e300756438214 [[]] .width = true := by decide
def e300766130374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300766130374 : Closed e300766130374 ∧ code e300766130374 = 1400277758150 := by decide
theorem cert_e300766130374 : check e300766130374 [[]] .width = true := by decide
def e300766179526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300766179526 : Closed e300766179526 ∧ code e300766179526 = 1400277807302 := by decide
theorem cert_e300766179526 : check e300766179526 [[]] .width = true := by decide
def e300768129222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300768129222 : Closed e300768129222 ∧ code e300768129222 = 1400279756998 := by decide
theorem cert_e300768129222 : check e300768129222 [[]] .width = true := by decide
def e300768147482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300768147482 : Closed e300768147482 ∧ code e300768147482 = 1400279775258 := by decide
theorem cert_e300768147482 : check e300768147482 [[]] .width = true := by decide
def e300768153798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300768153798 : Closed e300768153798 ∧ code e300768153798 = 1400279781574 := by decide
theorem cert_e300768153798 : check e300768153798 [[]] .width = true := by decide
def e300768155674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300768155674 : Closed e300768155674 ∧ code e300768155674 = 1400279783450 := by decide
theorem cert_e300768155674 : check e300768155674 [[]] .width = true := by decide
def e300768213018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300768213018 : Closed e300768213018 ∧ code e300768213018 = 1400279840794 := by decide
theorem cert_e300768213018 : check e300768213018 [[]] .width = true := by decide
def e300768225306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300768225306 : Closed e300768225306 ∧ code e300768225306 = 1400279853082 := by decide
theorem cert_e300768225306 : check e300768225306 [[]] .width = true := by decide
def e300768252102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300768252102 : Closed e300768252102 ∧ code e300768252102 = 1400279879878 := by decide
theorem cert_e300768252102 : check e300768252102 [[]] .width = true := by decide
def e300768253978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300768253978 : Closed e300768253978 ∧ code e300768253978 = 1400279881754 := by decide
theorem cert_e300768253978 : check e300768253978 [[]] .width = true := by decide
def e300768258074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300768258074 : Closed e300768258074 ∧ code e300768258074 = 1400279885850 := by decide
theorem cert_e300768258074 : check e300768258074 [[]] .width = true := by decide
def e300768419866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300768419866 : Closed e300768419866 ∧ code e300768419866 = 1400280047642 := by decide
theorem cert_e300768419866 : check e300768419866 [[]] .width = true := by decide
def e300768419958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300768419958 : Closed e300768419958 ∧ code e300768419958 = 1400280047734 := by decide
theorem cert_e300768419958 : check e300768419958 [[]] .width = true := by decide
def e300768420202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300768420202 : Closed e300768420202 ∧ code e300768420202 = 1400280047978 := by decide
theorem cert_e300768420202 : check e300768420202 [[]] .width = true := by decide
def e300768420250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300768420250 : Closed e300768420250 ∧ code e300768420250 = 1400280048026 := by decide
theorem cert_e300768420250 : check e300768420250 [[]] .width = true := by decide
def e300768522438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300768522438 : Closed e300768522438 ∧ code e300768522438 = 1400280150214 := by decide
theorem cert_e300768522438 : check e300768522438 [[]] .width = true := by decide
def e300768540698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300768540698 : Closed e300768540698 ∧ code e300768540698 = 1400280168474 := by decide
theorem cert_e300768540698 : check e300768540698 [[]] .width = true := by decide
def e300768547014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300768547014 : Closed e300768547014 ∧ code e300768547014 = 1400280174790 := by decide
theorem cert_e300768547014 : check e300768547014 [[]] .width = true := by decide
def e300768548890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300768548890 : Closed e300768548890 ∧ code e300768548890 = 1400280176666 := by decide
theorem cert_e300768548890 : check e300768548890 [[]] .width = true := by decide
def e300768755910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300768755910 : Closed e300768755910 ∧ code e300768755910 = 1400280383686 := by decide
theorem cert_e300768755910 : check e300768755910 [[]] .width = true := by decide
def e300768756438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e300768756438 : Closed e300768756438 ∧ code e300768756438 = 1400280384214 := by decide
theorem cert_e300768756438 : check e300768756438 [[]] .width = true := by decide
def e300768756442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e300768756442 : Closed e300768756442 ∧ code e300768756442 = 1400280384218 := by decide
theorem cert_e300768756442 : check e300768756442 [[]] .width = true := by decide
def e300768756458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e300768756458 : Closed e300768756458 ∧ code e300768756458 = 1400280384234 := by decide
theorem cert_e300768756458 : check e300768756458 [[]] .width = true := by decide
def e300768756534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e300768756534 : Closed e300768756534 ∧ code e300768756534 = 1400280384310 := by decide
theorem cert_e300768756534 : check e300768756534 [[]] .width = true := by decide
def e300768756538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e300768756538 : Closed e300768756538 ∧ code e300768756538 = 1400280384314 := by decide
theorem cert_e300768756538 : check e300768756538 [[]] .width = true := by decide
def e300768756622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e300768756622 : Closed e300768756622 ∧ code e300768756622 = 1400280384398 := by decide
theorem cert_e300768756622 : check e300768756622 [[]] .width = true := by decide
def e300768756634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e300768756634 : Closed e300768756634 ∧ code e300768756634 = 1400280384410 := by decide
theorem cert_e300768756634 : check e300768756634 [[]] .width = true := by decide
def e300768758554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e300768758554 : Closed e300768758554 ∧ code e300768758554 = 1400280386330 := by decide
theorem cert_e300768758554 : check e300768758554 [[]] .width = true := by decide
def e300768758598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e300768758598 : Closed e300768758598 ∧ code e300768758598 = 1400280386374 := by decide
theorem cert_e300768758598 : check e300768758598 [[]] .width = true := by decide
def e300768758838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e300768758838 : Closed e300768758838 ∧ code e300768758838 = 1400280386614 := by decide
theorem cert_e300768758838 : check e300768758838 [[]] .width = true := by decide
def e300768758842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e300768758842 : Closed e300768758842 ∧ code e300768758842 = 1400280386618 := by decide
theorem cert_e300768758842 : check e300768758842 [[]] .width = true := by decide
def e300768758982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e300768758982 : Closed e300768758982 ∧ code e300768758982 = 1400280386758 := by decide
theorem cert_e300768758982 : check e300768758982 [[]] .width = true := by decide
def e300768933914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300768933914 : Closed e300768933914 ∧ code e300768933914 = 1400280561690 := by decide
theorem cert_e300768933914 : check e300768933914 [[]] .width = true := by decide
def e300768946202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300768946202 : Closed e300768946202 ∧ code e300768946202 = 1400280573978 := by decide
theorem cert_e300768946202 : check e300768946202 [[]] .width = true := by decide
def e300769107994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300769107994 : Closed e300769107994 ∧ code e300769107994 = 1400280735770 := by decide
theorem cert_e300769107994 : check e300769107994 [[]] .width = true := by decide
def e300769108086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300769108086 : Closed e300769108086 ∧ code e300769108086 = 1400280735862 := by decide
theorem cert_e300769108086 : check e300769108086 [[]] .width = true := by decide
def e300769108330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300769108330 : Closed e300769108330 ∧ code e300769108330 = 1400280736106 := by decide
theorem cert_e300769108330 : check e300769108330 [[]] .width = true := by decide
def e300769108378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300769108378 : Closed e300769108378 ∧ code e300769108378 = 1400280736154 := by decide
theorem cert_e300769108378 : check e300769108378 [[]] .width = true := by decide
def e300769136838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300769136838 : Closed e300769136838 ∧ code e300769136838 = 1400280764614 := by decide
theorem cert_e300769136838 : check e300769136838 [[]] .width = true := by decide
def e300769138714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300769138714 : Closed e300769138714 ∧ code e300769138714 = 1400280766490 := by decide
theorem cert_e300769138714 : check e300769138714 [[]] .width = true := by decide
def e300769142810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300769142810 : Closed e300769142810 ∧ code e300769142810 = 1400280770586 := by decide
theorem cert_e300769142810 : check e300769142810 [[]] .width = true := by decide
def e300769149126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300769149126 : Closed e300769149126 ∧ code e300769149126 = 1400280776902 := by decide
theorem cert_e300769149126 : check e300769149126 [[]] .width = true := by decide
def e300769149654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e300769149654 : Closed e300769149654 ∧ code e300769149654 = 1400280777430 := by decide
theorem cert_e300769149654 : check e300769149654 [[]] .width = true := by decide
def e300769149658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e300769149658 : Closed e300769149658 ∧ code e300769149658 = 1400280777434 := by decide
theorem cert_e300769149658 : check e300769149658 [[]] .width = true := by decide
def e300769149674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e300769149674 : Closed e300769149674 ∧ code e300769149674 = 1400280777450 := by decide
theorem cert_e300769149674 : check e300769149674 [[]] .width = true := by decide
def e300769149750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e300769149750 : Closed e300769149750 ∧ code e300769149750 = 1400280777526 := by decide
theorem cert_e300769149750 : check e300769149750 [[]] .width = true := by decide
def e300769149754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e300769149754 : Closed e300769149754 ∧ code e300769149754 = 1400280777530 := by decide
theorem cert_e300769149754 : check e300769149754 [[]] .width = true := by decide
def e300769149838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e300769149838 : Closed e300769149838 ∧ code e300769149838 = 1400280777614 := by decide
theorem cert_e300769149838 : check e300769149838 [[]] .width = true := by decide
end Blc.Floor40
