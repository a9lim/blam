import R302887562694V0
import R302887562694K0
import R302887562694st0
import R302887562694hs0
import CodeBridge
import Batch060
namespace Certgen.R302887562694
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 53,.app 2 24,.app 3 21,.app 4 8,.lam 5,.app 6 7,.var 0,.var 0,.lam 9,.app 10 19,.app 11 12,.var 0,.lam 13,.lam 14,.app 15 18,.app 16 17,.var 0,.var 1,.var 2,.lam 20,.var 1,.lam 22,.lam 23,.var 0,.lam 25,.app 26 31,.app 27 28,.var 0,.lam 29,.lam 30,.var 1,.lam 32,.app 33 38,.app 34 35,.var 0,.lam 36,.lam 37,.var 1,.lam 39,.app 40 45,.app 41 42,.var 0,.lam 43,.lam 44,.var 0,.lam 46,.app 47 52,.app 48 49,.var 0,.lam 50,.lam 51,.var 1,.opaque,.app 54 58,.lam 55,.app 56 57,.var 0,.var 0,.lam 59,.app 60 61,.var 0,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (V20[i-20]?.getD []))
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD []))
def st (i : Nat) : AState := if i < 174 then (if i < 80 then (if i < 40 then (if i < 20 then (st0[i-0]?.getD entry) else (st20[i-20]?.getD entry)) else (if i < 60 then (st40[i-40]?.getD entry) else (st60[i-60]?.getD entry))) else (if i < 120 then (if i < 100 then (st80[i-80]?.getD entry) else (st100[i-100]?.getD entry)) else (if i < 140 then (st120[i-120]?.getD entry) else (if i < 160 then (st140[i-140]?.getD entry) else (st160[i-160]?.getD entry))))) else entry
def hs (i : Nat) : List Nat := (if i < 80 then (if i < 40 then (if i < 20 then (hs0[i-0]?.getD []) else (hs20[i-20]?.getD [])) else (if i < 60 then (hs40[i-40]?.getD []) else (hs60[i-60]?.getD []))) else (if i < 120 then (if i < 100 then (hs80[i-80]?.getD []) else (hs100[i-100]?.getD [])) else (if i < 140 then (hs120[i-120]?.getD []) else (if i < 160 then (hs140[i-140]?.getD []) else (hs160[i-160]?.getD [])))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R302887562694
