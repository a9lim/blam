import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302796626842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e302796626842 : Closed e302796626842 ∧ code e302796626842 = 1402308254618 := by decide
theorem cert_e302796626842 : check e302796626842 [[],[]] .smaller = true := by decide
def e302796626886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e302796626886 : Closed e302796626886 ∧ code e302796626886 = 1402308254662 := by decide
theorem cert_e302796626886 : check e302796626886 [[],[]] .three = true := by decide
def e302796627054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302796627054 : Closed e302796627054 ∧ code e302796627054 = 1402308254830 := by decide
theorem cert_e302796627054 : check e302796627054 [[],[]] .smaller = true := by decide
def e302796627066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302796627066 : Closed e302796627066 ∧ code e302796627066 = 1402308254842 := by decide
theorem cert_e302796627066 : check e302796627066 [[],[]] .smaller = true := by decide
def e302796627158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e302796627158 : Closed e302796627158 ∧ code e302796627158 = 1402308254934 := by decide
theorem cert_e302796627158 : check e302796627158 [[],[]] .smaller = true := by decide
def e302796627162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e302796627162 : Closed e302796627162 ∧ code e302796627162 = 1402308254938 := by decide
theorem cert_e302796627162 : check e302796627162 [[],[]] .smaller = true := by decide
def e302796627178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e302796627178 : Closed e302796627178 ∧ code e302796627178 = 1402308254954 := by decide
theorem cert_e302796627178 : check e302796627178 [[],[]] .smaller = true := by decide
def e302796627230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302796627230 : Closed e302796627230 ∧ code e302796627230 = 1402308255006 := by decide
theorem cert_e302796627230 : check e302796627230 [[],[]] .smaller = true := by decide
def e302796627254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e302796627254 : Closed e302796627254 ∧ code e302796627254 = 1402308255030 := by decide
theorem cert_e302796627254 : check e302796627254 [[],[]] .smaller = true := by decide
def e302796627258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e302796627258 : Closed e302796627258 ∧ code e302796627258 = 1402308255034 := by decide
theorem cert_e302796627258 : check e302796627258 [[],[]] .smaller = true := by decide
def e302796627354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e302796627354 : Closed e302796627354 ∧ code e302796627354 = 1402308255130 := by decide
theorem cert_e302796627354 : check e302796627354 [[],[]] .smaller = true := by decide
def e302796627398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302796627398 : Closed e302796627398 ∧ code e302796627398 = 1402308255174 := by decide
theorem cert_e302796627398 : check e302796627398 [[],[]] .smaller = true := by decide
def e302796627422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 3)))))))
theorem wire_e302796627422 : Closed e302796627422 ∧ code e302796627422 = 1402308255198 := by decide
theorem cert_e302796627422 : check e302796627422 [[],[]] .three = true := by decide
def e302796627438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 2)))))))
theorem wire_e302796627438 : Closed e302796627438 ∧ code e302796627438 = 1402308255214 := by decide
theorem cert_e302796627438 : check e302796627438 [[],[]] .three = true := by decide
def e302796627510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302796627510 : Closed e302796627510 ∧ code e302796627510 = 1402308255286 := by decide
theorem cert_e302796627510 : check e302796627510 [[],[]] .three = true := by decide
def e302796627514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302796627514 : Closed e302796627514 ∧ code e302796627514 = 1402308255290 := by decide
theorem cert_e302796627514 : check e302796627514 [[],[]] .three = true := by decide
def e302796627562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e302796627562 : Closed e302796627562 ∧ code e302796627562 = 1402308255338 := by decide
theorem cert_e302796627562 : check e302796627562 [[],[]] .three = true := by decide
def e302796627598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302796627598 : Closed e302796627598 ∧ code e302796627598 = 1402308255374 := by decide
theorem cert_e302796627598 : check e302796627598 [[],[]] .three = true := by decide
def e302796627610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e302796627610 : Closed e302796627610 ∧ code e302796627610 = 1402308255386 := by decide
theorem cert_e302796627610 : check e302796627610 [[],[]] .three = true := by decide
def e302796627654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302796627654 : Closed e302796627654 ∧ code e302796627654 = 1402308255430 := by decide
theorem cert_e302796627654 : check e302796627654 [[],[]] .three = true := by decide
def e302796627694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 2)))))))
theorem wire_e302796627694 : Closed e302796627694 ∧ code e302796627694 = 1402308255470 := by decide
theorem cert_e302796627694 : check e302796627694 [[],[]] .three = true := by decide
def e302796628830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e302796628830 : Closed e302796628830 ∧ code e302796628830 = 1402308256606 := by decide
theorem cert_e302796628830 : check e302796628830 [[],[]] .three = true := by decide
def e302796628846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e302796628846 : Closed e302796628846 ∧ code e302796628846 = 1402308256622 := by decide
theorem cert_e302796628846 : check e302796628846 [[],[]] .smaller = true := by decide
def e302796628854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e302796628854 : Closed e302796628854 ∧ code e302796628854 = 1402308256630 := by decide
theorem cert_e302796628854 : check e302796628854 [[],[]] .smaller = true := by decide
def e302796628858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e302796628858 : Closed e302796628858 ∧ code e302796628858 = 1402308256634 := by decide
theorem cert_e302796628858 : check e302796628858 [[],[]] .three = true := by decide
def e302796628910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e302796628910 : Closed e302796628910 ∧ code e302796628910 = 1402308256686 := by decide
theorem cert_e302796628910 : check e302796628910 [[],[]] .smaller = true := by decide
def e302796628922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e302796628922 : Closed e302796628922 ∧ code e302796628922 = 1402308256698 := by decide
theorem cert_e302796628922 : check e302796628922 [[],[]] .smaller = true := by decide
def e302796628950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e302796628950 : Closed e302796628950 ∧ code e302796628950 = 1402308256726 := by decide
theorem cert_e302796628950 : check e302796628950 [[],[]] .smaller = true := by decide
def e302796628954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e302796628954 : Closed e302796628954 ∧ code e302796628954 = 1402308256730 := by decide
theorem cert_e302796628954 : check e302796628954 [[],[]] .smaller = true := by decide
def e302796628970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 4))) (.var 0)) (.var 0)))))))
theorem wire_e302796628970 : Closed e302796628970 ∧ code e302796628970 = 1402308256746 := by decide
theorem cert_e302796628970 : check e302796628970 [[],[]] .three = true := by decide
def e302796629686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e302796629686 : Closed e302796629686 ∧ code e302796629686 = 1402308257462 := by decide
theorem cert_e302796629686 : check e302796629686 [[],[]] .smaller = true := by decide
def e302796629718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e302796629718 : Closed e302796629718 ∧ code e302796629718 = 1402308257494 := by decide
theorem cert_e302796629718 : check e302796629718 [[],[]] .smaller = true := by decide
def e302796629722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e302796629722 : Closed e302796629722 ∧ code e302796629722 = 1402308257498 := by decide
theorem cert_e302796629722 : check e302796629722 [[],[]] .smaller = true := by decide
def e302796629846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e302796629846 : Closed e302796629846 ∧ code e302796629846 = 1402308257622 := by decide
theorem cert_e302796629846 : check e302796629846 [[],[]] .smaller = true := by decide
def e302796629850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e302796629850 : Closed e302796629850 ∧ code e302796629850 = 1402308257626 := by decide
theorem cert_e302796629850 : check e302796629850 [[],[]] .smaller = true := by decide
def e302796629866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e302796629866 : Closed e302796629866 ∧ code e302796629866 = 1402308257642 := by decide
theorem cert_e302796629866 : check e302796629866 [[],[]] .smaller = true := by decide
def e302796630238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e302796630238 : Closed e302796630238 ∧ code e302796630238 = 1402308258014 := by decide
theorem cert_e302796630238 : check e302796630238 [[],[]] .three = true := by decide
def e302796630254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e302796630254 : Closed e302796630254 ∧ code e302796630254 = 1402308258030 := by decide
theorem cert_e302796630254 : check e302796630254 [[],[]] .smaller = true := by decide
def e302796630262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e302796630262 : Closed e302796630262 ∧ code e302796630262 = 1402308258038 := by decide
theorem cert_e302796630262 : check e302796630262 [[],[]] .smaller = true := by decide
def e302796630266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e302796630266 : Closed e302796630266 ∧ code e302796630266 = 1402308258042 := by decide
theorem cert_e302796630266 : check e302796630266 [[],[]] .three = true := by decide
def e302796630454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e302796630454 : Closed e302796630454 ∧ code e302796630454 = 1402308258230 := by decide
theorem cert_e302796630454 : check e302796630454 [[],[]] .smaller = true := by decide
def e302796630486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e302796630486 : Closed e302796630486 ∧ code e302796630486 = 1402308258262 := by decide
theorem cert_e302796630486 : check e302796630486 [[],[]] .smaller = true := by decide
def e302796630490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e302796630490 : Closed e302796630490 ∧ code e302796630490 = 1402308258266 := by decide
theorem cert_e302796630490 : check e302796630490 [[],[]] .smaller = true := by decide
def e302796630590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e302796630590 : Closed e302796630590 ∧ code e302796630590 = 1402308258366 := by decide
theorem cert_e302796630590 : check e302796630590 [[],[]] .three = true := by decide
def e302796630646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e302796630646 : Closed e302796630646 ∧ code e302796630646 = 1402308258422 := by decide
theorem cert_e302796630646 : check e302796630646 [[],[]] .smaller = true := by decide
def e302796630814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e302796630814 : Closed e302796630814 ∧ code e302796630814 = 1402308258590 := by decide
theorem cert_e302796630814 : check e302796630814 [[],[]] .smaller = true := by decide
def e302796630838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e302796630838 : Closed e302796630838 ∧ code e302796630838 = 1402308258614 := by decide
theorem cert_e302796630838 : check e302796630838 [[],[]] .smaller = true := by decide
def e302796630842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e302796630842 : Closed e302796630842 ∧ code e302796630842 = 1402308258618 := by decide
theorem cert_e302796630842 : check e302796630842 [[],[]] .smaller = true := by decide
def e302796630926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e302796630926 : Closed e302796630926 ∧ code e302796630926 = 1402308258702 := by decide
theorem cert_e302796630926 : check e302796630926 [[],[]] .smaller = true := by decide
def e302796630982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e302796630982 : Closed e302796630982 ∧ code e302796630982 = 1402308258758 := by decide
theorem cert_e302796630982 : check e302796630982 [[],[]] .three = true := by decide
def e302796631006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 3)))))))
theorem wire_e302796631006 : Closed e302796631006 ∧ code e302796631006 = 1402308258782 := by decide
theorem cert_e302796631006 : check e302796631006 [[],[]] .three = true := by decide
def e302796631150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302796631150 : Closed e302796631150 ∧ code e302796631150 = 1402308258926 := by decide
theorem cert_e302796631150 : check e302796631150 [[],[]] .smaller = true := by decide
def e302796631162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302796631162 : Closed e302796631162 ∧ code e302796631162 = 1402308258938 := by decide
theorem cert_e302796631162 : check e302796631162 [[],[]] .smaller = true := by decide
def e302796631254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e302796631254 : Closed e302796631254 ∧ code e302796631254 = 1402308259030 := by decide
theorem cert_e302796631254 : check e302796631254 [[],[]] .smaller = true := by decide
def e302796631258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e302796631258 : Closed e302796631258 ∧ code e302796631258 = 1402308259034 := by decide
theorem cert_e302796631258 : check e302796631258 [[],[]] .smaller = true := by decide
def e302796631274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e302796631274 : Closed e302796631274 ∧ code e302796631274 = 1402308259050 := by decide
theorem cert_e302796631274 : check e302796631274 [[],[]] .smaller = true := by decide
def e302796631326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302796631326 : Closed e302796631326 ∧ code e302796631326 = 1402308259102 := by decide
theorem cert_e302796631326 : check e302796631326 [[],[]] .smaller = true := by decide
def e302796631350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e302796631350 : Closed e302796631350 ∧ code e302796631350 = 1402308259126 := by decide
theorem cert_e302796631350 : check e302796631350 [[],[]] .smaller = true := by decide
def e302796631354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e302796631354 : Closed e302796631354 ∧ code e302796631354 = 1402308259130 := by decide
theorem cert_e302796631354 : check e302796631354 [[],[]] .smaller = true := by decide
def e302796631450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e302796631450 : Closed e302796631450 ∧ code e302796631450 = 1402308259226 := by decide
theorem cert_e302796631450 : check e302796631450 [[],[]] .smaller = true := by decide
def e302796631494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302796631494 : Closed e302796631494 ∧ code e302796631494 = 1402308259270 := by decide
theorem cert_e302796631494 : check e302796631494 [[],[]] .smaller = true := by decide
def e302796631518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 3)))))))
theorem wire_e302796631518 : Closed e302796631518 ∧ code e302796631518 = 1402308259294 := by decide
theorem cert_e302796631518 : check e302796631518 [[],[]] .three = true := by decide
def e302796631534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 2)))))))
theorem wire_e302796631534 : Closed e302796631534 ∧ code e302796631534 = 1402308259310 := by decide
theorem cert_e302796631534 : check e302796631534 [[],[]] .three = true := by decide
def e302796631606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302796631606 : Closed e302796631606 ∧ code e302796631606 = 1402308259382 := by decide
theorem cert_e302796631606 : check e302796631606 [[],[]] .smaller = true := by decide
def e302796631610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302796631610 : Closed e302796631610 ∧ code e302796631610 = 1402308259386 := by decide
theorem cert_e302796631610 : check e302796631610 [[],[]] .smaller = true := by decide
def e302796631694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302796631694 : Closed e302796631694 ∧ code e302796631694 = 1402308259470 := by decide
theorem cert_e302796631694 : check e302796631694 [[],[]] .smaller = true := by decide
def e302796631750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302796631750 : Closed e302796631750 ∧ code e302796631750 = 1402308259526 := by decide
theorem cert_e302796631750 : check e302796631750 [[],[]] .smaller = true := by decide
def e302796631774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 3)))))))
theorem wire_e302796631774 : Closed e302796631774 ∧ code e302796631774 = 1402308259550 := by decide
theorem cert_e302796631774 : check e302796631774 [[],[]] .three = true := by decide
def e302796631798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.var 1)))))))
theorem wire_e302796631798 : Closed e302796631798 ∧ code e302796631798 = 1402308259574 := by decide
theorem cert_e302796631798 : check e302796631798 [[],[]] .three = true := by decide
def e302796631834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302796631834 : Closed e302796631834 ∧ code e302796631834 = 1402308259610 := by decide
theorem cert_e302796631834 : check e302796631834 [[],[]] .three = true := by decide
def e302796631878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302796631878 : Closed e302796631878 ∧ code e302796631878 = 1402308259654 := by decide
theorem cert_e302796631878 : check e302796631878 [[],[]] .three = true := by decide
def e302796631902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 3)))))))
theorem wire_e302796631902 : Closed e302796631902 ∧ code e302796631902 = 1402308259678 := by decide
theorem cert_e302796631902 : check e302796631902 [[],[]] .three = true := by decide
def e302796631918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 2)))))))
theorem wire_e302796631918 : Closed e302796631918 ∧ code e302796631918 = 1402308259694 := by decide
theorem cert_e302796631918 : check e302796631918 [[],[]] .three = true := by decide
def e302796631926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.var 1)))))))
theorem wire_e302796631926 : Closed e302796631926 ∧ code e302796631926 = 1402308259702 := by decide
theorem cert_e302796631926 : check e302796631926 [[],[]] .three = true := by decide
def e302796631930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 3)) (.var 0)))))))
theorem wire_e302796631930 : Closed e302796631930 ∧ code e302796631930 = 1402308259706 := by decide
theorem cert_e302796631930 : check e302796631930 [[],[]] .three = true := by decide
def e302796632494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e302796632494 : Closed e302796632494 ∧ code e302796632494 = 1402308260270 := by decide
theorem cert_e302796632494 : check e302796632494 [[],[]] .three = true := by decide
def e302796632502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e302796632502 : Closed e302796632502 ∧ code e302796632502 = 1402308260278 := by decide
theorem cert_e302796632502 : check e302796632502 [[],[]] .three = true := by decide
def e302796632506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e302796632506 : Closed e302796632506 ∧ code e302796632506 = 1402308260282 := by decide
theorem cert_e302796632506 : check e302796632506 [[],[]] .three = true := by decide
def e302796632534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e302796632534 : Closed e302796632534 ∧ code e302796632534 = 1402308260310 := by decide
theorem cert_e302796632534 : check e302796632534 [[],[]] .three = true := by decide
def e302796632538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e302796632538 : Closed e302796632538 ∧ code e302796632538 = 1402308260314 := by decide
theorem cert_e302796632538 : check e302796632538 [[],[]] .three = true := by decide
def e302796632554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e302796632554 : Closed e302796632554 ∧ code e302796632554 = 1402308260330 := by decide
theorem cert_e302796632554 : check e302796632554 [[],[]] .three = true := by decide
def e302796632918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e302796632918 : Closed e302796632918 ∧ code e302796632918 = 1402308260694 := by decide
theorem cert_e302796632918 : check e302796632918 [[],[]] .three = true := by decide
def e302796632922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e302796632922 : Closed e302796632922 ∧ code e302796632922 = 1402308260698 := by decide
theorem cert_e302796632922 : check e302796632922 [[],[]] .three = true := by decide
def e302796632938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e302796632938 : Closed e302796632938 ∧ code e302796632938 = 1402308260714 := by decide
theorem cert_e302796632938 : check e302796632938 [[],[]] .three = true := by decide
def e302796633002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e302796633002 : Closed e302796633002 ∧ code e302796633002 = 1402308260778 := by decide
theorem cert_e302796633002 : check e302796633002 [[],[]] .three = true := by decide
def e302796633198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302796633198 : Closed e302796633198 ∧ code e302796633198 = 1402308260974 := by decide
theorem cert_e302796633198 : check e302796633198 [[],[]] .three = true := by decide
def e302796633206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e302796633206 : Closed e302796633206 ∧ code e302796633206 = 1402308260982 := by decide
theorem cert_e302796633206 : check e302796633206 [[],[]] .three = true := by decide
def e302796633210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302796633210 : Closed e302796633210 ∧ code e302796633210 = 1402308260986 := by decide
theorem cert_e302796633210 : check e302796633210 [[],[]] .three = true := by decide
def e302796633302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e302796633302 : Closed e302796633302 ∧ code e302796633302 = 1402308261078 := by decide
theorem cert_e302796633302 : check e302796633302 [[],[]] .three = true := by decide
def e302796633306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e302796633306 : Closed e302796633306 ∧ code e302796633306 = 1402308261082 := by decide
theorem cert_e302796633306 : check e302796633306 [[],[]] .three = true := by decide
def e302796633322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e302796633322 : Closed e302796633322 ∧ code e302796633322 = 1402308261098 := by decide
theorem cert_e302796633322 : check e302796633322 [[],[]] .three = true := by decide
def e302796633374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302796633374 : Closed e302796633374 ∧ code e302796633374 = 1402308261150 := by decide
theorem cert_e302796633374 : check e302796633374 [[],[]] .three = true := by decide
def e302796633398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e302796633398 : Closed e302796633398 ∧ code e302796633398 = 1402308261174 := by decide
theorem cert_e302796633398 : check e302796633398 [[],[]] .three = true := by decide
def e302796633402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e302796633402 : Closed e302796633402 ∧ code e302796633402 = 1402308261178 := by decide
theorem cert_e302796633402 : check e302796633402 [[],[]] .three = true := by decide
def e302796633486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e302796633486 : Closed e302796633486 ∧ code e302796633486 = 1402308261262 := by decide
theorem cert_e302796633486 : check e302796633486 [[],[]] .three = true := by decide
def e302796633498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e302796633498 : Closed e302796633498 ∧ code e302796633498 = 1402308261274 := by decide
theorem cert_e302796633498 : check e302796633498 [[],[]] .three = true := by decide
def e302796633542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302796633542 : Closed e302796633542 ∧ code e302796633542 = 1402308261318 := by decide
theorem cert_e302796633542 : check e302796633542 [[],[]] .three = true := by decide
def e302796633566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e302796633566 : Closed e302796633566 ∧ code e302796633566 = 1402308261342 := by decide
theorem cert_e302796633566 : check e302796633566 [[],[]] .three = true := by decide
def e302796633582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e302796633582 : Closed e302796633582 ∧ code e302796633582 = 1402308261358 := by decide
theorem cert_e302796633582 : check e302796633582 [[],[]] .three = true := by decide
def e302796633654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302796633654 : Closed e302796633654 ∧ code e302796633654 = 1402308261430 := by decide
theorem cert_e302796633654 : check e302796633654 [[],[]] .three = true := by decide
def e302796633658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302796633658 : Closed e302796633658 ∧ code e302796633658 = 1402308261434 := by decide
theorem cert_e302796633658 : check e302796633658 [[],[]] .three = true := by decide
def e302796633706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e302796633706 : Closed e302796633706 ∧ code e302796633706 = 1402308261482 := by decide
theorem cert_e302796633706 : check e302796633706 [[],[]] .three = true := by decide
def e302796633742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302796633742 : Closed e302796633742 ∧ code e302796633742 = 1402308261518 := by decide
theorem cert_e302796633742 : check e302796633742 [[],[]] .three = true := by decide
def e302796633754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e302796633754 : Closed e302796633754 ∧ code e302796633754 = 1402308261530 := by decide
theorem cert_e302796633754 : check e302796633754 [[],[]] .three = true := by decide
def e302796633798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302796633798 : Closed e302796633798 ∧ code e302796633798 = 1402308261574 := by decide
theorem cert_e302796633798 : check e302796633798 [[],[]] .three = true := by decide
def e302796633838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e302796633838 : Closed e302796633838 ∧ code e302796633838 = 1402308261614 := by decide
theorem cert_e302796633838 : check e302796633838 [[],[]] .three = true := by decide
def e302796633882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302796633882 : Closed e302796633882 ∧ code e302796633882 = 1402308261658 := by decide
theorem cert_e302796633882 : check e302796633882 [[],[]] .three = true := by decide
def e302796633926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302796633926 : Closed e302796633926 ∧ code e302796633926 = 1402308261702 := by decide
theorem cert_e302796633926 : check e302796633926 [[],[]] .three = true := by decide
def e302796633950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e302796633950 : Closed e302796633950 ∧ code e302796633950 = 1402308261726 := by decide
theorem cert_e302796633950 : check e302796633950 [[],[]] .three = true := by decide
def e302796633966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e302796633966 : Closed e302796633966 ∧ code e302796633966 = 1402308261742 := by decide
theorem cert_e302796633966 : check e302796633966 [[],[]] .three = true := by decide
def e302796633974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e302796633974 : Closed e302796633974 ∧ code e302796633974 = 1402308261750 := by decide
theorem cert_e302796633974 : check e302796633974 [[],[]] .three = true := by decide
def e302796633978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e302796633978 : Closed e302796633978 ∧ code e302796633978 = 1402308261754 := by decide
theorem cert_e302796633978 : check e302796633978 [[],[]] .three = true := by decide
def e302796634030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e302796634030 : Closed e302796634030 ∧ code e302796634030 = 1402308261806 := by decide
private def t_e302796634030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 2)))))))
theorem cert_e302796634030 : ¬ IsSelfInterpreter e302796634030 :=
  wSource (t := t_e302796634030) (replay_sound (ps := []) (t := e302796634030) (by decide)) (by decide)
def e302796634042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e302796634042 : Closed e302796634042 ∧ code e302796634042 = 1402308261818 := by decide
private def t_e302796634042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 2)) (.var 0)))))))
theorem cert_e302796634042 : ¬ IsSelfInterpreter e302796634042 :=
  wSource (t := t_e302796634042) (replay_sound (ps := []) (t := e302796634042) (by decide)) (by decide)
def e302796643806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 3)))))))
theorem wire_e302796643806 : Closed e302796643806 ∧ code e302796643806 = 1402308271582 := by decide
theorem cert_e302796643806 : check e302796643806 [[],[]] .three = true := by decide
def e302796643830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 4)))) (.var 1)))))))
theorem wire_e302796643830 : Closed e302796643830 ∧ code e302796643830 = 1402308271606 := by decide
theorem cert_e302796643830 : check e302796643830 [[],[]] .three = true := by decide
def e302796644062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 3)))))))
theorem wire_e302796644062 : Closed e302796644062 ∧ code e302796644062 = 1402308271838 := by decide
theorem cert_e302796644062 : check e302796644062 [[],[]] .three = true := by decide
def e302796644078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 2)))))))
theorem wire_e302796644078 : Closed e302796644078 ∧ code e302796644078 = 1402308271854 := by decide
theorem cert_e302796644078 : check e302796644078 [[],[]] .smaller = true := by decide
def e302796644086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 1)))))))
theorem wire_e302796644086 : Closed e302796644086 ∧ code e302796644086 = 1402308271862 := by decide
theorem cert_e302796644086 : check e302796644086 [[],[]] .smaller = true := by decide
def e302796644090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 4)))) (.var 0)))))))
theorem wire_e302796644090 : Closed e302796644090 ∧ code e302796644090 = 1402308271866 := by decide
theorem cert_e302796644090 : check e302796644090 [[],[]] .three = true := by decide
def e302796644214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 1)))))))
theorem wire_e302796644214 : Closed e302796644214 ∧ code e302796644214 = 1402308271990 := by decide
theorem cert_e302796644214 : check e302796644214 [[],[]] .smaller = true := by decide
def e302796644278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 1)))) (.var 1)))))))
theorem wire_e302796644278 : Closed e302796644278 ∧ code e302796644278 = 1402308272054 := by decide
theorem cert_e302796644278 : check e302796644278 [[],[]] .three = true := by decide
def e302796644282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 2)))) (.var 0)))))))
theorem wire_e302796644282 : Closed e302796644282 ∧ code e302796644282 = 1402308272058 := by decide
theorem cert_e302796644282 : check e302796644282 [[],[]] .three = true := by decide
def e302796649438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 3))))))))
theorem wire_e302796649438 : Closed e302796649438 ∧ code e302796649438 = 1402308277214 := by decide
theorem cert_e302796649438 : check e302796649438 [[],[]] .three = true := by decide
def e302796649454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.var 2))))))))
theorem wire_e302796649454 : Closed e302796649454 ∧ code e302796649454 = 1402308277230 := by decide
theorem cert_e302796649454 : check e302796649454 [[],[]] .three = true := by decide
def e302796650974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 3))))))))
theorem wire_e302796650974 : Closed e302796650974 ∧ code e302796650974 = 1402308278750 := by decide
theorem cert_e302796650974 : check e302796650974 [[],[]] .three = true := by decide
def e302796650990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2))))))))
theorem wire_e302796650990 : Closed e302796650990 ∧ code e302796650990 = 1402308278766 := by decide
theorem cert_e302796650990 : check e302796650990 [[],[]] .smaller = true := by decide
def e302796650998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.var 1))))))))
theorem wire_e302796650998 : Closed e302796650998 ∧ code e302796650998 = 1402308278774 := by decide
theorem cert_e302796650998 : check e302796650998 [[],[]] .three = true := by decide
def e302796651742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 3))))))))
theorem wire_e302796651742 : Closed e302796651742 ∧ code e302796651742 = 1402308279518 := by decide
theorem cert_e302796651742 : check e302796651742 [[],[]] .three = true := by decide
def e302796651758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2))))))))
theorem wire_e302796651758 : Closed e302796651758 ∧ code e302796651758 = 1402308279534 := by decide
theorem cert_e302796651758 : check e302796651758 [[],[]] .smaller = true := by decide
def e302796651766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1))))))))
theorem wire_e302796651766 : Closed e302796651766 ∧ code e302796651766 = 1402308279542 := by decide
theorem cert_e302796651766 : check e302796651766 [[],[]] .smaller = true := by decide
def e302796651770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 3) (.var 0))))))))
theorem wire_e302796651770 : Closed e302796651770 ∧ code e302796651770 = 1402308279546 := by decide
theorem cert_e302796651770 : check e302796651770 [[],[]] .three = true := by decide
def e302796652142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.var 2))))))))
theorem wire_e302796652142 : Closed e302796652142 ∧ code e302796652142 = 1402308279918 := by decide
theorem cert_e302796652142 : check e302796652142 [[],[]] .three = true := by decide
def e302796652150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.var 1))))))))
theorem wire_e302796652150 : Closed e302796652150 ∧ code e302796652150 = 1402308279926 := by decide
theorem cert_e302796652150 : check e302796652150 [[],[]] .three = true := by decide
def e302796652154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 2) (.var 0))))))))
theorem wire_e302796652154 : Closed e302796652154 ∧ code e302796652154 = 1402308279930 := by decide
theorem cert_e302796652154 : check e302796652154 [[],[]] .three = true := by decide
def e302796659422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e302796659422 : Closed e302796659422 ∧ code e302796659422 = 1402308287198 := by decide
theorem cert_e302796659422 : check e302796659422 [[],[]] .three = true := by decide
def e302796659446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e302796659446 : Closed e302796659446 ∧ code e302796659446 = 1402308287222 := by decide
theorem cert_e302796659446 : check e302796659446 [[],[]] .three = true := by decide
def e302796659550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e302796659550 : Closed e302796659550 ∧ code e302796659550 = 1402308287326 := by decide
theorem cert_e302796659550 : check e302796659550 [[],[]] .three = true := by decide
def e302796659566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2)))))))
theorem wire_e302796659566 : Closed e302796659566 ∧ code e302796659566 = 1402308287342 := by decide
theorem cert_e302796659566 : check e302796659566 [[],[]] .smaller = true := by decide
def e302796659574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1)))))))
theorem wire_e302796659574 : Closed e302796659574 ∧ code e302796659574 = 1402308287350 := by decide
theorem cert_e302796659574 : check e302796659574 [[],[]] .smaller = true := by decide
def e302796659578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e302796659578 : Closed e302796659578 ∧ code e302796659578 = 1402308287354 := by decide
theorem cert_e302796659578 : check e302796659578 [[],[]] .three = true := by decide
def e302796659638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1)))))))
theorem wire_e302796659638 : Closed e302796659638 ∧ code e302796659638 = 1402308287414 := by decide
theorem cert_e302796659638 : check e302796659638 [[],[]] .smaller = true := by decide
def e302796659670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e302796659670 : Closed e302796659670 ∧ code e302796659670 = 1402308287446 := by decide
theorem cert_e302796659670 : check e302796659670 [[],[]] .three = true := by decide
def e302796659674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e302796659674 : Closed e302796659674 ∧ code e302796659674 = 1402308287450 := by decide
theorem cert_e302796659674 : check e302796659674 [[],[]] .three = true := by decide
def e302796660062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e302796660062 : Closed e302796660062 ∧ code e302796660062 = 1402308287838 := by decide
theorem cert_e302796660062 : check e302796660062 [[],[]] .three = true := by decide
def e302796660078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e302796660078 : Closed e302796660078 ∧ code e302796660078 = 1402308287854 := by decide
theorem cert_e302796660078 : check e302796660078 [[],[]] .smaller = true := by decide
def e302796660086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e302796660086 : Closed e302796660086 ∧ code e302796660086 = 1402308287862 := by decide
theorem cert_e302796660086 : check e302796660086 [[],[]] .smaller = true := by decide
def e302796660090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e302796660090 : Closed e302796660090 ∧ code e302796660090 = 1402308287866 := by decide
theorem cert_e302796660090 : check e302796660090 [[],[]] .three = true := by decide
def e302796660142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e302796660142 : Closed e302796660142 ∧ code e302796660142 = 1402308287918 := by decide
theorem cert_e302796660142 : check e302796660142 [[],[]] .smaller = true := by decide
def e302796660154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e302796660154 : Closed e302796660154 ∧ code e302796660154 = 1402308287930 := by decide
theorem cert_e302796660154 : check e302796660154 [[],[]] .smaller = true := by decide
def e302796660182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e302796660182 : Closed e302796660182 ∧ code e302796660182 = 1402308287958 := by decide
theorem cert_e302796660182 : check e302796660182 [[],[]] .smaller = true := by decide
def e302796660186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e302796660186 : Closed e302796660186 ∧ code e302796660186 = 1402308287962 := by decide
theorem cert_e302796660186 : check e302796660186 [[],[]] .smaller = true := by decide
def e302796660202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e302796660202 : Closed e302796660202 ∧ code e302796660202 = 1402308287978 := by decide
theorem cert_e302796660202 : check e302796660202 [[],[]] .three = true := by decide
def e302796660406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e302796660406 : Closed e302796660406 ∧ code e302796660406 = 1402308288182 := by decide
theorem cert_e302796660406 : check e302796660406 [[],[]] .smaller = true := by decide
def e302796660438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e302796660438 : Closed e302796660438 ∧ code e302796660438 = 1402308288214 := by decide
theorem cert_e302796660438 : check e302796660438 [[],[]] .smaller = true := by decide
def e302796660442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e302796660442 : Closed e302796660442 ∧ code e302796660442 = 1402308288218 := by decide
theorem cert_e302796660442 : check e302796660442 [[],[]] .smaller = true := by decide
def e302796660566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e302796660566 : Closed e302796660566 ∧ code e302796660566 = 1402308288342 := by decide
theorem cert_e302796660566 : check e302796660566 [[],[]] .three = true := by decide
def e302796660570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e302796660570 : Closed e302796660570 ∧ code e302796660570 = 1402308288346 := by decide
theorem cert_e302796660570 : check e302796660570 [[],[]] .three = true := by decide
def e302796660586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e302796660586 : Closed e302796660586 ∧ code e302796660586 = 1402308288362 := by decide
theorem cert_e302796660586 : check e302796660586 [[],[]] .three = true := by decide
def e302796661726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 3)))))))
theorem wire_e302796661726 : Closed e302796661726 ∧ code e302796661726 = 1402308289502 := by decide
theorem cert_e302796661726 : check e302796661726 [[],[]] .three = true := by decide
end Blc.Floor40
