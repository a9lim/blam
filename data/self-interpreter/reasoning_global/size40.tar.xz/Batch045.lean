import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302801057222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e302801057222 : Closed e302801057222 ∧ code e302801057222 = 1402312684998 := by decide
theorem cert_e302801057222 : check e302801057222 [[],[]] .chain = true := by decide
def e302801057326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e302801057326 : Closed e302801057326 ∧ code e302801057326 = 1402312685102 := by decide
theorem cert_e302801057326 : check e302801057326 [[],[]] .chain = true := by decide
def e302801057506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e302801057506 : Closed e302801057506 ∧ code e302801057506 = 1402312685282 := by decide
theorem cert_e302801057506 : check e302801057506 [[],[]] .chain = true := by decide
def e302801057518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 2))))))
theorem wire_e302801057518 : Closed e302801057518 ∧ code e302801057518 = 1402312685294 := by decide
theorem cert_e302801057518 : check e302801057518 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801057558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e302801057558 : Closed e302801057558 ∧ code e302801057558 = 1402312685334 := by decide
theorem cert_e302801057558 : check e302801057558 [[],[]] .chain = true := by decide
def e302801057562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302801057562 : Closed e302801057562 ∧ code e302801057562 = 1402312685338 := by decide
theorem cert_e302801057562 : check e302801057562 [[],[]] .chain = true := by decide
def e302801057606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302801057606 : Closed e302801057606 ∧ code e302801057606 = 1402312685382 := by decide
theorem cert_e302801057606 : check e302801057606 [[],[]] .chain = true := by decide
def e302801057634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e302801057634 : Closed e302801057634 ∧ code e302801057634 = 1402312685410 := by decide
theorem cert_e302801057634 : check e302801057634 [[],[]] .chain = true := by decide
def e302801057646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 2))))))
theorem wire_e302801057646 : Closed e302801057646 ∧ code e302801057646 = 1402312685422 := by decide
theorem cert_e302801057646 : check e302801057646 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801057654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 1))))))
theorem wire_e302801057654 : Closed e302801057654 ∧ code e302801057654 = 1402312685430 := by decide
theorem cert_e302801057654 : check e302801057654 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801057974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 1))))))
theorem wire_e302801057974 : Closed e302801057974 ∧ code e302801057974 = 1402312685750 := by decide
theorem cert_e302801057974 : check e302801057974 [[],[]] .chain = true := by decide
def e302801058006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.var 1))))))
theorem wire_e302801058006 : Closed e302801058006 ∧ code e302801058006 = 1402312685782 := by decide
theorem cert_e302801058006 : check e302801058006 [[],[]] .chain = true := by decide
def e302801058010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))) (.var 0))))))
theorem wire_e302801058010 : Closed e302801058010 ∧ code e302801058010 = 1402312685786 := by decide
theorem cert_e302801058010 : check e302801058010 [[],[]] .chain = true := by decide
def e302801058026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e302801058026 : Closed e302801058026 ∧ code e302801058026 = 1402312685802 := by decide
theorem cert_e302801058026 : check e302801058026 [[],[]] .chain = true := by decide
def e302801058358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e302801058358 : Closed e302801058358 ∧ code e302801058358 = 1402312686134 := by decide
theorem cert_e302801058358 : check e302801058358 [[],[]] .chain = true := by decide
def e302801058362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e302801058362 : Closed e302801058362 ∧ code e302801058362 = 1402312686138 := by decide
theorem cert_e302801058362 : check e302801058362 [[],[]] .chain = true := by decide
def e302801058446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e302801058446 : Closed e302801058446 ∧ code e302801058446 = 1402312686222 := by decide
theorem cert_e302801058446 : check e302801058446 [[],[]] .chain = true := by decide
def e302801058502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e302801058502 : Closed e302801058502 ∧ code e302801058502 = 1402312686278 := by decide
theorem cert_e302801058502 : check e302801058502 [[],[]] .chain = true := by decide
def e302801058582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e302801058582 : Closed e302801058582 ∧ code e302801058582 = 1402312686358 := by decide
theorem cert_e302801058582 : check e302801058582 [[],[]] .chain = true := by decide
def e302801058586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302801058586 : Closed e302801058586 ∧ code e302801058586 = 1402312686362 := by decide
theorem cert_e302801058586 : check e302801058586 [[],[]] .chain = true := by decide
def e302801058630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302801058630 : Closed e302801058630 ∧ code e302801058630 = 1402312686406 := by decide
theorem cert_e302801058630 : check e302801058630 [[],[]] .chain = true := by decide
def e302801058658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e302801058658 : Closed e302801058658 ∧ code e302801058658 = 1402312686434 := by decide
theorem cert_e302801058658 : check e302801058658 [[],[]] .chain = true := by decide
def e302801058670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e302801058670 : Closed e302801058670 ∧ code e302801058670 = 1402312686446 := by decide
theorem cert_e302801058670 : check e302801058670 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302801058678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e302801058678 : Closed e302801058678 ∧ code e302801058678 = 1402312686454 := by decide
theorem cert_e302801058678 : check e302801058678 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302801058742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e302801058742 : Closed e302801058742 ∧ code e302801058742 = 1402312686518 := by decide
theorem cert_e302801058742 : check e302801058742 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e302801061614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e302801061614 : Closed e302801061614 ∧ code e302801061614 = 1402312689390 := by decide
theorem cert_e302801061614 : check e302801061614 [[],[]] .chain = true := by decide
def e302801061622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))) (.var 1))))))
theorem wire_e302801061622 : Closed e302801061622 ∧ code e302801061622 = 1402312689398 := by decide
theorem cert_e302801061622 : check e302801061622 [[],[]] .chain = true := by decide
def e302801061806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e302801061806 : Closed e302801061806 ∧ code e302801061806 = 1402312689582 := by decide
theorem cert_e302801061806 : check e302801061806 [[],[]] .chain = true := by decide
def e302801061846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))) (.var 1))))))
theorem wire_e302801061846 : Closed e302801061846 ∧ code e302801061846 = 1402312689622 := by decide
theorem cert_e302801061846 : check e302801061846 [[],[]] .chain = true := by decide
def e302801063150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e302801063150 : Closed e302801063150 ∧ code e302801063150 = 1402312690926 := by decide
theorem cert_e302801063150 : check e302801063150 [[],[]] .chain = true := by decide
def e302801063158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e302801063158 : Closed e302801063158 ∧ code e302801063158 = 1402312690934 := by decide
theorem cert_e302801063158 : check e302801063158 [[],[]] .chain = true := by decide
def e302801063534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e302801063534 : Closed e302801063534 ∧ code e302801063534 = 1402312691310 := by decide
theorem cert_e302801063534 : check e302801063534 [[],[]] .chain = true := by decide
def e302801063546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e302801063546 : Closed e302801063546 ∧ code e302801063546 = 1402312691322 := by decide
theorem cert_e302801063546 : check e302801063546 [[],[]] .chain = true := by decide
def e302801063734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e302801063734 : Closed e302801063734 ∧ code e302801063734 = 1402312691510 := by decide
theorem cert_e302801063734 : check e302801063734 [[],[]] .chain = true := by decide
def e302801063738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e302801063738 : Closed e302801063738 ∧ code e302801063738 = 1402312691514 := by decide
theorem cert_e302801063738 : check e302801063738 [[],[]] .chain = true := by decide
def e302801066222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.var 2))))))
theorem wire_e302801066222 : Closed e302801066222 ∧ code e302801066222 = 1402312693998 := by decide
theorem cert_e302801066222 : check e302801066222 [[],[]] .chain = true := by decide
def e302801066230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))) (.var 1))))))
theorem wire_e302801066230 : Closed e302801066230 ∧ code e302801066230 = 1402312694006 := by decide
theorem cert_e302801066230 : check e302801066230 [[],[]] .chain = true := by decide
def e302801066782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e302801066782 : Closed e302801066782 ∧ code e302801066782 = 1402312694558 := by decide
theorem cert_e302801066782 : check e302801066782 [[],[]] .chain = true := by decide
def e302801066894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e302801066894 : Closed e302801066894 ∧ code e302801066894 = 1402312694670 := by decide
theorem cert_e302801066894 : check e302801066894 [[],[]] .chain = true := by decide
def e302801067118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.var 2))))))
theorem wire_e302801067118 : Closed e302801067118 ∧ code e302801067118 = 1402312694894 := by decide
theorem cert_e302801067118 : check e302801067118 [[],[]] .chain = true := by decide
def e302801067130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))) (.var 0))))))
theorem wire_e302801067130 : Closed e302801067130 ∧ code e302801067130 = 1402312694906 := by decide
theorem cert_e302801067130 : check e302801067130 [[],[]] .chain = true := by decide
def e302801067294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e302801067294 : Closed e302801067294 ∧ code e302801067294 = 1402312695070 := by decide
theorem cert_e302801067294 : check e302801067294 [[],[]] .chain = true := by decide
def e302801067462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e302801067462 : Closed e302801067462 ∧ code e302801067462 = 1402312695238 := by decide
theorem cert_e302801067462 : check e302801067462 [[],[]] .chain = true := by decide
def e302801067574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.var 1))))))
theorem wire_e302801067574 : Closed e302801067574 ∧ code e302801067574 = 1402312695350 := by decide
theorem cert_e302801067574 : check e302801067574 [[],[]] .chain = true := by decide
def e302801067578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))) (.var 0))))))
theorem wire_e302801067578 : Closed e302801067578 ∧ code e302801067578 = 1402312695354 := by decide
theorem cert_e302801067578 : check e302801067578 [[],[]] .chain = true := by decide
def e302801067662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e302801067662 : Closed e302801067662 ∧ code e302801067662 = 1402312695438 := by decide
theorem cert_e302801067662 : check e302801067662 [[],[]] .chain = true := by decide
def e302801067718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e302801067718 : Closed e302801067718 ∧ code e302801067718 = 1402312695494 := by decide
theorem cert_e302801067718 : check e302801067718 [[],[]] .chain = true := by decide
def e302801069854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e302801069854 : Closed e302801069854 ∧ code e302801069854 = 1402312697630 := by decide
theorem cert_e302801069854 : check e302801069854 [[],[]] .chain = true := by decide
def e302801069966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e302801069966 : Closed e302801069966 ∧ code e302801069966 = 1402312697742 := by decide
theorem cert_e302801069966 : check e302801069966 [[],[]] .chain = true := by decide
def e302801072350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e302801072350 : Closed e302801072350 ∧ code e302801072350 = 1402312700126 := by decide
theorem cert_e302801072350 : check e302801072350 [[],[]] .chain = true := by decide
def e302801072378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e302801072378 : Closed e302801072378 ∧ code e302801072378 = 1402312700154 := by decide
theorem cert_e302801072378 : check e302801072378 [[],[]] .chain = true := by decide
def e302801072926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e302801072926 : Closed e302801072926 ∧ code e302801072926 = 1402312700702 := by decide
theorem cert_e302801072926 : check e302801072926 [[],[]] .chain = true := by decide
def e302801073094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e302801073094 : Closed e302801073094 ∧ code e302801073094 = 1402312700870 := by decide
theorem cert_e302801073094 : check e302801073094 [[],[]] .chain = true := by decide
def e302801074286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e302801074286 : Closed e302801074286 ∧ code e302801074286 = 1402312702062 := by decide
theorem cert_e302801074286 : check e302801074286 [[],[]] .chain = true := by decide
def e302801074298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e302801074298 : Closed e302801074298 ∧ code e302801074298 = 1402312702074 := by decide
theorem cert_e302801074298 : check e302801074298 [[],[]] .chain = true := by decide
def e302801074574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e302801074574 : Closed e302801074574 ∧ code e302801074574 = 1402312702350 := by decide
theorem cert_e302801074574 : check e302801074574 [[],[]] .chain = true := by decide
def e302801074630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e302801074630 : Closed e302801074630 ∧ code e302801074630 = 1402312702406 := by decide
theorem cert_e302801074630 : check e302801074630 [[],[]] .chain = true := by decide
def e302801076718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e302801076718 : Closed e302801076718 ∧ code e302801076718 = 1402312704494 := by decide
theorem cert_e302801076718 : check e302801076718 [[],[]] .chain = true := by decide
def e302801076726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e302801076726 : Closed e302801076726 ∧ code e302801076726 = 1402312704502 := by decide
theorem cert_e302801076726 : check e302801076726 [[],[]] .chain = true := by decide
def e302801077102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e302801077102 : Closed e302801077102 ∧ code e302801077102 = 1402312704878 := by decide
theorem cert_e302801077102 : check e302801077102 [[],[]] .chain = true := by decide
def e302801077114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e302801077114 : Closed e302801077114 ∧ code e302801077114 = 1402312704890 := by decide
theorem cert_e302801077114 : check e302801077114 [[],[]] .chain = true := by decide
def e302801077166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e302801077166 : Closed e302801077166 ∧ code e302801077166 = 1402312704942 := by decide
theorem cert_e302801077166 : check e302801077166 [[],[]] .chain = true := by decide
def e302801077226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e302801077226 : Closed e302801077226 ∧ code e302801077226 = 1402312705002 := by decide
theorem cert_e302801077226 : check e302801077226 [[],[]] .chain = true := by decide
def e302801077486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e302801077486 : Closed e302801077486 ∧ code e302801077486 = 1402312705262 := by decide
theorem cert_e302801077486 : check e302801077486 [[],[]] .chain = true := by decide
def e302801077494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e302801077494 : Closed e302801077494 ∧ code e302801077494 = 1402312705270 := by decide
theorem cert_e302801077494 : check e302801077494 [[],[]] .chain = true := by decide
def e302801077870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e302801077870 : Closed e302801077870 ∧ code e302801077870 = 1402312705646 := by decide
theorem cert_e302801077870 : check e302801077870 [[],[]] .chain = true := by decide
def e302801077882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e302801077882 : Closed e302801077882 ∧ code e302801077882 = 1402312705658 := by decide
theorem cert_e302801077882 : check e302801077882 [[],[]] .chain = true := by decide
def e302801078046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e302801078046 : Closed e302801078046 ∧ code e302801078046 = 1402312705822 := by decide
theorem cert_e302801078046 : check e302801078046 [[],[]] .chain = true := by decide
def e302801078158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e302801078158 : Closed e302801078158 ∧ code e302801078158 = 1402312705934 := by decide
theorem cert_e302801078158 : check e302801078158 [[],[]] .chain = true := by decide
def e302801078170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e302801078170 : Closed e302801078170 ∧ code e302801078170 = 1402312705946 := by decide
theorem cert_e302801078170 : check e302801078170 [[],[]] .chain = true := by decide
def e302801079406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.var 2))))))
theorem wire_e302801079406 : Closed e302801079406 ∧ code e302801079406 = 1402312707182 := by decide
theorem cert_e302801079406 : check e302801079406 [[],[]] .chain = true := by decide
def e302801079418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))) (.var 0))))))
theorem wire_e302801079418 : Closed e302801079418 ∧ code e302801079418 = 1402312707194 := by decide
theorem cert_e302801079418 : check e302801079418 [[],[]] .chain = true := by decide
def e302801079582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e302801079582 : Closed e302801079582 ∧ code e302801079582 = 1402312707358 := by decide
theorem cert_e302801079582 : check e302801079582 [[],[]] .chain = true := by decide
def e302801079750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e302801079750 : Closed e302801079750 ∧ code e302801079750 = 1402312707526 := by decide
theorem cert_e302801079750 : check e302801079750 [[],[]] .chain = true := by decide
def e302801079854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e302801079854 : Closed e302801079854 ∧ code e302801079854 = 1402312707630 := by decide
theorem cert_e302801079854 : check e302801079854 [[],[]] .chain = true := by decide
def e302801080034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e302801080034 : Closed e302801080034 ∧ code e302801080034 = 1402312707810 := by decide
theorem cert_e302801080034 : check e302801080034 [[],[]] .chain = true := by decide
def e302801080046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e302801080046 : Closed e302801080046 ∧ code e302801080046 = 1402312707822 := by decide
theorem cert_e302801080046 : check e302801080046 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801080086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e302801080086 : Closed e302801080086 ∧ code e302801080086 = 1402312707862 := by decide
theorem cert_e302801080086 : check e302801080086 [[],[]] .chain = true := by decide
def e302801080090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))) (.var 0))))))
theorem wire_e302801080090 : Closed e302801080090 ∧ code e302801080090 = 1402312707866 := by decide
theorem cert_e302801080090 : check e302801080090 [[],[]] .chain = true := by decide
def e302801080134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e302801080134 : Closed e302801080134 ∧ code e302801080134 = 1402312707910 := by decide
theorem cert_e302801080134 : check e302801080134 [[],[]] .chain = true := by decide
def e302801080162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e302801080162 : Closed e302801080162 ∧ code e302801080162 = 1402312707938 := by decide
theorem cert_e302801080162 : check e302801080162 [[],[]] .chain = true := by decide
def e302801080174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e302801080174 : Closed e302801080174 ∧ code e302801080174 = 1402312707950 := by decide
theorem cert_e302801080174 : check e302801080174 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801080182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e302801080182 : Closed e302801080182 ∧ code e302801080182 = 1402312707958 := by decide
theorem cert_e302801080182 : check e302801080182 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801080542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e302801080542 : Closed e302801080542 ∧ code e302801080542 = 1402312708318 := by decide
theorem cert_e302801080542 : check e302801080542 [[],[]] .chain = true := by decide
def e302801080570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e302801080570 : Closed e302801080570 ∧ code e302801080570 = 1402312708346 := by decide
theorem cert_e302801080570 : check e302801080570 [[],[]] .chain = true := by decide
def e302801081118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e302801081118 : Closed e302801081118 ∧ code e302801081118 = 1402312708894 := by decide
theorem cert_e302801081118 : check e302801081118 [[],[]] .chain = true := by decide
def e302801081286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e302801081286 : Closed e302801081286 ∧ code e302801081286 = 1402312709062 := by decide
theorem cert_e302801081286 : check e302801081286 [[],[]] .chain = true := by decide
def e302801082430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e302801082430 : Closed e302801082430 ∧ code e302801082430 = 1402312710206 := by decide
theorem cert_e302801082430 : check e302801082430 [[],[]] .chain = true := by decide
def e302801082850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e302801082850 : Closed e302801082850 ∧ code e302801082850 = 1402312710626 := by decide
theorem cert_e302801082850 : check e302801082850 [[],[]] .chain = true := by decide
def e302801082862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e302801082862 : Closed e302801082862 ∧ code e302801082862 = 1402312710638 := by decide
theorem cert_e302801082862 : check e302801082862 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801083422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e302801083422 : Closed e302801083422 ∧ code e302801083422 = 1402312711198 := by decide
theorem cert_e302801083422 : check e302801083422 [[],[]] .chain = true := by decide
def e302801083446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e302801083446 : Closed e302801083446 ∧ code e302801083446 = 1402312711222 := by decide
theorem cert_e302801083446 : check e302801083446 [[],[]] .chain = true := by decide
def e302801083450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e302801083450 : Closed e302801083450 ∧ code e302801083450 = 1402312711226 := by decide
theorem cert_e302801083450 : check e302801083450 [[],[]] .chain = true := by decide
def e302801083590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302801083590 : Closed e302801083590 ∧ code e302801083590 = 1402312711366 := by decide
theorem cert_e302801083590 : check e302801083590 [[],[]] .chain = true := by decide
def e302801083618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e302801083618 : Closed e302801083618 ∧ code e302801083618 = 1402312711394 := by decide
theorem cert_e302801083618 : check e302801083618 [[],[]] .chain = true := by decide
def e302801083630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e302801083630 : Closed e302801083630 ∧ code e302801083630 = 1402312711406 := by decide
theorem cert_e302801083630 : check e302801083630 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801083638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e302801083638 : Closed e302801083638 ∧ code e302801083638 = 1402312711414 := by decide
theorem cert_e302801083638 : check e302801083638 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e302801084662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 1))))))
theorem wire_e302801084662 : Closed e302801084662 ∧ code e302801084662 = 1402312712438 := by decide
theorem cert_e302801084662 : check e302801084662 [[],[]] .chain = true := by decide
def e302801084854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e302801084854 : Closed e302801084854 ∧ code e302801084854 = 1402312712630 := by decide
theorem cert_e302801084854 : check e302801084854 [[],[]] .chain = true := by decide
def e302801084858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e302801084858 : Closed e302801084858 ∧ code e302801084858 = 1402312712634 := by decide
theorem cert_e302801084858 : check e302801084858 [[],[]] .chain = true := by decide
def e302801084886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e302801084886 : Closed e302801084886 ∧ code e302801084886 = 1402312712662 := by decide
theorem cert_e302801084886 : check e302801084886 [[],[]] .chain = true := by decide
def e302801084906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e302801084906 : Closed e302801084906 ∧ code e302801084906 = 1402312712682 := by decide
theorem cert_e302801084906 : check e302801084906 [[],[]] .chain = true := by decide
def e302801085046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 1)))))))
theorem wire_e302801085046 : Closed e302801085046 ∧ code e302801085046 = 1402312712822 := by decide
theorem cert_e302801085046 : check e302801085046 [[],[]] .chain = true := by decide
def e302801085238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e302801085238 : Closed e302801085238 ∧ code e302801085238 = 1402312713014 := by decide
theorem cert_e302801085238 : check e302801085238 [[],[]] .chain = true := by decide
def e302801085242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e302801085242 : Closed e302801085242 ∧ code e302801085242 = 1402312713018 := by decide
theorem cert_e302801085242 : check e302801085242 [[],[]] .chain = true := by decide
def e302801085326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 2)))))))
theorem wire_e302801085326 : Closed e302801085326 ∧ code e302801085326 = 1402312713102 := by decide
theorem cert_e302801085326 : check e302801085326 [[],[]] .chain = true := by decide
def e302801085338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e302801085338 : Closed e302801085338 ∧ code e302801085338 = 1402312713114 := by decide
theorem cert_e302801085338 : check e302801085338 [[],[]] .chain = true := by decide
def e302801086006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.var 1))))))
theorem wire_e302801086006 : Closed e302801086006 ∧ code e302801086006 = 1402312713782 := by decide
theorem cert_e302801086006 : check e302801086006 [[],[]] .chain = true := by decide
def e302801086010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))) (.var 0))))))
theorem wire_e302801086010 : Closed e302801086010 ∧ code e302801086010 = 1402312713786 := by decide
theorem cert_e302801086010 : check e302801086010 [[],[]] .chain = true := by decide
def e302801086094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e302801086094 : Closed e302801086094 ∧ code e302801086094 = 1402312713870 := by decide
theorem cert_e302801086094 : check e302801086094 [[],[]] .chain = true := by decide
def e302801086150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e302801086150 : Closed e302801086150 ∧ code e302801086150 = 1402312713926 := by decide
theorem cert_e302801086150 : check e302801086150 [[],[]] .chain = true := by decide
def e302801086230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 1))))))
theorem wire_e302801086230 : Closed e302801086230 ∧ code e302801086230 = 1402312714006 := by decide
theorem cert_e302801086230 : check e302801086230 [[],[]] .chain = true := by decide
def e302801086234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))) (.var 0))))))
theorem wire_e302801086234 : Closed e302801086234 ∧ code e302801086234 = 1402312714010 := by decide
theorem cert_e302801086234 : check e302801086234 [[],[]] .chain = true := by decide
def e302801086278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e302801086278 : Closed e302801086278 ∧ code e302801086278 = 1402312714054 := by decide
theorem cert_e302801086278 : check e302801086278 [[],[]] .chain = true := by decide
def e302801086306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e302801086306 : Closed e302801086306 ∧ code e302801086306 = 1402312714082 := by decide
theorem cert_e302801086306 : check e302801086306 [[],[]] .chain = true := by decide
def e302801086318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e302801086318 : Closed e302801086318 ∧ code e302801086318 = 1402312714094 := by decide
theorem cert_e302801086318 : check e302801086318 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e302801086326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e302801086326 : Closed e302801086326 ∧ code e302801086326 = 1402312714102 := by decide
theorem cert_e302801086326 : check e302801086326 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e302801086390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e302801086390 : Closed e302801086390 ∧ code e302801086390 = 1402312714166 := by decide
theorem cert_e302801086390 : check e302801086390 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e302801086574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e302801086574 : Closed e302801086574 ∧ code e302801086574 = 1402312714350 := by decide
theorem cert_e302801086574 : check e302801086574 [[],[]] .chain = true := by decide
def e302801086586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e302801086586 : Closed e302801086586 ∧ code e302801086586 = 1402312714362 := by decide
theorem cert_e302801086586 : check e302801086586 [[],[]] .chain = true := by decide
def e302801086862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e302801086862 : Closed e302801086862 ∧ code e302801086862 = 1402312714638 := by decide
theorem cert_e302801086862 : check e302801086862 [[],[]] .chain = true := by decide
def e302801086918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e302801086918 : Closed e302801086918 ∧ code e302801086918 = 1402312714694 := by decide
theorem cert_e302801086918 : check e302801086918 [[],[]] .chain = true := by decide
def e302801087518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 3))))))))
theorem wire_e302801087518 : Closed e302801087518 ∧ code e302801087518 = 1402312715294 := by decide
theorem cert_e302801087518 : check e302801087518 [[],[]] .chain = true := by decide
def e302801087542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e302801087542 : Closed e302801087542 ∧ code e302801087542 = 1402312715318 := by decide
theorem cert_e302801087542 : check e302801087542 [[],[]] .chain = true := by decide
def e302801087546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e302801087546 : Closed e302801087546 ∧ code e302801087546 = 1402312715322 := by decide
theorem cert_e302801087546 : check e302801087546 [[],[]] .chain = true := by decide
def e302801087686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302801087686 : Closed e302801087686 ∧ code e302801087686 = 1402312715462 := by decide
theorem cert_e302801087686 : check e302801087686 [[],[]] .chain = true := by decide
def e302801087714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e302801087714 : Closed e302801087714 ∧ code e302801087714 = 1402312715490 := by decide
theorem cert_e302801087714 : check e302801087714 [[],[]] .chain = true := by decide
def e302801087726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e302801087726 : Closed e302801087726 ∧ code e302801087726 = 1402312715502 := by decide
theorem cert_e302801087726 : check e302801087726 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e302801087734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e302801087734 : Closed e302801087734 ∧ code e302801087734 = 1402312715510 := by decide
theorem cert_e302801087734 : check e302801087734 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e302801088118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e302801088118 : Closed e302801088118 ∧ code e302801088118 = 1402312715894 := by decide
theorem cert_e302801088118 : check e302801088118 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e302801098462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e302801098462 : Closed e302801098462 ∧ code e302801098462 = 1402312726238 := by decide
theorem cert_e302801098462 : check e302801098462 [[],[]] .chain = true := by decide
def e302801098486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e302801098486 : Closed e302801098486 ∧ code e302801098486 = 1402312726262 := by decide
theorem cert_e302801098486 : check e302801098486 [[],[]] .chain = true := by decide
def e302801098590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e302801098590 : Closed e302801098590 ∧ code e302801098590 = 1402312726366 := by decide
theorem cert_e302801098590 : check e302801098590 [[],[]] .chain = true := by decide
def e302801098618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e302801098618 : Closed e302801098618 ∧ code e302801098618 = 1402312726394 := by decide
theorem cert_e302801098618 : check e302801098618 [[],[]] .chain = true := by decide
def e302801098710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e302801098710 : Closed e302801098710 ∧ code e302801098710 = 1402312726486 := by decide
theorem cert_e302801098710 : check e302801098710 [[],[]] .chain = true := by decide
def e302801098714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e302801098714 : Closed e302801098714 ∧ code e302801098714 = 1402312726490 := by decide
theorem cert_e302801098714 : check e302801098714 [[],[]] .chain = true := by decide
def e302801099230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e302801099230 : Closed e302801099230 ∧ code e302801099230 = 1402312727006 := by decide
theorem cert_e302801099230 : check e302801099230 [[],[]] .chain = true := by decide
def e302801099254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e302801099254 : Closed e302801099254 ∧ code e302801099254 = 1402312727030 := by decide
theorem cert_e302801099254 : check e302801099254 [[],[]] .chain = true := by decide
def e302801099998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e302801099998 : Closed e302801099998 ∧ code e302801099998 = 1402312727774 := by decide
theorem cert_e302801099998 : check e302801099998 [[],[]] .chain = true := by decide
def e302801100026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e302801100026 : Closed e302801100026 ∧ code e302801100026 = 1402312727802 := by decide
theorem cert_e302801100026 : check e302801100026 [[],[]] .chain = true := by decide
def e302801100350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e302801100350 : Closed e302801100350 ∧ code e302801100350 = 1402312728126 := by decide
theorem cert_e302801100350 : check e302801100350 [[],[]] .chain = true := by decide
def e302801100574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e302801100574 : Closed e302801100574 ∧ code e302801100574 = 1402312728350 := by decide
theorem cert_e302801100574 : check e302801100574 [[],[]] .chain = true := by decide
def e302801100598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801100598 : Closed e302801100598 ∧ code e302801100598 = 1402312728374 := by decide
theorem cert_e302801100598 : check e302801100598 [[],[]] .chain = true := by decide
def e302801100602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801100602 : Closed e302801100602 ∧ code e302801100602 = 1402312728378 := by decide
theorem cert_e302801100602 : check e302801100602 [[],[]] .chain = true := by decide
def e302801115374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e302801115374 : Closed e302801115374 ∧ code e302801115374 = 1402312743150 := by decide
theorem cert_e302801115374 : check e302801115374 [[],[]] .chain = true := by decide
def e302801115382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e302801115382 : Closed e302801115382 ∧ code e302801115382 = 1402312743158 := by decide
theorem cert_e302801115382 : check e302801115382 [[],[]] .chain = true := by decide
def e302801115934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e302801115934 : Closed e302801115934 ∧ code e302801115934 = 1402312743710 := by decide
theorem cert_e302801115934 : check e302801115934 [[],[]] .chain = true := by decide
def e302801116046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e302801116046 : Closed e302801116046 ∧ code e302801116046 = 1402312743822 := by decide
theorem cert_e302801116046 : check e302801116046 [[],[]] .chain = true := by decide
def e302801116270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302801116270 : Closed e302801116270 ∧ code e302801116270 = 1402312744046 := by decide
theorem cert_e302801116270 : check e302801116270 [[],[]] .chain = true := by decide
def e302801116282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302801116282 : Closed e302801116282 ∧ code e302801116282 = 1402312744058 := by decide
theorem cert_e302801116282 : check e302801116282 [[],[]] .chain = true := by decide
def e302801116446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302801116446 : Closed e302801116446 ∧ code e302801116446 = 1402312744222 := by decide
theorem cert_e302801116446 : check e302801116446 [[],[]] .chain = true := by decide
def e302801116614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302801116614 : Closed e302801116614 ∧ code e302801116614 = 1402312744390 := by decide
theorem cert_e302801116614 : check e302801116614 [[],[]] .chain = true := by decide
def e302801116726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302801116726 : Closed e302801116726 ∧ code e302801116726 = 1402312744502 := by decide
theorem cert_e302801116726 : check e302801116726 [[],[]] .chain = true := by decide
def e302801116730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302801116730 : Closed e302801116730 ∧ code e302801116730 = 1402312744506 := by decide
theorem cert_e302801116730 : check e302801116730 [[],[]] .chain = true := by decide
def e302801116814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302801116814 : Closed e302801116814 ∧ code e302801116814 = 1402312744590 := by decide
theorem cert_e302801116814 : check e302801116814 [[],[]] .chain = true := by decide
def e302801116870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302801116870 : Closed e302801116870 ∧ code e302801116870 = 1402312744646 := by decide
theorem cert_e302801116870 : check e302801116870 [[],[]] .chain = true := by decide
def e302801119006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e302801119006 : Closed e302801119006 ∧ code e302801119006 = 1402312746782 := by decide
theorem cert_e302801119006 : check e302801119006 [[],[]] .chain = true := by decide
def e302801119118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e302801119118 : Closed e302801119118 ∧ code e302801119118 = 1402312746894 := by decide
theorem cert_e302801119118 : check e302801119118 [[],[]] .chain = true := by decide
def e302801121502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e302801121502 : Closed e302801121502 ∧ code e302801121502 = 1402312749278 := by decide
theorem cert_e302801121502 : check e302801121502 [[],[]] .chain = true := by decide
def e302801121530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e302801121530 : Closed e302801121530 ∧ code e302801121530 = 1402312749306 := by decide
theorem cert_e302801121530 : check e302801121530 [[],[]] .chain = true := by decide
end Blc.Floor40
