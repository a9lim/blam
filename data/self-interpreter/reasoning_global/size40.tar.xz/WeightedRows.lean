import Weighted
import Batch025
import Batch027
import Batch060
import Batch061
import Batch063
namespace Blc.Floor40.WeightedRows
open Term SelfintSharp WeakHeadClock Round3Floor38
def diag := Term.lam (.app (.var 0) (.var 0))
theorem deltaCount {e : Term} (he : IsSelfInterpreter e) : ∃ n, Count (.app e diag) n := by
  obtain ⟨k,h⟩ := inputCount (e := e) (c := diag) (m := SelfintControl.identity) (r := .var 0)
    (args := []) (k := 3) he (by decide) (by decide)
  obtain ⟨m,_,hm⟩ := count_app_left h
  exact ⟨m,hm⟩
private def te301464563130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem ex_e301464563130 : ¬ IsSelfInterpreter e301464563130 := by
  intro he
  have run : replay [[]] e301464563130 = some te301464563130 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 2 (by decide : Closed te301464563130) (by decide) (by decide) h
#print axioms ex_e301464563130
private def te301464563386 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e301464563386 : ¬ IsSelfInterpreter e301464563386 := by
  intro he
  have run : replay [[.left]] (.app e301464563386 diag) = some te301464563386 := by decide
  obtain ⟨_,h⟩ := clocks_replay (deltaCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te301464563386) (by decide) (by decide) h
#print axioms ex_e301464563386
private def te301464563434 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e301464563434 : ¬ IsSelfInterpreter e301464563434 := by
  intro he
  have run : replay [[.left]] (.app e301464563434 diag) = some te301464563434 := by decide
  obtain ⟨_,h⟩ := clocks_replay (deltaCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te301464563434) (by decide) (by decide) h
#print axioms ex_e301464563434
private def te301464563562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem ex_e301464563562 : ¬ IsSelfInterpreter e301464563562 := by
  intro he
  have run : replay [[]] e301464563562 = some te301464563562 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 2 (by decide : Closed te301464563562) (by decide) (by decide) h
#print axioms ex_e301464563562
private def te301464564666 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e301464564666 : ¬ IsSelfInterpreter e301464564666 := by
  intro he
  have run : replay [[.left]] (.app e301464564666 diag) = some te301464564666 := by decide
  obtain ⟨_,h⟩ := clocks_replay (deltaCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te301464564666) (by decide) (by decide) h
#print axioms ex_e301464564666
private def te301464564698 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e301464564698 : ¬ IsSelfInterpreter e301464564698 := by
  intro he
  have run : replay [[.left]] (.app e301464564698 diag) = some te301464564698 := by decide
  obtain ⟨_,h⟩ := clocks_replay (deltaCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te301464564698) (by decide) (by decide) h
#print axioms ex_e301464564698
private def te301464567002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem ex_e301464567002 : ¬ IsSelfInterpreter e301464567002 := by
  intro he
  have run : replay [[]] e301464567002 = some te301464567002 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 2 (by decide : Closed te301464567002) (by decide) (by decide) h
#print axioms ex_e301464567002
private def te301464567018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem ex_e301464567018 : ¬ IsSelfInterpreter e301464567018 := by
  intro he
  have run : replay [[]] e301464567018 = some te301464567018 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 2 (by decide : Closed te301464567018) (by decide) (by decide) h
#print axioms ex_e301464567018
private def te301464816494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem ex_e301464816494 : ¬ IsSelfInterpreter e301464816494 := by
  intro he
  have run : replay [[]] e301464816494 = some te301464816494 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 2 (by decide : Closed te301464816494) (by decide) (by decide) h
#print axioms ex_e301464816494
private def te301464816602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem ex_e301464816602 : ¬ IsSelfInterpreter e301464816602 := by
  intro he
  have run : replay [[]] e301464816602 = some te301464816602 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 2 (by decide : Closed te301464816602) (by decide) (by decide) h
#print axioms ex_e301464816602
private def te302309444538 : Term := (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e302309444538 : ¬ IsSelfInterpreter e302309444538 := by
  intro he
  have run : replay [] (.app e302309444538 diag) = some te302309444538 := by decide
  obtain ⟨_,h⟩ := clocks_replay (deltaCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302309444538) (by decide) (by decide) h
#print axioms ex_e302309444538
private def te302309444570 : Term := (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e302309444570 : ¬ IsSelfInterpreter e302309444570 := by
  intro he
  have run : replay [] (.app e302309444570 diag) = some te302309444570 := by decide
  obtain ⟨_,h⟩ := clocks_replay (deltaCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302309444570) (by decide) (by decide) h
#print axioms ex_e302309444570
private def te302887492474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))) (.var 0))))
theorem ex_e302887492474 : ¬ IsSelfInterpreter e302887492474 := by
  intro he
  have run : replay [[]] e302887492474 = some te302887492474 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 2 (by decide : Closed te302887492474) (by decide) (by decide) h
#print axioms ex_e302887492474
private def te302887493098 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e302887493098 : ¬ IsSelfInterpreter e302887493098 := by
  intro he
  have run : replay [] (.app e302887493098 diag) = some te302887493098 := by decide
  obtain ⟨_,h⟩ := clocks_replay (deltaCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302887493098) (by decide) (by decide) h
#print axioms ex_e302887493098
private def te302887493482 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e302887493482 : ¬ IsSelfInterpreter e302887493482 := by
  intro he
  have run : replay [] (.app e302887493482 diag) = some te302887493482 := by decide
  obtain ⟨_,h⟩ := clocks_replay (deltaCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302887493482) (by decide) (by decide) h
#print axioms ex_e302887493482
private def te302887562362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))) (.var 0))))
theorem ex_e302887562362 : ¬ IsSelfInterpreter e302887562362 := by
  intro he
  have run : replay [[]] e302887562362 = some te302887562362 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 2 (by decide : Closed te302887562362) (by decide) (by decide) h
#print axioms ex_e302887562362
private def te302887563706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))) (.var 0))))
theorem ex_e302887563706 : ¬ IsSelfInterpreter e302887563706 := by
  intro he
  have run : replay [] e302887563706 = some te302887563706 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302887563706) (by decide) (by decide) h
#print axioms ex_e302887563706
private def te302887563754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))) (.var 0))))
theorem ex_e302887563754 : ¬ IsSelfInterpreter e302887563754 := by
  intro he
  have run : replay [] e302887563754 = some te302887563754 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302887563754) (by decide) (by decide) h
#print axioms ex_e302887563754
private def te302887574650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))) (.var 0))))
theorem ex_e302887574650 : ¬ IsSelfInterpreter e302887574650 := by
  intro he
  have run : replay [] e302887574650 = some te302887574650 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302887574650) (by decide) (by decide) h
#print axioms ex_e302887574650
private def te302887593530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))) (.var 0))))
theorem ex_e302887593530 : ¬ IsSelfInterpreter e302887593530 := by
  intro he
  have run : replay [[]] e302887593530 = some te302887593530 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 2 (by decide : Closed te302887593530) (by decide) (by decide) h
#print axioms ex_e302887593530
private def te302887593754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))) (.var 0))))
theorem ex_e302887593754 : ¬ IsSelfInterpreter e302887593754 := by
  intro he
  have run : replay [] e302887593754 = some te302887593754 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302887593754) (by decide) (by decide) h
#print axioms ex_e302887593754
private def te302888258414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem ex_e302888258414 : ¬ IsSelfInterpreter e302888258414 := by
  intro he
  have run : replay [[]] e302888258414 = some te302888258414 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 2 (by decide : Closed te302888258414) (by decide) (by decide) h
#print axioms ex_e302888258414
private def te302888258490 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e302888258490 : ¬ IsSelfInterpreter e302888258490 := by
  intro he
  have run : replay [] (.app e302888258490 diag) = some te302888258490 := by decide
  obtain ⟨_,h⟩ := clocks_replay (deltaCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302888258490) (by decide) (by decide) h
#print axioms ex_e302888258490
private def te302888258522 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e302888258522 : ¬ IsSelfInterpreter e302888258522 := by
  intro he
  have run : replay [] (.app e302888258522 diag) = some te302888258522 := by decide
  obtain ⟨_,h⟩ := clocks_replay (deltaCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302888258522) (by decide) (by decide) h
#print axioms ex_e302888258522
private def te302897453294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem ex_e302897453294 : ¬ IsSelfInterpreter e302897453294 := by
  intro he
  have run : replay [] e302897453294 = some te302897453294 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302897453294) (by decide) (by decide) h
#print axioms ex_e302897453294
private def te302897453302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem ex_e302897453302 : ¬ IsSelfInterpreter e302897453302 := by
  intro he
  have run : replay [] e302897453302 = some te302897453302 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302897453302) (by decide) (by decide) h
#print axioms ex_e302897453302
private def te302897454190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem ex_e302897454190 : ¬ IsSelfInterpreter e302897454190 := by
  intro he
  have run : replay [] e302897454190 = some te302897454190 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302897454190) (by decide) (by decide) h
#print axioms ex_e302897454190
private def te302897454202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem ex_e302897454202 : ¬ IsSelfInterpreter e302897454202 := by
  intro he
  have run : replay [] e302897454202 = some te302897454202 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302897454202) (by decide) (by decide) h
#print axioms ex_e302897454202
private def te302897454646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem ex_e302897454646 : ¬ IsSelfInterpreter e302897454646 := by
  intro he
  have run : replay [] e302897454646 = some te302897454646 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302897454646) (by decide) (by decide) h
#print axioms ex_e302897454646
private def te302897454650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem ex_e302897454650 : ¬ IsSelfInterpreter e302897454650 := by
  intro he
  have run : replay [] e302897454650 = some te302897454650 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302897454650) (by decide) (by decide) h
#print axioms ex_e302897454650
private def te302897456926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem ex_e302897456926 : ¬ IsSelfInterpreter e302897456926 := by
  intro he
  have run : replay [] e302897456926 = some te302897456926 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302897456926) (by decide) (by decide) h
#print axioms ex_e302897456926
private def te302897457038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem ex_e302897457038 : ¬ IsSelfInterpreter e302897457038 := by
  intro he
  have run : replay [] e302897457038 = some te302897457038 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302897457038) (by decide) (by decide) h
#print axioms ex_e302897457038
private def te302897459998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem ex_e302897459998 : ¬ IsSelfInterpreter e302897459998 := by
  intro he
  have run : replay [] e302897459998 = some te302897459998 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302897459998) (by decide) (by decide) h
#print axioms ex_e302897459998
private def te302897460166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem ex_e302897460166 : ¬ IsSelfInterpreter e302897460166 := by
  intro he
  have run : replay [] e302897460166 = some te302897460166 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302897460166) (by decide) (by decide) h
#print axioms ex_e302897460166
private def te302897461646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem ex_e302897461646 : ¬ IsSelfInterpreter e302897461646 := by
  intro he
  have run : replay [] e302897461646 = some te302897461646 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302897461646) (by decide) (by decide) h
#print axioms ex_e302897461646
private def te302897461702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem ex_e302897461702 : ¬ IsSelfInterpreter e302897461702 := by
  intro he
  have run : replay [] e302897461702 = some te302897461702 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302897461702) (by decide) (by decide) h
#print axioms ex_e302897461702
private def te302902155130 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e302902155130 : ¬ IsSelfInterpreter e302902155130 := by
  intro he
  have run : replay [] (.app e302902155130 diag) = some te302902155130 := by decide
  obtain ⟨_,h⟩ := clocks_replay (deltaCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302902155130) (by decide) (by decide) h
#print axioms ex_e302902155130
private def te302902155226 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem ex_e302902155226 : ¬ IsSelfInterpreter e302902155226 := by
  intro he
  have run : replay [] (.app e302902155226 diag) = some te302902155226 := by decide
  obtain ⟨_,h⟩ := clocks_replay (deltaCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302902155226) (by decide) (by decide) h
#print axioms ex_e302902155226
private def te302902172782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem ex_e302902172782 : ¬ IsSelfInterpreter e302902172782 := by
  intro he
  have run : replay [] e302902172782 = some te302902172782 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302902172782) (by decide) (by decide) h
#print axioms ex_e302902172782
private def te302902172794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem ex_e302902172794 : ¬ IsSelfInterpreter e302902172794 := by
  intro he
  have run : replay [] e302902172794 = some te302902172794 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302902172794) (by decide) (by decide) h
#print axioms ex_e302902172794
private def te302902175518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem ex_e302902175518 : ¬ IsSelfInterpreter e302902175518 := by
  intro he
  have run : replay [] e302902175518 = some te302902175518 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302902175518) (by decide) (by decide) h
#print axioms ex_e302902175518
private def te302902180294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem ex_e302902180294 : ¬ IsSelfInterpreter e302902180294 := by
  intro he
  have run : replay [] e302902180294 = some te302902180294 := by decide
  obtain ⟨_,h⟩ := clocks_replay (rawCount he) run
  exact Weighted.no_clock 1 (by decide : Closed te302902180294) (by decide) (by decide) h
#print axioms ex_e302902180294
end Blc.Floor40.WeightedRows
