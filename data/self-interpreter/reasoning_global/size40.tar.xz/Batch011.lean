import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e282803050334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e282803050334 : Closed e282803050334 ∧ code e282803050334 = 1382314678110 := by decide
theorem cert_e282803050334 : check e282803050334 [[],[.under],[.under],[.under]] .three = true := by decide
def e282803050362 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e282803050362 : Closed e282803050362 ∧ code e282803050362 = 1382314678138 := by decide
theorem cert_e282803050362 : check e282803050362 [[],[.under],[.under],[.under]] .three = true := by decide
def e282803050454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e282803050454 : Closed e282803050454 ∧ code e282803050454 = 1382314678230 := by decide
theorem cert_e282803050454 : check e282803050454 [[],[.under],[.under],[.under]] .three = true := by decide
def e282803050458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e282803050458 : Closed e282803050458 ∧ code e282803050458 = 1382314678234 := by decide
theorem cert_e282803050458 : check e282803050458 [[],[.under],[.under],[.under]] .three = true := by decide
def e282803050974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e282803050974 : Closed e282803050974 ∧ code e282803050974 = 1382314678750 := by decide
theorem cert_e282803050974 : check e282803050974 [[],[.under],[.under],[.under]] .three = true := by decide
def e282803050998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e282803050998 : Closed e282803050998 ∧ code e282803050998 = 1382314678774 := by decide
theorem cert_e282803050998 : check e282803050998 [[],[.under],[.under],[.under]] .three = true := by decide
def e282803051742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e282803051742 : Closed e282803051742 ∧ code e282803051742 = 1382314679518 := by decide
theorem cert_e282803051742 : check e282803051742 [[],[.under],[.under],[.under]] .three = true := by decide
def e282803051770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e282803051770 : Closed e282803051770 ∧ code e282803051770 = 1382314679546 := by decide
theorem cert_e282803051770 : check e282803051770 [[],[.under],[.under],[.under]] .three = true := by decide
def e282803052342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e282803052342 : Closed e282803052342 ∧ code e282803052342 = 1382314680118 := by decide
theorem cert_e282803052342 : check e282803052342 [[],[.under],[.under],[.under]] .three = true := by decide
def e282803052346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e282803052346 : Closed e282803052346 ∧ code e282803052346 = 1382314680122 := by decide
theorem cert_e282803052346 : check e282803052346 [[],[.under],[.under],[.under]] .three = true := by decide
def e282803067118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e282803067118 : Closed e282803067118 ∧ code e282803067118 = 1382314694894 := by decide
theorem cert_e282803067118 : check e282803067118 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e282803067126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e282803067126 : Closed e282803067126 ∧ code e282803067126 = 1382314694902 := by decide
theorem cert_e282803067126 : check e282803067126 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e282803067678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e282803067678 : Closed e282803067678 ∧ code e282803067678 = 1382314695454 := by decide
theorem cert_e282803067678 : check e282803067678 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e282803067790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e282803067790 : Closed e282803067790 ∧ code e282803067790 = 1382314695566 := by decide
theorem cert_e282803067790 : check e282803067790 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e282803068014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e282803068014 : Closed e282803068014 ∧ code e282803068014 = 1382314695790 := by decide
theorem cert_e282803068014 : check e282803068014 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e282803068026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e282803068026 : Closed e282803068026 ∧ code e282803068026 = 1382314695802 := by decide
theorem cert_e282803068026 : check e282803068026 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .smaller = true := by decide
def e282803068190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e282803068190 : Closed e282803068190 ∧ code e282803068190 = 1382314695966 := by decide
theorem cert_e282803068190 : check e282803068190 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left]] .identityHead = true := by decide
def e282803068358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e282803068358 : Closed e282803068358 ∧ code e282803068358 = 1382314696134 := by decide
private def t_e282803068358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem cert_e282803068358 : ¬ IsSelfInterpreter e282803068358 :=
  wSource (t := t_e282803068358) (replay_sound (ps := []) (t := e282803068358) (by decide)) (by decide)
def e282803068470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e282803068470 : Closed e282803068470 ∧ code e282803068470 = 1382314696246 := by decide
theorem cert_e282803068470 : check e282803068470 [[],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e282803068474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e282803068474 : Closed e282803068474 ∧ code e282803068474 = 1382314696250 := by decide
theorem cert_e282803068474 : check e282803068474 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e282803068558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e282803068558 : Closed e282803068558 ∧ code e282803068558 = 1382314696334 := by decide
theorem cert_e282803068558 : check e282803068558 [[],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e282803068614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e282803068614 : Closed e282803068614 ∧ code e282803068614 = 1382314696390 := by decide
private def t_e282803068614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem cert_e282803068614 : ¬ IsSelfInterpreter e282803068614 :=
  wSource (t := t_e282803068614) (replay_sound (ps := []) (t := e282803068614) (by decide)) (by decide)
def e282803070750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e282803070750 : Closed e282803070750 ∧ code e282803070750 = 1382314698526 := by decide
theorem cert_e282803070750 : check e282803070750 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e282803070862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e282803070862 : Closed e282803070862 ∧ code e282803070862 = 1382314698638 := by decide
theorem cert_e282803070862 : check e282803070862 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[]] .identityHead = true := by decide
def e282803073822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e282803073822 : Closed e282803073822 ∧ code e282803073822 = 1382314701598 := by decide
theorem cert_e282803073822 : check e282803073822 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e282803073990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e282803073990 : Closed e282803073990 ∧ code e282803073990 = 1382314701766 := by decide
theorem cert_e282803073990 : check e282803073990 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e282803075470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e282803075470 : Closed e282803075470 ∧ code e282803075470 = 1382314703246 := by decide
theorem cert_e282803075470 : check e282803075470 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.under]] .identityHead = true := by decide
def e282803075526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e282803075526 : Closed e282803075526 ∧ code e282803075526 = 1382314703302 := by decide
theorem cert_e282803075526 : check e282803075526 [[],[.under],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e298506222106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298506222106 : Closed e298506222106 ∧ code e298506222106 = 1398017849882 := by decide
theorem cert_e298506222106 : check e298506222106 [[]] .width = true := by decide
def e298506246682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298506246682 : Closed e298506246682 ∧ code e298506246682 = 1398017874458 := by decide
theorem cert_e298506246682 : check e298506246682 [[]] .width = true := by decide
def e298506353178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298506353178 : Closed e298506353178 ∧ code e298506353178 = 1398017980954 := by decide
theorem cert_e298506353178 : check e298506353178 [[]] .width = true := by decide
def e298506381850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298506381850 : Closed e298506381850 ∧ code e298506381850 = 1398018009626 := by decide
theorem cert_e298506381850 : check e298506381850 [[]] .width = true := by decide
def e298506476058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298506476058 : Closed e298506476058 ∧ code e298506476058 = 1398018103834 := by decide
theorem cert_e298506476058 : check e298506476058 [[]] .width = true := by decide
def e298506480154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298506480154 : Closed e298506480154 ∧ code e298506480154 = 1398018107930 := by decide
theorem cert_e298506480154 : check e298506480154 [[]] .width = true := by decide
def e298507008538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298507008538 : Closed e298507008538 ∧ code e298507008538 = 1398018636314 := by decide
theorem cert_e298507008538 : check e298507008538 [[]] .width = true := by decide
def e298507033114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298507033114 : Closed e298507033114 ∧ code e298507033114 = 1398018660890 := by decide
theorem cert_e298507033114 : check e298507033114 [[]] .width = true := by decide
def e298507794970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298507794970 : Closed e298507794970 ∧ code e298507794970 = 1398019422746 := by decide
theorem cert_e298507794970 : check e298507794970 [[]] .width = true := by decide
def e298507823642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298507823642 : Closed e298507823642 ∧ code e298507823642 = 1398019451418 := by decide
theorem cert_e298507823642 : check e298507823642 [[]] .width = true := by decide
def e298508409370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298508409370 : Closed e298508409370 ∧ code e298508409370 = 1398020037146 := by decide
theorem cert_e298508409370 : check e298508409370 [[]] .width = true := by decide
def e298508413466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298508413466 : Closed e298508413466 ∧ code e298508413466 = 1398020041242 := by decide
theorem cert_e298508413466 : check e298508413466 [[]] .width = true := by decide
def e298523539994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298523539994 : Closed e298523539994 ∧ code e298523539994 = 1398035167770 := by decide
theorem cert_e298523539994 : check e298523539994 [[]] .width = true := by decide
def e298523548186 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298523548186 : Closed e298523548186 ∧ code e298523548186 = 1398035175962 := by decide
theorem cert_e298523548186 : check e298523548186 [[]] .width = true := by decide
def e298524113434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298524113434 : Closed e298524113434 ∧ code e298524113434 = 1398035741210 := by decide
theorem cert_e298524113434 : check e298524113434 [[]] .width = true := by decide
def e298524198426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298524198426 : Closed e298524198426 ∧ code e298524198426 = 1398035826202 := by decide
theorem cert_e298524198426 : check e298524198426 [[]] .width = true := by decide
def e298524201158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e298524201158 : Closed e298524201158 ∧ code e298524201158 = 1398035828934 := by decide
theorem cert_e298524201158 : check e298524201158 [[]] .width = true := by decide
def e298524228122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298524228122 : Closed e298524228122 ∧ code e298524228122 = 1398035855898 := by decide
theorem cert_e298524228122 : check e298524228122 [[]] .width = true := by decide
def e298524263962 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298524263962 : Closed e298524263962 ∧ code e298524263962 = 1398035891738 := by decide
theorem cert_e298524263962 : check e298524263962 [[]] .width = true := by decide
def e298524266694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e298524266694 : Closed e298524266694 ∧ code e298524266694 = 1398035894470 := by decide
theorem cert_e298524266694 : check e298524266694 [[]] .width = true := by decide
def e298524457498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298524457498 : Closed e298524457498 ∧ code e298524457498 = 1398036085274 := by decide
theorem cert_e298524457498 : check e298524457498 [[]] .width = true := by decide
def e298524469786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298524469786 : Closed e298524469786 ∧ code e298524469786 = 1398036097562 := by decide
theorem cert_e298524469786 : check e298524469786 [[]] .width = true := by decide
def e298524637722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298524637722 : Closed e298524637722 ∧ code e298524637722 = 1398036265498 := by decide
theorem cert_e298524637722 : check e298524637722 [[]] .width = true := by decide
def e298524722714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298524722714 : Closed e298524722714 ∧ code e298524722714 = 1398036350490 := by decide
theorem cert_e298524722714 : check e298524722714 [[]] .width = true := by decide
def e298524725446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e298524725446 : Closed e298524725446 ∧ code e298524725446 = 1398036353222 := by decide
theorem cert_e298524725446 : check e298524725446 [[]] .width = true := by decide
def e298524809754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298524809754 : Closed e298524809754 ∧ code e298524809754 = 1398036437530 := by decide
private def t_e298524809754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e298524809754 : ¬ IsSelfInterpreter e298524809754 :=
  wSource (t := t_e298524809754) (replay_sound (ps := []) (t := e298524809754) (by decide)) (by decide)
def e298524821018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298524821018 : Closed e298524821018 ∧ code e298524821018 = 1398036448794 := by decide
private def t_e298524821018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e298524821018 : ¬ IsSelfInterpreter e298524821018 :=
  wSource (t := t_e298524821018) (replay_sound (ps := []) (t := e298524821018) (by decide)) (by decide)
def e298524823750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e298524823750 : Closed e298524823750 ∧ code e298524823750 = 1398036451526 := by decide
theorem cert_e298524823750 : check e298524823750 [[]] .width = true := by decide
def e298524924442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298524924442 : Closed e298524924442 ∧ code e298524924442 = 1398036552218 := by decide
theorem cert_e298524924442 : check e298524924442 [[]] .width = true := by decide
def e298524928538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298524928538 : Closed e298524928538 ∧ code e298524928538 = 1398036556314 := by decide
theorem cert_e298524928538 : check e298524928538 [[]] .width = true := by decide
def e298525014554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298525014554 : Closed e298525014554 ∧ code e298525014554 = 1398036642330 := by decide
theorem cert_e298525014554 : check e298525014554 [[]] .width = true := by decide
def e298525050394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298525050394 : Closed e298525050394 ∧ code e298525050394 = 1398036678170 := by decide
theorem cert_e298525050394 : check e298525050394 [[]] .width = true := by decide
def e298525053126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e298525053126 : Closed e298525053126 ∧ code e298525053126 = 1398036680902 := by decide
theorem cert_e298525053126 : check e298525053126 [[]] .width = true := by decide
def e298525071898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298525071898 : Closed e298525071898 ∧ code e298525071898 = 1398036699674 := by decide
private def t_e298525071898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e298525071898 : ¬ IsSelfInterpreter e298525071898 :=
  wSource (t := t_e298525071898) (replay_sound (ps := []) (t := e298525071898) (by decide)) (by decide)
def e298525083162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298525083162 : Closed e298525083162 ∧ code e298525083162 = 1398036710938 := by decide
private def t_e298525083162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e298525083162 : ¬ IsSelfInterpreter e298525083162 :=
  wSource (t := t_e298525083162) (replay_sound (ps := []) (t := e298525083162) (by decide)) (by decide)
def e298525085894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e298525085894 : Closed e298525085894 ∧ code e298525085894 = 1398036713670 := by decide
theorem cert_e298525085894 : check e298525085894 [[]] .width = true := by decide
def e298527259162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298527259162 : Closed e298527259162 ∧ code e298527259162 = 1398038886938 := by decide
theorem cert_e298527259162 : check e298527259162 [[]] .width = true := by decide
def e298527344154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298527344154 : Closed e298527344154 ∧ code e298527344154 = 1398038971930 := by decide
theorem cert_e298527344154 : check e298527344154 [[]] .width = true := by decide
def e298527346886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e298527346886 : Closed e298527346886 ∧ code e298527346886 = 1398038974662 := by decide
theorem cert_e298527346886 : check e298527346886 [[]] .width = true := by decide
def e298527373850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298527373850 : Closed e298527373850 ∧ code e298527373850 = 1398039001626 := by decide
theorem cert_e298527373850 : check e298527373850 [[]] .width = true := by decide
def e298527409690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298527409690 : Closed e298527409690 ∧ code e298527409690 = 1398039037466 := by decide
theorem cert_e298527409690 : check e298527409690 [[]] .width = true := by decide
def e298527412422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e298527412422 : Closed e298527412422 ∧ code e298527412422 = 1398039040198 := by decide
theorem cert_e298527412422 : check e298527412422 [[]] .width = true := by decide
def e298530404890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298530404890 : Closed e298530404890 ∧ code e298530404890 = 1398042032666 := by decide
theorem cert_e298530404890 : check e298530404890 [[]] .width = true := by decide
def e298530489882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298530489882 : Closed e298530489882 ∧ code e298530489882 = 1398042117658 := by decide
theorem cert_e298530489882 : check e298530489882 [[]] .width = true := by decide
def e298530492614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e298530492614 : Closed e298530492614 ∧ code e298530492614 = 1398042120390 := by decide
theorem cert_e298530492614 : check e298530492614 [[]] .width = true := by decide
def e298530576922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298530576922 : Closed e298530576922 ∧ code e298530576922 = 1398042204698 := by decide
theorem cert_e298530576922 : check e298530576922 [[]] .width = true := by decide
def e298530588186 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298530588186 : Closed e298530588186 ∧ code e298530588186 = 1398042215962 := by decide
theorem cert_e298530588186 : check e298530588186 [[]] .width = true := by decide
def e298530590918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e298530590918 : Closed e298530590918 ∧ code e298530590918 = 1398042218694 := by decide
theorem cert_e298530590918 : check e298530590918 [[]] .width = true := by decide
def e298532092442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298532092442 : Closed e298532092442 ∧ code e298532092442 = 1398043720218 := by decide
theorem cert_e298532092442 : check e298532092442 [[]] .width = true := by decide
def e298532128282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298532128282 : Closed e298532128282 ∧ code e298532128282 = 1398043756058 := by decide
theorem cert_e298532128282 : check e298532128282 [[]] .width = true := by decide
def e298532131014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e298532131014 : Closed e298532131014 ∧ code e298532131014 = 1398043758790 := by decide
theorem cert_e298532131014 : check e298532131014 [[]] .width = true := by decide
def e298532149786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298532149786 : Closed e298532149786 ∧ code e298532149786 = 1398043777562 := by decide
theorem cert_e298532149786 : check e298532149786 [[]] .width = true := by decide
def e298532161050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298532161050 : Closed e298532161050 ∧ code e298532161050 = 1398043788826 := by decide
theorem cert_e298532161050 : check e298532161050 [[]] .width = true := by decide
def e298532163782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e298532163782 : Closed e298532163782 ∧ code e298532163782 = 1398043791558 := by decide
theorem cert_e298532163782 : check e298532163782 [[]] .width = true := by decide
def e298668088174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e298668088174 : Closed e298668088174 ∧ code e298668088174 = 1398179715950 := by decide
theorem cert_e298668088174 : check e298668088174 [[],[.left],[]] .sourceHead = true := by decide
def e298668088182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e298668088182 : Closed e298668088182 ∧ code e298668088182 = 1398179715958 := by decide
theorem cert_e298668088182 : check e298668088182 [[],[.left],[]] .sourceHead = true := by decide
def e298668088246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e298668088246 : Closed e298668088246 ∧ code e298668088246 = 1398179716022 := by decide
theorem cert_e298668088246 : check e298668088246 [[],[.left],[]] .sourceHead = true := by decide
def e298668088686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e298668088686 : Closed e298668088686 ∧ code e298668088686 = 1398179716462 := by decide
def e298668088694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e298668088694 : Closed e298668088694 ∧ code e298668088694 = 1398179716470 := by decide
theorem cert_e298668088694 : check e298668088694 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e298668088750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e298668088750 : Closed e298668088750 ∧ code e298668088750 = 1398179716526 := by decide
theorem cert_e298668088750 : check e298668088750 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e298668088762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e298668088762 : Closed e298668088762 ∧ code e298668088762 = 1398179716538 := by decide
theorem cert_e298668088762 : check e298668088762 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e298668088790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e298668088790 : Closed e298668088790 ∧ code e298668088790 = 1398179716566 := by decide
theorem cert_e298668088790 : check e298668088790 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e298668088794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e298668088794 : Closed e298668088794 ∧ code e298668088794 = 1398179716570 := by decide
def e298668089014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e298668089014 : Closed e298668089014 ∧ code e298668089014 = 1398179716790 := by decide
theorem cert_e298668089014 : check e298668089014 [[],[.left],[],[.under,.left,.left]] .sourceHead = true := by decide
def e298668089046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e298668089046 : Closed e298668089046 ∧ code e298668089046 = 1398179716822 := by decide
theorem cert_e298668089046 : check e298668089046 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e298668089050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e298668089050 : Closed e298668089050 ∧ code e298668089050 = 1398179716826 := by decide
theorem cert_e298668089050 : check e298668089050 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e298668091246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e298668091246 : Closed e298668091246 ∧ code e298668091246 = 1398179719022 := by decide
theorem cert_e298668091246 : check e298668091246 [[],[.left],[]] .sourceHead = true := by decide
def e298668091254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e298668091254 : Closed e298668091254 ∧ code e298668091254 = 1398179719030 := by decide
theorem cert_e298668091254 : check e298668091254 [[],[.left],[]] .sourceHead = true := by decide
def e298668091318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e298668091318 : Closed e298668091318 ∧ code e298668091318 = 1398179719094 := by decide
theorem cert_e298668091318 : check e298668091318 [[],[.left],[]] .sourceHead = true := by decide
def e298668092654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e298668092654 : Closed e298668092654 ∧ code e298668092654 = 1398179720430 := by decide
theorem cert_e298668092654 : check e298668092654 [[],[.left],[]] .sourceHead = true := by decide
def e298668092662 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e298668092662 : Closed e298668092662 ∧ code e298668092662 = 1398179720438 := by decide
theorem cert_e298668092662 : check e298668092662 [[],[.left],[]] .sourceHead = true := by decide
def e298668093046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e298668093046 : Closed e298668093046 ∧ code e298668093046 = 1398179720822 := by decide
theorem cert_e298668093046 : check e298668093046 [[],[.left],[]] .sourceHead = true := by decide
def e298668094318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e298668094318 : Closed e298668094318 ∧ code e298668094318 = 1398179722094 := by decide
theorem cert_e298668094318 : check e298668094318 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e298668094326 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e298668094326 : Closed e298668094326 ∧ code e298668094326 = 1398179722102 := by decide
theorem cert_e298668094326 : check e298668094326 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e298668094382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e298668094382 : Closed e298668094382 ∧ code e298668094382 = 1398179722158 := by decide
theorem cert_e298668094382 : check e298668094382 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e298668094394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e298668094394 : Closed e298668094394 ∧ code e298668094394 = 1398179722170 := by decide
theorem cert_e298668094394 : check e298668094394 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e298668094422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e298668094422 : Closed e298668094422 ∧ code e298668094422 = 1398179722198 := by decide
theorem cert_e298668094422 : check e298668094422 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e298668094426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e298668094426 : Closed e298668094426 ∧ code e298668094426 = 1398179722202 := by decide
theorem cert_e298668094426 : check e298668094426 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e298668094702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e298668094702 : Closed e298668094702 ∧ code e298668094702 = 1398179722478 := by decide
theorem cert_e298668094702 : check e298668094702 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e298668094710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e298668094710 : Closed e298668094710 ∧ code e298668094710 = 1398179722486 := by decide
theorem cert_e298668094710 : check e298668094710 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e298668095086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e298668095086 : Closed e298668095086 ∧ code e298668095086 = 1398179722862 := by decide
theorem cert_e298668095086 : check e298668095086 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e298668095098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e298668095098 : Closed e298668095098 ∧ code e298668095098 = 1398179722874 := by decide
theorem cert_e298668095098 : check e298668095098 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e298668095286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e298668095286 : Closed e298668095286 ∧ code e298668095286 = 1398179723062 := by decide
theorem cert_e298668095286 : check e298668095286 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e298668095290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e298668095290 : Closed e298668095290 ∧ code e298668095290 = 1398179723066 := by decide
theorem cert_e298668095290 : check e298668095290 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e298668095926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e298668095926 : Closed e298668095926 ∧ code e298668095926 = 1398179723702 := by decide
theorem cert_e298668095926 : check e298668095926 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e298668095958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e298668095958 : Closed e298668095958 ∧ code e298668095958 = 1398179723734 := by decide
theorem cert_e298668095958 : checkPay e298668095958 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left]] = true := by decide
def e298668095962 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e298668095962 : Closed e298668095962 ∧ code e298668095962 = 1398179723738 := by decide
theorem cert_e298668095962 : check e298668095962 [[],[.left],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e298668096118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e298668096118 : Closed e298668096118 ∧ code e298668096118 = 1398179723894 := by decide
theorem cert_e298668096118 : check e298668096118 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e298668096310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e298668096310 : Closed e298668096310 ∧ code e298668096310 = 1398179724086 := by decide
theorem cert_e298668096310 : check e298668096310 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e298668096314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e298668096314 : Closed e298668096314 ∧ code e298668096314 = 1398179724090 := by decide
theorem cert_e298668096314 : check e298668096314 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e298668103534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e298668103534 : Closed e298668103534 ∧ code e298668103534 = 1398179731310 := by decide
theorem cert_e298668103534 : check e298668103534 [[],[.left],[]] .sourceHead = true := by decide
def e298668103542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e298668103542 : Closed e298668103542 ∧ code e298668103542 = 1398179731318 := by decide
theorem cert_e298668103542 : check e298668103542 [[],[.left],[]] .sourceHead = true := by decide
def e298668103606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e298668103606 : Closed e298668103606 ∧ code e298668103606 = 1398179731382 := by decide
theorem cert_e298668103606 : check e298668103606 [[],[.left],[]] .sourceHead = true := by decide
def e298668104942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e298668104942 : Closed e298668104942 ∧ code e298668104942 = 1398179732718 := by decide
theorem cert_e298668104942 : check e298668104942 [[],[.left],[]] .sourceHead = true := by decide
def e298668104950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e298668104950 : Closed e298668104950 ∧ code e298668104950 = 1398179732726 := by decide
theorem cert_e298668104950 : check e298668104950 [[],[.left],[]] .sourceHead = true := by decide
def e298668105334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e298668105334 : Closed e298668105334 ∧ code e298668105334 = 1398179733110 := by decide
theorem cert_e298668105334 : check e298668105334 [[],[.left],[]] .sourceHead = true := by decide
def e298668116846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e298668116846 : Closed e298668116846 ∧ code e298668116846 = 1398179744622 := by decide
theorem cert_e298668116846 : check e298668116846 [[],[.left],[],[.under]] .three = true := by decide
def e298668116854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e298668116854 : Closed e298668116854 ∧ code e298668116854 = 1398179744630 := by decide
theorem cert_e298668116854 : check e298668116854 [[],[.left],[],[.under]] .three = true := by decide
def e298668116910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e298668116910 : Closed e298668116910 ∧ code e298668116910 = 1398179744686 := by decide
theorem cert_e298668116910 : check e298668116910 [[],[.left],[],[.under]] .three = true := by decide
def e298668116922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e298668116922 : Closed e298668116922 ∧ code e298668116922 = 1398179744698 := by decide
theorem cert_e298668116922 : check e298668116922 [[],[.left],[],[.under]] .three = true := by decide
def e298668116950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e298668116950 : Closed e298668116950 ∧ code e298668116950 = 1398179744726 := by decide
theorem cert_e298668116950 : check e298668116950 [[],[.left],[],[.under]] .three = true := by decide
def e298668116954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e298668116954 : Closed e298668116954 ∧ code e298668116954 = 1398179744730 := by decide
theorem cert_e298668116954 : check e298668116954 [[],[.left],[],[.under]] .three = true := by decide
def e298668117230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e298668117230 : Closed e298668117230 ∧ code e298668117230 = 1398179745006 := by decide
theorem cert_e298668117230 : check e298668117230 [[],[.left],[],[.under]] .three = true := by decide
def e298668117238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e298668117238 : Closed e298668117238 ∧ code e298668117238 = 1398179745014 := by decide
theorem cert_e298668117238 : check e298668117238 [[],[.left],[],[.under]] .three = true := by decide
def e298668117614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e298668117614 : Closed e298668117614 ∧ code e298668117614 = 1398179745390 := by decide
theorem cert_e298668117614 : check e298668117614 [[],[.left],[],[.under]] .three = true := by decide
def e298668117626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e298668117626 : Closed e298668117626 ∧ code e298668117626 = 1398179745402 := by decide
theorem cert_e298668117626 : check e298668117626 [[],[.left],[],[.under]] .three = true := by decide
def e298668117814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e298668117814 : Closed e298668117814 ∧ code e298668117814 = 1398179745590 := by decide
theorem cert_e298668117814 : check e298668117814 [[],[.left],[],[.under]] .three = true := by decide
def e298668117818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e298668117818 : Closed e298668117818 ∧ code e298668117818 = 1398179745594 := by decide
theorem cert_e298668117818 : check e298668117818 [[],[.left],[],[.under]] .three = true := by decide
def e298668123574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e298668123574 : Closed e298668123574 ∧ code e298668123574 = 1398179751350 := by decide
theorem cert_e298668123574 : check e298668123574 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e298668123606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e298668123606 : Closed e298668123606 ∧ code e298668123606 = 1398179751382 := by decide
theorem cert_e298668123606 : check e298668123606 [[],[.left],[],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e298668123610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e298668123610 : Closed e298668123610 ∧ code e298668123610 = 1398179751386 := by decide
theorem cert_e298668123610 : check e298668123610 [[],[.left],[],[.under],[.under,.left]] .chain = true := by decide
def e298668123766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e298668123766 : Closed e298668123766 ∧ code e298668123766 = 1398179751542 := by decide
theorem cert_e298668123766 : check e298668123766 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e298668123958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e298668123958 : Closed e298668123958 ∧ code e298668123958 = 1398179751734 := by decide
theorem cert_e298668123958 : check e298668123958 [[],[.left],[],[.under],[.under]] .three = true := by decide
def e298668123962 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e298668123962 : Closed e298668123962 ∧ code e298668123962 = 1398179751738 := by decide
theorem cert_e298668123962 : check e298668123962 [[],[.left],[],[.under],[.under]] .three = true := by decide
def e298668460910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e298668460910 : Closed e298668460910 ∧ code e298668460910 = 1398180088686 := by decide
theorem cert_e298668460910 : check e298668460910 [[],[.left]] .chain = true := by decide
def e298668460918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e298668460918 : Closed e298668460918 ∧ code e298668460918 = 1398180088694 := by decide
theorem cert_e298668460918 : check e298668460918 [[],[.left]] .chain = true := by decide
def e298668460974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e298668460974 : Closed e298668460974 ∧ code e298668460974 = 1398180088750 := by decide
theorem cert_e298668460974 : check e298668460974 [[],[.left]] .chain = true := by decide
def e298668460986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e298668460986 : Closed e298668460986 ∧ code e298668460986 = 1398180088762 := by decide
theorem cert_e298668460986 : check e298668460986 [[],[.left]] .chain = true := by decide
def e298668461014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e298668461014 : Closed e298668461014 ∧ code e298668461014 = 1398180088790 := by decide
theorem cert_e298668461014 : check e298668461014 [[],[.left]] .chain = true := by decide
def e298668461018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e298668461018 : Closed e298668461018 ∧ code e298668461018 = 1398180088794 := by decide
theorem cert_e298668461018 : check e298668461018 [[],[.left]] .chain = true := by decide
def e298668461294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e298668461294 : Closed e298668461294 ∧ code e298668461294 = 1398180089070 := by decide
theorem cert_e298668461294 : check e298668461294 [[],[.left]] .chain = true := by decide
def e298668461302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e298668461302 : Closed e298668461302 ∧ code e298668461302 = 1398180089078 := by decide
theorem cert_e298668461302 : check e298668461302 [[],[.left]] .chain = true := by decide
def e298668461678 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e298668461678 : Closed e298668461678 ∧ code e298668461678 = 1398180089454 := by decide
theorem cert_e298668461678 : check e298668461678 [[],[.left]] .chain = true := by decide
def e298668461690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e298668461690 : Closed e298668461690 ∧ code e298668461690 = 1398180089466 := by decide
theorem cert_e298668461690 : check e298668461690 [[],[.left]] .chain = true := by decide
def e298668461878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e298668461878 : Closed e298668461878 ∧ code e298668461878 = 1398180089654 := by decide
theorem cert_e298668461878 : check e298668461878 [[],[.left]] .chain = true := by decide
def e298668461882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e298668461882 : Closed e298668461882 ∧ code e298668461882 = 1398180089658 := by decide
theorem cert_e298668461882 : check e298668461882 [[],[.left]] .chain = true := by decide
def e298702302746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298702302746 : Closed e298702302746 ∧ code e298702302746 = 1398213930522 := by decide
theorem cert_e298702302746 : check e298702302746 [[]] .width = true := by decide
def e298702304794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298702304794 : Closed e298702304794 ∧ code e298702304794 = 1398213932570 := by decide
theorem cert_e298702304794 : check e298702304794 [[]] .width = true := by decide
def e298702319130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298702319130 : Closed e298702319130 ∧ code e298702319130 = 1398213946906 := by decide
theorem cert_e298702319130 : check e298702319130 [[]] .width = true := by decide
def e298702322202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298702322202 : Closed e298702322202 ∧ code e298702322202 = 1398213949978 := by decide
theorem cert_e298702322202 : check e298702322202 [[]] .width = true := by decide
def e298702329370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298702329370 : Closed e298702329370 ∧ code e298702329370 = 1398213957146 := by decide
theorem cert_e298702329370 : check e298702329370 [[]] .width = true := by decide
def e298702330394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e298702330394 : Closed e298702330394 ∧ code e298702330394 = 1398213958170 := by decide
theorem cert_e298702330394 : check e298702330394 [[]] .width = true := by decide
end Blc.Floor40
