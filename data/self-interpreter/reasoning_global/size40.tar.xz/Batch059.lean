import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302821962526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302821962526 : Closed e302821962526 ∧ code e302821962526 = 1402333590302 := by decide
theorem cert_e302821962526 : check e302821962526 [[],[]] .chain = true := by decide
def e302821962694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302821962694 : Closed e302821962694 ∧ code e302821962694 = 1402333590470 := by decide
theorem cert_e302821962694 : check e302821962694 [[],[]] .chain = true := by decide
def e302821964174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302821964174 : Closed e302821964174 ∧ code e302821964174 = 1402333591950 := by decide
theorem cert_e302821964174 : check e302821964174 [[],[]] .chain = true := by decide
def e302821964230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302821964230 : Closed e302821964230 ∧ code e302821964230 = 1402333592006 := by decide
theorem cert_e302821964230 : check e302821964230 [[],[]] .chain = true := by decide
def e302822198126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302822198126 : Closed e302822198126 ∧ code e302822198126 = 1402333825902 := by decide
theorem cert_e302822198126 : check e302822198126 [[],[]] .chain = true := by decide
def e302822198134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302822198134 : Closed e302822198134 ∧ code e302822198134 = 1402333825910 := by decide
theorem cert_e302822198134 : check e302822198134 [[],[]] .chain = true := by decide
def e302822198190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302822198190 : Closed e302822198190 ∧ code e302822198190 = 1402333825966 := by decide
theorem cert_e302822198190 : check e302822198190 [[],[]] .chain = true := by decide
def e302822198202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302822198202 : Closed e302822198202 ∧ code e302822198202 = 1402333825978 := by decide
theorem cert_e302822198202 : check e302822198202 [[],[]] .chain = true := by decide
def e302822198230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302822198230 : Closed e302822198230 ∧ code e302822198230 = 1402333826006 := by decide
theorem cert_e302822198230 : check e302822198230 [[],[]] .chain = true := by decide
def e302822198234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302822198234 : Closed e302822198234 ∧ code e302822198234 = 1402333826010 := by decide
theorem cert_e302822198234 : check e302822198234 [[],[]] .chain = true := by decide
def e302822198510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302822198510 : Closed e302822198510 ∧ code e302822198510 = 1402333826286 := by decide
theorem cert_e302822198510 : check e302822198510 [[],[]] .chain = true := by decide
def e302822198518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302822198518 : Closed e302822198518 ∧ code e302822198518 = 1402333826294 := by decide
theorem cert_e302822198518 : check e302822198518 [[],[]] .chain = true := by decide
def e302822198894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302822198894 : Closed e302822198894 ∧ code e302822198894 = 1402333826670 := by decide
theorem cert_e302822198894 : check e302822198894 [[],[]] .chain = true := by decide
def e302822198906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302822198906 : Closed e302822198906 ∧ code e302822198906 = 1402333826682 := by decide
theorem cert_e302822198906 : check e302822198906 [[],[]] .chain = true := by decide
def e302822199094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302822199094 : Closed e302822199094 ∧ code e302822199094 = 1402333826870 := by decide
theorem cert_e302822199094 : check e302822199094 [[],[]] .chain = true := by decide
def e302822199098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302822199098 : Closed e302822199098 ∧ code e302822199098 = 1402333826874 := by decide
theorem cert_e302822199098 : check e302822199098 [[],[]] .chain = true := by decide
def e302824566206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e302824566206 : Closed e302824566206 ∧ code e302824566206 = 1402336193982 := by decide
theorem cert_e302824566206 : check e302824566206 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824566262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e302824566262 : Closed e302824566262 ∧ code e302824566262 = 1402336194038 := by decide
theorem cert_e302824566262 : check e302824566262 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824566462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e302824566462 : Closed e302824566462 ∧ code e302824566462 = 1402336194238 := by decide
theorem cert_e302824566462 : check e302824566462 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824566522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e302824566522 : Closed e302824566522 ∧ code e302824566522 = 1402336194298 := by decide
theorem cert_e302824566522 : check e302824566522 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824566742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e302824566742 : Closed e302824566742 ∧ code e302824566742 = 1402336194518 := by decide
theorem cert_e302824566742 : check e302824566742 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824566746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e302824566746 : Closed e302824566746 ∧ code e302824566746 = 1402336194522 := by decide
theorem cert_e302824566746 : check e302824566746 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824567742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e302824567742 : Closed e302824567742 ∧ code e302824567742 = 1402336195518 := by decide
theorem cert_e302824567742 : check e302824567742 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824567798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e302824567798 : Closed e302824567798 ∧ code e302824567798 = 1402336195574 := by decide
theorem cert_e302824567798 : check e302824567798 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824569278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e302824569278 : Closed e302824569278 ∧ code e302824569278 = 1402336197054 := by decide
theorem cert_e302824569278 : check e302824569278 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824569338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e302824569338 : Closed e302824569338 ∧ code e302824569338 = 1402336197114 := by decide
theorem cert_e302824569338 : check e302824569338 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824570678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e302824570678 : Closed e302824570678 ∧ code e302824570678 = 1402336198454 := by decide
theorem cert_e302824570678 : check e302824570678 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824570682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e302824570682 : Closed e302824570682 ∧ code e302824570682 = 1402336198458 := by decide
theorem cert_e302824570682 : check e302824570682 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824598894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e302824598894 : Closed e302824598894 ∧ code e302824598894 = 1402336226670 := by decide
theorem cert_e302824598894 : check e302824598894 [[],[],[.under]] .width = true := by decide
def e302824598902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e302824598902 : Closed e302824598902 ∧ code e302824598902 = 1402336226678 := by decide
theorem cert_e302824598902 : check e302824598902 [[],[],[.under]] .width = true := by decide
def e302824598958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e302824598958 : Closed e302824598958 ∧ code e302824598958 = 1402336226734 := by decide
theorem cert_e302824598958 : check e302824598958 [[],[],[.under]] .width = true := by decide
def e302824598970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e302824598970 : Closed e302824598970 ∧ code e302824598970 = 1402336226746 := by decide
theorem cert_e302824598970 : check e302824598970 [[],[],[.under]] .width = true := by decide
def e302824598998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e302824598998 : Closed e302824598998 ∧ code e302824598998 = 1402336226774 := by decide
theorem cert_e302824598998 : check e302824598998 [[],[],[.under]] .width = true := by decide
def e302824599002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e302824599002 : Closed e302824599002 ∧ code e302824599002 = 1402336226778 := by decide
theorem cert_e302824599002 : check e302824599002 [[],[],[.under]] .width = true := by decide
def e302824599214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e302824599214 : Closed e302824599214 ∧ code e302824599214 = 1402336226990 := by decide
theorem cert_e302824599214 : check e302824599214 [[],[],[.under]] .width = true := by decide
def e302824599226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e302824599226 : Closed e302824599226 ∧ code e302824599226 = 1402336227002 := by decide
theorem cert_e302824599226 : check e302824599226 [[],[],[.under]] .width = true := by decide
def e302824599274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e302824599274 : Closed e302824599274 ∧ code e302824599274 = 1402336227050 := by decide
theorem cert_e302824599274 : check e302824599274 [[],[],[.under]] .width = true := by decide
def e302824599382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e302824599382 : Closed e302824599382 ∧ code e302824599382 = 1402336227158 := by decide
theorem cert_e302824599382 : check e302824599382 [[],[],[.under]] .width = true := by decide
def e302824599386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e302824599386 : Closed e302824599386 ∧ code e302824599386 = 1402336227162 := by decide
theorem cert_e302824599386 : check e302824599386 [[],[],[.under]] .width = true := by decide
def e302824599402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e302824599402 : Closed e302824599402 ∧ code e302824599402 = 1402336227178 := by decide
theorem cert_e302824599402 : check e302824599402 [[],[],[.under]] .width = true := by decide
def e302824600030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e302824600030 : Closed e302824600030 ∧ code e302824600030 = 1402336227806 := by decide
theorem cert_e302824600030 : check e302824600030 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824600054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e302824600054 : Closed e302824600054 ∧ code e302824600054 = 1402336227830 := by decide
theorem cert_e302824600054 : check e302824600054 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824600430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302824600430 : Closed e302824600430 ∧ code e302824600430 = 1402336228206 := by decide
theorem cert_e302824600430 : check e302824600430 [[],[],[.under]] .width = true := by decide
def e302824600438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302824600438 : Closed e302824600438 ∧ code e302824600438 = 1402336228214 := by decide
theorem cert_e302824600438 : check e302824600438 [[],[],[.under]] .width = true := by decide
def e302824600494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302824600494 : Closed e302824600494 ∧ code e302824600494 = 1402336228270 := by decide
theorem cert_e302824600494 : check e302824600494 [[],[],[.under]] .width = true := by decide
def e302824600506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302824600506 : Closed e302824600506 ∧ code e302824600506 = 1402336228282 := by decide
theorem cert_e302824600506 : check e302824600506 [[],[],[.under]] .width = true := by decide
def e302824600534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302824600534 : Closed e302824600534 ∧ code e302824600534 = 1402336228310 := by decide
theorem cert_e302824600534 : check e302824600534 [[],[],[.under]] .width = true := by decide
def e302824600538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302824600538 : Closed e302824600538 ∧ code e302824600538 = 1402336228314 := by decide
theorem cert_e302824600538 : check e302824600538 [[],[],[.under]] .width = true := by decide
def e302824600814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302824600814 : Closed e302824600814 ∧ code e302824600814 = 1402336228590 := by decide
theorem cert_e302824600814 : check e302824600814 [[],[],[.under]] .width = true := by decide
def e302824600822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302824600822 : Closed e302824600822 ∧ code e302824600822 = 1402336228598 := by decide
theorem cert_e302824600822 : check e302824600822 [[],[],[.under]] .width = true := by decide
def e302824601150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e302824601150 : Closed e302824601150 ∧ code e302824601150 = 1402336228926 := by decide
theorem cert_e302824601150 : check e302824601150 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824601198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302824601198 : Closed e302824601198 ∧ code e302824601198 = 1402336228974 := by decide
theorem cert_e302824601198 : check e302824601198 [[],[],[.under]] .width = true := by decide
def e302824601210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302824601210 : Closed e302824601210 ∧ code e302824601210 = 1402336228986 := by decide
theorem cert_e302824601210 : check e302824601210 [[],[],[.under]] .width = true := by decide
def e302824601398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302824601398 : Closed e302824601398 ∧ code e302824601398 = 1402336229174 := by decide
theorem cert_e302824601398 : check e302824601398 [[],[],[.under]] .width = true := by decide
def e302824601402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302824601402 : Closed e302824601402 ∧ code e302824601402 = 1402336229178 := by decide
theorem cert_e302824601402 : check e302824601402 [[],[],[.under]] .width = true := by decide
def e302824601486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e302824601486 : Closed e302824601486 ∧ code e302824601486 = 1402336229262 := by decide
theorem cert_e302824601486 : check e302824601486 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824601822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e302824601822 : Closed e302824601822 ∧ code e302824601822 = 1402336229598 := by decide
theorem cert_e302824601822 : check e302824601822 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824601850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e302824601850 : Closed e302824601850 ∧ code e302824601850 = 1402336229626 := by decide
theorem cert_e302824601850 : check e302824601850 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824602030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e302824602030 : Closed e302824602030 ∧ code e302824602030 = 1402336229806 := by decide
theorem cert_e302824602030 : check e302824602030 [[],[],[.under]] .width = true := by decide
def e302824602042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e302824602042 : Closed e302824602042 ∧ code e302824602042 = 1402336229818 := by decide
theorem cert_e302824602042 : check e302824602042 [[],[],[.under]] .width = true := by decide
def e302824602090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e302824602090 : Closed e302824602090 ∧ code e302824602090 = 1402336229866 := by decide
theorem cert_e302824602090 : check e302824602090 [[],[],[.under]] .width = true := by decide
def e302824602174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e302824602174 : Closed e302824602174 ∧ code e302824602174 = 1402336229950 := by decide
theorem cert_e302824602174 : check e302824602174 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824602222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302824602222 : Closed e302824602222 ∧ code e302824602222 = 1402336229998 := by decide
theorem cert_e302824602222 : check e302824602222 [[],[],[.under]] .width = true := by decide
def e302824602234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302824602234 : Closed e302824602234 ∧ code e302824602234 = 1402336230010 := by decide
theorem cert_e302824602234 : check e302824602234 [[],[],[.under]] .width = true := by decide
def e302824602522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302824602522 : Closed e302824602522 ∧ code e302824602522 = 1402336230298 := by decide
theorem cert_e302824602522 : check e302824602522 [[],[],[.under]] .width = true := by decide
def e302824602566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e302824602566 : Closed e302824602566 ∧ code e302824602566 = 1402336230342 := by decide
private def t_e302824602566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem cert_e302824602566 : ¬ IsSelfInterpreter e302824602566 :=
  wSource (t := t_e302824602566) (replay_sound (ps := []) (t := e302824602566) (by decide)) (by decide)
def e302824602838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e302824602838 : Closed e302824602838 ∧ code e302824602838 = 1402336230614 := by decide
theorem cert_e302824602838 : check e302824602838 [[],[],[.under]] .width = true := by decide
def e302824602842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e302824602842 : Closed e302824602842 ∧ code e302824602842 = 1402336230618 := by decide
theorem cert_e302824602842 : check e302824602842 [[],[],[.under]] .width = true := by decide
def e302824602858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e302824602858 : Closed e302824602858 ∧ code e302824602858 = 1402336230634 := by decide
theorem cert_e302824602858 : check e302824602858 [[],[],[.under]] .width = true := by decide
def e302824602934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302824602934 : Closed e302824602934 ∧ code e302824602934 = 1402336230710 := by decide
theorem cert_e302824602934 : check e302824602934 [[],[],[.under]] .width = true := by decide
def e302824602938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302824602938 : Closed e302824602938 ∧ code e302824602938 = 1402336230714 := by decide
theorem cert_e302824602938 : check e302824602938 [[],[],[.under]] .width = true := by decide
def e302824603034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302824603034 : Closed e302824603034 ∧ code e302824603034 = 1402336230810 := by decide
theorem cert_e302824603034 : check e302824603034 [[],[],[.under]] .width = true := by decide
def e302824603190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e302824603190 : Closed e302824603190 ∧ code e302824603190 = 1402336230966 := by decide
theorem cert_e302824603190 : check e302824603190 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824603194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e302824603194 : Closed e302824603194 ∧ code e302824603194 = 1402336230970 := by decide
theorem cert_e302824603194 : check e302824603194 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824603278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e302824603278 : Closed e302824603278 ∧ code e302824603278 = 1402336231054 := by decide
theorem cert_e302824603278 : check e302824603278 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824603334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e302824603334 : Closed e302824603334 ∧ code e302824603334 = 1402336231110 := by decide
private def t_e302824603334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem cert_e302824603334 : ¬ IsSelfInterpreter e302824603334 :=
  wSource (t := t_e302824603334) (replay_sound (ps := []) (t := e302824603334) (by decide)) (by decide)
def e302824606574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302824606574 : Closed e302824606574 ∧ code e302824606574 = 1402336234350 := by decide
theorem cert_e302824606574 : check e302824606574 [[],[],[.under]] .width = true := by decide
def e302824606582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302824606582 : Closed e302824606582 ∧ code e302824606582 = 1402336234358 := by decide
theorem cert_e302824606582 : check e302824606582 [[],[],[.under]] .width = true := by decide
def e302824606638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302824606638 : Closed e302824606638 ∧ code e302824606638 = 1402336234414 := by decide
theorem cert_e302824606638 : check e302824606638 [[],[],[.under]] .width = true := by decide
def e302824606650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302824606650 : Closed e302824606650 ∧ code e302824606650 = 1402336234426 := by decide
theorem cert_e302824606650 : check e302824606650 [[],[],[.under]] .width = true := by decide
def e302824606678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302824606678 : Closed e302824606678 ∧ code e302824606678 = 1402336234454 := by decide
theorem cert_e302824606678 : check e302824606678 [[],[],[.under]] .width = true := by decide
def e302824606682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302824606682 : Closed e302824606682 ∧ code e302824606682 = 1402336234458 := by decide
theorem cert_e302824606682 : check e302824606682 [[],[],[.under]] .width = true := by decide
def e302824606958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302824606958 : Closed e302824606958 ∧ code e302824606958 = 1402336234734 := by decide
theorem cert_e302824606958 : check e302824606958 [[],[],[.under]] .width = true := by decide
def e302824606966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302824606966 : Closed e302824606966 ∧ code e302824606966 = 1402336234742 := by decide
theorem cert_e302824606966 : check e302824606966 [[],[],[.under]] .width = true := by decide
def e302824607294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e302824607294 : Closed e302824607294 ∧ code e302824607294 = 1402336235070 := by decide
theorem cert_e302824607294 : check e302824607294 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824607342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302824607342 : Closed e302824607342 ∧ code e302824607342 = 1402336235118 := by decide
theorem cert_e302824607342 : check e302824607342 [[],[],[.under]] .width = true := by decide
def e302824607354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302824607354 : Closed e302824607354 ∧ code e302824607354 = 1402336235130 := by decide
theorem cert_e302824607354 : check e302824607354 [[],[],[.under]] .width = true := by decide
def e302824607542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302824607542 : Closed e302824607542 ∧ code e302824607542 = 1402336235318 := by decide
theorem cert_e302824607542 : check e302824607542 [[],[],[.under]] .width = true := by decide
def e302824607546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302824607546 : Closed e302824607546 ∧ code e302824607546 = 1402336235322 := by decide
theorem cert_e302824607546 : check e302824607546 [[],[],[.under]] .width = true := by decide
def e302824607630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e302824607630 : Closed e302824607630 ∧ code e302824607630 = 1402336235406 := by decide
theorem cert_e302824607630 : check e302824607630 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824613294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e302824613294 : Closed e302824613294 ∧ code e302824613294 = 1402336241070 := by decide
theorem cert_e302824613294 : check e302824613294 [[],[],[.under]] .width = true := by decide
def e302824613306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e302824613306 : Closed e302824613306 ∧ code e302824613306 = 1402336241082 := by decide
theorem cert_e302824613306 : check e302824613306 [[],[],[.under]] .width = true := by decide
def e302824613354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e302824613354 : Closed e302824613354 ∧ code e302824613354 = 1402336241130 := by decide
theorem cert_e302824613354 : check e302824613354 [[],[],[.under]] .width = true := by decide
def e302824613438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e302824613438 : Closed e302824613438 ∧ code e302824613438 = 1402336241214 := by decide
theorem cert_e302824613438 : check e302824613438 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824613486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e302824613486 : Closed e302824613486 ∧ code e302824613486 = 1402336241262 := by decide
theorem cert_e302824613486 : check e302824613486 [[],[],[.under]] .width = true := by decide
def e302824613498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e302824613498 : Closed e302824613498 ∧ code e302824613498 = 1402336241274 := by decide
theorem cert_e302824613498 : check e302824613498 [[],[],[.under]] .width = true := by decide
def e302824613786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e302824613786 : Closed e302824613786 ∧ code e302824613786 = 1402336241562 := by decide
theorem cert_e302824613786 : check e302824613786 [[],[],[.under]] .width = true := by decide
def e302824613830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e302824613830 : Closed e302824613830 ∧ code e302824613830 = 1402336241606 := by decide
theorem cert_e302824613830 : check e302824613830 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824616662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302824616662 : Closed e302824616662 ∧ code e302824616662 = 1402336244438 := by decide
theorem cert_e302824616662 : check e302824616662 [[],[],[.under]] .width = true := by decide
def e302824616666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302824616666 : Closed e302824616666 ∧ code e302824616666 = 1402336244442 := by decide
theorem cert_e302824616666 : check e302824616666 [[],[],[.under]] .width = true := by decide
def e302824616682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302824616682 : Closed e302824616682 ∧ code e302824616682 = 1402336244458 := by decide
theorem cert_e302824616682 : check e302824616682 [[],[],[.under]] .width = true := by decide
def e302824616758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302824616758 : Closed e302824616758 ∧ code e302824616758 = 1402336244534 := by decide
theorem cert_e302824616758 : check e302824616758 [[],[],[.under]] .width = true := by decide
def e302824616762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302824616762 : Closed e302824616762 ∧ code e302824616762 = 1402336244538 := by decide
theorem cert_e302824616762 : check e302824616762 [[],[],[.under]] .width = true := by decide
def e302824616858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302824616858 : Closed e302824616858 ∧ code e302824616858 = 1402336244634 := by decide
theorem cert_e302824616858 : check e302824616858 [[],[],[.under]] .width = true := by decide
def e302824618382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e302824618382 : Closed e302824618382 ∧ code e302824618382 = 1402336246158 := by decide
theorem cert_e302824618382 : check e302824618382 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824618438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e302824618438 : Closed e302824618438 ∧ code e302824618438 = 1402336246214 := by decide
theorem cert_e302824618438 : check e302824618438 [[],[],[.under],[.under,.under]] .three = true := by decide
def e302824730990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e302824730990 : Closed e302824730990 ∧ code e302824730990 = 1402336358766 := by decide
theorem cert_e302824730990 : check e302824730990 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302824730998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e302824730998 : Closed e302824730998 ∧ code e302824730998 = 1402336358774 := by decide
theorem cert_e302824730998 : check e302824730998 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302824732206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e302824732206 : Closed e302824732206 ∧ code e302824732206 = 1402336359982 := by decide
theorem cert_e302824732206 : check e302824732206 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e302824732386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e302824732386 : Closed e302824732386 ∧ code e302824732386 = 1402336360162 := by decide
theorem cert_e302824732386 : check e302824732386 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e302824732398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e302824732398 : Closed e302824732398 ∧ code e302824732398 = 1402336360174 := by decide
theorem cert_e302824732398 : check e302824732398 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e302824732438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302824732438 : Closed e302824732438 ∧ code e302824732438 = 1402336360214 := by decide
private def t_e302824732438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem cert_e302824732438 : ¬ IsSelfInterpreter e302824732438 :=
  wSource (t := t_e302824732438) (replay_sound (ps := []) (t := e302824732438) (by decide)) (by decide)
def e302824732514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302824732514 : Closed e302824732514 ∧ code e302824732514 = 1402336360290 := by decide
private def t_e302824732514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem cert_e302824732514 : ¬ IsSelfInterpreter e302824732514 :=
  wSource (t := t_e302824732514) (replay_sound (ps := []) (t := e302824732514) (by decide)) (by decide)
def e302824732526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e302824732526 : Closed e302824732526 ∧ code e302824732526 = 1402336360302 := by decide
private def t_e302824732526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem cert_e302824732526 : ¬ IsSelfInterpreter e302824732526 :=
  wSource (t := t_e302824732526) (replay_sound (ps := []) (t := e302824732526) (by decide)) (by decide)
def e302824732534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e302824732534 : Closed e302824732534 ∧ code e302824732534 = 1402336360310 := by decide
private def t_e302824732534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem cert_e302824732534 : ¬ IsSelfInterpreter e302824732534 :=
  wSource (t := t_e302824732534) (replay_sound (ps := []) (t := e302824732534) (by decide)) (by decide)
def e302824732846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e302824732846 : Closed e302824732846 ∧ code e302824732846 = 1402336360622 := by decide
theorem cert_e302824732846 : check e302824732846 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824732858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e302824732858 : Closed e302824732858 ∧ code e302824732858 = 1402336360634 := by decide
theorem cert_e302824732858 : check e302824732858 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824733230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e302824733230 : Closed e302824733230 ∧ code e302824733230 = 1402336361006 := by decide
theorem cert_e302824733230 : check e302824733230 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824733410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e302824733410 : Closed e302824733410 ∧ code e302824733410 = 1402336361186 := by decide
theorem cert_e302824733410 : check e302824733410 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824733422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e302824733422 : Closed e302824733422 ∧ code e302824733422 = 1402336361198 := by decide
theorem cert_e302824733422 : check e302824733422 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824733578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e302824733578 : Closed e302824733578 ∧ code e302824733578 = 1402336361354 := by decide
theorem cert_e302824733578 : check e302824733578 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824733602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e302824733602 : Closed e302824733602 ∧ code e302824733602 = 1402336361378 := by decide
theorem cert_e302824733602 : check e302824733602 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824733614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e302824733614 : Closed e302824733614 ∧ code e302824733614 = 1402336361390 := by decide
theorem cert_e302824733614 : check e302824733614 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824733626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e302824733626 : Closed e302824733626 ∧ code e302824733626 = 1402336361402 := by decide
theorem cert_e302824733626 : check e302824733626 [[],[],[.under],[.under,.under]] .sourceHead = true := by decide
def e302824733782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e302824733782 : Closed e302824733782 ∧ code e302824733782 = 1402336361558 := by decide
theorem cert_e302824733782 : check e302824733782 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e302824733786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e302824733786 : Closed e302824733786 ∧ code e302824733786 = 1402336361562 := by decide
theorem cert_e302824733786 : check e302824733786 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e302824733974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302824733974 : Closed e302824733974 ∧ code e302824733974 = 1402336361750 := by decide
private def t_e302824733974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem cert_e302824733974 : ¬ IsSelfInterpreter e302824733974 :=
  wSource (t := t_e302824733974) (replay_sound (ps := []) (t := e302824733974) (by decide)) (by decide)
def e302824734050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302824734050 : Closed e302824734050 ∧ code e302824734050 = 1402336361826 := by decide
private def t_e302824734050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem cert_e302824734050 : ¬ IsSelfInterpreter e302824734050 :=
  wSource (t := t_e302824734050) (replay_sound (ps := []) (t := e302824734050) (by decide)) (by decide)
def e302824734062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e302824734062 : Closed e302824734062 ∧ code e302824734062 = 1402336361838 := by decide
private def t_e302824734062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem cert_e302824734062 : ¬ IsSelfInterpreter e302824734062 :=
  wSource (t := t_e302824734062) (replay_sound (ps := []) (t := e302824734062) (by decide)) (by decide)
def e302824734070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e302824734070 : Closed e302824734070 ∧ code e302824734070 = 1402336361846 := by decide
private def t_e302824734070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem cert_e302824734070 : ¬ IsSelfInterpreter e302824734070 :=
  wSource (t := t_e302824734070) (replay_sound (ps := []) (t := e302824734070) (by decide)) (by decide)
def e302824734090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e302824734090 : Closed e302824734090 ∧ code e302824734090 = 1402336361866 := by decide
theorem cert_e302824734090 : check e302824734090 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e302824734114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e302824734114 : Closed e302824734114 ∧ code e302824734114 = 1402336361890 := by decide
theorem cert_e302824734114 : check e302824734114 [[],[],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e302824734126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e302824734126 : Closed e302824734126 ∧ code e302824734126 = 1402336361902 := by decide
theorem cert_e302824734126 : checkPay e302824734126 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left]] 0 [[.under,.left,.left,.right,.under,.left,.left],[.under,.left,.left,.right,.under,.left,.left,.left,.left],[.under,.left,.left,.right,.under,.left,.left,.left],[.under,.left,.left,.right,.under,.right,.under,.left,.left],[.under,.left,.left,.right,.under,.right,.under,.left]] = true := by decide
def e302824734138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e302824734138 : Closed e302824734138 ∧ code e302824734138 = 1402336361914 := by decide
theorem cert_e302824734138 : checkPay e302824734138 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left]] 0 [] = true := by decide
def e302824734166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e302824734166 : Closed e302824734166 ∧ code e302824734166 = 1402336361942 := by decide
private def t_e302824734166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e302824734166 : ¬ IsSelfInterpreter e302824734166 :=
  wSource (t := t_e302824734166) (replay_sound (ps := []) (t := e302824734166) (by decide)) (by decide)
def e302824734170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e302824734170 : Closed e302824734170 ∧ code e302824734170 = 1402336361946 := by decide
private def t_e302824734170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e302824734170 : ¬ IsSelfInterpreter e302824734170 :=
  wSource (t := t_e302824734170) (replay_sound (ps := []) (t := e302824734170) (by decide)) (by decide)
def e302824735214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e302824735214 : Closed e302824735214 ∧ code e302824735214 = 1402336362990 := by decide
theorem cert_e302824735214 : check e302824735214 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left]] .smaller = true := by decide
def e302824735222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e302824735222 : Closed e302824735222 ∧ code e302824735222 = 1402336362998 := by decide
theorem cert_e302824735222 : check e302824735222 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302824735982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e302824735982 : Closed e302824735982 ∧ code e302824735982 = 1402336363758 := by decide
theorem cert_e302824735982 : check e302824735982 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302824735990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e302824735990 : Closed e302824735990 ∧ code e302824735990 = 1402336363766 := by decide
theorem cert_e302824735990 : checkPay e302824735990 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left]] 0 [] = true := by decide
def e302824736542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e302824736542 : Closed e302824736542 ∧ code e302824736542 = 1402336364318 := by decide
theorem cert_e302824736542 : checkPay e302824736542 [[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left]] 0 [] = true := by decide
def e302824736654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e302824736654 : Closed e302824736654 ∧ code e302824736654 = 1402336364430 := by decide
theorem cert_e302824736654 : check e302824736654 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302824738350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e302824738350 : Closed e302824738350 ∧ code e302824738350 = 1402336366126 := by decide
theorem cert_e302824738350 : check e302824738350 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e302824738530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e302824738530 : Closed e302824738530 ∧ code e302824738530 = 1402336366306 := by decide
theorem cert_e302824738530 : check e302824738530 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e302824738542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e302824738542 : Closed e302824738542 ∧ code e302824738542 = 1402336366318 := by decide
theorem cert_e302824738542 : check e302824738542 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e302824738582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e302824738582 : Closed e302824738582 ∧ code e302824738582 = 1402336366358 := by decide
theorem cert_e302824738582 : check e302824738582 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302824738658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e302824738658 : Closed e302824738658 ∧ code e302824738658 = 1402336366434 := by decide
theorem cert_e302824738658 : check e302824738658 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e302824738670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e302824738670 : Closed e302824738670 ∧ code e302824738670 = 1402336366446 := by decide
theorem cert_e302824738670 : check e302824738670 [[],[],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e302824738678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e302824738678 : Closed e302824738678 ∧ code e302824738678 = 1402336366454 := by decide
private def t_e302824738678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem cert_e302824738678 : ¬ IsSelfInterpreter e302824738678 :=
  wSource (t := t_e302824738678) (replay_sound (ps := []) (t := e302824738678) (by decide)) (by decide)
def e302824740926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e302824740926 : Closed e302824740926 ∧ code e302824740926 = 1402336368702 := by decide
theorem cert_e302824740926 : check e302824740926 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e302824741346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e302824741346 : Closed e302824741346 ∧ code e302824741346 = 1402336369122 := by decide
theorem cert_e302824741346 : check e302824741346 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e302824741358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e302824741358 : Closed e302824741358 ∧ code e302824741358 = 1402336369134 := by decide
theorem cert_e302824741358 : check e302824741358 [[],[],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e302824741918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e302824741918 : Closed e302824741918 ∧ code e302824741918 = 1402336369694 := by decide
private def t_e302824741918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem cert_e302824741918 : ¬ IsSelfInterpreter e302824741918 :=
  wSource (t := t_e302824741918) (replay_sound (ps := []) (t := e302824741918) (by decide)) (by decide)
def e302824742114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302824742114 : Closed e302824742114 ∧ code e302824742114 = 1402336369890 := by decide
private def t_e302824742114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem cert_e302824742114 : ¬ IsSelfInterpreter e302824742114 :=
  wSource (t := t_e302824742114) (replay_sound (ps := []) (t := e302824742114) (by decide)) (by decide)
def e302824742126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e302824742126 : Closed e302824742126 ∧ code e302824742126 = 1402336369902 := by decide
private def t_e302824742126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem cert_e302824742126 : ¬ IsSelfInterpreter e302824742126 :=
  wSource (t := t_e302824742126) (replay_sound (ps := []) (t := e302824742126) (by decide)) (by decide)
def e302824742134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e302824742134 : Closed e302824742134 ∧ code e302824742134 = 1402336369910 := by decide
private def t_e302824742134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem cert_e302824742134 : ¬ IsSelfInterpreter e302824742134 :=
  wSource (t := t_e302824742134) (replay_sound (ps := []) (t := e302824742134) (by decide)) (by decide)
def e302824743150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e302824743150 : Closed e302824743150 ∧ code e302824743150 = 1402336370926 := by decide
theorem cert_e302824743150 : checkPay e302824743150 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.under,.under,.left],[.under,.under,.under,.left,.left],[.under,.under,.under,.left]] = true := by decide
def e302824743162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e302824743162 : Closed e302824743162 ∧ code e302824743162 = 1402336370938 := by decide
theorem cert_e302824743162 : checkPay e302824743162 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e302824743534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e302824743534 : Closed e302824743534 ∧ code e302824743534 = 1402336371310 := by decide
theorem cert_e302824743534 : checkPay e302824743534 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e302824743546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e302824743546 : Closed e302824743546 ∧ code e302824743546 = 1402336371322 := by decide
theorem cert_e302824743546 : checkPay e302824743546 [[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
end Blc.Floor40
