import CodeBridge
import R302824804150Blk0
import R302824804150Blk6
namespace Certgen.R302824804150
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit150 : Term := .var 0
def lit131 : Term := .var 1
def lit93 : Term := .var 2
def lit123 : Term := .lam lit150
def lit130 : Term := .lam lit131
def lit122 : Term := .lam lit123
def lit148 : Term := .app lit150 lit150
def lit94 : Term := .app lit150 lit131
def lit129 : Term := .lam lit130
def lit132 : Term := .var 5
def lit147 : Term := .lam lit148
def lit120 : Term := .app lit150 lit122
def lit127 : Term := .app lit150 lit129
def lit92 : Term := .app lit93 lit94
def lit142 : Term := .app lit147 lit147
def lit90 : Term := .app lit93 lit92
def lit126 : Term := .app lit127 lit132
def lit89 : Term := .lam lit90
def lit125 : Term := .lam lit126
def lit87 : Term := .app lit131 lit89
def lit86 : Term := .lam lit87
def lit85 : Term := .lam lit86
def lit119 : Term := .app lit120 lit125
def lit118 : Term := .lam lit119
def lit84 : Term := .app lit85 lit120
def lit112 : Term := .app lit127 lit118
def lit111 : Term := .lam lit112
def lit105 : Term := .app lit127 lit111
def lit104 : Term := .lam lit105
def lit102 : Term := .app lit150 lit104
def lit71 : Term := .app lit85 lit84
def lit70 : Term := .lam lit71
def lit69 : Term := .app lit70 lit102
def lit36 : Term := .app lit70 lit69
def lit35 : Term := .lam lit36
def lit2 : Term := .app lit70 lit35
def lit1 : Term := .app lit2 lit142
def lit0 : Term := .app lit1 lit142
def filling : Nat → Term := fun p => if p = 132 then Term.var 5 else Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub150 : model.term 150 = lit150 := model.var_eq 150 0 (by rfl)
theorem sub149 : model.term 149 = lit150 := model.var_eq 149 0 (by rfl)
theorem sub148 : model.term 148 = lit148 := by rw [model.app_eq 148 149 150 (by rfl), sub149, sub150]; rfl
theorem sub147 : model.term 147 = lit147 := by rw [model.lam_eq 147 148 (by rfl), sub148]; rfl
theorem sub146 : model.term 146 = lit150 := model.var_eq 146 0 (by rfl)
theorem sub145 : model.term 145 = lit150 := model.var_eq 145 0 (by rfl)
theorem sub144 : model.term 144 = lit148 := by rw [model.app_eq 144 145 146 (by rfl), sub145, sub146]; rfl
theorem sub143 : model.term 143 = lit147 := by rw [model.lam_eq 143 144 (by rfl), sub144]; rfl
theorem sub142 : model.term 142 = lit142 := by rw [model.app_eq 142 143 147 (by rfl), sub143, sub147]; rfl
theorem sub141 : model.term 141 = lit150 := model.var_eq 141 0 (by rfl)
theorem sub140 : model.term 140 = lit150 := model.var_eq 140 0 (by rfl)
theorem sub139 : model.term 139 = lit148 := by rw [model.app_eq 139 140 141 (by rfl), sub140, sub141]; rfl
theorem sub138 : model.term 138 = lit147 := by rw [model.lam_eq 138 139 (by rfl), sub139]; rfl
theorem sub137 : model.term 137 = lit150 := model.var_eq 137 0 (by rfl)
theorem sub136 : model.term 136 = lit150 := model.var_eq 136 0 (by rfl)
theorem sub135 : model.term 135 = lit148 := by rw [model.app_eq 135 136 137 (by rfl), sub136, sub137]; rfl
theorem sub134 : model.term 134 = lit147 := by rw [model.lam_eq 134 135 (by rfl), sub135]; rfl
theorem sub133 : model.term 133 = lit142 := by rw [model.app_eq 133 134 138 (by rfl), sub134, sub138]; rfl
theorem sub132 : model.term 132 = lit132 := (opaqueTerm (rankedCode code ordered_code) filling (p := 132) (by rfl)).trans (by rfl)
theorem sub131 : model.term 131 = lit131 := model.var_eq 131 1 (by rfl)
theorem sub130 : model.term 130 = lit130 := by rw [model.lam_eq 130 131 (by rfl), sub131]; rfl
theorem sub129 : model.term 129 = lit129 := by rw [model.lam_eq 129 130 (by rfl), sub130]; rfl
theorem sub128 : model.term 128 = lit150 := model.var_eq 128 0 (by rfl)
theorem sub127 : model.term 127 = lit127 := by rw [model.app_eq 127 128 129 (by rfl), sub128, sub129]; rfl
theorem sub126 : model.term 126 = lit126 := by rw [model.app_eq 126 127 132 (by rfl), sub127, sub132]; rfl
theorem sub125 : model.term 125 = lit125 := by rw [model.lam_eq 125 126 (by rfl), sub126]; rfl
theorem sub124 : model.term 124 = lit150 := model.var_eq 124 0 (by rfl)
theorem sub123 : model.term 123 = lit123 := by rw [model.lam_eq 123 124 (by rfl), sub124]; rfl
theorem sub122 : model.term 122 = lit122 := by rw [model.lam_eq 122 123 (by rfl), sub123]; rfl
theorem sub121 : model.term 121 = lit150 := model.var_eq 121 0 (by rfl)
theorem sub120 : model.term 120 = lit120 := by rw [model.app_eq 120 121 122 (by rfl), sub121, sub122]; rfl
theorem sub119 : model.term 119 = lit119 := by rw [model.app_eq 119 120 125 (by rfl), sub120, sub125]; rfl
theorem sub118 : model.term 118 = lit118 := by rw [model.lam_eq 118 119 (by rfl), sub119]; rfl
theorem sub117 : model.term 117 = lit131 := model.var_eq 117 1 (by rfl)
theorem sub116 : model.term 116 = lit130 := by rw [model.lam_eq 116 117 (by rfl), sub117]; rfl
theorem sub115 : model.term 115 = lit129 := by rw [model.lam_eq 115 116 (by rfl), sub116]; rfl
theorem sub114 : model.term 114 = lit150 := model.var_eq 114 0 (by rfl)
theorem sub113 : model.term 113 = lit127 := by rw [model.app_eq 113 114 115 (by rfl), sub114, sub115]; rfl
theorem sub112 : model.term 112 = lit112 := by rw [model.app_eq 112 113 118 (by rfl), sub113, sub118]; rfl
theorem sub111 : model.term 111 = lit111 := by rw [model.lam_eq 111 112 (by rfl), sub112]; rfl
theorem sub110 : model.term 110 = lit131 := model.var_eq 110 1 (by rfl)
theorem sub109 : model.term 109 = lit130 := by rw [model.lam_eq 109 110 (by rfl), sub110]; rfl
theorem sub108 : model.term 108 = lit129 := by rw [model.lam_eq 108 109 (by rfl), sub109]; rfl
theorem sub107 : model.term 107 = lit150 := model.var_eq 107 0 (by rfl)
theorem sub106 : model.term 106 = lit127 := by rw [model.app_eq 106 107 108 (by rfl), sub107, sub108]; rfl
theorem sub105 : model.term 105 = lit105 := by rw [model.app_eq 105 106 111 (by rfl), sub106, sub111]; rfl
theorem sub104 : model.term 104 = lit104 := by rw [model.lam_eq 104 105 (by rfl), sub105]; rfl
theorem sub103 : model.term 103 = lit150 := model.var_eq 103 0 (by rfl)
theorem sub102 : model.term 102 = lit102 := by rw [model.app_eq 102 103 104 (by rfl), sub103, sub104]; rfl
theorem sub101 : model.term 101 = lit150 := model.var_eq 101 0 (by rfl)
theorem sub100 : model.term 100 = lit123 := by rw [model.lam_eq 100 101 (by rfl), sub101]; rfl
theorem sub99 : model.term 99 = lit122 := by rw [model.lam_eq 99 100 (by rfl), sub100]; rfl
theorem sub98 : model.term 98 = lit150 := model.var_eq 98 0 (by rfl)
theorem sub97 : model.term 97 = lit120 := by rw [model.app_eq 97 98 99 (by rfl), sub98, sub99]; rfl
theorem sub96 : model.term 96 = lit131 := model.var_eq 96 1 (by rfl)
theorem sub95 : model.term 95 = lit150 := model.var_eq 95 0 (by rfl)
theorem sub94 : model.term 94 = lit94 := by rw [model.app_eq 94 95 96 (by rfl), sub95, sub96]; rfl
theorem sub93 : model.term 93 = lit93 := model.var_eq 93 2 (by rfl)
theorem sub92 : model.term 92 = lit92 := by rw [model.app_eq 92 93 94 (by rfl), sub93, sub94]; rfl
theorem sub91 : model.term 91 = lit93 := model.var_eq 91 2 (by rfl)
theorem sub90 : model.term 90 = lit90 := by rw [model.app_eq 90 91 92 (by rfl), sub91, sub92]; rfl
theorem sub89 : model.term 89 = lit89 := by rw [model.lam_eq 89 90 (by rfl), sub90]; rfl
theorem sub88 : model.term 88 = lit131 := model.var_eq 88 1 (by rfl)
theorem sub87 : model.term 87 = lit87 := by rw [model.app_eq 87 88 89 (by rfl), sub88, sub89]; rfl
theorem sub86 : model.term 86 = lit86 := by rw [model.lam_eq 86 87 (by rfl), sub87]; rfl
theorem sub85 : model.term 85 = lit85 := by rw [model.lam_eq 85 86 (by rfl), sub86]; rfl
theorem sub84 : model.term 84 = lit84 := by rw [model.app_eq 84 85 97 (by rfl), sub85, sub97]; rfl
theorem sub83 : model.term 83 = lit131 := model.var_eq 83 1 (by rfl)
theorem sub82 : model.term 82 = lit150 := model.var_eq 82 0 (by rfl)
theorem sub81 : model.term 81 = lit94 := by rw [model.app_eq 81 82 83 (by rfl), sub82, sub83]; rfl
theorem sub80 : model.term 80 = lit93 := model.var_eq 80 2 (by rfl)
theorem sub79 : model.term 79 = lit92 := by rw [model.app_eq 79 80 81 (by rfl), sub80, sub81]; rfl
theorem sub78 : model.term 78 = lit93 := model.var_eq 78 2 (by rfl)
theorem sub77 : model.term 77 = lit90 := by rw [model.app_eq 77 78 79 (by rfl), sub78, sub79]; rfl
theorem sub76 : model.term 76 = lit89 := by rw [model.lam_eq 76 77 (by rfl), sub77]; rfl
theorem sub75 : model.term 75 = lit131 := model.var_eq 75 1 (by rfl)
theorem sub74 : model.term 74 = lit87 := by rw [model.app_eq 74 75 76 (by rfl), sub75, sub76]; rfl
theorem sub73 : model.term 73 = lit86 := by rw [model.lam_eq 73 74 (by rfl), sub74]; rfl
theorem sub72 : model.term 72 = lit85 := by rw [model.lam_eq 72 73 (by rfl), sub73]; rfl
theorem sub71 : model.term 71 = lit71 := by rw [model.app_eq 71 72 84 (by rfl), sub72, sub84]; rfl
theorem sub70 : model.term 70 = lit70 := by rw [model.lam_eq 70 71 (by rfl), sub71]; rfl
theorem sub69 : model.term 69 = lit69 := by rw [model.app_eq 69 70 102 (by rfl), sub70, sub102]; rfl
theorem sub68 : model.term 68 = lit150 := model.var_eq 68 0 (by rfl)
theorem sub67 : model.term 67 = lit123 := by rw [model.lam_eq 67 68 (by rfl), sub68]; rfl
theorem sub66 : model.term 66 = lit122 := by rw [model.lam_eq 66 67 (by rfl), sub67]; rfl
theorem sub65 : model.term 65 = lit150 := model.var_eq 65 0 (by rfl)
theorem sub64 : model.term 64 = lit120 := by rw [model.app_eq 64 65 66 (by rfl), sub65, sub66]; rfl
theorem sub63 : model.term 63 = lit131 := model.var_eq 63 1 (by rfl)
theorem sub62 : model.term 62 = lit150 := model.var_eq 62 0 (by rfl)
theorem sub61 : model.term 61 = lit94 := by rw [model.app_eq 61 62 63 (by rfl), sub62, sub63]; rfl
theorem sub60 : model.term 60 = lit93 := model.var_eq 60 2 (by rfl)
theorem sub59 : model.term 59 = lit92 := by rw [model.app_eq 59 60 61 (by rfl), sub60, sub61]; rfl
theorem sub58 : model.term 58 = lit93 := model.var_eq 58 2 (by rfl)
theorem sub57 : model.term 57 = lit90 := by rw [model.app_eq 57 58 59 (by rfl), sub58, sub59]; rfl
theorem sub56 : model.term 56 = lit89 := by rw [model.lam_eq 56 57 (by rfl), sub57]; rfl
theorem sub55 : model.term 55 = lit131 := model.var_eq 55 1 (by rfl)
theorem sub54 : model.term 54 = lit87 := by rw [model.app_eq 54 55 56 (by rfl), sub55, sub56]; rfl
theorem sub53 : model.term 53 = lit86 := by rw [model.lam_eq 53 54 (by rfl), sub54]; rfl
theorem sub52 : model.term 52 = lit85 := by rw [model.lam_eq 52 53 (by rfl), sub53]; rfl
theorem sub51 : model.term 51 = lit84 := by rw [model.app_eq 51 52 64 (by rfl), sub52, sub64]; rfl
theorem sub50 : model.term 50 = lit131 := model.var_eq 50 1 (by rfl)
theorem sub49 : model.term 49 = lit150 := model.var_eq 49 0 (by rfl)
theorem sub48 : model.term 48 = lit94 := by rw [model.app_eq 48 49 50 (by rfl), sub49, sub50]; rfl
theorem sub47 : model.term 47 = lit93 := model.var_eq 47 2 (by rfl)
theorem sub46 : model.term 46 = lit92 := by rw [model.app_eq 46 47 48 (by rfl), sub47, sub48]; rfl
theorem sub45 : model.term 45 = lit93 := model.var_eq 45 2 (by rfl)
theorem sub44 : model.term 44 = lit90 := by rw [model.app_eq 44 45 46 (by rfl), sub45, sub46]; rfl
theorem sub43 : model.term 43 = lit89 := by rw [model.lam_eq 43 44 (by rfl), sub44]; rfl
theorem sub42 : model.term 42 = lit131 := model.var_eq 42 1 (by rfl)
theorem sub41 : model.term 41 = lit87 := by rw [model.app_eq 41 42 43 (by rfl), sub42, sub43]; rfl
theorem sub40 : model.term 40 = lit86 := by rw [model.lam_eq 40 41 (by rfl), sub41]; rfl
theorem sub39 : model.term 39 = lit85 := by rw [model.lam_eq 39 40 (by rfl), sub40]; rfl
theorem sub38 : model.term 38 = lit71 := by rw [model.app_eq 38 39 51 (by rfl), sub39, sub51]; rfl
theorem sub37 : model.term 37 = lit70 := by rw [model.lam_eq 37 38 (by rfl), sub38]; rfl
theorem sub36 : model.term 36 = lit36 := by rw [model.app_eq 36 37 69 (by rfl), sub37, sub69]; rfl
theorem sub35 : model.term 35 = lit35 := by rw [model.lam_eq 35 36 (by rfl), sub36]; rfl
theorem sub34 : model.term 34 = lit150 := model.var_eq 34 0 (by rfl)
theorem sub33 : model.term 33 = lit123 := by rw [model.lam_eq 33 34 (by rfl), sub34]; rfl
theorem sub32 : model.term 32 = lit122 := by rw [model.lam_eq 32 33 (by rfl), sub33]; rfl
theorem sub31 : model.term 31 = lit150 := model.var_eq 31 0 (by rfl)
theorem sub30 : model.term 30 = lit120 := by rw [model.app_eq 30 31 32 (by rfl), sub31, sub32]; rfl
theorem sub29 : model.term 29 = lit131 := model.var_eq 29 1 (by rfl)
theorem sub28 : model.term 28 = lit150 := model.var_eq 28 0 (by rfl)
theorem sub27 : model.term 27 = lit94 := by rw [model.app_eq 27 28 29 (by rfl), sub28, sub29]; rfl
theorem sub26 : model.term 26 = lit93 := model.var_eq 26 2 (by rfl)
theorem sub25 : model.term 25 = lit92 := by rw [model.app_eq 25 26 27 (by rfl), sub26, sub27]; rfl
theorem sub24 : model.term 24 = lit93 := model.var_eq 24 2 (by rfl)
theorem sub23 : model.term 23 = lit90 := by rw [model.app_eq 23 24 25 (by rfl), sub24, sub25]; rfl
theorem sub22 : model.term 22 = lit89 := by rw [model.lam_eq 22 23 (by rfl), sub23]; rfl
theorem sub21 : model.term 21 = lit131 := model.var_eq 21 1 (by rfl)
theorem sub20 : model.term 20 = lit87 := by rw [model.app_eq 20 21 22 (by rfl), sub21, sub22]; rfl
theorem sub19 : model.term 19 = lit86 := by rw [model.lam_eq 19 20 (by rfl), sub20]; rfl
theorem sub18 : model.term 18 = lit85 := by rw [model.lam_eq 18 19 (by rfl), sub19]; rfl
theorem sub17 : model.term 17 = lit84 := by rw [model.app_eq 17 18 30 (by rfl), sub18, sub30]; rfl
theorem sub16 : model.term 16 = lit131 := model.var_eq 16 1 (by rfl)
theorem sub15 : model.term 15 = lit150 := model.var_eq 15 0 (by rfl)
theorem sub14 : model.term 14 = lit94 := by rw [model.app_eq 14 15 16 (by rfl), sub15, sub16]; rfl
theorem sub13 : model.term 13 = lit93 := model.var_eq 13 2 (by rfl)
theorem sub12 : model.term 12 = lit92 := by rw [model.app_eq 12 13 14 (by rfl), sub13, sub14]; rfl
theorem sub11 : model.term 11 = lit93 := model.var_eq 11 2 (by rfl)
theorem sub10 : model.term 10 = lit90 := by rw [model.app_eq 10 11 12 (by rfl), sub11, sub12]; rfl
theorem sub9 : model.term 9 = lit89 := by rw [model.lam_eq 9 10 (by rfl), sub10]; rfl
theorem sub8 : model.term 8 = lit131 := model.var_eq 8 1 (by rfl)
theorem sub7 : model.term 7 = lit87 := by rw [model.app_eq 7 8 9 (by rfl), sub8, sub9]; rfl
theorem sub6 : model.term 6 = lit86 := by rw [model.lam_eq 6 7 (by rfl), sub7]; rfl
theorem sub5 : model.term 5 = lit85 := by rw [model.lam_eq 5 6 (by rfl), sub6]; rfl
theorem sub4 : model.term 4 = lit71 := by rw [model.app_eq 4 5 17 (by rfl), sub5, sub17]; rfl
theorem sub3 : model.term 3 = lit70 := by rw [model.lam_eq 3 4 (by rfl), sub4]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 35 (by rfl), sub3, sub35]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 133 (by rfl), sub2, sub133]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 142 (by rfl), sub1, sub142]; rfl
theorem allValid (i : Nat) (h : i < 95) : validState i = true := by
 by_cases h48 : i < 48
 · by_cases h24 : i < 24
   · by_cases h12 : i < 12
     · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
   · by_cases h36 : i < 36
     · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
 · by_cases h72 : i < 72
   · by_cases h60 : i < 60
     · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
   · by_cases h84 : i < 84
     · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 95
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e302824804150 := by
 intro he
 have hp : replay [[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] (call e302824804150 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R302824804150
