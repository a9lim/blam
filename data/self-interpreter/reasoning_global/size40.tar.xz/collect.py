from candidates import *
import re
rows=json.loads((HERE/'certs.json').read_text());rw=json.loads((HERE/'weighted.json').read_text())
wires=sorted(rows); names=[];imports=set();records=[];rs=[];covered=set()
for j,s in enumerate(wires):
    x=str(int(s,2));ename='e'+x
    bmod=f'Batch{j//160:03}';batch=(HERE/(bmod+'.lean')).read_text()
    from genlean import expr
    e,rest=lc.decode(s);assert rest==len(s) and lc.enc(e)==s
    assert f'def {ename} : Term := {expr(e)}\n' in batch
    assert f'theorem wire_{ename} : Closed {ename} ∧ code {ename} = {int("1"+s,2)} := by decide' in batch
    k=rows[s][0];module=bmod;theorem='Blc.Floor40.cert_'+ename
    if k=='open':
        if s in rw:
            module='WeightedRows';theorem='Blc.Floor40.WeightedRows.ex_'+ename;kind='weighted_rank'
        elif x=='302887566022':module='Parity';theorem='Blc.Floor40.Parity.excluded';kind='swap_parity'
        else:module='R'+x;theorem='Certgen.'+module+'.excluded';kind='regular'
        p=(HERE/(module+'.lean')).read_text();name=theorem.split('.')[-1]
        assert f'theorem {name} : ¬ IsSelfInterpreter {ename} := by' in p
        assert (HERE/(module+'.olean')).exists() and theorem in (HERE/(module+'.log')).read_text()
        imports.add(module);names.append((ename,theorem))
        k=kind
    else:
        assert f'theorem cert_{ename} :' in batch
    strength='complete' if k in ('weighted_rank','swap_parity','regular','Wsource','Widentity') else 'predicate'
    record=dict(wire=s,root='literal' if s[:2]=='00' else 'app',triple=counts(e),kind=k,strength=strength,module=module,theorem=theorem)
    if k=='weighted_rank':record.update(charge=rw[s][0],probe=rw[s][1],replay=rw[s][2])
    if k=='regular':
        p=HERE/('h'+x+'.json')
        if not p.exists():p=HERE/('r'+x+'.json')
        n,kind,j,kc,mode,ps,c=json.loads(p.read_text())
        record.update(states=n,probe=kind,prefix=ps)
    records.append(record)
assert len(names)==92 and len(wires)==10284
s=''.join('import '+m+'\n' for m in sorted(imports))+'namespace Blc.Floor40\n'
s+='def residuals : List Term := ['+','.join(e for e,_ in names)+']\n'
# Incremental list construction avoids any fragile giant case split.
for i,(e,t) in reversed(list(enumerate(names))):
    prev='[]' if i+1==len(names) else 'rs'+str(i+1)
    s+=f'private def rs{i} := {e} :: {prev}\n'
    base='by simp at h' if i+1==len(names) else f'exact reject{i+1} _ h'
    s+=f'private theorem reject{i} (t : Term) (h : t ∈ rs{i}) : ¬ IsSelfInterpreter t := by\n  rcases List.mem_cons.mp h with rfl | h\n  · exact {t}\n  · '+('simp at h' if base.startswith('by') else base)+'\n'
s+='theorem residuals_excluded (t : Term) (h : t ∈ residuals) : ¬ IsSelfInterpreter t := reject0 t h\n#print axioms residuals_excluded\nend Blc.Floor40\n'
(HERE/'Residuals.lean').write_text(s)
(HERE/'ledger.json').write_text(json.dumps(records,separators=(',',':')))
print(Counter(x['kind'] for x in records))
print(Counter(x['strength'] for x in records))
