def bridge(out,c,ts,idx):
    import re
    pos=out.index('def terms : Array Term')
    end=out.index('theorem excluded')
    before=out[:pos]
    after=out[end:]
    before=before.replace('import RegularBase','import CodeBridge')
    fill='fun p => '+''.join(f'if p = {j} then Term.var {n[1]} else ' for j,n in enumerate(c['nodes']) if n[0]=='C')+'Term.var 0'
    rows=[f'def filling : Nat → Term := {fill}',
        'theorem ordered_code : ordered code = true := by decide +kernel',
        'def model : Model P := codeModel (rankedCode code ordered_code) filling']
    for j in reversed(range(len(ts))):
        n=c['nodes'][j];k=n[0];rhs=f'lit{idx[ts[j]]}'
        if k=='A':
            f,a=n[1:];pf=f'by rw [model.app_eq {j} {f} {a} (by rfl), sub{f}, sub{a}]; rfl'
        elif k=='L':
            b=n[1];pf=f'by rw [model.lam_eq {j} {b} (by rfl), sub{b}]; rfl'
        elif k=='V':pf=f'model.var_eq {j} {n[1]} (by rfl)'
        else:pf=f'(opaqueTerm (rankedCode code ordered_code) filling (p := {j}) (by rfl)).trans (by rfl)'
        rows.append(f'theorem sub{j} : model.term {j} = {rhs} := {pf}')
    return before+'\n'.join(rows)+'\n'+after.replace('some (model.term 0) := by decide','some (model.term 0) := by rw [sub0]; decide')
