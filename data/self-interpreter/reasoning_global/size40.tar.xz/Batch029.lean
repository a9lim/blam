import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302394138254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302394138254 : Closed e302394138254 ∧ code e302394138254 = 1401905766030 := by decide
theorem cert_e302394138254 : check e302394138254 [[],[]] .sourceHead = true := by decide
def e302394138310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302394138310 : Closed e302394138310 ∧ code e302394138310 = 1401905766086 := by decide
theorem cert_e302394138310 : check e302394138310 [[],[]] .sourceHead = true := by decide
def e302394140446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e302394140446 : Closed e302394140446 ∧ code e302394140446 = 1401905768222 := by decide
theorem cert_e302394140446 : check e302394140446 [[],[]] .sourceHead = true := by decide
def e302394140558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e302394140558 : Closed e302394140558 ∧ code e302394140558 = 1401905768334 := by decide
theorem cert_e302394140558 : check e302394140558 [[],[]] .sourceHead = true := by decide
def e302394143518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302394143518 : Closed e302394143518 ∧ code e302394143518 = 1401905771294 := by decide
theorem cert_e302394143518 : check e302394143518 [[],[]] .sourceHead = true := by decide
def e302394143686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302394143686 : Closed e302394143686 ∧ code e302394143686 = 1401905771462 := by decide
theorem cert_e302394143686 : check e302394143686 [[],[]] .sourceHead = true := by decide
def e302394145166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302394145166 : Closed e302394145166 ∧ code e302394145166 = 1401905772942 := by decide
theorem cert_e302394145166 : check e302394145166 [[],[]] .sourceHead = true := by decide
def e302394145222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302394145222 : Closed e302394145222 ∧ code e302394145222 = 1401905772998 := by decide
theorem cert_e302394145222 : check e302394145222 [[],[]] .sourceHead = true := by decide
def e302398838494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e302398838494 : Closed e302398838494 ∧ code e302398838494 = 1401910466270 := by decide
theorem cert_e302398838494 : check e302398838494 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e302398838518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e302398838518 : Closed e302398838518 ∧ code e302398838518 = 1401910466294 := by decide
theorem cert_e302398838518 : check e302398838518 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e302398838622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e302398838622 : Closed e302398838622 ∧ code e302398838622 = 1401910466398 := by decide
theorem cert_e302398838622 : check e302398838622 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302398838650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e302398838650 : Closed e302398838650 ∧ code e302398838650 = 1401910466426 := by decide
theorem cert_e302398838650 : checkPay e302398838650 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[],[],[]] = true := by decide
def e302398838742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e302398838742 : Closed e302398838742 ∧ code e302398838742 = 1401910466518 := by decide
theorem cert_e302398838742 : check e302398838742 [[],[],[.left],[.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e302398838746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e302398838746 : Closed e302398838746 ∧ code e302398838746 = 1401910466522 := by decide
theorem cert_e302398838746 : check e302398838746 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302398839262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e302398839262 : Closed e302398839262 ∧ code e302398839262 = 1401910467038 := by decide
theorem cert_e302398839262 : check e302398839262 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e302398839286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e302398839286 : Closed e302398839286 ∧ code e302398839286 = 1401910467062 := by decide
theorem cert_e302398839286 : check e302398839286 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e302398840030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e302398840030 : Closed e302398840030 ∧ code e302398840030 = 1401910467806 := by decide
theorem cert_e302398840030 : check e302398840030 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e302398840058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e302398840058 : Closed e302398840058 ∧ code e302398840058 = 1401910467834 := by decide
theorem cert_e302398840058 : check e302398840058 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e302398840630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e302398840630 : Closed e302398840630 ∧ code e302398840630 = 1401910468406 := by decide
theorem cert_e302398840630 : check e302398840630 [[],[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e302398840634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e302398840634 : Closed e302398840634 ∧ code e302398840634 = 1401910468410 := by decide
theorem cert_e302398840634 : check e302398840634 [[],[],[.left],[.left],[.left],[],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302398855406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e302398855406 : Closed e302398855406 ∧ code e302398855406 = 1401910483182 := by decide
theorem cert_e302398855406 : check e302398855406 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[.left],[]] .chain = true := by decide
def e302398855414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e302398855414 : Closed e302398855414 ∧ code e302398855414 = 1401910483190 := by decide
theorem cert_e302398855414 : check e302398855414 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[.left],[],[],[],[],[]] .sourceHead = true := by decide
def e302398855966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e302398855966 : Closed e302398855966 ∧ code e302398855966 = 1401910483742 := by decide
theorem cert_e302398855966 : check e302398855966 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[],[],[],[]] .sourceHead = true := by decide
def e302398856078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e302398856078 : Closed e302398856078 ∧ code e302398856078 = 1401910483854 := by decide
theorem cert_e302398856078 : check e302398856078 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e302398856302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302398856302 : Closed e302398856302 ∧ code e302398856302 = 1401910484078 := by decide
theorem cert_e302398856302 : check e302398856302 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e302398856314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302398856314 : Closed e302398856314 ∧ code e302398856314 = 1401910484090 := by decide
theorem cert_e302398856314 : check e302398856314 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e302398856478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302398856478 : Closed e302398856478 ∧ code e302398856478 = 1401910484254 := by decide
theorem cert_e302398856478 : check e302398856478 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[.left],[],[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e302398856646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302398856646 : Closed e302398856646 ∧ code e302398856646 = 1401910484422 := by decide
private def t_e302398856646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem cert_e302398856646 : ¬ IsSelfInterpreter e302398856646 :=
  wSource (t := t_e302398856646) (replay_sound (ps := []) (t := e302398856646) (by decide)) (by decide)
def e302398856758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302398856758 : Closed e302398856758 ∧ code e302398856758 = 1401910484534 := by decide
theorem cert_e302398856758 : check e302398856758 [[],[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e302398856762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302398856762 : Closed e302398856762 ∧ code e302398856762 = 1401910484538 := by decide
theorem cert_e302398856762 : check e302398856762 [[],[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .three = true := by decide
def e302398856846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302398856846 : Closed e302398856846 ∧ code e302398856846 = 1401910484622 := by decide
theorem cert_e302398856846 : check e302398856846 [[],[],[.left],[.left],[.left],[],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[.left],[]] .chain = true := by decide
def e302398856902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302398856902 : Closed e302398856902 ∧ code e302398856902 = 1401910484678 := by decide
private def t_e302398856902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem cert_e302398856902 : ¬ IsSelfInterpreter e302398856902 :=
  wSource (t := t_e302398856902) (replay_sound (ps := []) (t := e302398856902) (by decide)) (by decide)
def e302398859038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e302398859038 : Closed e302398859038 ∧ code e302398859038 = 1401910486814 := by decide
theorem cert_e302398859038 : check e302398859038 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e302398859150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e302398859150 : Closed e302398859150 ∧ code e302398859150 = 1401910486926 := by decide
theorem cert_e302398859150 : check e302398859150 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e302398862110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302398862110 : Closed e302398862110 ∧ code e302398862110 = 1401910489886 := by decide
theorem cert_e302398862110 : check e302398862110 [[],[],[.left],[.left],[.left],[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e302398862278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302398862278 : Closed e302398862278 ∧ code e302398862278 = 1401910490054 := by decide
theorem cert_e302398862278 : check e302398862278 [[],[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .smaller = true := by decide
def e302398863758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302398863758 : Closed e302398863758 ∧ code e302398863758 = 1401910491534 := by decide
def e302398863814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302398863814 : Closed e302398863814 ∧ code e302398863814 = 1401910491590 := by decide
def e302795283166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e302795283166 : Closed e302795283166 ∧ code e302795283166 = 1402306910942 := by decide
theorem cert_e302795283166 : check e302795283166 [[],[]] .smaller = true := by decide
def e302795283190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e302795283190 : Closed e302795283190 ∧ code e302795283190 = 1402306910966 := by decide
theorem cert_e302795283190 : check e302795283190 [[],[]] .smaller = true := by decide
def e302795283294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e302795283294 : Closed e302795283294 ∧ code e302795283294 = 1402306911070 := by decide
theorem cert_e302795283294 : check e302795283294 [[],[]] .smaller = true := by decide
def e302795283310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e302795283310 : Closed e302795283310 ∧ code e302795283310 = 1402306911086 := by decide
theorem cert_e302795283310 : check e302795283310 [[],[]] .smaller = true := by decide
def e302795283318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e302795283318 : Closed e302795283318 ∧ code e302795283318 = 1402306911094 := by decide
theorem cert_e302795283318 : check e302795283318 [[],[]] .smaller = true := by decide
def e302795283322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e302795283322 : Closed e302795283322 ∧ code e302795283322 = 1402306911098 := by decide
theorem cert_e302795283322 : check e302795283322 [[],[]] .smaller = true := by decide
def e302795283382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e302795283382 : Closed e302795283382 ∧ code e302795283382 = 1402306911158 := by decide
theorem cert_e302795283382 : check e302795283382 [[],[]] .smaller = true := by decide
def e302795283414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e302795283414 : Closed e302795283414 ∧ code e302795283414 = 1402306911190 := by decide
theorem cert_e302795283414 : check e302795283414 [[],[]] .smaller = true := by decide
def e302795283418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e302795283418 : Closed e302795283418 ∧ code e302795283418 = 1402306911194 := by decide
theorem cert_e302795283418 : check e302795283418 [[],[]] .smaller = true := by decide
def e302795283806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e302795283806 : Closed e302795283806 ∧ code e302795283806 = 1402306911582 := by decide
theorem cert_e302795283806 : check e302795283806 [[],[]] .smaller = true := by decide
def e302795283822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e302795283822 : Closed e302795283822 ∧ code e302795283822 = 1402306911598 := by decide
theorem cert_e302795283822 : check e302795283822 [[],[]] .smaller = true := by decide
def e302795283830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e302795283830 : Closed e302795283830 ∧ code e302795283830 = 1402306911606 := by decide
theorem cert_e302795283830 : check e302795283830 [[],[]] .smaller = true := by decide
def e302795283834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e302795283834 : Closed e302795283834 ∧ code e302795283834 = 1402306911610 := by decide
theorem cert_e302795283834 : check e302795283834 [[],[]] .smaller = true := by decide
def e302795283886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e302795283886 : Closed e302795283886 ∧ code e302795283886 = 1402306911662 := by decide
theorem cert_e302795283886 : check e302795283886 [[],[]] .smaller = true := by decide
def e302795283898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e302795283898 : Closed e302795283898 ∧ code e302795283898 = 1402306911674 := by decide
theorem cert_e302795283898 : check e302795283898 [[],[]] .smaller = true := by decide
def e302795283926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e302795283926 : Closed e302795283926 ∧ code e302795283926 = 1402306911702 := by decide
theorem cert_e302795283926 : check e302795283926 [[],[]] .smaller = true := by decide
def e302795283930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e302795283930 : Closed e302795283930 ∧ code e302795283930 = 1402306911706 := by decide
theorem cert_e302795283930 : check e302795283930 [[],[]] .smaller = true := by decide
def e302795283946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e302795283946 : Closed e302795283946 ∧ code e302795283946 = 1402306911722 := by decide
theorem cert_e302795283946 : check e302795283946 [[],[]] .smaller = true := by decide
def e302795284150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e302795284150 : Closed e302795284150 ∧ code e302795284150 = 1402306911926 := by decide
theorem cert_e302795284150 : check e302795284150 [[],[]] .smaller = true := by decide
def e302795284182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e302795284182 : Closed e302795284182 ∧ code e302795284182 = 1402306911958 := by decide
theorem cert_e302795284182 : check e302795284182 [[],[]] .smaller = true := by decide
def e302795284186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e302795284186 : Closed e302795284186 ∧ code e302795284186 = 1402306911962 := by decide
theorem cert_e302795284186 : check e302795284186 [[],[]] .smaller = true := by decide
def e302795284310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e302795284310 : Closed e302795284310 ∧ code e302795284310 = 1402306912086 := by decide
theorem cert_e302795284310 : check e302795284310 [[],[]] .smaller = true := by decide
def e302795284314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e302795284314 : Closed e302795284314 ∧ code e302795284314 = 1402306912090 := by decide
theorem cert_e302795284314 : check e302795284314 [[],[]] .smaller = true := by decide
def e302795284330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e302795284330 : Closed e302795284330 ∧ code e302795284330 = 1402306912106 := by decide
theorem cert_e302795284330 : check e302795284330 [[],[]] .smaller = true := by decide
def e302795286238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e302795286238 : Closed e302795286238 ∧ code e302795286238 = 1402306914014 := by decide
theorem cert_e302795286238 : check e302795286238 [[],[]] .smaller = true := by decide
def e302795286262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e302795286262 : Closed e302795286262 ∧ code e302795286262 = 1402306914038 := by decide
theorem cert_e302795286262 : check e302795286262 [[],[]] .smaller = true := by decide
def e302795286366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e302795286366 : Closed e302795286366 ∧ code e302795286366 = 1402306914142 := by decide
theorem cert_e302795286366 : check e302795286366 [[],[]] .smaller = true := by decide
def e302795286382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e302795286382 : Closed e302795286382 ∧ code e302795286382 = 1402306914158 := by decide
theorem cert_e302795286382 : check e302795286382 [[],[]] .smaller = true := by decide
def e302795286390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e302795286390 : Closed e302795286390 ∧ code e302795286390 = 1402306914166 := by decide
theorem cert_e302795286390 : check e302795286390 [[],[]] .smaller = true := by decide
def e302795286394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e302795286394 : Closed e302795286394 ∧ code e302795286394 = 1402306914170 := by decide
theorem cert_e302795286394 : check e302795286394 [[],[]] .smaller = true := by decide
def e302795286454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e302795286454 : Closed e302795286454 ∧ code e302795286454 = 1402306914230 := by decide
theorem cert_e302795286454 : check e302795286454 [[],[]] .smaller = true := by decide
def e302795286486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e302795286486 : Closed e302795286486 ∧ code e302795286486 = 1402306914262 := by decide
theorem cert_e302795286486 : check e302795286486 [[],[]] .smaller = true := by decide
def e302795286490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e302795286490 : Closed e302795286490 ∧ code e302795286490 = 1402306914266 := by decide
theorem cert_e302795286490 : check e302795286490 [[],[]] .smaller = true := by decide
def e302795287006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e302795287006 : Closed e302795287006 ∧ code e302795287006 = 1402306914782 := by decide
theorem cert_e302795287006 : check e302795287006 [[],[]] .smaller = true := by decide
def e302795287030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e302795287030 : Closed e302795287030 ∧ code e302795287030 = 1402306914806 := by decide
theorem cert_e302795287030 : check e302795287030 [[],[]] .smaller = true := by decide
def e302795287774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e302795287774 : Closed e302795287774 ∧ code e302795287774 = 1402306915550 := by decide
theorem cert_e302795287774 : check e302795287774 [[],[]] .smaller = true := by decide
def e302795287790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e302795287790 : Closed e302795287790 ∧ code e302795287790 = 1402306915566 := by decide
theorem cert_e302795287790 : check e302795287790 [[],[]] .smaller = true := by decide
def e302795287798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e302795287798 : Closed e302795287798 ∧ code e302795287798 = 1402306915574 := by decide
theorem cert_e302795287798 : check e302795287798 [[],[]] .smaller = true := by decide
def e302795287802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e302795287802 : Closed e302795287802 ∧ code e302795287802 = 1402306915578 := by decide
theorem cert_e302795287802 : check e302795287802 [[],[]] .smaller = true := by decide
def e302795288182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e302795288182 : Closed e302795288182 ∧ code e302795288182 = 1402306915958 := by decide
theorem cert_e302795288182 : check e302795288182 [[],[]] .smaller = true := by decide
def e302795288374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e302795288374 : Closed e302795288374 ∧ code e302795288374 = 1402306916150 := by decide
theorem cert_e302795288374 : check e302795288374 [[],[]] .smaller = true := by decide
def e302795288378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e302795288378 : Closed e302795288378 ∧ code e302795288378 = 1402306916154 := by decide
theorem cert_e302795288378 : check e302795288378 [[],[]] .smaller = true := by decide
def e302795289438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e302795289438 : Closed e302795289438 ∧ code e302795289438 = 1402306917214 := by decide
theorem cert_e302795289438 : check e302795289438 [[],[]] .smaller = true := by decide
def e302795289454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e302795289454 : Closed e302795289454 ∧ code e302795289454 = 1402306917230 := by decide
theorem cert_e302795289454 : check e302795289454 [[],[]] .smaller = true := by decide
def e302795289462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e302795289462 : Closed e302795289462 ∧ code e302795289462 = 1402306917238 := by decide
theorem cert_e302795289462 : check e302795289462 [[],[]] .smaller = true := by decide
def e302795289466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e302795289466 : Closed e302795289466 ∧ code e302795289466 = 1402306917242 := by decide
theorem cert_e302795289466 : check e302795289466 [[],[]] .smaller = true := by decide
def e302795289518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e302795289518 : Closed e302795289518 ∧ code e302795289518 = 1402306917294 := by decide
theorem cert_e302795289518 : check e302795289518 [[],[]] .smaller = true := by decide
def e302795289530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e302795289530 : Closed e302795289530 ∧ code e302795289530 = 1402306917306 := by decide
theorem cert_e302795289530 : check e302795289530 [[],[]] .smaller = true := by decide
def e302795289558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e302795289558 : Closed e302795289558 ∧ code e302795289558 = 1402306917334 := by decide
theorem cert_e302795289558 : check e302795289558 [[],[]] .smaller = true := by decide
def e302795289562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e302795289562 : Closed e302795289562 ∧ code e302795289562 = 1402306917338 := by decide
theorem cert_e302795289562 : check e302795289562 [[],[]] .smaller = true := by decide
def e302795289578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e302795289578 : Closed e302795289578 ∧ code e302795289578 = 1402306917354 := by decide
theorem cert_e302795289578 : check e302795289578 [[],[]] .smaller = true := by decide
def e302795289822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e302795289822 : Closed e302795289822 ∧ code e302795289822 = 1402306917598 := by decide
theorem cert_e302795289822 : check e302795289822 [[],[]] .smaller = true := by decide
def e302795289838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e302795289838 : Closed e302795289838 ∧ code e302795289838 = 1402306917614 := by decide
theorem cert_e302795289838 : check e302795289838 [[],[]] .smaller = true := by decide
def e302795289846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e302795289846 : Closed e302795289846 ∧ code e302795289846 = 1402306917622 := by decide
theorem cert_e302795289846 : check e302795289846 [[],[]] .smaller = true := by decide
def e302795289850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e302795289850 : Closed e302795289850 ∧ code e302795289850 = 1402306917626 := by decide
theorem cert_e302795289850 : check e302795289850 [[],[]] .smaller = true := by decide
def e302795290222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e302795290222 : Closed e302795290222 ∧ code e302795290222 = 1402306917998 := by decide
theorem cert_e302795290222 : check e302795290222 [[],[]] .smaller = true := by decide
def e302795290234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e302795290234 : Closed e302795290234 ∧ code e302795290234 = 1402306918010 := by decide
theorem cert_e302795290234 : check e302795290234 [[],[]] .smaller = true := by decide
def e302795290422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e302795290422 : Closed e302795290422 ∧ code e302795290422 = 1402306918198 := by decide
theorem cert_e302795290422 : check e302795290422 [[],[]] .smaller = true := by decide
def e302795290426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e302795290426 : Closed e302795290426 ∧ code e302795290426 = 1402306918202 := by decide
theorem cert_e302795290426 : check e302795290426 [[],[]] .smaller = true := by decide
def e302795290522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e302795290522 : Closed e302795290522 ∧ code e302795290522 = 1402306918298 := by decide
theorem cert_e302795290522 : check e302795290522 [[],[]] .smaller = true := by decide
def e302795291062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e302795291062 : Closed e302795291062 ∧ code e302795291062 = 1402306918838 := by decide
theorem cert_e302795291062 : check e302795291062 [[],[]] .smaller = true := by decide
def e302795291094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e302795291094 : Closed e302795291094 ∧ code e302795291094 = 1402306918870 := by decide
theorem cert_e302795291094 : check e302795291094 [[],[]] .smaller = true := by decide
def e302795291098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e302795291098 : Closed e302795291098 ∧ code e302795291098 = 1402306918874 := by decide
theorem cert_e302795291098 : check e302795291098 [[],[]] .smaller = true := by decide
def e302795291254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e302795291254 : Closed e302795291254 ∧ code e302795291254 = 1402306919030 := by decide
theorem cert_e302795291254 : check e302795291254 [[],[]] .smaller = true := by decide
def e302795291446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e302795291446 : Closed e302795291446 ∧ code e302795291446 = 1402306919222 := by decide
theorem cert_e302795291446 : check e302795291446 [[],[]] .smaller = true := by decide
def e302795291450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e302795291450 : Closed e302795291450 ∧ code e302795291450 = 1402306919226 := by decide
theorem cert_e302795291450 : check e302795291450 [[],[]] .smaller = true := by decide
def e302795291862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e302795291862 : Closed e302795291862 ∧ code e302795291862 = 1402306919638 := by decide
theorem cert_e302795291862 : check e302795291862 [[],[]] .smaller = true := by decide
def e302795291866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e302795291866 : Closed e302795291866 ∧ code e302795291866 = 1402306919642 := by decide
theorem cert_e302795291866 : check e302795291866 [[],[]] .smaller = true := by decide
def e302795291882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e302795291882 : Closed e302795291882 ∧ code e302795291882 = 1402306919658 := by decide
theorem cert_e302795291882 : check e302795291882 [[],[]] .smaller = true := by decide
def e302795291958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e302795291958 : Closed e302795291958 ∧ code e302795291958 = 1402306919734 := by decide
theorem cert_e302795291958 : check e302795291958 [[],[]] .smaller = true := by decide
def e302795291962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e302795291962 : Closed e302795291962 ∧ code e302795291962 = 1402306919738 := by decide
theorem cert_e302795291962 : check e302795291962 [[],[]] .smaller = true := by decide
def e302795292058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e302795292058 : Closed e302795292058 ∧ code e302795292058 = 1402306919834 := by decide
theorem cert_e302795292058 : check e302795292058 [[],[]] .smaller = true := by decide
def e302795298526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e302795298526 : Closed e302795298526 ∧ code e302795298526 = 1402306926302 := by decide
theorem cert_e302795298526 : check e302795298526 [[],[]] .smaller = true := by decide
def e302795298550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e302795298550 : Closed e302795298550 ∧ code e302795298550 = 1402306926326 := by decide
theorem cert_e302795298550 : check e302795298550 [[],[]] .smaller = true := by decide
def e302795298654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e302795298654 : Closed e302795298654 ∧ code e302795298654 = 1402306926430 := by decide
theorem cert_e302795298654 : check e302795298654 [[],[]] .smaller = true := by decide
def e302795298670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e302795298670 : Closed e302795298670 ∧ code e302795298670 = 1402306926446 := by decide
theorem cert_e302795298670 : check e302795298670 [[],[]] .smaller = true := by decide
def e302795298678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e302795298678 : Closed e302795298678 ∧ code e302795298678 = 1402306926454 := by decide
theorem cert_e302795298678 : check e302795298678 [[],[]] .smaller = true := by decide
def e302795298682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e302795298682 : Closed e302795298682 ∧ code e302795298682 = 1402306926458 := by decide
theorem cert_e302795298682 : check e302795298682 [[],[]] .smaller = true := by decide
def e302795298742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e302795298742 : Closed e302795298742 ∧ code e302795298742 = 1402306926518 := by decide
theorem cert_e302795298742 : check e302795298742 [[],[]] .smaller = true := by decide
def e302795298774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e302795298774 : Closed e302795298774 ∧ code e302795298774 = 1402306926550 := by decide
theorem cert_e302795298774 : check e302795298774 [[],[]] .smaller = true := by decide
def e302795298778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e302795298778 : Closed e302795298778 ∧ code e302795298778 = 1402306926554 := by decide
theorem cert_e302795298778 : check e302795298778 [[],[]] .smaller = true := by decide
def e302795299294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e302795299294 : Closed e302795299294 ∧ code e302795299294 = 1402306927070 := by decide
theorem cert_e302795299294 : check e302795299294 [[],[]] .smaller = true := by decide
def e302795299318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e302795299318 : Closed e302795299318 ∧ code e302795299318 = 1402306927094 := by decide
theorem cert_e302795299318 : check e302795299318 [[],[]] .smaller = true := by decide
def e302795300062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e302795300062 : Closed e302795300062 ∧ code e302795300062 = 1402306927838 := by decide
theorem cert_e302795300062 : check e302795300062 [[],[]] .smaller = true := by decide
def e302795300078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e302795300078 : Closed e302795300078 ∧ code e302795300078 = 1402306927854 := by decide
theorem cert_e302795300078 : check e302795300078 [[],[]] .smaller = true := by decide
def e302795300086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e302795300086 : Closed e302795300086 ∧ code e302795300086 = 1402306927862 := by decide
theorem cert_e302795300086 : check e302795300086 [[],[]] .smaller = true := by decide
def e302795300090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e302795300090 : Closed e302795300090 ∧ code e302795300090 = 1402306927866 := by decide
theorem cert_e302795300090 : check e302795300090 [[],[]] .smaller = true := by decide
def e302795300470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e302795300470 : Closed e302795300470 ∧ code e302795300470 = 1402306928246 := by decide
theorem cert_e302795300470 : check e302795300470 [[],[]] .smaller = true := by decide
def e302795300662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e302795300662 : Closed e302795300662 ∧ code e302795300662 = 1402306928438 := by decide
theorem cert_e302795300662 : check e302795300662 [[],[]] .smaller = true := by decide
def e302795300666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e302795300666 : Closed e302795300666 ∧ code e302795300666 = 1402306928442 := by decide
theorem cert_e302795300666 : check e302795300666 [[],[]] .smaller = true := by decide
def e302795311966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e302795311966 : Closed e302795311966 ∧ code e302795311966 = 1402306939742 := by decide
theorem cert_e302795311966 : check e302795311966 [[],[]] .smaller = true := by decide
def e302795311982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e302795311982 : Closed e302795311982 ∧ code e302795311982 = 1402306939758 := by decide
theorem cert_e302795311982 : check e302795311982 [[],[]] .smaller = true := by decide
def e302795311990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e302795311990 : Closed e302795311990 ∧ code e302795311990 = 1402306939766 := by decide
theorem cert_e302795311990 : check e302795311990 [[],[]] .smaller = true := by decide
def e302795311994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e302795311994 : Closed e302795311994 ∧ code e302795311994 = 1402306939770 := by decide
theorem cert_e302795311994 : check e302795311994 [[],[]] .smaller = true := by decide
def e302795312046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e302795312046 : Closed e302795312046 ∧ code e302795312046 = 1402306939822 := by decide
theorem cert_e302795312046 : check e302795312046 [[],[]] .smaller = true := by decide
def e302795312058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e302795312058 : Closed e302795312058 ∧ code e302795312058 = 1402306939834 := by decide
theorem cert_e302795312058 : check e302795312058 [[],[]] .smaller = true := by decide
def e302795312086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e302795312086 : Closed e302795312086 ∧ code e302795312086 = 1402306939862 := by decide
theorem cert_e302795312086 : check e302795312086 [[],[]] .smaller = true := by decide
def e302795312090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e302795312090 : Closed e302795312090 ∧ code e302795312090 = 1402306939866 := by decide
theorem cert_e302795312090 : check e302795312090 [[],[]] .smaller = true := by decide
def e302795312106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e302795312106 : Closed e302795312106 ∧ code e302795312106 = 1402306939882 := by decide
theorem cert_e302795312106 : check e302795312106 [[],[]] .smaller = true := by decide
def e302795312350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e302795312350 : Closed e302795312350 ∧ code e302795312350 = 1402306940126 := by decide
theorem cert_e302795312350 : check e302795312350 [[],[]] .smaller = true := by decide
def e302795312366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e302795312366 : Closed e302795312366 ∧ code e302795312366 = 1402306940142 := by decide
theorem cert_e302795312366 : check e302795312366 [[],[]] .smaller = true := by decide
def e302795312374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e302795312374 : Closed e302795312374 ∧ code e302795312374 = 1402306940150 := by decide
theorem cert_e302795312374 : check e302795312374 [[],[]] .smaller = true := by decide
def e302795312378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e302795312378 : Closed e302795312378 ∧ code e302795312378 = 1402306940154 := by decide
theorem cert_e302795312378 : check e302795312378 [[],[]] .smaller = true := by decide
def e302795312750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e302795312750 : Closed e302795312750 ∧ code e302795312750 = 1402306940526 := by decide
theorem cert_e302795312750 : check e302795312750 [[],[]] .smaller = true := by decide
def e302795312762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e302795312762 : Closed e302795312762 ∧ code e302795312762 = 1402306940538 := by decide
theorem cert_e302795312762 : check e302795312762 [[],[]] .smaller = true := by decide
def e302795312950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e302795312950 : Closed e302795312950 ∧ code e302795312950 = 1402306940726 := by decide
theorem cert_e302795312950 : check e302795312950 [[],[]] .smaller = true := by decide
def e302795312954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e302795312954 : Closed e302795312954 ∧ code e302795312954 = 1402306940730 := by decide
theorem cert_e302795312954 : check e302795312954 [[],[]] .smaller = true := by decide
def e302795313050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e302795313050 : Closed e302795313050 ∧ code e302795313050 = 1402306940826 := by decide
theorem cert_e302795313050 : check e302795313050 [[],[]] .smaller = true := by decide
def e302795318710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e302795318710 : Closed e302795318710 ∧ code e302795318710 = 1402306946486 := by decide
theorem cert_e302795318710 : check e302795318710 [[],[]] .smaller = true := by decide
def e302795318742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e302795318742 : Closed e302795318742 ∧ code e302795318742 = 1402306946518 := by decide
theorem cert_e302795318742 : check e302795318742 [[],[]] .smaller = true := by decide
def e302795318746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e302795318746 : Closed e302795318746 ∧ code e302795318746 = 1402306946522 := by decide
theorem cert_e302795318746 : check e302795318746 [[],[]] .smaller = true := by decide
def e302795318902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e302795318902 : Closed e302795318902 ∧ code e302795318902 = 1402306946678 := by decide
theorem cert_e302795318902 : check e302795318902 [[],[]] .smaller = true := by decide
def e302795319094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e302795319094 : Closed e302795319094 ∧ code e302795319094 = 1402306946870 := by decide
theorem cert_e302795319094 : check e302795319094 [[],[]] .smaller = true := by decide
def e302795319098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e302795319098 : Closed e302795319098 ∧ code e302795319098 = 1402306946874 := by decide
theorem cert_e302795319098 : check e302795319098 [[],[]] .smaller = true := by decide
def e302795322070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e302795322070 : Closed e302795322070 ∧ code e302795322070 = 1402306949846 := by decide
theorem cert_e302795322070 : check e302795322070 [[],[]] .smaller = true := by decide
def e302795322074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e302795322074 : Closed e302795322074 ∧ code e302795322074 = 1402306949850 := by decide
theorem cert_e302795322074 : check e302795322074 [[],[]] .smaller = true := by decide
def e302795322090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e302795322090 : Closed e302795322090 ∧ code e302795322090 = 1402306949866 := by decide
theorem cert_e302795322090 : check e302795322090 [[],[]] .smaller = true := by decide
def e302795322166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e302795322166 : Closed e302795322166 ∧ code e302795322166 = 1402306949942 := by decide
theorem cert_e302795322166 : check e302795322166 [[],[]] .smaller = true := by decide
def e302795322170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e302795322170 : Closed e302795322170 ∧ code e302795322170 = 1402306949946 := by decide
theorem cert_e302795322170 : check e302795322170 [[],[]] .smaller = true := by decide
def e302795322266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e302795322266 : Closed e302795322266 ∧ code e302795322266 = 1402306950042 := by decide
theorem cert_e302795322266 : check e302795322266 [[],[]] .smaller = true := by decide
def e302795547502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e302795547502 : Closed e302795547502 ∧ code e302795547502 = 1402307175278 := by decide
theorem cert_e302795547502 : check e302795547502 [[],[]] .smaller = true := by decide
def e302795547510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e302795547510 : Closed e302795547510 ∧ code e302795547510 = 1402307175286 := by decide
theorem cert_e302795547510 : check e302795547510 [[],[]] .smaller = true := by decide
end Blc.Floor40
