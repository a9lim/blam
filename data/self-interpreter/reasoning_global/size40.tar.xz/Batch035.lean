import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302796709486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e302796709486 : Closed e302796709486 ∧ code e302796709486 = 1402308337262 := by decide
theorem cert_e302796709486 : check e302796709486 [[],[]] .smaller = true := by decide
def e302796709498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e302796709498 : Closed e302796709498 ∧ code e302796709498 = 1402308337274 := by decide
theorem cert_e302796709498 : check e302796709498 [[],[]] .smaller = true := by decide
def e302796709686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.var 1))))))))
theorem wire_e302796709686 : Closed e302796709686 ∧ code e302796709686 = 1402308337462 := by decide
theorem cert_e302796709686 : check e302796709686 [[],[]] .three = true := by decide
def e302796709690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 1) (.var 0))))))))
theorem wire_e302796709690 : Closed e302796709690 ∧ code e302796709690 = 1402308337466 := by decide
theorem cert_e302796709690 : check e302796709690 [[],[]] .three = true := by decide
def e302796713310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e302796713310 : Closed e302796713310 ∧ code e302796713310 = 1402308341086 := by decide
theorem cert_e302796713310 : check e302796713310 [[],[]] .three = true := by decide
def e302796713326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e302796713326 : Closed e302796713326 ∧ code e302796713326 = 1402308341102 := by decide
theorem cert_e302796713326 : check e302796713326 [[],[]] .smaller = true := by decide
def e302796713334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e302796713334 : Closed e302796713334 ∧ code e302796713334 = 1402308341110 := by decide
theorem cert_e302796713334 : check e302796713334 [[],[]] .smaller = true := by decide
def e302796713338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e302796713338 : Closed e302796713338 ∧ code e302796713338 = 1402308341114 := by decide
theorem cert_e302796713338 : check e302796713338 [[],[]] .three = true := by decide
def e302796713390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e302796713390 : Closed e302796713390 ∧ code e302796713390 = 1402308341166 := by decide
theorem cert_e302796713390 : check e302796713390 [[],[]] .smaller = true := by decide
def e302796713402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e302796713402 : Closed e302796713402 ∧ code e302796713402 = 1402308341178 := by decide
theorem cert_e302796713402 : check e302796713402 [[],[]] .smaller = true := by decide
def e302796713430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e302796713430 : Closed e302796713430 ∧ code e302796713430 = 1402308341206 := by decide
theorem cert_e302796713430 : check e302796713430 [[],[]] .smaller = true := by decide
def e302796713434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e302796713434 : Closed e302796713434 ∧ code e302796713434 = 1402308341210 := by decide
theorem cert_e302796713434 : check e302796713434 [[],[]] .smaller = true := by decide
def e302796713450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e302796713450 : Closed e302796713450 ∧ code e302796713450 = 1402308341226 := by decide
theorem cert_e302796713450 : check e302796713450 [[],[]] .three = true := by decide
def e302796713646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e302796713646 : Closed e302796713646 ∧ code e302796713646 = 1402308341422 := by decide
theorem cert_e302796713646 : check e302796713646 [[],[]] .smaller = true := by decide
def e302796713658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e302796713658 : Closed e302796713658 ∧ code e302796713658 = 1402308341434 := by decide
theorem cert_e302796713658 : check e302796713658 [[],[]] .smaller = true := by decide
def e302796713706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e302796713706 : Closed e302796713706 ∧ code e302796713706 = 1402308341482 := by decide
theorem cert_e302796713706 : check e302796713706 [[],[]] .smaller = true := by decide
def e302796713814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e302796713814 : Closed e302796713814 ∧ code e302796713814 = 1402308341590 := by decide
theorem cert_e302796713814 : check e302796713814 [[],[]] .smaller = true := by decide
def e302796713818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e302796713818 : Closed e302796713818 ∧ code e302796713818 = 1402308341594 := by decide
theorem cert_e302796713818 : check e302796713818 [[],[]] .smaller = true := by decide
def e302796713834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e302796713834 : Closed e302796713834 ∧ code e302796713834 = 1402308341610 := by decide
theorem cert_e302796713834 : check e302796713834 [[],[]] .smaller = true := by decide
def e302796713898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e302796713898 : Closed e302796713898 ∧ code e302796713898 = 1402308341674 := by decide
theorem cert_e302796713898 : check e302796713898 [[],[]] .three = true := by decide
def e302796714462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e302796714462 : Closed e302796714462 ∧ code e302796714462 = 1402308342238 := by decide
theorem cert_e302796714462 : check e302796714462 [[],[]] .three = true := by decide
def e302796714478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e302796714478 : Closed e302796714478 ∧ code e302796714478 = 1402308342254 := by decide
theorem cert_e302796714478 : check e302796714478 [[],[]] .smaller = true := by decide
def e302796714486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e302796714486 : Closed e302796714486 ∧ code e302796714486 = 1402308342262 := by decide
theorem cert_e302796714486 : check e302796714486 [[],[]] .three = true := by decide
def e302796714846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e302796714846 : Closed e302796714846 ∧ code e302796714846 = 1402308342622 := by decide
theorem cert_e302796714846 : check e302796714846 [[],[]] .three = true := by decide
def e302796714862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e302796714862 : Closed e302796714862 ∧ code e302796714862 = 1402308342638 := by decide
theorem cert_e302796714862 : check e302796714862 [[],[]] .smaller = true := by decide
def e302796714870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e302796714870 : Closed e302796714870 ∧ code e302796714870 = 1402308342646 := by decide
theorem cert_e302796714870 : check e302796714870 [[],[]] .smaller = true := by decide
def e302796714874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e302796714874 : Closed e302796714874 ∧ code e302796714874 = 1402308342650 := by decide
theorem cert_e302796714874 : check e302796714874 [[],[]] .three = true := by decide
def e302796714926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e302796714926 : Closed e302796714926 ∧ code e302796714926 = 1402308342702 := by decide
theorem cert_e302796714926 : check e302796714926 [[],[]] .smaller = true := by decide
def e302796714938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e302796714938 : Closed e302796714938 ∧ code e302796714938 = 1402308342714 := by decide
theorem cert_e302796714938 : check e302796714938 [[],[]] .smaller = true := by decide
def e302796714966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e302796714966 : Closed e302796714966 ∧ code e302796714966 = 1402308342742 := by decide
theorem cert_e302796714966 : check e302796714966 [[],[]] .smaller = true := by decide
def e302796714970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e302796714970 : Closed e302796714970 ∧ code e302796714970 = 1402308342746 := by decide
theorem cert_e302796714970 : check e302796714970 [[],[]] .smaller = true := by decide
def e302796714986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e302796714986 : Closed e302796714986 ∧ code e302796714986 = 1402308342762 := by decide
theorem cert_e302796714986 : check e302796714986 [[],[]] .three = true := by decide
def e302796715230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e302796715230 : Closed e302796715230 ∧ code e302796715230 = 1402308343006 := by decide
theorem cert_e302796715230 : check e302796715230 [[],[]] .three = true := by decide
def e302796715246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e302796715246 : Closed e302796715246 ∧ code e302796715246 = 1402308343022 := by decide
theorem cert_e302796715246 : check e302796715246 [[],[]] .smaller = true := by decide
def e302796715254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e302796715254 : Closed e302796715254 ∧ code e302796715254 = 1402308343030 := by decide
theorem cert_e302796715254 : check e302796715254 [[],[]] .smaller = true := by decide
def e302796715258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e302796715258 : Closed e302796715258 ∧ code e302796715258 = 1402308343034 := by decide
theorem cert_e302796715258 : check e302796715258 [[],[]] .three = true := by decide
def e302796715582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 4))))))))
theorem wire_e302796715582 : Closed e302796715582 ∧ code e302796715582 = 1402308343358 := by decide
theorem cert_e302796715582 : check e302796715582 [[],[]] .three = true := by decide
def e302796715630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e302796715630 : Closed e302796715630 ∧ code e302796715630 = 1402308343406 := by decide
theorem cert_e302796715630 : check e302796715630 [[],[]] .smaller = true := by decide
def e302796715642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e302796715642 : Closed e302796715642 ∧ code e302796715642 = 1402308343418 := by decide
theorem cert_e302796715642 : check e302796715642 [[],[]] .smaller = true := by decide
def e302796715806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3))))))))
theorem wire_e302796715806 : Closed e302796715806 ∧ code e302796715806 = 1402308343582 := by decide
theorem cert_e302796715806 : check e302796715806 [[],[]] .smaller = true := by decide
def e302796715830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e302796715830 : Closed e302796715830 ∧ code e302796715830 = 1402308343606 := by decide
theorem cert_e302796715830 : check e302796715830 [[],[]] .smaller = true := by decide
def e302796715834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e302796715834 : Closed e302796715834 ∧ code e302796715834 = 1402308343610 := by decide
theorem cert_e302796715834 : check e302796715834 [[],[]] .smaller = true := by decide
def e302796715918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 2))))))))
theorem wire_e302796715918 : Closed e302796715918 ∧ code e302796715918 = 1402308343694 := by decide
theorem cert_e302796715918 : check e302796715918 [[],[]] .three = true := by decide
def e302796715930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e302796715930 : Closed e302796715930 ∧ code e302796715930 = 1402308343706 := by decide
theorem cert_e302796715930 : check e302796715930 [[],[]] .three = true := by decide
def e302796716254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e302796716254 : Closed e302796716254 ∧ code e302796716254 = 1402308344030 := by decide
theorem cert_e302796716254 : check e302796716254 [[],[]] .three = true := by decide
def e302796716282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e302796716282 : Closed e302796716282 ∧ code e302796716282 = 1402308344058 := by decide
theorem cert_e302796716282 : check e302796716282 [[],[]] .three = true := by decide
def e302796716462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e302796716462 : Closed e302796716462 ∧ code e302796716462 = 1402308344238 := by decide
theorem cert_e302796716462 : check e302796716462 [[],[]] .smaller = true := by decide
def e302796716474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e302796716474 : Closed e302796716474 ∧ code e302796716474 = 1402308344250 := by decide
theorem cert_e302796716474 : check e302796716474 [[],[]] .smaller = true := by decide
def e302796716522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e302796716522 : Closed e302796716522 ∧ code e302796716522 = 1402308344298 := by decide
theorem cert_e302796716522 : check e302796716522 [[],[]] .smaller = true := by decide
def e302796716606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 4))))))))
theorem wire_e302796716606 : Closed e302796716606 ∧ code e302796716606 = 1402308344382 := by decide
theorem cert_e302796716606 : check e302796716606 [[],[]] .three = true := by decide
def e302796716654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e302796716654 : Closed e302796716654 ∧ code e302796716654 = 1402308344430 := by decide
theorem cert_e302796716654 : check e302796716654 [[],[]] .smaller = true := by decide
def e302796716666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e302796716666 : Closed e302796716666 ∧ code e302796716666 = 1402308344442 := by decide
theorem cert_e302796716666 : check e302796716666 [[],[]] .smaller = true := by decide
def e302796716954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e302796716954 : Closed e302796716954 ∧ code e302796716954 = 1402308344730 := by decide
theorem cert_e302796716954 : check e302796716954 [[],[]] .smaller = true := by decide
def e302796716998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.lam (.var 1))))))))
theorem wire_e302796716998 : Closed e302796716998 ∧ code e302796716998 = 1402308344774 := by decide
theorem cert_e302796716998 : check e302796716998 [[],[]] .three = true := by decide
def e302796717166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e302796717166 : Closed e302796717166 ∧ code e302796717166 = 1402308344942 := by decide
theorem cert_e302796717166 : check e302796717166 [[],[]] .smaller = true := by decide
def e302796717178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302796717178 : Closed e302796717178 ∧ code e302796717178 = 1402308344954 := by decide
theorem cert_e302796717178 : check e302796717178 [[],[]] .smaller = true := by decide
def e302796717270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e302796717270 : Closed e302796717270 ∧ code e302796717270 = 1402308345046 := by decide
theorem cert_e302796717270 : check e302796717270 [[],[]] .smaller = true := by decide
def e302796717274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e302796717274 : Closed e302796717274 ∧ code e302796717274 = 1402308345050 := by decide
theorem cert_e302796717274 : check e302796717274 [[],[]] .smaller = true := by decide
def e302796717290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e302796717290 : Closed e302796717290 ∧ code e302796717290 = 1402308345066 := by decide
theorem cert_e302796717290 : check e302796717290 [[],[]] .smaller = true := by decide
def e302796717342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3))))))))
theorem wire_e302796717342 : Closed e302796717342 ∧ code e302796717342 = 1402308345118 := by decide
theorem cert_e302796717342 : check e302796717342 [[],[]] .smaller = true := by decide
def e302796717366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e302796717366 : Closed e302796717366 ∧ code e302796717366 = 1402308345142 := by decide
theorem cert_e302796717366 : check e302796717366 [[],[]] .smaller = true := by decide
def e302796717370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e302796717370 : Closed e302796717370 ∧ code e302796717370 = 1402308345146 := by decide
theorem cert_e302796717370 : check e302796717370 [[],[]] .smaller = true := by decide
def e302796717466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e302796717466 : Closed e302796717466 ∧ code e302796717466 = 1402308345242 := by decide
theorem cert_e302796717466 : check e302796717466 [[],[]] .smaller = true := by decide
def e302796717510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1))))))))
theorem wire_e302796717510 : Closed e302796717510 ∧ code e302796717510 = 1402308345286 := by decide
theorem cert_e302796717510 : check e302796717510 [[],[]] .smaller = true := by decide
def e302796717534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 3)))))))
theorem wire_e302796717534 : Closed e302796717534 ∧ code e302796717534 = 1402308345310 := by decide
theorem cert_e302796717534 : check e302796717534 [[],[]] .three = true := by decide
def e302796717550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 2)))))))
theorem wire_e302796717550 : Closed e302796717550 ∧ code e302796717550 = 1402308345326 := by decide
theorem cert_e302796717550 : check e302796717550 [[],[]] .three = true := by decide
def e302796717622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e302796717622 : Closed e302796717622 ∧ code e302796717622 = 1402308345398 := by decide
theorem cert_e302796717622 : check e302796717622 [[],[]] .three = true := by decide
def e302796717626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e302796717626 : Closed e302796717626 ∧ code e302796717626 = 1402308345402 := by decide
theorem cert_e302796717626 : check e302796717626 [[],[]] .three = true := by decide
def e302796717674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e302796717674 : Closed e302796717674 ∧ code e302796717674 = 1402308345450 := by decide
theorem cert_e302796717674 : check e302796717674 [[],[]] .three = true := by decide
def e302796717710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 2))))))))
theorem wire_e302796717710 : Closed e302796717710 ∧ code e302796717710 = 1402308345486 := by decide
theorem cert_e302796717710 : check e302796717710 [[],[]] .three = true := by decide
def e302796717722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e302796717722 : Closed e302796717722 ∧ code e302796717722 = 1402308345498 := by decide
theorem cert_e302796717722 : check e302796717722 [[],[]] .three = true := by decide
def e302796717766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.lam (.var 1))))))))
theorem wire_e302796717766 : Closed e302796717766 ∧ code e302796717766 = 1402308345542 := by decide
theorem cert_e302796717766 : check e302796717766 [[],[]] .three = true := by decide
def e302796717806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 2)))))))
theorem wire_e302796717806 : Closed e302796717806 ∧ code e302796717806 = 1402308345582 := by decide
theorem cert_e302796717806 : check e302796717806 [[],[]] .three = true := by decide
def e302796719038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 4)))))))))
theorem wire_e302796719038 : Closed e302796719038 ∧ code e302796719038 = 1402308346814 := by decide
theorem cert_e302796719038 : check e302796719038 [[],[]] .three = true := by decide
def e302796719070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e302796719070 : Closed e302796719070 ∧ code e302796719070 = 1402308346846 := by decide
theorem cert_e302796719070 : check e302796719070 [[],[]] .smaller = true := by decide
def e302796719086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e302796719086 : Closed e302796719086 ∧ code e302796719086 = 1402308346862 := by decide
theorem cert_e302796719086 : check e302796719086 [[],[]] .smaller = true := by decide
def e302796719094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 4) (.var 1)))))))))
theorem wire_e302796719094 : Closed e302796719094 ∧ code e302796719094 = 1402308346870 := by decide
theorem cert_e302796719094 : check e302796719094 [[],[]] .three = true := by decide
def e302796720990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e302796720990 : Closed e302796720990 ∧ code e302796720990 = 1402308348766 := by decide
theorem cert_e302796720990 : check e302796720990 [[],[]] .three = true := by decide
def e302796721006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302796721006 : Closed e302796721006 ∧ code e302796721006 = 1402308348782 := by decide
theorem cert_e302796721006 : check e302796721006 [[],[]] .smaller = true := by decide
def e302796721014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302796721014 : Closed e302796721014 ∧ code e302796721014 = 1402308348790 := by decide
theorem cert_e302796721014 : check e302796721014 [[],[]] .smaller = true := by decide
def e302796721018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e302796721018 : Closed e302796721018 ∧ code e302796721018 = 1402308348794 := by decide
theorem cert_e302796721018 : check e302796721018 [[],[]] .three = true := by decide
def e302796721070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302796721070 : Closed e302796721070 ∧ code e302796721070 = 1402308348846 := by decide
theorem cert_e302796721070 : check e302796721070 [[],[]] .smaller = true := by decide
def e302796721082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302796721082 : Closed e302796721082 ∧ code e302796721082 = 1402308348858 := by decide
theorem cert_e302796721082 : check e302796721082 [[],[]] .smaller = true := by decide
def e302796721110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302796721110 : Closed e302796721110 ∧ code e302796721110 = 1402308348886 := by decide
theorem cert_e302796721110 : check e302796721110 [[],[]] .smaller = true := by decide
def e302796721114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302796721114 : Closed e302796721114 ∧ code e302796721114 = 1402308348890 := by decide
theorem cert_e302796721114 : check e302796721114 [[],[]] .smaller = true := by decide
def e302796721130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e302796721130 : Closed e302796721130 ∧ code e302796721130 = 1402308348906 := by decide
theorem cert_e302796721130 : check e302796721130 [[],[]] .three = true := by decide
def e302796721374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e302796721374 : Closed e302796721374 ∧ code e302796721374 = 1402308349150 := by decide
theorem cert_e302796721374 : check e302796721374 [[],[]] .three = true := by decide
def e302796721390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302796721390 : Closed e302796721390 ∧ code e302796721390 = 1402308349166 := by decide
theorem cert_e302796721390 : check e302796721390 [[],[]] .smaller = true := by decide
def e302796721398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302796721398 : Closed e302796721398 ∧ code e302796721398 = 1402308349174 := by decide
theorem cert_e302796721398 : check e302796721398 [[],[]] .smaller = true := by decide
def e302796721402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e302796721402 : Closed e302796721402 ∧ code e302796721402 = 1402308349178 := by decide
theorem cert_e302796721402 : check e302796721402 [[],[]] .three = true := by decide
def e302796721726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e302796721726 : Closed e302796721726 ∧ code e302796721726 = 1402308349502 := by decide
theorem cert_e302796721726 : check e302796721726 [[],[]] .three = true := by decide
def e302796721774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302796721774 : Closed e302796721774 ∧ code e302796721774 = 1402308349550 := by decide
theorem cert_e302796721774 : check e302796721774 [[],[]] .smaller = true := by decide
def e302796721786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302796721786 : Closed e302796721786 ∧ code e302796721786 = 1402308349562 := by decide
theorem cert_e302796721786 : check e302796721786 [[],[]] .smaller = true := by decide
def e302796721950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e302796721950 : Closed e302796721950 ∧ code e302796721950 = 1402308349726 := by decide
theorem cert_e302796721950 : check e302796721950 [[],[]] .smaller = true := by decide
def e302796721974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302796721974 : Closed e302796721974 ∧ code e302796721974 = 1402308349750 := by decide
theorem cert_e302796721974 : check e302796721974 [[],[]] .smaller = true := by decide
def e302796721978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302796721978 : Closed e302796721978 ∧ code e302796721978 = 1402308349754 := by decide
theorem cert_e302796721978 : check e302796721978 [[],[]] .smaller = true := by decide
def e302796722062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e302796722062 : Closed e302796722062 ∧ code e302796722062 = 1402308349838 := by decide
theorem cert_e302796722062 : check e302796722062 [[],[]] .three = true := by decide
def e302796722074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e302796722074 : Closed e302796722074 ∧ code e302796722074 = 1402308349850 := by decide
theorem cert_e302796722074 : check e302796722074 [[],[]] .three = true := by decide
def e302796726750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e302796726750 : Closed e302796726750 ∧ code e302796726750 = 1402308354526 := by decide
theorem cert_e302796726750 : check e302796726750 [[],[]] .smaller = true := by decide
def e302796726774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e302796726774 : Closed e302796726774 ∧ code e302796726774 = 1402308354550 := by decide
theorem cert_e302796726774 : check e302796726774 [[],[]] .smaller = true := by decide
def e302796727726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e302796727726 : Closed e302796727726 ∧ code e302796727726 = 1402308355502 := by decide
theorem cert_e302796727726 : check e302796727726 [[],[]] .smaller = true := by decide
def e302796727738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e302796727738 : Closed e302796727738 ∧ code e302796727738 = 1402308355514 := by decide
theorem cert_e302796727738 : check e302796727738 [[],[]] .smaller = true := by decide
def e302796727786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e302796727786 : Closed e302796727786 ∧ code e302796727786 = 1402308355562 := by decide
theorem cert_e302796727786 : check e302796727786 [[],[]] .smaller = true := by decide
def e302796727870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e302796727870 : Closed e302796727870 ∧ code e302796727870 = 1402308355646 := by decide
theorem cert_e302796727870 : check e302796727870 [[],[]] .three = true := by decide
def e302796727918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e302796727918 : Closed e302796727918 ∧ code e302796727918 = 1402308355694 := by decide
theorem cert_e302796727918 : check e302796727918 [[],[]] .smaller = true := by decide
def e302796727930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e302796727930 : Closed e302796727930 ∧ code e302796727930 = 1402308355706 := by decide
theorem cert_e302796727930 : check e302796727930 [[],[]] .smaller = true := by decide
def e302796728218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e302796728218 : Closed e302796728218 ∧ code e302796728218 = 1402308355994 := by decide
theorem cert_e302796728218 : check e302796728218 [[],[]] .smaller = true := by decide
def e302796728262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e302796728262 : Closed e302796728262 ∧ code e302796728262 = 1402308356038 := by decide
theorem cert_e302796728262 : check e302796728262 [[],[]] .three = true := by decide
def e302796730606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e302796730606 : Closed e302796730606 ∧ code e302796730606 = 1402308358382 := by decide
theorem cert_e302796730606 : check e302796730606 [[],[]] .smaller = true := by decide
def e302796730614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e302796730614 : Closed e302796730614 ∧ code e302796730614 = 1402308358390 := by decide
theorem cert_e302796730614 : check e302796730614 [[],[]] .smaller = true := by decide
def e302796731094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e302796731094 : Closed e302796731094 ∧ code e302796731094 = 1402308358870 := by decide
theorem cert_e302796731094 : check e302796731094 [[],[]] .smaller = true := by decide
def e302796731098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e302796731098 : Closed e302796731098 ∧ code e302796731098 = 1402308358874 := by decide
theorem cert_e302796731098 : check e302796731098 [[],[]] .smaller = true := by decide
def e302796731114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e302796731114 : Closed e302796731114 ∧ code e302796731114 = 1402308358890 := by decide
theorem cert_e302796731114 : check e302796731114 [[],[]] .smaller = true := by decide
def e302796731166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e302796731166 : Closed e302796731166 ∧ code e302796731166 = 1402308358942 := by decide
theorem cert_e302796731166 : check e302796731166 [[],[]] .smaller = true := by decide
def e302796731190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e302796731190 : Closed e302796731190 ∧ code e302796731190 = 1402308358966 := by decide
theorem cert_e302796731190 : check e302796731190 [[],[]] .smaller = true := by decide
def e302796731194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e302796731194 : Closed e302796731194 ∧ code e302796731194 = 1402308358970 := by decide
theorem cert_e302796731194 : check e302796731194 [[],[]] .smaller = true := by decide
def e302796731290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e302796731290 : Closed e302796731290 ∧ code e302796731290 = 1402308359066 := by decide
theorem cert_e302796731290 : check e302796731290 [[],[]] .smaller = true := by decide
def e302796731334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e302796731334 : Closed e302796731334 ∧ code e302796731334 = 1402308359110 := by decide
theorem cert_e302796731334 : check e302796731334 [[],[]] .smaller = true := by decide
def e302796731358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 3))))))))
theorem wire_e302796731358 : Closed e302796731358 ∧ code e302796731358 = 1402308359134 := by decide
theorem cert_e302796731358 : check e302796731358 [[],[]] .three = true := by decide
def e302796731374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 2))))))))
theorem wire_e302796731374 : Closed e302796731374 ∧ code e302796731374 = 1402308359150 := by decide
theorem cert_e302796731374 : check e302796731374 [[],[]] .three = true := by decide
def e302796732534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e302796732534 : Closed e302796732534 ∧ code e302796732534 = 1402308360310 := by decide
theorem cert_e302796732534 : check e302796732534 [[],[]] .three = true := by decide
def e302796732778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e302796732778 : Closed e302796732778 ∧ code e302796732778 = 1402308360554 := by decide
theorem cert_e302796732778 : check e302796732778 [[],[]] .three = true := by decide
def e302796732814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302796732814 : Closed e302796732814 ∧ code e302796732814 = 1402308360590 := by decide
theorem cert_e302796732814 : check e302796732814 [[],[]] .three = true := by decide
def e302796732826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e302796732826 : Closed e302796732826 ∧ code e302796732826 = 1402308360602 := by decide
theorem cert_e302796732826 : check e302796732826 [[],[]] .three = true := by decide
def e302796732870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302796732870 : Closed e302796732870 ∧ code e302796732870 = 1402308360646 := by decide
theorem cert_e302796732870 : check e302796732870 [[],[]] .three = true := by decide
def e302796732910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 2))))))))
theorem wire_e302796732910 : Closed e302796732910 ∧ code e302796732910 = 1402308360686 := by decide
theorem cert_e302796732910 : check e302796732910 [[],[]] .three = true := by decide
def e302796736374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e302796736374 : Closed e302796736374 ∧ code e302796736374 = 1402308364150 := by decide
theorem cert_e302796736374 : check e302796736374 [[],[]] .smaller = true := by decide
def e302796736438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e302796736438 : Closed e302796736438 ∧ code e302796736438 = 1402308364214 := by decide
theorem cert_e302796736438 : check e302796736438 [[],[]] .smaller = true := by decide
def e302796736442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e302796736442 : Closed e302796736442 ∧ code e302796736442 = 1402308364218 := by decide
theorem cert_e302796736442 : check e302796736442 [[],[]] .smaller = true := by decide
def e302796737758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e302796737758 : Closed e302796737758 ∧ code e302796737758 = 1402308365534 := by decide
theorem cert_e302796737758 : check e302796737758 [[],[]] .three = true := by decide
def e302796737774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e302796737774 : Closed e302796737774 ∧ code e302796737774 = 1402308365550 := by decide
theorem cert_e302796737774 : check e302796737774 [[],[]] .smaller = true := by decide
def e302796737782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e302796737782 : Closed e302796737782 ∧ code e302796737782 = 1402308365558 := by decide
theorem cert_e302796737782 : check e302796737782 [[],[]] .smaller = true := by decide
def e302796737786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e302796737786 : Closed e302796737786 ∧ code e302796737786 = 1402308365562 := by decide
theorem cert_e302796737786 : check e302796737786 [[],[]] .three = true := by decide
def e302796738158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e302796738158 : Closed e302796738158 ∧ code e302796738158 = 1402308365934 := by decide
theorem cert_e302796738158 : check e302796738158 [[],[]] .smaller = true := by decide
def e302796738170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e302796738170 : Closed e302796738170 ∧ code e302796738170 = 1402308365946 := by decide
theorem cert_e302796738170 : check e302796738170 [[],[]] .smaller = true := by decide
def e302796738358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e302796738358 : Closed e302796738358 ∧ code e302796738358 = 1402308366134 := by decide
theorem cert_e302796738358 : check e302796738358 [[],[]] .smaller = true := by decide
def e302796738362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e302796738362 : Closed e302796738362 ∧ code e302796738362 = 1402308366138 := by decide
theorem cert_e302796738362 : check e302796738362 [[],[]] .smaller = true := by decide
def e302796738458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.app (.var 0) (.var 0))))))))
theorem wire_e302796738458 : Closed e302796738458 ∧ code e302796738458 = 1402308366234 := by decide
theorem cert_e302796738458 : check e302796738458 [[],[]] .three = true := by decide
def e302796740278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e302796740278 : Closed e302796740278 ∧ code e302796740278 = 1402308368054 := by decide
theorem cert_e302796740278 : check e302796740278 [[],[]] .smaller = true := by decide
def e302796740310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e302796740310 : Closed e302796740310 ∧ code e302796740310 = 1402308368086 := by decide
theorem cert_e302796740310 : check e302796740310 [[],[]] .smaller = true := by decide
def e302796740314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e302796740314 : Closed e302796740314 ∧ code e302796740314 = 1402308368090 := by decide
theorem cert_e302796740314 : check e302796740314 [[],[]] .smaller = true := by decide
def e302796740438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e302796740438 : Closed e302796740438 ∧ code e302796740438 = 1402308368214 := by decide
theorem cert_e302796740438 : check e302796740438 [[],[]] .smaller = true := by decide
def e302796740442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e302796740442 : Closed e302796740442 ∧ code e302796740442 = 1402308368218 := by decide
theorem cert_e302796740442 : check e302796740442 [[],[]] .smaller = true := by decide
def e302796740458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e302796740458 : Closed e302796740458 ∧ code e302796740458 = 1402308368234 := by decide
theorem cert_e302796740458 : check e302796740458 [[],[]] .smaller = true := by decide
def e302796740830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e302796740830 : Closed e302796740830 ∧ code e302796740830 = 1402308368606 := by decide
theorem cert_e302796740830 : check e302796740830 [[],[]] .three = true := by decide
def e302796740846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e302796740846 : Closed e302796740846 ∧ code e302796740846 = 1402308368622 := by decide
theorem cert_e302796740846 : check e302796740846 [[],[]] .smaller = true := by decide
def e302796740854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e302796740854 : Closed e302796740854 ∧ code e302796740854 = 1402308368630 := by decide
theorem cert_e302796740854 : check e302796740854 [[],[]] .smaller = true := by decide
def e302796740858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e302796740858 : Closed e302796740858 ∧ code e302796740858 = 1402308368634 := by decide
theorem cert_e302796740858 : check e302796740858 [[],[]] .three = true := by decide
def e302796741046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e302796741046 : Closed e302796741046 ∧ code e302796741046 = 1402308368822 := by decide
theorem cert_e302796741046 : check e302796741046 [[],[]] .smaller = true := by decide
def e302796741078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e302796741078 : Closed e302796741078 ∧ code e302796741078 = 1402308368854 := by decide
theorem cert_e302796741078 : check e302796741078 [[],[]] .smaller = true := by decide
def e302796741082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e302796741082 : Closed e302796741082 ∧ code e302796741082 = 1402308368858 := by decide
theorem cert_e302796741082 : check e302796741082 [[],[]] .smaller = true := by decide
def e302796741182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 4))))))))
theorem wire_e302796741182 : Closed e302796741182 ∧ code e302796741182 = 1402308368958 := by decide
theorem cert_e302796741182 : check e302796741182 [[],[]] .three = true := by decide
def e302796741238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e302796741238 : Closed e302796741238 ∧ code e302796741238 = 1402308369014 := by decide
theorem cert_e302796741238 : check e302796741238 [[],[]] .smaller = true := by decide
def e302796741406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e302796741406 : Closed e302796741406 ∧ code e302796741406 = 1402308369182 := by decide
theorem cert_e302796741406 : check e302796741406 [[],[]] .smaller = true := by decide
def e302796741430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e302796741430 : Closed e302796741430 ∧ code e302796741430 = 1402308369206 := by decide
theorem cert_e302796741430 : check e302796741430 [[],[]] .smaller = true := by decide
def e302796741434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e302796741434 : Closed e302796741434 ∧ code e302796741434 = 1402308369210 := by decide
theorem cert_e302796741434 : check e302796741434 [[],[]] .smaller = true := by decide
def e302796741518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e302796741518 : Closed e302796741518 ∧ code e302796741518 = 1402308369294 := by decide
theorem cert_e302796741518 : check e302796741518 [[],[]] .smaller = true := by decide
def e302796741574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.lam (.var 1))))))))
theorem wire_e302796741574 : Closed e302796741574 ∧ code e302796741574 = 1402308369350 := by decide
theorem cert_e302796741574 : check e302796741574 [[],[]] .three = true := by decide
def e302796741598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 3)))))))
theorem wire_e302796741598 : Closed e302796741598 ∧ code e302796741598 = 1402308369374 := by decide
theorem cert_e302796741598 : check e302796741598 [[],[]] .three = true := by decide
def e302796741742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e302796741742 : Closed e302796741742 ∧ code e302796741742 = 1402308369518 := by decide
theorem cert_e302796741742 : check e302796741742 [[],[]] .smaller = true := by decide
end Blc.Floor40
