import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e301453061550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e301453061550 : Closed e301453061550 ∧ code e301453061550 = 1400964689326 := by decide
theorem cert_e301453061550 : check e301453061550 [[],[]] .smaller = true := by decide
def e301453061562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e301453061562 : Closed e301453061562 ∧ code e301453061562 = 1400964689338 := by decide
theorem cert_e301453061562 : check e301453061562 [[],[]] .smaller = true := by decide
def e301453061590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e301453061590 : Closed e301453061590 ∧ code e301453061590 = 1400964689366 := by decide
theorem cert_e301453061590 : check e301453061590 [[],[]] .smaller = true := by decide
def e301453061594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e301453061594 : Closed e301453061594 ∧ code e301453061594 = 1400964689370 := by decide
theorem cert_e301453061594 : check e301453061594 [[],[]] .smaller = true := by decide
def e301453061806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e301453061806 : Closed e301453061806 ∧ code e301453061806 = 1400964689582 := by decide
theorem cert_e301453061806 : check e301453061806 [[],[]] .smaller = true := by decide
def e301453061818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e301453061818 : Closed e301453061818 ∧ code e301453061818 = 1400964689594 := by decide
theorem cert_e301453061818 : check e301453061818 [[],[]] .smaller = true := by decide
def e301453061866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e301453061866 : Closed e301453061866 ∧ code e301453061866 = 1400964689642 := by decide
theorem cert_e301453061866 : check e301453061866 [[],[]] .smaller = true := by decide
def e301453061974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e301453061974 : Closed e301453061974 ∧ code e301453061974 = 1400964689750 := by decide
theorem cert_e301453061974 : check e301453061974 [[],[]] .smaller = true := by decide
def e301453061978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e301453061978 : Closed e301453061978 ∧ code e301453061978 = 1400964689754 := by decide
theorem cert_e301453061978 : check e301453061978 [[],[]] .smaller = true := by decide
def e301453061994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e301453061994 : Closed e301453061994 ∧ code e301453061994 = 1400964689770 := by decide
theorem cert_e301453061994 : check e301453061994 [[],[]] .smaller = true := by decide
def e301453063022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e301453063022 : Closed e301453063022 ∧ code e301453063022 = 1400964690798 := by decide
theorem cert_e301453063022 : check e301453063022 [[],[]] .smaller = true := by decide
def e301453063030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e301453063030 : Closed e301453063030 ∧ code e301453063030 = 1400964690806 := by decide
theorem cert_e301453063030 : check e301453063030 [[],[]] .smaller = true := by decide
def e301453063086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e301453063086 : Closed e301453063086 ∧ code e301453063086 = 1400964690862 := by decide
theorem cert_e301453063086 : check e301453063086 [[],[]] .smaller = true := by decide
def e301453063098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e301453063098 : Closed e301453063098 ∧ code e301453063098 = 1400964690874 := by decide
theorem cert_e301453063098 : check e301453063098 [[],[]] .smaller = true := by decide
def e301453063126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e301453063126 : Closed e301453063126 ∧ code e301453063126 = 1400964690902 := by decide
theorem cert_e301453063126 : check e301453063126 [[],[]] .smaller = true := by decide
def e301453063130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e301453063130 : Closed e301453063130 ∧ code e301453063130 = 1400964690906 := by decide
theorem cert_e301453063130 : check e301453063130 [[],[]] .smaller = true := by decide
def e301453063406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e301453063406 : Closed e301453063406 ∧ code e301453063406 = 1400964691182 := by decide
theorem cert_e301453063406 : check e301453063406 [[],[]] .smaller = true := by decide
def e301453063414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e301453063414 : Closed e301453063414 ∧ code e301453063414 = 1400964691190 := by decide
theorem cert_e301453063414 : check e301453063414 [[],[]] .smaller = true := by decide
def e301453063790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e301453063790 : Closed e301453063790 ∧ code e301453063790 = 1400964691566 := by decide
theorem cert_e301453063790 : check e301453063790 [[],[]] .smaller = true := by decide
def e301453063802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e301453063802 : Closed e301453063802 ∧ code e301453063802 = 1400964691578 := by decide
theorem cert_e301453063802 : check e301453063802 [[],[]] .smaller = true := by decide
def e301453063990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e301453063990 : Closed e301453063990 ∧ code e301453063990 = 1400964691766 := by decide
theorem cert_e301453063990 : check e301453063990 [[],[]] .smaller = true := by decide
def e301453063994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e301453063994 : Closed e301453063994 ∧ code e301453063994 = 1400964691770 := by decide
theorem cert_e301453063994 : check e301453063994 [[],[]] .smaller = true := by decide
def e301453064622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e301453064622 : Closed e301453064622 ∧ code e301453064622 = 1400964692398 := by decide
theorem cert_e301453064622 : check e301453064622 [[],[]] .smaller = true := by decide
def e301453064634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e301453064634 : Closed e301453064634 ∧ code e301453064634 = 1400964692410 := by decide
theorem cert_e301453064634 : check e301453064634 [[],[]] .smaller = true := by decide
def e301453064682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e301453064682 : Closed e301453064682 ∧ code e301453064682 = 1400964692458 := by decide
theorem cert_e301453064682 : check e301453064682 [[],[]] .smaller = true := by decide
def e301453064814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e301453064814 : Closed e301453064814 ∧ code e301453064814 = 1400964692590 := by decide
theorem cert_e301453064814 : check e301453064814 [[],[]] .smaller = true := by decide
def e301453064826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e301453064826 : Closed e301453064826 ∧ code e301453064826 = 1400964692602 := by decide
theorem cert_e301453064826 : check e301453064826 [[],[]] .smaller = true := by decide
def e301453065114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e301453065114 : Closed e301453065114 ∧ code e301453065114 = 1400964692890 := by decide
theorem cert_e301453065114 : check e301453065114 [[],[]] .smaller = true := by decide
def e301453065430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e301453065430 : Closed e301453065430 ∧ code e301453065430 = 1400964693206 := by decide
theorem cert_e301453065430 : check e301453065430 [[],[]] .smaller = true := by decide
def e301453065434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e301453065434 : Closed e301453065434 ∧ code e301453065434 = 1400964693210 := by decide
theorem cert_e301453065434 : check e301453065434 [[],[]] .smaller = true := by decide
def e301453065450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e301453065450 : Closed e301453065450 ∧ code e301453065450 = 1400964693226 := by decide
theorem cert_e301453065450 : check e301453065450 [[],[]] .smaller = true := by decide
def e301453065526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e301453065526 : Closed e301453065526 ∧ code e301453065526 = 1400964693302 := by decide
theorem cert_e301453065526 : check e301453065526 [[],[]] .smaller = true := by decide
def e301453065530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e301453065530 : Closed e301453065530 ∧ code e301453065530 = 1400964693306 := by decide
theorem cert_e301453065530 : check e301453065530 [[],[]] .smaller = true := by decide
def e301453065626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e301453065626 : Closed e301453065626 ∧ code e301453065626 = 1400964693402 := by decide
theorem cert_e301453065626 : check e301453065626 [[],[]] .smaller = true := by decide
def e301453069166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e301453069166 : Closed e301453069166 ∧ code e301453069166 = 1400964696942 := by decide
theorem cert_e301453069166 : check e301453069166 [[],[]] .smaller = true := by decide
def e301453069174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e301453069174 : Closed e301453069174 ∧ code e301453069174 = 1400964696950 := by decide
theorem cert_e301453069174 : check e301453069174 [[],[]] .smaller = true := by decide
def e301453069230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e301453069230 : Closed e301453069230 ∧ code e301453069230 = 1400964697006 := by decide
theorem cert_e301453069230 : check e301453069230 [[],[]] .smaller = true := by decide
def e301453069242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e301453069242 : Closed e301453069242 ∧ code e301453069242 = 1400964697018 := by decide
theorem cert_e301453069242 : check e301453069242 [[],[]] .smaller = true := by decide
def e301453069270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e301453069270 : Closed e301453069270 ∧ code e301453069270 = 1400964697046 := by decide
theorem cert_e301453069270 : check e301453069270 [[],[]] .smaller = true := by decide
def e301453069274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e301453069274 : Closed e301453069274 ∧ code e301453069274 = 1400964697050 := by decide
theorem cert_e301453069274 : check e301453069274 [[],[]] .smaller = true := by decide
def e301453069550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e301453069550 : Closed e301453069550 ∧ code e301453069550 = 1400964697326 := by decide
theorem cert_e301453069550 : check e301453069550 [[],[]] .smaller = true := by decide
def e301453069558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e301453069558 : Closed e301453069558 ∧ code e301453069558 = 1400964697334 := by decide
theorem cert_e301453069558 : check e301453069558 [[],[]] .smaller = true := by decide
def e301453069934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e301453069934 : Closed e301453069934 ∧ code e301453069934 = 1400964697710 := by decide
theorem cert_e301453069934 : check e301453069934 [[],[]] .smaller = true := by decide
def e301453069946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e301453069946 : Closed e301453069946 ∧ code e301453069946 = 1400964697722 := by decide
theorem cert_e301453069946 : check e301453069946 [[],[]] .smaller = true := by decide
def e301453070134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e301453070134 : Closed e301453070134 ∧ code e301453070134 = 1400964697910 := by decide
theorem cert_e301453070134 : check e301453070134 [[],[]] .smaller = true := by decide
def e301453070138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e301453070138 : Closed e301453070138 ∧ code e301453070138 = 1400964697914 := by decide
theorem cert_e301453070138 : check e301453070138 [[],[]] .smaller = true := by decide
def e301453075886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e301453075886 : Closed e301453075886 ∧ code e301453075886 = 1400964703662 := by decide
theorem cert_e301453075886 : check e301453075886 [[],[]] .smaller = true := by decide
def e301453075898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e301453075898 : Closed e301453075898 ∧ code e301453075898 = 1400964703674 := by decide
theorem cert_e301453075898 : check e301453075898 [[],[]] .smaller = true := by decide
def e301453075946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e301453075946 : Closed e301453075946 ∧ code e301453075946 = 1400964703722 := by decide
theorem cert_e301453075946 : check e301453075946 [[],[]] .smaller = true := by decide
def e301453076078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e301453076078 : Closed e301453076078 ∧ code e301453076078 = 1400964703854 := by decide
theorem cert_e301453076078 : check e301453076078 [[],[]] .smaller = true := by decide
def e301453076090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e301453076090 : Closed e301453076090 ∧ code e301453076090 = 1400964703866 := by decide
theorem cert_e301453076090 : check e301453076090 [[],[]] .smaller = true := by decide
def e301453076378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e301453076378 : Closed e301453076378 ∧ code e301453076378 = 1400964704154 := by decide
theorem cert_e301453076378 : check e301453076378 [[],[]] .smaller = true := by decide
def e301453079254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e301453079254 : Closed e301453079254 ∧ code e301453079254 = 1400964707030 := by decide
theorem cert_e301453079254 : check e301453079254 [[],[]] .smaller = true := by decide
def e301453079258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e301453079258 : Closed e301453079258 ∧ code e301453079258 = 1400964707034 := by decide
theorem cert_e301453079258 : check e301453079258 [[],[]] .smaller = true := by decide
def e301453079274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e301453079274 : Closed e301453079274 ∧ code e301453079274 = 1400964707050 := by decide
theorem cert_e301453079274 : check e301453079274 [[],[]] .smaller = true := by decide
def e301453079350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e301453079350 : Closed e301453079350 ∧ code e301453079350 = 1400964707126 := by decide
theorem cert_e301453079350 : check e301453079350 [[],[]] .smaller = true := by decide
def e301453079354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e301453079354 : Closed e301453079354 ∧ code e301453079354 = 1400964707130 := by decide
theorem cert_e301453079354 : check e301453079354 [[],[]] .smaller = true := by decide
def e301453079450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e301453079450 : Closed e301453079450 ∧ code e301453079450 = 1400964707226 := by decide
theorem cert_e301453079450 : check e301453079450 [[],[]] .smaller = true := by decide
def e301453194718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e301453194718 : Closed e301453194718 ∧ code e301453194718 = 1400964822494 := by decide
theorem cert_e301453194718 : check e301453194718 [[],[]] .three = true := by decide
def e301453194734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e301453194734 : Closed e301453194734 ∧ code e301453194734 = 1400964822510 := by decide
theorem cert_e301453194734 : check e301453194734 [[],[]] .three = true := by decide
def e301453194974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e301453194974 : Closed e301453194974 ∧ code e301453194974 = 1400964822750 := by decide
theorem cert_e301453194974 : check e301453194974 [[],[]] .three = true := by decide
def e301453194990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e301453194990 : Closed e301453194990 ∧ code e301453194990 = 1400964822766 := by decide
theorem cert_e301453194990 : check e301453194990 [[],[]] .smaller = true := by decide
def e301453194998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e301453194998 : Closed e301453194998 ∧ code e301453194998 = 1400964822774 := by decide
theorem cert_e301453194998 : check e301453194998 [[],[]] .three = true := by decide
def e301453195102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e301453195102 : Closed e301453195102 ∧ code e301453195102 = 1400964822878 := by decide
theorem cert_e301453195102 : check e301453195102 [[],[]] .three = true := by decide
def e301453195118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e301453195118 : Closed e301453195118 ∧ code e301453195118 = 1400964822894 := by decide
theorem cert_e301453195118 : check e301453195118 [[],[]] .smaller = true := by decide
def e301453195126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e301453195126 : Closed e301453195126 ∧ code e301453195126 = 1400964822902 := by decide
theorem cert_e301453195126 : check e301453195126 [[],[]] .smaller = true := by decide
def e301453195130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e301453195130 : Closed e301453195130 ∧ code e301453195130 = 1400964822906 := by decide
theorem cert_e301453195130 : check e301453195130 [[],[]] .three = true := by decide
def e301453195182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e301453195182 : Closed e301453195182 ∧ code e301453195182 = 1400964822958 := by decide
theorem cert_e301453195182 : check e301453195182 [[],[]] .three = true := by decide
def e301453195190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e301453195190 : Closed e301453195190 ∧ code e301453195190 = 1400964822966 := by decide
theorem cert_e301453195190 : check e301453195190 [[],[]] .three = true := by decide
def e301453195194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e301453195194 : Closed e301453195194 ∧ code e301453195194 = 1400964822970 := by decide
theorem cert_e301453195194 : check e301453195194 [[],[]] .three = true := by decide
def e301453195998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e301453195998 : Closed e301453195998 ∧ code e301453195998 = 1400964823774 := by decide
theorem cert_e301453195998 : check e301453195998 [[],[]] .three = true := by decide
def e301453196014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e301453196014 : Closed e301453196014 ∧ code e301453196014 = 1400964823790 := by decide
theorem cert_e301453196014 : check e301453196014 [[],[]] .smaller = true := by decide
def e301453196022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e301453196022 : Closed e301453196022 ∧ code e301453196022 = 1400964823798 := by decide
theorem cert_e301453196022 : check e301453196022 [[],[]] .three = true := by decide
def e301453196126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e301453196126 : Closed e301453196126 ∧ code e301453196126 = 1400964823902 := by decide
theorem cert_e301453196126 : check e301453196126 [[],[]] .three = true := by decide
def e301453196154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e301453196154 : Closed e301453196154 ∧ code e301453196154 = 1400964823930 := by decide
theorem cert_e301453196154 : check e301453196154 [[],[]] .three = true := by decide
def e301453196206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e301453196206 : Closed e301453196206 ∧ code e301453196206 = 1400964823982 := by decide
theorem cert_e301453196206 : check e301453196206 [[],[]] .smaller = true := by decide
def e301453196218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e301453196218 : Closed e301453196218 ∧ code e301453196218 = 1400964823994 := by decide
theorem cert_e301453196218 : check e301453196218 [[],[]] .smaller = true := by decide
def e301453196246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e301453196246 : Closed e301453196246 ∧ code e301453196246 = 1400964824022 := by decide
theorem cert_e301453196246 : check e301453196246 [[],[]] .three = true := by decide
def e301453196250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e301453196250 : Closed e301453196250 ∧ code e301453196250 = 1400964824026 := by decide
theorem cert_e301453196250 : check e301453196250 [[],[]] .three = true := by decide
def e301453196638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e301453196638 : Closed e301453196638 ∧ code e301453196638 = 1400964824414 := by decide
theorem cert_e301453196638 : check e301453196638 [[],[]] .three = true := by decide
def e301453196654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e301453196654 : Closed e301453196654 ∧ code e301453196654 = 1400964824430 := by decide
theorem cert_e301453196654 : check e301453196654 [[],[]] .smaller = true := by decide
def e301453196662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e301453196662 : Closed e301453196662 ∧ code e301453196662 = 1400964824438 := by decide
theorem cert_e301453196662 : check e301453196662 [[],[]] .smaller = true := by decide
def e301453196666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e301453196666 : Closed e301453196666 ∧ code e301453196666 = 1400964824442 := by decide
theorem cert_e301453196666 : check e301453196666 [[],[]] .three = true := by decide
def e301453196718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e301453196718 : Closed e301453196718 ∧ code e301453196718 = 1400964824494 := by decide
theorem cert_e301453196718 : check e301453196718 [[],[]] .smaller = true := by decide
def e301453196730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e301453196730 : Closed e301453196730 ∧ code e301453196730 = 1400964824506 := by decide
theorem cert_e301453196730 : check e301453196730 [[],[]] .smaller = true := by decide
def e301453196758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e301453196758 : Closed e301453196758 ∧ code e301453196758 = 1400964824534 := by decide
theorem cert_e301453196758 : check e301453196758 [[],[]] .smaller = true := by decide
def e301453196762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e301453196762 : Closed e301453196762 ∧ code e301453196762 = 1400964824538 := by decide
theorem cert_e301453196762 : check e301453196762 [[],[]] .smaller = true := by decide
def e301453196778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e301453196778 : Closed e301453196778 ∧ code e301453196778 = 1400964824554 := by decide
theorem cert_e301453196778 : check e301453196778 [[],[]] .three = true := by decide
def e301453196974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e301453196974 : Closed e301453196974 ∧ code e301453196974 = 1400964824750 := by decide
theorem cert_e301453196974 : check e301453196974 [[],[]] .three = true := by decide
def e301453196982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e301453196982 : Closed e301453196982 ∧ code e301453196982 = 1400964824758 := by decide
theorem cert_e301453196982 : check e301453196982 [[],[]] .three = true := by decide
def e301453196986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e301453196986 : Closed e301453196986 ∧ code e301453196986 = 1400964824762 := by decide
theorem cert_e301453196986 : check e301453196986 [[],[]] .three = true := by decide
def e301453197014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e301453197014 : Closed e301453197014 ∧ code e301453197014 = 1400964824790 := by decide
theorem cert_e301453197014 : check e301453197014 [[],[]] .three = true := by decide
def e301453197018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e301453197018 : Closed e301453197018 ∧ code e301453197018 = 1400964824794 := by decide
theorem cert_e301453197018 : check e301453197018 [[],[]] .three = true := by decide
def e301453197034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e301453197034 : Closed e301453197034 ∧ code e301453197034 = 1400964824810 := by decide
theorem cert_e301453197034 : check e301453197034 [[],[]] .three = true := by decide
def e301453200862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e301453200862 : Closed e301453200862 ∧ code e301453200862 = 1400964828638 := by decide
theorem cert_e301453200862 : check e301453200862 [[],[]] .three = true := by decide
def e301453200878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e301453200878 : Closed e301453200878 ∧ code e301453200878 = 1400964828654 := by decide
theorem cert_e301453200878 : check e301453200878 [[],[]] .three = true := by decide
def e301453201118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e301453201118 : Closed e301453201118 ∧ code e301453201118 = 1400964828894 := by decide
theorem cert_e301453201118 : check e301453201118 [[],[]] .three = true := by decide
def e301453201134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e301453201134 : Closed e301453201134 ∧ code e301453201134 = 1400964828910 := by decide
theorem cert_e301453201134 : check e301453201134 [[],[]] .smaller = true := by decide
def e301453201142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e301453201142 : Closed e301453201142 ∧ code e301453201142 = 1400964828918 := by decide
theorem cert_e301453201142 : check e301453201142 [[],[]] .three = true := by decide
def e301453201246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e301453201246 : Closed e301453201246 ∧ code e301453201246 = 1400964829022 := by decide
theorem cert_e301453201246 : check e301453201246 [[],[]] .three = true := by decide
def e301453201262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e301453201262 : Closed e301453201262 ∧ code e301453201262 = 1400964829038 := by decide
theorem cert_e301453201262 : check e301453201262 [[],[]] .smaller = true := by decide
def e301453201270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e301453201270 : Closed e301453201270 ∧ code e301453201270 = 1400964829046 := by decide
theorem cert_e301453201270 : check e301453201270 [[],[]] .smaller = true := by decide
def e301453201274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e301453201274 : Closed e301453201274 ∧ code e301453201274 = 1400964829050 := by decide
theorem cert_e301453201274 : check e301453201274 [[],[]] .three = true := by decide
def e301453201326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e301453201326 : Closed e301453201326 ∧ code e301453201326 = 1400964829102 := by decide
theorem cert_e301453201326 : check e301453201326 [[],[]] .three = true := by decide
def e301453201334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e301453201334 : Closed e301453201334 ∧ code e301453201334 = 1400964829110 := by decide
theorem cert_e301453201334 : check e301453201334 [[],[]] .three = true := by decide
def e301453201338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e301453201338 : Closed e301453201338 ∧ code e301453201338 = 1400964829114 := by decide
theorem cert_e301453201338 : check e301453201338 [[],[]] .three = true := by decide
def e301453202398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e301453202398 : Closed e301453202398 ∧ code e301453202398 = 1400964830174 := by decide
theorem cert_e301453202398 : check e301453202398 [[],[]] .three = true := by decide
def e301453202414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e301453202414 : Closed e301453202414 ∧ code e301453202414 = 1400964830190 := by decide
theorem cert_e301453202414 : check e301453202414 [[],[]] .three = true := by decide
def e301453203934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e301453203934 : Closed e301453203934 ∧ code e301453203934 = 1400964831710 := by decide
theorem cert_e301453203934 : check e301453203934 [[],[]] .three = true := by decide
def e301453203950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e301453203950 : Closed e301453203950 ∧ code e301453203950 = 1400964831726 := by decide
theorem cert_e301453203950 : check e301453203950 [[],[]] .smaller = true := by decide
def e301453203958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e301453203958 : Closed e301453203958 ∧ code e301453203958 = 1400964831734 := by decide
theorem cert_e301453203958 : check e301453203958 [[],[]] .three = true := by decide
def e301453204702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e301453204702 : Closed e301453204702 ∧ code e301453204702 = 1400964832478 := by decide
theorem cert_e301453204702 : check e301453204702 [[],[]] .three = true := by decide
def e301453204718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e301453204718 : Closed e301453204718 ∧ code e301453204718 = 1400964832494 := by decide
theorem cert_e301453204718 : check e301453204718 [[],[]] .smaller = true := by decide
def e301453204726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e301453204726 : Closed e301453204726 ∧ code e301453204726 = 1400964832502 := by decide
theorem cert_e301453204726 : check e301453204726 [[],[]] .smaller = true := by decide
def e301453204730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e301453204730 : Closed e301453204730 ∧ code e301453204730 = 1400964832506 := by decide
theorem cert_e301453204730 : check e301453204730 [[],[]] .three = true := by decide
def e301453205102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e301453205102 : Closed e301453205102 ∧ code e301453205102 = 1400964832878 := by decide
theorem cert_e301453205102 : check e301453205102 [[],[]] .three = true := by decide
def e301453205110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e301453205110 : Closed e301453205110 ∧ code e301453205110 = 1400964832886 := by decide
theorem cert_e301453205110 : check e301453205110 [[],[]] .three = true := by decide
def e301453205114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e301453205114 : Closed e301453205114 ∧ code e301453205114 = 1400964832890 := by decide
theorem cert_e301453205114 : check e301453205114 [[],[]] .three = true := by decide
def e301453207262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e301453207262 : Closed e301453207262 ∧ code e301453207262 = 1400964835038 := by decide
theorem cert_e301453207262 : check e301453207262 [[],[]] .three = true := by decide
def e301453207278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e301453207278 : Closed e301453207278 ∧ code e301453207278 = 1400964835054 := by decide
theorem cert_e301453207278 : check e301453207278 [[],[]] .smaller = true := by decide
def e301453207286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e301453207286 : Closed e301453207286 ∧ code e301453207286 = 1400964835062 := by decide
theorem cert_e301453207286 : check e301453207286 [[],[]] .three = true := by decide
def e301453207390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e301453207390 : Closed e301453207390 ∧ code e301453207390 = 1400964835166 := by decide
theorem cert_e301453207390 : check e301453207390 [[],[]] .three = true := by decide
def e301453207418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e301453207418 : Closed e301453207418 ∧ code e301453207418 = 1400964835194 := by decide
theorem cert_e301453207418 : check e301453207418 [[],[]] .three = true := by decide
def e301453207470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e301453207470 : Closed e301453207470 ∧ code e301453207470 = 1400964835246 := by decide
theorem cert_e301453207470 : check e301453207470 [[],[]] .smaller = true := by decide
def e301453207482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e301453207482 : Closed e301453207482 ∧ code e301453207482 = 1400964835258 := by decide
theorem cert_e301453207482 : check e301453207482 [[],[]] .smaller = true := by decide
def e301453207510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e301453207510 : Closed e301453207510 ∧ code e301453207510 = 1400964835286 := by decide
theorem cert_e301453207510 : check e301453207510 [[],[]] .three = true := by decide
def e301453207514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e301453207514 : Closed e301453207514 ∧ code e301453207514 = 1400964835290 := by decide
theorem cert_e301453207514 : check e301453207514 [[],[]] .three = true := by decide
def e301453208030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e301453208030 : Closed e301453208030 ∧ code e301453208030 = 1400964835806 := by decide
theorem cert_e301453208030 : check e301453208030 [[],[]] .three = true := by decide
def e301453208046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e301453208046 : Closed e301453208046 ∧ code e301453208046 = 1400964835822 := by decide
theorem cert_e301453208046 : check e301453208046 [[],[]] .smaller = true := by decide
def e301453208054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e301453208054 : Closed e301453208054 ∧ code e301453208054 = 1400964835830 := by decide
theorem cert_e301453208054 : check e301453208054 [[],[]] .three = true := by decide
def e301453208798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e301453208798 : Closed e301453208798 ∧ code e301453208798 = 1400964836574 := by decide
theorem cert_e301453208798 : check e301453208798 [[],[]] .three = true := by decide
def e301453208826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e301453208826 : Closed e301453208826 ∧ code e301453208826 = 1400964836602 := by decide
theorem cert_e301453208826 : check e301453208826 [[],[]] .three = true := by decide
def e301453209198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e301453209198 : Closed e301453209198 ∧ code e301453209198 = 1400964836974 := by decide
theorem cert_e301453209198 : check e301453209198 [[],[]] .smaller = true := by decide
def e301453209210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e301453209210 : Closed e301453209210 ∧ code e301453209210 = 1400964836986 := by decide
theorem cert_e301453209210 : check e301453209210 [[],[]] .smaller = true := by decide
def e301453209398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e301453209398 : Closed e301453209398 ∧ code e301453209398 = 1400964837174 := by decide
theorem cert_e301453209398 : check e301453209398 [[],[]] .three = true := by decide
def e301453209402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e301453209402 : Closed e301453209402 ∧ code e301453209402 = 1400964837178 := by decide
theorem cert_e301453209402 : check e301453209402 [[],[]] .three = true := by decide
def e301453210462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e301453210462 : Closed e301453210462 ∧ code e301453210462 = 1400964838238 := by decide
theorem cert_e301453210462 : check e301453210462 [[],[]] .three = true := by decide
def e301453210478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e301453210478 : Closed e301453210478 ∧ code e301453210478 = 1400964838254 := by decide
theorem cert_e301453210478 : check e301453210478 [[],[]] .smaller = true := by decide
def e301453210486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e301453210486 : Closed e301453210486 ∧ code e301453210486 = 1400964838262 := by decide
theorem cert_e301453210486 : check e301453210486 [[],[]] .smaller = true := by decide
def e301453210490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e301453210490 : Closed e301453210490 ∧ code e301453210490 = 1400964838266 := by decide
theorem cert_e301453210490 : check e301453210490 [[],[]] .three = true := by decide
def e301453210542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e301453210542 : Closed e301453210542 ∧ code e301453210542 = 1400964838318 := by decide
theorem cert_e301453210542 : check e301453210542 [[],[]] .smaller = true := by decide
def e301453210554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e301453210554 : Closed e301453210554 ∧ code e301453210554 = 1400964838330 := by decide
theorem cert_e301453210554 : check e301453210554 [[],[]] .smaller = true := by decide
def e301453210582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e301453210582 : Closed e301453210582 ∧ code e301453210582 = 1400964838358 := by decide
theorem cert_e301453210582 : check e301453210582 [[],[]] .smaller = true := by decide
def e301453210586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e301453210586 : Closed e301453210586 ∧ code e301453210586 = 1400964838362 := by decide
theorem cert_e301453210586 : check e301453210586 [[],[]] .smaller = true := by decide
def e301453210602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e301453210602 : Closed e301453210602 ∧ code e301453210602 = 1400964838378 := by decide
theorem cert_e301453210602 : check e301453210602 [[],[]] .three = true := by decide
def e301453210846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e301453210846 : Closed e301453210846 ∧ code e301453210846 = 1400964838622 := by decide
theorem cert_e301453210846 : check e301453210846 [[],[]] .three = true := by decide
def e301453210862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e301453210862 : Closed e301453210862 ∧ code e301453210862 = 1400964838638 := by decide
theorem cert_e301453210862 : check e301453210862 [[],[]] .smaller = true := by decide
def e301453210870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e301453210870 : Closed e301453210870 ∧ code e301453210870 = 1400964838646 := by decide
theorem cert_e301453210870 : check e301453210870 [[],[]] .smaller = true := by decide
def e301453210874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e301453210874 : Closed e301453210874 ∧ code e301453210874 = 1400964838650 := by decide
theorem cert_e301453210874 : check e301453210874 [[],[]] .three = true := by decide
def e301453211246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e301453211246 : Closed e301453211246 ∧ code e301453211246 = 1400964839022 := by decide
theorem cert_e301453211246 : check e301453211246 [[],[]] .smaller = true := by decide
def e301453211258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e301453211258 : Closed e301453211258 ∧ code e301453211258 = 1400964839034 := by decide
theorem cert_e301453211258 : check e301453211258 [[],[]] .smaller = true := by decide
def e301453211446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e301453211446 : Closed e301453211446 ∧ code e301453211446 = 1400964839222 := by decide
theorem cert_e301453211446 : check e301453211446 [[],[]] .smaller = true := by decide
def e301453211450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e301453211450 : Closed e301453211450 ∧ code e301453211450 = 1400964839226 := by decide
theorem cert_e301453211450 : check e301453211450 [[],[]] .smaller = true := by decide
def e301453211546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e301453211546 : Closed e301453211546 ∧ code e301453211546 = 1400964839322 := by decide
theorem cert_e301453211546 : check e301453211546 [[],[]] .three = true := by decide
def e301453212078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e301453212078 : Closed e301453212078 ∧ code e301453212078 = 1400964839854 := by decide
theorem cert_e301453212078 : check e301453212078 [[],[]] .three = true := by decide
def e301453212086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e301453212086 : Closed e301453212086 ∧ code e301453212086 = 1400964839862 := by decide
theorem cert_e301453212086 : check e301453212086 [[],[]] .three = true := by decide
def e301453212090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e301453212090 : Closed e301453212090 ∧ code e301453212090 = 1400964839866 := by decide
theorem cert_e301453212090 : check e301453212090 [[],[]] .three = true := by decide
def e301453212118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e301453212118 : Closed e301453212118 ∧ code e301453212118 = 1400964839894 := by decide
theorem cert_e301453212118 : check e301453212118 [[],[]] .three = true := by decide
def e301453212122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e301453212122 : Closed e301453212122 ∧ code e301453212122 = 1400964839898 := by decide
theorem cert_e301453212122 : check e301453212122 [[],[]] .three = true := by decide
def e301453212138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e301453212138 : Closed e301453212138 ∧ code e301453212138 = 1400964839914 := by decide
theorem cert_e301453212138 : check e301453212138 [[],[]] .three = true := by decide
end Blc.Floor40
