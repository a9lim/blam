import R302902171894Data
namespace Certgen.R302902171894
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl1944 : FloorIndex.rangeOK validState 1944 12 = true := by decide +kernel
theorem bl1956 : FloorIndex.rangeOK validState 1956 12 = true := by decide +kernel
theorem bl1968 : FloorIndex.rangeOK validState 1968 1 = true := by decide +kernel
end Certgen.R302902171894
