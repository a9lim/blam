from regular40 import *
import regular40
old=probeType
def new(e,kind):
    if kind=='bottom1':return A(e,om)
    if kind=='rigid1':return A(e,V(0))
    if kind=='proj1':return A(e,KI)
    if kind=='delta1':return A(e,om[1])
    if kind=='id1':return A(e,I)
    return old(e,kind)
regular40.probeType=new
cfg=[(k,mode) for k in range(6) for mode in ['site','lambda','arg','argenv','env']]
for s in (HERE/'open.txt').read_text().split():
    pr=HERE/('r'+str(int(s,2))+'.json')
    if pr.exists():continue
    r=find(s,cfg,[(x,j) for j in [0,1,3,5] for x in ['bottom1','rigid1','proj1','delta1','id1','extra2','extra3']])
    if r:pr.write_text(json.dumps(r));print(s,r[:5],flush=True)
    else:print(s,'open',flush=True)
