from candidates import *
from genlean import expr,paths
from smart_probe import weak_path
sys.path.insert(0,str(ROOT/'data/self-interpreter/reasoning_weight/archive/certgen'))
import regular,portable
om=A(L(A(V(0),V(0))),L(A(V(0),V(0))))
C=V(1);R=V(0)
def mask(t,d=0):
    if t[0]=='V':return t if t[1]<d else ('C',t[1])
    if t[0]=='L':return L(mask(t[1],d+1))
    return A(mask(t[1],d),mask(t[2],d))
def probeType(e,kind):
    # Each term has a normal form if e is an interpreter.
    if kind=='raw':return e # only weak-head clock
    if kind=='rigid':return A(A(e,C),lc.bitlist('0010',R))
    if kind=='generic':return A(A(e,C),R) # only when stuck placeholders? DO NOT USE
    if kind=='suffix':return A(A(e,KI),lc.bitlist('0010',R))
    if kind=='poison':return A(A(e,L(L(I))),lc.bitlist('0010',om))
    if kind=='ignore':return A(A(e,L(L(R))),lc.bitlist('0010',om)) # unused
    if kind=='value':return A(A(e,L(L(V(1)))),lc.bitlist('0010',om))
    if kind=='apply':return A(A(A(A(e,L(L(V(1)))),lc.bitlist('0010',om)),om),I)
    if kind.startswith('extra'):
        t=probeType(e,'suffix')
        for _ in range(int(kind[5:])):t=A(t,om)
        return t # target R applied to omegas has a clock; need direct weak-head solution
    raise AssertionError()
def find(s,configs,opts):
    e=lc.decode(s)[0];best=None
    for k,mode in configs:
        for kind,j in opts:
            t=probeType(e,kind);ps=[]
            for _ in range(j):
                p=weak_path(t)
                if p is None:break
                t=bounded(t,p)
                if t is None:break
                ps.append(p)
            if t is None or len(ps)!=j:continue
            try:r=regular.discover(mask(t),k,cap=4500,seconds=.12,mode=mode)
            except regular.Limit:continue
            if r['ok'] and r['states']<800:
                c=portable.portable(r);score=len(c['states'])
                if best is None or score<best[0]:best=(score,kind,j,k,mode,ps,c)
                if score<165:return best
        if best:return best
    return best
def run():
    cfg=[(0,'site'),(1,'lambda'),(1,'site'),(1,'arg'),(2,'argenv'),(2,'site'),(2,'lambda'),(3,'arg'),(3,'argenv'),(4,'site')]
    for s in (HERE/'open.txt').read_text().split():
        pr=HERE/('r'+str(int(s,2))+'.json')
        if pr.exists():continue
        r=find(s,cfg,[(x,j) for j in [0,2] for x in ['raw','rigid','suffix','poison','value','apply','extra1']])
        if r:
            pr.write_text(json.dumps(r));print(s,r[:5],flush=True)
        else:print(s,'open',flush=True)
if __name__=='__main__':run()
