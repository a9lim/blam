import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e350578242402 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350578242402 : Closed e350578242402 ∧ code e350578242402 = 1450089870178 := by decide
theorem cert_e350578242402 : check e350578242402 [[.left],[.left]] .chain = true := by decide
def e350578242466 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.var 0)))
theorem wire_e350578242466 : Closed e350578242466 ∧ code e350578242466 = 1450089870242 := by decide
theorem cert_e350578242466 : check e350578242466 [[.left],[.left]] .chain = true := by decide
def e350578252642 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e350578252642 : Closed e350578252642 ∧ code e350578252642 = 1450089880418 := by decide
theorem cert_e350578252642 : check e350578252642 [[.left],[.left]] .chain = true := by decide
def e350578253154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.var 0)))
theorem wire_e350578253154 : Closed e350578253154 ∧ code e350578253154 = 1450089880930 := by decide
theorem cert_e350578253154 : check e350578253154 [[.left],[.left]] .chain = true := by decide
def e350578253218 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.var 0)))
theorem wire_e350578253218 : Closed e350578253218 ∧ code e350578253218 = 1450089880994 := by decide
theorem cert_e350578253218 : check e350578253218 [[.left],[.left]] .chain = true := by decide
def e350578255714 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350578255714 : Closed e350578255714 ∧ code e350578255714 = 1450089883490 := by decide
theorem cert_e350578255714 : check e350578255714 [[.left],[.left]] .chain = true := by decide
def e350578258786 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350578258786 : Closed e350578258786 ∧ code e350578258786 = 1450089886562 := by decide
theorem cert_e350578258786 : check e350578258786 [[.left],[.left]] .chain = true := by decide
def e350578258850 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.var 0)))
theorem wire_e350578258850 : Closed e350578258850 ∧ code e350578258850 = 1450089886626 := by decide
theorem cert_e350578258850 : check e350578258850 [[.left],[.left]] .chain = true := by decide
def e350578374370 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e350578374370 : Closed e350578374370 ∧ code e350578374370 = 1450090002146 := by decide
theorem cert_e350578374370 : check e350578374370 [[.left],[.left]] .chain = true := by decide
def e350578374498 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350578374498 : Closed e350578374498 ∧ code e350578374498 = 1450090002274 := by decide
theorem cert_e350578374498 : check e350578374498 [[.left],[.left]] .chain = true := by decide
def e350578375522 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350578375522 : Closed e350578375522 ∧ code e350578375522 = 1450090003298 := by decide
theorem cert_e350578375522 : check e350578375522 [[.left],[.left]] .chain = true := by decide
def e350578396898 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e350578396898 : Closed e350578396898 ∧ code e350578396898 = 1450090024674 := by decide
theorem cert_e350578396898 : check e350578396898 [[.left],[.left]] .chain = true := by decide
def e350578397026 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e350578397026 : Closed e350578397026 ∧ code e350578397026 = 1450090024802 := by decide
theorem cert_e350578397026 : check e350578397026 [[.left],[.left]] .chain = true := by decide
def e350578403170 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e350578403170 : Closed e350578403170 ∧ code e350578403170 = 1450090030946 := by decide
theorem cert_e350578403170 : check e350578403170 [[.left],[.left]] .chain = true := by decide
def e350578587362 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e350578587362 : Closed e350578587362 ∧ code e350578587362 = 1450090215138 := by decide
theorem cert_e350578587362 : check e350578587362 [[.left],[.left]] .chain = true := by decide
def e350578587490 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350578587490 : Closed e350578587490 ∧ code e350578587490 = 1450090215266 := by decide
theorem cert_e350578587490 : check e350578587490 [[.left],[.left]] .chain = true := by decide
def e350578588386 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e350578588386 : Closed e350578588386 ∧ code e350578588386 = 1450090216162 := by decide
theorem cert_e350578588386 : check e350578588386 [[.left],[.left]] .chain = true := by decide
def e350578588578 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e350578588578 : Closed e350578588578 ∧ code e350578588578 = 1450090216354 := by decide
theorem cert_e350578588578 : check e350578588578 [[.left],[.left]] .chain = true := by decide
def e350578589026 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350578589026 : Closed e350578589026 ∧ code e350578589026 = 1450090216802 := by decide
theorem cert_e350578589026 : check e350578589026 [[.left],[.left]] .chain = true := by decide
def e350578589090 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e350578589090 : Closed e350578589090 ∧ code e350578589090 = 1450090216866 := by decide
theorem cert_e350578589090 : check e350578589090 [[.left],[.left]] .chain = true := by decide
def e350578593506 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e350578593506 : Closed e350578593506 ∧ code e350578593506 = 1450090221282 := by decide
theorem cert_e350578593506 : check e350578593506 [[.left],[.left]] .chain = true := by decide
def e350578593634 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e350578593634 : Closed e350578593634 ∧ code e350578593634 = 1450090221410 := by decide
theorem cert_e350578593634 : check e350578593634 [[.left],[.left]] .chain = true := by decide
def e350578599650 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e350578599650 : Closed e350578599650 ∧ code e350578599650 = 1450090227426 := by decide
theorem cert_e350578599650 : check e350578599650 [[.left],[.left]] .chain = true := by decide
def e350578599842 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e350578599842 : Closed e350578599842 ∧ code e350578599842 = 1450090227618 := by decide
theorem cert_e350578599842 : check e350578599842 [[.left],[.left]] .chain = true := by decide
def e350578602850 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e350578602850 : Closed e350578602850 ∧ code e350578602850 = 1450090230626 := by decide
theorem cert_e350578602850 : check e350578602850 [[.left],[.left]] .chain = true := by decide
def e350578602914 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e350578602914 : Closed e350578602914 ∧ code e350578602914 = 1450090230690 := by decide
theorem cert_e350578602914 : check e350578602914 [[.left],[.left]] .chain = true := by decide
def e350578695010 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350578695010 : Closed e350578695010 ∧ code e350578695010 = 1450090322786 := by decide
theorem cert_e350578695010 : check e350578695010 [[.left],[.left]] .chain = true := by decide
def e350578695522 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350578695522 : Closed e350578695522 ∧ code e350578695522 = 1450090323298 := by decide
theorem cert_e350578695522 : check e350578695522 [[.left],[.left]] .chain = true := by decide
def e350578695586 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e350578695586 : Closed e350578695586 ∧ code e350578695586 = 1450090323362 := by decide
theorem cert_e350578695586 : check e350578695586 [[.left],[.left]] .chain = true := by decide
def e350578698082 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e350578698082 : Closed e350578698082 ∧ code e350578698082 = 1450090325858 := by decide
theorem cert_e350578698082 : check e350578698082 [[.left],[.left]] .chain = true := by decide
def e350578701154 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e350578701154 : Closed e350578701154 ∧ code e350578701154 = 1450090328930 := by decide
theorem cert_e350578701154 : check e350578701154 [[.left],[.left]] .chain = true := by decide
def e350578701218 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e350578701218 : Closed e350578701218 ∧ code e350578701218 = 1450090328994 := by decide
theorem cert_e350578701218 : check e350578701218 [[.left],[.left]] .chain = true := by decide
def e350584092386 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e350584092386 : Closed e350584092386 ∧ code e350584092386 = 1450095720162 := by decide
theorem cert_e350584092386 : check e350584092386 [[.left],[.left],[],[],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e350584092514 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350584092514 : Closed e350584092514 ∧ code e350584092514 = 1450095720290 := by decide
private def t_e350584092514 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.var 0)))
theorem cert_e350584092514 : ¬ IsSelfInterpreter e350584092514 :=
  wSource (t := t_e350584092514) (replay_sound (ps := []) (t := e350584092514) (by decide)) (by decide)
def e350584093410 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.var 0)))
theorem wire_e350584093410 : Closed e350584093410 ∧ code e350584093410 = 1450095721186 := by decide
theorem cert_e350584093410 : check e350584093410 [[.left],[.left],[],[],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e350584093602 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e350584093602 : Closed e350584093602 ∧ code e350584093602 = 1450095721378 := by decide
theorem cert_e350584093602 : checkPay e350584093602 [[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[]] 0 [[.under,.left],[.under]] = true := by decide
def e350584094050 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem wire_e350584094050 : Closed e350584094050 ∧ code e350584094050 = 1450095721826 := by decide
private def t_e350584094050 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.var 0)))
theorem cert_e350584094050 : ¬ IsSelfInterpreter e350584094050 :=
  wSource (t := t_e350584094050) (replay_sound (ps := []) (t := e350584094050) (by decide)) (by decide)
def e350584094114 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.var 0)))
theorem wire_e350584094114 : Closed e350584094114 ∧ code e350584094114 = 1450095721890 := by decide
theorem cert_e350584094114 : check e350584094114 [[.left],[.left],[],[],[.under],[.under,.left]] .chain = true := by decide
def e350584098530 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e350584098530 : Closed e350584098530 ∧ code e350584098530 = 1450095726306 := by decide
theorem cert_e350584098530 : checkPay e350584098530 [[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left],[]] 0 [[.under,.right]] = true := by decide
def e350584098658 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e350584098658 : Closed e350584098658 ∧ code e350584098658 = 1450095726434 := by decide
theorem cert_e350584098658 : check e350584098658 [[.left],[.left],[],[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e350584104674 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.var 0)))
theorem wire_e350584104674 : Closed e350584104674 ∧ code e350584104674 = 1450095732450 := by decide
theorem cert_e350584104674 : check e350584104674 [[.left],[.left],[],[],[.under],[.under],[.under]] .sourceHead = true := by decide
def e350584104866 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e350584104866 : Closed e350584104866 ∧ code e350584104866 = 1450095732642 := by decide
theorem cert_e350584104866 : check e350584104866 [[.left],[.left],[],[],[.under],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e350584107874 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.var 0)))
theorem wire_e350584107874 : Closed e350584107874 ∧ code e350584107874 = 1450095735650 := by decide
theorem cert_e350584107874 : check e350584107874 [[.left],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e350584107938 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.var 0)))
theorem wire_e350584107938 : Closed e350584107938 ∧ code e350584107938 = 1450095735714 := by decide
theorem cert_e350584107938 : check e350584107938 [[.left],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
end Blc.Floor40
