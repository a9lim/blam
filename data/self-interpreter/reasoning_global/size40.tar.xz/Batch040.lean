import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302800801242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e302800801242 : Closed e302800801242 ∧ code e302800801242 = 1402312429018 := by decide
theorem cert_e302800801242 : check e302800801242 [[],[]] .chain = true := by decide
def e302800801454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e302800801454 : Closed e302800801454 ∧ code e302800801454 = 1402312429230 := by decide
theorem cert_e302800801454 : check e302800801454 [[],[]] .chain = true := by decide
def e302800801466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e302800801466 : Closed e302800801466 ∧ code e302800801466 = 1402312429242 := by decide
theorem cert_e302800801466 : check e302800801466 [[],[]] .chain = true := by decide
def e302800801514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e302800801514 : Closed e302800801514 ∧ code e302800801514 = 1402312429290 := by decide
theorem cert_e302800801514 : check e302800801514 [[],[]] .chain = true := by decide
def e302800801622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e302800801622 : Closed e302800801622 ∧ code e302800801622 = 1402312429398 := by decide
theorem cert_e302800801622 : check e302800801622 [[],[]] .chain = true := by decide
def e302800801626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e302800801626 : Closed e302800801626 ∧ code e302800801626 = 1402312429402 := by decide
theorem cert_e302800801626 : check e302800801626 [[],[]] .chain = true := by decide
def e302800801642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e302800801642 : Closed e302800801642 ∧ code e302800801642 = 1402312429418 := by decide
theorem cert_e302800801642 : check e302800801642 [[],[]] .chain = true := by decide
def e302800806766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e302800806766 : Closed e302800806766 ∧ code e302800806766 = 1402312434542 := by decide
theorem cert_e302800806766 : check e302800806766 [[],[]] .chain = true := by decide
def e302800806774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e302800806774 : Closed e302800806774 ∧ code e302800806774 = 1402312434550 := by decide
theorem cert_e302800806774 : check e302800806774 [[],[]] .chain = true := by decide
def e302800806830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e302800806830 : Closed e302800806830 ∧ code e302800806830 = 1402312434606 := by decide
theorem cert_e302800806830 : check e302800806830 [[],[]] .chain = true := by decide
def e302800806842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e302800806842 : Closed e302800806842 ∧ code e302800806842 = 1402312434618 := by decide
theorem cert_e302800806842 : check e302800806842 [[],[]] .chain = true := by decide
def e302800806870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e302800806870 : Closed e302800806870 ∧ code e302800806870 = 1402312434646 := by decide
theorem cert_e302800806870 : check e302800806870 [[],[]] .chain = true := by decide
def e302800806874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e302800806874 : Closed e302800806874 ∧ code e302800806874 = 1402312434650 := by decide
theorem cert_e302800806874 : check e302800806874 [[],[]] .chain = true := by decide
def e302800808174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e302800808174 : Closed e302800808174 ∧ code e302800808174 = 1402312435950 := by decide
theorem cert_e302800808174 : check e302800808174 [[],[]] .chain = true := by decide
def e302800808182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e302800808182 : Closed e302800808182 ∧ code e302800808182 = 1402312435958 := by decide
theorem cert_e302800808182 : check e302800808182 [[],[]] .chain = true := by decide
def e302800808734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e302800808734 : Closed e302800808734 ∧ code e302800808734 = 1402312436510 := by decide
theorem cert_e302800808734 : check e302800808734 [[],[]] .chain = true := by decide
def e302800808846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e302800808846 : Closed e302800808846 ∧ code e302800808846 = 1402312436622 := by decide
theorem cert_e302800808846 : check e302800808846 [[],[]] .chain = true := by decide
def e302800809070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e302800809070 : Closed e302800809070 ∧ code e302800809070 = 1402312436846 := by decide
theorem cert_e302800809070 : check e302800809070 [[],[]] .chain = true := by decide
def e302800809082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e302800809082 : Closed e302800809082 ∧ code e302800809082 = 1402312436858 := by decide
theorem cert_e302800809082 : check e302800809082 [[],[]] .chain = true := by decide
def e302800809246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e302800809246 : Closed e302800809246 ∧ code e302800809246 = 1402312437022 := by decide
theorem cert_e302800809246 : check e302800809246 [[],[]] .chain = true := by decide
def e302800809414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e302800809414 : Closed e302800809414 ∧ code e302800809414 = 1402312437190 := by decide
theorem cert_e302800809414 : check e302800809414 [[],[]] .chain = true := by decide
def e302800809526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e302800809526 : Closed e302800809526 ∧ code e302800809526 = 1402312437302 := by decide
theorem cert_e302800809526 : check e302800809526 [[],[]] .chain = true := by decide
def e302800809530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e302800809530 : Closed e302800809530 ∧ code e302800809530 = 1402312437306 := by decide
theorem cert_e302800809530 : check e302800809530 [[],[]] .chain = true := by decide
def e302800809614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e302800809614 : Closed e302800809614 ∧ code e302800809614 = 1402312437390 := by decide
theorem cert_e302800809614 : check e302800809614 [[],[]] .chain = true := by decide
def e302800809670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e302800809670 : Closed e302800809670 ∧ code e302800809670 = 1402312437446 := by decide
theorem cert_e302800809670 : check e302800809670 [[],[]] .chain = true := by decide
def e302800810350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e302800810350 : Closed e302800810350 ∧ code e302800810350 = 1402312438126 := by decide
theorem cert_e302800810350 : check e302800810350 [[],[]] .chain = true := by decide
def e302800810358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e302800810358 : Closed e302800810358 ∧ code e302800810358 = 1402312438134 := by decide
theorem cert_e302800810358 : check e302800810358 [[],[]] .chain = true := by decide
def e302800810414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e302800810414 : Closed e302800810414 ∧ code e302800810414 = 1402312438190 := by decide
theorem cert_e302800810414 : check e302800810414 [[],[]] .chain = true := by decide
def e302800810426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e302800810426 : Closed e302800810426 ∧ code e302800810426 = 1402312438202 := by decide
theorem cert_e302800810426 : check e302800810426 [[],[]] .chain = true := by decide
def e302800810474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e302800810474 : Closed e302800810474 ∧ code e302800810474 = 1402312438250 := by decide
theorem cert_e302800810474 : check e302800810474 [[],[]] .chain = true := by decide
def e302800811118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e302800811118 : Closed e302800811118 ∧ code e302800811118 = 1402312438894 := by decide
theorem cert_e302800811118 : check e302800811118 [[],[]] .chain = true := by decide
def e302800811130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e302800811130 : Closed e302800811130 ∧ code e302800811130 = 1402312438906 := by decide
theorem cert_e302800811130 : check e302800811130 [[],[]] .chain = true := by decide
def e302800811294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e302800811294 : Closed e302800811294 ∧ code e302800811294 = 1402312439070 := by decide
theorem cert_e302800811294 : check e302800811294 [[],[]] .chain = true := by decide
def e302800811462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e302800811462 : Closed e302800811462 ∧ code e302800811462 = 1402312439238 := by decide
theorem cert_e302800811462 : check e302800811462 [[],[]] .chain = true := by decide
def e302800811566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e302800811566 : Closed e302800811566 ∧ code e302800811566 = 1402312439342 := by decide
theorem cert_e302800811566 : check e302800811566 [[],[]] .chain = true := by decide
def e302800811746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e302800811746 : Closed e302800811746 ∧ code e302800811746 = 1402312439522 := by decide
theorem cert_e302800811746 : check e302800811746 [[],[]] .chain = true := by decide
def e302800811758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e302800811758 : Closed e302800811758 ∧ code e302800811758 = 1402312439534 := by decide
theorem cert_e302800811758 : check e302800811758 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e302800811798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e302800811798 : Closed e302800811798 ∧ code e302800811798 = 1402312439574 := by decide
theorem cert_e302800811798 : check e302800811798 [[],[]] .chain = true := by decide
def e302800811802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e302800811802 : Closed e302800811802 ∧ code e302800811802 = 1402312439578 := by decide
theorem cert_e302800811802 : check e302800811802 [[],[]] .chain = true := by decide
def e302800811846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302800811846 : Closed e302800811846 ∧ code e302800811846 = 1402312439622 := by decide
theorem cert_e302800811846 : check e302800811846 [[],[]] .chain = true := by decide
def e302800811874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e302800811874 : Closed e302800811874 ∧ code e302800811874 = 1402312439650 := by decide
theorem cert_e302800811874 : check e302800811874 [[],[]] .chain = true := by decide
def e302800811886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e302800811886 : Closed e302800811886 ∧ code e302800811886 = 1402312439662 := by decide
theorem cert_e302800811886 : check e302800811886 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e302800811894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e302800811894 : Closed e302800811894 ∧ code e302800811894 = 1402312439670 := by decide
theorem cert_e302800811894 : check e302800811894 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e302800812214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e302800812214 : Closed e302800812214 ∧ code e302800812214 = 1402312439990 := by decide
theorem cert_e302800812214 : check e302800812214 [[],[]] .chain = true := by decide
def e302800812246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e302800812246 : Closed e302800812246 ∧ code e302800812246 = 1402312440022 := by decide
theorem cert_e302800812246 : check e302800812246 [[],[]] .chain = true := by decide
def e302800812250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e302800812250 : Closed e302800812250 ∧ code e302800812250 = 1402312440026 := by decide
theorem cert_e302800812250 : check e302800812250 [[],[]] .chain = true := by decide
def e302800812266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e302800812266 : Closed e302800812266 ∧ code e302800812266 = 1402312440042 := by decide
theorem cert_e302800812266 : check e302800812266 [[],[]] .chain = true := by decide
def e302800812598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e302800812598 : Closed e302800812598 ∧ code e302800812598 = 1402312440374 := by decide
theorem cert_e302800812598 : check e302800812598 [[],[]] .chain = true := by decide
def e302800812602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e302800812602 : Closed e302800812602 ∧ code e302800812602 = 1402312440378 := by decide
theorem cert_e302800812602 : check e302800812602 [[],[]] .chain = true := by decide
def e302800812686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e302800812686 : Closed e302800812686 ∧ code e302800812686 = 1402312440462 := by decide
theorem cert_e302800812686 : check e302800812686 [[],[]] .chain = true := by decide
def e302800812742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e302800812742 : Closed e302800812742 ∧ code e302800812742 = 1402312440518 := by decide
theorem cert_e302800812742 : check e302800812742 [[],[]] .chain = true := by decide
def e302800812822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 1))))))
theorem wire_e302800812822 : Closed e302800812822 ∧ code e302800812822 = 1402312440598 := by decide
theorem cert_e302800812822 : check e302800812822 [[],[]] .chain = true := by decide
def e302800812826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e302800812826 : Closed e302800812826 ∧ code e302800812826 = 1402312440602 := by decide
theorem cert_e302800812826 : check e302800812826 [[],[]] .chain = true := by decide
def e302800812870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302800812870 : Closed e302800812870 ∧ code e302800812870 = 1402312440646 := by decide
theorem cert_e302800812870 : check e302800812870 [[],[]] .chain = true := by decide
def e302800812898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e302800812898 : Closed e302800812898 ∧ code e302800812898 = 1402312440674 := by decide
theorem cert_e302800812898 : check e302800812898 [[],[]] .chain = true := by decide
def e302800812910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e302800812910 : Closed e302800812910 ∧ code e302800812910 = 1402312440686 := by decide
theorem cert_e302800812910 : check e302800812910 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302800812918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e302800812918 : Closed e302800812918 ∧ code e302800812918 = 1402312440694 := by decide
theorem cert_e302800812918 : check e302800812918 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302800812982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e302800812982 : Closed e302800812982 ∧ code e302800812982 = 1402312440758 := by decide
theorem cert_e302800812982 : check e302800812982 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302800815470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e302800815470 : Closed e302800815470 ∧ code e302800815470 = 1402312443246 := by decide
theorem cert_e302800815470 : check e302800815470 [[],[]] .chain = true := by decide
def e302800815478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e302800815478 : Closed e302800815478 ∧ code e302800815478 = 1402312443254 := by decide
theorem cert_e302800815478 : check e302800815478 [[],[]] .chain = true := by decide
def e302800815534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e302800815534 : Closed e302800815534 ∧ code e302800815534 = 1402312443310 := by decide
theorem cert_e302800815534 : check e302800815534 [[],[]] .chain = true := by decide
def e302800815546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e302800815546 : Closed e302800815546 ∧ code e302800815546 = 1402312443322 := by decide
theorem cert_e302800815546 : check e302800815546 [[],[]] .chain = true := by decide
def e302800815574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e302800815574 : Closed e302800815574 ∧ code e302800815574 = 1402312443350 := by decide
theorem cert_e302800815574 : check e302800815574 [[],[]] .chain = true := by decide
def e302800815578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e302800815578 : Closed e302800815578 ∧ code e302800815578 = 1402312443354 := by decide
theorem cert_e302800815578 : check e302800815578 [[],[]] .chain = true := by decide
def e302800815790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e302800815790 : Closed e302800815790 ∧ code e302800815790 = 1402312443566 := by decide
theorem cert_e302800815790 : check e302800815790 [[],[]] .chain = true := by decide
def e302800815802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e302800815802 : Closed e302800815802 ∧ code e302800815802 = 1402312443578 := by decide
theorem cert_e302800815802 : check e302800815802 [[],[]] .chain = true := by decide
def e302800815850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e302800815850 : Closed e302800815850 ∧ code e302800815850 = 1402312443626 := by decide
theorem cert_e302800815850 : check e302800815850 [[],[]] .chain = true := by decide
def e302800816042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e302800816042 : Closed e302800816042 ∧ code e302800816042 = 1402312443818 := by decide
theorem cert_e302800816042 : check e302800816042 [[],[]] .chain = true := by decide
def e302800818542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e302800818542 : Closed e302800818542 ∧ code e302800818542 = 1402312446318 := by decide
theorem cert_e302800818542 : check e302800818542 [[],[]] .chain = true := by decide
def e302800818550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e302800818550 : Closed e302800818550 ∧ code e302800818550 = 1402312446326 := by decide
theorem cert_e302800818550 : check e302800818550 [[],[]] .chain = true := by decide
def e302800818606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e302800818606 : Closed e302800818606 ∧ code e302800818606 = 1402312446382 := by decide
theorem cert_e302800818606 : check e302800818606 [[],[]] .chain = true := by decide
def e302800818618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e302800818618 : Closed e302800818618 ∧ code e302800818618 = 1402312446394 := by decide
theorem cert_e302800818618 : check e302800818618 [[],[]] .chain = true := by decide
def e302800818666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e302800818666 : Closed e302800818666 ∧ code e302800818666 = 1402312446442 := by decide
theorem cert_e302800818666 : check e302800818666 [[],[]] .chain = true := by decide
def e302800819310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e302800819310 : Closed e302800819310 ∧ code e302800819310 = 1402312447086 := by decide
theorem cert_e302800819310 : check e302800819310 [[],[]] .chain = true := by decide
def e302800819322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e302800819322 : Closed e302800819322 ∧ code e302800819322 = 1402312447098 := by decide
theorem cert_e302800819322 : check e302800819322 [[],[]] .chain = true := by decide
def e302800819486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e302800819486 : Closed e302800819486 ∧ code e302800819486 = 1402312447262 := by decide
theorem cert_e302800819486 : check e302800819486 [[],[]] .chain = true := by decide
def e302800819654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e302800819654 : Closed e302800819654 ∧ code e302800819654 = 1402312447430 := by decide
theorem cert_e302800819654 : check e302800819654 [[],[]] .chain = true := by decide
def e302800819758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e302800819758 : Closed e302800819758 ∧ code e302800819758 = 1402312447534 := by decide
theorem cert_e302800819758 : check e302800819758 [[],[]] .chain = true := by decide
def e302800819938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e302800819938 : Closed e302800819938 ∧ code e302800819938 = 1402312447714 := by decide
theorem cert_e302800819938 : check e302800819938 [[],[]] .chain = true := by decide
def e302800819950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e302800819950 : Closed e302800819950 ∧ code e302800819950 = 1402312447726 := by decide
theorem cert_e302800819950 : check e302800819950 [[],[]] .sourceHead = true := by decide
def e302800819990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e302800819990 : Closed e302800819990 ∧ code e302800819990 = 1402312447766 := by decide
theorem cert_e302800819990 : check e302800819990 [[],[]] .chain = true := by decide
def e302800819994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e302800819994 : Closed e302800819994 ∧ code e302800819994 = 1402312447770 := by decide
theorem cert_e302800819994 : check e302800819994 [[],[]] .chain = true := by decide
def e302800820038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302800820038 : Closed e302800820038 ∧ code e302800820038 = 1402312447814 := by decide
theorem cert_e302800820038 : check e302800820038 [[],[]] .chain = true := by decide
def e302800820066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e302800820066 : Closed e302800820066 ∧ code e302800820066 = 1402312447842 := by decide
theorem cert_e302800820066 : check e302800820066 [[],[]] .chain = true := by decide
def e302800820078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e302800820078 : Closed e302800820078 ∧ code e302800820078 = 1402312447854 := by decide
theorem cert_e302800820078 : check e302800820078 [[],[]] .sourceHead = true := by decide
def e302800820086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e302800820086 : Closed e302800820086 ∧ code e302800820086 = 1402312447862 := by decide
theorem cert_e302800820086 : check e302800820086 [[],[]] .sourceHead = true := by decide
def e302800820398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e302800820398 : Closed e302800820398 ∧ code e302800820398 = 1402312448174 := by decide
theorem cert_e302800820398 : check e302800820398 [[],[]] .chain = true := by decide
def e302800820410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e302800820410 : Closed e302800820410 ∧ code e302800820410 = 1402312448186 := by decide
theorem cert_e302800820410 : check e302800820410 [[],[]] .chain = true := by decide
def e302800820782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e302800820782 : Closed e302800820782 ∧ code e302800820782 = 1402312448558 := by decide
theorem cert_e302800820782 : check e302800820782 [[],[]] .chain = true := by decide
def e302800820962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e302800820962 : Closed e302800820962 ∧ code e302800820962 = 1402312448738 := by decide
theorem cert_e302800820962 : check e302800820962 [[],[]] .chain = true := by decide
def e302800820974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e302800820974 : Closed e302800820974 ∧ code e302800820974 = 1402312448750 := by decide
theorem cert_e302800820974 : check e302800820974 [[],[]] .sourceHead = true := by decide
def e302800821130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e302800821130 : Closed e302800821130 ∧ code e302800821130 = 1402312448906 := by decide
theorem cert_e302800821130 : check e302800821130 [[],[]] .chain = true := by decide
def e302800821154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e302800821154 : Closed e302800821154 ∧ code e302800821154 = 1402312448930 := by decide
theorem cert_e302800821154 : check e302800821154 [[],[]] .chain = true := by decide
def e302800821166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e302800821166 : Closed e302800821166 ∧ code e302800821166 = 1402312448942 := by decide
theorem cert_e302800821166 : check e302800821166 [[],[]] .sourceHead = true := by decide
def e302800821178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e302800821178 : Closed e302800821178 ∧ code e302800821178 = 1402312448954 := by decide
theorem cert_e302800821178 : check e302800821178 [[],[]] .sourceHead = true := by decide
def e302800821334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e302800821334 : Closed e302800821334 ∧ code e302800821334 = 1402312449110 := by decide
theorem cert_e302800821334 : check e302800821334 [[],[]] .chain = true := by decide
def e302800821338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e302800821338 : Closed e302800821338 ∧ code e302800821338 = 1402312449114 := by decide
theorem cert_e302800821338 : check e302800821338 [[],[]] .chain = true := by decide
def e302800821354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e302800821354 : Closed e302800821354 ∧ code e302800821354 = 1402312449130 := by decide
theorem cert_e302800821354 : check e302800821354 [[],[]] .chain = true := by decide
def e302800821526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e302800821526 : Closed e302800821526 ∧ code e302800821526 = 1402312449302 := by decide
theorem cert_e302800821526 : check e302800821526 [[],[]] .chain = true := by decide
def e302800821530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))) (.var 0))))))
theorem wire_e302800821530 : Closed e302800821530 ∧ code e302800821530 = 1402312449306 := by decide
theorem cert_e302800821530 : check e302800821530 [[],[]] .chain = true := by decide
def e302800821574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302800821574 : Closed e302800821574 ∧ code e302800821574 = 1402312449350 := by decide
theorem cert_e302800821574 : check e302800821574 [[],[]] .chain = true := by decide
def e302800821602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e302800821602 : Closed e302800821602 ∧ code e302800821602 = 1402312449378 := by decide
theorem cert_e302800821602 : check e302800821602 [[],[]] .chain = true := by decide
def e302800821614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e302800821614 : Closed e302800821614 ∧ code e302800821614 = 1402312449390 := by decide
theorem cert_e302800821614 : check e302800821614 [[],[]] .sourceHead = true := by decide
def e302800821622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e302800821622 : Closed e302800821622 ∧ code e302800821622 = 1402312449398 := by decide
theorem cert_e302800821622 : check e302800821622 [[],[]] .sourceHead = true := by decide
def e302800821642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e302800821642 : Closed e302800821642 ∧ code e302800821642 = 1402312449418 := by decide
theorem cert_e302800821642 : check e302800821642 [[],[]] .chain = true := by decide
def e302800821666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e302800821666 : Closed e302800821666 ∧ code e302800821666 = 1402312449442 := by decide
theorem cert_e302800821666 : check e302800821666 [[],[]] .chain = true := by decide
def e302800821678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e302800821678 : Closed e302800821678 ∧ code e302800821678 = 1402312449454 := by decide
theorem cert_e302800821678 : check e302800821678 [[],[]] .sourceHead = true := by decide
def e302800821690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e302800821690 : Closed e302800821690 ∧ code e302800821690 = 1402312449466 := by decide
theorem cert_e302800821690 : check e302800821690 [[],[]] .sourceHead = true := by decide
def e302800821718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e302800821718 : Closed e302800821718 ∧ code e302800821718 = 1402312449494 := by decide
theorem cert_e302800821718 : check e302800821718 [[],[]] .sourceHead = true := by decide
def e302800821722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e302800821722 : Closed e302800821722 ∧ code e302800821722 = 1402312449498 := by decide
theorem cert_e302800821722 : check e302800821722 [[],[]] .sourceHead = true := by decide
def e302800822966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e302800822966 : Closed e302800822966 ∧ code e302800822966 = 1402312450742 := by decide
theorem cert_e302800822966 : check e302800822966 [[],[]] .chain = true := by decide
def e302800822998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e302800822998 : Closed e302800822998 ∧ code e302800822998 = 1402312450774 := by decide
theorem cert_e302800822998 : check e302800822998 [[],[]] .chain = true := by decide
def e302800823002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e302800823002 : Closed e302800823002 ∧ code e302800823002 = 1402312450778 := by decide
theorem cert_e302800823002 : check e302800823002 [[],[]] .chain = true := by decide
def e302800823126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e302800823126 : Closed e302800823126 ∧ code e302800823126 = 1402312450902 := by decide
theorem cert_e302800823126 : check e302800823126 [[],[]] .chain = true := by decide
def e302800823130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e302800823130 : Closed e302800823130 ∧ code e302800823130 = 1402312450906 := by decide
theorem cert_e302800823130 : check e302800823130 [[],[]] .chain = true := by decide
def e302800823146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e302800823146 : Closed e302800823146 ∧ code e302800823146 = 1402312450922 := by decide
theorem cert_e302800823146 : check e302800823146 [[],[]] .chain = true := by decide
def e302800823210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e302800823210 : Closed e302800823210 ∧ code e302800823210 = 1402312450986 := by decide
theorem cert_e302800823210 : check e302800823210 [[],[]] .chain = true := by decide
def e302800824502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e302800824502 : Closed e302800824502 ∧ code e302800824502 = 1402312452278 := by decide
theorem cert_e302800824502 : check e302800824502 [[],[]] .chain = true := by decide
def e302800824534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e302800824534 : Closed e302800824534 ∧ code e302800824534 = 1402312452310 := by decide
theorem cert_e302800824534 : check e302800824534 [[],[]] .chain = true := by decide
def e302800824538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e302800824538 : Closed e302800824538 ∧ code e302800824538 = 1402312452314 := by decide
theorem cert_e302800824538 : check e302800824538 [[],[]] .chain = true := by decide
def e302800824554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e302800824554 : Closed e302800824554 ∧ code e302800824554 = 1402312452330 := by decide
theorem cert_e302800824554 : check e302800824554 [[],[]] .chain = true := by decide
def e302800824886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e302800824886 : Closed e302800824886 ∧ code e302800824886 = 1402312452662 := by decide
theorem cert_e302800824886 : check e302800824886 [[],[]] .chain = true := by decide
def e302800824890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e302800824890 : Closed e302800824890 ∧ code e302800824890 = 1402312452666 := by decide
theorem cert_e302800824890 : check e302800824890 [[],[]] .chain = true := by decide
def e302800824974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e302800824974 : Closed e302800824974 ∧ code e302800824974 = 1402312452750 := by decide
theorem cert_e302800824974 : check e302800824974 [[],[]] .chain = true := by decide
def e302800825030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e302800825030 : Closed e302800825030 ∧ code e302800825030 = 1402312452806 := by decide
theorem cert_e302800825030 : check e302800825030 [[],[]] .chain = true := by decide
def e302800825110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 1))))))
theorem wire_e302800825110 : Closed e302800825110 ∧ code e302800825110 = 1402312452886 := by decide
theorem cert_e302800825110 : check e302800825110 [[],[]] .chain = true := by decide
def e302800825114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e302800825114 : Closed e302800825114 ∧ code e302800825114 = 1402312452890 := by decide
theorem cert_e302800825114 : check e302800825114 [[],[]] .chain = true := by decide
def e302800825158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302800825158 : Closed e302800825158 ∧ code e302800825158 = 1402312452934 := by decide
theorem cert_e302800825158 : check e302800825158 [[],[]] .chain = true := by decide
def e302800825186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e302800825186 : Closed e302800825186 ∧ code e302800825186 = 1402312452962 := by decide
theorem cert_e302800825186 : check e302800825186 [[],[]] .chain = true := by decide
def e302800825198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e302800825198 : Closed e302800825198 ∧ code e302800825198 = 1402312452974 := by decide
theorem cert_e302800825198 : check e302800825198 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302800825206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e302800825206 : Closed e302800825206 ∧ code e302800825206 = 1402312452982 := by decide
theorem cert_e302800825206 : check e302800825206 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302800825270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e302800825270 : Closed e302800825270 ∧ code e302800825270 = 1402312453046 := by decide
theorem cert_e302800825270 : check e302800825270 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e302800825430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e302800825430 : Closed e302800825430 ∧ code e302800825430 = 1402312453206 := by decide
theorem cert_e302800825430 : check e302800825430 [[],[]] .chain = true := by decide
def e302800825434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e302800825434 : Closed e302800825434 ∧ code e302800825434 = 1402312453210 := by decide
theorem cert_e302800825434 : check e302800825434 [[],[]] .chain = true := by decide
def e302800825450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e302800825450 : Closed e302800825450 ∧ code e302800825450 = 1402312453226 := by decide
theorem cert_e302800825450 : check e302800825450 [[],[]] .chain = true := by decide
def e302800825622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e302800825622 : Closed e302800825622 ∧ code e302800825622 = 1402312453398 := by decide
theorem cert_e302800825622 : check e302800825622 [[],[]] .chain = true := by decide
def e302800825626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))) (.var 0))))))
theorem wire_e302800825626 : Closed e302800825626 ∧ code e302800825626 = 1402312453402 := by decide
theorem cert_e302800825626 : check e302800825626 [[],[]] .chain = true := by decide
def e302800825670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302800825670 : Closed e302800825670 ∧ code e302800825670 = 1402312453446 := by decide
theorem cert_e302800825670 : check e302800825670 [[],[]] .chain = true := by decide
def e302800825698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e302800825698 : Closed e302800825698 ∧ code e302800825698 = 1402312453474 := by decide
theorem cert_e302800825698 : check e302800825698 [[],[]] .chain = true := by decide
def e302800825710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e302800825710 : Closed e302800825710 ∧ code e302800825710 = 1402312453486 := by decide
theorem cert_e302800825710 : check e302800825710 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302800825718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e302800825718 : Closed e302800825718 ∧ code e302800825718 = 1402312453494 := by decide
theorem cert_e302800825718 : check e302800825718 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302800825738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e302800825738 : Closed e302800825738 ∧ code e302800825738 = 1402312453514 := by decide
theorem cert_e302800825738 : check e302800825738 [[],[]] .chain = true := by decide
def e302800825762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e302800825762 : Closed e302800825762 ∧ code e302800825762 = 1402312453538 := by decide
theorem cert_e302800825762 : check e302800825762 [[],[]] .chain = true := by decide
def e302800825774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e302800825774 : Closed e302800825774 ∧ code e302800825774 = 1402312453550 := by decide
theorem cert_e302800825774 : check e302800825774 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302800825786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e302800825786 : Closed e302800825786 ∧ code e302800825786 = 1402312453562 := by decide
theorem cert_e302800825786 : check e302800825786 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e302800825814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e302800825814 : Closed e302800825814 ∧ code e302800825814 = 1402312453590 := by decide
theorem cert_e302800825814 : check e302800825814 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e302800825818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e302800825818 : Closed e302800825818 ∧ code e302800825818 = 1402312453594 := by decide
theorem cert_e302800825818 : check e302800825818 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e302800826038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e302800826038 : Closed e302800826038 ∧ code e302800826038 = 1402312453814 := by decide
private def t_e302800826038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))
theorem cert_e302800826038 : ¬ IsSelfInterpreter e302800826038 :=
  wSource (t := t_e302800826038) (replay_sound (ps := []) (t := e302800826038) (by decide)) (by decide)
def e302800826070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e302800826070 : Closed e302800826070 ∧ code e302800826070 = 1402312453846 := by decide
private def t_e302800826070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))
theorem cert_e302800826070 : ¬ IsSelfInterpreter e302800826070 :=
  wSource (t := t_e302800826070) (replay_sound (ps := []) (t := e302800826070) (by decide)) (by decide)
def e302800826074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e302800826074 : Closed e302800826074 ∧ code e302800826074 = 1402312453850 := by decide
private def t_e302800826074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))
theorem cert_e302800826074 : ¬ IsSelfInterpreter e302800826074 :=
  wSource (t := t_e302800826074) (replay_sound (ps := []) (t := e302800826074) (by decide)) (by decide)
def e302800834414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 1)) (.var 2))))))
theorem wire_e302800834414 : Closed e302800834414 ∧ code e302800834414 = 1402312462190 := by decide
theorem cert_e302800834414 : check e302800834414 [[],[]] .chain = true := by decide
def e302800834422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.var 1))))))
theorem wire_e302800834422 : Closed e302800834422 ∧ code e302800834422 = 1402312462198 := by decide
theorem cert_e302800834422 : check e302800834422 [[],[]] .chain = true := by decide
def e302800834486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.var 1))))))
theorem wire_e302800834486 : Closed e302800834486 ∧ code e302800834486 = 1402312462262 := by decide
theorem cert_e302800834486 : check e302800834486 [[],[]] .chain = true := by decide
def e302800837486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e302800837486 : Closed e302800837486 ∧ code e302800837486 = 1402312465262 := by decide
theorem cert_e302800837486 : check e302800837486 [[],[]] .chain = true := by decide
def e302800837494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e302800837494 : Closed e302800837494 ∧ code e302800837494 = 1402312465270 := by decide
theorem cert_e302800837494 : check e302800837494 [[],[]] .chain = true := by decide
def e302800837550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e302800837550 : Closed e302800837550 ∧ code e302800837550 = 1402312465326 := by decide
theorem cert_e302800837550 : check e302800837550 [[],[]] .chain = true := by decide
def e302800837562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e302800837562 : Closed e302800837562 ∧ code e302800837562 = 1402312465338 := by decide
theorem cert_e302800837562 : check e302800837562 [[],[]] .chain = true := by decide
def e302800837590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e302800837590 : Closed e302800837590 ∧ code e302800837590 = 1402312465366 := by decide
theorem cert_e302800837590 : check e302800837590 [[],[]] .chain = true := by decide
def e302800837594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e302800837594 : Closed e302800837594 ∧ code e302800837594 = 1402312465370 := by decide
theorem cert_e302800837594 : check e302800837594 [[],[]] .chain = true := by decide
def e302800837998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e302800837998 : Closed e302800837998 ∧ code e302800837998 = 1402312465774 := by decide
theorem cert_e302800837998 : check e302800837998 [[],[]] .chain = true := by decide
end Blc.Floor40
