import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e300677980186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300677980186 : Closed e300677980186 ∧ code e300677980186 = 1400189607962 := by decide
theorem cert_e300677980186 : check e300677980186 [[]] .width = true := by decide
def e300677980278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300677980278 : Closed e300677980278 ∧ code e300677980278 = 1400189608054 := by decide
theorem cert_e300677980278 : check e300677980278 [[]] .width = true := by decide
def e300677980522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300677980522 : Closed e300677980522 ∧ code e300677980522 = 1400189608298 := by decide
theorem cert_e300677980522 : check e300677980522 [[]] .width = true := by decide
def e300677980570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300677980570 : Closed e300677980570 ∧ code e300677980570 = 1400189608346 := by decide
theorem cert_e300677980570 : check e300677980570 [[]] .width = true := by decide
def e300678094874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300678094874 : Closed e300678094874 ∧ code e300678094874 = 1400189722650 := by decide
theorem cert_e300678094874 : check e300678094874 [[]] .width = true := by decide
def e300678094966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300678094966 : Closed e300678094966 ∧ code e300678094966 = 1400189722742 := by decide
theorem cert_e300678094966 : check e300678094966 [[]] .width = true := by decide
def e300678095210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300678095210 : Closed e300678095210 ∧ code e300678095210 = 1400189722986 := by decide
theorem cert_e300678095210 : check e300678095210 [[]] .width = true := by decide
def e300678095258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300678095258 : Closed e300678095258 ∧ code e300678095258 = 1400189723034 := by decide
theorem cert_e300678095258 : check e300678095258 [[]] .width = true := by decide
def e300679622854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300679622854 : Closed e300679622854 ∧ code e300679622854 = 1400191250630 := by decide
theorem cert_e300679622854 : check e300679622854 [[]] .width = true := by decide
def e300679680198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300679680198 : Closed e300679680198 ∧ code e300679680198 = 1400191307974 := by decide
theorem cert_e300679680198 : check e300679680198 [[]] .width = true := by decide
def e300680437786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300680437786 : Closed e300680437786 ∧ code e300680437786 = 1400192065562 := by decide
theorem cert_e300680437786 : check e300680437786 [[]] .width = true := by decide
def e300680437878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300680437878 : Closed e300680437878 ∧ code e300680437878 = 1400192065654 := by decide
theorem cert_e300680437878 : check e300680437878 [[]] .width = true := by decide
def e300680438122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300680438122 : Closed e300680438122 ∧ code e300680438122 = 1400192065898 := by decide
theorem cert_e300680438122 : check e300680438122 [[]] .width = true := by decide
def e300680438170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300680438170 : Closed e300680438170 ∧ code e300680438170 = 1400192065946 := by decide
theorem cert_e300680438170 : check e300680438170 [[]] .width = true := by decide
def e300680442054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300680442054 : Closed e300680442054 ∧ code e300680442054 = 1400192069830 := by decide
theorem cert_e300680442054 : check e300680442054 [[]] .width = true := by decide
def e300680454170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300680454170 : Closed e300680454170 ∧ code e300680454170 = 1400192081946 := by decide
theorem cert_e300680454170 : check e300680454170 [[]] .width = true := by decide
def e300680454262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300680454262 : Closed e300680454262 ∧ code e300680454262 = 1400192082038 := by decide
theorem cert_e300680454262 : check e300680454262 [[]] .width = true := by decide
def e300680454506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300680454506 : Closed e300680454506 ∧ code e300680454506 = 1400192082282 := by decide
theorem cert_e300680454506 : check e300680454506 [[]] .width = true := by decide
def e300680454554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300680454554 : Closed e300680454554 ∧ code e300680454554 = 1400192082330 := by decide
theorem cert_e300680454554 : check e300680454554 [[]] .width = true := by decide
def e300680466630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300680466630 : Closed e300680466630 ∧ code e300680466630 = 1400192094406 := by decide
theorem cert_e300680466630 : check e300680466630 [[]] .width = true := by decide
def e300738638022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300738638022 : Closed e300738638022 ∧ code e300738638022 = 1400250265798 := by decide
theorem cert_e300738638022 : check e300738638022 [[]] .width = true := by decide
def e300738654406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300738654406 : Closed e300738654406 ∧ code e300738654406 = 1400250282182 := by decide
theorem cert_e300738654406 : check e300738654406 [[]] .width = true := by decide
def e300738769094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300738769094 : Closed e300738769094 ∧ code e300738769094 = 1400250396870 := by decide
theorem cert_e300738769094 : check e300738769094 [[]] .width = true := by decide
def e300738787354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300738787354 : Closed e300738787354 ∧ code e300738787354 = 1400250415130 := by decide
theorem cert_e300738787354 : check e300738787354 [[]] .width = true := by decide
def e300738793670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300738793670 : Closed e300738793670 ∧ code e300738793670 = 1400250421446 := by decide
theorem cert_e300738793670 : check e300738793670 [[]] .width = true := by decide
def e300738795546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300738795546 : Closed e300738795546 ∧ code e300738795546 = 1400250423322 := by decide
theorem cert_e300738795546 : check e300738795546 [[]] .width = true := by decide
def e300738851014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300738851014 : Closed e300738851014 ∧ code e300738851014 = 1400250478790 := by decide
theorem cert_e300738851014 : check e300738851014 [[]] .width = true := by decide
def e300738859206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300738859206 : Closed e300738859206 ∧ code e300738859206 = 1400250486982 := by decide
theorem cert_e300738859206 : check e300738859206 [[]] .width = true := by decide
def e300738861082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300738861082 : Closed e300738861082 ∧ code e300738861082 = 1400250488858 := by decide
theorem cert_e300738861082 : check e300738861082 [[]] .width = true := by decide
def e300739293382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300739293382 : Closed e300739293382 ∧ code e300739293382 = 1400250921158 := by decide
theorem cert_e300739293382 : check e300739293382 [[]] .width = true := by decide
def e300739311642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300739311642 : Closed e300739311642 ∧ code e300739311642 = 1400250939418 := by decide
theorem cert_e300739311642 : check e300739311642 [[]] .width = true := by decide
def e300739317958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300739317958 : Closed e300739317958 ∧ code e300739317958 = 1400250945734 := by decide
theorem cert_e300739317958 : check e300739317958 [[]] .width = true := by decide
def e300739319834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300739319834 : Closed e300739319834 ∧ code e300739319834 = 1400250947610 := by decide
theorem cert_e300739319834 : check e300739319834 [[]] .width = true := by decide
def e300739377178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300739377178 : Closed e300739377178 ∧ code e300739377178 = 1400251004954 := by decide
theorem cert_e300739377178 : check e300739377178 [[]] .width = true := by decide
def e300739389466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300739389466 : Closed e300739389466 ∧ code e300739389466 = 1400251017242 := by decide
theorem cert_e300739389466 : check e300739389466 [[]] .width = true := by decide
def e300739416262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300739416262 : Closed e300739416262 ∧ code e300739416262 = 1400251044038 := by decide
theorem cert_e300739416262 : check e300739416262 [[]] .width = true := by decide
def e300739418138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300739418138 : Closed e300739418138 ∧ code e300739418138 = 1400251045914 := by decide
theorem cert_e300739418138 : check e300739418138 [[]] .width = true := by decide
def e300739422234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300739422234 : Closed e300739422234 ∧ code e300739422234 = 1400251050010 := by decide
theorem cert_e300739422234 : check e300739422234 [[]] .width = true := by decide
def e300739637446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300739637446 : Closed e300739637446 ∧ code e300739637446 = 1400251265222 := by decide
theorem cert_e300739637446 : check e300739637446 [[]] .width = true := by decide
def e300739645638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300739645638 : Closed e300739645638 ∧ code e300739645638 = 1400251273414 := by decide
theorem cert_e300739645638 : check e300739645638 [[]] .width = true := by decide
def e300739647514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300739647514 : Closed e300739647514 ∧ code e300739647514 = 1400251275290 := by decide
theorem cert_e300739647514 : check e300739647514 [[]] .width = true := by decide
def e300739678406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300739678406 : Closed e300739678406 ∧ code e300739678406 = 1400251306182 := by decide
theorem cert_e300739678406 : check e300739678406 [[]] .width = true := by decide
def e300739680282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300739680282 : Closed e300739680282 ∧ code e300739680282 = 1400251308058 := by decide
theorem cert_e300739680282 : check e300739680282 [[]] .width = true := by decide
def e300739684378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300739684378 : Closed e300739684378 ∧ code e300739684378 = 1400251312154 := by decide
theorem cert_e300739684378 : check e300739684378 [[]] .width = true := by decide
def e300740960282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300740960282 : Closed e300740960282 ∧ code e300740960282 = 1400252588058 := by decide
theorem cert_e300740960282 : check e300740960282 [[]] .width = true := by decide
def e300740960374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300740960374 : Closed e300740960374 ∧ code e300740960374 = 1400252588150 := by decide
theorem cert_e300740960374 : check e300740960374 [[]] .width = true := by decide
def e300740960618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300740960618 : Closed e300740960618 ∧ code e300740960618 = 1400252588394 := by decide
theorem cert_e300740960618 : check e300740960618 [[]] .width = true := by decide
def e300740960666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300740960666 : Closed e300740960666 ∧ code e300740960666 = 1400252588442 := by decide
theorem cert_e300740960666 : check e300740960666 [[]] .width = true := by decide
def e300740993050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300740993050 : Closed e300740993050 ∧ code e300740993050 = 1400252620826 := by decide
theorem cert_e300740993050 : check e300740993050 [[]] .width = true := by decide
def e300740993142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300740993142 : Closed e300740993142 ∧ code e300740993142 = 1400252620918 := by decide
theorem cert_e300740993142 : check e300740993142 [[]] .width = true := by decide
def e300740993386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300740993386 : Closed e300740993386 ∧ code e300740993386 = 1400252621162 := by decide
theorem cert_e300740993386 : check e300740993386 [[]] .width = true := by decide
def e300740993434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300740993434 : Closed e300740993434 ∧ code e300740993434 = 1400252621210 := by decide
theorem cert_e300740993434 : check e300740993434 [[]] .width = true := by decide
def e300741783750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300741783750 : Closed e300741783750 ∧ code e300741783750 = 1400253411526 := by decide
theorem cert_e300741783750 : check e300741783750 [[]] .width = true := by decide
def e300741800134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300741800134 : Closed e300741800134 ∧ code e300741800134 = 1400253427910 := by decide
theorem cert_e300741800134 : check e300741800134 [[]] .width = true := by decide
def e300741914822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300741914822 : Closed e300741914822 ∧ code e300741914822 = 1400253542598 := by decide
theorem cert_e300741914822 : check e300741914822 [[]] .width = true := by decide
def e300741933082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300741933082 : Closed e300741933082 ∧ code e300741933082 = 1400253560858 := by decide
theorem cert_e300741933082 : check e300741933082 [[]] .width = true := by decide
def e300741939398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300741939398 : Closed e300741939398 ∧ code e300741939398 = 1400253567174 := by decide
theorem cert_e300741939398 : check e300741939398 [[]] .width = true := by decide
def e300741941274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300741941274 : Closed e300741941274 ∧ code e300741941274 = 1400253569050 := by decide
theorem cert_e300741941274 : check e300741941274 [[]] .width = true := by decide
def e300741996742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300741996742 : Closed e300741996742 ∧ code e300741996742 = 1400253624518 := by decide
theorem cert_e300741996742 : check e300741996742 [[]] .width = true := by decide
def e300742004934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300742004934 : Closed e300742004934 ∧ code e300742004934 = 1400253632710 := by decide
theorem cert_e300742004934 : check e300742004934 [[]] .width = true := by decide
def e300742006810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300742006810 : Closed e300742006810 ∧ code e300742006810 = 1400253634586 := by decide
theorem cert_e300742006810 : check e300742006810 [[]] .width = true := by decide
def e300742570182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300742570182 : Closed e300742570182 ∧ code e300742570182 = 1400254197958 := by decide
theorem cert_e300742570182 : check e300742570182 [[]] .width = true := by decide
def e300742586566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300742586566 : Closed e300742586566 ∧ code e300742586566 = 1400254214342 := by decide
theorem cert_e300742586566 : check e300742586566 [[]] .width = true := by decide
def e300743254042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300743254042 : Closed e300743254042 ∧ code e300743254042 = 1400254881818 := by decide
theorem cert_e300743254042 : check e300743254042 [[]] .width = true := by decide
def e300743254134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300743254134 : Closed e300743254134 ∧ code e300743254134 = 1400254881910 := by decide
theorem cert_e300743254134 : check e300743254134 [[]] .width = true := by decide
def e300743254378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300743254378 : Closed e300743254378 ∧ code e300743254378 = 1400254882154 := by decide
theorem cert_e300743254378 : check e300743254378 [[]] .width = true := by decide
def e300743254426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300743254426 : Closed e300743254426 ∧ code e300743254426 = 1400254882202 := by decide
theorem cert_e300743254426 : check e300743254426 [[]] .width = true := by decide
def e300743356614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300743356614 : Closed e300743356614 ∧ code e300743356614 = 1400254984390 := by decide
theorem cert_e300743356614 : check e300743356614 [[]] .width = true := by decide
def e300743374874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300743374874 : Closed e300743374874 ∧ code e300743374874 = 1400255002650 := by decide
theorem cert_e300743374874 : check e300743374874 [[]] .width = true := by decide
def e300743381190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300743381190 : Closed e300743381190 ∧ code e300743381190 = 1400255008966 := by decide
theorem cert_e300743381190 : check e300743381190 [[]] .width = true := by decide
def e300743383066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300743383066 : Closed e300743383066 ∧ code e300743383066 = 1400255010842 := by decide
theorem cert_e300743383066 : check e300743383066 [[]] .width = true := by decide
def e300743590086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300743590086 : Closed e300743590086 ∧ code e300743590086 = 1400255217862 := by decide
theorem cert_e300743590086 : check e300743590086 [[]] .width = true := by decide
def e300743590614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e300743590614 : Closed e300743590614 ∧ code e300743590614 = 1400255218390 := by decide
theorem cert_e300743590614 : check e300743590614 [[]] .width = true := by decide
def e300743590618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e300743590618 : Closed e300743590618 ∧ code e300743590618 = 1400255218394 := by decide
theorem cert_e300743590618 : check e300743590618 [[]] .width = true := by decide
def e300743590634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e300743590634 : Closed e300743590634 ∧ code e300743590634 = 1400255218410 := by decide
theorem cert_e300743590634 : check e300743590634 [[]] .width = true := by decide
def e300743590710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e300743590710 : Closed e300743590710 ∧ code e300743590710 = 1400255218486 := by decide
theorem cert_e300743590710 : check e300743590710 [[]] .width = true := by decide
def e300743590714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e300743590714 : Closed e300743590714 ∧ code e300743590714 = 1400255218490 := by decide
theorem cert_e300743590714 : check e300743590714 [[]] .width = true := by decide
def e300743590798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e300743590798 : Closed e300743590798 ∧ code e300743590798 = 1400255218574 := by decide
theorem cert_e300743590798 : check e300743590798 [[]] .width = true := by decide
def e300743590810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e300743590810 : Closed e300743590810 ∧ code e300743590810 = 1400255218586 := by decide
theorem cert_e300743590810 : check e300743590810 [[]] .width = true := by decide
def e300743592730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e300743592730 : Closed e300743592730 ∧ code e300743592730 = 1400255220506 := by decide
theorem cert_e300743592730 : check e300743592730 [[]] .width = true := by decide
def e300743592774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e300743592774 : Closed e300743592774 ∧ code e300743592774 = 1400255220550 := by decide
theorem cert_e300743592774 : check e300743592774 [[]] .width = true := by decide
def e300743593014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e300743593014 : Closed e300743593014 ∧ code e300743593014 = 1400255220790 := by decide
theorem cert_e300743593014 : check e300743593014 [[]] .width = true := by decide
def e300743593018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e300743593018 : Closed e300743593018 ∧ code e300743593018 = 1400255220794 := by decide
theorem cert_e300743593018 : check e300743593018 [[]] .width = true := by decide
def e300743593158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e300743593158 : Closed e300743593158 ∧ code e300743593158 = 1400255220934 := by decide
theorem cert_e300743593158 : check e300743593158 [[]] .width = true := by decide
def e300743712794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300743712794 : Closed e300743712794 ∧ code e300743712794 = 1400255340570 := by decide
theorem cert_e300743712794 : check e300743712794 [[]] .width = true := by decide
def e300743712886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300743712886 : Closed e300743712886 ∧ code e300743712886 = 1400255340662 := by decide
theorem cert_e300743712886 : check e300743712886 [[]] .width = true := by decide
def e300743713130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300743713130 : Closed e300743713130 ∧ code e300743713130 = 1400255340906 := by decide
theorem cert_e300743713130 : check e300743713130 [[]] .width = true := by decide
def e300743713178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300743713178 : Closed e300743713178 ∧ code e300743713178 = 1400255340954 := by decide
theorem cert_e300743713178 : check e300743713178 [[]] .width = true := by decide
def e300743766214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300743766214 : Closed e300743766214 ∧ code e300743766214 = 1400255393990 := by decide
theorem cert_e300743766214 : check e300743766214 [[]] .width = true := by decide
def e300743774406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300743774406 : Closed e300743774406 ∧ code e300743774406 = 1400255402182 := by decide
theorem cert_e300743774406 : check e300743774406 [[]] .width = true := by decide
def e300743776282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300743776282 : Closed e300743776282 ∧ code e300743776282 = 1400255404058 := by decide
theorem cert_e300743776282 : check e300743776282 [[]] .width = true := by decide
def e300743852230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300743852230 : Closed e300743852230 ∧ code e300743852230 = 1400255480006 := by decide
theorem cert_e300743852230 : check e300743852230 [[]] .width = true := by decide
def e300743852758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e300743852758 : Closed e300743852758 ∧ code e300743852758 = 1400255480534 := by decide
theorem cert_e300743852758 : check e300743852758 [[]] .width = true := by decide
def e300743852762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e300743852762 : Closed e300743852762 ∧ code e300743852762 = 1400255480538 := by decide
theorem cert_e300743852762 : check e300743852762 [[]] .width = true := by decide
def e300743852778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e300743852778 : Closed e300743852778 ∧ code e300743852778 = 1400255480554 := by decide
theorem cert_e300743852778 : check e300743852778 [[]] .width = true := by decide
def e300743852854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e300743852854 : Closed e300743852854 ∧ code e300743852854 = 1400255480630 := by decide
theorem cert_e300743852854 : check e300743852854 [[]] .width = true := by decide
def e300743852858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e300743852858 : Closed e300743852858 ∧ code e300743852858 = 1400255480634 := by decide
theorem cert_e300743852858 : check e300743852858 [[]] .width = true := by decide
def e300743852942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e300743852942 : Closed e300743852942 ∧ code e300743852942 = 1400255480718 := by decide
theorem cert_e300743852942 : check e300743852942 [[]] .width = true := by decide
def e300743852954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e300743852954 : Closed e300743852954 ∧ code e300743852954 = 1400255480730 := by decide
theorem cert_e300743852954 : check e300743852954 [[]] .width = true := by decide
def e300743854874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e300743854874 : Closed e300743854874 ∧ code e300743854874 = 1400255482650 := by decide
theorem cert_e300743854874 : check e300743854874 [[]] .width = true := by decide
def e300743854918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e300743854918 : Closed e300743854918 ∧ code e300743854918 = 1400255482694 := by decide
theorem cert_e300743854918 : check e300743854918 [[]] .width = true := by decide
def e300743855158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e300743855158 : Closed e300743855158 ∧ code e300743855158 = 1400255482934 := by decide
theorem cert_e300743855158 : check e300743855158 [[]] .width = true := by decide
def e300743855162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e300743855162 : Closed e300743855162 ∧ code e300743855162 = 1400255482938 := by decide
theorem cert_e300743855162 : check e300743855162 [[]] .width = true := by decide
def e300743855302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e300743855302 : Closed e300743855302 ∧ code e300743855302 = 1400255483078 := by decide
theorem cert_e300743855302 : check e300743855302 [[]] .width = true := by decide
def e300744630298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300744630298 : Closed e300744630298 ∧ code e300744630298 = 1400256258074 := by decide
theorem cert_e300744630298 : check e300744630298 [[]] .width = true := by decide
def e300744630390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300744630390 : Closed e300744630390 ∧ code e300744630390 = 1400256258166 := by decide
theorem cert_e300744630390 : check e300744630390 [[]] .width = true := by decide
def e300744630634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300744630634 : Closed e300744630634 ∧ code e300744630634 = 1400256258410 := by decide
theorem cert_e300744630634 : check e300744630634 [[]] .width = true := by decide
def e300744630682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300744630682 : Closed e300744630682 ∧ code e300744630682 = 1400256258458 := by decide
theorem cert_e300744630682 : check e300744630682 [[]] .width = true := by decide
def e300744679450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300744679450 : Closed e300744679450 ∧ code e300744679450 = 1400256307226 := by decide
theorem cert_e300744679450 : check e300744679450 [[]] .width = true := by decide
def e300744679542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300744679542 : Closed e300744679542 ∧ code e300744679542 = 1400256307318 := by decide
theorem cert_e300744679542 : check e300744679542 [[]] .width = true := by decide
def e300744679786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300744679786 : Closed e300744679786 ∧ code e300744679786 = 1400256307562 := by decide
theorem cert_e300744679786 : check e300744679786 [[]] .width = true := by decide
def e300744679834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300744679834 : Closed e300744679834 ∧ code e300744679834 = 1400256307610 := by decide
theorem cert_e300744679834 : check e300744679834 [[]] .width = true := by decide
def e300745060550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300745060550 : Closed e300745060550 ∧ code e300745060550 = 1400256688326 := by decide
theorem cert_e300745060550 : check e300745060550 [[]] .width = true := by decide
def e300745078810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300745078810 : Closed e300745078810 ∧ code e300745078810 = 1400256706586 := by decide
theorem cert_e300745078810 : check e300745078810 [[]] .width = true := by decide
def e300745085126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300745085126 : Closed e300745085126 ∧ code e300745085126 = 1400256712902 := by decide
theorem cert_e300745085126 : check e300745085126 [[]] .width = true := by decide
def e300745087002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300745087002 : Closed e300745087002 ∧ code e300745087002 = 1400256714778 := by decide
theorem cert_e300745087002 : check e300745087002 [[]] .width = true := by decide
def e300745144346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300745144346 : Closed e300745144346 ∧ code e300745144346 = 1400256772122 := by decide
theorem cert_e300745144346 : check e300745144346 [[]] .width = true := by decide
def e300745156634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300745156634 : Closed e300745156634 ∧ code e300745156634 = 1400256784410 := by decide
theorem cert_e300745156634 : check e300745156634 [[]] .width = true := by decide
def e300745183430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300745183430 : Closed e300745183430 ∧ code e300745183430 = 1400256811206 := by decide
theorem cert_e300745183430 : check e300745183430 [[]] .width = true := by decide
def e300745185306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300745185306 : Closed e300745185306 ∧ code e300745185306 = 1400256813082 := by decide
theorem cert_e300745185306 : check e300745185306 [[]] .width = true := by decide
def e300745189402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300745189402 : Closed e300745189402 ∧ code e300745189402 = 1400256817178 := by decide
theorem cert_e300745189402 : check e300745189402 [[]] .width = true := by decide
def e300745351194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300745351194 : Closed e300745351194 ∧ code e300745351194 = 1400256978970 := by decide
theorem cert_e300745351194 : check e300745351194 [[]] .width = true := by decide
def e300745351286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300745351286 : Closed e300745351286 ∧ code e300745351286 = 1400256979062 := by decide
theorem cert_e300745351286 : check e300745351286 [[]] .width = true := by decide
def e300745351530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300745351530 : Closed e300745351530 ∧ code e300745351530 = 1400256979306 := by decide
theorem cert_e300745351530 : check e300745351530 [[]] .width = true := by decide
def e300745351578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300745351578 : Closed e300745351578 ∧ code e300745351578 = 1400256979354 := by decide
theorem cert_e300745351578 : check e300745351578 [[]] .width = true := by decide
def e300745453766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300745453766 : Closed e300745453766 ∧ code e300745453766 = 1400257081542 := by decide
theorem cert_e300745453766 : check e300745453766 [[]] .width = true := by decide
def e300745472026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300745472026 : Closed e300745472026 ∧ code e300745472026 = 1400257099802 := by decide
theorem cert_e300745472026 : check e300745472026 [[]] .width = true := by decide
def e300745478342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300745478342 : Closed e300745478342 ∧ code e300745478342 = 1400257106118 := by decide
theorem cert_e300745478342 : check e300745478342 [[]] .width = true := by decide
def e300745480218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300745480218 : Closed e300745480218 ∧ code e300745480218 = 1400257107994 := by decide
theorem cert_e300745480218 : check e300745480218 [[]] .width = true := by decide
def e300745687238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300745687238 : Closed e300745687238 ∧ code e300745687238 = 1400257315014 := by decide
theorem cert_e300745687238 : check e300745687238 [[]] .width = true := by decide
def e300745687766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e300745687766 : Closed e300745687766 ∧ code e300745687766 = 1400257315542 := by decide
theorem cert_e300745687766 : check e300745687766 [[]] .width = true := by decide
def e300745687770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e300745687770 : Closed e300745687770 ∧ code e300745687770 = 1400257315546 := by decide
theorem cert_e300745687770 : check e300745687770 [[]] .width = true := by decide
def e300745687786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e300745687786 : Closed e300745687786 ∧ code e300745687786 = 1400257315562 := by decide
theorem cert_e300745687786 : check e300745687786 [[]] .width = true := by decide
def e300745687862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e300745687862 : Closed e300745687862 ∧ code e300745687862 = 1400257315638 := by decide
theorem cert_e300745687862 : check e300745687862 [[]] .width = true := by decide
def e300745687866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e300745687866 : Closed e300745687866 ∧ code e300745687866 = 1400257315642 := by decide
theorem cert_e300745687866 : check e300745687866 [[]] .width = true := by decide
def e300745687950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e300745687950 : Closed e300745687950 ∧ code e300745687950 = 1400257315726 := by decide
theorem cert_e300745687950 : check e300745687950 [[]] .width = true := by decide
def e300745687962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e300745687962 : Closed e300745687962 ∧ code e300745687962 = 1400257315738 := by decide
theorem cert_e300745687962 : check e300745687962 [[]] .width = true := by decide
def e300745689882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e300745689882 : Closed e300745689882 ∧ code e300745689882 = 1400257317658 := by decide
theorem cert_e300745689882 : check e300745689882 [[]] .width = true := by decide
def e300745689926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e300745689926 : Closed e300745689926 ∧ code e300745689926 = 1400257317702 := by decide
theorem cert_e300745689926 : check e300745689926 [[]] .width = true := by decide
def e300745690166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e300745690166 : Closed e300745690166 ∧ code e300745690166 = 1400257317942 := by decide
theorem cert_e300745690166 : check e300745690166 [[]] .width = true := by decide
def e300745690170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e300745690170 : Closed e300745690170 ∧ code e300745690170 = 1400257317946 := by decide
theorem cert_e300745690170 : check e300745690170 [[]] .width = true := by decide
def e300745690310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e300745690310 : Closed e300745690310 ∧ code e300745690310 = 1400257318086 := by decide
theorem cert_e300745690310 : check e300745690310 [[]] .width = true := by decide
def e300745865242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300745865242 : Closed e300745865242 ∧ code e300745865242 = 1400257493018 := by decide
theorem cert_e300745865242 : check e300745865242 [[]] .width = true := by decide
def e300745877530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300745877530 : Closed e300745877530 ∧ code e300745877530 = 1400257505306 := by decide
theorem cert_e300745877530 : check e300745877530 [[]] .width = true := by decide
def e300746039322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300746039322 : Closed e300746039322 ∧ code e300746039322 = 1400257667098 := by decide
theorem cert_e300746039322 : check e300746039322 [[]] .width = true := by decide
def e300746039414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300746039414 : Closed e300746039414 ∧ code e300746039414 = 1400257667190 := by decide
private def t_e300746039414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e300746039414 : ¬ IsSelfInterpreter e300746039414 :=
  wSource (t := t_e300746039414) (replay_sound (ps := []) (t := e300746039414) (by decide)) (by decide)
def e300746039658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300746039658 : Closed e300746039658 ∧ code e300746039658 = 1400257667434 := by decide
private def t_e300746039658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e300746039658 : ¬ IsSelfInterpreter e300746039658 :=
  wSource (t := t_e300746039658) (replay_sound (ps := []) (t := e300746039658) (by decide)) (by decide)
def e300746039706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300746039706 : Closed e300746039706 ∧ code e300746039706 = 1400257667482 := by decide
private def t_e300746039706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e300746039706 : ¬ IsSelfInterpreter e300746039706 :=
  wSource (t := t_e300746039706) (replay_sound (ps := []) (t := e300746039706) (by decide)) (by decide)
def e300746068166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300746068166 : Closed e300746068166 ∧ code e300746068166 = 1400257695942 := by decide
theorem cert_e300746068166 : check e300746068166 [[]] .width = true := by decide
def e300746070042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300746070042 : Closed e300746070042 ∧ code e300746070042 = 1400257697818 := by decide
theorem cert_e300746070042 : check e300746070042 [[]] .width = true := by decide
def e300746074138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300746074138 : Closed e300746074138 ∧ code e300746074138 = 1400257701914 := by decide
theorem cert_e300746074138 : check e300746074138 [[]] .width = true := by decide
def e300746080454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300746080454 : Closed e300746080454 ∧ code e300746080454 = 1400257708230 := by decide
theorem cert_e300746080454 : check e300746080454 [[]] .width = true := by decide
def e300746080982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e300746080982 : Closed e300746080982 ∧ code e300746080982 = 1400257708758 := by decide
theorem cert_e300746080982 : check e300746080982 [[]] .width = true := by decide
def e300746080986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e300746080986 : Closed e300746080986 ∧ code e300746080986 = 1400257708762 := by decide
theorem cert_e300746080986 : check e300746080986 [[]] .width = true := by decide
def e300746081002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e300746081002 : Closed e300746081002 ∧ code e300746081002 = 1400257708778 := by decide
theorem cert_e300746081002 : check e300746081002 [[]] .width = true := by decide
def e300746081078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e300746081078 : Closed e300746081078 ∧ code e300746081078 = 1400257708854 := by decide
theorem cert_e300746081078 : check e300746081078 [[]] .width = true := by decide
def e300746081082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e300746081082 : Closed e300746081082 ∧ code e300746081082 = 1400257708858 := by decide
theorem cert_e300746081082 : check e300746081082 [[]] .width = true := by decide
def e300746081166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e300746081166 : Closed e300746081166 ∧ code e300746081166 = 1400257708942 := by decide
theorem cert_e300746081166 : check e300746081166 [[]] .width = true := by decide
def e300746081178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e300746081178 : Closed e300746081178 ∧ code e300746081178 = 1400257708954 := by decide
theorem cert_e300746081178 : check e300746081178 [[]] .width = true := by decide
def e300746083098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e300746083098 : Closed e300746083098 ∧ code e300746083098 = 1400257710874 := by decide
theorem cert_e300746083098 : check e300746083098 [[]] .width = true := by decide
end Blc.Floor40
