import R302824804150V0
import R302824804150K0
import R302824804150st0
import R302824804150hs0
import CodeBridge
import Batch060
namespace Certgen.R302824804150
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 142,.app 2 133,.app 3 35,.lam 4,.app 5 17,.lam 6,.lam 7,.app 8 9,.var 1,.lam 10,.app 11 12,.var 2,.app 13 14,.var 2,.app 15 16,.var 0,.var 1,.app 18 30,.lam 19,.lam 20,.app 21 22,.var 1,.lam 23,.app 24 25,.var 2,.app 26 27,.var 2,.app 28 29,.var 0,.var 1,.app 31 32,.var 0,.lam 33,.lam 34,.var 0,.lam 36,.app 37 69,.lam 38,.app 39 51,.lam 40,.lam 41,.app 42 43,.var 1,.lam 44,.app 45 46,.var 2,.app 47 48,.var 2,.app 49 50,.var 0,.var 1,.app 52 64,.lam 53,.lam 54,.app 55 56,.var 1,.lam 57,.app 58 59,.var 2,.app 60 61,.var 2,.app 62 63,.var 0,.var 1,.app 65 66,.var 0,.lam 67,.lam 68,.var 0,.app 70 102,.lam 71,.app 72 84,.lam 73,.lam 74,.app 75 76,.var 1,.lam 77,.app 78 79,.var 2,.app 80 81,.var 2,.app 82 83,.var 0,.var 1,.app 85 97,.lam 86,.lam 87,.app 88 89,.var 1,.lam 90,.app 91 92,.var 2,.app 93 94,.var 2,.app 95 96,.var 0,.var 1,.app 98 99,.var 0,.lam 100,.lam 101,.var 0,.app 103 104,.var 0,.lam 105,.app 106 111,.app 107 108,.var 0,.lam 109,.lam 110,.var 1,.lam 112,.app 113 118,.app 114 115,.var 0,.lam 116,.lam 117,.var 1,.lam 119,.app 120 125,.app 121 122,.var 0,.lam 123,.lam 124,.var 0,.lam 126,.app 127 132,.app 128 129,.var 0,.lam 130,.lam 131,.var 1,.opaque,.app 134 138,.lam 135,.app 136 137,.var 0,.var 0,.lam 139,.app 140 141,.var 0,.var 0,.app 143 147,.lam 144,.app 145 146,.var 0,.var 0,.lam 148,.app 149 150,.var 0,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (V20[i-20]?.getD []))
def K (i : Nat) : List Frame := (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD []))
def st (i : Nat) : AState := if i < 95 then (if i < 40 then (if i < 20 then (st0[i-0]?.getD entry) else (st20[i-20]?.getD entry)) else (if i < 60 then (st40[i-40]?.getD entry) else (if i < 80 then (st60[i-60]?.getD entry) else (st80[i-80]?.getD entry)))) else entry
def hs (i : Nat) : List Nat := (if i < 40 then (if i < 20 then (hs0[i-0]?.getD []) else (hs20[i-20]?.getD [])) else (if i < 60 then (hs40[i-40]?.getD []) else (if i < 80 then (hs60[i-60]?.getD []) else (hs80[i-80]?.getD []))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R302824804150
