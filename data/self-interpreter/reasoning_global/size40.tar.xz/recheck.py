"""Rebuild just the proof dependency closure into an empty object directory."""
import csv
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import tempfile
import time

base = Path(__file__).resolve().parent
repo = base.parents[2]
prefix = Path.home()/'.elan/toolchains'/(repo/'lean/lean-toolchain').read_text().strip().replace('/','--').replace(':','---')
rows = json.loads((base/'ledger.json').read_text())
complete = [r for r in rows if r['strength'] == 'complete']
roots = ['Residuals'] + sorted({r['module'] for r in rows})
audit = ''.join(f'import {m}\n' for m in roots) + ''.join(f'#print axioms {r["theorem"]}\n' for r in complete)
(base/'Audit40.lean').write_text(audit)
order = []
seen = set()
def visit(module):
    if module in seen:
        return
    seen.add(module)
    for name in re.findall(r'^import ([\w.]+)', (base/(module+'.lean')).read_text(), re.M):
        if (base/(name+'.lean')).is_file():
            visit(name)
    order.append(module)
visit('Audit40')
start = time.monotonic()
metrics = []
with tempfile.TemporaryDirectory(prefix='replay-',dir=base) as out:
    out = Path(out)
    env = dict(os.environ,LEAN_PATH=os.pathsep.join(map(str,[out,repo/'lean/.lake/build/lib/lean',prefix/'lib/lean'])),LEAN_NUM_THREADS='2')
    for module in order:
        ts = time.monotonic()
        with (out/(module+'.log')).open('w') as log:
            p = subprocess.Popen([str(prefix/'bin/lean'),'-j2','-M','900','--root='+str(base),str(base/(module+'.lean')),'-o',str(out/(module+'.olean'))],env=env,cwd=out,stdout=log,stderr=log)
            signal.signal(signal.SIGALRM,lambda *_:p.kill())
            signal.alarm(max(1,min(120, int(575-(ts-start)))))
            _,st,usage=os.wait4(p.pid,0)
            signal.alarm(0)
            p.returncode=os.waitstatus_to_exitcode(st)
        if p.returncode:
            raise SystemExit(module+' failed: '+(out/(module+'.log')).read_text()[-3500:])
        metrics.append(dict(module=module,seconds=round(time.monotonic()-ts,4),rss_bytes=usage.ru_maxrss))
        if len(metrics)%50==0:print(len(metrics),'/',len(order),flush=True)
    text=(out/'Audit40.log').read_text()
    (base/'Audit40.log').write_text(text)
    axioms = dict(re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",text))
    assert len(axioms)==len(complete)==306
    for filename,selected in [('complete.tsv',complete),('residuals.tsv',[r for r in complete if not r['kind'].startswith('W')])]:
        with (base/filename).open('w') as f:
            w=csv.writer(f,delimiter='\t',lineterminator='\n')
            w.writerow(['wire','kind','file','theorem','statement','axioms'])
            for r in selected:
                n=r['theorem']
                assert set(axioms[n].split(', ')) <= {'propext','Classical.choice','Quot.sound'}
                w.writerow([r['wire'],r['kind'],r['module']+'.lean',n,'¬ Blc.IsSelfInterpreter Blc.Floor40.e'+str(int(r['wire'],2)),axioms[n]])
result=dict(seconds=round(time.monotonic()-start,3),modules=len(order),peak_rss_bytes=max(v['rss_bytes'] for v in metrics),rows=metrics)
(base/'recheck.json').write_text(json.dumps(result,indent=1)+'\n')
print({k:v for k,v in result.items() if k!='rows'})
