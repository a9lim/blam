import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e301100742454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e301100742454 : Closed e301100742454 ∧ code e301100742454 = 1400612370230 := by decide
theorem cert_e301100742454 : check e301100742454 [[],[]] .chain = true := by decide
def e301100742458 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e301100742458 : Closed e301100742458 ∧ code e301100742458 = 1400612370234 := by decide
theorem cert_e301100742458 : check e301100742458 [[],[]] .chain = true := by decide
def e301100743086 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e301100743086 : Closed e301100743086 ∧ code e301100743086 = 1400612370862 := by decide
theorem cert_e301100743086 : check e301100743086 [[],[]] .chain = true := by decide
def e301100743098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e301100743098 : Closed e301100743098 ∧ code e301100743098 = 1400612370874 := by decide
theorem cert_e301100743098 : check e301100743098 [[],[]] .chain = true := by decide
def e301100743146 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e301100743146 : Closed e301100743146 ∧ code e301100743146 = 1400612370922 := by decide
theorem cert_e301100743146 : check e301100743146 [[],[]] .chain = true := by decide
def e301100743278 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e301100743278 : Closed e301100743278 ∧ code e301100743278 = 1400612371054 := by decide
theorem cert_e301100743278 : check e301100743278 [[],[]] .chain = true := by decide
def e301100743290 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e301100743290 : Closed e301100743290 ∧ code e301100743290 = 1400612371066 := by decide
theorem cert_e301100743290 : check e301100743290 [[],[]] .chain = true := by decide
def e301100743578 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e301100743578 : Closed e301100743578 ∧ code e301100743578 = 1400612371354 := by decide
theorem cert_e301100743578 : check e301100743578 [[],[]] .chain = true := by decide
def e301100743894 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e301100743894 : Closed e301100743894 ∧ code e301100743894 = 1400612371670 := by decide
theorem cert_e301100743894 : check e301100743894 [[],[]] .chain = true := by decide
def e301100743898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e301100743898 : Closed e301100743898 ∧ code e301100743898 = 1400612371674 := by decide
theorem cert_e301100743898 : check e301100743898 [[],[]] .chain = true := by decide
def e301100743914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e301100743914 : Closed e301100743914 ∧ code e301100743914 = 1400612371690 := by decide
theorem cert_e301100743914 : check e301100743914 [[],[]] .chain = true := by decide
def e301100743990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e301100743990 : Closed e301100743990 ∧ code e301100743990 = 1400612371766 := by decide
theorem cert_e301100743990 : check e301100743990 [[],[]] .chain = true := by decide
def e301100743994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e301100743994 : Closed e301100743994 ∧ code e301100743994 = 1400612371770 := by decide
theorem cert_e301100743994 : check e301100743994 [[],[]] .chain = true := by decide
def e301100744090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e301100744090 : Closed e301100744090 ∧ code e301100744090 = 1400612371866 := by decide
theorem cert_e301100744090 : check e301100744090 [[],[]] .chain = true := by decide
def e301100747630 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e301100747630 : Closed e301100747630 ∧ code e301100747630 = 1400612375406 := by decide
theorem cert_e301100747630 : check e301100747630 [[],[]] .chain = true := by decide
def e301100747638 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e301100747638 : Closed e301100747638 ∧ code e301100747638 = 1400612375414 := by decide
theorem cert_e301100747638 : check e301100747638 [[],[]] .chain = true := by decide
def e301100747694 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e301100747694 : Closed e301100747694 ∧ code e301100747694 = 1400612375470 := by decide
theorem cert_e301100747694 : check e301100747694 [[],[]] .chain = true := by decide
def e301100747706 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e301100747706 : Closed e301100747706 ∧ code e301100747706 = 1400612375482 := by decide
theorem cert_e301100747706 : check e301100747706 [[],[]] .chain = true := by decide
def e301100747734 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e301100747734 : Closed e301100747734 ∧ code e301100747734 = 1400612375510 := by decide
theorem cert_e301100747734 : check e301100747734 [[],[]] .chain = true := by decide
def e301100747738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e301100747738 : Closed e301100747738 ∧ code e301100747738 = 1400612375514 := by decide
theorem cert_e301100747738 : check e301100747738 [[],[]] .chain = true := by decide
def e301100748014 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e301100748014 : Closed e301100748014 ∧ code e301100748014 = 1400612375790 := by decide
theorem cert_e301100748014 : check e301100748014 [[],[]] .chain = true := by decide
def e301100748022 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e301100748022 : Closed e301100748022 ∧ code e301100748022 = 1400612375798 := by decide
theorem cert_e301100748022 : check e301100748022 [[],[]] .chain = true := by decide
def e301100748398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e301100748398 : Closed e301100748398 ∧ code e301100748398 = 1400612376174 := by decide
theorem cert_e301100748398 : check e301100748398 [[],[]] .chain = true := by decide
def e301100748410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e301100748410 : Closed e301100748410 ∧ code e301100748410 = 1400612376186 := by decide
theorem cert_e301100748410 : check e301100748410 [[],[]] .chain = true := by decide
def e301100748598 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e301100748598 : Closed e301100748598 ∧ code e301100748598 = 1400612376374 := by decide
theorem cert_e301100748598 : check e301100748598 [[],[]] .chain = true := by decide
def e301100748602 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e301100748602 : Closed e301100748602 ∧ code e301100748602 = 1400612376378 := by decide
theorem cert_e301100748602 : check e301100748602 [[],[]] .chain = true := by decide
def e301100754350 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e301100754350 : Closed e301100754350 ∧ code e301100754350 = 1400612382126 := by decide
theorem cert_e301100754350 : check e301100754350 [[],[]] .chain = true := by decide
def e301100754362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e301100754362 : Closed e301100754362 ∧ code e301100754362 = 1400612382138 := by decide
theorem cert_e301100754362 : check e301100754362 [[],[]] .chain = true := by decide
def e301100754410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e301100754410 : Closed e301100754410 ∧ code e301100754410 = 1400612382186 := by decide
theorem cert_e301100754410 : check e301100754410 [[],[]] .chain = true := by decide
def e301100754542 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e301100754542 : Closed e301100754542 ∧ code e301100754542 = 1400612382318 := by decide
theorem cert_e301100754542 : check e301100754542 [[],[]] .chain = true := by decide
def e301100754554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e301100754554 : Closed e301100754554 ∧ code e301100754554 = 1400612382330 := by decide
theorem cert_e301100754554 : check e301100754554 [[],[]] .chain = true := by decide
def e301100754842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e301100754842 : Closed e301100754842 ∧ code e301100754842 = 1400612382618 := by decide
theorem cert_e301100754842 : check e301100754842 [[],[]] .chain = true := by decide
def e301100757718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e301100757718 : Closed e301100757718 ∧ code e301100757718 = 1400612385494 := by decide
theorem cert_e301100757718 : check e301100757718 [[],[]] .chain = true := by decide
def e301100757722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e301100757722 : Closed e301100757722 ∧ code e301100757722 = 1400612385498 := by decide
theorem cert_e301100757722 : check e301100757722 [[],[]] .chain = true := by decide
def e301100757738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e301100757738 : Closed e301100757738 ∧ code e301100757738 = 1400612385514 := by decide
theorem cert_e301100757738 : check e301100757738 [[],[]] .chain = true := by decide
def e301100757814 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e301100757814 : Closed e301100757814 ∧ code e301100757814 = 1400612385590 := by decide
theorem cert_e301100757814 : check e301100757814 [[],[]] .chain = true := by decide
def e301100757818 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e301100757818 : Closed e301100757818 ∧ code e301100757818 = 1400612385594 := by decide
theorem cert_e301100757818 : check e301100757818 [[],[]] .chain = true := by decide
def e301100757914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e301100757914 : Closed e301100757914 ∧ code e301100757914 = 1400612385690 := by decide
theorem cert_e301100757914 : check e301100757914 [[],[]] .chain = true := by decide
def e301100895086 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e301100895086 : Closed e301100895086 ∧ code e301100895086 = 1400612522862 := by decide
theorem cert_e301100895086 : check e301100895086 [[],[]] .chain = true := by decide
def e301100895094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e301100895094 : Closed e301100895094 ∧ code e301100895094 = 1400612522870 := by decide
theorem cert_e301100895094 : check e301100895094 [[],[]] .chain = true := by decide
def e301100895150 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e301100895150 : Closed e301100895150 ∧ code e301100895150 = 1400612522926 := by decide
theorem cert_e301100895150 : check e301100895150 [[],[]] .chain = true := by decide
def e301100895162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e301100895162 : Closed e301100895162 ∧ code e301100895162 = 1400612522938 := by decide
theorem cert_e301100895162 : check e301100895162 [[],[]] .chain = true := by decide
def e301100895190 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e301100895190 : Closed e301100895190 ∧ code e301100895190 = 1400612522966 := by decide
theorem cert_e301100895190 : check e301100895190 [[],[]] .chain = true := by decide
def e301100895194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e301100895194 : Closed e301100895194 ∧ code e301100895194 = 1400612522970 := by decide
theorem cert_e301100895194 : check e301100895194 [[],[]] .chain = true := by decide
def e301100895470 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e301100895470 : Closed e301100895470 ∧ code e301100895470 = 1400612523246 := by decide
theorem cert_e301100895470 : check e301100895470 [[],[]] .chain = true := by decide
def e301100895478 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e301100895478 : Closed e301100895478 ∧ code e301100895478 = 1400612523254 := by decide
theorem cert_e301100895478 : check e301100895478 [[],[]] .chain = true := by decide
def e301100895854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e301100895854 : Closed e301100895854 ∧ code e301100895854 = 1400612523630 := by decide
theorem cert_e301100895854 : check e301100895854 [[],[]] .chain = true := by decide
def e301100895866 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e301100895866 : Closed e301100895866 ∧ code e301100895866 = 1400612523642 := by decide
theorem cert_e301100895866 : check e301100895866 [[],[]] .chain = true := by decide
def e301100896054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e301100896054 : Closed e301100896054 ∧ code e301100896054 = 1400612523830 := by decide
theorem cert_e301100896054 : check e301100896054 [[],[]] .chain = true := by decide
def e301100896058 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e301100896058 : Closed e301100896058 ∧ code e301100896058 = 1400612523834 := by decide
theorem cert_e301100896058 : check e301100896058 [[],[]] .chain = true := by decide
def e301101484910 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e301101484910 : Closed e301101484910 ∧ code e301101484910 = 1400613112686 := by decide
theorem cert_e301101484910 : check e301101484910 [[],[],[],[]] .sourceHead = true := by decide
def e301101484918 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e301101484918 : Closed e301101484918 ∧ code e301101484918 = 1400613112694 := by decide
theorem cert_e301101484918 : check e301101484918 [[],[],[],[]] .sourceHead = true := by decide
def e301101484974 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e301101484974 : Closed e301101484974 ∧ code e301101484974 = 1400613112750 := by decide
theorem cert_e301101484974 : check e301101484974 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e301101484986 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e301101484986 : Closed e301101484986 ∧ code e301101484986 = 1400613112762 := by decide
private def t_e301101484986 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e301101484986 : ¬ IsSelfInterpreter e301101484986 :=
  wSource (t := t_e301101484986) (replay_sound (ps := []) (t := e301101484986) (by decide)) (by decide)
def e301101485014 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e301101485014 : Closed e301101485014 ∧ code e301101485014 = 1400613112790 := by decide
theorem cert_e301101485014 : check e301101485014 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e301101485018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e301101485018 : Closed e301101485018 ∧ code e301101485018 = 1400613112794 := by decide
private def t_e301101485018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e301101485018 : ¬ IsSelfInterpreter e301101485018 :=
  wSource (t := t_e301101485018) (replay_sound (ps := []) (t := e301101485018) (by decide)) (by decide)
def e301101485294 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e301101485294 : Closed e301101485294 ∧ code e301101485294 = 1400613113070 := by decide
theorem cert_e301101485294 : check e301101485294 [[],[],[],[]] .sourceHead = true := by decide
def e301101485302 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e301101485302 : Closed e301101485302 ∧ code e301101485302 = 1400613113078 := by decide
theorem cert_e301101485302 : check e301101485302 [[],[],[],[]] .sourceHead = true := by decide
def e301101485678 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e301101485678 : Closed e301101485678 ∧ code e301101485678 = 1400613113454 := by decide
theorem cert_e301101485678 : check e301101485678 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e301101485690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e301101485690 : Closed e301101485690 ∧ code e301101485690 = 1400613113466 := by decide
theorem cert_e301101485690 : check e301101485690 [[],[],[],[],[.under],[.under,.left]] .sourceHead = true := by decide
def e301101485878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e301101485878 : Closed e301101485878 ∧ code e301101485878 = 1400613113654 := by decide
theorem cert_e301101485878 : check e301101485878 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e301101485882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e301101485882 : Closed e301101485882 ∧ code e301101485882 = 1400613113658 := by decide
theorem cert_e301101485882 : check e301101485882 [[],[],[],[],[.under],[.under,.left]] .chain = true := by decide
def e301120469018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e301120469018 : Closed e301120469018 ∧ code e301120469018 = 1400632096794 := by decide
theorem cert_e301120469018 : check e301120469018 [[]] .width = true := by decide
def e301120477210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e301120477210 : Closed e301120477210 ∧ code e301120477210 = 1400632104986 := by decide
theorem cert_e301120477210 : check e301120477210 [[]] .width = true := by decide
def e301120534554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e301120534554 : Closed e301120534554 ∧ code e301120534554 = 1400632162330 := by decide
theorem cert_e301120534554 : check e301120534554 [[]] .width = true := by decide
def e301120546842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e301120546842 : Closed e301120546842 ∧ code e301120546842 = 1400632174618 := by decide
theorem cert_e301120546842 : check e301120546842 [[]] .width = true := by decide
def e301120575514 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e301120575514 : Closed e301120575514 ∧ code e301120575514 = 1400632203290 := by decide
theorem cert_e301120575514 : check e301120575514 [[]] .width = true := by decide
def e301120579610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e301120579610 : Closed e301120579610 ∧ code e301120579610 = 1400632207386 := by decide
theorem cert_e301120579610 : check e301120579610 [[]] .width = true := by decide
def e301120862234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e301120862234 : Closed e301120862234 ∧ code e301120862234 = 1400632490010 := by decide
theorem cert_e301120862234 : check e301120862234 [[]] .width = true := by decide
def e301120870426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e301120870426 : Closed e301120870426 ∧ code e301120870426 = 1400632498202 := by decide
theorem cert_e301120870426 : check e301120870426 [[]] .width = true := by decide
def e301121255450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e301121255450 : Closed e301121255450 ∧ code e301121255450 = 1400632883226 := by decide
theorem cert_e301121255450 : check e301121255450 [[]] .width = true := by decide
def e301121267738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e301121267738 : Closed e301121267738 ∧ code e301121267738 = 1400632895514 := by decide
theorem cert_e301121267738 : check e301121267738 [[]] .width = true := by decide
def e301121460250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e301121460250 : Closed e301121460250 ∧ code e301121460250 = 1400633088026 := by decide
theorem cert_e301121460250 : check e301121460250 [[]] .width = true := by decide
def e301121464346 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e301121464346 : Closed e301121464346 ∧ code e301121464346 = 1400633092122 := by decide
theorem cert_e301121464346 : check e301121464346 [[]] .width = true := by decide
def e301134294382 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e301134294382 : Closed e301134294382 ∧ code e301134294382 = 1400645922158 := by decide
theorem cert_e301134294382 : check e301134294382 [[],[]] .chain = true := by decide
def e301134294390 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e301134294390 : Closed e301134294390 ∧ code e301134294390 = 1400645922166 := by decide
theorem cert_e301134294390 : check e301134294390 [[],[]] .chain = true := by decide
def e301134294446 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e301134294446 : Closed e301134294446 ∧ code e301134294446 = 1400645922222 := by decide
theorem cert_e301134294446 : check e301134294446 [[],[]] .chain = true := by decide
def e301134294458 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e301134294458 : Closed e301134294458 ∧ code e301134294458 = 1400645922234 := by decide
theorem cert_e301134294458 : check e301134294458 [[],[]] .chain = true := by decide
def e301134294486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e301134294486 : Closed e301134294486 ∧ code e301134294486 = 1400645922262 := by decide
theorem cert_e301134294486 : check e301134294486 [[],[]] .chain = true := by decide
def e301134294490 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e301134294490 : Closed e301134294490 ∧ code e301134294490 = 1400645922266 := by decide
theorem cert_e301134294490 : check e301134294490 [[],[]] .chain = true := by decide
def e301134294702 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e301134294702 : Closed e301134294702 ∧ code e301134294702 = 1400645922478 := by decide
theorem cert_e301134294702 : check e301134294702 [[],[]] .chain = true := by decide
def e301134294714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e301134294714 : Closed e301134294714 ∧ code e301134294714 = 1400645922490 := by decide
theorem cert_e301134294714 : check e301134294714 [[],[]] .chain = true := by decide
def e301134294762 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e301134294762 : Closed e301134294762 ∧ code e301134294762 = 1400645922538 := by decide
theorem cert_e301134294762 : check e301134294762 [[],[]] .chain = true := by decide
def e301134294870 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e301134294870 : Closed e301134294870 ∧ code e301134294870 = 1400645922646 := by decide
theorem cert_e301134294870 : check e301134294870 [[],[]] .chain = true := by decide
def e301134294874 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e301134294874 : Closed e301134294874 ∧ code e301134294874 = 1400645922650 := by decide
theorem cert_e301134294874 : check e301134294874 [[],[]] .chain = true := by decide
def e301134294890 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e301134294890 : Closed e301134294890 ∧ code e301134294890 = 1400645922666 := by decide
theorem cert_e301134294890 : check e301134294890 [[],[]] .chain = true := by decide
def e301134295918 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e301134295918 : Closed e301134295918 ∧ code e301134295918 = 1400645923694 := by decide
theorem cert_e301134295918 : check e301134295918 [[],[]] .chain = true := by decide
def e301134295926 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e301134295926 : Closed e301134295926 ∧ code e301134295926 = 1400645923702 := by decide
theorem cert_e301134295926 : check e301134295926 [[],[]] .chain = true := by decide
def e301134295982 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e301134295982 : Closed e301134295982 ∧ code e301134295982 = 1400645923758 := by decide
theorem cert_e301134295982 : check e301134295982 [[],[]] .chain = true := by decide
def e301134295994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e301134295994 : Closed e301134295994 ∧ code e301134295994 = 1400645923770 := by decide
theorem cert_e301134295994 : check e301134295994 [[],[]] .chain = true := by decide
def e301134296022 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e301134296022 : Closed e301134296022 ∧ code e301134296022 = 1400645923798 := by decide
theorem cert_e301134296022 : check e301134296022 [[],[]] .chain = true := by decide
def e301134296026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e301134296026 : Closed e301134296026 ∧ code e301134296026 = 1400645923802 := by decide
theorem cert_e301134296026 : check e301134296026 [[],[]] .chain = true := by decide
def e301134296302 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e301134296302 : Closed e301134296302 ∧ code e301134296302 = 1400645924078 := by decide
theorem cert_e301134296302 : check e301134296302 [[],[]] .chain = true := by decide
def e301134296310 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e301134296310 : Closed e301134296310 ∧ code e301134296310 = 1400645924086 := by decide
theorem cert_e301134296310 : check e301134296310 [[],[]] .chain = true := by decide
def e301134296686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e301134296686 : Closed e301134296686 ∧ code e301134296686 = 1400645924462 := by decide
theorem cert_e301134296686 : check e301134296686 [[],[]] .chain = true := by decide
def e301134296698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e301134296698 : Closed e301134296698 ∧ code e301134296698 = 1400645924474 := by decide
theorem cert_e301134296698 : check e301134296698 [[],[]] .chain = true := by decide
def e301134296886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e301134296886 : Closed e301134296886 ∧ code e301134296886 = 1400645924662 := by decide
theorem cert_e301134296886 : check e301134296886 [[],[]] .chain = true := by decide
def e301134296890 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e301134296890 : Closed e301134296890 ∧ code e301134296890 = 1400645924666 := by decide
theorem cert_e301134296890 : check e301134296890 [[],[]] .chain = true := by decide
def e301134297518 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e301134297518 : Closed e301134297518 ∧ code e301134297518 = 1400645925294 := by decide
theorem cert_e301134297518 : check e301134297518 [[],[]] .chain = true := by decide
def e301134297530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e301134297530 : Closed e301134297530 ∧ code e301134297530 = 1400645925306 := by decide
theorem cert_e301134297530 : check e301134297530 [[],[]] .chain = true := by decide
def e301134297578 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e301134297578 : Closed e301134297578 ∧ code e301134297578 = 1400645925354 := by decide
theorem cert_e301134297578 : check e301134297578 [[],[]] .chain = true := by decide
def e301134297710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e301134297710 : Closed e301134297710 ∧ code e301134297710 = 1400645925486 := by decide
theorem cert_e301134297710 : check e301134297710 [[],[]] .chain = true := by decide
def e301134297722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e301134297722 : Closed e301134297722 ∧ code e301134297722 = 1400645925498 := by decide
theorem cert_e301134297722 : check e301134297722 [[],[]] .chain = true := by decide
def e301134298010 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e301134298010 : Closed e301134298010 ∧ code e301134298010 = 1400645925786 := by decide
theorem cert_e301134298010 : check e301134298010 [[],[]] .chain = true := by decide
def e301134298326 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e301134298326 : Closed e301134298326 ∧ code e301134298326 = 1400645926102 := by decide
theorem cert_e301134298326 : check e301134298326 [[],[]] .chain = true := by decide
def e301134298330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e301134298330 : Closed e301134298330 ∧ code e301134298330 = 1400645926106 := by decide
theorem cert_e301134298330 : check e301134298330 [[],[]] .chain = true := by decide
def e301134298346 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e301134298346 : Closed e301134298346 ∧ code e301134298346 = 1400645926122 := by decide
theorem cert_e301134298346 : check e301134298346 [[],[]] .chain = true := by decide
def e301134298422 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e301134298422 : Closed e301134298422 ∧ code e301134298422 = 1400645926198 := by decide
theorem cert_e301134298422 : check e301134298422 [[],[]] .chain = true := by decide
def e301134298426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e301134298426 : Closed e301134298426 ∧ code e301134298426 = 1400645926202 := by decide
theorem cert_e301134298426 : check e301134298426 [[],[]] .chain = true := by decide
def e301134298522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e301134298522 : Closed e301134298522 ∧ code e301134298522 = 1400645926298 := by decide
theorem cert_e301134298522 : check e301134298522 [[],[]] .chain = true := by decide
def e301134302062 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e301134302062 : Closed e301134302062 ∧ code e301134302062 = 1400645929838 := by decide
theorem cert_e301134302062 : check e301134302062 [[],[]] .chain = true := by decide
def e301134302070 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e301134302070 : Closed e301134302070 ∧ code e301134302070 = 1400645929846 := by decide
theorem cert_e301134302070 : check e301134302070 [[],[]] .chain = true := by decide
def e301134302126 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e301134302126 : Closed e301134302126 ∧ code e301134302126 = 1400645929902 := by decide
theorem cert_e301134302126 : check e301134302126 [[],[]] .chain = true := by decide
def e301134302138 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e301134302138 : Closed e301134302138 ∧ code e301134302138 = 1400645929914 := by decide
theorem cert_e301134302138 : check e301134302138 [[],[]] .chain = true := by decide
def e301134302166 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e301134302166 : Closed e301134302166 ∧ code e301134302166 = 1400645929942 := by decide
theorem cert_e301134302166 : check e301134302166 [[],[]] .chain = true := by decide
def e301134302170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e301134302170 : Closed e301134302170 ∧ code e301134302170 = 1400645929946 := by decide
theorem cert_e301134302170 : check e301134302170 [[],[]] .chain = true := by decide
def e301134302446 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e301134302446 : Closed e301134302446 ∧ code e301134302446 = 1400645930222 := by decide
theorem cert_e301134302446 : check e301134302446 [[],[]] .chain = true := by decide
def e301134302454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e301134302454 : Closed e301134302454 ∧ code e301134302454 = 1400645930230 := by decide
theorem cert_e301134302454 : check e301134302454 [[],[]] .chain = true := by decide
def e301134302830 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e301134302830 : Closed e301134302830 ∧ code e301134302830 = 1400645930606 := by decide
theorem cert_e301134302830 : check e301134302830 [[],[]] .chain = true := by decide
def e301134302842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e301134302842 : Closed e301134302842 ∧ code e301134302842 = 1400645930618 := by decide
theorem cert_e301134302842 : check e301134302842 [[],[]] .chain = true := by decide
def e301134303030 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e301134303030 : Closed e301134303030 ∧ code e301134303030 = 1400645930806 := by decide
theorem cert_e301134303030 : check e301134303030 [[],[]] .chain = true := by decide
def e301134303034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e301134303034 : Closed e301134303034 ∧ code e301134303034 = 1400645930810 := by decide
theorem cert_e301134303034 : check e301134303034 [[],[]] .chain = true := by decide
def e301134308782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e301134308782 : Closed e301134308782 ∧ code e301134308782 = 1400645936558 := by decide
theorem cert_e301134308782 : check e301134308782 [[],[]] .chain = true := by decide
def e301134308794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e301134308794 : Closed e301134308794 ∧ code e301134308794 = 1400645936570 := by decide
theorem cert_e301134308794 : check e301134308794 [[],[]] .chain = true := by decide
def e301134308842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e301134308842 : Closed e301134308842 ∧ code e301134308842 = 1400645936618 := by decide
theorem cert_e301134308842 : check e301134308842 [[],[]] .chain = true := by decide
def e301134308974 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e301134308974 : Closed e301134308974 ∧ code e301134308974 = 1400645936750 := by decide
theorem cert_e301134308974 : check e301134308974 [[],[]] .chain = true := by decide
def e301134308986 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e301134308986 : Closed e301134308986 ∧ code e301134308986 = 1400645936762 := by decide
theorem cert_e301134308986 : check e301134308986 [[],[]] .chain = true := by decide
def e301134309274 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e301134309274 : Closed e301134309274 ∧ code e301134309274 = 1400645937050 := by decide
theorem cert_e301134309274 : check e301134309274 [[],[]] .chain = true := by decide
def e301134312150 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e301134312150 : Closed e301134312150 ∧ code e301134312150 = 1400645939926 := by decide
theorem cert_e301134312150 : check e301134312150 [[],[]] .chain = true := by decide
def e301134312154 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e301134312154 : Closed e301134312154 ∧ code e301134312154 = 1400645939930 := by decide
theorem cert_e301134312154 : check e301134312154 [[],[]] .chain = true := by decide
def e301134312170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e301134312170 : Closed e301134312170 ∧ code e301134312170 = 1400645939946 := by decide
theorem cert_e301134312170 : check e301134312170 [[],[]] .chain = true := by decide
def e301134312246 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e301134312246 : Closed e301134312246 ∧ code e301134312246 = 1400645940022 := by decide
theorem cert_e301134312246 : check e301134312246 [[],[]] .chain = true := by decide
def e301134312250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e301134312250 : Closed e301134312250 ∧ code e301134312250 = 1400645940026 := by decide
theorem cert_e301134312250 : check e301134312250 [[],[]] .chain = true := by decide
def e301134312346 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e301134312346 : Closed e301134312346 ∧ code e301134312346 = 1400645940122 := by decide
theorem cert_e301134312346 : check e301134312346 [[],[]] .chain = true := by decide
def e301134449518 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e301134449518 : Closed e301134449518 ∧ code e301134449518 = 1400646077294 := by decide
theorem cert_e301134449518 : check e301134449518 [[],[]] .chain = true := by decide
def e301134449526 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e301134449526 : Closed e301134449526 ∧ code e301134449526 = 1400646077302 := by decide
theorem cert_e301134449526 : check e301134449526 [[],[]] .chain = true := by decide
def e301134449582 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e301134449582 : Closed e301134449582 ∧ code e301134449582 = 1400646077358 := by decide
theorem cert_e301134449582 : check e301134449582 [[],[]] .chain = true := by decide
def e301134449594 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e301134449594 : Closed e301134449594 ∧ code e301134449594 = 1400646077370 := by decide
theorem cert_e301134449594 : check e301134449594 [[],[]] .chain = true := by decide
def e301134449622 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e301134449622 : Closed e301134449622 ∧ code e301134449622 = 1400646077398 := by decide
theorem cert_e301134449622 : check e301134449622 [[],[]] .chain = true := by decide
def e301134449626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e301134449626 : Closed e301134449626 ∧ code e301134449626 = 1400646077402 := by decide
theorem cert_e301134449626 : check e301134449626 [[],[]] .chain = true := by decide
def e301134449902 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e301134449902 : Closed e301134449902 ∧ code e301134449902 = 1400646077678 := by decide
theorem cert_e301134449902 : check e301134449902 [[],[]] .chain = true := by decide
def e301134449910 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e301134449910 : Closed e301134449910 ∧ code e301134449910 = 1400646077686 := by decide
theorem cert_e301134449910 : check e301134449910 [[],[]] .chain = true := by decide
def e301134450286 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e301134450286 : Closed e301134450286 ∧ code e301134450286 = 1400646078062 := by decide
theorem cert_e301134450286 : check e301134450286 [[],[]] .chain = true := by decide
def e301134450298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e301134450298 : Closed e301134450298 ∧ code e301134450298 = 1400646078074 := by decide
theorem cert_e301134450298 : check e301134450298 [[],[]] .chain = true := by decide
def e301134450486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e301134450486 : Closed e301134450486 ∧ code e301134450486 = 1400646078262 := by decide
theorem cert_e301134450486 : check e301134450486 [[],[]] .chain = true := by decide
def e301134450490 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e301134450490 : Closed e301134450490 ∧ code e301134450490 = 1400646078266 := by decide
theorem cert_e301134450490 : check e301134450490 [[],[]] .chain = true := by decide
def e301135039342 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e301135039342 : Closed e301135039342 ∧ code e301135039342 = 1400646667118 := by decide
theorem cert_e301135039342 : check e301135039342 [[],[],[],[],[]] .sourceHead = true := by decide
def e301135039350 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e301135039350 : Closed e301135039350 ∧ code e301135039350 = 1400646667126 := by decide
theorem cert_e301135039350 : check e301135039350 [[],[],[],[],[]] .sourceHead = true := by decide
def e301135039406 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e301135039406 : Closed e301135039406 ∧ code e301135039406 = 1400646667182 := by decide
theorem cert_e301135039406 : check e301135039406 [[],[],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e301135039418 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e301135039418 : Closed e301135039418 ∧ code e301135039418 = 1400646667194 := by decide
private def t_e301135039418 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e301135039418 : ¬ IsSelfInterpreter e301135039418 :=
  wSource (t := t_e301135039418) (replay_sound (ps := []) (t := e301135039418) (by decide)) (by decide)
def e301135039446 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e301135039446 : Closed e301135039446 ∧ code e301135039446 = 1400646667222 := by decide
theorem cert_e301135039446 : check e301135039446 [[],[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e301135039450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e301135039450 : Closed e301135039450 ∧ code e301135039450 = 1400646667226 := by decide
private def t_e301135039450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e301135039450 : ¬ IsSelfInterpreter e301135039450 :=
  wSource (t := t_e301135039450) (replay_sound (ps := []) (t := e301135039450) (by decide)) (by decide)
def e301135039726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e301135039726 : Closed e301135039726 ∧ code e301135039726 = 1400646667502 := by decide
theorem cert_e301135039726 : check e301135039726 [[],[],[],[],[]] .sourceHead = true := by decide
def e301135039734 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e301135039734 : Closed e301135039734 ∧ code e301135039734 = 1400646667510 := by decide
theorem cert_e301135039734 : check e301135039734 [[],[],[],[],[]] .sourceHead = true := by decide
def e301135040110 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e301135040110 : Closed e301135040110 ∧ code e301135040110 = 1400646667886 := by decide
theorem cert_e301135040110 : checkPay e301135040110 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under]] = true := by decide
def e301135040122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e301135040122 : Closed e301135040122 ∧ code e301135040122 = 1400646667898 := by decide
theorem cert_e301135040122 : check e301135040122 [[],[],[],[],[],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e301135040310 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e301135040310 : Closed e301135040310 ∧ code e301135040310 = 1400646668086 := by decide
theorem cert_e301135040310 : check e301135040310 [[],[],[],[],[],[.under],[.under]] .sourceHead = true := by decide
def e301135040314 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e301135040314 : Closed e301135040314 ∧ code e301135040314 = 1400646668090 := by decide
theorem cert_e301135040314 : check e301135040314 [[],[],[],[],[],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e301453061486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e301453061486 : Closed e301453061486 ∧ code e301453061486 = 1400964689262 := by decide
theorem cert_e301453061486 : check e301453061486 [[],[]] .smaller = true := by decide
def e301453061494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e301453061494 : Closed e301453061494 ∧ code e301453061494 = 1400964689270 := by decide
theorem cert_e301453061494 : check e301453061494 [[],[]] .smaller = true := by decide
end Blc.Floor40
