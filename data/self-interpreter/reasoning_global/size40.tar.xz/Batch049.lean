import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302801381190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e302801381190 : Closed e302801381190 ∧ code e302801381190 = 1402313008966 := by decide
theorem cert_e302801381190 : check e302801381190 [[],[]] .chain = true := by decide
def e302801381218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e302801381218 : Closed e302801381218 ∧ code e302801381218 = 1402313008994 := by decide
theorem cert_e302801381218 : check e302801381218 [[],[]] .chain = true := by decide
def e302801381230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e302801381230 : Closed e302801381230 ∧ code e302801381230 = 1402313009006 := by decide
theorem cert_e302801381230 : check e302801381230 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801381238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e302801381238 : Closed e302801381238 ∧ code e302801381238 = 1402313009014 := by decide
theorem cert_e302801381238 : check e302801381238 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801381302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e302801381302 : Closed e302801381302 ∧ code e302801381302 = 1402313009078 := by decide
theorem cert_e302801381302 : check e302801381302 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801381486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e302801381486 : Closed e302801381486 ∧ code e302801381486 = 1402313009262 := by decide
theorem cert_e302801381486 : check e302801381486 [[],[]] .chain = true := by decide
def e302801381498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e302801381498 : Closed e302801381498 ∧ code e302801381498 = 1402313009274 := by decide
theorem cert_e302801381498 : check e302801381498 [[],[]] .chain = true := by decide
def e302801381774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e302801381774 : Closed e302801381774 ∧ code e302801381774 = 1402313009550 := by decide
theorem cert_e302801381774 : check e302801381774 [[],[]] .chain = true := by decide
def e302801381830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e302801381830 : Closed e302801381830 ∧ code e302801381830 = 1402313009606 := by decide
theorem cert_e302801381830 : check e302801381830 [[],[]] .chain = true := by decide
def e302801382430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 3))))))))
theorem wire_e302801382430 : Closed e302801382430 ∧ code e302801382430 = 1402313010206 := by decide
theorem cert_e302801382430 : check e302801382430 [[],[]] .chain = true := by decide
def e302801382454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e302801382454 : Closed e302801382454 ∧ code e302801382454 = 1402313010230 := by decide
theorem cert_e302801382454 : check e302801382454 [[],[]] .chain = true := by decide
def e302801382458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e302801382458 : Closed e302801382458 ∧ code e302801382458 = 1402313010234 := by decide
theorem cert_e302801382458 : check e302801382458 [[],[]] .chain = true := by decide
def e302801382598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302801382598 : Closed e302801382598 ∧ code e302801382598 = 1402313010374 := by decide
theorem cert_e302801382598 : check e302801382598 [[],[]] .chain = true := by decide
def e302801382626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e302801382626 : Closed e302801382626 ∧ code e302801382626 = 1402313010402 := by decide
theorem cert_e302801382626 : check e302801382626 [[],[]] .chain = true := by decide
def e302801382638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e302801382638 : Closed e302801382638 ∧ code e302801382638 = 1402313010414 := by decide
theorem cert_e302801382638 : check e302801382638 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801382646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e302801382646 : Closed e302801382646 ∧ code e302801382646 = 1402313010422 := by decide
theorem cert_e302801382646 : check e302801382646 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801383030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e302801383030 : Closed e302801383030 ∧ code e302801383030 = 1402313010806 := by decide
theorem cert_e302801383030 : check e302801383030 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801383542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e302801383542 : Closed e302801383542 ∧ code e302801383542 = 1402313011318 := by decide
theorem cert_e302801383542 : check e302801383542 [[],[]] .chain = true := by decide
def e302801383546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e302801383546 : Closed e302801383546 ∧ code e302801383546 = 1402313011322 := by decide
theorem cert_e302801383546 : check e302801383546 [[],[]] .chain = true := by decide
def e302801383642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e302801383642 : Closed e302801383642 ∧ code e302801383642 = 1402313011418 := by decide
theorem cert_e302801383642 : check e302801383642 [[],[]] .chain = true := by decide
def e302801383658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e302801383658 : Closed e302801383658 ∧ code e302801383658 = 1402313011434 := by decide
theorem cert_e302801383658 : check e302801383658 [[],[]] .chain = true := by decide
def e302801383734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e302801383734 : Closed e302801383734 ∧ code e302801383734 = 1402313011510 := by decide
theorem cert_e302801383734 : check e302801383734 [[],[]] .chain = true := by decide
def e302801383738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e302801383738 : Closed e302801383738 ∧ code e302801383738 = 1402313011514 := by decide
theorem cert_e302801383738 : check e302801383738 [[],[]] .chain = true := by decide
def e302801383822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e302801383822 : Closed e302801383822 ∧ code e302801383822 = 1402313011598 := by decide
theorem cert_e302801383822 : check e302801383822 [[],[]] .chain = true := by decide
def e302801383834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e302801383834 : Closed e302801383834 ∧ code e302801383834 = 1402313011610 := by decide
theorem cert_e302801383834 : check e302801383834 [[],[]] .chain = true := by decide
def e302801383878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e302801383878 : Closed e302801383878 ∧ code e302801383878 = 1402313011654 := by decide
theorem cert_e302801383878 : check e302801383878 [[],[]] .chain = true := by decide
def e302801384214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e302801384214 : Closed e302801384214 ∧ code e302801384214 = 1402313011990 := by decide
theorem cert_e302801384214 : check e302801384214 [[],[]] .chain = true := by decide
def e302801384218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.var 0))))))
theorem wire_e302801384218 : Closed e302801384218 ∧ code e302801384218 = 1402313011994 := by decide
theorem cert_e302801384218 : check e302801384218 [[],[]] .chain = true := by decide
def e302801384262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e302801384262 : Closed e302801384262 ∧ code e302801384262 = 1402313012038 := by decide
theorem cert_e302801384262 : check e302801384262 [[],[]] .chain = true := by decide
def e302801384290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e302801384290 : Closed e302801384290 ∧ code e302801384290 = 1402313012066 := by decide
theorem cert_e302801384290 : check e302801384290 [[],[]] .chain = true := by decide
def e302801384302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e302801384302 : Closed e302801384302 ∧ code e302801384302 = 1402313012078 := by decide
theorem cert_e302801384302 : check e302801384302 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801384310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e302801384310 : Closed e302801384310 ∧ code e302801384310 = 1402313012086 := by decide
theorem cert_e302801384310 : check e302801384310 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801384330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e302801384330 : Closed e302801384330 ∧ code e302801384330 = 1402313012106 := by decide
theorem cert_e302801384330 : check e302801384330 [[],[]] .chain = true := by decide
def e302801384354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e302801384354 : Closed e302801384354 ∧ code e302801384354 = 1402313012130 := by decide
theorem cert_e302801384354 : check e302801384354 [[],[]] .chain = true := by decide
def e302801384366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e302801384366 : Closed e302801384366 ∧ code e302801384366 = 1402313012142 := by decide
theorem cert_e302801384366 : check e302801384366 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801384378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e302801384378 : Closed e302801384378 ∧ code e302801384378 = 1402313012154 := by decide
theorem cert_e302801384378 : check e302801384378 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801384406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e302801384406 : Closed e302801384406 ∧ code e302801384406 = 1402313012182 := by decide
theorem cert_e302801384406 : check e302801384406 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801384410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e302801384410 : Closed e302801384410 ∧ code e302801384410 = 1402313012186 := by decide
theorem cert_e302801384410 : check e302801384410 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801384478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e302801384478 : Closed e302801384478 ∧ code e302801384478 = 1402313012254 := by decide
theorem cert_e302801384478 : check e302801384478 [[],[]] .chain = true := by decide
def e302801384502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e302801384502 : Closed e302801384502 ∧ code e302801384502 = 1402313012278 := by decide
theorem cert_e302801384502 : check e302801384502 [[],[]] .chain = true := by decide
def e302801384506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e302801384506 : Closed e302801384506 ∧ code e302801384506 = 1402313012282 := by decide
theorem cert_e302801384506 : check e302801384506 [[],[]] .chain = true := by decide
def e302801384646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302801384646 : Closed e302801384646 ∧ code e302801384646 = 1402313012422 := by decide
theorem cert_e302801384646 : check e302801384646 [[],[]] .chain = true := by decide
def e302801384674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e302801384674 : Closed e302801384674 ∧ code e302801384674 = 1402313012450 := by decide
theorem cert_e302801384674 : check e302801384674 [[],[]] .chain = true := by decide
def e302801384686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e302801384686 : Closed e302801384686 ∧ code e302801384686 = 1402313012462 := by decide
theorem cert_e302801384686 : check e302801384686 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801384694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e302801384694 : Closed e302801384694 ∧ code e302801384694 = 1402313012470 := by decide
theorem cert_e302801384694 : check e302801384694 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801384974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e302801384974 : Closed e302801384974 ∧ code e302801384974 = 1402313012750 := by decide
theorem cert_e302801384974 : check e302801384974 [[],[]] .chain = true := by decide
def e302801385058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e302801385058 : Closed e302801385058 ∧ code e302801385058 = 1402313012834 := by decide
theorem cert_e302801385058 : check e302801385058 [[],[]] .chain = true := by decide
def e302801385070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e302801385070 : Closed e302801385070 ∧ code e302801385070 = 1402313012846 := by decide
theorem cert_e302801385070 : check e302801385070 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801385082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e302801385082 : Closed e302801385082 ∧ code e302801385082 = 1402313012858 := by decide
theorem cert_e302801385082 : check e302801385082 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801385270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e302801385270 : Closed e302801385270 ∧ code e302801385270 = 1402313013046 := by decide
theorem cert_e302801385270 : check e302801385270 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801385274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e302801385274 : Closed e302801385274 ∧ code e302801385274 = 1402313013050 := by decide
theorem cert_e302801385274 : check e302801385274 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801385910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e302801385910 : Closed e302801385910 ∧ code e302801385910 = 1402313013686 := by decide
theorem cert_e302801385910 : check e302801385910 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801385942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e302801385942 : Closed e302801385942 ∧ code e302801385942 = 1402313013718 := by decide
theorem cert_e302801385942 : check e302801385942 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801385946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e302801385946 : Closed e302801385946 ∧ code e302801385946 = 1402313013722 := by decide
theorem cert_e302801385946 : check e302801385946 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801386102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e302801386102 : Closed e302801386102 ∧ code e302801386102 = 1402313013878 := by decide
theorem cert_e302801386102 : check e302801386102 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801386294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e302801386294 : Closed e302801386294 ∧ code e302801386294 = 1402313014070 := by decide
theorem cert_e302801386294 : check e302801386294 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801386298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e302801386298 : Closed e302801386298 ∧ code e302801386298 = 1402313014074 := by decide
theorem cert_e302801386298 : check e302801386298 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801388974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e302801388974 : Closed e302801388974 ∧ code e302801388974 = 1402313016750 := by decide
theorem cert_e302801388974 : check e302801388974 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801388986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e302801388986 : Closed e302801388986 ∧ code e302801388986 = 1402313016762 := by decide
theorem cert_e302801388986 : check e302801388986 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801389034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e302801389034 : Closed e302801389034 ∧ code e302801389034 = 1402313016810 := by decide
theorem cert_e302801389034 : check e302801389034 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801389166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e302801389166 : Closed e302801389166 ∧ code e302801389166 = 1402313016942 := by decide
theorem cert_e302801389166 : check e302801389166 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801389178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e302801389178 : Closed e302801389178 ∧ code e302801389178 = 1402313016954 := by decide
theorem cert_e302801389178 : check e302801389178 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801389342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e302801389342 : Closed e302801389342 ∧ code e302801389342 = 1402313017118 := by decide
theorem cert_e302801389342 : check e302801389342 [[],[]] .chain = true := by decide
def e302801389454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e302801389454 : Closed e302801389454 ∧ code e302801389454 = 1402313017230 := by decide
theorem cert_e302801389454 : check e302801389454 [[],[]] .chain = true := by decide
def e302801389466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801389466 : Closed e302801389466 ∧ code e302801389466 = 1402313017242 := by decide
theorem cert_e302801389466 : check e302801389466 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801393206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302801393206 : Closed e302801393206 ∧ code e302801393206 = 1402313020982 := by decide
theorem cert_e302801393206 : check e302801393206 [[],[]] .chain = true := by decide
def e302801393210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302801393210 : Closed e302801393210 ∧ code e302801393210 = 1402313020986 := by decide
theorem cert_e302801393210 : check e302801393210 [[],[]] .chain = true := by decide
def e302801393294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302801393294 : Closed e302801393294 ∧ code e302801393294 = 1402313021070 := by decide
theorem cert_e302801393294 : check e302801393294 [[],[]] .chain = true := by decide
def e302801393350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302801393350 : Closed e302801393350 ∧ code e302801393350 = 1402313021126 := by decide
theorem cert_e302801393350 : check e302801393350 [[],[]] .chain = true := by decide
def e302801393430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302801393430 : Closed e302801393430 ∧ code e302801393430 = 1402313021206 := by decide
theorem cert_e302801393430 : check e302801393430 [[],[]] .chain = true := by decide
def e302801393434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302801393434 : Closed e302801393434 ∧ code e302801393434 = 1402313021210 := by decide
theorem cert_e302801393434 : check e302801393434 [[],[]] .chain = true := by decide
def e302801393478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302801393478 : Closed e302801393478 ∧ code e302801393478 = 1402313021254 := by decide
theorem cert_e302801393478 : check e302801393478 [[],[]] .chain = true := by decide
def e302801393506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302801393506 : Closed e302801393506 ∧ code e302801393506 = 1402313021282 := by decide
theorem cert_e302801393506 : check e302801393506 [[],[]] .chain = true := by decide
def e302801393518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e302801393518 : Closed e302801393518 ∧ code e302801393518 = 1402313021294 := by decide
theorem cert_e302801393518 : check e302801393518 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801393526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e302801393526 : Closed e302801393526 ∧ code e302801393526 = 1402313021302 := by decide
theorem cert_e302801393526 : check e302801393526 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801393590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e302801393590 : Closed e302801393590 ∧ code e302801393590 = 1402313021366 := by decide
theorem cert_e302801393590 : check e302801393590 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801393774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e302801393774 : Closed e302801393774 ∧ code e302801393774 = 1402313021550 := by decide
theorem cert_e302801393774 : check e302801393774 [[],[]] .chain = true := by decide
def e302801393786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e302801393786 : Closed e302801393786 ∧ code e302801393786 = 1402313021562 := by decide
theorem cert_e302801393786 : check e302801393786 [[],[]] .chain = true := by decide
def e302801394062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e302801394062 : Closed e302801394062 ∧ code e302801394062 = 1402313021838 := by decide
theorem cert_e302801394062 : check e302801394062 [[],[]] .chain = true := by decide
def e302801394118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e302801394118 : Closed e302801394118 ∧ code e302801394118 = 1402313021894 := by decide
theorem cert_e302801394118 : check e302801394118 [[],[]] .chain = true := by decide
def e302801394718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 3)))))))))
theorem wire_e302801394718 : Closed e302801394718 ∧ code e302801394718 = 1402313022494 := by decide
theorem cert_e302801394718 : check e302801394718 [[],[]] .chain = true := by decide
def e302801394742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302801394742 : Closed e302801394742 ∧ code e302801394742 = 1402313022518 := by decide
theorem cert_e302801394742 : check e302801394742 [[],[]] .chain = true := by decide
def e302801394746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302801394746 : Closed e302801394746 ∧ code e302801394746 = 1402313022522 := by decide
theorem cert_e302801394746 : check e302801394746 [[],[]] .chain = true := by decide
def e302801394886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302801394886 : Closed e302801394886 ∧ code e302801394886 = 1402313022662 := by decide
theorem cert_e302801394886 : check e302801394886 [[],[]] .chain = true := by decide
def e302801394914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302801394914 : Closed e302801394914 ∧ code e302801394914 = 1402313022690 := by decide
theorem cert_e302801394914 : check e302801394914 [[],[]] .chain = true := by decide
def e302801394926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e302801394926 : Closed e302801394926 ∧ code e302801394926 = 1402313022702 := by decide
theorem cert_e302801394926 : check e302801394926 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801394934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e302801394934 : Closed e302801394934 ∧ code e302801394934 = 1402313022710 := by decide
theorem cert_e302801394934 : check e302801394934 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801395318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e302801395318 : Closed e302801395318 ∧ code e302801395318 = 1402313023094 := by decide
theorem cert_e302801395318 : check e302801395318 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801404630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e302801404630 : Closed e302801404630 ∧ code e302801404630 = 1402313032406 := by decide
theorem cert_e302801404630 : check e302801404630 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801404634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e302801404634 : Closed e302801404634 ∧ code e302801404634 = 1402313032410 := by decide
theorem cert_e302801404634 : check e302801404634 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801404650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e302801404650 : Closed e302801404650 ∧ code e302801404650 = 1402313032426 := by decide
theorem cert_e302801404650 : check e302801404650 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801404726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801404726 : Closed e302801404726 ∧ code e302801404726 = 1402313032502 := by decide
theorem cert_e302801404726 : check e302801404726 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801404730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801404730 : Closed e302801404730 ∧ code e302801404730 = 1402313032506 := by decide
theorem cert_e302801404730 : check e302801404730 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801404814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e302801404814 : Closed e302801404814 ∧ code e302801404814 = 1402313032590 := by decide
theorem cert_e302801404814 : check e302801404814 [[],[]] .chain = true := by decide
def e302801404826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801404826 : Closed e302801404826 ∧ code e302801404826 = 1402313032602 := by decide
theorem cert_e302801404826 : check e302801404826 [[],[],[.under,.under,.left]] .width = true := by decide
def e302801406742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302801406742 : Closed e302801406742 ∧ code e302801406742 = 1402313034518 := by decide
theorem cert_e302801406742 : check e302801406742 [[],[]] .chain = true := by decide
def e302801406746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302801406746 : Closed e302801406746 ∧ code e302801406746 = 1402313034522 := by decide
theorem cert_e302801406746 : check e302801406746 [[],[]] .chain = true := by decide
def e302801406790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302801406790 : Closed e302801406790 ∧ code e302801406790 = 1402313034566 := by decide
theorem cert_e302801406790 : check e302801406790 [[],[]] .chain = true := by decide
def e302801406818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e302801406818 : Closed e302801406818 ∧ code e302801406818 = 1402313034594 := by decide
theorem cert_e302801406818 : check e302801406818 [[],[]] .chain = true := by decide
def e302801406830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e302801406830 : Closed e302801406830 ∧ code e302801406830 = 1402313034606 := by decide
theorem cert_e302801406830 : check e302801406830 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801406838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e302801406838 : Closed e302801406838 ∧ code e302801406838 = 1402313034614 := by decide
theorem cert_e302801406838 : check e302801406838 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801406858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e302801406858 : Closed e302801406858 ∧ code e302801406858 = 1402313034634 := by decide
theorem cert_e302801406858 : check e302801406858 [[],[]] .chain = true := by decide
def e302801406882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e302801406882 : Closed e302801406882 ∧ code e302801406882 = 1402313034658 := by decide
theorem cert_e302801406882 : check e302801406882 [[],[]] .chain = true := by decide
def e302801406894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e302801406894 : Closed e302801406894 ∧ code e302801406894 = 1402313034670 := by decide
theorem cert_e302801406894 : check e302801406894 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801406906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e302801406906 : Closed e302801406906 ∧ code e302801406906 = 1402313034682 := by decide
theorem cert_e302801406906 : check e302801406906 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801406934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e302801406934 : Closed e302801406934 ∧ code e302801406934 = 1402313034710 := by decide
theorem cert_e302801406934 : check e302801406934 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801406938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e302801406938 : Closed e302801406938 ∧ code e302801406938 = 1402313034714 := by decide
theorem cert_e302801406938 : check e302801406938 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801407006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e302801407006 : Closed e302801407006 ∧ code e302801407006 = 1402313034782 := by decide
theorem cert_e302801407006 : check e302801407006 [[],[]] .chain = true := by decide
def e302801407030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e302801407030 : Closed e302801407030 ∧ code e302801407030 = 1402313034806 := by decide
theorem cert_e302801407030 : check e302801407030 [[],[]] .chain = true := by decide
def e302801407034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e302801407034 : Closed e302801407034 ∧ code e302801407034 = 1402313034810 := by decide
theorem cert_e302801407034 : check e302801407034 [[],[]] .chain = true := by decide
def e302801407174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e302801407174 : Closed e302801407174 ∧ code e302801407174 = 1402313034950 := by decide
theorem cert_e302801407174 : check e302801407174 [[],[]] .chain = true := by decide
def e302801407202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e302801407202 : Closed e302801407202 ∧ code e302801407202 = 1402313034978 := by decide
theorem cert_e302801407202 : check e302801407202 [[],[]] .chain = true := by decide
def e302801407214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e302801407214 : Closed e302801407214 ∧ code e302801407214 = 1402313034990 := by decide
theorem cert_e302801407214 : check e302801407214 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801407222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e302801407222 : Closed e302801407222 ∧ code e302801407222 = 1402313034998 := by decide
theorem cert_e302801407222 : check e302801407222 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801407502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e302801407502 : Closed e302801407502 ∧ code e302801407502 = 1402313035278 := by decide
theorem cert_e302801407502 : check e302801407502 [[],[]] .chain = true := by decide
def e302801407586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e302801407586 : Closed e302801407586 ∧ code e302801407586 = 1402313035362 := by decide
theorem cert_e302801407586 : check e302801407586 [[],[]] .chain = true := by decide
def e302801407598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e302801407598 : Closed e302801407598 ∧ code e302801407598 = 1402313035374 := by decide
theorem cert_e302801407598 : check e302801407598 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801407610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e302801407610 : Closed e302801407610 ∧ code e302801407610 = 1402313035386 := by decide
theorem cert_e302801407610 : check e302801407610 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801407798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e302801407798 : Closed e302801407798 ∧ code e302801407798 = 1402313035574 := by decide
theorem cert_e302801407798 : check e302801407798 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801407802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e302801407802 : Closed e302801407802 ∧ code e302801407802 = 1402313035578 := by decide
theorem cert_e302801407802 : check e302801407802 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e302801413558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e302801413558 : Closed e302801413558 ∧ code e302801413558 = 1402313041334 := by decide
private def t_e302801413558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem cert_e302801413558 : ¬ IsSelfInterpreter e302801413558 :=
  wSource (t := t_e302801413558) (replay_sound (ps := []) (t := e302801413558) (by decide)) (by decide)
def e302801413590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e302801413590 : Closed e302801413590 ∧ code e302801413590 = 1402313041366 := by decide
private def t_e302801413590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem cert_e302801413590 : ¬ IsSelfInterpreter e302801413590 :=
  wSource (t := t_e302801413590) (replay_sound (ps := []) (t := e302801413590) (by decide)) (by decide)
def e302801413594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e302801413594 : Closed e302801413594 ∧ code e302801413594 = 1402313041370 := by decide
private def t_e302801413594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem cert_e302801413594 : ¬ IsSelfInterpreter e302801413594 :=
  wSource (t := t_e302801413594) (replay_sound (ps := []) (t := e302801413594) (by decide)) (by decide)
def e302801413750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e302801413750 : Closed e302801413750 ∧ code e302801413750 = 1402313041526 := by decide
private def t_e302801413750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem cert_e302801413750 : ¬ IsSelfInterpreter e302801413750 :=
  wSource (t := t_e302801413750) (replay_sound (ps := []) (t := e302801413750) (by decide)) (by decide)
def e302801413942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e302801413942 : Closed e302801413942 ∧ code e302801413942 = 1402313041718 := by decide
private def t_e302801413942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem cert_e302801413942 : ¬ IsSelfInterpreter e302801413942 :=
  wSource (t := t_e302801413942) (replay_sound (ps := []) (t := e302801413942) (by decide)) (by decide)
def e302801413946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e302801413946 : Closed e302801413946 ∧ code e302801413946 = 1402313041722 := by decide
private def t_e302801413946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem cert_e302801413946 : ¬ IsSelfInterpreter e302801413946 :=
  wSource (t := t_e302801413946) (replay_sound (ps := []) (t := e302801413946) (by decide)) (by decide)
def e302801491678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e302801491678 : Closed e302801491678 ∧ code e302801491678 = 1402313119454 := by decide
theorem cert_e302801491678 : check e302801491678 [[],[]] .smaller = true := by decide
def e302801491702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e302801491702 : Closed e302801491702 ∧ code e302801491702 = 1402313119478 := by decide
theorem cert_e302801491702 : check e302801491702 [[],[]] .smaller = true := by decide
def e302801491806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e302801491806 : Closed e302801491806 ∧ code e302801491806 = 1402313119582 := by decide
theorem cert_e302801491806 : check e302801491806 [[],[]] .smaller = true := by decide
def e302801491834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e302801491834 : Closed e302801491834 ∧ code e302801491834 = 1402313119610 := by decide
theorem cert_e302801491834 : check e302801491834 [[],[]] .smaller = true := by decide
def e302801491926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e302801491926 : Closed e302801491926 ∧ code e302801491926 = 1402313119702 := by decide
theorem cert_e302801491926 : check e302801491926 [[],[]] .smaller = true := by decide
def e302801491930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e302801491930 : Closed e302801491930 ∧ code e302801491930 = 1402313119706 := by decide
theorem cert_e302801491930 : check e302801491930 [[],[]] .smaller = true := by decide
def e302801492446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e302801492446 : Closed e302801492446 ∧ code e302801492446 = 1402313120222 := by decide
theorem cert_e302801492446 : check e302801492446 [[],[]] .smaller = true := by decide
def e302801492470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e302801492470 : Closed e302801492470 ∧ code e302801492470 = 1402313120246 := by decide
theorem cert_e302801492470 : check e302801492470 [[],[]] .smaller = true := by decide
def e302801493214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e302801493214 : Closed e302801493214 ∧ code e302801493214 = 1402313120990 := by decide
theorem cert_e302801493214 : check e302801493214 [[],[]] .smaller = true := by decide
def e302801493242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e302801493242 : Closed e302801493242 ∧ code e302801493242 = 1402313121018 := by decide
theorem cert_e302801493242 : check e302801493242 [[],[]] .smaller = true := by decide
def e302801493814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e302801493814 : Closed e302801493814 ∧ code e302801493814 = 1402313121590 := by decide
theorem cert_e302801493814 : check e302801493814 [[],[]] .smaller = true := by decide
def e302801493818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e302801493818 : Closed e302801493818 ∧ code e302801493818 = 1402313121594 := by decide
theorem cert_e302801493818 : check e302801493818 [[],[]] .smaller = true := by decide
def e302801508590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e302801508590 : Closed e302801508590 ∧ code e302801508590 = 1402313136366 := by decide
theorem cert_e302801508590 : check e302801508590 [[],[]] .smaller = true := by decide
def e302801508598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e302801508598 : Closed e302801508598 ∧ code e302801508598 = 1402313136374 := by decide
theorem cert_e302801508598 : check e302801508598 [[],[]] .smaller = true := by decide
def e302801509150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e302801509150 : Closed e302801509150 ∧ code e302801509150 = 1402313136926 := by decide
theorem cert_e302801509150 : check e302801509150 [[],[]] .smaller = true := by decide
def e302801509262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e302801509262 : Closed e302801509262 ∧ code e302801509262 = 1402313137038 := by decide
theorem cert_e302801509262 : check e302801509262 [[],[]] .smaller = true := by decide
def e302801509310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 4)))))))))
theorem wire_e302801509310 : Closed e302801509310 ∧ code e302801509310 = 1402313137086 := by decide
theorem cert_e302801509310 : check e302801509310 [[],[]] .chain = true := by decide
def e302801509358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 2)))))))))
theorem wire_e302801509358 : Closed e302801509358 ∧ code e302801509358 = 1402313137134 := by decide
theorem cert_e302801509358 : check e302801509358 [[],[]] .chain = true := by decide
def e302801509486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e302801509486 : Closed e302801509486 ∧ code e302801509486 = 1402313137262 := by decide
theorem cert_e302801509486 : check e302801509486 [[],[]] .smaller = true := by decide
def e302801509498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e302801509498 : Closed e302801509498 ∧ code e302801509498 = 1402313137274 := by decide
theorem cert_e302801509498 : check e302801509498 [[],[]] .smaller = true := by decide
def e302801509662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e302801509662 : Closed e302801509662 ∧ code e302801509662 = 1402313137438 := by decide
theorem cert_e302801509662 : check e302801509662 [[],[]] .smaller = true := by decide
def e302801509830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e302801509830 : Closed e302801509830 ∧ code e302801509830 = 1402313137606 := by decide
theorem cert_e302801509830 : check e302801509830 [[],[]] .smaller = true := by decide
def e302801509854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e302801509854 : Closed e302801509854 ∧ code e302801509854 = 1402313137630 := by decide
theorem cert_e302801509854 : check e302801509854 [[],[]] .smaller = true := by decide
def e302801509870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e302801509870 : Closed e302801509870 ∧ code e302801509870 = 1402313137646 := by decide
theorem cert_e302801509870 : check e302801509870 [[],[]] .smaller = true := by decide
def e302801509942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e302801509942 : Closed e302801509942 ∧ code e302801509942 = 1402313137718 := by decide
theorem cert_e302801509942 : check e302801509942 [[],[]] .smaller = true := by decide
def e302801509946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e302801509946 : Closed e302801509946 ∧ code e302801509946 = 1402313137722 := by decide
theorem cert_e302801509946 : check e302801509946 [[],[]] .smaller = true := by decide
def e302801510030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e302801510030 : Closed e302801510030 ∧ code e302801510030 = 1402313137806 := by decide
theorem cert_e302801510030 : check e302801510030 [[],[]] .smaller = true := by decide
def e302801510078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 4)))))))))
theorem wire_e302801510078 : Closed e302801510078 ∧ code e302801510078 = 1402313137854 := by decide
theorem cert_e302801510078 : check e302801510078 [[],[]] .chain = true := by decide
def e302801510086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e302801510086 : Closed e302801510086 ∧ code e302801510086 = 1402313137862 := by decide
theorem cert_e302801510086 : check e302801510086 [[],[]] .smaller = true := by decide
def e302801510110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e302801510110 : Closed e302801510110 ∧ code e302801510110 = 1402313137886 := by decide
theorem cert_e302801510110 : check e302801510110 [[],[]] .smaller = true := by decide
def e302801510134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e302801510134 : Closed e302801510134 ∧ code e302801510134 = 1402313137910 := by decide
theorem cert_e302801510134 : check e302801510134 [[],[]] .smaller = true := by decide
def e302801510138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 0)))))))))
theorem wire_e302801510138 : Closed e302801510138 ∧ code e302801510138 = 1402313137914 := by decide
theorem cert_e302801510138 : check e302801510138 [[],[]] .chain = true := by decide
def e302801510254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e302801510254 : Closed e302801510254 ∧ code e302801510254 = 1402313138030 := by decide
theorem cert_e302801510254 : check e302801510254 [[],[]] .smaller = true := by decide
def e302801510262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e302801510262 : Closed e302801510262 ∧ code e302801510262 = 1402313138038 := by decide
theorem cert_e302801510262 : check e302801510262 [[],[]] .smaller = true := by decide
end Blc.Floor40
