import CodeBridge
import Batch060
namespace Certgen.R302824803574
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 142,.app 2 133,.app 3 35,.lam 4,.app 5 17,.lam 6,.lam 7,.app 8 9,.var 1,.lam 10,.app 11 12,.var 2,.app 13 14,.var 0,.app 15 16,.var 2,.var 1,.app 18 19,.var 0,.app 20 32,.lam 21,.lam 22,.app 23 24,.var 1,.lam 25,.app 26 27,.var 2,.app 28 29,.var 0,.app 30 31,.var 2,.var 1,.lam 33,.lam 34,.var 0,.lam 36,.app 37 69,.lam 38,.app 39 51,.lam 40,.lam 41,.app 42 43,.var 1,.lam 44,.app 45 46,.var 2,.app 47 48,.var 0,.app 49 50,.var 2,.var 1,.app 52 53,.var 0,.app 54 66,.lam 55,.lam 56,.app 57 58,.var 1,.lam 59,.app 60 61,.var 2,.app 62 63,.var 0,.app 64 65,.var 2,.var 1,.lam 67,.lam 68,.var 0,.app 70 71,.var 0,.app 72 104,.lam 73,.app 74 86,.lam 75,.lam 76,.app 77 78,.var 1,.lam 79,.app 80 81,.var 2,.app 82 83,.var 0,.app 84 85,.var 2,.var 1,.app 87 88,.var 0,.app 89 101,.lam 90,.lam 91,.app 92 93,.var 1,.lam 94,.app 95 96,.var 2,.app 97 98,.var 0,.app 99 100,.var 2,.var 1,.lam 102,.lam 103,.var 0,.lam 105,.app 106 111,.app 107 108,.var 0,.lam 109,.lam 110,.var 1,.lam 112,.app 113 118,.app 114 115,.var 0,.lam 116,.lam 117,.var 1,.lam 119,.app 120 125,.app 121 122,.var 0,.lam 123,.lam 124,.var 0,.lam 126,.app 127 132,.app 128 129,.var 0,.lam 130,.lam 131,.var 1,.opaque,.app 134 138,.lam 135,.app 136 137,.var 0,.var 0,.lam 139,.app 140 141,.var 0,.var 0,.app 143 147,.lam 144,.app 145 146,.var 0,.var 0,.lam 148,.app 149 150,.var 0,.var 0]
def values : Array (List AClo) := #[[⟨147,[]⟩],[⟨146,[0]⟩,⟨150,[1]⟩],[⟨32,[4]⟩],[⟨71,[7]⟩],[⟨35,[]⟩],[⟨24,[3,2,4]⟩],[⟨53,[8,7]⟩],[⟨19,[4]⟩],[⟨69,[7]⟩],[⟨51,[8,7]⟩],[⟨9,[14,11,4]⟩],[⟨17,[4]⟩],[⟨66,[8,7]⟩],[⟨43,[10,9,8,7]⟩],[⟨133,[]⟩],[⟨58,[13,12,8,7]⟩],[⟨142,[]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨142,[]⟩,0⟩],[⟨⟨133,[]⟩,1⟩],[⟨⟨147,[]⟩,0⟩],[⟨⟨146,[0]⟩,0⟩],[⟨⟨150,[1]⟩,0⟩],[⟨⟨19,[4]⟩,18⟩],[⟨⟨32,[4]⟩,17⟩],[⟨⟨35,[]⟩,2⟩],[⟨⟨24,[3,2,4]⟩,14⟩],[⟨⟨69,[7]⟩,18⟩],[⟨⟨51,[8,7]⟩,18⟩],[⟨⟨17,[4]⟩,2⟩],[⟨⟨43,[10,9,8,7]⟩,1⟩],[⟨⟨53,[8,7]⟩,13⟩],[⟨⟨66,[8,7]⟩,13⟩],[⟨⟨58,[13,12,8,7]⟩,1⟩],[⟨⟨71,[7]⟩,14⟩],[⟨⟨9,[14,11,4]⟩,1⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[]⟩,2⟩,⟨⟨3,[]⟩,8⟩,⟨⟨4,[4]⟩,2⟩,⟨⟨5,[4]⟩,12⟩,⟨⟨6,[11,4]⟩,2⟩,⟨⟨7,[14,11,4]⟩,1⟩,⟨⟨8,[14,11,4]⟩,18⟩,⟨⟨17,[4]⟩,18⟩,⟨⟨18,[4]⟩,6⟩,⟨⟨19,[4]⟩,17⟩,⟨⟨20,[4]⟩,7⟩,⟨⟨21,[2,4]⟩,17⟩,⟨⟨22,[3,2,4]⟩,14⟩,⟨⟨23,[3,2,4]⟩,9⟩,⟨⟨32,[4]⟩,9⟩,⟨⟨33,[5,4]⟩,14⟩,⟨⟨34,[6,5,4]⟩,13⟩,⟨⟨35,[]⟩,6⟩,⟨⟨36,[7]⟩,18⟩,⟨⟨37,[7]⟩,10⟩,⟨⟨38,[8,7]⟩,18⟩,⟨⟨39,[8,7]⟩,11⟩,⟨⟨40,[9,8,7]⟩,18⟩,⟨⟨41,[10,9,8,7]⟩,1⟩,⟨⟨42,[10,9,8,7]⟩,13⟩,⟨⟨51,[8,7]⟩,13⟩,⟨⟨52,[8,7]⟩,14⟩,⟨⟨53,[8,7]⟩,13⟩,⟨⟨54,[8,7]⟩,15⟩,⟨⟨55,[12,8,7]⟩,13⟩,⟨⟨56,[13,12,8,7]⟩,1⟩,⟨⟨57,[13,12,8,7]⟩,16⟩,⟨⟨66,[8,7]⟩,16⟩,⟨⟨67,[15,8,7]⟩,1⟩,⟨⟨68,[16,15,8,7]⟩,0⟩,⟨⟨69,[7]⟩,14⟩,⟨⟨70,[7]⟩,17⟩,⟨⟨142,[]⟩,0⟩,⟨⟨143,[]⟩,3⟩,⟨⟨144,[0]⟩,0⟩,⟨⟨145,[0]⟩,4⟩,⟨⟨146,[0]⟩,5⟩,⟨⟨147,[]⟩,4⟩,⟨⟨147,[]⟩,5⟩,⟨⟨148,[1]⟩,0⟩,⟨⟨149,[1]⟩,5⟩,⟨⟨150,[1]⟩,5⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[19],[12],[13],[14],[15],[16],[17],[18],[29],[20],[21],[22],[23],[24],[25],[26],[27],[28],[37],[30],[31],[32],[33],[34],[35],[36],[39],[38],[11],[40],[41],[42],[44],[45],[46],[46],[47],[43,48],[43,48]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem block24 : checkRange P V K states hints 24 12=true := by decide
theorem block36 : checkRange P V K states hints 36 12=true := by decide
theorem block48 : checkRange P V K states hints 48 1=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<49 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 by_cases h12 : i<24
 · exact range_sound block12 i (by omega) h12 hi
 by_cases h24 : i<36
 · exact range_sound block24 i (by omega) h24 hi
 by_cases h36 : i<48
 · exact range_sound block36 i (by omega) h36 hi
 exact range_sound block48 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit150 : Term := .var 0
def lit131 : Term := .var 1
def lit99 : Term := .var 2
def lit123 : Term := .lam lit150
def lit130 : Term := .lam lit131
def lit122 : Term := .lam lit123
def lit148 : Term := .app lit150 lit150
def lit129 : Term := .lam lit130
def lit132 : Term := .var 5
def lit147 : Term := .lam lit148
def lit98 : Term := .app lit99 lit131
def lit120 : Term := .app lit150 lit122
def lit127 : Term := .app lit150 lit129
def lit96 : Term := .app lit150 lit98
def lit142 : Term := .app lit147 lit147
def lit94 : Term := .app lit99 lit96
def lit126 : Term := .app lit127 lit132
def lit93 : Term := .lam lit94
def lit125 : Term := .lam lit126
def lit91 : Term := .app lit131 lit93
def lit90 : Term := .lam lit91
def lit89 : Term := .lam lit90
def lit119 : Term := .app lit120 lit125
def lit118 : Term := .lam lit119
def lit88 : Term := .app lit89 lit122
def lit86 : Term := .app lit150 lit88
def lit112 : Term := .app lit127 lit118
def lit111 : Term := .lam lit112
def lit105 : Term := .app lit127 lit111
def lit104 : Term := .lam lit105
def lit73 : Term := .app lit89 lit86
def lit72 : Term := .lam lit73
def lit71 : Term := .app lit72 lit104
def lit69 : Term := .app lit150 lit71
def lit36 : Term := .app lit72 lit69
def lit35 : Term := .lam lit36
def lit2 : Term := .app lit72 lit35
def lit1 : Term := .app lit2 lit142
def lit0 : Term := .app lit1 lit142
def filling : Nat → Term := fun p => if p = 132 then Term.var 5 else Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub150 : model.term 150 = lit150 := model.var_eq 150 0 (by rfl)
theorem sub149 : model.term 149 = lit150 := model.var_eq 149 0 (by rfl)
theorem sub148 : model.term 148 = lit148 := by rw [model.app_eq 148 149 150 (by rfl), sub149, sub150]; rfl
theorem sub147 : model.term 147 = lit147 := by rw [model.lam_eq 147 148 (by rfl), sub148]; rfl
theorem sub146 : model.term 146 = lit150 := model.var_eq 146 0 (by rfl)
theorem sub145 : model.term 145 = lit150 := model.var_eq 145 0 (by rfl)
theorem sub144 : model.term 144 = lit148 := by rw [model.app_eq 144 145 146 (by rfl), sub145, sub146]; rfl
theorem sub143 : model.term 143 = lit147 := by rw [model.lam_eq 143 144 (by rfl), sub144]; rfl
theorem sub142 : model.term 142 = lit142 := by rw [model.app_eq 142 143 147 (by rfl), sub143, sub147]; rfl
theorem sub141 : model.term 141 = lit150 := model.var_eq 141 0 (by rfl)
theorem sub140 : model.term 140 = lit150 := model.var_eq 140 0 (by rfl)
theorem sub139 : model.term 139 = lit148 := by rw [model.app_eq 139 140 141 (by rfl), sub140, sub141]; rfl
theorem sub138 : model.term 138 = lit147 := by rw [model.lam_eq 138 139 (by rfl), sub139]; rfl
theorem sub137 : model.term 137 = lit150 := model.var_eq 137 0 (by rfl)
theorem sub136 : model.term 136 = lit150 := model.var_eq 136 0 (by rfl)
theorem sub135 : model.term 135 = lit148 := by rw [model.app_eq 135 136 137 (by rfl), sub136, sub137]; rfl
theorem sub134 : model.term 134 = lit147 := by rw [model.lam_eq 134 135 (by rfl), sub135]; rfl
theorem sub133 : model.term 133 = lit142 := by rw [model.app_eq 133 134 138 (by rfl), sub134, sub138]; rfl
theorem sub132 : model.term 132 = lit132 := (opaqueTerm (rankedCode code ordered_code) filling (p := 132) (by rfl)).trans (by rfl)
theorem sub131 : model.term 131 = lit131 := model.var_eq 131 1 (by rfl)
theorem sub130 : model.term 130 = lit130 := by rw [model.lam_eq 130 131 (by rfl), sub131]; rfl
theorem sub129 : model.term 129 = lit129 := by rw [model.lam_eq 129 130 (by rfl), sub130]; rfl
theorem sub128 : model.term 128 = lit150 := model.var_eq 128 0 (by rfl)
theorem sub127 : model.term 127 = lit127 := by rw [model.app_eq 127 128 129 (by rfl), sub128, sub129]; rfl
theorem sub126 : model.term 126 = lit126 := by rw [model.app_eq 126 127 132 (by rfl), sub127, sub132]; rfl
theorem sub125 : model.term 125 = lit125 := by rw [model.lam_eq 125 126 (by rfl), sub126]; rfl
theorem sub124 : model.term 124 = lit150 := model.var_eq 124 0 (by rfl)
theorem sub123 : model.term 123 = lit123 := by rw [model.lam_eq 123 124 (by rfl), sub124]; rfl
theorem sub122 : model.term 122 = lit122 := by rw [model.lam_eq 122 123 (by rfl), sub123]; rfl
theorem sub121 : model.term 121 = lit150 := model.var_eq 121 0 (by rfl)
theorem sub120 : model.term 120 = lit120 := by rw [model.app_eq 120 121 122 (by rfl), sub121, sub122]; rfl
theorem sub119 : model.term 119 = lit119 := by rw [model.app_eq 119 120 125 (by rfl), sub120, sub125]; rfl
theorem sub118 : model.term 118 = lit118 := by rw [model.lam_eq 118 119 (by rfl), sub119]; rfl
theorem sub117 : model.term 117 = lit131 := model.var_eq 117 1 (by rfl)
theorem sub116 : model.term 116 = lit130 := by rw [model.lam_eq 116 117 (by rfl), sub117]; rfl
theorem sub115 : model.term 115 = lit129 := by rw [model.lam_eq 115 116 (by rfl), sub116]; rfl
theorem sub114 : model.term 114 = lit150 := model.var_eq 114 0 (by rfl)
theorem sub113 : model.term 113 = lit127 := by rw [model.app_eq 113 114 115 (by rfl), sub114, sub115]; rfl
theorem sub112 : model.term 112 = lit112 := by rw [model.app_eq 112 113 118 (by rfl), sub113, sub118]; rfl
theorem sub111 : model.term 111 = lit111 := by rw [model.lam_eq 111 112 (by rfl), sub112]; rfl
theorem sub110 : model.term 110 = lit131 := model.var_eq 110 1 (by rfl)
theorem sub109 : model.term 109 = lit130 := by rw [model.lam_eq 109 110 (by rfl), sub110]; rfl
theorem sub108 : model.term 108 = lit129 := by rw [model.lam_eq 108 109 (by rfl), sub109]; rfl
theorem sub107 : model.term 107 = lit150 := model.var_eq 107 0 (by rfl)
theorem sub106 : model.term 106 = lit127 := by rw [model.app_eq 106 107 108 (by rfl), sub107, sub108]; rfl
theorem sub105 : model.term 105 = lit105 := by rw [model.app_eq 105 106 111 (by rfl), sub106, sub111]; rfl
theorem sub104 : model.term 104 = lit104 := by rw [model.lam_eq 104 105 (by rfl), sub105]; rfl
theorem sub103 : model.term 103 = lit150 := model.var_eq 103 0 (by rfl)
theorem sub102 : model.term 102 = lit123 := by rw [model.lam_eq 102 103 (by rfl), sub103]; rfl
theorem sub101 : model.term 101 = lit122 := by rw [model.lam_eq 101 102 (by rfl), sub102]; rfl
theorem sub100 : model.term 100 = lit131 := model.var_eq 100 1 (by rfl)
theorem sub99 : model.term 99 = lit99 := model.var_eq 99 2 (by rfl)
theorem sub98 : model.term 98 = lit98 := by rw [model.app_eq 98 99 100 (by rfl), sub99, sub100]; rfl
theorem sub97 : model.term 97 = lit150 := model.var_eq 97 0 (by rfl)
theorem sub96 : model.term 96 = lit96 := by rw [model.app_eq 96 97 98 (by rfl), sub97, sub98]; rfl
theorem sub95 : model.term 95 = lit99 := model.var_eq 95 2 (by rfl)
theorem sub94 : model.term 94 = lit94 := by rw [model.app_eq 94 95 96 (by rfl), sub95, sub96]; rfl
theorem sub93 : model.term 93 = lit93 := by rw [model.lam_eq 93 94 (by rfl), sub94]; rfl
theorem sub92 : model.term 92 = lit131 := model.var_eq 92 1 (by rfl)
theorem sub91 : model.term 91 = lit91 := by rw [model.app_eq 91 92 93 (by rfl), sub92, sub93]; rfl
theorem sub90 : model.term 90 = lit90 := by rw [model.lam_eq 90 91 (by rfl), sub91]; rfl
theorem sub89 : model.term 89 = lit89 := by rw [model.lam_eq 89 90 (by rfl), sub90]; rfl
theorem sub88 : model.term 88 = lit88 := by rw [model.app_eq 88 89 101 (by rfl), sub89, sub101]; rfl
theorem sub87 : model.term 87 = lit150 := model.var_eq 87 0 (by rfl)
theorem sub86 : model.term 86 = lit86 := by rw [model.app_eq 86 87 88 (by rfl), sub87, sub88]; rfl
theorem sub85 : model.term 85 = lit131 := model.var_eq 85 1 (by rfl)
theorem sub84 : model.term 84 = lit99 := model.var_eq 84 2 (by rfl)
theorem sub83 : model.term 83 = lit98 := by rw [model.app_eq 83 84 85 (by rfl), sub84, sub85]; rfl
theorem sub82 : model.term 82 = lit150 := model.var_eq 82 0 (by rfl)
theorem sub81 : model.term 81 = lit96 := by rw [model.app_eq 81 82 83 (by rfl), sub82, sub83]; rfl
theorem sub80 : model.term 80 = lit99 := model.var_eq 80 2 (by rfl)
theorem sub79 : model.term 79 = lit94 := by rw [model.app_eq 79 80 81 (by rfl), sub80, sub81]; rfl
theorem sub78 : model.term 78 = lit93 := by rw [model.lam_eq 78 79 (by rfl), sub79]; rfl
theorem sub77 : model.term 77 = lit131 := model.var_eq 77 1 (by rfl)
theorem sub76 : model.term 76 = lit91 := by rw [model.app_eq 76 77 78 (by rfl), sub77, sub78]; rfl
theorem sub75 : model.term 75 = lit90 := by rw [model.lam_eq 75 76 (by rfl), sub76]; rfl
theorem sub74 : model.term 74 = lit89 := by rw [model.lam_eq 74 75 (by rfl), sub75]; rfl
theorem sub73 : model.term 73 = lit73 := by rw [model.app_eq 73 74 86 (by rfl), sub74, sub86]; rfl
theorem sub72 : model.term 72 = lit72 := by rw [model.lam_eq 72 73 (by rfl), sub73]; rfl
theorem sub71 : model.term 71 = lit71 := by rw [model.app_eq 71 72 104 (by rfl), sub72, sub104]; rfl
theorem sub70 : model.term 70 = lit150 := model.var_eq 70 0 (by rfl)
theorem sub69 : model.term 69 = lit69 := by rw [model.app_eq 69 70 71 (by rfl), sub70, sub71]; rfl
theorem sub68 : model.term 68 = lit150 := model.var_eq 68 0 (by rfl)
theorem sub67 : model.term 67 = lit123 := by rw [model.lam_eq 67 68 (by rfl), sub68]; rfl
theorem sub66 : model.term 66 = lit122 := by rw [model.lam_eq 66 67 (by rfl), sub67]; rfl
theorem sub65 : model.term 65 = lit131 := model.var_eq 65 1 (by rfl)
theorem sub64 : model.term 64 = lit99 := model.var_eq 64 2 (by rfl)
theorem sub63 : model.term 63 = lit98 := by rw [model.app_eq 63 64 65 (by rfl), sub64, sub65]; rfl
theorem sub62 : model.term 62 = lit150 := model.var_eq 62 0 (by rfl)
theorem sub61 : model.term 61 = lit96 := by rw [model.app_eq 61 62 63 (by rfl), sub62, sub63]; rfl
theorem sub60 : model.term 60 = lit99 := model.var_eq 60 2 (by rfl)
theorem sub59 : model.term 59 = lit94 := by rw [model.app_eq 59 60 61 (by rfl), sub60, sub61]; rfl
theorem sub58 : model.term 58 = lit93 := by rw [model.lam_eq 58 59 (by rfl), sub59]; rfl
theorem sub57 : model.term 57 = lit131 := model.var_eq 57 1 (by rfl)
theorem sub56 : model.term 56 = lit91 := by rw [model.app_eq 56 57 58 (by rfl), sub57, sub58]; rfl
theorem sub55 : model.term 55 = lit90 := by rw [model.lam_eq 55 56 (by rfl), sub56]; rfl
theorem sub54 : model.term 54 = lit89 := by rw [model.lam_eq 54 55 (by rfl), sub55]; rfl
theorem sub53 : model.term 53 = lit88 := by rw [model.app_eq 53 54 66 (by rfl), sub54, sub66]; rfl
theorem sub52 : model.term 52 = lit150 := model.var_eq 52 0 (by rfl)
theorem sub51 : model.term 51 = lit86 := by rw [model.app_eq 51 52 53 (by rfl), sub52, sub53]; rfl
theorem sub50 : model.term 50 = lit131 := model.var_eq 50 1 (by rfl)
theorem sub49 : model.term 49 = lit99 := model.var_eq 49 2 (by rfl)
theorem sub48 : model.term 48 = lit98 := by rw [model.app_eq 48 49 50 (by rfl), sub49, sub50]; rfl
theorem sub47 : model.term 47 = lit150 := model.var_eq 47 0 (by rfl)
theorem sub46 : model.term 46 = lit96 := by rw [model.app_eq 46 47 48 (by rfl), sub47, sub48]; rfl
theorem sub45 : model.term 45 = lit99 := model.var_eq 45 2 (by rfl)
theorem sub44 : model.term 44 = lit94 := by rw [model.app_eq 44 45 46 (by rfl), sub45, sub46]; rfl
theorem sub43 : model.term 43 = lit93 := by rw [model.lam_eq 43 44 (by rfl), sub44]; rfl
theorem sub42 : model.term 42 = lit131 := model.var_eq 42 1 (by rfl)
theorem sub41 : model.term 41 = lit91 := by rw [model.app_eq 41 42 43 (by rfl), sub42, sub43]; rfl
theorem sub40 : model.term 40 = lit90 := by rw [model.lam_eq 40 41 (by rfl), sub41]; rfl
theorem sub39 : model.term 39 = lit89 := by rw [model.lam_eq 39 40 (by rfl), sub40]; rfl
theorem sub38 : model.term 38 = lit73 := by rw [model.app_eq 38 39 51 (by rfl), sub39, sub51]; rfl
theorem sub37 : model.term 37 = lit72 := by rw [model.lam_eq 37 38 (by rfl), sub38]; rfl
theorem sub36 : model.term 36 = lit36 := by rw [model.app_eq 36 37 69 (by rfl), sub37, sub69]; rfl
theorem sub35 : model.term 35 = lit35 := by rw [model.lam_eq 35 36 (by rfl), sub36]; rfl
theorem sub34 : model.term 34 = lit150 := model.var_eq 34 0 (by rfl)
theorem sub33 : model.term 33 = lit123 := by rw [model.lam_eq 33 34 (by rfl), sub34]; rfl
theorem sub32 : model.term 32 = lit122 := by rw [model.lam_eq 32 33 (by rfl), sub33]; rfl
theorem sub31 : model.term 31 = lit131 := model.var_eq 31 1 (by rfl)
theorem sub30 : model.term 30 = lit99 := model.var_eq 30 2 (by rfl)
theorem sub29 : model.term 29 = lit98 := by rw [model.app_eq 29 30 31 (by rfl), sub30, sub31]; rfl
theorem sub28 : model.term 28 = lit150 := model.var_eq 28 0 (by rfl)
theorem sub27 : model.term 27 = lit96 := by rw [model.app_eq 27 28 29 (by rfl), sub28, sub29]; rfl
theorem sub26 : model.term 26 = lit99 := model.var_eq 26 2 (by rfl)
theorem sub25 : model.term 25 = lit94 := by rw [model.app_eq 25 26 27 (by rfl), sub26, sub27]; rfl
theorem sub24 : model.term 24 = lit93 := by rw [model.lam_eq 24 25 (by rfl), sub25]; rfl
theorem sub23 : model.term 23 = lit131 := model.var_eq 23 1 (by rfl)
theorem sub22 : model.term 22 = lit91 := by rw [model.app_eq 22 23 24 (by rfl), sub23, sub24]; rfl
theorem sub21 : model.term 21 = lit90 := by rw [model.lam_eq 21 22 (by rfl), sub22]; rfl
theorem sub20 : model.term 20 = lit89 := by rw [model.lam_eq 20 21 (by rfl), sub21]; rfl
theorem sub19 : model.term 19 = lit88 := by rw [model.app_eq 19 20 32 (by rfl), sub20, sub32]; rfl
theorem sub18 : model.term 18 = lit150 := model.var_eq 18 0 (by rfl)
theorem sub17 : model.term 17 = lit86 := by rw [model.app_eq 17 18 19 (by rfl), sub18, sub19]; rfl
theorem sub16 : model.term 16 = lit131 := model.var_eq 16 1 (by rfl)
theorem sub15 : model.term 15 = lit99 := model.var_eq 15 2 (by rfl)
theorem sub14 : model.term 14 = lit98 := by rw [model.app_eq 14 15 16 (by rfl), sub15, sub16]; rfl
theorem sub13 : model.term 13 = lit150 := model.var_eq 13 0 (by rfl)
theorem sub12 : model.term 12 = lit96 := by rw [model.app_eq 12 13 14 (by rfl), sub13, sub14]; rfl
theorem sub11 : model.term 11 = lit99 := model.var_eq 11 2 (by rfl)
theorem sub10 : model.term 10 = lit94 := by rw [model.app_eq 10 11 12 (by rfl), sub11, sub12]; rfl
theorem sub9 : model.term 9 = lit93 := by rw [model.lam_eq 9 10 (by rfl), sub10]; rfl
theorem sub8 : model.term 8 = lit131 := model.var_eq 8 1 (by rfl)
theorem sub7 : model.term 7 = lit91 := by rw [model.app_eq 7 8 9 (by rfl), sub8, sub9]; rfl
theorem sub6 : model.term 6 = lit90 := by rw [model.lam_eq 6 7 (by rfl), sub7]; rfl
theorem sub5 : model.term 5 = lit89 := by rw [model.lam_eq 5 6 (by rfl), sub6]; rfl
theorem sub4 : model.term 4 = lit73 := by rw [model.app_eq 4 5 17 (by rfl), sub5, sub17]; rfl
theorem sub3 : model.term 3 = lit72 := by rw [model.lam_eq 3 4 (by rfl), sub4]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 35 (by rfl), sub3, sub35]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 133 (by rfl), sub2, sub133]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 142 (by rfl), sub1, sub142]; rfl
theorem excluded : ¬ IsSelfInterpreter e302824803574 := by
 intro he
 have hp : replay [[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] (call e302824803574 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R302824803574
