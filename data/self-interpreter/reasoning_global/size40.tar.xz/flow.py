from candidates import *
def analyze(e):
    q=A(A(e,V(1)),lc.bitlist('0010',V(0)))
    vals=[]; inputs=[]; outputs=[]; rules=[];tags=[]
    def node():
        vals.append(0);return len(vals)-1
    def label():
        inputs.append(node());outputs.append(node());return len(inputs)-1
    cs=[label() for _ in range(4)];rs=[label() for _ in range(2)]
    for src,dst in zip(cs+rs,cs[1:]+cs[-1:]+rs[1:]+rs[-1:]):
        vals[outputs[src]]=1<<dst
    def gen(t,env):
        if t[0]=='V':return env[t[1]]
        if t[0]=='L':
            a=label(); tags.append(a);r=node();vals[r]=1<<a
            rules.append(('join',gen(t[1],(inputs[a],)+env),outputs[a]))
        else:
            f=gen(t[1],env);x=gen(t[2],env);r=node()
            rules.append(('apply',f,x,r))
        return r
    cr=node(); rr=node();vals[cr]=1;vals[rr]=1<<4
    top=gen(q,(rr,cr))
    for _ in range(500):
        old=vals[:]
        for k,*args in rules:
            if k=='join':
                x,y=args;vals[y]|=vals[x]
            else:
                f,x,r=args;n=vals[f]
                while n:
                    bit=n&-n;i=bit.bit_length()-1;n-=bit
                    vals[inputs[i]]|=vals[x];vals[r]|=vals[outputs[i]]
        if vals==old:break
    else:raise AssertionError()
    return dict(top=vals[top],dom=[vals[x] for x in inputs],cod=[vals[x] for x in outputs])
if __name__=='__main__':
    rem={}
    for wirestr,r in json.loads((HERE/'certs.json').read_text()).items():
        if r[0]=='open':rem[wirestr]=analyze(lc.decode(wirestr)[0])
    (HERE/'flows.json').write_text(json.dumps(rem))
    print(Counter((v['top'] & 4)!=0 for v in rem.values()))
    for k,v in rem.items():
        if v['top'] & 4:print(k,lc.show(lc.decode(k)[0]),v['top'])
