import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302308707246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e302308707246 : Closed e302308707246 ∧ code e302308707246 = 1401820335022 := by decide
theorem cert_e302308707246 : check e302308707246 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302308707258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e302308707258 : Closed e302308707258 ∧ code e302308707258 = 1401820335034 := by decide
theorem cert_e302308707258 : check e302308707258 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302308707286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e302308707286 : Closed e302308707286 ∧ code e302308707286 = 1401820335062 := by decide
theorem cert_e302308707286 : check e302308707286 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e302308707290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e302308707290 : Closed e302308707290 ∧ code e302308707290 = 1401820335066 := by decide
theorem cert_e302308707290 : check e302308707290 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e302308707566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e302308707566 : Closed e302308707566 ∧ code e302308707566 = 1401820335342 := by decide
theorem cert_e302308707566 : check e302308707566 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e302308707574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e302308707574 : Closed e302308707574 ∧ code e302308707574 = 1401820335350 := by decide
theorem cert_e302308707574 : check e302308707574 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e302308707950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e302308707950 : Closed e302308707950 ∧ code e302308707950 = 1401820335726 := by decide
theorem cert_e302308707950 : check e302308707950 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302308707962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e302308707962 : Closed e302308707962 ∧ code e302308707962 = 1401820335738 := by decide
theorem cert_e302308707962 : check e302308707962 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e302308708150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e302308708150 : Closed e302308708150 ∧ code e302308708150 = 1401820335926 := by decide
theorem cert_e302308708150 : check e302308708150 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e302308708154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e302308708154 : Closed e302308708154 ∧ code e302308708154 = 1401820335930 := by decide
theorem cert_e302308708154 : check e302308708154 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e302308713902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e302308713902 : Closed e302308713902 ∧ code e302308713902 = 1401820341678 := by decide
theorem cert_e302308713902 : check e302308713902 [[],[]] .sourceHead = true := by decide
def e302308713914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e302308713914 : Closed e302308713914 ∧ code e302308713914 = 1401820341690 := by decide
theorem cert_e302308713914 : check e302308713914 [[],[]] .sourceHead = true := by decide
def e302308713962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e302308713962 : Closed e302308713962 ∧ code e302308713962 = 1401820341738 := by decide
theorem cert_e302308713962 : check e302308713962 [[],[]] .sourceHead = true := by decide
def e302308714094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e302308714094 : Closed e302308714094 ∧ code e302308714094 = 1401820341870 := by decide
theorem cert_e302308714094 : check e302308714094 [[],[]] .sourceHead = true := by decide
def e302308714106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e302308714106 : Closed e302308714106 ∧ code e302308714106 = 1401820341882 := by decide
theorem cert_e302308714106 : check e302308714106 [[],[]] .sourceHead = true := by decide
def e302308714394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e302308714394 : Closed e302308714394 ∧ code e302308714394 = 1401820342170 := by decide
theorem cert_e302308714394 : check e302308714394 [[],[]] .sourceHead = true := by decide
def e302308717270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e302308717270 : Closed e302308717270 ∧ code e302308717270 = 1401820345046 := by decide
theorem cert_e302308717270 : check e302308717270 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302308717274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e302308717274 : Closed e302308717274 ∧ code e302308717274 = 1401820345050 := by decide
theorem cert_e302308717274 : check e302308717274 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302308717290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e302308717290 : Closed e302308717290 ∧ code e302308717290 = 1401820345066 := by decide
theorem cert_e302308717290 : check e302308717290 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302308717366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e302308717366 : Closed e302308717366 ∧ code e302308717366 = 1401820345142 := by decide
theorem cert_e302308717366 : check e302308717366 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302308717370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e302308717370 : Closed e302308717370 ∧ code e302308717370 = 1401820345146 := by decide
theorem cert_e302308717370 : check e302308717370 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302308717466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e302308717466 : Closed e302308717466 ∧ code e302308717466 = 1401820345242 := by decide
theorem cert_e302308717466 : check e302308717466 [[],[],[.under,.under,.left]] .chain = true := by decide
def e302308854638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e302308854638 : Closed e302308854638 ∧ code e302308854638 = 1401820482414 := by decide
theorem cert_e302308854638 : check e302308854638 [[],[]] .sourceHead = true := by decide
def e302308854646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e302308854646 : Closed e302308854646 ∧ code e302308854646 = 1401820482422 := by decide
theorem cert_e302308854646 : check e302308854646 [[],[]] .sourceHead = true := by decide
def e302308854702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e302308854702 : Closed e302308854702 ∧ code e302308854702 = 1401820482478 := by decide
theorem cert_e302308854702 : check e302308854702 [[],[]] .sourceHead = true := by decide
def e302308854714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e302308854714 : Closed e302308854714 ∧ code e302308854714 = 1401820482490 := by decide
theorem cert_e302308854714 : check e302308854714 [[],[]] .sourceHead = true := by decide
def e302308854742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e302308854742 : Closed e302308854742 ∧ code e302308854742 = 1401820482518 := by decide
theorem cert_e302308854742 : check e302308854742 [[],[]] .sourceHead = true := by decide
def e302308854746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e302308854746 : Closed e302308854746 ∧ code e302308854746 = 1401820482522 := by decide
theorem cert_e302308854746 : check e302308854746 [[],[]] .sourceHead = true := by decide
def e302308855022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e302308855022 : Closed e302308855022 ∧ code e302308855022 = 1401820482798 := by decide
theorem cert_e302308855022 : check e302308855022 [[],[]] .sourceHead = true := by decide
def e302308855030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e302308855030 : Closed e302308855030 ∧ code e302308855030 = 1401820482806 := by decide
theorem cert_e302308855030 : check e302308855030 [[],[]] .sourceHead = true := by decide
def e302308855406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e302308855406 : Closed e302308855406 ∧ code e302308855406 = 1401820483182 := by decide
theorem cert_e302308855406 : check e302308855406 [[],[]] .sourceHead = true := by decide
def e302308855418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e302308855418 : Closed e302308855418 ∧ code e302308855418 = 1401820483194 := by decide
theorem cert_e302308855418 : check e302308855418 [[],[]] .sourceHead = true := by decide
def e302308855606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e302308855606 : Closed e302308855606 ∧ code e302308855606 = 1401820483382 := by decide
theorem cert_e302308855606 : check e302308855606 [[],[]] .sourceHead = true := by decide
def e302308855610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e302308855610 : Closed e302308855610 ∧ code e302308855610 = 1401820483386 := by decide
theorem cert_e302308855610 : check e302308855610 [[],[]] .sourceHead = true := by decide
def e302309444462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e302309444462 : Closed e302309444462 ∧ code e302309444462 = 1401821072238 := by decide
theorem cert_e302309444462 : check e302309444462 [[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e302309444470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e302309444470 : Closed e302309444470 ∧ code e302309444470 = 1401821072246 := by decide
theorem cert_e302309444470 : check e302309444470 [[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e302309444526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e302309444526 : Closed e302309444526 ∧ code e302309444526 = 1401821072302 := by decide
theorem cert_e302309444526 : check e302309444526 [[],[],[.left],[.left],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e302309444538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e302309444538 : Closed e302309444538 ∧ code e302309444538 = 1401821072314 := by decide
def e302309444566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e302309444566 : Closed e302309444566 ∧ code e302309444566 = 1401821072342 := by decide
theorem cert_e302309444566 : check e302309444566 [[],[],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e302309444570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e302309444570 : Closed e302309444570 ∧ code e302309444570 = 1401821072346 := by decide
def e302309444846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e302309444846 : Closed e302309444846 ∧ code e302309444846 = 1401821072622 := by decide
theorem cert_e302309444846 : check e302309444846 [[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e302309444854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e302309444854 : Closed e302309444854 ∧ code e302309444854 = 1401821072630 := by decide
theorem cert_e302309444854 : check e302309444854 [[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e302309445230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e302309445230 : Closed e302309445230 ∧ code e302309445230 = 1401821073006 := by decide
theorem cert_e302309445230 : checkPay e302309445230 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[],[]] = true := by decide
def e302309445242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e302309445242 : Closed e302309445242 ∧ code e302309445242 = 1401821073018 := by decide
theorem cert_e302309445242 : checkPay e302309445242 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left]] 0 [] = true := by decide
def e302309445430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e302309445430 : Closed e302309445430 ∧ code e302309445430 = 1401821073206 := by decide
theorem cert_e302309445430 : check e302309445430 [[],[],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e302309445434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e302309445434 : Closed e302309445434 ∧ code e302309445434 = 1401821073210 := by decide
theorem cert_e302309445434 : check e302309445434 [[],[],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e302392629982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e302392629982 : Closed e302392629982 ∧ code e302392629982 = 1401904257758 := by decide
theorem cert_e302392629982 : check e302392629982 [[],[]] .three = true := by decide
def e302392630006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e302392630006 : Closed e302392630006 ∧ code e302392630006 = 1401904257782 := by decide
theorem cert_e302392630006 : check e302392630006 [[],[]] .three = true := by decide
def e302392630110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e302392630110 : Closed e302392630110 ∧ code e302392630110 = 1401904257886 := by decide
theorem cert_e302392630110 : check e302392630110 [[],[]] .three = true := by decide
def e302392630126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e302392630126 : Closed e302392630126 ∧ code e302392630126 = 1401904257902 := by decide
theorem cert_e302392630126 : check e302392630126 [[],[]] .smaller = true := by decide
def e302392630134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e302392630134 : Closed e302392630134 ∧ code e302392630134 = 1401904257910 := by decide
theorem cert_e302392630134 : check e302392630134 [[],[]] .smaller = true := by decide
def e302392630138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e302392630138 : Closed e302392630138 ∧ code e302392630138 = 1401904257914 := by decide
theorem cert_e302392630138 : check e302392630138 [[],[]] .three = true := by decide
def e302392630198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e302392630198 : Closed e302392630198 ∧ code e302392630198 = 1401904257974 := by decide
theorem cert_e302392630198 : check e302392630198 [[],[]] .smaller = true := by decide
def e302392630230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e302392630230 : Closed e302392630230 ∧ code e302392630230 = 1401904258006 := by decide
theorem cert_e302392630230 : check e302392630230 [[],[]] .three = true := by decide
def e302392630234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e302392630234 : Closed e302392630234 ∧ code e302392630234 = 1401904258010 := by decide
theorem cert_e302392630234 : check e302392630234 [[],[]] .three = true := by decide
def e302392630622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e302392630622 : Closed e302392630622 ∧ code e302392630622 = 1401904258398 := by decide
theorem cert_e302392630622 : check e302392630622 [[],[]] .three = true := by decide
def e302392630638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e302392630638 : Closed e302392630638 ∧ code e302392630638 = 1401904258414 := by decide
theorem cert_e302392630638 : check e302392630638 [[],[]] .smaller = true := by decide
def e302392630646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e302392630646 : Closed e302392630646 ∧ code e302392630646 = 1401904258422 := by decide
theorem cert_e302392630646 : check e302392630646 [[],[]] .smaller = true := by decide
def e302392630650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e302392630650 : Closed e302392630650 ∧ code e302392630650 = 1401904258426 := by decide
theorem cert_e302392630650 : check e302392630650 [[],[]] .three = true := by decide
def e302392630702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e302392630702 : Closed e302392630702 ∧ code e302392630702 = 1401904258478 := by decide
theorem cert_e302392630702 : check e302392630702 [[],[]] .smaller = true := by decide
def e302392630714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e302392630714 : Closed e302392630714 ∧ code e302392630714 = 1401904258490 := by decide
theorem cert_e302392630714 : check e302392630714 [[],[]] .smaller = true := by decide
def e302392630742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e302392630742 : Closed e302392630742 ∧ code e302392630742 = 1401904258518 := by decide
theorem cert_e302392630742 : check e302392630742 [[],[]] .smaller = true := by decide
def e302392630746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e302392630746 : Closed e302392630746 ∧ code e302392630746 = 1401904258522 := by decide
theorem cert_e302392630746 : check e302392630746 [[],[]] .smaller = true := by decide
def e302392630762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e302392630762 : Closed e302392630762 ∧ code e302392630762 = 1401904258538 := by decide
theorem cert_e302392630762 : check e302392630762 [[],[]] .three = true := by decide
def e302392630966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e302392630966 : Closed e302392630966 ∧ code e302392630966 = 1401904258742 := by decide
theorem cert_e302392630966 : check e302392630966 [[],[]] .smaller = true := by decide
def e302392630998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e302392630998 : Closed e302392630998 ∧ code e302392630998 = 1401904258774 := by decide
theorem cert_e302392630998 : check e302392630998 [[],[]] .smaller = true := by decide
def e302392631002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e302392631002 : Closed e302392631002 ∧ code e302392631002 = 1401904258778 := by decide
theorem cert_e302392631002 : check e302392631002 [[],[]] .smaller = true := by decide
def e302392631126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e302392631126 : Closed e302392631126 ∧ code e302392631126 = 1401904258902 := by decide
theorem cert_e302392631126 : check e302392631126 [[],[]] .three = true := by decide
def e302392631130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e302392631130 : Closed e302392631130 ∧ code e302392631130 = 1401904258906 := by decide
theorem cert_e302392631130 : check e302392631130 [[],[]] .three = true := by decide
def e302392631146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e302392631146 : Closed e302392631146 ∧ code e302392631146 = 1401904258922 := by decide
theorem cert_e302392631146 : check e302392631146 [[],[]] .three = true := by decide
def e302392633054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e302392633054 : Closed e302392633054 ∧ code e302392633054 = 1401904260830 := by decide
theorem cert_e302392633054 : check e302392633054 [[],[]] .three = true := by decide
def e302392633078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e302392633078 : Closed e302392633078 ∧ code e302392633078 = 1401904260854 := by decide
theorem cert_e302392633078 : check e302392633078 [[],[]] .three = true := by decide
def e302392633182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e302392633182 : Closed e302392633182 ∧ code e302392633182 = 1401904260958 := by decide
theorem cert_e302392633182 : check e302392633182 [[],[]] .three = true := by decide
def e302392633198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e302392633198 : Closed e302392633198 ∧ code e302392633198 = 1401904260974 := by decide
theorem cert_e302392633198 : check e302392633198 [[],[]] .smaller = true := by decide
def e302392633206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e302392633206 : Closed e302392633206 ∧ code e302392633206 = 1401904260982 := by decide
theorem cert_e302392633206 : check e302392633206 [[],[]] .smaller = true := by decide
def e302392633210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e302392633210 : Closed e302392633210 ∧ code e302392633210 = 1401904260986 := by decide
theorem cert_e302392633210 : check e302392633210 [[],[]] .three = true := by decide
def e302392633270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e302392633270 : Closed e302392633270 ∧ code e302392633270 = 1401904261046 := by decide
theorem cert_e302392633270 : check e302392633270 [[],[]] .smaller = true := by decide
def e302392633302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e302392633302 : Closed e302392633302 ∧ code e302392633302 = 1401904261078 := by decide
theorem cert_e302392633302 : check e302392633302 [[],[]] .three = true := by decide
def e302392633306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e302392633306 : Closed e302392633306 ∧ code e302392633306 = 1401904261082 := by decide
theorem cert_e302392633306 : check e302392633306 [[],[]] .three = true := by decide
def e302392633822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e302392633822 : Closed e302392633822 ∧ code e302392633822 = 1401904261598 := by decide
theorem cert_e302392633822 : check e302392633822 [[],[]] .three = true := by decide
def e302392633846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e302392633846 : Closed e302392633846 ∧ code e302392633846 = 1401904261622 := by decide
theorem cert_e302392633846 : check e302392633846 [[],[]] .three = true := by decide
def e302392634590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e302392634590 : Closed e302392634590 ∧ code e302392634590 = 1401904262366 := by decide
theorem cert_e302392634590 : check e302392634590 [[],[]] .three = true := by decide
def e302392634606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e302392634606 : Closed e302392634606 ∧ code e302392634606 = 1401904262382 := by decide
theorem cert_e302392634606 : check e302392634606 [[],[]] .smaller = true := by decide
def e302392634614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e302392634614 : Closed e302392634614 ∧ code e302392634614 = 1401904262390 := by decide
theorem cert_e302392634614 : check e302392634614 [[],[]] .smaller = true := by decide
def e302392634618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e302392634618 : Closed e302392634618 ∧ code e302392634618 = 1401904262394 := by decide
theorem cert_e302392634618 : check e302392634618 [[],[]] .three = true := by decide
def e302392634998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e302392634998 : Closed e302392634998 ∧ code e302392634998 = 1401904262774 := by decide
theorem cert_e302392634998 : check e302392634998 [[],[]] .smaller = true := by decide
def e302392635190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e302392635190 : Closed e302392635190 ∧ code e302392635190 = 1401904262966 := by decide
theorem cert_e302392635190 : check e302392635190 [[],[]] .three = true := by decide
def e302392635194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e302392635194 : Closed e302392635194 ∧ code e302392635194 = 1401904262970 := by decide
theorem cert_e302392635194 : check e302392635194 [[],[]] .three = true := by decide
def e302392636254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e302392636254 : Closed e302392636254 ∧ code e302392636254 = 1401904264030 := by decide
theorem cert_e302392636254 : check e302392636254 [[],[]] .three = true := by decide
def e302392636270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e302392636270 : Closed e302392636270 ∧ code e302392636270 = 1401904264046 := by decide
theorem cert_e302392636270 : check e302392636270 [[],[]] .smaller = true := by decide
def e302392636278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e302392636278 : Closed e302392636278 ∧ code e302392636278 = 1401904264054 := by decide
theorem cert_e302392636278 : check e302392636278 [[],[]] .smaller = true := by decide
def e302392636282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e302392636282 : Closed e302392636282 ∧ code e302392636282 = 1401904264058 := by decide
theorem cert_e302392636282 : check e302392636282 [[],[]] .three = true := by decide
def e302392636334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e302392636334 : Closed e302392636334 ∧ code e302392636334 = 1401904264110 := by decide
theorem cert_e302392636334 : check e302392636334 [[],[]] .smaller = true := by decide
def e302392636346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e302392636346 : Closed e302392636346 ∧ code e302392636346 = 1401904264122 := by decide
theorem cert_e302392636346 : check e302392636346 [[],[]] .smaller = true := by decide
def e302392636374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e302392636374 : Closed e302392636374 ∧ code e302392636374 = 1401904264150 := by decide
theorem cert_e302392636374 : check e302392636374 [[],[]] .smaller = true := by decide
def e302392636378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e302392636378 : Closed e302392636378 ∧ code e302392636378 = 1401904264154 := by decide
theorem cert_e302392636378 : check e302392636378 [[],[]] .smaller = true := by decide
def e302392636394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e302392636394 : Closed e302392636394 ∧ code e302392636394 = 1401904264170 := by decide
theorem cert_e302392636394 : check e302392636394 [[],[]] .three = true := by decide
def e302392636638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e302392636638 : Closed e302392636638 ∧ code e302392636638 = 1401904264414 := by decide
theorem cert_e302392636638 : check e302392636638 [[],[]] .three = true := by decide
def e302392636654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e302392636654 : Closed e302392636654 ∧ code e302392636654 = 1401904264430 := by decide
theorem cert_e302392636654 : check e302392636654 [[],[]] .smaller = true := by decide
def e302392636662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e302392636662 : Closed e302392636662 ∧ code e302392636662 = 1401904264438 := by decide
theorem cert_e302392636662 : check e302392636662 [[],[]] .smaller = true := by decide
def e302392636666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e302392636666 : Closed e302392636666 ∧ code e302392636666 = 1401904264442 := by decide
theorem cert_e302392636666 : check e302392636666 [[],[]] .three = true := by decide
def e302392637038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e302392637038 : Closed e302392637038 ∧ code e302392637038 = 1401904264814 := by decide
theorem cert_e302392637038 : check e302392637038 [[],[]] .smaller = true := by decide
def e302392637050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e302392637050 : Closed e302392637050 ∧ code e302392637050 = 1401904264826 := by decide
theorem cert_e302392637050 : check e302392637050 [[],[]] .smaller = true := by decide
def e302392637238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e302392637238 : Closed e302392637238 ∧ code e302392637238 = 1401904265014 := by decide
theorem cert_e302392637238 : check e302392637238 [[],[]] .smaller = true := by decide
def e302392637242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e302392637242 : Closed e302392637242 ∧ code e302392637242 = 1401904265018 := by decide
theorem cert_e302392637242 : check e302392637242 [[],[]] .smaller = true := by decide
def e302392637338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e302392637338 : Closed e302392637338 ∧ code e302392637338 = 1401904265114 := by decide
theorem cert_e302392637338 : check e302392637338 [[],[]] .three = true := by decide
def e302392637878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e302392637878 : Closed e302392637878 ∧ code e302392637878 = 1401904265654 := by decide
theorem cert_e302392637878 : check e302392637878 [[],[]] .smaller = true := by decide
def e302392637910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e302392637910 : Closed e302392637910 ∧ code e302392637910 = 1401904265686 := by decide
theorem cert_e302392637910 : check e302392637910 [[],[]] .smaller = true := by decide
def e302392637914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e302392637914 : Closed e302392637914 ∧ code e302392637914 = 1401904265690 := by decide
theorem cert_e302392637914 : check e302392637914 [[],[]] .smaller = true := by decide
def e302392638070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e302392638070 : Closed e302392638070 ∧ code e302392638070 = 1401904265846 := by decide
theorem cert_e302392638070 : check e302392638070 [[],[]] .smaller = true := by decide
def e302392638262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e302392638262 : Closed e302392638262 ∧ code e302392638262 = 1401904266038 := by decide
theorem cert_e302392638262 : check e302392638262 [[],[]] .smaller = true := by decide
def e302392638266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e302392638266 : Closed e302392638266 ∧ code e302392638266 = 1401904266042 := by decide
theorem cert_e302392638266 : check e302392638266 [[],[]] .smaller = true := by decide
def e302392638678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e302392638678 : Closed e302392638678 ∧ code e302392638678 = 1401904266454 := by decide
theorem cert_e302392638678 : check e302392638678 [[],[]] .three = true := by decide
def e302392638682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e302392638682 : Closed e302392638682 ∧ code e302392638682 = 1401904266458 := by decide
theorem cert_e302392638682 : check e302392638682 [[],[]] .three = true := by decide
def e302392638698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e302392638698 : Closed e302392638698 ∧ code e302392638698 = 1401904266474 := by decide
theorem cert_e302392638698 : check e302392638698 [[],[]] .three = true := by decide
def e302392638774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e302392638774 : Closed e302392638774 ∧ code e302392638774 = 1401904266550 := by decide
theorem cert_e302392638774 : check e302392638774 [[],[]] .three = true := by decide
def e302392638778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e302392638778 : Closed e302392638778 ∧ code e302392638778 = 1401904266554 := by decide
theorem cert_e302392638778 : check e302392638778 [[],[]] .three = true := by decide
def e302392638874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e302392638874 : Closed e302392638874 ∧ code e302392638874 = 1401904266650 := by decide
theorem cert_e302392638874 : check e302392638874 [[],[]] .three = true := by decide
def e302392645342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e302392645342 : Closed e302392645342 ∧ code e302392645342 = 1401904273118 := by decide
theorem cert_e302392645342 : check e302392645342 [[],[]] .three = true := by decide
def e302392645366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e302392645366 : Closed e302392645366 ∧ code e302392645366 = 1401904273142 := by decide
theorem cert_e302392645366 : check e302392645366 [[],[]] .three = true := by decide
def e302392645470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e302392645470 : Closed e302392645470 ∧ code e302392645470 = 1401904273246 := by decide
theorem cert_e302392645470 : check e302392645470 [[],[]] .three = true := by decide
def e302392645486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e302392645486 : Closed e302392645486 ∧ code e302392645486 = 1401904273262 := by decide
theorem cert_e302392645486 : check e302392645486 [[],[]] .smaller = true := by decide
def e302392645494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e302392645494 : Closed e302392645494 ∧ code e302392645494 = 1401904273270 := by decide
theorem cert_e302392645494 : check e302392645494 [[],[]] .smaller = true := by decide
def e302392645498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e302392645498 : Closed e302392645498 ∧ code e302392645498 = 1401904273274 := by decide
theorem cert_e302392645498 : check e302392645498 [[],[]] .three = true := by decide
def e302392645558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e302392645558 : Closed e302392645558 ∧ code e302392645558 = 1401904273334 := by decide
theorem cert_e302392645558 : check e302392645558 [[],[]] .smaller = true := by decide
def e302392645590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e302392645590 : Closed e302392645590 ∧ code e302392645590 = 1401904273366 := by decide
theorem cert_e302392645590 : check e302392645590 [[],[]] .three = true := by decide
def e302392645594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e302392645594 : Closed e302392645594 ∧ code e302392645594 = 1401904273370 := by decide
theorem cert_e302392645594 : check e302392645594 [[],[]] .three = true := by decide
def e302392646110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e302392646110 : Closed e302392646110 ∧ code e302392646110 = 1401904273886 := by decide
theorem cert_e302392646110 : check e302392646110 [[],[]] .three = true := by decide
def e302392646134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e302392646134 : Closed e302392646134 ∧ code e302392646134 = 1401904273910 := by decide
theorem cert_e302392646134 : check e302392646134 [[],[]] .three = true := by decide
def e302392646878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e302392646878 : Closed e302392646878 ∧ code e302392646878 = 1401904274654 := by decide
theorem cert_e302392646878 : check e302392646878 [[],[]] .three = true := by decide
def e302392646894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e302392646894 : Closed e302392646894 ∧ code e302392646894 = 1401904274670 := by decide
theorem cert_e302392646894 : check e302392646894 [[],[]] .smaller = true := by decide
def e302392646902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e302392646902 : Closed e302392646902 ∧ code e302392646902 = 1401904274678 := by decide
theorem cert_e302392646902 : check e302392646902 [[],[]] .smaller = true := by decide
def e302392646906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e302392646906 : Closed e302392646906 ∧ code e302392646906 = 1401904274682 := by decide
theorem cert_e302392646906 : check e302392646906 [[],[]] .three = true := by decide
def e302392647286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e302392647286 : Closed e302392647286 ∧ code e302392647286 = 1401904275062 := by decide
theorem cert_e302392647286 : check e302392647286 [[],[]] .smaller = true := by decide
def e302392647478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e302392647478 : Closed e302392647478 ∧ code e302392647478 = 1401904275254 := by decide
theorem cert_e302392647478 : check e302392647478 [[],[]] .three = true := by decide
def e302392647482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e302392647482 : Closed e302392647482 ∧ code e302392647482 = 1401904275258 := by decide
theorem cert_e302392647482 : check e302392647482 [[],[]] .three = true := by decide
def e302392658782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e302392658782 : Closed e302392658782 ∧ code e302392658782 = 1401904286558 := by decide
theorem cert_e302392658782 : check e302392658782 [[],[]] .three = true := by decide
def e302392658798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302392658798 : Closed e302392658798 ∧ code e302392658798 = 1401904286574 := by decide
theorem cert_e302392658798 : check e302392658798 [[],[]] .smaller = true := by decide
def e302392658806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302392658806 : Closed e302392658806 ∧ code e302392658806 = 1401904286582 := by decide
theorem cert_e302392658806 : check e302392658806 [[],[]] .smaller = true := by decide
def e302392658810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e302392658810 : Closed e302392658810 ∧ code e302392658810 = 1401904286586 := by decide
theorem cert_e302392658810 : check e302392658810 [[],[]] .three = true := by decide
def e302392658862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302392658862 : Closed e302392658862 ∧ code e302392658862 = 1401904286638 := by decide
theorem cert_e302392658862 : check e302392658862 [[],[]] .smaller = true := by decide
def e302392658874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302392658874 : Closed e302392658874 ∧ code e302392658874 = 1401904286650 := by decide
theorem cert_e302392658874 : check e302392658874 [[],[]] .smaller = true := by decide
def e302392658902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302392658902 : Closed e302392658902 ∧ code e302392658902 = 1401904286678 := by decide
theorem cert_e302392658902 : check e302392658902 [[],[]] .smaller = true := by decide
def e302392658906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302392658906 : Closed e302392658906 ∧ code e302392658906 = 1401904286682 := by decide
theorem cert_e302392658906 : check e302392658906 [[],[]] .smaller = true := by decide
def e302392658922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e302392658922 : Closed e302392658922 ∧ code e302392658922 = 1401904286698 := by decide
theorem cert_e302392658922 : check e302392658922 [[],[]] .three = true := by decide
def e302392659166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e302392659166 : Closed e302392659166 ∧ code e302392659166 = 1401904286942 := by decide
theorem cert_e302392659166 : check e302392659166 [[],[]] .three = true := by decide
def e302392659182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302392659182 : Closed e302392659182 ∧ code e302392659182 = 1401904286958 := by decide
theorem cert_e302392659182 : check e302392659182 [[],[]] .smaller = true := by decide
def e302392659190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302392659190 : Closed e302392659190 ∧ code e302392659190 = 1401904286966 := by decide
theorem cert_e302392659190 : check e302392659190 [[],[]] .smaller = true := by decide
def e302392659194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e302392659194 : Closed e302392659194 ∧ code e302392659194 = 1401904286970 := by decide
theorem cert_e302392659194 : check e302392659194 [[],[]] .three = true := by decide
def e302392659566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302392659566 : Closed e302392659566 ∧ code e302392659566 = 1401904287342 := by decide
theorem cert_e302392659566 : check e302392659566 [[],[]] .smaller = true := by decide
def e302392659578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302392659578 : Closed e302392659578 ∧ code e302392659578 = 1401904287354 := by decide
theorem cert_e302392659578 : check e302392659578 [[],[]] .smaller = true := by decide
def e302392659766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302392659766 : Closed e302392659766 ∧ code e302392659766 = 1401904287542 := by decide
theorem cert_e302392659766 : check e302392659766 [[],[]] .smaller = true := by decide
def e302392659770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302392659770 : Closed e302392659770 ∧ code e302392659770 = 1401904287546 := by decide
theorem cert_e302392659770 : check e302392659770 [[],[]] .smaller = true := by decide
def e302392659866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e302392659866 : Closed e302392659866 ∧ code e302392659866 = 1401904287642 := by decide
theorem cert_e302392659866 : check e302392659866 [[],[]] .three = true := by decide
def e302392665526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e302392665526 : Closed e302392665526 ∧ code e302392665526 = 1401904293302 := by decide
theorem cert_e302392665526 : check e302392665526 [[],[]] .smaller = true := by decide
def e302392665558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e302392665558 : Closed e302392665558 ∧ code e302392665558 = 1401904293334 := by decide
theorem cert_e302392665558 : check e302392665558 [[],[]] .smaller = true := by decide
def e302392665562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e302392665562 : Closed e302392665562 ∧ code e302392665562 = 1401904293338 := by decide
theorem cert_e302392665562 : check e302392665562 [[],[]] .smaller = true := by decide
def e302392665718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e302392665718 : Closed e302392665718 ∧ code e302392665718 = 1401904293494 := by decide
theorem cert_e302392665718 : check e302392665718 [[],[]] .smaller = true := by decide
def e302392665910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e302392665910 : Closed e302392665910 ∧ code e302392665910 = 1401904293686 := by decide
theorem cert_e302392665910 : check e302392665910 [[],[]] .smaller = true := by decide
def e302392665914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e302392665914 : Closed e302392665914 ∧ code e302392665914 = 1401904293690 := by decide
theorem cert_e302392665914 : check e302392665914 [[],[]] .smaller = true := by decide
end Blc.Floor40
