import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e299171701558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e299171701558 : Closed e299171701558 ∧ code e299171701558 = 1398683329334 := by decide
theorem cert_e299171701558 : check e299171701558 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299171701562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e299171701562 : Closed e299171701562 ∧ code e299171701562 = 1398683329338 := by decide
theorem cert_e299171701562 : check e299171701562 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299171701658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e299171701658 : Closed e299171701658 ∧ code e299171701658 = 1398683329434 := by decide
theorem cert_e299171701658 : check e299171701658 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299171702326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e299171702326 : Closed e299171702326 ∧ code e299171702326 = 1398683330102 := by decide
theorem cert_e299171702326 : check e299171702326 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299171702330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e299171702330 : Closed e299171702330 ∧ code e299171702330 = 1398683330106 := by decide
theorem cert_e299171702330 : check e299171702330 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299171702414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e299171702414 : Closed e299171702414 ∧ code e299171702414 = 1398683330190 := by decide
theorem cert_e299171702414 : check e299171702414 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299171702470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e299171702470 : Closed e299171702470 ∧ code e299171702470 = 1398683330246 := by decide
theorem cert_e299171702470 : check e299171702470 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299171702554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e299171702554 : Closed e299171702554 ∧ code e299171702554 = 1398683330330 := by decide
theorem cert_e299171702554 : check e299171702554 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299171702598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e299171702598 : Closed e299171702598 ∧ code e299171702598 = 1398683330374 := by decide
theorem cert_e299171702598 : check e299171702598 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299171703182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e299171703182 : Closed e299171703182 ∧ code e299171703182 = 1398683330958 := by decide
theorem cert_e299171703182 : check e299171703182 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299171703238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e299171703238 : Closed e299171703238 ∧ code e299171703238 = 1398683331014 := by decide
theorem cert_e299171703238 : check e299171703238 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299171704006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e299171704006 : Closed e299171704006 ∧ code e299171704006 = 1398683331782 := by decide
theorem cert_e299171704006 : check e299171704006 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299171714782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e299171714782 : Closed e299171714782 ∧ code e299171714782 = 1398683342558 := by decide
theorem cert_e299171714782 : check e299171714782 [[],[.left],[]] .chain = true := by decide
def e299171714806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e299171714806 : Closed e299171714806 ∧ code e299171714806 = 1398683342582 := by decide
theorem cert_e299171714806 : check e299171714806 [[],[.left],[]] .chain = true := by decide
def e299171714910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e299171714910 : Closed e299171714910 ∧ code e299171714910 = 1398683342686 := by decide
theorem cert_e299171714910 : check e299171714910 [[],[.left],[]] .chain = true := by decide
def e299171714938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e299171714938 : Closed e299171714938 ∧ code e299171714938 = 1398683342714 := by decide
theorem cert_e299171714938 : check e299171714938 [[],[.left],[]] .chain = true := by decide
def e299171715030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e299171715030 : Closed e299171715030 ∧ code e299171715030 = 1398683342806 := by decide
theorem cert_e299171715030 : check e299171715030 [[],[.left],[]] .chain = true := by decide
def e299171715034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e299171715034 : Closed e299171715034 ∧ code e299171715034 = 1398683342810 := by decide
theorem cert_e299171715034 : check e299171715034 [[],[.left],[]] .chain = true := by decide
def e299171715550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e299171715550 : Closed e299171715550 ∧ code e299171715550 = 1398683343326 := by decide
theorem cert_e299171715550 : check e299171715550 [[],[.left],[]] .chain = true := by decide
def e299171715574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e299171715574 : Closed e299171715574 ∧ code e299171715574 = 1398683343350 := by decide
theorem cert_e299171715574 : check e299171715574 [[],[.left],[]] .chain = true := by decide
def e299171716318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e299171716318 : Closed e299171716318 ∧ code e299171716318 = 1398683344094 := by decide
theorem cert_e299171716318 : check e299171716318 [[],[.left],[]] .chain = true := by decide
def e299171716346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e299171716346 : Closed e299171716346 ∧ code e299171716346 = 1398683344122 := by decide
theorem cert_e299171716346 : check e299171716346 [[],[.left],[]] .chain = true := by decide
def e299171716918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e299171716918 : Closed e299171716918 ∧ code e299171716918 = 1398683344694 := by decide
theorem cert_e299171716918 : check e299171716918 [[],[.left],[]] .chain = true := by decide
def e299171716922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e299171716922 : Closed e299171716922 ∧ code e299171716922 = 1398683344698 := by decide
theorem cert_e299171716922 : check e299171716922 [[],[.left],[]] .chain = true := by decide
def e299171731694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e299171731694 : Closed e299171731694 ∧ code e299171731694 = 1398683359470 := by decide
theorem cert_e299171731694 : check e299171731694 [[],[.left],[]] .sourceHead = true := by decide
def e299171731702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e299171731702 : Closed e299171731702 ∧ code e299171731702 = 1398683359478 := by decide
theorem cert_e299171731702 : check e299171731702 [[],[.left],[]] .sourceHead = true := by decide
def e299171732254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e299171732254 : Closed e299171732254 ∧ code e299171732254 = 1398683360030 := by decide
theorem cert_e299171732254 : check e299171732254 [[],[.left],[]] .sourceHead = true := by decide
def e299171732366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e299171732366 : Closed e299171732366 ∧ code e299171732366 = 1398683360142 := by decide
theorem cert_e299171732366 : check e299171732366 [[],[.left],[]] .sourceHead = true := by decide
def e299171732590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e299171732590 : Closed e299171732590 ∧ code e299171732590 = 1398683360366 := by decide
theorem cert_e299171732590 : check e299171732590 [[],[.left],[]] .sourceHead = true := by decide
def e299171732602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e299171732602 : Closed e299171732602 ∧ code e299171732602 = 1398683360378 := by decide
theorem cert_e299171732602 : check e299171732602 [[],[.left],[]] .sourceHead = true := by decide
def e299171732766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e299171732766 : Closed e299171732766 ∧ code e299171732766 = 1398683360542 := by decide
theorem cert_e299171732766 : check e299171732766 [[],[.left],[]] .sourceHead = true := by decide
def e299171732934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e299171732934 : Closed e299171732934 ∧ code e299171732934 = 1398683360710 := by decide
theorem cert_e299171732934 : check e299171732934 [[],[.left],[]] .sourceHead = true := by decide
def e299171733046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e299171733046 : Closed e299171733046 ∧ code e299171733046 = 1398683360822 := by decide
theorem cert_e299171733046 : check e299171733046 [[],[.left],[]] .sourceHead = true := by decide
def e299171733050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e299171733050 : Closed e299171733050 ∧ code e299171733050 = 1398683360826 := by decide
theorem cert_e299171733050 : check e299171733050 [[],[.left],[]] .sourceHead = true := by decide
def e299171733134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e299171733134 : Closed e299171733134 ∧ code e299171733134 = 1398683360910 := by decide
theorem cert_e299171733134 : check e299171733134 [[],[.left],[]] .sourceHead = true := by decide
def e299171733190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e299171733190 : Closed e299171733190 ∧ code e299171733190 = 1398683360966 := by decide
theorem cert_e299171733190 : check e299171733190 [[],[.left],[]] .sourceHead = true := by decide
def e299171735326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e299171735326 : Closed e299171735326 ∧ code e299171735326 = 1398683363102 := by decide
theorem cert_e299171735326 : check e299171735326 [[],[.left],[]] .sourceHead = true := by decide
def e299171735438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e299171735438 : Closed e299171735438 ∧ code e299171735438 = 1398683363214 := by decide
theorem cert_e299171735438 : check e299171735438 [[],[.left],[]] .sourceHead = true := by decide
def e299171738398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e299171738398 : Closed e299171738398 ∧ code e299171738398 = 1398683366174 := by decide
theorem cert_e299171738398 : check e299171738398 [[],[.left],[]] .sourceHead = true := by decide
def e299171738566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e299171738566 : Closed e299171738566 ∧ code e299171738566 = 1398683366342 := by decide
theorem cert_e299171738566 : check e299171738566 [[],[.left],[]] .sourceHead = true := by decide
def e299171740046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e299171740046 : Closed e299171740046 ∧ code e299171740046 = 1398683367822 := by decide
theorem cert_e299171740046 : check e299171740046 [[],[.left],[]] .sourceHead = true := by decide
def e299171740102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e299171740102 : Closed e299171740102 ∧ code e299171740102 = 1398683367878 := by decide
theorem cert_e299171740102 : check e299171740102 [[],[.left],[]] .sourceHead = true := by decide
def e299171777390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e299171777390 : Closed e299171777390 ∧ code e299171777390 = 1398683405166 := by decide
theorem cert_e299171777390 : check e299171777390 [[],[.left],[],[.under]] .smaller = true := by decide
def e299171777398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e299171777398 : Closed e299171777398 ∧ code e299171777398 = 1398683405174 := by decide
theorem cert_e299171777398 : check e299171777398 [[],[.left],[],[.under]] .smaller = true := by decide
def e299171777454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e299171777454 : Closed e299171777454 ∧ code e299171777454 = 1398683405230 := by decide
theorem cert_e299171777454 : check e299171777454 [[],[.left],[],[.under]] .smaller = true := by decide
def e299171777466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e299171777466 : Closed e299171777466 ∧ code e299171777466 = 1398683405242 := by decide
theorem cert_e299171777466 : check e299171777466 [[],[.left],[],[.under]] .smaller = true := by decide
def e299171777494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e299171777494 : Closed e299171777494 ∧ code e299171777494 = 1398683405270 := by decide
theorem cert_e299171777494 : check e299171777494 [[],[.left],[],[.under]] .smaller = true := by decide
def e299171777498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e299171777498 : Closed e299171777498 ∧ code e299171777498 = 1398683405274 := by decide
theorem cert_e299171777498 : check e299171777498 [[],[.left],[],[.under]] .smaller = true := by decide
def e299171777774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e299171777774 : Closed e299171777774 ∧ code e299171777774 = 1398683405550 := by decide
theorem cert_e299171777774 : check e299171777774 [[],[.left],[],[.under]] .smaller = true := by decide
def e299171777782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e299171777782 : Closed e299171777782 ∧ code e299171777782 = 1398683405558 := by decide
theorem cert_e299171777782 : check e299171777782 [[],[.left],[],[.under]] .smaller = true := by decide
def e299171778158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e299171778158 : Closed e299171778158 ∧ code e299171778158 = 1398683405934 := by decide
theorem cert_e299171778158 : check e299171778158 [[],[.left],[],[.under]] .smaller = true := by decide
def e299171778170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e299171778170 : Closed e299171778170 ∧ code e299171778170 = 1398683405946 := by decide
theorem cert_e299171778170 : check e299171778170 [[],[.left],[],[.under]] .smaller = true := by decide
def e299171778358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e299171778358 : Closed e299171778358 ∧ code e299171778358 = 1398683406134 := by decide
theorem cert_e299171778358 : check e299171778358 [[],[.left],[],[.under]] .smaller = true := by decide
def e299171778362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e299171778362 : Closed e299171778362 ∧ code e299171778362 = 1398683406138 := by decide
theorem cert_e299171778362 : check e299171778362 [[],[.left],[],[.under]] .smaller = true := by decide
def e299171785838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e299171785838 : Closed e299171785838 ∧ code e299171785838 = 1398683413614 := by decide
theorem cert_e299171785838 : check e299171785838 [[],[.left],[],[.under]] .three = true := by decide
def e299171785850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e299171785850 : Closed e299171785850 ∧ code e299171785850 = 1398683413626 := by decide
theorem cert_e299171785850 : check e299171785850 [[],[.left],[],[.under]] .three = true := by decide
def e299171786014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e299171786014 : Closed e299171786014 ∧ code e299171786014 = 1398683413790 := by decide
theorem cert_e299171786014 : check e299171786014 [[],[.left],[],[.under]] .three = true := by decide
def e299171786182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e299171786182 : Closed e299171786182 ∧ code e299171786182 = 1398683413958 := by decide
theorem cert_e299171786182 : check e299171786182 [[],[.left],[],[.under]] .three = true := by decide
def e299171786522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e299171786522 : Closed e299171786522 ∧ code e299171786522 = 1398683414298 := by decide
theorem cert_e299171786522 : check e299171786522 [[],[.left],[],[.under]] .three = true := by decide
def e299171786566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e299171786566 : Closed e299171786566 ∧ code e299171786566 = 1398683414342 := by decide
theorem cert_e299171786566 : check e299171786566 [[],[.left],[],[.under]] .three = true := by decide
def e299171787550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e299171787550 : Closed e299171787550 ∧ code e299171787550 = 1398683415326 := by decide
theorem cert_e299171787550 : check e299171787550 [[],[.left],[],[.under]] .three = true := by decide
def e299171787718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e299171787718 : Closed e299171787718 ∧ code e299171787718 = 1398683415494 := by decide
theorem cert_e299171787718 : check e299171787718 [[],[.left],[],[.under]] .three = true := by decide
def e299171790022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e299171790022 : Closed e299171790022 ∧ code e299171790022 = 1398683417798 := by decide
theorem cert_e299171790022 : check e299171790022 [[],[.left],[],[.under]] .three = true := by decide
def e299171812918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e299171812918 : Closed e299171812918 ∧ code e299171812918 = 1398683440694 := by decide
theorem cert_e299171812918 : check e299171812918 [[],[.left],[],[.under]] .three = true := by decide
def e299171812922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e299171812922 : Closed e299171812922 ∧ code e299171812922 = 1398683440698 := by decide
theorem cert_e299171812922 : check e299171812922 [[],[.left],[],[.under]] .three = true := by decide
def e299171813006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e299171813006 : Closed e299171813006 ∧ code e299171813006 = 1398683440782 := by decide
theorem cert_e299171813006 : check e299171813006 [[],[.left],[],[.under]] .three = true := by decide
def e299171813062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e299171813062 : Closed e299171813062 ∧ code e299171813062 = 1398683440838 := by decide
theorem cert_e299171813062 : check e299171813062 [[],[.left],[],[.under]] .three = true := by decide
def e299171813146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e299171813146 : Closed e299171813146 ∧ code e299171813146 = 1398683440922 := by decide
theorem cert_e299171813146 : check e299171813146 [[],[.left],[],[.under]] .three = true := by decide
def e299171813190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e299171813190 : Closed e299171813190 ∧ code e299171813190 = 1398683440966 := by decide
theorem cert_e299171813190 : check e299171813190 [[],[.left],[],[.under]] .three = true := by decide
def e299171813774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e299171813774 : Closed e299171813774 ∧ code e299171813774 = 1398683441550 := by decide
theorem cert_e299171813774 : check e299171813774 [[],[.left],[],[.under]] .three = true := by decide
def e299171813830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e299171813830 : Closed e299171813830 ∧ code e299171813830 = 1398683441606 := by decide
theorem cert_e299171813830 : check e299171813830 [[],[.left],[],[.under]] .three = true := by decide
def e299171814598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e299171814598 : Closed e299171814598 ∧ code e299171814598 = 1398683442374 := by decide
theorem cert_e299171814598 : check e299171814598 [[],[.left],[],[.under]] .three = true := by decide
def e299172911342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e299172911342 : Closed e299172911342 ∧ code e299172911342 = 1398684539118 := by decide
theorem cert_e299172911342 : check e299172911342 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172911350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e299172911350 : Closed e299172911350 ∧ code e299172911350 = 1398684539126 := by decide
theorem cert_e299172911350 : check e299172911350 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172911902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e299172911902 : Closed e299172911902 ∧ code e299172911902 = 1398684539678 := by decide
theorem cert_e299172911902 : check e299172911902 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172912014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e299172912014 : Closed e299172912014 ∧ code e299172912014 = 1398684539790 := by decide
theorem cert_e299172912014 : check e299172912014 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172912238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e299172912238 : Closed e299172912238 ∧ code e299172912238 = 1398684540014 := by decide
theorem cert_e299172912238 : check e299172912238 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172912250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e299172912250 : Closed e299172912250 ∧ code e299172912250 = 1398684540026 := by decide
theorem cert_e299172912250 : check e299172912250 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172912414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e299172912414 : Closed e299172912414 ∧ code e299172912414 = 1398684540190 := by decide
theorem cert_e299172912414 : check e299172912414 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172912582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e299172912582 : Closed e299172912582 ∧ code e299172912582 = 1398684540358 := by decide
theorem cert_e299172912582 : check e299172912582 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172912694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e299172912694 : Closed e299172912694 ∧ code e299172912694 = 1398684540470 := by decide
theorem cert_e299172912694 : check e299172912694 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172912698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e299172912698 : Closed e299172912698 ∧ code e299172912698 = 1398684540474 := by decide
theorem cert_e299172912698 : check e299172912698 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172912782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e299172912782 : Closed e299172912782 ∧ code e299172912782 = 1398684540558 := by decide
theorem cert_e299172912782 : check e299172912782 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172912838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e299172912838 : Closed e299172912838 ∧ code e299172912838 = 1398684540614 := by decide
theorem cert_e299172912838 : check e299172912838 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172914974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e299172914974 : Closed e299172914974 ∧ code e299172914974 = 1398684542750 := by decide
theorem cert_e299172914974 : check e299172914974 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172915086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e299172915086 : Closed e299172915086 ∧ code e299172915086 = 1398684542862 := by decide
theorem cert_e299172915086 : check e299172915086 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172918046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e299172918046 : Closed e299172918046 ∧ code e299172918046 = 1398684545822 := by decide
theorem cert_e299172918046 : check e299172918046 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172918214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e299172918214 : Closed e299172918214 ∧ code e299172918214 = 1398684545990 := by decide
theorem cert_e299172918214 : check e299172918214 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172919694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e299172919694 : Closed e299172919694 ∧ code e299172919694 = 1398684547470 := by decide
theorem cert_e299172919694 : check e299172919694 [[],[.left],[],[]] .sourceHead = true := by decide
def e299172919750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e299172919750 : Closed e299172919750 ∧ code e299172919750 = 1398684547526 := by decide
theorem cert_e299172919750 : check e299172919750 [[],[.left],[],[]] .sourceHead = true := by decide
def e299177613022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e299177613022 : Closed e299177613022 ∧ code e299177613022 = 1398689240798 := by decide
theorem cert_e299177613022 : check e299177613022 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e299177613046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e299177613046 : Closed e299177613046 ∧ code e299177613046 = 1398689240822 := by decide
theorem cert_e299177613046 : check e299177613046 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e299177613150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e299177613150 : Closed e299177613150 ∧ code e299177613150 = 1398689240926 := by decide
theorem cert_e299177613150 : check e299177613150 [[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e299177613178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e299177613178 : Closed e299177613178 ∧ code e299177613178 = 1398689240954 := by decide
theorem cert_e299177613178 : check e299177613178 [[],[.left],[.left],[.left],[],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e299177613270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e299177613270 : Closed e299177613270 ∧ code e299177613270 = 1398689241046 := by decide
theorem cert_e299177613270 : check e299177613270 [[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e299177613274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e299177613274 : Closed e299177613274 ∧ code e299177613274 = 1398689241050 := by decide
theorem cert_e299177613274 : check e299177613274 [[],[.left],[.left],[.left],[],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e299177613790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e299177613790 : Closed e299177613790 ∧ code e299177613790 = 1398689241566 := by decide
theorem cert_e299177613790 : check e299177613790 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e299177613814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e299177613814 : Closed e299177613814 ∧ code e299177613814 = 1398689241590 := by decide
theorem cert_e299177613814 : check e299177613814 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e299177614558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e299177614558 : Closed e299177614558 ∧ code e299177614558 = 1398689242334 := by decide
theorem cert_e299177614558 : check e299177614558 [[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e299177614586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e299177614586 : Closed e299177614586 ∧ code e299177614586 = 1398689242362 := by decide
theorem cert_e299177614586 : check e299177614586 [[],[.left],[.left],[.left],[],[.under],[.under,.left]] .chain = true := by decide
def e299177615158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e299177615158 : Closed e299177615158 ∧ code e299177615158 = 1398689242934 := by decide
theorem cert_e299177615158 : check e299177615158 [[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e299177615162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e299177615162 : Closed e299177615162 ∧ code e299177615162 = 1398689242938 := by decide
theorem cert_e299177615162 : check e299177615162 [[],[.left],[.left],[.left],[],[.under],[.under,.left]] .chain = true := by decide
def e299177629934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e299177629934 : Closed e299177629934 ∧ code e299177629934 = 1398689257710 := by decide
theorem cert_e299177629934 : check e299177629934 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .sourceHead = true := by decide
def e299177629942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e299177629942 : Closed e299177629942 ∧ code e299177629942 = 1398689257718 := by decide
theorem cert_e299177629942 : check e299177629942 [[],[.left],[.left],[.left],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e299177630494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e299177630494 : Closed e299177630494 ∧ code e299177630494 = 1398689258270 := by decide
theorem cert_e299177630494 : check e299177630494 [[],[.left],[.left],[.left],[],[.left],[.left],[],[.left],[],[]] .chain = true := by decide
def e299177630606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e299177630606 : Closed e299177630606 ∧ code e299177630606 = 1398689258382 := by decide
theorem cert_e299177630606 : check e299177630606 [[],[.left],[.left],[.left],[],[.left],[.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e299177630830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e299177630830 : Closed e299177630830 ∧ code e299177630830 = 1398689258606 := by decide
theorem cert_e299177630830 : check e299177630830 [[],[.left],[.left],[.left],[],[.left],[],[.left],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e299177630842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e299177630842 : Closed e299177630842 ∧ code e299177630842 = 1398689258618 := by decide
theorem cert_e299177630842 : check e299177630842 [[],[.left],[.left],[.left],[],[.left],[],[.left],[],[],[],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e299177631006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e299177631006 : Closed e299177631006 ∧ code e299177631006 = 1398689258782 := by decide
theorem cert_e299177631006 : check e299177631006 [[],[.left],[.left],[.left],[],[.left],[],[.left],[.left],[],[]] .chain = true := by decide
def e299177631174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e299177631174 : Closed e299177631174 ∧ code e299177631174 = 1398689258950 := by decide
private def t_e299177631174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem cert_e299177631174 : ¬ IsSelfInterpreter e299177631174 :=
  wSource (t := t_e299177631174) (replay_sound (ps := []) (t := e299177631174) (by decide)) (by decide)
def e299177631286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e299177631286 : Closed e299177631286 ∧ code e299177631286 = 1398689259062 := by decide
theorem cert_e299177631286 : check e299177631286 [[],[.left],[.left],[.left],[],[.left],[.left],[],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .chain = true := by decide
def e299177631290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e299177631290 : Closed e299177631290 ∧ code e299177631290 = 1398689259066 := by decide
theorem cert_e299177631290 : check e299177631290 [[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e299177631374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e299177631374 : Closed e299177631374 ∧ code e299177631374 = 1398689259150 := by decide
theorem cert_e299177631374 : check e299177631374 [[],[.left],[.left],[.left],[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .chain = true := by decide
def e299177631430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e299177631430 : Closed e299177631430 ∧ code e299177631430 = 1398689259206 := by decide
private def t_e299177631430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem cert_e299177631430 : ¬ IsSelfInterpreter e299177631430 :=
  wSource (t := t_e299177631430) (replay_sound (ps := []) (t := e299177631430) (by decide)) (by decide)
def e299177633566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e299177633566 : Closed e299177633566 ∧ code e299177633566 = 1398689261342 := by decide
theorem cert_e299177633566 : check e299177633566 [[],[.left],[.left],[.left],[],[],[.left],[],[]] .sourceHead = true := by decide
def e299177633678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e299177633678 : Closed e299177633678 ∧ code e299177633678 = 1398689261454 := by decide
theorem cert_e299177633678 : check e299177633678 [[],[.left],[.left],[.left],[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e299177636638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e299177636638 : Closed e299177636638 ∧ code e299177636638 = 1398689264414 := by decide
theorem cert_e299177636638 : check e299177636638 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e299177636806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e299177636806 : Closed e299177636806 ∧ code e299177636806 = 1398689264582 := by decide
theorem cert_e299177636806 : check e299177636806 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e299177638286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e299177638286 : Closed e299177638286 ∧ code e299177638286 = 1398689266062 := by decide
theorem cert_e299177638286 : check e299177638286 [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left]] .identityHead = true := by decide
def e299177638342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e299177638342 : Closed e299177638342 ∧ code e299177638342 = 1398689266118 := by decide
theorem cert_e299177638342 : check e299177638342 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e300671688730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300671688730 : Closed e300671688730 ∧ code e300671688730 = 1400183316506 := by decide
theorem cert_e300671688730 : check e300671688730 [[]] .width = true := by decide
def e300671688822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300671688822 : Closed e300671688822 ∧ code e300671688822 = 1400183316598 := by decide
theorem cert_e300671688822 : check e300671688822 [[]] .width = true := by decide
def e300671689066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300671689066 : Closed e300671689066 ∧ code e300671689066 = 1400183316842 := by decide
theorem cert_e300671689066 : check e300671689066 [[]] .width = true := by decide
def e300671689114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300671689114 : Closed e300671689114 ∧ code e300671689114 = 1400183316890 := by decide
theorem cert_e300671689114 : check e300671689114 [[]] .width = true := by decide
def e300671758534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300671758534 : Closed e300671758534 ∧ code e300671758534 = 1400183386310 := by decide
theorem cert_e300671758534 : check e300671758534 [[]] .width = true := by decide
def e300671787034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300671787034 : Closed e300671787034 ∧ code e300671787034 = 1400183414810 := by decide
theorem cert_e300671787034 : check e300671787034 [[]] .width = true := by decide
def e300671787126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300671787126 : Closed e300671787126 ∧ code e300671787126 = 1400183414902 := by decide
theorem cert_e300671787126 : check e300671787126 [[]] .width = true := by decide
def e300671787370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300671787370 : Closed e300671787370 ∧ code e300671787370 = 1400183415146 := by decide
theorem cert_e300671787370 : check e300671787370 [[]] .width = true := by decide
def e300671787418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300671787418 : Closed e300671787418 ∧ code e300671787418 = 1400183415194 := by decide
theorem cert_e300671787418 : check e300671787418 [[]] .width = true := by decide
def e300671791302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300671791302 : Closed e300671791302 ∧ code e300671791302 = 1400183419078 := by decide
theorem cert_e300671791302 : check e300671791302 [[]] .width = true := by decide
def e300672213018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300672213018 : Closed e300672213018 ∧ code e300672213018 = 1400183840794 := by decide
theorem cert_e300672213018 : check e300672213018 [[]] .width = true := by decide
def e300672213110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300672213110 : Closed e300672213110 ∧ code e300672213110 = 1400183840886 := by decide
theorem cert_e300672213110 : check e300672213110 [[]] .width = true := by decide
def e300672213354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300672213354 : Closed e300672213354 ∧ code e300672213354 = 1400183841130 := by decide
theorem cert_e300672213354 : check e300672213354 [[]] .width = true := by decide
def e300672213402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300672213402 : Closed e300672213402 ∧ code e300672213402 = 1400183841178 := by decide
theorem cert_e300672213402 : check e300672213402 [[]] .width = true := by decide
def e300672327706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300672327706 : Closed e300672327706 ∧ code e300672327706 = 1400183955482 := by decide
theorem cert_e300672327706 : check e300672327706 [[]] .width = true := by decide
def e300672327798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300672327798 : Closed e300672327798 ∧ code e300672327798 = 1400183955574 := by decide
theorem cert_e300672327798 : check e300672327798 [[]] .width = true := by decide
def e300672328042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300672328042 : Closed e300672328042 ∧ code e300672328042 = 1400183955818 := by decide
theorem cert_e300672328042 : check e300672328042 [[]] .width = true := by decide
def e300672328090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300672328090 : Closed e300672328090 ∧ code e300672328090 = 1400183955866 := by decide
theorem cert_e300672328090 : check e300672328090 [[]] .width = true := by decide
def e300672544966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300672544966 : Closed e300672544966 ∧ code e300672544966 = 1400184172742 := by decide
theorem cert_e300672544966 : check e300672544966 [[]] .width = true := by decide
def e300672602310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300672602310 : Closed e300672602310 ∧ code e300672602310 = 1400184230086 := by decide
theorem cert_e300672602310 : check e300672602310 [[]] .width = true := by decide
def e300672704538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300672704538 : Closed e300672704538 ∧ code e300672704538 = 1400184332314 := by decide
theorem cert_e300672704538 : check e300672704538 [[]] .width = true := by decide
def e300672704630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300672704630 : Closed e300672704630 ∧ code e300672704630 = 1400184332406 := by decide
theorem cert_e300672704630 : check e300672704630 [[]] .width = true := by decide
def e300672704874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300672704874 : Closed e300672704874 ∧ code e300672704874 = 1400184332650 := by decide
theorem cert_e300672704874 : check e300672704874 [[]] .width = true := by decide
def e300672704922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300672704922 : Closed e300672704922 ∧ code e300672704922 = 1400184332698 := by decide
theorem cert_e300672704922 : check e300672704922 [[]] .width = true := by decide
def e300672708806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300672708806 : Closed e300672708806 ∧ code e300672708806 = 1400184336582 := by decide
theorem cert_e300672708806 : check e300672708806 [[]] .width = true := by decide
def e300672720922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300672720922 : Closed e300672720922 ∧ code e300672720922 = 1400184348698 := by decide
theorem cert_e300672720922 : check e300672720922 [[]] .width = true := by decide
def e300672721014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300672721014 : Closed e300672721014 ∧ code e300672721014 = 1400184348790 := by decide
theorem cert_e300672721014 : check e300672721014 [[]] .width = true := by decide
def e300672721258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300672721258 : Closed e300672721258 ∧ code e300672721258 = 1400184349034 := by decide
theorem cert_e300672721258 : check e300672721258 [[]] .width = true := by decide
def e300672721306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300672721306 : Closed e300672721306 ∧ code e300672721306 = 1400184349082 := by decide
theorem cert_e300672721306 : check e300672721306 [[]] .width = true := by decide
def e300672733382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300672733382 : Closed e300672733382 ∧ code e300672733382 = 1400184361158 := by decide
theorem cert_e300672733382 : check e300672733382 [[]] .width = true := by decide
def e300674834458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300674834458 : Closed e300674834458 ∧ code e300674834458 = 1400186462234 := by decide
theorem cert_e300674834458 : check e300674834458 [[]] .width = true := by decide
def e300674834550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300674834550 : Closed e300674834550 ∧ code e300674834550 = 1400186462326 := by decide
theorem cert_e300674834550 : check e300674834550 [[]] .width = true := by decide
def e300674834794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300674834794 : Closed e300674834794 ∧ code e300674834794 = 1400186462570 := by decide
theorem cert_e300674834794 : check e300674834794 [[]] .width = true := by decide
def e300674834842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300674834842 : Closed e300674834842 ∧ code e300674834842 = 1400186462618 := by decide
theorem cert_e300674834842 : check e300674834842 [[]] .width = true := by decide
def e300674904262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300674904262 : Closed e300674904262 ∧ code e300674904262 = 1400186532038 := by decide
theorem cert_e300674904262 : check e300674904262 [[]] .width = true := by decide
def e300674932762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300674932762 : Closed e300674932762 ∧ code e300674932762 = 1400186560538 := by decide
theorem cert_e300674932762 : check e300674932762 [[]] .width = true := by decide
def e300674932854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300674932854 : Closed e300674932854 ∧ code e300674932854 = 1400186560630 := by decide
theorem cert_e300674932854 : check e300674932854 [[]] .width = true := by decide
def e300674933098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300674933098 : Closed e300674933098 ∧ code e300674933098 = 1400186560874 := by decide
theorem cert_e300674933098 : check e300674933098 [[]] .width = true := by decide
def e300674933146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300674933146 : Closed e300674933146 ∧ code e300674933146 = 1400186560922 := by decide
theorem cert_e300674933146 : check e300674933146 [[]] .width = true := by decide
def e300674937030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300674937030 : Closed e300674937030 ∧ code e300674937030 = 1400186564806 := by decide
theorem cert_e300674937030 : check e300674937030 [[]] .width = true := by decide
end Blc.Floor40
