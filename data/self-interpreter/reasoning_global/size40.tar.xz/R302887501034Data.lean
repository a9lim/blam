import R302887501034V0
import R302887501034K0
import R302887501034st0
import R302887501034hs0
import CodeBridge
import Batch060
namespace Certgen.R302887501034
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 54,.app 2 50,.app 3 37,.app 4 17,.lam 5,.app 6 16,.app 7 8,.var 0,.lam 9,.lam 10,.lam 11,.app 12 13,.var 3,.app 14 15,.var 1,.var 0,.var 0,.lam 18,.lam 19,.lam 20,.app 21 34,.lam 22,.app 23 33,.app 24 25,.var 0,.lam 26,.lam 27,.lam 28,.app 29 30,.var 3,.app 31 32,.var 1,.var 0,.var 0,.app 35 36,.var 1,.var 0,.lam 38,.app 39 49,.app 40 41,.var 0,.lam 42,.lam 43,.lam 44,.app 45 46,.var 3,.app 47 48,.var 1,.var 0,.var 0,.lam 51,.lam 52,.lam 53,.var 0,.lam 55,.app 56 61,.app 57 58,.var 0,.lam 59,.lam 60,.var 1,.lam 62,.app 63 68,.app 64 65,.var 0,.lam 66,.lam 67,.var 1,.lam 69,.app 70 75,.app 71 72,.var 0,.lam 73,.lam 74,.var 0,.lam 76,.app 77 82,.app 78 79,.var 0,.lam 80,.lam 81,.var 1,.app 83 87,.lam 84,.app 85 86,.var 0,.var 0,.lam 88,.app 89 90,.var 0,.var 0]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) : List AClo := (if i < 20 then (V0[i-0]?.getD []) else (if i < 40 then (V20[i-20]?.getD []) else (V40[i-40]?.getD [])))
def K (i : Nat) : List Frame := (if i < 40 then (if i < 20 then (K0[i-0]?.getD []) else (K20[i-20]?.getD [])) else (if i < 60 then (K40[i-40]?.getD []) else (K60[i-60]?.getD [])))
def st (i : Nat) : AState := if i < 197 then (if i < 100 then (if i < 40 then (if i < 20 then (st0[i-0]?.getD entry) else (st20[i-20]?.getD entry)) else (if i < 60 then (st40[i-40]?.getD entry) else (if i < 80 then (st60[i-60]?.getD entry) else (st80[i-80]?.getD entry)))) else (if i < 140 then (if i < 120 then (st100[i-100]?.getD entry) else (st120[i-120]?.getD entry)) else (if i < 160 then (st140[i-140]?.getD entry) else (if i < 180 then (st160[i-160]?.getD entry) else (st180[i-180]?.getD entry))))) else entry
def hs (i : Nat) : List Nat := (if i < 100 then (if i < 40 then (if i < 20 then (hs0[i-0]?.getD []) else (hs20[i-20]?.getD [])) else (if i < 60 then (hs40[i-40]?.getD []) else (if i < 80 then (hs60[i-60]?.getD []) else (hs80[i-80]?.getD [])))) else (if i < 140 then (if i < 120 then (hs100[i-100]?.getD []) else (hs120[i-120]?.getD [])) else (if i < 160 then (hs140[i-140]?.getD []) else (if i < 180 then (hs160[i-160]?.getD []) else (hs180[i-180]?.getD [])))))
def validState (i : Nat) := FloorIndex.check P V K st i (hs i)
end Certgen.R302887501034
