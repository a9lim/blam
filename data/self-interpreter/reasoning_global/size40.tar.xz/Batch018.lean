import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e300769149850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e300769149850 : Closed e300769149850 ∧ code e300769149850 = 1400280777626 := by decide
theorem cert_e300769149850 : check e300769149850 [[]] .width = true := by decide
def e300769151770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e300769151770 : Closed e300769151770 ∧ code e300769151770 = 1400280779546 := by decide
theorem cert_e300769151770 : check e300769151770 [[]] .width = true := by decide
def e300769151814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e300769151814 : Closed e300769151814 ∧ code e300769151814 = 1400280779590 := by decide
theorem cert_e300769151814 : check e300769151814 [[]] .width = true := by decide
def e300769152054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e300769152054 : Closed e300769152054 ∧ code e300769152054 = 1400280779830 := by decide
theorem cert_e300769152054 : check e300769152054 [[]] .width = true := by decide
def e300769152058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e300769152058 : Closed e300769152058 ∧ code e300769152058 = 1400280779834 := by decide
theorem cert_e300769152058 : check e300769152058 [[]] .width = true := by decide
def e300769152198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e300769152198 : Closed e300769152198 ∧ code e300769152198 = 1400280779974 := by decide
theorem cert_e300769152198 : check e300769152198 [[]] .width = true := by decide
def e300774027462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300774027462 : Closed e300774027462 ∧ code e300774027462 = 1400285655238 := by decide
theorem cert_e300774027462 : check e300774027462 [[]] .width = true := by decide
def e300774043846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300774043846 : Closed e300774043846 ∧ code e300774043846 = 1400285671622 := by decide
theorem cert_e300774043846 : check e300774043846 [[]] .width = true := by decide
def e300775026886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300775026886 : Closed e300775026886 ∧ code e300775026886 = 1400286654662 := by decide
theorem cert_e300775026886 : check e300775026886 [[]] .width = true := by decide
def e300775035078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300775035078 : Closed e300775035078 ∧ code e300775035078 = 1400286662854 := by decide
theorem cert_e300775035078 : check e300775035078 [[]] .width = true := by decide
def e300775036954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300775036954 : Closed e300775036954 ∧ code e300775036954 = 1400286664730 := by decide
theorem cert_e300775036954 : check e300775036954 [[]] .width = true := by decide
def e300775067846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300775067846 : Closed e300775067846 ∧ code e300775067846 = 1400286695622 := by decide
theorem cert_e300775067846 : check e300775067846 [[]] .width = true := by decide
def e300775069722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300775069722 : Closed e300775069722 ∧ code e300775069722 = 1400286697498 := by decide
theorem cert_e300775069722 : check e300775069722 [[]] .width = true := by decide
def e300775073818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300775073818 : Closed e300775073818 ∧ code e300775073818 = 1400286701594 := by decide
theorem cert_e300775073818 : check e300775073818 [[]] .width = true := by decide
def e300775170074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300775170074 : Closed e300775170074 ∧ code e300775170074 = 1400286797850 := by decide
theorem cert_e300775170074 : check e300775170074 [[]] .width = true := by decide
def e300775170166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300775170166 : Closed e300775170166 ∧ code e300775170166 = 1400286797942 := by decide
theorem cert_e300775170166 : check e300775170166 [[]] .width = true := by decide
def e300775170410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300775170410 : Closed e300775170410 ∧ code e300775170410 = 1400286798186 := by decide
theorem cert_e300775170410 : check e300775170410 [[]] .width = true := by decide
def e300775170458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300775170458 : Closed e300775170458 ∧ code e300775170458 = 1400286798234 := by decide
theorem cert_e300775170458 : check e300775170458 [[]] .width = true := by decide
def e300775223494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300775223494 : Closed e300775223494 ∧ code e300775223494 = 1400286851270 := by decide
theorem cert_e300775223494 : check e300775223494 [[]] .width = true := by decide
def e300775231686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300775231686 : Closed e300775231686 ∧ code e300775231686 = 1400286859462 := by decide
theorem cert_e300775231686 : check e300775231686 [[]] .width = true := by decide
def e300775233562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300775233562 : Closed e300775233562 ∧ code e300775233562 = 1400286861338 := by decide
theorem cert_e300775233562 : check e300775233562 [[]] .width = true := by decide
def e300775309510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300775309510 : Closed e300775309510 ∧ code e300775309510 = 1400286937286 := by decide
theorem cert_e300775309510 : check e300775309510 [[]] .width = true := by decide
def e300775310038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e300775310038 : Closed e300775310038 ∧ code e300775310038 = 1400286937814 := by decide
theorem cert_e300775310038 : check e300775310038 [[]] .width = true := by decide
def e300775310042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e300775310042 : Closed e300775310042 ∧ code e300775310042 = 1400286937818 := by decide
theorem cert_e300775310042 : check e300775310042 [[]] .width = true := by decide
def e300775310058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e300775310058 : Closed e300775310058 ∧ code e300775310058 = 1400286937834 := by decide
theorem cert_e300775310058 : check e300775310058 [[]] .width = true := by decide
def e300775310134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e300775310134 : Closed e300775310134 ∧ code e300775310134 = 1400286937910 := by decide
theorem cert_e300775310134 : check e300775310134 [[]] .width = true := by decide
def e300775310138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e300775310138 : Closed e300775310138 ∧ code e300775310138 = 1400286937914 := by decide
theorem cert_e300775310138 : check e300775310138 [[]] .width = true := by decide
def e300775310222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e300775310222 : Closed e300775310222 ∧ code e300775310222 = 1400286937998 := by decide
theorem cert_e300775310222 : check e300775310222 [[]] .width = true := by decide
def e300775310234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e300775310234 : Closed e300775310234 ∧ code e300775310234 = 1400286938010 := by decide
theorem cert_e300775310234 : check e300775310234 [[]] .width = true := by decide
def e300775312154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e300775312154 : Closed e300775312154 ∧ code e300775312154 = 1400286939930 := by decide
theorem cert_e300775312154 : check e300775312154 [[]] .width = true := by decide
def e300775312198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e300775312198 : Closed e300775312198 ∧ code e300775312198 = 1400286939974 := by decide
theorem cert_e300775312198 : check e300775312198 [[]] .width = true := by decide
def e300775312438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e300775312438 : Closed e300775312438 ∧ code e300775312438 = 1400286940214 := by decide
theorem cert_e300775312438 : check e300775312438 [[]] .width = true := by decide
def e300775312442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e300775312442 : Closed e300775312442 ∧ code e300775312442 = 1400286940218 := by decide
theorem cert_e300775312442 : check e300775312442 [[]] .width = true := by decide
def e300775312582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e300775312582 : Closed e300775312582 ∧ code e300775312582 = 1400286940358 := by decide
theorem cert_e300775312582 : check e300775312582 [[]] .width = true := by decide
def e300775399450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e300775399450 : Closed e300775399450 ∧ code e300775399450 = 1400287027226 := by decide
theorem cert_e300775399450 : check e300775399450 [[]] .width = true := by decide
def e300775399542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e300775399542 : Closed e300775399542 ∧ code e300775399542 = 1400287027318 := by decide
theorem cert_e300775399542 : check e300775399542 [[]] .width = true := by decide
def e300775399786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e300775399786 : Closed e300775399786 ∧ code e300775399786 = 1400287027562 := by decide
theorem cert_e300775399786 : check e300775399786 [[]] .width = true := by decide
def e300775399834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e300775399834 : Closed e300775399834 ∧ code e300775399834 = 1400287027610 := by decide
theorem cert_e300775399834 : check e300775399834 [[]] .width = true := by decide
def e300775428294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e300775428294 : Closed e300775428294 ∧ code e300775428294 = 1400287056070 := by decide
theorem cert_e300775428294 : check e300775428294 [[]] .width = true := by decide
def e300775430170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300775430170 : Closed e300775430170 ∧ code e300775430170 = 1400287057946 := by decide
theorem cert_e300775430170 : check e300775430170 [[]] .width = true := by decide
def e300775434266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e300775434266 : Closed e300775434266 ∧ code e300775434266 = 1400287062042 := by decide
theorem cert_e300775434266 : check e300775434266 [[]] .width = true := by decide
def e300775440582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e300775440582 : Closed e300775440582 ∧ code e300775440582 = 1400287068358 := by decide
theorem cert_e300775440582 : check e300775440582 [[]] .width = true := by decide
def e300775441110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e300775441110 : Closed e300775441110 ∧ code e300775441110 = 1400287068886 := by decide
theorem cert_e300775441110 : check e300775441110 [[]] .width = true := by decide
def e300775441114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e300775441114 : Closed e300775441114 ∧ code e300775441114 = 1400287068890 := by decide
theorem cert_e300775441114 : check e300775441114 [[]] .width = true := by decide
def e300775441130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e300775441130 : Closed e300775441130 ∧ code e300775441130 = 1400287068906 := by decide
theorem cert_e300775441130 : check e300775441130 [[]] .width = true := by decide
def e300775441206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e300775441206 : Closed e300775441206 ∧ code e300775441206 = 1400287068982 := by decide
theorem cert_e300775441206 : check e300775441206 [[]] .width = true := by decide
def e300775441210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e300775441210 : Closed e300775441210 ∧ code e300775441210 = 1400287068986 := by decide
theorem cert_e300775441210 : check e300775441210 [[]] .width = true := by decide
def e300775441294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e300775441294 : Closed e300775441294 ∧ code e300775441294 = 1400287069070 := by decide
theorem cert_e300775441294 : check e300775441294 [[]] .width = true := by decide
def e300775441306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e300775441306 : Closed e300775441306 ∧ code e300775441306 = 1400287069082 := by decide
theorem cert_e300775441306 : check e300775441306 [[]] .width = true := by decide
def e300775443226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e300775443226 : Closed e300775443226 ∧ code e300775443226 = 1400287071002 := by decide
theorem cert_e300775443226 : check e300775443226 [[]] .width = true := by decide
def e300775443270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e300775443270 : Closed e300775443270 ∧ code e300775443270 = 1400287071046 := by decide
theorem cert_e300775443270 : check e300775443270 [[]] .width = true := by decide
def e300775443510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e300775443510 : Closed e300775443510 ∧ code e300775443510 = 1400287071286 := by decide
theorem cert_e300775443510 : check e300775443510 [[]] .width = true := by decide
def e300775443514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e300775443514 : Closed e300775443514 ∧ code e300775443514 = 1400287071290 := by decide
theorem cert_e300775443514 : check e300775443514 [[]] .width = true := by decide
def e300775443654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e300775443654 : Closed e300775443654 ∧ code e300775443654 = 1400287071430 := by decide
theorem cert_e300775443654 : check e300775443654 [[]] .width = true := by decide
def e300882680686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e300882680686 : Closed e300882680686 ∧ code e300882680686 = 1400394308462 := by decide
theorem cert_e300882680686 : check e300882680686 [[],[]] .chain = true := by decide
def e300882680694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e300882680694 : Closed e300882680694 ∧ code e300882680694 = 1400394308470 := by decide
theorem cert_e300882680694 : check e300882680694 [[],[]] .chain = true := by decide
def e300882680758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e300882680758 : Closed e300882680758 ∧ code e300882680758 = 1400394308534 := by decide
theorem cert_e300882680758 : check e300882680758 [[],[]] .chain = true := by decide
def e300882681198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e300882681198 : Closed e300882681198 ∧ code e300882681198 = 1400394308974 := by decide
theorem cert_e300882681198 : check e300882681198 [[],[]] .chain = true := by decide
def e300882681206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e300882681206 : Closed e300882681206 ∧ code e300882681206 = 1400394308982 := by decide
theorem cert_e300882681206 : check e300882681206 [[],[]] .chain = true := by decide
def e300882681262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e300882681262 : Closed e300882681262 ∧ code e300882681262 = 1400394309038 := by decide
theorem cert_e300882681262 : check e300882681262 [[],[]] .chain = true := by decide
def e300882681274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e300882681274 : Closed e300882681274 ∧ code e300882681274 = 1400394309050 := by decide
theorem cert_e300882681274 : check e300882681274 [[],[]] .chain = true := by decide
def e300882681302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e300882681302 : Closed e300882681302 ∧ code e300882681302 = 1400394309078 := by decide
theorem cert_e300882681302 : check e300882681302 [[],[]] .chain = true := by decide
def e300882681306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e300882681306 : Closed e300882681306 ∧ code e300882681306 = 1400394309082 := by decide
theorem cert_e300882681306 : check e300882681306 [[],[]] .chain = true := by decide
def e300882681526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e300882681526 : Closed e300882681526 ∧ code e300882681526 = 1400394309302 := by decide
theorem cert_e300882681526 : check e300882681526 [[],[]] .chain = true := by decide
def e300882681558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e300882681558 : Closed e300882681558 ∧ code e300882681558 = 1400394309334 := by decide
theorem cert_e300882681558 : check e300882681558 [[],[]] .chain = true := by decide
def e300882681562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e300882681562 : Closed e300882681562 ∧ code e300882681562 = 1400394309338 := by decide
theorem cert_e300882681562 : check e300882681562 [[],[]] .chain = true := by decide
def e300882683758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e300882683758 : Closed e300882683758 ∧ code e300882683758 = 1400394311534 := by decide
theorem cert_e300882683758 : check e300882683758 [[],[]] .chain = true := by decide
def e300882683766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e300882683766 : Closed e300882683766 ∧ code e300882683766 = 1400394311542 := by decide
theorem cert_e300882683766 : check e300882683766 [[],[]] .chain = true := by decide
def e300882683830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e300882683830 : Closed e300882683830 ∧ code e300882683830 = 1400394311606 := by decide
theorem cert_e300882683830 : check e300882683830 [[],[]] .chain = true := by decide
def e300882685166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e300882685166 : Closed e300882685166 ∧ code e300882685166 = 1400394312942 := by decide
theorem cert_e300882685166 : check e300882685166 [[],[]] .chain = true := by decide
def e300882685174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e300882685174 : Closed e300882685174 ∧ code e300882685174 = 1400394312950 := by decide
theorem cert_e300882685174 : check e300882685174 [[],[]] .chain = true := by decide
def e300882685558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e300882685558 : Closed e300882685558 ∧ code e300882685558 = 1400394313334 := by decide
theorem cert_e300882685558 : check e300882685558 [[],[]] .chain = true := by decide
def e300882686830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e300882686830 : Closed e300882686830 ∧ code e300882686830 = 1400394314606 := by decide
theorem cert_e300882686830 : check e300882686830 [[],[]] .chain = true := by decide
def e300882686838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e300882686838 : Closed e300882686838 ∧ code e300882686838 = 1400394314614 := by decide
theorem cert_e300882686838 : check e300882686838 [[],[]] .chain = true := by decide
def e300882686894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e300882686894 : Closed e300882686894 ∧ code e300882686894 = 1400394314670 := by decide
theorem cert_e300882686894 : check e300882686894 [[],[]] .chain = true := by decide
def e300882686906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e300882686906 : Closed e300882686906 ∧ code e300882686906 = 1400394314682 := by decide
theorem cert_e300882686906 : check e300882686906 [[],[]] .chain = true := by decide
def e300882686934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e300882686934 : Closed e300882686934 ∧ code e300882686934 = 1400394314710 := by decide
theorem cert_e300882686934 : check e300882686934 [[],[]] .chain = true := by decide
def e300882686938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e300882686938 : Closed e300882686938 ∧ code e300882686938 = 1400394314714 := by decide
theorem cert_e300882686938 : check e300882686938 [[],[]] .chain = true := by decide
def e300882687214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e300882687214 : Closed e300882687214 ∧ code e300882687214 = 1400394314990 := by decide
theorem cert_e300882687214 : check e300882687214 [[],[]] .chain = true := by decide
def e300882687222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e300882687222 : Closed e300882687222 ∧ code e300882687222 = 1400394314998 := by decide
theorem cert_e300882687222 : check e300882687222 [[],[]] .chain = true := by decide
def e300882687598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e300882687598 : Closed e300882687598 ∧ code e300882687598 = 1400394315374 := by decide
theorem cert_e300882687598 : check e300882687598 [[],[]] .chain = true := by decide
def e300882687610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e300882687610 : Closed e300882687610 ∧ code e300882687610 = 1400394315386 := by decide
theorem cert_e300882687610 : check e300882687610 [[],[]] .chain = true := by decide
def e300882687798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e300882687798 : Closed e300882687798 ∧ code e300882687798 = 1400394315574 := by decide
theorem cert_e300882687798 : check e300882687798 [[],[]] .chain = true := by decide
def e300882687802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e300882687802 : Closed e300882687802 ∧ code e300882687802 = 1400394315578 := by decide
theorem cert_e300882687802 : check e300882687802 [[],[]] .chain = true := by decide
def e300882688438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e300882688438 : Closed e300882688438 ∧ code e300882688438 = 1400394316214 := by decide
theorem cert_e300882688438 : check e300882688438 [[],[]] .chain = true := by decide
def e300882688470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e300882688470 : Closed e300882688470 ∧ code e300882688470 = 1400394316246 := by decide
theorem cert_e300882688470 : check e300882688470 [[],[]] .chain = true := by decide
def e300882688474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e300882688474 : Closed e300882688474 ∧ code e300882688474 = 1400394316250 := by decide
theorem cert_e300882688474 : check e300882688474 [[],[]] .chain = true := by decide
def e300882688630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e300882688630 : Closed e300882688630 ∧ code e300882688630 = 1400394316406 := by decide
theorem cert_e300882688630 : check e300882688630 [[],[]] .chain = true := by decide
def e300882688822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e300882688822 : Closed e300882688822 ∧ code e300882688822 = 1400394316598 := by decide
theorem cert_e300882688822 : check e300882688822 [[],[]] .chain = true := by decide
def e300882688826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e300882688826 : Closed e300882688826 ∧ code e300882688826 = 1400394316602 := by decide
theorem cert_e300882688826 : check e300882688826 [[],[]] .chain = true := by decide
def e300882696046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e300882696046 : Closed e300882696046 ∧ code e300882696046 = 1400394323822 := by decide
theorem cert_e300882696046 : check e300882696046 [[],[]] .chain = true := by decide
def e300882696054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e300882696054 : Closed e300882696054 ∧ code e300882696054 = 1400394323830 := by decide
theorem cert_e300882696054 : check e300882696054 [[],[]] .chain = true := by decide
def e300882696118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e300882696118 : Closed e300882696118 ∧ code e300882696118 = 1400394323894 := by decide
theorem cert_e300882696118 : check e300882696118 [[],[]] .chain = true := by decide
def e300882697454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e300882697454 : Closed e300882697454 ∧ code e300882697454 = 1400394325230 := by decide
theorem cert_e300882697454 : check e300882697454 [[],[]] .chain = true := by decide
def e300882697462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e300882697462 : Closed e300882697462 ∧ code e300882697462 = 1400394325238 := by decide
theorem cert_e300882697462 : check e300882697462 [[],[]] .chain = true := by decide
def e300882697846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e300882697846 : Closed e300882697846 ∧ code e300882697846 = 1400394325622 := by decide
theorem cert_e300882697846 : check e300882697846 [[],[]] .chain = true := by decide
def e300882709358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e300882709358 : Closed e300882709358 ∧ code e300882709358 = 1400394337134 := by decide
theorem cert_e300882709358 : check e300882709358 [[],[]] .chain = true := by decide
def e300882709366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e300882709366 : Closed e300882709366 ∧ code e300882709366 = 1400394337142 := by decide
theorem cert_e300882709366 : check e300882709366 [[],[]] .chain = true := by decide
def e300882709422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e300882709422 : Closed e300882709422 ∧ code e300882709422 = 1400394337198 := by decide
theorem cert_e300882709422 : check e300882709422 [[],[]] .chain = true := by decide
def e300882709434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e300882709434 : Closed e300882709434 ∧ code e300882709434 = 1400394337210 := by decide
theorem cert_e300882709434 : check e300882709434 [[],[]] .chain = true := by decide
def e300882709462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e300882709462 : Closed e300882709462 ∧ code e300882709462 = 1400394337238 := by decide
theorem cert_e300882709462 : check e300882709462 [[],[]] .chain = true := by decide
def e300882709466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e300882709466 : Closed e300882709466 ∧ code e300882709466 = 1400394337242 := by decide
theorem cert_e300882709466 : check e300882709466 [[],[]] .chain = true := by decide
def e300882709742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e300882709742 : Closed e300882709742 ∧ code e300882709742 = 1400394337518 := by decide
theorem cert_e300882709742 : check e300882709742 [[],[]] .chain = true := by decide
def e300882709750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e300882709750 : Closed e300882709750 ∧ code e300882709750 = 1400394337526 := by decide
theorem cert_e300882709750 : check e300882709750 [[],[]] .chain = true := by decide
def e300882710126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e300882710126 : Closed e300882710126 ∧ code e300882710126 = 1400394337902 := by decide
theorem cert_e300882710126 : check e300882710126 [[],[]] .chain = true := by decide
def e300882710138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e300882710138 : Closed e300882710138 ∧ code e300882710138 = 1400394337914 := by decide
theorem cert_e300882710138 : check e300882710138 [[],[]] .chain = true := by decide
def e300882710326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e300882710326 : Closed e300882710326 ∧ code e300882710326 = 1400394338102 := by decide
theorem cert_e300882710326 : check e300882710326 [[],[]] .chain = true := by decide
def e300882710330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e300882710330 : Closed e300882710330 ∧ code e300882710330 = 1400394338106 := by decide
theorem cert_e300882710330 : check e300882710330 [[],[]] .chain = true := by decide
def e300882716086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e300882716086 : Closed e300882716086 ∧ code e300882716086 = 1400394343862 := by decide
theorem cert_e300882716086 : check e300882716086 [[],[]] .chain = true := by decide
def e300882716118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e300882716118 : Closed e300882716118 ∧ code e300882716118 = 1400394343894 := by decide
theorem cert_e300882716118 : check e300882716118 [[],[]] .chain = true := by decide
def e300882716122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e300882716122 : Closed e300882716122 ∧ code e300882716122 = 1400394343898 := by decide
theorem cert_e300882716122 : check e300882716122 [[],[]] .chain = true := by decide
def e300882716278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e300882716278 : Closed e300882716278 ∧ code e300882716278 = 1400394344054 := by decide
theorem cert_e300882716278 : check e300882716278 [[],[]] .chain = true := by decide
def e300882716470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e300882716470 : Closed e300882716470 ∧ code e300882716470 = 1400394344246 := by decide
theorem cert_e300882716470 : check e300882716470 [[],[]] .chain = true := by decide
def e300882716474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e300882716474 : Closed e300882716474 ∧ code e300882716474 = 1400394344250 := by decide
theorem cert_e300882716474 : check e300882716474 [[],[]] .chain = true := by decide
def e300883053422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e300883053422 : Closed e300883053422 ∧ code e300883053422 = 1400394681198 := by decide
theorem cert_e300883053422 : check e300883053422 [[],[],[.under]] .smaller = true := by decide
def e300883053430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e300883053430 : Closed e300883053430 ∧ code e300883053430 = 1400394681206 := by decide
theorem cert_e300883053430 : check e300883053430 [[],[],[.under]] .smaller = true := by decide
def e300883053486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e300883053486 : Closed e300883053486 ∧ code e300883053486 = 1400394681262 := by decide
theorem cert_e300883053486 : check e300883053486 [[],[],[.under]] .smaller = true := by decide
def e300883053498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e300883053498 : Closed e300883053498 ∧ code e300883053498 = 1400394681274 := by decide
theorem cert_e300883053498 : check e300883053498 [[],[],[.under]] .smaller = true := by decide
def e300883053526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e300883053526 : Closed e300883053526 ∧ code e300883053526 = 1400394681302 := by decide
theorem cert_e300883053526 : check e300883053526 [[],[],[.under]] .smaller = true := by decide
def e300883053530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e300883053530 : Closed e300883053530 ∧ code e300883053530 = 1400394681306 := by decide
theorem cert_e300883053530 : check e300883053530 [[],[],[.under]] .smaller = true := by decide
def e300883053806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e300883053806 : Closed e300883053806 ∧ code e300883053806 = 1400394681582 := by decide
theorem cert_e300883053806 : check e300883053806 [[],[],[.under]] .smaller = true := by decide
def e300883053814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e300883053814 : Closed e300883053814 ∧ code e300883053814 = 1400394681590 := by decide
theorem cert_e300883053814 : check e300883053814 [[],[],[.under]] .smaller = true := by decide
def e300883054190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e300883054190 : Closed e300883054190 ∧ code e300883054190 = 1400394681966 := by decide
theorem cert_e300883054190 : check e300883054190 [[],[],[.under]] .smaller = true := by decide
def e300883054202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e300883054202 : Closed e300883054202 ∧ code e300883054202 = 1400394681978 := by decide
theorem cert_e300883054202 : check e300883054202 [[],[],[.under]] .smaller = true := by decide
def e300883054390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e300883054390 : Closed e300883054390 ∧ code e300883054390 = 1400394682166 := by decide
theorem cert_e300883054390 : check e300883054390 [[],[],[.under]] .smaller = true := by decide
def e300883054394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e300883054394 : Closed e300883054394 ∧ code e300883054394 = 1400394682170 := by decide
theorem cert_e300883054394 : check e300883054394 [[],[],[.under]] .smaller = true := by decide
def e301056356550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e301056356550 : Closed e301056356550 ∧ code e301056356550 = 1400567984326 := by decide
theorem cert_e301056356550 : check e301056356550 [[]] .width = true := by decide
def e301056372934 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e301056372934 : Closed e301056372934 ∧ code e301056372934 = 1400568000710 := by decide
theorem cert_e301056372934 : check e301056372934 [[]] .width = true := by decide
def e301056487622 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e301056487622 : Closed e301056487622 ∧ code e301056487622 = 1400568115398 := by decide
theorem cert_e301056487622 : check e301056487622 [[]] .width = true := by decide
def e301056512198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e301056512198 : Closed e301056512198 ∧ code e301056512198 = 1400568139974 := by decide
theorem cert_e301056512198 : check e301056512198 [[]] .width = true := by decide
def e301056569542 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e301056569542 : Closed e301056569542 ∧ code e301056569542 = 1400568197318 := by decide
theorem cert_e301056569542 : check e301056569542 [[]] .width = true := by decide
def e301056577734 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e301056577734 : Closed e301056577734 ∧ code e301056577734 = 1400568205510 := by decide
theorem cert_e301056577734 : check e301056577734 [[]] .width = true := by decide
def e301057142982 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e301057142982 : Closed e301057142982 ∧ code e301057142982 = 1400568770758 := by decide
theorem cert_e301057142982 : check e301057142982 [[]] .width = true := by decide
def e301057159366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e301057159366 : Closed e301057159366 ∧ code e301057159366 = 1400568787142 := by decide
theorem cert_e301057159366 : check e301057159366 [[]] .width = true := by decide
def e301057929414 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e301057929414 : Closed e301057929414 ∧ code e301057929414 = 1400569557190 := by decide
theorem cert_e301057929414 : check e301057929414 [[]] .width = true := by decide
def e301057953990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e301057953990 : Closed e301057953990 ∧ code e301057953990 = 1400569581766 := by decide
theorem cert_e301057953990 : check e301057953990 [[]] .width = true := by decide
def e301058339014 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e301058339014 : Closed e301058339014 ∧ code e301058339014 = 1400569966790 := by decide
theorem cert_e301058339014 : check e301058339014 [[]] .width = true := by decide
def e301058347206 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e301058347206 : Closed e301058347206 ∧ code e301058347206 = 1400569974982 := by decide
theorem cert_e301058347206 : check e301058347206 [[]] .width = true := by decide
def e301100739950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e301100739950 : Closed e301100739950 ∧ code e301100739950 = 1400612367726 := by decide
theorem cert_e301100739950 : check e301100739950 [[],[]] .chain = true := by decide
def e301100739958 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e301100739958 : Closed e301100739958 ∧ code e301100739958 = 1400612367734 := by decide
theorem cert_e301100739958 : check e301100739958 [[],[]] .chain = true := by decide
def e301100740014 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e301100740014 : Closed e301100740014 ∧ code e301100740014 = 1400612367790 := by decide
theorem cert_e301100740014 : check e301100740014 [[],[]] .chain = true := by decide
def e301100740026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e301100740026 : Closed e301100740026 ∧ code e301100740026 = 1400612367802 := by decide
theorem cert_e301100740026 : check e301100740026 [[],[]] .chain = true := by decide
def e301100740054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e301100740054 : Closed e301100740054 ∧ code e301100740054 = 1400612367830 := by decide
theorem cert_e301100740054 : check e301100740054 [[],[]] .chain = true := by decide
def e301100740058 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e301100740058 : Closed e301100740058 ∧ code e301100740058 = 1400612367834 := by decide
theorem cert_e301100740058 : check e301100740058 [[],[]] .chain = true := by decide
def e301100740270 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e301100740270 : Closed e301100740270 ∧ code e301100740270 = 1400612368046 := by decide
theorem cert_e301100740270 : check e301100740270 [[],[]] .chain = true := by decide
def e301100740282 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e301100740282 : Closed e301100740282 ∧ code e301100740282 = 1400612368058 := by decide
theorem cert_e301100740282 : check e301100740282 [[],[]] .chain = true := by decide
def e301100740330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e301100740330 : Closed e301100740330 ∧ code e301100740330 = 1400612368106 := by decide
theorem cert_e301100740330 : check e301100740330 [[],[]] .chain = true := by decide
def e301100740438 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e301100740438 : Closed e301100740438 ∧ code e301100740438 = 1400612368214 := by decide
theorem cert_e301100740438 : check e301100740438 [[],[]] .chain = true := by decide
def e301100740442 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e301100740442 : Closed e301100740442 ∧ code e301100740442 = 1400612368218 := by decide
theorem cert_e301100740442 : check e301100740442 [[],[]] .chain = true := by decide
def e301100740458 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e301100740458 : Closed e301100740458 ∧ code e301100740458 = 1400612368234 := by decide
theorem cert_e301100740458 : check e301100740458 [[],[]] .chain = true := by decide
def e301100741486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e301100741486 : Closed e301100741486 ∧ code e301100741486 = 1400612369262 := by decide
theorem cert_e301100741486 : check e301100741486 [[],[]] .chain = true := by decide
def e301100741494 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e301100741494 : Closed e301100741494 ∧ code e301100741494 = 1400612369270 := by decide
theorem cert_e301100741494 : check e301100741494 [[],[]] .chain = true := by decide
def e301100741550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e301100741550 : Closed e301100741550 ∧ code e301100741550 = 1400612369326 := by decide
theorem cert_e301100741550 : check e301100741550 [[],[]] .chain = true := by decide
def e301100741562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e301100741562 : Closed e301100741562 ∧ code e301100741562 = 1400612369338 := by decide
theorem cert_e301100741562 : check e301100741562 [[],[]] .chain = true := by decide
def e301100741590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e301100741590 : Closed e301100741590 ∧ code e301100741590 = 1400612369366 := by decide
theorem cert_e301100741590 : check e301100741590 [[],[]] .chain = true := by decide
def e301100741594 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e301100741594 : Closed e301100741594 ∧ code e301100741594 = 1400612369370 := by decide
theorem cert_e301100741594 : check e301100741594 [[],[]] .chain = true := by decide
def e301100741870 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e301100741870 : Closed e301100741870 ∧ code e301100741870 = 1400612369646 := by decide
theorem cert_e301100741870 : check e301100741870 [[],[]] .chain = true := by decide
def e301100741878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e301100741878 : Closed e301100741878 ∧ code e301100741878 = 1400612369654 := by decide
theorem cert_e301100741878 : check e301100741878 [[],[]] .chain = true := by decide
def e301100742254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e301100742254 : Closed e301100742254 ∧ code e301100742254 = 1400612370030 := by decide
theorem cert_e301100742254 : check e301100742254 [[],[]] .chain = true := by decide
def e301100742266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e301100742266 : Closed e301100742266 ∧ code e301100742266 = 1400612370042 := by decide
theorem cert_e301100742266 : check e301100742266 [[],[]] .chain = true := by decide
end Blc.Floor40
