import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302795594206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e302795594206 : Closed e302795594206 ∧ code e302795594206 = 1402307221982 := by decide
theorem cert_e302795594206 : check e302795594206 [[],[]] .smaller = true := by decide
def e302795594230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e302795594230 : Closed e302795594230 ∧ code e302795594230 = 1402307222006 := by decide
theorem cert_e302795594230 : check e302795594230 [[],[]] .smaller = true := by decide
def e302795594974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e302795594974 : Closed e302795594974 ∧ code e302795594974 = 1402307222750 := by decide
theorem cert_e302795594974 : check e302795594974 [[],[]] .smaller = true := by decide
def e302795595002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e302795595002 : Closed e302795595002 ∧ code e302795595002 = 1402307222778 := by decide
theorem cert_e302795595002 : check e302795595002 [[],[]] .smaller = true := by decide
def e302795595574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e302795595574 : Closed e302795595574 ∧ code e302795595574 = 1402307223350 := by decide
theorem cert_e302795595574 : check e302795595574 [[],[]] .smaller = true := by decide
def e302795595578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e302795595578 : Closed e302795595578 ∧ code e302795595578 = 1402307223354 := by decide
theorem cert_e302795595578 : check e302795595578 [[],[]] .smaller = true := by decide
def e302795610350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e302795610350 : Closed e302795610350 ∧ code e302795610350 = 1402307238126 := by decide
theorem cert_e302795610350 : check e302795610350 [[],[]] .smaller = true := by decide
def e302795610358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e302795610358 : Closed e302795610358 ∧ code e302795610358 = 1402307238134 := by decide
theorem cert_e302795610358 : check e302795610358 [[],[]] .smaller = true := by decide
def e302795610910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e302795610910 : Closed e302795610910 ∧ code e302795610910 = 1402307238686 := by decide
theorem cert_e302795610910 : check e302795610910 [[],[]] .smaller = true := by decide
def e302795611022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e302795611022 : Closed e302795611022 ∧ code e302795611022 = 1402307238798 := by decide
theorem cert_e302795611022 : check e302795611022 [[],[]] .smaller = true := by decide
def e302795611070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 4)))))))))
theorem wire_e302795611070 : Closed e302795611070 ∧ code e302795611070 = 1402307238846 := by decide
theorem cert_e302795611070 : check e302795611070 [[],[]] .three = true := by decide
def e302795611118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 2)))))))))
theorem wire_e302795611118 : Closed e302795611118 ∧ code e302795611118 = 1402307238894 := by decide
theorem cert_e302795611118 : check e302795611118 [[],[]] .three = true := by decide
def e302795611246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e302795611246 : Closed e302795611246 ∧ code e302795611246 = 1402307239022 := by decide
theorem cert_e302795611246 : check e302795611246 [[],[]] .smaller = true := by decide
def e302795611258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e302795611258 : Closed e302795611258 ∧ code e302795611258 = 1402307239034 := by decide
theorem cert_e302795611258 : check e302795611258 [[],[]] .smaller = true := by decide
def e302795611422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e302795611422 : Closed e302795611422 ∧ code e302795611422 = 1402307239198 := by decide
theorem cert_e302795611422 : check e302795611422 [[],[]] .smaller = true := by decide
def e302795611582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 4)))))))))
theorem wire_e302795611582 : Closed e302795611582 ∧ code e302795611582 = 1402307239358 := by decide
theorem cert_e302795611582 : check e302795611582 [[],[]] .three = true := by decide
def e302795611590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e302795611590 : Closed e302795611590 ∧ code e302795611590 = 1402307239366 := by decide
theorem cert_e302795611590 : check e302795611590 [[],[]] .smaller = true := by decide
def e302795611638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.var 1)))))))))
theorem wire_e302795611638 : Closed e302795611638 ∧ code e302795611638 = 1402307239414 := by decide
theorem cert_e302795611638 : check e302795611638 [[],[]] .three = true := by decide
def e302795611702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e302795611702 : Closed e302795611702 ∧ code e302795611702 = 1402307239478 := by decide
theorem cert_e302795611702 : check e302795611702 [[],[]] .smaller = true := by decide
def e302795611706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e302795611706 : Closed e302795611706 ∧ code e302795611706 = 1402307239482 := by decide
theorem cert_e302795611706 : check e302795611706 [[],[]] .smaller = true := by decide
def e302795611790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e302795611790 : Closed e302795611790 ∧ code e302795611790 = 1402307239566 := by decide
theorem cert_e302795611790 : check e302795611790 [[],[]] .smaller = true := by decide
def e302795611838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 4)))))))))
theorem wire_e302795611838 : Closed e302795611838 ∧ code e302795611838 = 1402307239614 := by decide
theorem cert_e302795611838 : check e302795611838 [[],[]] .three = true := by decide
def e302795611846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e302795611846 : Closed e302795611846 ∧ code e302795611846 = 1402307239622 := by decide
theorem cert_e302795611846 : check e302795611846 [[],[]] .smaller = true := by decide
def e302795611898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 4)) (.var 0)))))))))
theorem wire_e302795611898 : Closed e302795611898 ∧ code e302795611898 = 1402307239674 := by decide
theorem cert_e302795611898 : check e302795611898 [[],[]] .three = true := by decide
def e302795612078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 2)))))))))
theorem wire_e302795612078 : Closed e302795612078 ∧ code e302795612078 = 1402307239854 := by decide
theorem cert_e302795612078 : check e302795612078 [[],[]] .three = true := by decide
def e302795612086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.var 1)))))))))
theorem wire_e302795612086 : Closed e302795612086 ∧ code e302795612086 = 1402307239862 := by decide
theorem cert_e302795612086 : check e302795612086 [[],[]] .three = true := by decide
def e302795612090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 2)) (.var 0)))))))))
theorem wire_e302795612090 : Closed e302795612090 ∧ code e302795612090 = 1402307239866 := by decide
theorem cert_e302795612090 : check e302795612090 [[],[]] .three = true := by decide
def e302795613982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e302795613982 : Closed e302795613982 ∧ code e302795613982 = 1402307241758 := by decide
theorem cert_e302795613982 : check e302795613982 [[],[]] .smaller = true := by decide
def e302795614094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e302795614094 : Closed e302795614094 ∧ code e302795614094 = 1402307241870 := by decide
theorem cert_e302795614094 : check e302795614094 [[],[]] .smaller = true := by decide
def e302795614142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 4))))))))))
theorem wire_e302795614142 : Closed e302795614142 ∧ code e302795614142 = 1402307241918 := by decide
theorem cert_e302795614142 : check e302795614142 [[],[]] .three = true := by decide
def e302795614190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 2))))))))))
theorem wire_e302795614190 : Closed e302795614190 ∧ code e302795614190 = 1402307241966 := by decide
theorem cert_e302795614190 : check e302795614190 [[],[]] .three = true := by decide
def e302795617054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e302795617054 : Closed e302795617054 ∧ code e302795617054 = 1402307244830 := by decide
theorem cert_e302795617054 : check e302795617054 [[],[]] .smaller = true := by decide
def e302795617214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 4))))))))))
theorem wire_e302795617214 : Closed e302795617214 ∧ code e302795617214 = 1402307244990 := by decide
theorem cert_e302795617214 : check e302795617214 [[],[]] .three = true := by decide
def e302795617222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e302795617222 : Closed e302795617222 ∧ code e302795617222 = 1402307244998 := by decide
theorem cert_e302795617222 : check e302795617222 [[],[]] .smaller = true := by decide
def e302795617270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.var 1))))))))))
theorem wire_e302795617270 : Closed e302795617270 ∧ code e302795617270 = 1402307245046 := by decide
theorem cert_e302795617270 : check e302795617270 [[],[]] .three = true := by decide
def e302795618702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e302795618702 : Closed e302795618702 ∧ code e302795618702 = 1402307246478 := by decide
theorem cert_e302795618702 : check e302795618702 [[],[]] .smaller = true := by decide
def e302795618750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 4))))))))))
theorem wire_e302795618750 : Closed e302795618750 ∧ code e302795618750 = 1402307246526 := by decide
theorem cert_e302795618750 : check e302795618750 [[],[]] .three = true := by decide
def e302795618758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e302795618758 : Closed e302795618758 ∧ code e302795618758 = 1402307246534 := by decide
theorem cert_e302795618758 : check e302795618758 [[],[]] .smaller = true := by decide
def e302795618810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 4) (.var 0))))))))))
theorem wire_e302795618810 : Closed e302795618810 ∧ code e302795618810 = 1402307246586 := by decide
theorem cert_e302795618810 : check e302795618810 [[],[]] .three = true := by decide
def e302795619950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 2))))))))))
theorem wire_e302795619950 : Closed e302795619950 ∧ code e302795619950 = 1402307247726 := by decide
theorem cert_e302795619950 : check e302795619950 [[],[]] .three = true := by decide
def e302795619958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.var 1))))))))))
theorem wire_e302795619958 : Closed e302795619958 ∧ code e302795619958 = 1402307247734 := by decide
theorem cert_e302795619958 : check e302795619958 [[],[]] .three = true := by decide
def e302795619962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 2) (.var 0))))))))))
theorem wire_e302795619962 : Closed e302795619962 ∧ code e302795619962 = 1402307247738 := by decide
theorem cert_e302795619962 : check e302795619962 [[],[]] .three = true := by decide
def e302795656046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e302795656046 : Closed e302795656046 ∧ code e302795656046 = 1402307283822 := by decide
theorem cert_e302795656046 : check e302795656046 [[],[]] .smaller = true := by decide
def e302795656054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e302795656054 : Closed e302795656054 ∧ code e302795656054 = 1402307283830 := by decide
theorem cert_e302795656054 : check e302795656054 [[],[]] .smaller = true := by decide
def e302795656110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e302795656110 : Closed e302795656110 ∧ code e302795656110 = 1402307283886 := by decide
theorem cert_e302795656110 : check e302795656110 [[],[]] .smaller = true := by decide
def e302795656122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e302795656122 : Closed e302795656122 ∧ code e302795656122 = 1402307283898 := by decide
theorem cert_e302795656122 : check e302795656122 [[],[]] .smaller = true := by decide
def e302795656150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e302795656150 : Closed e302795656150 ∧ code e302795656150 = 1402307283926 := by decide
theorem cert_e302795656150 : check e302795656150 [[],[]] .smaller = true := by decide
def e302795656154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e302795656154 : Closed e302795656154 ∧ code e302795656154 = 1402307283930 := by decide
theorem cert_e302795656154 : check e302795656154 [[],[]] .smaller = true := by decide
def e302795656430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e302795656430 : Closed e302795656430 ∧ code e302795656430 = 1402307284206 := by decide
theorem cert_e302795656430 : check e302795656430 [[],[]] .smaller = true := by decide
def e302795656438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e302795656438 : Closed e302795656438 ∧ code e302795656438 = 1402307284214 := by decide
theorem cert_e302795656438 : check e302795656438 [[],[]] .smaller = true := by decide
def e302795656814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e302795656814 : Closed e302795656814 ∧ code e302795656814 = 1402307284590 := by decide
theorem cert_e302795656814 : check e302795656814 [[],[]] .smaller = true := by decide
def e302795656826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e302795656826 : Closed e302795656826 ∧ code e302795656826 = 1402307284602 := by decide
theorem cert_e302795656826 : check e302795656826 [[],[]] .smaller = true := by decide
def e302795657014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e302795657014 : Closed e302795657014 ∧ code e302795657014 = 1402307284790 := by decide
theorem cert_e302795657014 : check e302795657014 [[],[]] .smaller = true := by decide
def e302795657018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e302795657018 : Closed e302795657018 ∧ code e302795657018 = 1402307284794 := by decide
theorem cert_e302795657018 : check e302795657018 [[],[]] .smaller = true := by decide
def e302795664494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e302795664494 : Closed e302795664494 ∧ code e302795664494 = 1402307292270 := by decide
theorem cert_e302795664494 : check e302795664494 [[],[]] .smaller = true := by decide
def e302795664506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e302795664506 : Closed e302795664506 ∧ code e302795664506 = 1402307292282 := by decide
theorem cert_e302795664506 : check e302795664506 [[],[]] .smaller = true := by decide
def e302795664670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e302795664670 : Closed e302795664670 ∧ code e302795664670 = 1402307292446 := by decide
theorem cert_e302795664670 : check e302795664670 [[],[]] .smaller = true := by decide
def e302795664830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e302795664830 : Closed e302795664830 ∧ code e302795664830 = 1402307292606 := by decide
theorem cert_e302795664830 : check e302795664830 [[],[]] .three = true := by decide
def e302795664838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e302795664838 : Closed e302795664838 ∧ code e302795664838 = 1402307292614 := by decide
theorem cert_e302795664838 : check e302795664838 [[],[]] .smaller = true := by decide
def e302795664886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e302795664886 : Closed e302795664886 ∧ code e302795664886 = 1402307292662 := by decide
theorem cert_e302795664886 : check e302795664886 [[],[]] .three = true := by decide
def e302795665086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e302795665086 : Closed e302795665086 ∧ code e302795665086 = 1402307292862 := by decide
theorem cert_e302795665086 : check e302795665086 [[],[]] .three = true := by decide
def e302795665146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e302795665146 : Closed e302795665146 ∧ code e302795665146 = 1402307292922 := by decide
theorem cert_e302795665146 : check e302795665146 [[],[]] .three = true := by decide
def e302795665178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e302795665178 : Closed e302795665178 ∧ code e302795665178 = 1402307292954 := by decide
theorem cert_e302795665178 : check e302795665178 [[],[]] .smaller = true := by decide
def e302795665222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e302795665222 : Closed e302795665222 ∧ code e302795665222 = 1402307292998 := by decide
theorem cert_e302795665222 : check e302795665222 [[],[]] .smaller = true := by decide
def e302795665366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e302795665366 : Closed e302795665366 ∧ code e302795665366 = 1402307293142 := by decide
theorem cert_e302795665366 : check e302795665366 [[],[]] .three = true := by decide
def e302795665370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e302795665370 : Closed e302795665370 ∧ code e302795665370 = 1402307293146 := by decide
theorem cert_e302795665370 : check e302795665370 [[],[]] .three = true := by decide
def e302795666206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e302795666206 : Closed e302795666206 ∧ code e302795666206 = 1402307293982 := by decide
theorem cert_e302795666206 : check e302795666206 [[],[]] .smaller = true := by decide
def e302795666366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e302795666366 : Closed e302795666366 ∧ code e302795666366 = 1402307294142 := by decide
theorem cert_e302795666366 : check e302795666366 [[],[]] .three = true := by decide
def e302795666374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e302795666374 : Closed e302795666374 ∧ code e302795666374 = 1402307294150 := by decide
theorem cert_e302795666374 : check e302795666374 [[],[]] .smaller = true := by decide
def e302795666422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e302795666422 : Closed e302795666422 ∧ code e302795666422 = 1402307294198 := by decide
theorem cert_e302795666422 : check e302795666422 [[],[]] .three = true := by decide
def e302795667902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e302795667902 : Closed e302795667902 ∧ code e302795667902 = 1402307295678 := by decide
theorem cert_e302795667902 : check e302795667902 [[],[]] .three = true := by decide
def e302795667962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e302795667962 : Closed e302795667962 ∧ code e302795667962 = 1402307295738 := by decide
theorem cert_e302795667962 : check e302795667962 [[],[]] .three = true := by decide
def e302795668678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e302795668678 : Closed e302795668678 ∧ code e302795668678 = 1402307296454 := by decide
theorem cert_e302795668678 : check e302795668678 [[],[]] .smaller = true := by decide
def e302795669302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e302795669302 : Closed e302795669302 ∧ code e302795669302 = 1402307297078 := by decide
theorem cert_e302795669302 : check e302795669302 [[],[]] .three = true := by decide
def e302795669306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e302795669306 : Closed e302795669306 ∧ code e302795669306 = 1402307297082 := by decide
theorem cert_e302795669306 : check e302795669306 [[],[]] .three = true := by decide
def e302795691574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e302795691574 : Closed e302795691574 ∧ code e302795691574 = 1402307319350 := by decide
theorem cert_e302795691574 : check e302795691574 [[],[]] .smaller = true := by decide
def e302795691578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e302795691578 : Closed e302795691578 ∧ code e302795691578 = 1402307319354 := by decide
theorem cert_e302795691578 : check e302795691578 [[],[]] .smaller = true := by decide
def e302795691662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e302795691662 : Closed e302795691662 ∧ code e302795691662 = 1402307319438 := by decide
theorem cert_e302795691662 : check e302795691662 [[],[]] .smaller = true := by decide
def e302795691710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 4)))))))))
theorem wire_e302795691710 : Closed e302795691710 ∧ code e302795691710 = 1402307319486 := by decide
theorem cert_e302795691710 : check e302795691710 [[],[]] .three = true := by decide
def e302795691718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e302795691718 : Closed e302795691718 ∧ code e302795691718 = 1402307319494 := by decide
theorem cert_e302795691718 : check e302795691718 [[],[]] .smaller = true := by decide
def e302795691770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 4)) (.var 0)))))))))
theorem wire_e302795691770 : Closed e302795691770 ∧ code e302795691770 = 1402307319546 := by decide
theorem cert_e302795691770 : check e302795691770 [[],[]] .three = true := by decide
def e302795691802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e302795691802 : Closed e302795691802 ∧ code e302795691802 = 1402307319578 := by decide
theorem cert_e302795691802 : check e302795691802 [[],[]] .smaller = true := by decide
def e302795691846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e302795691846 : Closed e302795691846 ∧ code e302795691846 = 1402307319622 := by decide
theorem cert_e302795691846 : check e302795691846 [[],[]] .smaller = true := by decide
def e302795692010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 4) (.var 0)) (.var 0)))))))))
theorem wire_e302795692010 : Closed e302795692010 ∧ code e302795692010 = 1402307319786 := by decide
theorem cert_e302795692010 : check e302795692010 [[],[]] .three = true := by decide
def e302795692430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e302795692430 : Closed e302795692430 ∧ code e302795692430 = 1402307320206 := by decide
theorem cert_e302795692430 : check e302795692430 [[],[]] .smaller = true := by decide
def e302795692478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 4))))))))))
theorem wire_e302795692478 : Closed e302795692478 ∧ code e302795692478 = 1402307320254 := by decide
theorem cert_e302795692478 : check e302795692478 [[],[]] .three = true := by decide
def e302795692486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e302795692486 : Closed e302795692486 ∧ code e302795692486 = 1402307320262 := by decide
theorem cert_e302795692486 : check e302795692486 [[],[]] .smaller = true := by decide
def e302795692538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 4) (.var 0))))))))))
theorem wire_e302795692538 : Closed e302795692538 ∧ code e302795692538 = 1402307320314 := by decide
theorem cert_e302795692538 : check e302795692538 [[],[]] .three = true := by decide
def e302795693254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e302795693254 : Closed e302795693254 ∧ code e302795693254 = 1402307321030 := by decide
theorem cert_e302795693254 : check e302795693254 [[],[]] .smaller = true := by decide
def e302795693978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.app (.var 0) (.var 0))))))))))
theorem wire_e302795693978 : Closed e302795693978 ∧ code e302795693978 = 1402307321754 := by decide
theorem cert_e302795693978 : check e302795693978 [[],[]] .three = true := by decide
def e302795711918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e302795711918 : Closed e302795711918 ∧ code e302795711918 = 1402307339694 := by decide
theorem cert_e302795711918 : check e302795711918 [[],[]] .three = true := by decide
def e302795711926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e302795711926 : Closed e302795711926 ∧ code e302795711926 = 1402307339702 := by decide
theorem cert_e302795711926 : check e302795711926 [[],[]] .three = true := by decide
def e302795711930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e302795711930 : Closed e302795711930 ∧ code e302795711930 = 1402307339706 := by decide
theorem cert_e302795711930 : check e302795711930 [[],[]] .three = true := by decide
def e302795711958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e302795711958 : Closed e302795711958 ∧ code e302795711958 = 1402307339734 := by decide
theorem cert_e302795711958 : check e302795711958 [[],[]] .three = true := by decide
def e302795711962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e302795711962 : Closed e302795711962 ∧ code e302795711962 = 1402307339738 := by decide
theorem cert_e302795711962 : check e302795711962 [[],[]] .three = true := by decide
def e302795711978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e302795711978 : Closed e302795711978 ∧ code e302795711978 = 1402307339754 := by decide
theorem cert_e302795711978 : check e302795711978 [[],[]] .three = true := by decide
def e302795712110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e302795712110 : Closed e302795712110 ∧ code e302795712110 = 1402307339886 := by decide
theorem cert_e302795712110 : check e302795712110 [[],[]] .three = true := by decide
def e302795712118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e302795712118 : Closed e302795712118 ∧ code e302795712118 = 1402307339894 := by decide
theorem cert_e302795712118 : check e302795712118 [[],[]] .three = true := by decide
def e302795712122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e302795712122 : Closed e302795712122 ∧ code e302795712122 = 1402307339898 := by decide
theorem cert_e302795712122 : check e302795712122 [[],[]] .three = true := by decide
def e302795712310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e302795712310 : Closed e302795712310 ∧ code e302795712310 = 1402307340086 := by decide
theorem cert_e302795712310 : check e302795712310 [[],[]] .three = true := by decide
def e302795712314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e302795712314 : Closed e302795712314 ∧ code e302795712314 = 1402307340090 := by decide
theorem cert_e302795712314 : check e302795712314 [[],[]] .three = true := by decide
def e302795712410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e302795712410 : Closed e302795712410 ∧ code e302795712410 = 1402307340186 := by decide
theorem cert_e302795712410 : check e302795712410 [[],[]] .three = true := by decide
def e302796597982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e302796597982 : Closed e302796597982 ∧ code e302796597982 = 1402308225758 := by decide
theorem cert_e302796597982 : check e302796597982 [[],[]] .three = true := by decide
def e302796598006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e302796598006 : Closed e302796598006 ∧ code e302796598006 = 1402308225782 := by decide
theorem cert_e302796598006 : check e302796598006 [[],[]] .three = true := by decide
def e302796598110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e302796598110 : Closed e302796598110 ∧ code e302796598110 = 1402308225886 := by decide
theorem cert_e302796598110 : check e302796598110 [[],[]] .three = true := by decide
def e302796598126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e302796598126 : Closed e302796598126 ∧ code e302796598126 = 1402308225902 := by decide
theorem cert_e302796598126 : check e302796598126 [[],[]] .smaller = true := by decide
def e302796598134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e302796598134 : Closed e302796598134 ∧ code e302796598134 = 1402308225910 := by decide
theorem cert_e302796598134 : check e302796598134 [[],[]] .smaller = true := by decide
def e302796598138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e302796598138 : Closed e302796598138 ∧ code e302796598138 = 1402308225914 := by decide
theorem cert_e302796598138 : check e302796598138 [[],[]] .three = true := by decide
def e302796598198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e302796598198 : Closed e302796598198 ∧ code e302796598198 = 1402308225974 := by decide
theorem cert_e302796598198 : check e302796598198 [[],[]] .smaller = true := by decide
def e302796598230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e302796598230 : Closed e302796598230 ∧ code e302796598230 = 1402308226006 := by decide
theorem cert_e302796598230 : check e302796598230 [[],[]] .three = true := by decide
def e302796598234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e302796598234 : Closed e302796598234 ∧ code e302796598234 = 1402308226010 := by decide
theorem cert_e302796598234 : check e302796598234 [[],[]] .three = true := by decide
def e302796598622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e302796598622 : Closed e302796598622 ∧ code e302796598622 = 1402308226398 := by decide
theorem cert_e302796598622 : check e302796598622 [[],[]] .three = true := by decide
def e302796598638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e302796598638 : Closed e302796598638 ∧ code e302796598638 = 1402308226414 := by decide
theorem cert_e302796598638 : check e302796598638 [[],[]] .smaller = true := by decide
def e302796598646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e302796598646 : Closed e302796598646 ∧ code e302796598646 = 1402308226422 := by decide
theorem cert_e302796598646 : check e302796598646 [[],[]] .smaller = true := by decide
def e302796598650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e302796598650 : Closed e302796598650 ∧ code e302796598650 = 1402308226426 := by decide
theorem cert_e302796598650 : check e302796598650 [[],[]] .three = true := by decide
def e302796598702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e302796598702 : Closed e302796598702 ∧ code e302796598702 = 1402308226478 := by decide
theorem cert_e302796598702 : check e302796598702 [[],[]] .smaller = true := by decide
def e302796598714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e302796598714 : Closed e302796598714 ∧ code e302796598714 = 1402308226490 := by decide
theorem cert_e302796598714 : check e302796598714 [[],[]] .smaller = true := by decide
def e302796598742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e302796598742 : Closed e302796598742 ∧ code e302796598742 = 1402308226518 := by decide
theorem cert_e302796598742 : check e302796598742 [[],[]] .smaller = true := by decide
def e302796598746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e302796598746 : Closed e302796598746 ∧ code e302796598746 = 1402308226522 := by decide
theorem cert_e302796598746 : check e302796598746 [[],[]] .smaller = true := by decide
def e302796598762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e302796598762 : Closed e302796598762 ∧ code e302796598762 = 1402308226538 := by decide
theorem cert_e302796598762 : check e302796598762 [[],[]] .three = true := by decide
def e302796598966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e302796598966 : Closed e302796598966 ∧ code e302796598966 = 1402308226742 := by decide
theorem cert_e302796598966 : check e302796598966 [[],[]] .smaller = true := by decide
def e302796598998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e302796598998 : Closed e302796598998 ∧ code e302796598998 = 1402308226774 := by decide
theorem cert_e302796598998 : check e302796598998 [[],[]] .smaller = true := by decide
def e302796599002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e302796599002 : Closed e302796599002 ∧ code e302796599002 = 1402308226778 := by decide
theorem cert_e302796599002 : check e302796599002 [[],[]] .smaller = true := by decide
def e302796599126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e302796599126 : Closed e302796599126 ∧ code e302796599126 = 1402308226902 := by decide
theorem cert_e302796599126 : check e302796599126 [[],[]] .three = true := by decide
def e302796599130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e302796599130 : Closed e302796599130 ∧ code e302796599130 = 1402308226906 := by decide
theorem cert_e302796599130 : check e302796599130 [[],[]] .three = true := by decide
def e302796599146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e302796599146 : Closed e302796599146 ∧ code e302796599146 = 1402308226922 := by decide
theorem cert_e302796599146 : check e302796599146 [[],[]] .three = true := by decide
def e302796600670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e302796600670 : Closed e302796600670 ∧ code e302796600670 = 1402308228446 := by decide
theorem cert_e302796600670 : check e302796600670 [[],[]] .three = true := by decide
def e302796600686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e302796600686 : Closed e302796600686 ∧ code e302796600686 = 1402308228462 := by decide
theorem cert_e302796600686 : check e302796600686 [[],[]] .smaller = true := by decide
def e302796600694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e302796600694 : Closed e302796600694 ∧ code e302796600694 = 1402308228470 := by decide
theorem cert_e302796600694 : check e302796600694 [[],[]] .smaller = true := by decide
def e302796600698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e302796600698 : Closed e302796600698 ∧ code e302796600698 = 1402308228474 := by decide
theorem cert_e302796600698 : check e302796600698 [[],[]] .three = true := by decide
def e302796600750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e302796600750 : Closed e302796600750 ∧ code e302796600750 = 1402308228526 := by decide
theorem cert_e302796600750 : check e302796600750 [[],[]] .smaller = true := by decide
def e302796600762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e302796600762 : Closed e302796600762 ∧ code e302796600762 = 1402308228538 := by decide
theorem cert_e302796600762 : check e302796600762 [[],[]] .smaller = true := by decide
def e302796600790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e302796600790 : Closed e302796600790 ∧ code e302796600790 = 1402308228566 := by decide
theorem cert_e302796600790 : check e302796600790 [[],[]] .smaller = true := by decide
def e302796600794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e302796600794 : Closed e302796600794 ∧ code e302796600794 = 1402308228570 := by decide
theorem cert_e302796600794 : check e302796600794 [[],[]] .smaller = true := by decide
def e302796600810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e302796600810 : Closed e302796600810 ∧ code e302796600810 = 1402308228586 := by decide
theorem cert_e302796600810 : check e302796600810 [[],[]] .three = true := by decide
def e302796601006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e302796601006 : Closed e302796601006 ∧ code e302796601006 = 1402308228782 := by decide
theorem cert_e302796601006 : check e302796601006 [[],[]] .smaller = true := by decide
def e302796601018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e302796601018 : Closed e302796601018 ∧ code e302796601018 = 1402308228794 := by decide
theorem cert_e302796601018 : check e302796601018 [[],[]] .smaller = true := by decide
def e302796601066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e302796601066 : Closed e302796601066 ∧ code e302796601066 = 1402308228842 := by decide
theorem cert_e302796601066 : check e302796601066 [[],[]] .smaller = true := by decide
def e302796601174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e302796601174 : Closed e302796601174 ∧ code e302796601174 = 1402308228950 := by decide
theorem cert_e302796601174 : check e302796601174 [[],[]] .smaller = true := by decide
def e302796601178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e302796601178 : Closed e302796601178 ∧ code e302796601178 = 1402308228954 := by decide
theorem cert_e302796601178 : check e302796601178 [[],[]] .smaller = true := by decide
def e302796601194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e302796601194 : Closed e302796601194 ∧ code e302796601194 = 1402308228970 := by decide
theorem cert_e302796601194 : check e302796601194 [[],[]] .smaller = true := by decide
def e302796601258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e302796601258 : Closed e302796601258 ∧ code e302796601258 = 1402308229034 := by decide
theorem cert_e302796601258 : check e302796601258 [[],[]] .three = true := by decide
def e302796602038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e302796602038 : Closed e302796602038 ∧ code e302796602038 = 1402308229814 := by decide
theorem cert_e302796602038 : check e302796602038 [[],[]] .smaller = true := by decide
def e302796602070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e302796602070 : Closed e302796602070 ∧ code e302796602070 = 1402308229846 := by decide
theorem cert_e302796602070 : check e302796602070 [[],[]] .smaller = true := by decide
def e302796602074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e302796602074 : Closed e302796602074 ∧ code e302796602074 = 1402308229850 := by decide
theorem cert_e302796602074 : check e302796602074 [[],[]] .smaller = true := by decide
def e302796602198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e302796602198 : Closed e302796602198 ∧ code e302796602198 = 1402308229974 := by decide
theorem cert_e302796602198 : check e302796602198 [[],[]] .smaller = true := by decide
def e302796602202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e302796602202 : Closed e302796602202 ∧ code e302796602202 = 1402308229978 := by decide
theorem cert_e302796602202 : check e302796602202 [[],[]] .smaller = true := by decide
def e302796602218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e302796602218 : Closed e302796602218 ∧ code e302796602218 = 1402308229994 := by decide
theorem cert_e302796602218 : check e302796602218 [[],[]] .smaller = true := by decide
def e302796602710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e302796602710 : Closed e302796602710 ∧ code e302796602710 = 1402308230486 := by decide
theorem cert_e302796602710 : check e302796602710 [[],[]] .three = true := by decide
def e302796602714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e302796602714 : Closed e302796602714 ∧ code e302796602714 = 1402308230490 := by decide
theorem cert_e302796602714 : check e302796602714 [[],[]] .three = true := by decide
def e302796602730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e302796602730 : Closed e302796602730 ∧ code e302796602730 = 1402308230506 := by decide
theorem cert_e302796602730 : check e302796602730 [[],[]] .three = true := by decide
def e302796602794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e302796602794 : Closed e302796602794 ∧ code e302796602794 = 1402308230570 := by decide
theorem cert_e302796602794 : check e302796602794 [[],[]] .three = true := by decide
def e302796606942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 3)))))))
theorem wire_e302796606942 : Closed e302796606942 ∧ code e302796606942 = 1402308234718 := by decide
theorem cert_e302796606942 : check e302796606942 [[],[]] .three = true := by decide
def e302796606958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.var 2)))))))
theorem wire_e302796606958 : Closed e302796606958 ∧ code e302796606958 = 1402308234734 := by decide
theorem cert_e302796606958 : check e302796606958 [[],[]] .three = true := by decide
def e302796607198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 3)))))))
theorem wire_e302796607198 : Closed e302796607198 ∧ code e302796607198 = 1402308234974 := by decide
theorem cert_e302796607198 : check e302796607198 [[],[]] .three = true := by decide
def e302796607214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2)))))))
theorem wire_e302796607214 : Closed e302796607214 ∧ code e302796607214 = 1402308234990 := by decide
theorem cert_e302796607214 : check e302796607214 [[],[]] .smaller = true := by decide
def e302796607222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.var 1)))))))
theorem wire_e302796607222 : Closed e302796607222 ∧ code e302796607222 = 1402308234998 := by decide
theorem cert_e302796607222 : check e302796607222 [[],[]] .three = true := by decide
def e302796607326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 3)))))))
theorem wire_e302796607326 : Closed e302796607326 ∧ code e302796607326 = 1402308235102 := by decide
theorem cert_e302796607326 : check e302796607326 [[],[]] .three = true := by decide
def e302796607342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2)))))))
theorem wire_e302796607342 : Closed e302796607342 ∧ code e302796607342 = 1402308235118 := by decide
theorem cert_e302796607342 : check e302796607342 [[],[]] .smaller = true := by decide
def e302796607350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1)))))))
theorem wire_e302796607350 : Closed e302796607350 ∧ code e302796607350 = 1402308235126 := by decide
theorem cert_e302796607350 : check e302796607350 [[],[]] .smaller = true := by decide
end Blc.Floor40
