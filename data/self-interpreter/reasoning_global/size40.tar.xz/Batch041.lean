import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302800838006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e302800838006 : Closed e302800838006 ∧ code e302800838006 = 1402312465782 := by decide
theorem cert_e302800838006 : check e302800838006 [[],[]] .chain = true := by decide
def e302800838318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e302800838318 : Closed e302800838318 ∧ code e302800838318 = 1402312466094 := by decide
theorem cert_e302800838318 : check e302800838318 [[],[]] .chain = true := by decide
def e302800838330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e302800838330 : Closed e302800838330 ∧ code e302800838330 = 1402312466106 := by decide
theorem cert_e302800838330 : check e302800838330 [[],[]] .chain = true := by decide
def e302800838486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e302800838486 : Closed e302800838486 ∧ code e302800838486 = 1402312466262 := by decide
theorem cert_e302800838486 : check e302800838486 [[],[]] .chain = true := by decide
def e302800838490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e302800838490 : Closed e302800838490 ∧ code e302800838490 = 1402312466266 := by decide
theorem cert_e302800838490 : check e302800838490 [[],[]] .chain = true := by decide
def e302800840558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e302800840558 : Closed e302800840558 ∧ code e302800840558 = 1402312468334 := by decide
theorem cert_e302800840558 : check e302800840558 [[],[]] .chain = true := by decide
def e302800840566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e302800840566 : Closed e302800840566 ∧ code e302800840566 = 1402312468342 := by decide
theorem cert_e302800840566 : check e302800840566 [[],[]] .chain = true := by decide
def e302800840630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e302800840630 : Closed e302800840630 ∧ code e302800840630 = 1402312468406 := by decide
theorem cert_e302800840630 : check e302800840630 [[],[]] .chain = true := by decide
def e302800841966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e302800841966 : Closed e302800841966 ∧ code e302800841966 = 1402312469742 := by decide
theorem cert_e302800841966 : check e302800841966 [[],[]] .chain = true := by decide
def e302800841974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e302800841974 : Closed e302800841974 ∧ code e302800841974 = 1402312469750 := by decide
theorem cert_e302800841974 : check e302800841974 [[],[]] .chain = true := by decide
def e302800842358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e302800842358 : Closed e302800842358 ∧ code e302800842358 = 1402312470134 := by decide
theorem cert_e302800842358 : check e302800842358 [[],[]] .chain = true := by decide
def e302800843630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e302800843630 : Closed e302800843630 ∧ code e302800843630 = 1402312471406 := by decide
theorem cert_e302800843630 : check e302800843630 [[],[]] .chain = true := by decide
def e302800843638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e302800843638 : Closed e302800843638 ∧ code e302800843638 = 1402312471414 := by decide
theorem cert_e302800843638 : check e302800843638 [[],[]] .chain = true := by decide
def e302800843694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e302800843694 : Closed e302800843694 ∧ code e302800843694 = 1402312471470 := by decide
theorem cert_e302800843694 : check e302800843694 [[],[]] .chain = true := by decide
def e302800843706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e302800843706 : Closed e302800843706 ∧ code e302800843706 = 1402312471482 := by decide
theorem cert_e302800843706 : check e302800843706 [[],[]] .chain = true := by decide
def e302800843734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e302800843734 : Closed e302800843734 ∧ code e302800843734 = 1402312471510 := by decide
theorem cert_e302800843734 : check e302800843734 [[],[]] .chain = true := by decide
def e302800843738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e302800843738 : Closed e302800843738 ∧ code e302800843738 = 1402312471514 := by decide
theorem cert_e302800843738 : check e302800843738 [[],[]] .chain = true := by decide
def e302800844014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e302800844014 : Closed e302800844014 ∧ code e302800844014 = 1402312471790 := by decide
theorem cert_e302800844014 : check e302800844014 [[],[]] .chain = true := by decide
def e302800844022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e302800844022 : Closed e302800844022 ∧ code e302800844022 = 1402312471798 := by decide
theorem cert_e302800844022 : check e302800844022 [[],[]] .chain = true := by decide
def e302800844398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e302800844398 : Closed e302800844398 ∧ code e302800844398 = 1402312472174 := by decide
theorem cert_e302800844398 : check e302800844398 [[],[]] .chain = true := by decide
def e302800844410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e302800844410 : Closed e302800844410 ∧ code e302800844410 = 1402312472186 := by decide
theorem cert_e302800844410 : check e302800844410 [[],[]] .chain = true := by decide
def e302800844598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e302800844598 : Closed e302800844598 ∧ code e302800844598 = 1402312472374 := by decide
theorem cert_e302800844598 : check e302800844598 [[],[]] .chain = true := by decide
def e302800844602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e302800844602 : Closed e302800844602 ∧ code e302800844602 = 1402312472378 := by decide
theorem cert_e302800844602 : check e302800844602 [[],[]] .chain = true := by decide
def e302800845038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 2))) (.var 2))))))
theorem wire_e302800845038 : Closed e302800845038 ∧ code e302800845038 = 1402312472814 := by decide
theorem cert_e302800845038 : check e302800845038 [[],[]] .chain = true := by decide
def e302800845046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.var 1))))))
theorem wire_e302800845046 : Closed e302800845046 ∧ code e302800845046 = 1402312472822 := by decide
theorem cert_e302800845046 : check e302800845046 [[],[]] .chain = true := by decide
def e302800845230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e302800845230 : Closed e302800845230 ∧ code e302800845230 = 1402312473006 := by decide
theorem cert_e302800845230 : check e302800845230 [[],[]] .chain = true := by decide
def e302800845242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e302800845242 : Closed e302800845242 ∧ code e302800845242 = 1402312473018 := by decide
theorem cert_e302800845242 : check e302800845242 [[],[]] .chain = true := by decide
def e302800845290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e302800845290 : Closed e302800845290 ∧ code e302800845290 = 1402312473066 := by decide
theorem cert_e302800845290 : check e302800845290 [[],[]] .chain = true := by decide
def e302800845422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e302800845422 : Closed e302800845422 ∧ code e302800845422 = 1402312473198 := by decide
theorem cert_e302800845422 : check e302800845422 [[],[]] .chain = true := by decide
def e302800845434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e302800845434 : Closed e302800845434 ∧ code e302800845434 = 1402312473210 := by decide
theorem cert_e302800845434 : check e302800845434 [[],[]] .chain = true := by decide
def e302800845598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e302800845598 : Closed e302800845598 ∧ code e302800845598 = 1402312473374 := by decide
theorem cert_e302800845598 : check e302800845598 [[],[]] .chain = true := by decide
def e302800845710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e302800845710 : Closed e302800845710 ∧ code e302800845710 = 1402312473486 := by decide
theorem cert_e302800845710 : check e302800845710 [[],[]] .chain = true := by decide
def e302800845722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e302800845722 : Closed e302800845722 ∧ code e302800845722 = 1402312473498 := by decide
theorem cert_e302800845722 : check e302800845722 [[],[]] .chain = true := by decide
def e302800845942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.var 1))))))
theorem wire_e302800845942 : Closed e302800845942 ∧ code e302800845942 = 1402312473718 := by decide
theorem cert_e302800845942 : check e302800845942 [[],[]] .chain = true := by decide
def e302800846038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e302800846038 : Closed e302800846038 ∧ code e302800846038 = 1402312473814 := by decide
theorem cert_e302800846038 : check e302800846038 [[],[]] .chain = true := by decide
def e302800846042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e302800846042 : Closed e302800846042 ∧ code e302800846042 = 1402312473818 := by decide
theorem cert_e302800846042 : check e302800846042 [[],[]] .chain = true := by decide
def e302800846058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e302800846058 : Closed e302800846058 ∧ code e302800846058 = 1402312473834 := by decide
theorem cert_e302800846058 : check e302800846058 [[],[]] .chain = true := by decide
def e302800846134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e302800846134 : Closed e302800846134 ∧ code e302800846134 = 1402312473910 := by decide
theorem cert_e302800846134 : check e302800846134 [[],[]] .chain = true := by decide
def e302800846138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e302800846138 : Closed e302800846138 ∧ code e302800846138 = 1402312473914 := by decide
theorem cert_e302800846138 : check e302800846138 [[],[]] .chain = true := by decide
def e302800846222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e302800846222 : Closed e302800846222 ∧ code e302800846222 = 1402312473998 := by decide
theorem cert_e302800846222 : check e302800846222 [[],[]] .chain = true := by decide
def e302800846234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e302800846234 : Closed e302800846234 ∧ code e302800846234 = 1402312474010 := by decide
theorem cert_e302800846234 : check e302800846234 [[],[]] .chain = true := by decide
def e302800855918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e302800855918 : Closed e302800855918 ∧ code e302800855918 = 1402312483694 := by decide
theorem cert_e302800855918 : check e302800855918 [[],[]] .chain = true := by decide
def e302800855926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e302800855926 : Closed e302800855926 ∧ code e302800855926 = 1402312483702 := by decide
theorem cert_e302800855926 : check e302800855926 [[],[]] .chain = true := by decide
def e302800855982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e302800855982 : Closed e302800855982 ∧ code e302800855982 = 1402312483758 := by decide
theorem cert_e302800855982 : check e302800855982 [[],[]] .chain = true := by decide
def e302800855994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e302800855994 : Closed e302800855994 ∧ code e302800855994 = 1402312483770 := by decide
theorem cert_e302800855994 : check e302800855994 [[],[]] .chain = true := by decide
def e302800856022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e302800856022 : Closed e302800856022 ∧ code e302800856022 = 1402312483798 := by decide
theorem cert_e302800856022 : check e302800856022 [[],[]] .chain = true := by decide
def e302800856026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e302800856026 : Closed e302800856026 ∧ code e302800856026 = 1402312483802 := by decide
theorem cert_e302800856026 : check e302800856026 [[],[]] .chain = true := by decide
def e302800857326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.var 2))))))
theorem wire_e302800857326 : Closed e302800857326 ∧ code e302800857326 = 1402312485102 := by decide
theorem cert_e302800857326 : check e302800857326 [[],[]] .chain = true := by decide
def e302800857334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 3))) (.var 1))))))
theorem wire_e302800857334 : Closed e302800857334 ∧ code e302800857334 = 1402312485110 := by decide
theorem cert_e302800857334 : check e302800857334 [[],[]] .chain = true := by decide
def e302800857886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e302800857886 : Closed e302800857886 ∧ code e302800857886 = 1402312485662 := by decide
theorem cert_e302800857886 : check e302800857886 [[],[]] .chain = true := by decide
def e302800857998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e302800857998 : Closed e302800857998 ∧ code e302800857998 = 1402312485774 := by decide
theorem cert_e302800857998 : check e302800857998 [[],[]] .chain = true := by decide
def e302800858222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e302800858222 : Closed e302800858222 ∧ code e302800858222 = 1402312485998 := by decide
theorem cert_e302800858222 : check e302800858222 [[],[]] .chain = true := by decide
def e302800858234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e302800858234 : Closed e302800858234 ∧ code e302800858234 = 1402312486010 := by decide
theorem cert_e302800858234 : check e302800858234 [[],[]] .chain = true := by decide
def e302800858398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e302800858398 : Closed e302800858398 ∧ code e302800858398 = 1402312486174 := by decide
theorem cert_e302800858398 : check e302800858398 [[],[]] .chain = true := by decide
def e302800858566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e302800858566 : Closed e302800858566 ∧ code e302800858566 = 1402312486342 := by decide
theorem cert_e302800858566 : check e302800858566 [[],[]] .chain = true := by decide
def e302800858678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 1))) (.var 1))))))
theorem wire_e302800858678 : Closed e302800858678 ∧ code e302800858678 = 1402312486454 := by decide
theorem cert_e302800858678 : check e302800858678 [[],[]] .chain = true := by decide
def e302800858682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.var 0))))))
theorem wire_e302800858682 : Closed e302800858682 ∧ code e302800858682 = 1402312486458 := by decide
theorem cert_e302800858682 : check e302800858682 [[],[]] .chain = true := by decide
def e302800858766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e302800858766 : Closed e302800858766 ∧ code e302800858766 = 1402312486542 := by decide
theorem cert_e302800858766 : check e302800858766 [[],[]] .chain = true := by decide
def e302800858822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e302800858822 : Closed e302800858822 ∧ code e302800858822 = 1402312486598 := by decide
theorem cert_e302800858822 : check e302800858822 [[],[]] .chain = true := by decide
def e302800859502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e302800859502 : Closed e302800859502 ∧ code e302800859502 = 1402312487278 := by decide
theorem cert_e302800859502 : check e302800859502 [[],[]] .chain = true := by decide
def e302800859510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e302800859510 : Closed e302800859510 ∧ code e302800859510 = 1402312487286 := by decide
theorem cert_e302800859510 : check e302800859510 [[],[]] .chain = true := by decide
def e302800859566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e302800859566 : Closed e302800859566 ∧ code e302800859566 = 1402312487342 := by decide
theorem cert_e302800859566 : check e302800859566 [[],[]] .chain = true := by decide
def e302800859578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e302800859578 : Closed e302800859578 ∧ code e302800859578 = 1402312487354 := by decide
theorem cert_e302800859578 : check e302800859578 [[],[]] .chain = true := by decide
def e302800859626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e302800859626 : Closed e302800859626 ∧ code e302800859626 = 1402312487402 := by decide
theorem cert_e302800859626 : check e302800859626 [[],[]] .chain = true := by decide
def e302800860270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.var 2))))))
theorem wire_e302800860270 : Closed e302800860270 ∧ code e302800860270 = 1402312488046 := by decide
theorem cert_e302800860270 : check e302800860270 [[],[]] .chain = true := by decide
def e302800860282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.var 0))))))
theorem wire_e302800860282 : Closed e302800860282 ∧ code e302800860282 = 1402312488058 := by decide
theorem cert_e302800860282 : check e302800860282 [[],[]] .chain = true := by decide
def e302800860446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e302800860446 : Closed e302800860446 ∧ code e302800860446 = 1402312488222 := by decide
theorem cert_e302800860446 : check e302800860446 [[],[]] .chain = true := by decide
def e302800860614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e302800860614 : Closed e302800860614 ∧ code e302800860614 = 1402312488390 := by decide
theorem cert_e302800860614 : check e302800860614 [[],[]] .chain = true := by decide
def e302800860718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e302800860718 : Closed e302800860718 ∧ code e302800860718 = 1402312488494 := by decide
theorem cert_e302800860718 : check e302800860718 [[],[]] .chain = true := by decide
def e302800860898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e302800860898 : Closed e302800860898 ∧ code e302800860898 = 1402312488674 := by decide
theorem cert_e302800860898 : check e302800860898 [[],[]] .chain = true := by decide
def e302800860910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e302800860910 : Closed e302800860910 ∧ code e302800860910 = 1402312488686 := by decide
theorem cert_e302800860910 : check e302800860910 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302800860950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 1))))))
theorem wire_e302800860950 : Closed e302800860950 ∧ code e302800860950 = 1402312488726 := by decide
theorem cert_e302800860950 : check e302800860950 [[],[]] .chain = true := by decide
def e302800860954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.var 0))))))
theorem wire_e302800860954 : Closed e302800860954 ∧ code e302800860954 = 1402312488730 := by decide
theorem cert_e302800860954 : check e302800860954 [[],[]] .chain = true := by decide
def e302800860998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302800860998 : Closed e302800860998 ∧ code e302800860998 = 1402312488774 := by decide
theorem cert_e302800860998 : check e302800860998 [[],[]] .chain = true := by decide
def e302800861026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e302800861026 : Closed e302800861026 ∧ code e302800861026 = 1402312488802 := by decide
theorem cert_e302800861026 : check e302800861026 [[],[]] .chain = true := by decide
def e302800861038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e302800861038 : Closed e302800861038 ∧ code e302800861038 = 1402312488814 := by decide
theorem cert_e302800861038 : check e302800861038 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302800861046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e302800861046 : Closed e302800861046 ∧ code e302800861046 = 1402312488822 := by decide
theorem cert_e302800861046 : check e302800861046 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302800861366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e302800861366 : Closed e302800861366 ∧ code e302800861366 = 1402312489142 := by decide
theorem cert_e302800861366 : check e302800861366 [[],[]] .chain = true := by decide
def e302800861398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e302800861398 : Closed e302800861398 ∧ code e302800861398 = 1402312489174 := by decide
theorem cert_e302800861398 : check e302800861398 [[],[]] .chain = true := by decide
def e302800861402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e302800861402 : Closed e302800861402 ∧ code e302800861402 = 1402312489178 := by decide
theorem cert_e302800861402 : check e302800861402 [[],[]] .chain = true := by decide
def e302800861418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e302800861418 : Closed e302800861418 ∧ code e302800861418 = 1402312489194 := by decide
theorem cert_e302800861418 : check e302800861418 [[],[]] .chain = true := by decide
def e302800861750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 1))) (.var 1))))))
theorem wire_e302800861750 : Closed e302800861750 ∧ code e302800861750 = 1402312489526 := by decide
theorem cert_e302800861750 : check e302800861750 [[],[]] .chain = true := by decide
def e302800861754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.var 0))))))
theorem wire_e302800861754 : Closed e302800861754 ∧ code e302800861754 = 1402312489530 := by decide
theorem cert_e302800861754 : check e302800861754 [[],[]] .chain = true := by decide
def e302800861838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e302800861838 : Closed e302800861838 ∧ code e302800861838 = 1402312489614 := by decide
theorem cert_e302800861838 : check e302800861838 [[],[]] .chain = true := by decide
def e302800861894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e302800861894 : Closed e302800861894 ∧ code e302800861894 = 1402312489670 := by decide
theorem cert_e302800861894 : check e302800861894 [[],[]] .chain = true := by decide
def e302800861974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 1))))))
theorem wire_e302800861974 : Closed e302800861974 ∧ code e302800861974 = 1402312489750 := by decide
theorem cert_e302800861974 : check e302800861974 [[],[]] .chain = true := by decide
def e302800861978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.var 0))))))
theorem wire_e302800861978 : Closed e302800861978 ∧ code e302800861978 = 1402312489754 := by decide
theorem cert_e302800861978 : check e302800861978 [[],[]] .chain = true := by decide
def e302800862022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e302800862022 : Closed e302800862022 ∧ code e302800862022 = 1402312489798 := by decide
theorem cert_e302800862022 : check e302800862022 [[],[]] .chain = true := by decide
def e302800862050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e302800862050 : Closed e302800862050 ∧ code e302800862050 = 1402312489826 := by decide
theorem cert_e302800862050 : check e302800862050 [[],[]] .chain = true := by decide
def e302800862062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e302800862062 : Closed e302800862062 ∧ code e302800862062 = 1402312489838 := by decide
theorem cert_e302800862062 : check e302800862062 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e302800862070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e302800862070 : Closed e302800862070 ∧ code e302800862070 = 1402312489846 := by decide
theorem cert_e302800862070 : check e302800862070 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e302800862134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e302800862134 : Closed e302800862134 ∧ code e302800862134 = 1402312489910 := by decide
theorem cert_e302800862134 : check e302800862134 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e302800865006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e302800865006 : Closed e302800865006 ∧ code e302800865006 = 1402312492782 := by decide
theorem cert_e302800865006 : check e302800865006 [[],[]] .chain = true := by decide
def e302800865014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 3)))) (.var 1))))))
theorem wire_e302800865014 : Closed e302800865014 ∧ code e302800865014 = 1402312492790 := by decide
theorem cert_e302800865014 : check e302800865014 [[],[]] .chain = true := by decide
def e302800865198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e302800865198 : Closed e302800865198 ∧ code e302800865198 = 1402312492974 := by decide
theorem cert_e302800865198 : check e302800865198 [[],[]] .chain = true := by decide
def e302800865238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 0)))) (.var 1))))))
theorem wire_e302800865238 : Closed e302800865238 ∧ code e302800865238 = 1402312493014 := by decide
theorem cert_e302800865238 : check e302800865238 [[],[]] .chain = true := by decide
def e302800866542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e302800866542 : Closed e302800866542 ∧ code e302800866542 = 1402312494318 := by decide
theorem cert_e302800866542 : check e302800866542 [[],[]] .chain = true := by decide
def e302800866550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e302800866550 : Closed e302800866550 ∧ code e302800866550 = 1402312494326 := by decide
theorem cert_e302800866550 : check e302800866550 [[],[]] .chain = true := by decide
def e302800866926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e302800866926 : Closed e302800866926 ∧ code e302800866926 = 1402312494702 := by decide
theorem cert_e302800866926 : check e302800866926 [[],[]] .chain = true := by decide
def e302800866938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e302800866938 : Closed e302800866938 ∧ code e302800866938 = 1402312494714 := by decide
theorem cert_e302800866938 : check e302800866938 [[],[]] .chain = true := by decide
def e302800867126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e302800867126 : Closed e302800867126 ∧ code e302800867126 = 1402312494902 := by decide
theorem cert_e302800867126 : check e302800867126 [[],[]] .chain = true := by decide
def e302800867130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e302800867130 : Closed e302800867130 ∧ code e302800867130 = 1402312494906 := by decide
theorem cert_e302800867130 : check e302800867130 [[],[]] .chain = true := by decide
def e302800869614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e302800869614 : Closed e302800869614 ∧ code e302800869614 = 1402312497390 := by decide
theorem cert_e302800869614 : check e302800869614 [[],[]] .chain = true := by decide
def e302800869622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e302800869622 : Closed e302800869622 ∧ code e302800869622 = 1402312497398 := by decide
theorem cert_e302800869622 : check e302800869622 [[],[]] .chain = true := by decide
def e302800870174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e302800870174 : Closed e302800870174 ∧ code e302800870174 = 1402312497950 := by decide
theorem cert_e302800870174 : check e302800870174 [[],[]] .chain = true := by decide
def e302800870286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e302800870286 : Closed e302800870286 ∧ code e302800870286 = 1402312498062 := by decide
theorem cert_e302800870286 : check e302800870286 [[],[]] .chain = true := by decide
def e302800870510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e302800870510 : Closed e302800870510 ∧ code e302800870510 = 1402312498286 := by decide
theorem cert_e302800870510 : check e302800870510 [[],[]] .chain = true := by decide
def e302800870522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e302800870522 : Closed e302800870522 ∧ code e302800870522 = 1402312498298 := by decide
theorem cert_e302800870522 : check e302800870522 [[],[]] .chain = true := by decide
def e302800870686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e302800870686 : Closed e302800870686 ∧ code e302800870686 = 1402312498462 := by decide
theorem cert_e302800870686 : check e302800870686 [[],[]] .chain = true := by decide
def e302800870854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e302800870854 : Closed e302800870854 ∧ code e302800870854 = 1402312498630 := by decide
theorem cert_e302800870854 : check e302800870854 [[],[]] .chain = true := by decide
def e302800870966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e302800870966 : Closed e302800870966 ∧ code e302800870966 = 1402312498742 := by decide
theorem cert_e302800870966 : check e302800870966 [[],[]] .chain = true := by decide
def e302800870970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e302800870970 : Closed e302800870970 ∧ code e302800870970 = 1402312498746 := by decide
theorem cert_e302800870970 : check e302800870970 [[],[]] .chain = true := by decide
def e302800871054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e302800871054 : Closed e302800871054 ∧ code e302800871054 = 1402312498830 := by decide
theorem cert_e302800871054 : check e302800871054 [[],[]] .chain = true := by decide
def e302800871110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e302800871110 : Closed e302800871110 ∧ code e302800871110 = 1402312498886 := by decide
theorem cert_e302800871110 : check e302800871110 [[],[]] .chain = true := by decide
def e302800873246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e302800873246 : Closed e302800873246 ∧ code e302800873246 = 1402312501022 := by decide
theorem cert_e302800873246 : check e302800873246 [[],[]] .chain = true := by decide
def e302800873358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e302800873358 : Closed e302800873358 ∧ code e302800873358 = 1402312501134 := by decide
theorem cert_e302800873358 : check e302800873358 [[],[]] .chain = true := by decide
def e302800875742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e302800875742 : Closed e302800875742 ∧ code e302800875742 = 1402312503518 := by decide
theorem cert_e302800875742 : check e302800875742 [[],[]] .chain = true := by decide
def e302800875770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e302800875770 : Closed e302800875770 ∧ code e302800875770 = 1402312503546 := by decide
theorem cert_e302800875770 : check e302800875770 [[],[]] .chain = true := by decide
def e302800876318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e302800876318 : Closed e302800876318 ∧ code e302800876318 = 1402312504094 := by decide
theorem cert_e302800876318 : check e302800876318 [[],[]] .chain = true := by decide
def e302800876486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e302800876486 : Closed e302800876486 ∧ code e302800876486 = 1402312504262 := by decide
theorem cert_e302800876486 : check e302800876486 [[],[]] .chain = true := by decide
def e302800877678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e302800877678 : Closed e302800877678 ∧ code e302800877678 = 1402312505454 := by decide
theorem cert_e302800877678 : check e302800877678 [[],[]] .chain = true := by decide
def e302800877690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e302800877690 : Closed e302800877690 ∧ code e302800877690 = 1402312505466 := by decide
theorem cert_e302800877690 : check e302800877690 [[],[]] .chain = true := by decide
def e302800877966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e302800877966 : Closed e302800877966 ∧ code e302800877966 = 1402312505742 := by decide
theorem cert_e302800877966 : check e302800877966 [[],[]] .chain = true := by decide
def e302800878022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e302800878022 : Closed e302800878022 ∧ code e302800878022 = 1402312505798 := by decide
theorem cert_e302800878022 : check e302800878022 [[],[]] .chain = true := by decide
def e302800880110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e302800880110 : Closed e302800880110 ∧ code e302800880110 = 1402312507886 := by decide
theorem cert_e302800880110 : check e302800880110 [[],[]] .chain = true := by decide
def e302800880118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e302800880118 : Closed e302800880118 ∧ code e302800880118 = 1402312507894 := by decide
theorem cert_e302800880118 : check e302800880118 [[],[]] .chain = true := by decide
def e302800880494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e302800880494 : Closed e302800880494 ∧ code e302800880494 = 1402312508270 := by decide
theorem cert_e302800880494 : check e302800880494 [[],[]] .chain = true := by decide
def e302800880506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))
theorem wire_e302800880506 : Closed e302800880506 ∧ code e302800880506 = 1402312508282 := by decide
theorem cert_e302800880506 : check e302800880506 [[],[]] .chain = true := by decide
def e302800880558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e302800880558 : Closed e302800880558 ∧ code e302800880558 = 1402312508334 := by decide
theorem cert_e302800880558 : check e302800880558 [[],[]] .chain = true := by decide
def e302800880618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))
theorem wire_e302800880618 : Closed e302800880618 ∧ code e302800880618 = 1402312508394 := by decide
theorem cert_e302800880618 : check e302800880618 [[],[]] .chain = true := by decide
def e302800880878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e302800880878 : Closed e302800880878 ∧ code e302800880878 = 1402312508654 := by decide
theorem cert_e302800880878 : check e302800880878 [[],[]] .chain = true := by decide
def e302800880886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e302800880886 : Closed e302800880886 ∧ code e302800880886 = 1402312508662 := by decide
theorem cert_e302800880886 : check e302800880886 [[],[]] .chain = true := by decide
def e302800881262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e302800881262 : Closed e302800881262 ∧ code e302800881262 = 1402312509038 := by decide
theorem cert_e302800881262 : check e302800881262 [[],[]] .chain = true := by decide
def e302800881274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e302800881274 : Closed e302800881274 ∧ code e302800881274 = 1402312509050 := by decide
theorem cert_e302800881274 : check e302800881274 [[],[]] .chain = true := by decide
def e302800881438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e302800881438 : Closed e302800881438 ∧ code e302800881438 = 1402312509214 := by decide
theorem cert_e302800881438 : check e302800881438 [[],[]] .chain = true := by decide
def e302800881550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e302800881550 : Closed e302800881550 ∧ code e302800881550 = 1402312509326 := by decide
theorem cert_e302800881550 : check e302800881550 [[],[]] .chain = true := by decide
def e302800881562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e302800881562 : Closed e302800881562 ∧ code e302800881562 = 1402312509338 := by decide
theorem cert_e302800881562 : check e302800881562 [[],[]] .chain = true := by decide
def e302800882798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e302800882798 : Closed e302800882798 ∧ code e302800882798 = 1402312510574 := by decide
theorem cert_e302800882798 : check e302800882798 [[],[]] .chain = true := by decide
def e302800882810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e302800882810 : Closed e302800882810 ∧ code e302800882810 = 1402312510586 := by decide
theorem cert_e302800882810 : check e302800882810 [[],[]] .chain = true := by decide
def e302800882974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e302800882974 : Closed e302800882974 ∧ code e302800882974 = 1402312510750 := by decide
theorem cert_e302800882974 : check e302800882974 [[],[]] .chain = true := by decide
def e302800883142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e302800883142 : Closed e302800883142 ∧ code e302800883142 = 1402312510918 := by decide
theorem cert_e302800883142 : check e302800883142 [[],[]] .chain = true := by decide
def e302800883246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e302800883246 : Closed e302800883246 ∧ code e302800883246 = 1402312511022 := by decide
theorem cert_e302800883246 : check e302800883246 [[],[]] .chain = true := by decide
def e302800883426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e302800883426 : Closed e302800883426 ∧ code e302800883426 = 1402312511202 := by decide
theorem cert_e302800883426 : check e302800883426 [[],[]] .chain = true := by decide
def e302800883438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e302800883438 : Closed e302800883438 ∧ code e302800883438 = 1402312511214 := by decide
theorem cert_e302800883438 : check e302800883438 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302800883478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e302800883478 : Closed e302800883478 ∧ code e302800883478 = 1402312511254 := by decide
theorem cert_e302800883478 : check e302800883478 [[],[]] .chain = true := by decide
def e302800883482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302800883482 : Closed e302800883482 ∧ code e302800883482 = 1402312511258 := by decide
theorem cert_e302800883482 : check e302800883482 [[],[]] .chain = true := by decide
def e302800883526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302800883526 : Closed e302800883526 ∧ code e302800883526 = 1402312511302 := by decide
theorem cert_e302800883526 : check e302800883526 [[],[]] .chain = true := by decide
def e302800883554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e302800883554 : Closed e302800883554 ∧ code e302800883554 = 1402312511330 := by decide
theorem cert_e302800883554 : check e302800883554 [[],[]] .chain = true := by decide
def e302800883566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e302800883566 : Closed e302800883566 ∧ code e302800883566 = 1402312511342 := by decide
theorem cert_e302800883566 : check e302800883566 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302800883574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e302800883574 : Closed e302800883574 ∧ code e302800883574 = 1402312511350 := by decide
theorem cert_e302800883574 : check e302800883574 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302800883934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e302800883934 : Closed e302800883934 ∧ code e302800883934 = 1402312511710 := by decide
theorem cert_e302800883934 : check e302800883934 [[],[]] .chain = true := by decide
def e302800883962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e302800883962 : Closed e302800883962 ∧ code e302800883962 = 1402312511738 := by decide
theorem cert_e302800883962 : check e302800883962 [[],[]] .chain = true := by decide
def e302800884510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e302800884510 : Closed e302800884510 ∧ code e302800884510 = 1402312512286 := by decide
theorem cert_e302800884510 : check e302800884510 [[],[]] .chain = true := by decide
def e302800884678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e302800884678 : Closed e302800884678 ∧ code e302800884678 = 1402312512454 := by decide
theorem cert_e302800884678 : check e302800884678 [[],[]] .chain = true := by decide
def e302800885822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e302800885822 : Closed e302800885822 ∧ code e302800885822 = 1402312513598 := by decide
theorem cert_e302800885822 : check e302800885822 [[],[]] .chain = true := by decide
def e302800886242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e302800886242 : Closed e302800886242 ∧ code e302800886242 = 1402312514018 := by decide
theorem cert_e302800886242 : check e302800886242 [[],[]] .chain = true := by decide
def e302800886254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e302800886254 : Closed e302800886254 ∧ code e302800886254 = 1402312514030 := by decide
theorem cert_e302800886254 : check e302800886254 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e302800886814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e302800886814 : Closed e302800886814 ∧ code e302800886814 = 1402312514590 := by decide
theorem cert_e302800886814 : check e302800886814 [[],[]] .chain = true := by decide
def e302800886838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e302800886838 : Closed e302800886838 ∧ code e302800886838 = 1402312514614 := by decide
theorem cert_e302800886838 : check e302800886838 [[],[]] .chain = true := by decide
def e302800886842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e302800886842 : Closed e302800886842 ∧ code e302800886842 = 1402312514618 := by decide
theorem cert_e302800886842 : check e302800886842 [[],[]] .chain = true := by decide
end Blc.Floor40
