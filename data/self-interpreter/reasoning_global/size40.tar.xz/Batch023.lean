import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e301453778574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e301453778574 : Closed e301453778574 ∧ code e301453778574 = 1400965406350 := by decide
theorem cert_e301453778574 : check e301453778574 [[],[]] .chain = true := by decide
def e301453778586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e301453778586 : Closed e301453778586 ∧ code e301453778586 = 1400965406362 := by decide
theorem cert_e301453778586 : check e301453778586 [[],[]] .chain = true := by decide
def e301453778630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e301453778630 : Closed e301453778630 ∧ code e301453778630 = 1400965406406 := by decide
theorem cert_e301453778630 : check e301453778630 [[],[]] .chain = true := by decide
def e301453779422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e301453779422 : Closed e301453779422 ∧ code e301453779422 = 1400965407198 := by decide
theorem cert_e301453779422 : check e301453779422 [[],[]] .chain = true := by decide
def e301453779446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e301453779446 : Closed e301453779446 ∧ code e301453779446 = 1400965407222 := by decide
theorem cert_e301453779446 : check e301453779446 [[],[]] .chain = true := by decide
def e301453780398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e301453780398 : Closed e301453780398 ∧ code e301453780398 = 1400965408174 := by decide
theorem cert_e301453780398 : check e301453780398 [[],[]] .chain = true := by decide
def e301453780410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e301453780410 : Closed e301453780410 ∧ code e301453780410 = 1400965408186 := by decide
theorem cert_e301453780410 : check e301453780410 [[],[]] .chain = true := by decide
def e301453780458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e301453780458 : Closed e301453780458 ∧ code e301453780458 = 1400965408234 := by decide
theorem cert_e301453780458 : check e301453780458 [[],[]] .chain = true := by decide
def e301453780590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e301453780590 : Closed e301453780590 ∧ code e301453780590 = 1400965408366 := by decide
theorem cert_e301453780590 : check e301453780590 [[],[]] .chain = true := by decide
def e301453780602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e301453780602 : Closed e301453780602 ∧ code e301453780602 = 1400965408378 := by decide
theorem cert_e301453780602 : check e301453780602 [[],[]] .chain = true := by decide
def e301453780766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e301453780766 : Closed e301453780766 ∧ code e301453780766 = 1400965408542 := by decide
theorem cert_e301453780766 : check e301453780766 [[],[]] .chain = true := by decide
def e301453780878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e301453780878 : Closed e301453780878 ∧ code e301453780878 = 1400965408654 := by decide
theorem cert_e301453780878 : check e301453780878 [[],[]] .chain = true := by decide
def e301453780890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e301453780890 : Closed e301453780890 ∧ code e301453780890 = 1400965408666 := by decide
theorem cert_e301453780890 : check e301453780890 [[],[]] .chain = true := by decide
def e301453783838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e301453783838 : Closed e301453783838 ∧ code e301453783838 = 1400965411614 := by decide
theorem cert_e301453783838 : check e301453783838 [[],[]] .chain = true := by decide
def e301453784006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e301453784006 : Closed e301453784006 ∧ code e301453784006 = 1400965411782 := by decide
theorem cert_e301453784006 : check e301453784006 [[],[]] .chain = true := by decide
def e301453785206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e301453785206 : Closed e301453785206 ∧ code e301453785206 = 1400965412982 := by decide
theorem cert_e301453785206 : check e301453785206 [[],[]] .chain = true := by decide
def e301453785450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e301453785450 : Closed e301453785450 ∧ code e301453785450 = 1400965413226 := by decide
theorem cert_e301453785450 : check e301453785450 [[],[]] .chain = true := by decide
def e301453785486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e301453785486 : Closed e301453785486 ∧ code e301453785486 = 1400965413262 := by decide
theorem cert_e301453785486 : check e301453785486 [[],[]] .chain = true := by decide
def e301453785498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e301453785498 : Closed e301453785498 ∧ code e301453785498 = 1400965413274 := by decide
theorem cert_e301453785498 : check e301453785498 [[],[]] .chain = true := by decide
def e301453785542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e301453785542 : Closed e301453785542 ∧ code e301453785542 = 1400965413318 := by decide
theorem cert_e301453785542 : check e301453785542 [[],[]] .chain = true := by decide
def e301453788086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e301453788086 : Closed e301453788086 ∧ code e301453788086 = 1400965415862 := by decide
theorem cert_e301453788086 : check e301453788086 [[],[]] .chain = true := by decide
def e301453788090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e301453788090 : Closed e301453788090 ∧ code e301453788090 = 1400965415866 := by decide
theorem cert_e301453788090 : check e301453788090 [[],[]] .chain = true := by decide
def e301453788122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e301453788122 : Closed e301453788122 ∧ code e301453788122 = 1400965415898 := by decide
theorem cert_e301453788122 : check e301453788122 [[],[]] .chain = true := by decide
def e301453788790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e301453788790 : Closed e301453788790 ∧ code e301453788790 = 1400965416566 := by decide
theorem cert_e301453788790 : check e301453788790 [[],[]] .chain = true := by decide
def e301453788982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e301453788982 : Closed e301453788982 ∧ code e301453788982 = 1400965416758 := by decide
theorem cert_e301453788982 : check e301453788982 [[],[]] .chain = true := by decide
def e301453788986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e301453788986 : Closed e301453788986 ∧ code e301453788986 = 1400965416762 := by decide
theorem cert_e301453788986 : check e301453788986 [[],[]] .chain = true := by decide
def e301453790038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e301453790038 : Closed e301453790038 ∧ code e301453790038 = 1400965417814 := by decide
theorem cert_e301453790038 : check e301453790038 [[],[]] .chain = true := by decide
def e301453790042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e301453790042 : Closed e301453790042 ∧ code e301453790042 = 1400965417818 := by decide
theorem cert_e301453790042 : check e301453790042 [[],[]] .chain = true := by decide
def e301453790058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e301453790058 : Closed e301453790058 ∧ code e301453790058 = 1400965417834 := by decide
theorem cert_e301453790058 : check e301453790058 [[],[]] .chain = true := by decide
def e301453790122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e301453790122 : Closed e301453790122 ∧ code e301453790122 = 1400965417898 := by decide
theorem cert_e301453790122 : check e301453790122 [[],[]] .chain = true := by decide
def e301453790326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e301453790326 : Closed e301453790326 ∧ code e301453790326 = 1400965418102 := by decide
theorem cert_e301453790326 : check e301453790326 [[],[]] .chain = true := by decide
def e301453790422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e301453790422 : Closed e301453790422 ∧ code e301453790422 = 1400965418198 := by decide
theorem cert_e301453790422 : check e301453790422 [[],[]] .chain = true := by decide
def e301453790426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e301453790426 : Closed e301453790426 ∧ code e301453790426 = 1400965418202 := by decide
theorem cert_e301453790426 : check e301453790426 [[],[]] .chain = true := by decide
def e301453790442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e301453790442 : Closed e301453790442 ∧ code e301453790442 = 1400965418218 := by decide
theorem cert_e301453790442 : check e301453790442 [[],[]] .chain = true := by decide
def e301453790518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e301453790518 : Closed e301453790518 ∧ code e301453790518 = 1400965418294 := by decide
theorem cert_e301453790518 : check e301453790518 [[],[]] .chain = true := by decide
def e301453790522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e301453790522 : Closed e301453790522 ∧ code e301453790522 = 1400965418298 := by decide
theorem cert_e301453790522 : check e301453790522 [[],[]] .chain = true := by decide
def e301453790606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e301453790606 : Closed e301453790606 ∧ code e301453790606 = 1400965418382 := by decide
theorem cert_e301453790606 : check e301453790606 [[],[]] .chain = true := by decide
def e301453790618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e301453790618 : Closed e301453790618 ∧ code e301453790618 = 1400965418394 := by decide
theorem cert_e301453790618 : check e301453790618 [[],[]] .chain = true := by decide
def e301453790774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e301453790774 : Closed e301453790774 ∧ code e301453790774 = 1400965418550 := by decide
theorem cert_e301453790774 : check e301453790774 [[],[]] .chain = true := by decide
def e301453790778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e301453790778 : Closed e301453790778 ∧ code e301453790778 = 1400965418554 := by decide
theorem cert_e301453790778 : check e301453790778 [[],[]] .chain = true := by decide
def e301453790826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e301453790826 : Closed e301453790826 ∧ code e301453790826 = 1400965418602 := by decide
theorem cert_e301453790826 : check e301453790826 [[],[]] .chain = true := by decide
def e301453790862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e301453790862 : Closed e301453790862 ∧ code e301453790862 = 1400965418638 := by decide
theorem cert_e301453790862 : check e301453790862 [[],[]] .chain = true := by decide
def e301453790874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e301453790874 : Closed e301453790874 ∧ code e301453790874 = 1400965418650 := by decide
theorem cert_e301453790874 : check e301453790874 [[],[]] .chain = true := by decide
def e301453790918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e301453790918 : Closed e301453790918 ∧ code e301453790918 = 1400965418694 := by decide
theorem cert_e301453790918 : check e301453790918 [[],[]] .chain = true := by decide
def e301453791470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e301453791470 : Closed e301453791470 ∧ code e301453791470 = 1400965419246 := by decide
theorem cert_e301453791470 : check e301453791470 [[],[]] .chain = true := by decide
def e301453791478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e301453791478 : Closed e301453791478 ∧ code e301453791478 = 1400965419254 := by decide
theorem cert_e301453791478 : check e301453791478 [[],[]] .chain = true := by decide
def e301453791958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e301453791958 : Closed e301453791958 ∧ code e301453791958 = 1400965419734 := by decide
theorem cert_e301453791958 : check e301453791958 [[],[]] .chain = true := by decide
def e301453791962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e301453791962 : Closed e301453791962 ∧ code e301453791962 = 1400965419738 := by decide
theorem cert_e301453791962 : check e301453791962 [[],[]] .chain = true := by decide
def e301453791978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e301453791978 : Closed e301453791978 ∧ code e301453791978 = 1400965419754 := by decide
theorem cert_e301453791978 : check e301453791978 [[],[]] .chain = true := by decide
def e301453792054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e301453792054 : Closed e301453792054 ∧ code e301453792054 = 1400965419830 := by decide
theorem cert_e301453792054 : check e301453792054 [[],[]] .chain = true := by decide
def e301453792058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e301453792058 : Closed e301453792058 ∧ code e301453792058 = 1400965419834 := by decide
theorem cert_e301453792058 : check e301453792058 [[],[]] .chain = true := by decide
def e301453792142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e301453792142 : Closed e301453792142 ∧ code e301453792142 = 1400965419918 := by decide
theorem cert_e301453792142 : check e301453792142 [[],[]] .chain = true := by decide
def e301453792154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e301453792154 : Closed e301453792154 ∧ code e301453792154 = 1400965419930 := by decide
theorem cert_e301453792154 : check e301453792154 [[],[]] .chain = true := by decide
def e301453793398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e301453793398 : Closed e301453793398 ∧ code e301453793398 = 1400965421174 := by decide
theorem cert_e301453793398 : check e301453793398 [[],[]] .chain = true := by decide
def e301453793642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e301453793642 : Closed e301453793642 ∧ code e301453793642 = 1400965421418 := by decide
theorem cert_e301453793642 : check e301453793642 [[],[]] .chain = true := by decide
def e301453793678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e301453793678 : Closed e301453793678 ∧ code e301453793678 = 1400965421454 := by decide
theorem cert_e301453793678 : check e301453793678 [[],[]] .chain = true := by decide
def e301453793690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e301453793690 : Closed e301453793690 ∧ code e301453793690 = 1400965421466 := by decide
theorem cert_e301453793690 : check e301453793690 [[],[]] .chain = true := by decide
def e301453793734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e301453793734 : Closed e301453793734 ∧ code e301453793734 = 1400965421510 := by decide
theorem cert_e301453793734 : check e301453793734 [[],[]] .chain = true := by decide
def e301453806446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e301453806446 : Closed e301453806446 ∧ code e301453806446 = 1400965434222 := by decide
theorem cert_e301453806446 : check e301453806446 [[],[]] .smaller = true := by decide
def e301453806454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e301453806454 : Closed e301453806454 ∧ code e301453806454 = 1400965434230 := by decide
theorem cert_e301453806454 : check e301453806454 [[],[]] .smaller = true := by decide
def e301453806510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e301453806510 : Closed e301453806510 ∧ code e301453806510 = 1400965434286 := by decide
theorem cert_e301453806510 : check e301453806510 [[],[]] .smaller = true := by decide
def e301453806522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e301453806522 : Closed e301453806522 ∧ code e301453806522 = 1400965434298 := by decide
theorem cert_e301453806522 : check e301453806522 [[],[]] .smaller = true := by decide
def e301453806550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e301453806550 : Closed e301453806550 ∧ code e301453806550 = 1400965434326 := by decide
theorem cert_e301453806550 : check e301453806550 [[],[]] .smaller = true := by decide
def e301453806554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e301453806554 : Closed e301453806554 ∧ code e301453806554 = 1400965434330 := by decide
theorem cert_e301453806554 : check e301453806554 [[],[]] .smaller = true := by decide
def e301453806830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e301453806830 : Closed e301453806830 ∧ code e301453806830 = 1400965434606 := by decide
theorem cert_e301453806830 : check e301453806830 [[],[]] .smaller = true := by decide
def e301453806838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e301453806838 : Closed e301453806838 ∧ code e301453806838 = 1400965434614 := by decide
theorem cert_e301453806838 : check e301453806838 [[],[]] .smaller = true := by decide
def e301453807214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e301453807214 : Closed e301453807214 ∧ code e301453807214 = 1400965434990 := by decide
theorem cert_e301453807214 : check e301453807214 [[],[]] .smaller = true := by decide
def e301453807226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e301453807226 : Closed e301453807226 ∧ code e301453807226 = 1400965435002 := by decide
theorem cert_e301453807226 : check e301453807226 [[],[]] .smaller = true := by decide
def e301453807414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e301453807414 : Closed e301453807414 ∧ code e301453807414 = 1400965435190 := by decide
theorem cert_e301453807414 : check e301453807414 [[],[]] .smaller = true := by decide
def e301453807418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e301453807418 : Closed e301453807418 ∧ code e301453807418 = 1400965435194 := by decide
theorem cert_e301453807418 : check e301453807418 [[],[]] .smaller = true := by decide
def e301453847918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e301453847918 : Closed e301453847918 ∧ code e301453847918 = 1400965475694 := by decide
theorem cert_e301453847918 : check e301453847918 [[],[]] .chain = true := by decide
def e301453847926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e301453847926 : Closed e301453847926 ∧ code e301453847926 = 1400965475702 := by decide
theorem cert_e301453847926 : check e301453847926 [[],[]] .chain = true := by decide
def e301453847982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e301453847982 : Closed e301453847982 ∧ code e301453847982 = 1400965475758 := by decide
theorem cert_e301453847982 : check e301453847982 [[],[]] .chain = true := by decide
def e301453847994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e301453847994 : Closed e301453847994 ∧ code e301453847994 = 1400965475770 := by decide
theorem cert_e301453847994 : check e301453847994 [[],[]] .chain = true := by decide
def e301453848022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e301453848022 : Closed e301453848022 ∧ code e301453848022 = 1400965475798 := by decide
theorem cert_e301453848022 : check e301453848022 [[],[]] .chain = true := by decide
def e301453848026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e301453848026 : Closed e301453848026 ∧ code e301453848026 = 1400965475802 := by decide
theorem cert_e301453848026 : check e301453848026 [[],[]] .chain = true := by decide
def e301453848238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e301453848238 : Closed e301453848238 ∧ code e301453848238 = 1400965476014 := by decide
theorem cert_e301453848238 : check e301453848238 [[],[]] .chain = true := by decide
def e301453848250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e301453848250 : Closed e301453848250 ∧ code e301453848250 = 1400965476026 := by decide
theorem cert_e301453848250 : check e301453848250 [[],[]] .chain = true := by decide
def e301453848298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e301453848298 : Closed e301453848298 ∧ code e301453848298 = 1400965476074 := by decide
theorem cert_e301453848298 : check e301453848298 [[],[]] .chain = true := by decide
def e301453848406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e301453848406 : Closed e301453848406 ∧ code e301453848406 = 1400965476182 := by decide
theorem cert_e301453848406 : check e301453848406 [[],[]] .chain = true := by decide
def e301453848410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e301453848410 : Closed e301453848410 ∧ code e301453848410 = 1400965476186 := by decide
theorem cert_e301453848410 : check e301453848410 [[],[]] .chain = true := by decide
def e301453848426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e301453848426 : Closed e301453848426 ∧ code e301453848426 = 1400965476202 := by decide
theorem cert_e301453848426 : check e301453848426 [[],[]] .chain = true := by decide
def e301453849454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e301453849454 : Closed e301453849454 ∧ code e301453849454 = 1400965477230 := by decide
theorem cert_e301453849454 : check e301453849454 [[],[]] .chain = true := by decide
def e301453849462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e301453849462 : Closed e301453849462 ∧ code e301453849462 = 1400965477238 := by decide
theorem cert_e301453849462 : check e301453849462 [[],[]] .chain = true := by decide
def e301453849518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e301453849518 : Closed e301453849518 ∧ code e301453849518 = 1400965477294 := by decide
theorem cert_e301453849518 : check e301453849518 [[],[]] .chain = true := by decide
def e301453849530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e301453849530 : Closed e301453849530 ∧ code e301453849530 = 1400965477306 := by decide
theorem cert_e301453849530 : check e301453849530 [[],[]] .chain = true := by decide
def e301453849558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e301453849558 : Closed e301453849558 ∧ code e301453849558 = 1400965477334 := by decide
theorem cert_e301453849558 : check e301453849558 [[],[]] .chain = true := by decide
def e301453849562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e301453849562 : Closed e301453849562 ∧ code e301453849562 = 1400965477338 := by decide
theorem cert_e301453849562 : check e301453849562 [[],[]] .chain = true := by decide
def e301453849838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e301453849838 : Closed e301453849838 ∧ code e301453849838 = 1400965477614 := by decide
theorem cert_e301453849838 : check e301453849838 [[],[]] .chain = true := by decide
def e301453849846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e301453849846 : Closed e301453849846 ∧ code e301453849846 = 1400965477622 := by decide
theorem cert_e301453849846 : check e301453849846 [[],[]] .chain = true := by decide
def e301453850222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e301453850222 : Closed e301453850222 ∧ code e301453850222 = 1400965477998 := by decide
theorem cert_e301453850222 : check e301453850222 [[],[]] .chain = true := by decide
def e301453850234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e301453850234 : Closed e301453850234 ∧ code e301453850234 = 1400965478010 := by decide
theorem cert_e301453850234 : check e301453850234 [[],[]] .chain = true := by decide
def e301453850422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e301453850422 : Closed e301453850422 ∧ code e301453850422 = 1400965478198 := by decide
theorem cert_e301453850422 : check e301453850422 [[],[]] .chain = true := by decide
def e301453850426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e301453850426 : Closed e301453850426 ∧ code e301453850426 = 1400965478202 := by decide
theorem cert_e301453850426 : check e301453850426 [[],[]] .chain = true := by decide
def e301453850862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))
theorem wire_e301453850862 : Closed e301453850862 ∧ code e301453850862 = 1400965478638 := by decide
theorem cert_e301453850862 : check e301453850862 [[],[]] .chain = true := by decide
def e301453850870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))
theorem wire_e301453850870 : Closed e301453850870 ∧ code e301453850870 = 1400965478646 := by decide
theorem cert_e301453850870 : check e301453850870 [[],[]] .chain = true := by decide
def e301453851054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e301453851054 : Closed e301453851054 ∧ code e301453851054 = 1400965478830 := by decide
theorem cert_e301453851054 : check e301453851054 [[],[]] .chain = true := by decide
def e301453851066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e301453851066 : Closed e301453851066 ∧ code e301453851066 = 1400965478842 := by decide
theorem cert_e301453851066 : check e301453851066 [[],[]] .chain = true := by decide
def e301453851114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e301453851114 : Closed e301453851114 ∧ code e301453851114 = 1400965478890 := by decide
theorem cert_e301453851114 : check e301453851114 [[],[]] .chain = true := by decide
def e301453851246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e301453851246 : Closed e301453851246 ∧ code e301453851246 = 1400965479022 := by decide
theorem cert_e301453851246 : check e301453851246 [[],[]] .chain = true := by decide
def e301453851258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e301453851258 : Closed e301453851258 ∧ code e301453851258 = 1400965479034 := by decide
theorem cert_e301453851258 : check e301453851258 [[],[]] .chain = true := by decide
def e301453851422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))
theorem wire_e301453851422 : Closed e301453851422 ∧ code e301453851422 = 1400965479198 := by decide
theorem cert_e301453851422 : check e301453851422 [[],[]] .chain = true := by decide
def e301453851534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))
theorem wire_e301453851534 : Closed e301453851534 ∧ code e301453851534 = 1400965479310 := by decide
theorem cert_e301453851534 : check e301453851534 [[],[]] .chain = true := by decide
def e301453851546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e301453851546 : Closed e301453851546 ∧ code e301453851546 = 1400965479322 := by decide
theorem cert_e301453851546 : check e301453851546 [[],[]] .chain = true := by decide
def e301453851766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))
theorem wire_e301453851766 : Closed e301453851766 ∧ code e301453851766 = 1400965479542 := by decide
theorem cert_e301453851766 : check e301453851766 [[],[]] .chain = true := by decide
def e301453851862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e301453851862 : Closed e301453851862 ∧ code e301453851862 = 1400965479638 := by decide
theorem cert_e301453851862 : check e301453851862 [[],[]] .chain = true := by decide
def e301453851866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e301453851866 : Closed e301453851866 ∧ code e301453851866 = 1400965479642 := by decide
theorem cert_e301453851866 : check e301453851866 [[],[]] .chain = true := by decide
def e301453851882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e301453851882 : Closed e301453851882 ∧ code e301453851882 = 1400965479658 := by decide
theorem cert_e301453851882 : check e301453851882 [[],[]] .chain = true := by decide
def e301453851958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e301453851958 : Closed e301453851958 ∧ code e301453851958 = 1400965479734 := by decide
theorem cert_e301453851958 : check e301453851958 [[],[]] .chain = true := by decide
def e301453851962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e301453851962 : Closed e301453851962 ∧ code e301453851962 = 1400965479738 := by decide
theorem cert_e301453851962 : check e301453851962 [[],[]] .chain = true := by decide
def e301453852046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))
theorem wire_e301453852046 : Closed e301453852046 ∧ code e301453852046 = 1400965479822 := by decide
theorem cert_e301453852046 : check e301453852046 [[],[]] .chain = true := by decide
def e301453852058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e301453852058 : Closed e301453852058 ∧ code e301453852058 = 1400965479834 := by decide
theorem cert_e301453852058 : check e301453852058 [[],[]] .chain = true := by decide
def e301453853662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e301453853662 : Closed e301453853662 ∧ code e301453853662 = 1400965481438 := by decide
theorem cert_e301453853662 : check e301453853662 [[],[]] .chain = true := by decide
def e301453853678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e301453853678 : Closed e301453853678 ∧ code e301453853678 = 1400965481454 := by decide
theorem cert_e301453853678 : check e301453853678 [[],[]] .chain = true := by decide
def e301453855598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e301453855598 : Closed e301453855598 ∧ code e301453855598 = 1400965483374 := by decide
theorem cert_e301453855598 : check e301453855598 [[],[]] .chain = true := by decide
def e301453855606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e301453855606 : Closed e301453855606 ∧ code e301453855606 = 1400965483382 := by decide
theorem cert_e301453855606 : check e301453855606 [[],[]] .chain = true := by decide
def e301453855662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e301453855662 : Closed e301453855662 ∧ code e301453855662 = 1400965483438 := by decide
theorem cert_e301453855662 : check e301453855662 [[],[]] .chain = true := by decide
def e301453855674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e301453855674 : Closed e301453855674 ∧ code e301453855674 = 1400965483450 := by decide
theorem cert_e301453855674 : check e301453855674 [[],[]] .chain = true := by decide
def e301453855702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e301453855702 : Closed e301453855702 ∧ code e301453855702 = 1400965483478 := by decide
theorem cert_e301453855702 : check e301453855702 [[],[]] .chain = true := by decide
def e301453855706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e301453855706 : Closed e301453855706 ∧ code e301453855706 = 1400965483482 := by decide
theorem cert_e301453855706 : check e301453855706 [[],[]] .chain = true := by decide
def e301453855982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e301453855982 : Closed e301453855982 ∧ code e301453855982 = 1400965483758 := by decide
theorem cert_e301453855982 : check e301453855982 [[],[]] .chain = true := by decide
def e301453855990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e301453855990 : Closed e301453855990 ∧ code e301453855990 = 1400965483766 := by decide
theorem cert_e301453855990 : check e301453855990 [[],[]] .chain = true := by decide
def e301453856366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e301453856366 : Closed e301453856366 ∧ code e301453856366 = 1400965484142 := by decide
theorem cert_e301453856366 : check e301453856366 [[],[]] .chain = true := by decide
def e301453856378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e301453856378 : Closed e301453856378 ∧ code e301453856378 = 1400965484154 := by decide
theorem cert_e301453856378 : check e301453856378 [[],[]] .chain = true := by decide
def e301453856566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e301453856566 : Closed e301453856566 ∧ code e301453856566 = 1400965484342 := by decide
theorem cert_e301453856566 : check e301453856566 [[],[]] .chain = true := by decide
def e301453856570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e301453856570 : Closed e301453856570 ∧ code e301453856570 = 1400965484346 := by decide
theorem cert_e301453856570 : check e301453856570 [[],[]] .chain = true := by decide
def e301453861342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e301453861342 : Closed e301453861342 ∧ code e301453861342 = 1400965489118 := by decide
theorem cert_e301453861342 : check e301453861342 [[],[]] .chain = true := by decide
def e301453861366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e301453861366 : Closed e301453861366 ∧ code e301453861366 = 1400965489142 := by decide
theorem cert_e301453861366 : check e301453861366 [[],[]] .chain = true := by decide
def e301453862318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e301453862318 : Closed e301453862318 ∧ code e301453862318 = 1400965490094 := by decide
theorem cert_e301453862318 : check e301453862318 [[],[]] .chain = true := by decide
def e301453862330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e301453862330 : Closed e301453862330 ∧ code e301453862330 = 1400965490106 := by decide
theorem cert_e301453862330 : check e301453862330 [[],[]] .chain = true := by decide
def e301453862378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e301453862378 : Closed e301453862378 ∧ code e301453862378 = 1400965490154 := by decide
theorem cert_e301453862378 : check e301453862378 [[],[]] .chain = true := by decide
def e301453862510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e301453862510 : Closed e301453862510 ∧ code e301453862510 = 1400965490286 := by decide
theorem cert_e301453862510 : check e301453862510 [[],[]] .chain = true := by decide
def e301453862522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e301453862522 : Closed e301453862522 ∧ code e301453862522 = 1400965490298 := by decide
theorem cert_e301453862522 : check e301453862522 [[],[]] .chain = true := by decide
def e301453862686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e301453862686 : Closed e301453862686 ∧ code e301453862686 = 1400965490462 := by decide
theorem cert_e301453862686 : check e301453862686 [[],[]] .chain = true := by decide
def e301453862798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e301453862798 : Closed e301453862798 ∧ code e301453862798 = 1400965490574 := by decide
theorem cert_e301453862798 : check e301453862798 [[],[]] .chain = true := by decide
def e301453862810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e301453862810 : Closed e301453862810 ∧ code e301453862810 = 1400965490586 := by decide
theorem cert_e301453862810 : check e301453862810 [[],[]] .chain = true := by decide
def e301453865198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e301453865198 : Closed e301453865198 ∧ code e301453865198 = 1400965492974 := by decide
theorem cert_e301453865198 : check e301453865198 [[],[]] .chain = true := by decide
def e301453865206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e301453865206 : Closed e301453865206 ∧ code e301453865206 = 1400965492982 := by decide
theorem cert_e301453865206 : check e301453865206 [[],[]] .chain = true := by decide
def e301453865686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e301453865686 : Closed e301453865686 ∧ code e301453865686 = 1400965493462 := by decide
theorem cert_e301453865686 : check e301453865686 [[],[]] .chain = true := by decide
def e301453865690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e301453865690 : Closed e301453865690 ∧ code e301453865690 = 1400965493466 := by decide
theorem cert_e301453865690 : check e301453865690 [[],[]] .chain = true := by decide
def e301453865706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e301453865706 : Closed e301453865706 ∧ code e301453865706 = 1400965493482 := by decide
theorem cert_e301453865706 : check e301453865706 [[],[]] .chain = true := by decide
def e301453865782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e301453865782 : Closed e301453865782 ∧ code e301453865782 = 1400965493558 := by decide
theorem cert_e301453865782 : check e301453865782 [[],[]] .chain = true := by decide
def e301453865786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e301453865786 : Closed e301453865786 ∧ code e301453865786 = 1400965493562 := by decide
theorem cert_e301453865786 : check e301453865786 [[],[]] .chain = true := by decide
def e301453865870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e301453865870 : Closed e301453865870 ∧ code e301453865870 = 1400965493646 := by decide
theorem cert_e301453865870 : check e301453865870 [[],[]] .chain = true := by decide
def e301453865882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e301453865882 : Closed e301453865882 ∧ code e301453865882 = 1400965493658 := by decide
theorem cert_e301453865882 : check e301453865882 [[],[]] .chain = true := by decide
def e301453956782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e301453956782 : Closed e301453956782 ∧ code e301453956782 = 1400965584558 := by decide
theorem cert_e301453956782 : check e301453956782 [[],[]] .chain = true := by decide
def e301453956794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e301453956794 : Closed e301453956794 ∧ code e301453956794 = 1400965584570 := by decide
theorem cert_e301453956794 : check e301453956794 [[],[]] .chain = true := by decide
def e301453956842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e301453956842 : Closed e301453956842 ∧ code e301453956842 = 1400965584618 := by decide
theorem cert_e301453956842 : check e301453956842 [[],[]] .chain = true := by decide
def e301453957034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e301453957034 : Closed e301453957034 ∧ code e301453957034 = 1400965584810 := by decide
theorem cert_e301453957034 : check e301453957034 [[],[]] .chain = true := by decide
def e301453957358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e301453957358 : Closed e301453957358 ∧ code e301453957358 = 1400965585134 := by decide
theorem cert_e301453957358 : check e301453957358 [[],[]] .chain = true := by decide
def e301453957366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e301453957366 : Closed e301453957366 ∧ code e301453957366 = 1400965585142 := by decide
theorem cert_e301453957366 : check e301453957366 [[],[]] .chain = true := by decide
def e301453957550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e301453957550 : Closed e301453957550 ∧ code e301453957550 = 1400965585326 := by decide
theorem cert_e301453957550 : check e301453957550 [[],[]] .chain = true := by decide
def e301453957562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e301453957562 : Closed e301453957562 ∧ code e301453957562 = 1400965585338 := by decide
theorem cert_e301453957562 : check e301453957562 [[],[]] .chain = true := by decide
def e301453957610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e301453957610 : Closed e301453957610 ∧ code e301453957610 = 1400965585386 := by decide
theorem cert_e301453957610 : check e301453957610 [[],[]] .chain = true := by decide
def e301453957742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e301453957742 : Closed e301453957742 ∧ code e301453957742 = 1400965585518 := by decide
theorem cert_e301453957742 : check e301453957742 [[],[]] .chain = true := by decide
def e301453957754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e301453957754 : Closed e301453957754 ∧ code e301453957754 = 1400965585530 := by decide
theorem cert_e301453957754 : check e301453957754 [[],[]] .chain = true := by decide
def e301453957918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e301453957918 : Closed e301453957918 ∧ code e301453957918 = 1400965585694 := by decide
theorem cert_e301453957918 : check e301453957918 [[],[]] .chain = true := by decide
def e301453958030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e301453958030 : Closed e301453958030 ∧ code e301453958030 = 1400965585806 := by decide
theorem cert_e301453958030 : check e301453958030 [[],[]] .chain = true := by decide
def e301453958042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e301453958042 : Closed e301453958042 ∧ code e301453958042 = 1400965585818 := by decide
theorem cert_e301453958042 : check e301453958042 [[],[]] .chain = true := by decide
def e301453958254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e301453958254 : Closed e301453958254 ∧ code e301453958254 = 1400965586030 := by decide
theorem cert_e301453958254 : check e301453958254 [[],[]] .chain = true := by decide
end Blc.Floor40
