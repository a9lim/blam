import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e282511599022 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e282511599022 : Closed e282511599022 ∧ code e282511599022 = 1382023226798 := by decide
theorem cert_e282511599022 : check e282511599022 [[],[.under]] .three = true := by decide
def e282511599034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e282511599034 : Closed e282511599034 ∧ code e282511599034 = 1382023226810 := by decide
theorem cert_e282511599034 : check e282511599034 [[],[.under]] .three = true := by decide
def e282511599082 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e282511599082 : Closed e282511599082 ∧ code e282511599082 = 1382023226858 := by decide
theorem cert_e282511599082 : check e282511599082 [[],[.under]] .three = true := by decide
def e282511599214 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e282511599214 : Closed e282511599214 ∧ code e282511599214 = 1382023226990 := by decide
theorem cert_e282511599214 : check e282511599214 [[],[.under]] .three = true := by decide
def e282511599226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e282511599226 : Closed e282511599226 ∧ code e282511599226 = 1382023227002 := by decide
theorem cert_e282511599226 : check e282511599226 [[],[.under]] .three = true := by decide
def e282511599514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e282511599514 : Closed e282511599514 ∧ code e282511599514 = 1382023227290 := by decide
theorem cert_e282511599514 : check e282511599514 [[],[.under]] .three = true := by decide
def e282511602390 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e282511602390 : Closed e282511602390 ∧ code e282511602390 = 1382023230166 := by decide
theorem cert_e282511602390 : check e282511602390 [[],[.under]] .three = true := by decide
def e282511602394 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e282511602394 : Closed e282511602394 ∧ code e282511602394 = 1382023230170 := by decide
theorem cert_e282511602394 : check e282511602394 [[],[.under]] .three = true := by decide
def e282511602410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e282511602410 : Closed e282511602410 ∧ code e282511602410 = 1382023230186 := by decide
theorem cert_e282511602410 : check e282511602410 [[],[.under]] .three = true := by decide
def e282511602486 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e282511602486 : Closed e282511602486 ∧ code e282511602486 = 1382023230262 := by decide
theorem cert_e282511602486 : check e282511602486 [[],[.under]] .three = true := by decide
def e282511602490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e282511602490 : Closed e282511602490 ∧ code e282511602490 = 1382023230266 := by decide
theorem cert_e282511602490 : check e282511602490 [[],[.under]] .three = true := by decide
def e282511602586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e282511602586 : Closed e282511602586 ∧ code e282511602586 = 1382023230362 := by decide
theorem cert_e282511602586 : check e282511602586 [[],[.under]] .three = true := by decide
def e282511739758 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e282511739758 : Closed e282511739758 ∧ code e282511739758 = 1382023367534 := by decide
theorem cert_e282511739758 : check e282511739758 [[],[.under]] .chain = true := by decide
def e282511739766 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e282511739766 : Closed e282511739766 ∧ code e282511739766 = 1382023367542 := by decide
theorem cert_e282511739766 : check e282511739766 [[],[.under]] .chain = true := by decide
def e282511739822 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e282511739822 : Closed e282511739822 ∧ code e282511739822 = 1382023367598 := by decide
theorem cert_e282511739822 : check e282511739822 [[],[.under]] .chain = true := by decide
def e282511739834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e282511739834 : Closed e282511739834 ∧ code e282511739834 = 1382023367610 := by decide
theorem cert_e282511739834 : check e282511739834 [[],[.under]] .chain = true := by decide
def e282511739862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e282511739862 : Closed e282511739862 ∧ code e282511739862 = 1382023367638 := by decide
theorem cert_e282511739862 : check e282511739862 [[],[.under]] .chain = true := by decide
def e282511739866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e282511739866 : Closed e282511739866 ∧ code e282511739866 = 1382023367642 := by decide
theorem cert_e282511739866 : check e282511739866 [[],[.under]] .chain = true := by decide
def e282511740142 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e282511740142 : Closed e282511740142 ∧ code e282511740142 = 1382023367918 := by decide
theorem cert_e282511740142 : check e282511740142 [[],[.under]] .chain = true := by decide
def e282511740150 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e282511740150 : Closed e282511740150 ∧ code e282511740150 = 1382023367926 := by decide
theorem cert_e282511740150 : check e282511740150 [[],[.under]] .chain = true := by decide
def e282511740526 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e282511740526 : Closed e282511740526 ∧ code e282511740526 = 1382023368302 := by decide
theorem cert_e282511740526 : check e282511740526 [[],[.under]] .chain = true := by decide
def e282511740538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e282511740538 : Closed e282511740538 ∧ code e282511740538 = 1382023368314 := by decide
theorem cert_e282511740538 : check e282511740538 [[],[.under]] .chain = true := by decide
def e282511740726 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e282511740726 : Closed e282511740726 ∧ code e282511740726 = 1382023368502 := by decide
theorem cert_e282511740726 : check e282511740726 [[],[.under]] .chain = true := by decide
def e282511740730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e282511740730 : Closed e282511740730 ∧ code e282511740730 = 1382023368506 := by decide
theorem cert_e282511740730 : check e282511740730 [[],[.under]] .chain = true := by decide
def e282512329582 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e282512329582 : Closed e282512329582 ∧ code e282512329582 = 1382023957358 := by decide
theorem cert_e282512329582 : check e282512329582 [[],[.under],[.under]] .smaller = true := by decide
def e282512329590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e282512329590 : Closed e282512329590 ∧ code e282512329590 = 1382023957366 := by decide
theorem cert_e282512329590 : check e282512329590 [[],[.under],[.under]] .smaller = true := by decide
def e282512329646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e282512329646 : Closed e282512329646 ∧ code e282512329646 = 1382023957422 := by decide
theorem cert_e282512329646 : check e282512329646 [[],[.under],[.under]] .smaller = true := by decide
def e282512329658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e282512329658 : Closed e282512329658 ∧ code e282512329658 = 1382023957434 := by decide
theorem cert_e282512329658 : check e282512329658 [[],[.under],[.under]] .smaller = true := by decide
def e282512329686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e282512329686 : Closed e282512329686 ∧ code e282512329686 = 1382023957462 := by decide
theorem cert_e282512329686 : check e282512329686 [[],[.under],[.under]] .smaller = true := by decide
def e282512329690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e282512329690 : Closed e282512329690 ∧ code e282512329690 = 1382023957466 := by decide
theorem cert_e282512329690 : check e282512329690 [[],[.under],[.under]] .smaller = true := by decide
def e282512329966 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e282512329966 : Closed e282512329966 ∧ code e282512329966 = 1382023957742 := by decide
theorem cert_e282512329966 : check e282512329966 [[],[.under],[.under]] .smaller = true := by decide
def e282512329974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e282512329974 : Closed e282512329974 ∧ code e282512329974 = 1382023957750 := by decide
theorem cert_e282512329974 : check e282512329974 [[],[.under],[.under]] .smaller = true := by decide
def e282512330350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e282512330350 : Closed e282512330350 ∧ code e282512330350 = 1382023958126 := by decide
theorem cert_e282512330350 : check e282512330350 [[],[.under],[.under]] .smaller = true := by decide
def e282512330362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e282512330362 : Closed e282512330362 ∧ code e282512330362 = 1382023958138 := by decide
theorem cert_e282512330362 : check e282512330362 [[],[.under],[.under]] .smaller = true := by decide
def e282512330550 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e282512330550 : Closed e282512330550 ∧ code e282512330550 = 1382023958326 := by decide
theorem cert_e282512330550 : check e282512330550 [[],[.under],[.under]] .smaller = true := by decide
def e282512330554 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e282512330554 : Closed e282512330554 ∧ code e282512330554 = 1382023958330 := by decide
theorem cert_e282512330554 : check e282512330554 [[],[.under],[.under]] .smaller = true := by decide
def e282796841694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e282796841694 : Closed e282796841694 ∧ code e282796841694 = 1382308469470 := by decide
theorem cert_e282796841694 : check e282796841694 [[],[.under]] .three = true := by decide
def e282796841718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e282796841718 : Closed e282796841718 ∧ code e282796841718 = 1382308469494 := by decide
theorem cert_e282796841718 : check e282796841718 [[],[.under]] .three = true := by decide
def e282796841822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e282796841822 : Closed e282796841822 ∧ code e282796841822 = 1382308469598 := by decide
theorem cert_e282796841822 : check e282796841822 [[],[.under]] .three = true := by decide
def e282796841838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e282796841838 : Closed e282796841838 ∧ code e282796841838 = 1382308469614 := by decide
theorem cert_e282796841838 : check e282796841838 [[],[.under]] .smaller = true := by decide
def e282796841846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e282796841846 : Closed e282796841846 ∧ code e282796841846 = 1382308469622 := by decide
theorem cert_e282796841846 : check e282796841846 [[],[.under]] .smaller = true := by decide
def e282796841850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e282796841850 : Closed e282796841850 ∧ code e282796841850 = 1382308469626 := by decide
theorem cert_e282796841850 : check e282796841850 [[],[.under]] .three = true := by decide
def e282796841910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e282796841910 : Closed e282796841910 ∧ code e282796841910 = 1382308469686 := by decide
theorem cert_e282796841910 : check e282796841910 [[],[.under]] .smaller = true := by decide
def e282796841942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e282796841942 : Closed e282796841942 ∧ code e282796841942 = 1382308469718 := by decide
theorem cert_e282796841942 : check e282796841942 [[],[.under]] .three = true := by decide
def e282796841946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e282796841946 : Closed e282796841946 ∧ code e282796841946 = 1382308469722 := by decide
theorem cert_e282796841946 : check e282796841946 [[],[.under]] .three = true := by decide
def e282796842334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e282796842334 : Closed e282796842334 ∧ code e282796842334 = 1382308470110 := by decide
theorem cert_e282796842334 : check e282796842334 [[],[.under]] .three = true := by decide
def e282796842350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e282796842350 : Closed e282796842350 ∧ code e282796842350 = 1382308470126 := by decide
theorem cert_e282796842350 : check e282796842350 [[],[.under]] .smaller = true := by decide
def e282796842358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e282796842358 : Closed e282796842358 ∧ code e282796842358 = 1382308470134 := by decide
theorem cert_e282796842358 : check e282796842358 [[],[.under]] .smaller = true := by decide
def e282796842362 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e282796842362 : Closed e282796842362 ∧ code e282796842362 = 1382308470138 := by decide
theorem cert_e282796842362 : check e282796842362 [[],[.under]] .three = true := by decide
def e282796842414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e282796842414 : Closed e282796842414 ∧ code e282796842414 = 1382308470190 := by decide
theorem cert_e282796842414 : check e282796842414 [[],[.under]] .smaller = true := by decide
def e282796842426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e282796842426 : Closed e282796842426 ∧ code e282796842426 = 1382308470202 := by decide
theorem cert_e282796842426 : check e282796842426 [[],[.under]] .smaller = true := by decide
def e282796842454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e282796842454 : Closed e282796842454 ∧ code e282796842454 = 1382308470230 := by decide
theorem cert_e282796842454 : check e282796842454 [[],[.under]] .smaller = true := by decide
def e282796842458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e282796842458 : Closed e282796842458 ∧ code e282796842458 = 1382308470234 := by decide
theorem cert_e282796842458 : check e282796842458 [[],[.under]] .smaller = true := by decide
def e282796842474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e282796842474 : Closed e282796842474 ∧ code e282796842474 = 1382308470250 := by decide
theorem cert_e282796842474 : check e282796842474 [[],[.under]] .three = true := by decide
def e282796842678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e282796842678 : Closed e282796842678 ∧ code e282796842678 = 1382308470454 := by decide
theorem cert_e282796842678 : check e282796842678 [[],[.under]] .smaller = true := by decide
def e282796842710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e282796842710 : Closed e282796842710 ∧ code e282796842710 = 1382308470486 := by decide
theorem cert_e282796842710 : check e282796842710 [[],[.under]] .smaller = true := by decide
def e282796842714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e282796842714 : Closed e282796842714 ∧ code e282796842714 = 1382308470490 := by decide
theorem cert_e282796842714 : check e282796842714 [[],[.under]] .smaller = true := by decide
def e282796842838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e282796842838 : Closed e282796842838 ∧ code e282796842838 = 1382308470614 := by decide
theorem cert_e282796842838 : check e282796842838 [[],[.under]] .three = true := by decide
def e282796842842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e282796842842 : Closed e282796842842 ∧ code e282796842842 = 1382308470618 := by decide
theorem cert_e282796842842 : check e282796842842 [[],[.under]] .three = true := by decide
def e282796842858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e282796842858 : Closed e282796842858 ∧ code e282796842858 = 1382308470634 := by decide
theorem cert_e282796842858 : check e282796842858 [[],[.under]] .three = true := by decide
def e282796844766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e282796844766 : Closed e282796844766 ∧ code e282796844766 = 1382308472542 := by decide
theorem cert_e282796844766 : check e282796844766 [[],[.under]] .three = true := by decide
def e282796844790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e282796844790 : Closed e282796844790 ∧ code e282796844790 = 1382308472566 := by decide
theorem cert_e282796844790 : check e282796844790 [[],[.under]] .three = true := by decide
def e282796844894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e282796844894 : Closed e282796844894 ∧ code e282796844894 = 1382308472670 := by decide
theorem cert_e282796844894 : check e282796844894 [[],[.under]] .three = true := by decide
def e282796844910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e282796844910 : Closed e282796844910 ∧ code e282796844910 = 1382308472686 := by decide
theorem cert_e282796844910 : check e282796844910 [[],[.under]] .smaller = true := by decide
def e282796844918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e282796844918 : Closed e282796844918 ∧ code e282796844918 = 1382308472694 := by decide
theorem cert_e282796844918 : check e282796844918 [[],[.under]] .smaller = true := by decide
def e282796844922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e282796844922 : Closed e282796844922 ∧ code e282796844922 = 1382308472698 := by decide
theorem cert_e282796844922 : check e282796844922 [[],[.under]] .three = true := by decide
def e282796844982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e282796844982 : Closed e282796844982 ∧ code e282796844982 = 1382308472758 := by decide
theorem cert_e282796844982 : check e282796844982 [[],[.under]] .smaller = true := by decide
def e282796845014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e282796845014 : Closed e282796845014 ∧ code e282796845014 = 1382308472790 := by decide
theorem cert_e282796845014 : check e282796845014 [[],[.under]] .three = true := by decide
def e282796845018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e282796845018 : Closed e282796845018 ∧ code e282796845018 = 1382308472794 := by decide
theorem cert_e282796845018 : check e282796845018 [[],[.under]] .three = true := by decide
def e282796845534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e282796845534 : Closed e282796845534 ∧ code e282796845534 = 1382308473310 := by decide
theorem cert_e282796845534 : check e282796845534 [[],[.under]] .three = true := by decide
def e282796845558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e282796845558 : Closed e282796845558 ∧ code e282796845558 = 1382308473334 := by decide
theorem cert_e282796845558 : check e282796845558 [[],[.under]] .three = true := by decide
def e282796846302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e282796846302 : Closed e282796846302 ∧ code e282796846302 = 1382308474078 := by decide
theorem cert_e282796846302 : check e282796846302 [[],[.under]] .three = true := by decide
def e282796846318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e282796846318 : Closed e282796846318 ∧ code e282796846318 = 1382308474094 := by decide
theorem cert_e282796846318 : check e282796846318 [[],[.under]] .smaller = true := by decide
def e282796846326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e282796846326 : Closed e282796846326 ∧ code e282796846326 = 1382308474102 := by decide
theorem cert_e282796846326 : check e282796846326 [[],[.under]] .smaller = true := by decide
def e282796846330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e282796846330 : Closed e282796846330 ∧ code e282796846330 = 1382308474106 := by decide
theorem cert_e282796846330 : check e282796846330 [[],[.under]] .three = true := by decide
def e282796846710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e282796846710 : Closed e282796846710 ∧ code e282796846710 = 1382308474486 := by decide
theorem cert_e282796846710 : check e282796846710 [[],[.under]] .smaller = true := by decide
def e282796846902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e282796846902 : Closed e282796846902 ∧ code e282796846902 = 1382308474678 := by decide
theorem cert_e282796846902 : check e282796846902 [[],[.under]] .three = true := by decide
def e282796846906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e282796846906 : Closed e282796846906 ∧ code e282796846906 = 1382308474682 := by decide
theorem cert_e282796846906 : check e282796846906 [[],[.under]] .three = true := by decide
def e282796847966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e282796847966 : Closed e282796847966 ∧ code e282796847966 = 1382308475742 := by decide
theorem cert_e282796847966 : check e282796847966 [[],[.under]] .three = true := by decide
def e282796847982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e282796847982 : Closed e282796847982 ∧ code e282796847982 = 1382308475758 := by decide
theorem cert_e282796847982 : check e282796847982 [[],[.under]] .smaller = true := by decide
def e282796847990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e282796847990 : Closed e282796847990 ∧ code e282796847990 = 1382308475766 := by decide
theorem cert_e282796847990 : check e282796847990 [[],[.under]] .smaller = true := by decide
def e282796847994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e282796847994 : Closed e282796847994 ∧ code e282796847994 = 1382308475770 := by decide
theorem cert_e282796847994 : check e282796847994 [[],[.under]] .three = true := by decide
def e282796848046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e282796848046 : Closed e282796848046 ∧ code e282796848046 = 1382308475822 := by decide
theorem cert_e282796848046 : check e282796848046 [[],[.under]] .smaller = true := by decide
def e282796848058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e282796848058 : Closed e282796848058 ∧ code e282796848058 = 1382308475834 := by decide
theorem cert_e282796848058 : check e282796848058 [[],[.under]] .smaller = true := by decide
def e282796848086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e282796848086 : Closed e282796848086 ∧ code e282796848086 = 1382308475862 := by decide
theorem cert_e282796848086 : check e282796848086 [[],[.under]] .smaller = true := by decide
def e282796848090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e282796848090 : Closed e282796848090 ∧ code e282796848090 = 1382308475866 := by decide
theorem cert_e282796848090 : check e282796848090 [[],[.under]] .smaller = true := by decide
def e282796848106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e282796848106 : Closed e282796848106 ∧ code e282796848106 = 1382308475882 := by decide
theorem cert_e282796848106 : check e282796848106 [[],[.under]] .three = true := by decide
def e282796848350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e282796848350 : Closed e282796848350 ∧ code e282796848350 = 1382308476126 := by decide
theorem cert_e282796848350 : check e282796848350 [[],[.under]] .three = true := by decide
def e282796848366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e282796848366 : Closed e282796848366 ∧ code e282796848366 = 1382308476142 := by decide
theorem cert_e282796848366 : check e282796848366 [[],[.under]] .smaller = true := by decide
def e282796848374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e282796848374 : Closed e282796848374 ∧ code e282796848374 = 1382308476150 := by decide
theorem cert_e282796848374 : check e282796848374 [[],[.under]] .smaller = true := by decide
def e282796848378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e282796848378 : Closed e282796848378 ∧ code e282796848378 = 1382308476154 := by decide
theorem cert_e282796848378 : check e282796848378 [[],[.under]] .three = true := by decide
def e282796848750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e282796848750 : Closed e282796848750 ∧ code e282796848750 = 1382308476526 := by decide
theorem cert_e282796848750 : check e282796848750 [[],[.under]] .smaller = true := by decide
def e282796848762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e282796848762 : Closed e282796848762 ∧ code e282796848762 = 1382308476538 := by decide
theorem cert_e282796848762 : check e282796848762 [[],[.under]] .smaller = true := by decide
def e282796848950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e282796848950 : Closed e282796848950 ∧ code e282796848950 = 1382308476726 := by decide
theorem cert_e282796848950 : check e282796848950 [[],[.under]] .smaller = true := by decide
def e282796848954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e282796848954 : Closed e282796848954 ∧ code e282796848954 = 1382308476730 := by decide
theorem cert_e282796848954 : check e282796848954 [[],[.under]] .smaller = true := by decide
def e282796849050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e282796849050 : Closed e282796849050 ∧ code e282796849050 = 1382308476826 := by decide
theorem cert_e282796849050 : check e282796849050 [[],[.under]] .three = true := by decide
def e282796849590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e282796849590 : Closed e282796849590 ∧ code e282796849590 = 1382308477366 := by decide
theorem cert_e282796849590 : check e282796849590 [[],[.under]] .smaller = true := by decide
def e282796849622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e282796849622 : Closed e282796849622 ∧ code e282796849622 = 1382308477398 := by decide
theorem cert_e282796849622 : check e282796849622 [[],[.under]] .smaller = true := by decide
def e282796849626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e282796849626 : Closed e282796849626 ∧ code e282796849626 = 1382308477402 := by decide
theorem cert_e282796849626 : check e282796849626 [[],[.under]] .smaller = true := by decide
def e282796849782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e282796849782 : Closed e282796849782 ∧ code e282796849782 = 1382308477558 := by decide
theorem cert_e282796849782 : check e282796849782 [[],[.under]] .smaller = true := by decide
def e282796849974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e282796849974 : Closed e282796849974 ∧ code e282796849974 = 1382308477750 := by decide
theorem cert_e282796849974 : check e282796849974 [[],[.under]] .smaller = true := by decide
def e282796849978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e282796849978 : Closed e282796849978 ∧ code e282796849978 = 1382308477754 := by decide
theorem cert_e282796849978 : check e282796849978 [[],[.under]] .smaller = true := by decide
def e282796850390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e282796850390 : Closed e282796850390 ∧ code e282796850390 = 1382308478166 := by decide
theorem cert_e282796850390 : check e282796850390 [[],[.under]] .three = true := by decide
def e282796850394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e282796850394 : Closed e282796850394 ∧ code e282796850394 = 1382308478170 := by decide
theorem cert_e282796850394 : check e282796850394 [[],[.under]] .three = true := by decide
def e282796850410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e282796850410 : Closed e282796850410 ∧ code e282796850410 = 1382308478186 := by decide
theorem cert_e282796850410 : check e282796850410 [[],[.under]] .three = true := by decide
def e282796850486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e282796850486 : Closed e282796850486 ∧ code e282796850486 = 1382308478262 := by decide
theorem cert_e282796850486 : check e282796850486 [[],[.under]] .three = true := by decide
def e282796850490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e282796850490 : Closed e282796850490 ∧ code e282796850490 = 1382308478266 := by decide
theorem cert_e282796850490 : check e282796850490 [[],[.under]] .three = true := by decide
def e282796850586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e282796850586 : Closed e282796850586 ∧ code e282796850586 = 1382308478362 := by decide
theorem cert_e282796850586 : check e282796850586 [[],[.under]] .three = true := by decide
def e282796857054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e282796857054 : Closed e282796857054 ∧ code e282796857054 = 1382308484830 := by decide
theorem cert_e282796857054 : check e282796857054 [[],[.under]] .three = true := by decide
def e282796857078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e282796857078 : Closed e282796857078 ∧ code e282796857078 = 1382308484854 := by decide
theorem cert_e282796857078 : check e282796857078 [[],[.under]] .three = true := by decide
def e282796857182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e282796857182 : Closed e282796857182 ∧ code e282796857182 = 1382308484958 := by decide
theorem cert_e282796857182 : check e282796857182 [[],[.under]] .three = true := by decide
def e282796857198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e282796857198 : Closed e282796857198 ∧ code e282796857198 = 1382308484974 := by decide
theorem cert_e282796857198 : check e282796857198 [[],[.under]] .smaller = true := by decide
def e282796857206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e282796857206 : Closed e282796857206 ∧ code e282796857206 = 1382308484982 := by decide
theorem cert_e282796857206 : check e282796857206 [[],[.under]] .smaller = true := by decide
def e282796857210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e282796857210 : Closed e282796857210 ∧ code e282796857210 = 1382308484986 := by decide
theorem cert_e282796857210 : check e282796857210 [[],[.under]] .three = true := by decide
def e282796857270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e282796857270 : Closed e282796857270 ∧ code e282796857270 = 1382308485046 := by decide
theorem cert_e282796857270 : check e282796857270 [[],[.under]] .smaller = true := by decide
def e282796857302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e282796857302 : Closed e282796857302 ∧ code e282796857302 = 1382308485078 := by decide
theorem cert_e282796857302 : check e282796857302 [[],[.under]] .three = true := by decide
def e282796857306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e282796857306 : Closed e282796857306 ∧ code e282796857306 = 1382308485082 := by decide
theorem cert_e282796857306 : check e282796857306 [[],[.under]] .three = true := by decide
def e282796857822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e282796857822 : Closed e282796857822 ∧ code e282796857822 = 1382308485598 := by decide
theorem cert_e282796857822 : check e282796857822 [[],[.under]] .three = true := by decide
def e282796857846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e282796857846 : Closed e282796857846 ∧ code e282796857846 = 1382308485622 := by decide
theorem cert_e282796857846 : check e282796857846 [[],[.under]] .three = true := by decide
def e282796858590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e282796858590 : Closed e282796858590 ∧ code e282796858590 = 1382308486366 := by decide
theorem cert_e282796858590 : check e282796858590 [[],[.under]] .three = true := by decide
def e282796858606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e282796858606 : Closed e282796858606 ∧ code e282796858606 = 1382308486382 := by decide
theorem cert_e282796858606 : check e282796858606 [[],[.under]] .smaller = true := by decide
def e282796858614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e282796858614 : Closed e282796858614 ∧ code e282796858614 = 1382308486390 := by decide
theorem cert_e282796858614 : check e282796858614 [[],[.under]] .smaller = true := by decide
def e282796858618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e282796858618 : Closed e282796858618 ∧ code e282796858618 = 1382308486394 := by decide
theorem cert_e282796858618 : check e282796858618 [[],[.under]] .three = true := by decide
def e282796858998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e282796858998 : Closed e282796858998 ∧ code e282796858998 = 1382308486774 := by decide
theorem cert_e282796858998 : check e282796858998 [[],[.under]] .smaller = true := by decide
def e282796859190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e282796859190 : Closed e282796859190 ∧ code e282796859190 = 1382308486966 := by decide
theorem cert_e282796859190 : check e282796859190 [[],[.under]] .three = true := by decide
def e282796859194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e282796859194 : Closed e282796859194 ∧ code e282796859194 = 1382308486970 := by decide
theorem cert_e282796859194 : check e282796859194 [[],[.under]] .three = true := by decide
def e282796870494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e282796870494 : Closed e282796870494 ∧ code e282796870494 = 1382308498270 := by decide
theorem cert_e282796870494 : check e282796870494 [[],[.under]] .three = true := by decide
def e282796870510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e282796870510 : Closed e282796870510 ∧ code e282796870510 = 1382308498286 := by decide
theorem cert_e282796870510 : check e282796870510 [[],[.under]] .smaller = true := by decide
def e282796870518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e282796870518 : Closed e282796870518 ∧ code e282796870518 = 1382308498294 := by decide
theorem cert_e282796870518 : check e282796870518 [[],[.under]] .smaller = true := by decide
def e282796870522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e282796870522 : Closed e282796870522 ∧ code e282796870522 = 1382308498298 := by decide
theorem cert_e282796870522 : check e282796870522 [[],[.under]] .three = true := by decide
def e282796870574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e282796870574 : Closed e282796870574 ∧ code e282796870574 = 1382308498350 := by decide
theorem cert_e282796870574 : check e282796870574 [[],[.under]] .smaller = true := by decide
def e282796870586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e282796870586 : Closed e282796870586 ∧ code e282796870586 = 1382308498362 := by decide
theorem cert_e282796870586 : check e282796870586 [[],[.under]] .smaller = true := by decide
def e282796870614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e282796870614 : Closed e282796870614 ∧ code e282796870614 = 1382308498390 := by decide
theorem cert_e282796870614 : check e282796870614 [[],[.under]] .smaller = true := by decide
def e282796870618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e282796870618 : Closed e282796870618 ∧ code e282796870618 = 1382308498394 := by decide
theorem cert_e282796870618 : check e282796870618 [[],[.under]] .smaller = true := by decide
def e282796870634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e282796870634 : Closed e282796870634 ∧ code e282796870634 = 1382308498410 := by decide
theorem cert_e282796870634 : check e282796870634 [[],[.under]] .three = true := by decide
def e282796870878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e282796870878 : Closed e282796870878 ∧ code e282796870878 = 1382308498654 := by decide
theorem cert_e282796870878 : check e282796870878 [[],[.under]] .three = true := by decide
def e282796870894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e282796870894 : Closed e282796870894 ∧ code e282796870894 = 1382308498670 := by decide
theorem cert_e282796870894 : check e282796870894 [[],[.under]] .smaller = true := by decide
def e282796870902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e282796870902 : Closed e282796870902 ∧ code e282796870902 = 1382308498678 := by decide
theorem cert_e282796870902 : check e282796870902 [[],[.under]] .smaller = true := by decide
def e282796870906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e282796870906 : Closed e282796870906 ∧ code e282796870906 = 1382308498682 := by decide
theorem cert_e282796870906 : check e282796870906 [[],[.under]] .three = true := by decide
def e282796871278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e282796871278 : Closed e282796871278 ∧ code e282796871278 = 1382308499054 := by decide
theorem cert_e282796871278 : check e282796871278 [[],[.under]] .smaller = true := by decide
def e282796871290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e282796871290 : Closed e282796871290 ∧ code e282796871290 = 1382308499066 := by decide
theorem cert_e282796871290 : check e282796871290 [[],[.under]] .smaller = true := by decide
def e282796871478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e282796871478 : Closed e282796871478 ∧ code e282796871478 = 1382308499254 := by decide
theorem cert_e282796871478 : check e282796871478 [[],[.under]] .smaller = true := by decide
def e282796871482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e282796871482 : Closed e282796871482 ∧ code e282796871482 = 1382308499258 := by decide
theorem cert_e282796871482 : check e282796871482 [[],[.under]] .smaller = true := by decide
def e282796871578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e282796871578 : Closed e282796871578 ∧ code e282796871578 = 1382308499354 := by decide
theorem cert_e282796871578 : check e282796871578 [[],[.under]] .three = true := by decide
def e282796877238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e282796877238 : Closed e282796877238 ∧ code e282796877238 = 1382308505014 := by decide
theorem cert_e282796877238 : check e282796877238 [[],[.under]] .smaller = true := by decide
def e282796877270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e282796877270 : Closed e282796877270 ∧ code e282796877270 = 1382308505046 := by decide
theorem cert_e282796877270 : check e282796877270 [[],[.under]] .smaller = true := by decide
def e282796877274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e282796877274 : Closed e282796877274 ∧ code e282796877274 = 1382308505050 := by decide
theorem cert_e282796877274 : check e282796877274 [[],[.under]] .smaller = true := by decide
def e282796877430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e282796877430 : Closed e282796877430 ∧ code e282796877430 = 1382308505206 := by decide
theorem cert_e282796877430 : check e282796877430 [[],[.under]] .smaller = true := by decide
def e282796877622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e282796877622 : Closed e282796877622 ∧ code e282796877622 = 1382308505398 := by decide
theorem cert_e282796877622 : check e282796877622 [[],[.under]] .smaller = true := by decide
def e282796877626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e282796877626 : Closed e282796877626 ∧ code e282796877626 = 1382308505402 := by decide
theorem cert_e282796877626 : check e282796877626 [[],[.under]] .smaller = true := by decide
def e282796880598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e282796880598 : Closed e282796880598 ∧ code e282796880598 = 1382308508374 := by decide
theorem cert_e282796880598 : check e282796880598 [[],[.under]] .three = true := by decide
def e282796880602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e282796880602 : Closed e282796880602 ∧ code e282796880602 = 1382308508378 := by decide
theorem cert_e282796880602 : check e282796880602 [[],[.under]] .three = true := by decide
def e282796880618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e282796880618 : Closed e282796880618 ∧ code e282796880618 = 1382308508394 := by decide
theorem cert_e282796880618 : check e282796880618 [[],[.under]] .three = true := by decide
def e282796880694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e282796880694 : Closed e282796880694 ∧ code e282796880694 = 1382308508470 := by decide
theorem cert_e282796880694 : check e282796880694 [[],[.under]] .three = true := by decide
def e282796880698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e282796880698 : Closed e282796880698 ∧ code e282796880698 = 1382308508474 := by decide
theorem cert_e282796880698 : check e282796880698 [[],[.under]] .three = true := by decide
def e282796880794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e282796880794 : Closed e282796880794 ∧ code e282796880794 = 1382308508570 := by decide
theorem cert_e282796880794 : check e282796880794 [[],[.under]] .three = true := by decide
def e282797106030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e282797106030 : Closed e282797106030 ∧ code e282797106030 = 1382308733806 := by decide
theorem cert_e282797106030 : check e282797106030 [[],[.under]] .three = true := by decide
def e282797106038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e282797106038 : Closed e282797106038 ∧ code e282797106038 = 1382308733814 := by decide
theorem cert_e282797106038 : check e282797106038 [[],[.under]] .three = true := by decide
def e282797106094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e282797106094 : Closed e282797106094 ∧ code e282797106094 = 1382308733870 := by decide
theorem cert_e282797106094 : check e282797106094 [[],[.under]] .three = true := by decide
def e282797106106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e282797106106 : Closed e282797106106 ∧ code e282797106106 = 1382308733882 := by decide
theorem cert_e282797106106 : check e282797106106 [[],[.under]] .three = true := by decide
end Blc.Floor40
