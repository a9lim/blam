import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e299171407834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e299171407834 : Closed e299171407834 ∧ code e299171407834 = 1398683035610 := by decide
theorem cert_e299171407834 : check e299171407834 [[],[.left],[]] .chain = true := by decide
def e299171408350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e299171408350 : Closed e299171408350 ∧ code e299171408350 = 1398683036126 := by decide
theorem cert_e299171408350 : check e299171408350 [[],[.left],[]] .chain = true := by decide
def e299171408374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e299171408374 : Closed e299171408374 ∧ code e299171408374 = 1398683036150 := by decide
theorem cert_e299171408374 : check e299171408374 [[],[.left],[]] .chain = true := by decide
def e299171409118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e299171409118 : Closed e299171409118 ∧ code e299171409118 = 1398683036894 := by decide
theorem cert_e299171409118 : check e299171409118 [[],[.left],[]] .chain = true := by decide
def e299171409134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e299171409134 : Closed e299171409134 ∧ code e299171409134 = 1398683036910 := by decide
theorem cert_e299171409134 : check e299171409134 [[],[.left],[]] .chain = true := by decide
def e299171409142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e299171409142 : Closed e299171409142 ∧ code e299171409142 = 1398683036918 := by decide
theorem cert_e299171409142 : check e299171409142 [[],[.left],[]] .chain = true := by decide
def e299171409146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e299171409146 : Closed e299171409146 ∧ code e299171409146 = 1398683036922 := by decide
theorem cert_e299171409146 : check e299171409146 [[],[.left],[]] .chain = true := by decide
def e299171409526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e299171409526 : Closed e299171409526 ∧ code e299171409526 = 1398683037302 := by decide
theorem cert_e299171409526 : check e299171409526 [[],[.left],[]] .chain = true := by decide
def e299171409718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e299171409718 : Closed e299171409718 ∧ code e299171409718 = 1398683037494 := by decide
theorem cert_e299171409718 : check e299171409718 [[],[.left],[]] .chain = true := by decide
def e299171409722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e299171409722 : Closed e299171409722 ∧ code e299171409722 = 1398683037498 := by decide
theorem cert_e299171409722 : check e299171409722 [[],[.left],[]] .chain = true := by decide
def e299171410782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e299171410782 : Closed e299171410782 ∧ code e299171410782 = 1398683038558 := by decide
theorem cert_e299171410782 : check e299171410782 [[],[.left],[]] .chain = true := by decide
def e299171410798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e299171410798 : Closed e299171410798 ∧ code e299171410798 = 1398683038574 := by decide
theorem cert_e299171410798 : check e299171410798 [[],[.left],[]] .chain = true := by decide
def e299171410806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e299171410806 : Closed e299171410806 ∧ code e299171410806 = 1398683038582 := by decide
theorem cert_e299171410806 : check e299171410806 [[],[.left],[]] .chain = true := by decide
def e299171410810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e299171410810 : Closed e299171410810 ∧ code e299171410810 = 1398683038586 := by decide
theorem cert_e299171410810 : check e299171410810 [[],[.left],[]] .chain = true := by decide
def e299171410862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e299171410862 : Closed e299171410862 ∧ code e299171410862 = 1398683038638 := by decide
theorem cert_e299171410862 : check e299171410862 [[],[.left],[]] .chain = true := by decide
def e299171410874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e299171410874 : Closed e299171410874 ∧ code e299171410874 = 1398683038650 := by decide
theorem cert_e299171410874 : check e299171410874 [[],[.left],[]] .chain = true := by decide
def e299171410902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e299171410902 : Closed e299171410902 ∧ code e299171410902 = 1398683038678 := by decide
theorem cert_e299171410902 : check e299171410902 [[],[.left],[]] .chain = true := by decide
def e299171410906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e299171410906 : Closed e299171410906 ∧ code e299171410906 = 1398683038682 := by decide
theorem cert_e299171410906 : check e299171410906 [[],[.left],[]] .chain = true := by decide
def e299171410922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e299171410922 : Closed e299171410922 ∧ code e299171410922 = 1398683038698 := by decide
theorem cert_e299171410922 : check e299171410922 [[],[.left],[]] .chain = true := by decide
def e299171411166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e299171411166 : Closed e299171411166 ∧ code e299171411166 = 1398683038942 := by decide
theorem cert_e299171411166 : check e299171411166 [[],[.left],[]] .chain = true := by decide
def e299171411182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e299171411182 : Closed e299171411182 ∧ code e299171411182 = 1398683038958 := by decide
theorem cert_e299171411182 : check e299171411182 [[],[.left],[]] .chain = true := by decide
def e299171411190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e299171411190 : Closed e299171411190 ∧ code e299171411190 = 1398683038966 := by decide
theorem cert_e299171411190 : check e299171411190 [[],[.left],[]] .chain = true := by decide
def e299171411194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e299171411194 : Closed e299171411194 ∧ code e299171411194 = 1398683038970 := by decide
theorem cert_e299171411194 : check e299171411194 [[],[.left],[]] .chain = true := by decide
def e299171411566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e299171411566 : Closed e299171411566 ∧ code e299171411566 = 1398683039342 := by decide
theorem cert_e299171411566 : check e299171411566 [[],[.left],[]] .chain = true := by decide
def e299171411578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e299171411578 : Closed e299171411578 ∧ code e299171411578 = 1398683039354 := by decide
theorem cert_e299171411578 : check e299171411578 [[],[.left],[]] .chain = true := by decide
def e299171411766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e299171411766 : Closed e299171411766 ∧ code e299171411766 = 1398683039542 := by decide
theorem cert_e299171411766 : check e299171411766 [[],[.left],[]] .chain = true := by decide
def e299171411770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e299171411770 : Closed e299171411770 ∧ code e299171411770 = 1398683039546 := by decide
theorem cert_e299171411770 : check e299171411770 [[],[.left],[]] .chain = true := by decide
def e299171411866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e299171411866 : Closed e299171411866 ∧ code e299171411866 = 1398683039642 := by decide
theorem cert_e299171411866 : check e299171411866 [[],[.left],[]] .chain = true := by decide
def e299171412406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e299171412406 : Closed e299171412406 ∧ code e299171412406 = 1398683040182 := by decide
theorem cert_e299171412406 : check e299171412406 [[],[.left],[]] .chain = true := by decide
def e299171412438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e299171412438 : Closed e299171412438 ∧ code e299171412438 = 1398683040214 := by decide
theorem cert_e299171412438 : check e299171412438 [[],[.left],[]] .chain = true := by decide
def e299171412442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e299171412442 : Closed e299171412442 ∧ code e299171412442 = 1398683040218 := by decide
theorem cert_e299171412442 : check e299171412442 [[],[.left],[]] .chain = true := by decide
def e299171412598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e299171412598 : Closed e299171412598 ∧ code e299171412598 = 1398683040374 := by decide
theorem cert_e299171412598 : check e299171412598 [[],[.left],[]] .chain = true := by decide
def e299171412790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e299171412790 : Closed e299171412790 ∧ code e299171412790 = 1398683040566 := by decide
theorem cert_e299171412790 : check e299171412790 [[],[.left],[]] .chain = true := by decide
def e299171412794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e299171412794 : Closed e299171412794 ∧ code e299171412794 = 1398683040570 := by decide
theorem cert_e299171412794 : check e299171412794 [[],[.left],[]] .chain = true := by decide
def e299171413206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e299171413206 : Closed e299171413206 ∧ code e299171413206 = 1398683040982 := by decide
theorem cert_e299171413206 : check e299171413206 [[],[.left],[]] .chain = true := by decide
def e299171413210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e299171413210 : Closed e299171413210 ∧ code e299171413210 = 1398683040986 := by decide
theorem cert_e299171413210 : check e299171413210 [[],[.left],[]] .chain = true := by decide
def e299171413226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e299171413226 : Closed e299171413226 ∧ code e299171413226 = 1398683041002 := by decide
theorem cert_e299171413226 : check e299171413226 [[],[.left],[]] .chain = true := by decide
def e299171413302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e299171413302 : Closed e299171413302 ∧ code e299171413302 = 1398683041078 := by decide
theorem cert_e299171413302 : check e299171413302 [[],[.left],[]] .chain = true := by decide
def e299171413306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e299171413306 : Closed e299171413306 ∧ code e299171413306 = 1398683041082 := by decide
theorem cert_e299171413306 : check e299171413306 [[],[.left],[]] .chain = true := by decide
def e299171413402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e299171413402 : Closed e299171413402 ∧ code e299171413402 = 1398683041178 := by decide
theorem cert_e299171413402 : check e299171413402 [[],[.left],[]] .chain = true := by decide
def e299171419870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e299171419870 : Closed e299171419870 ∧ code e299171419870 = 1398683047646 := by decide
theorem cert_e299171419870 : check e299171419870 [[],[.left],[]] .chain = true := by decide
def e299171419894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e299171419894 : Closed e299171419894 ∧ code e299171419894 = 1398683047670 := by decide
theorem cert_e299171419894 : check e299171419894 [[],[.left],[]] .chain = true := by decide
def e299171419998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e299171419998 : Closed e299171419998 ∧ code e299171419998 = 1398683047774 := by decide
theorem cert_e299171419998 : check e299171419998 [[],[.left],[]] .chain = true := by decide
def e299171420014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e299171420014 : Closed e299171420014 ∧ code e299171420014 = 1398683047790 := by decide
theorem cert_e299171420014 : check e299171420014 [[],[.left],[]] .chain = true := by decide
def e299171420022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e299171420022 : Closed e299171420022 ∧ code e299171420022 = 1398683047798 := by decide
theorem cert_e299171420022 : check e299171420022 [[],[.left],[]] .chain = true := by decide
def e299171420026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e299171420026 : Closed e299171420026 ∧ code e299171420026 = 1398683047802 := by decide
theorem cert_e299171420026 : check e299171420026 [[],[.left],[]] .chain = true := by decide
def e299171420086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e299171420086 : Closed e299171420086 ∧ code e299171420086 = 1398683047862 := by decide
theorem cert_e299171420086 : check e299171420086 [[],[.left],[]] .chain = true := by decide
def e299171420118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e299171420118 : Closed e299171420118 ∧ code e299171420118 = 1398683047894 := by decide
theorem cert_e299171420118 : check e299171420118 [[],[.left],[]] .chain = true := by decide
def e299171420122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e299171420122 : Closed e299171420122 ∧ code e299171420122 = 1398683047898 := by decide
theorem cert_e299171420122 : check e299171420122 [[],[.left],[]] .chain = true := by decide
def e299171420638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e299171420638 : Closed e299171420638 ∧ code e299171420638 = 1398683048414 := by decide
theorem cert_e299171420638 : check e299171420638 [[],[.left],[]] .chain = true := by decide
def e299171420662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e299171420662 : Closed e299171420662 ∧ code e299171420662 = 1398683048438 := by decide
theorem cert_e299171420662 : check e299171420662 [[],[.left],[]] .chain = true := by decide
def e299171421406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e299171421406 : Closed e299171421406 ∧ code e299171421406 = 1398683049182 := by decide
theorem cert_e299171421406 : check e299171421406 [[],[.left],[]] .chain = true := by decide
def e299171421422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e299171421422 : Closed e299171421422 ∧ code e299171421422 = 1398683049198 := by decide
theorem cert_e299171421422 : check e299171421422 [[],[.left],[]] .chain = true := by decide
def e299171421430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e299171421430 : Closed e299171421430 ∧ code e299171421430 = 1398683049206 := by decide
theorem cert_e299171421430 : check e299171421430 [[],[.left],[]] .chain = true := by decide
def e299171421434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e299171421434 : Closed e299171421434 ∧ code e299171421434 = 1398683049210 := by decide
theorem cert_e299171421434 : check e299171421434 [[],[.left],[]] .chain = true := by decide
def e299171421814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e299171421814 : Closed e299171421814 ∧ code e299171421814 = 1398683049590 := by decide
theorem cert_e299171421814 : check e299171421814 [[],[.left],[]] .chain = true := by decide
def e299171422006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e299171422006 : Closed e299171422006 ∧ code e299171422006 = 1398683049782 := by decide
theorem cert_e299171422006 : check e299171422006 [[],[.left],[]] .chain = true := by decide
def e299171422010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e299171422010 : Closed e299171422010 ∧ code e299171422010 = 1398683049786 := by decide
theorem cert_e299171422010 : check e299171422010 [[],[.left],[]] .chain = true := by decide
def e299171433310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e299171433310 : Closed e299171433310 ∧ code e299171433310 = 1398683061086 := by decide
theorem cert_e299171433310 : check e299171433310 [[],[.left],[]] .chain = true := by decide
def e299171433326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e299171433326 : Closed e299171433326 ∧ code e299171433326 = 1398683061102 := by decide
theorem cert_e299171433326 : check e299171433326 [[],[.left],[]] .chain = true := by decide
def e299171433334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e299171433334 : Closed e299171433334 ∧ code e299171433334 = 1398683061110 := by decide
theorem cert_e299171433334 : check e299171433334 [[],[.left],[]] .chain = true := by decide
def e299171433338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e299171433338 : Closed e299171433338 ∧ code e299171433338 = 1398683061114 := by decide
theorem cert_e299171433338 : check e299171433338 [[],[.left],[]] .chain = true := by decide
def e299171433390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e299171433390 : Closed e299171433390 ∧ code e299171433390 = 1398683061166 := by decide
theorem cert_e299171433390 : check e299171433390 [[],[.left],[]] .chain = true := by decide
def e299171433402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e299171433402 : Closed e299171433402 ∧ code e299171433402 = 1398683061178 := by decide
theorem cert_e299171433402 : check e299171433402 [[],[.left],[]] .chain = true := by decide
def e299171433430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e299171433430 : Closed e299171433430 ∧ code e299171433430 = 1398683061206 := by decide
theorem cert_e299171433430 : check e299171433430 [[],[.left],[]] .chain = true := by decide
def e299171433434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e299171433434 : Closed e299171433434 ∧ code e299171433434 = 1398683061210 := by decide
theorem cert_e299171433434 : check e299171433434 [[],[.left],[]] .chain = true := by decide
def e299171433450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e299171433450 : Closed e299171433450 ∧ code e299171433450 = 1398683061226 := by decide
theorem cert_e299171433450 : check e299171433450 [[],[.left],[]] .chain = true := by decide
def e299171433694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e299171433694 : Closed e299171433694 ∧ code e299171433694 = 1398683061470 := by decide
theorem cert_e299171433694 : check e299171433694 [[],[.left],[]] .chain = true := by decide
def e299171433710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e299171433710 : Closed e299171433710 ∧ code e299171433710 = 1398683061486 := by decide
theorem cert_e299171433710 : check e299171433710 [[],[.left],[]] .chain = true := by decide
def e299171433718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e299171433718 : Closed e299171433718 ∧ code e299171433718 = 1398683061494 := by decide
theorem cert_e299171433718 : check e299171433718 [[],[.left],[]] .chain = true := by decide
def e299171433722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e299171433722 : Closed e299171433722 ∧ code e299171433722 = 1398683061498 := by decide
theorem cert_e299171433722 : check e299171433722 [[],[.left],[]] .chain = true := by decide
def e299171434094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e299171434094 : Closed e299171434094 ∧ code e299171434094 = 1398683061870 := by decide
theorem cert_e299171434094 : check e299171434094 [[],[.left],[]] .chain = true := by decide
def e299171434106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e299171434106 : Closed e299171434106 ∧ code e299171434106 = 1398683061882 := by decide
theorem cert_e299171434106 : check e299171434106 [[],[.left],[]] .chain = true := by decide
def e299171434294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e299171434294 : Closed e299171434294 ∧ code e299171434294 = 1398683062070 := by decide
theorem cert_e299171434294 : check e299171434294 [[],[.left],[]] .chain = true := by decide
def e299171434298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e299171434298 : Closed e299171434298 ∧ code e299171434298 = 1398683062074 := by decide
theorem cert_e299171434298 : check e299171434298 [[],[.left],[]] .chain = true := by decide
def e299171434394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e299171434394 : Closed e299171434394 ∧ code e299171434394 = 1398683062170 := by decide
theorem cert_e299171434394 : check e299171434394 [[],[.left],[]] .chain = true := by decide
def e299171440054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e299171440054 : Closed e299171440054 ∧ code e299171440054 = 1398683067830 := by decide
theorem cert_e299171440054 : check e299171440054 [[],[.left],[]] .chain = true := by decide
def e299171440086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e299171440086 : Closed e299171440086 ∧ code e299171440086 = 1398683067862 := by decide
theorem cert_e299171440086 : check e299171440086 [[],[.left],[]] .chain = true := by decide
def e299171440090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e299171440090 : Closed e299171440090 ∧ code e299171440090 = 1398683067866 := by decide
theorem cert_e299171440090 : check e299171440090 [[],[.left],[]] .chain = true := by decide
def e299171440246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e299171440246 : Closed e299171440246 ∧ code e299171440246 = 1398683068022 := by decide
theorem cert_e299171440246 : check e299171440246 [[],[.left],[]] .chain = true := by decide
def e299171440438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e299171440438 : Closed e299171440438 ∧ code e299171440438 = 1398683068214 := by decide
theorem cert_e299171440438 : check e299171440438 [[],[.left],[]] .chain = true := by decide
def e299171440442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e299171440442 : Closed e299171440442 ∧ code e299171440442 = 1398683068218 := by decide
theorem cert_e299171440442 : check e299171440442 [[],[.left],[]] .chain = true := by decide
def e299171443414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e299171443414 : Closed e299171443414 ∧ code e299171443414 = 1398683071190 := by decide
theorem cert_e299171443414 : check e299171443414 [[],[.left],[]] .chain = true := by decide
def e299171443418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e299171443418 : Closed e299171443418 ∧ code e299171443418 = 1398683071194 := by decide
theorem cert_e299171443418 : check e299171443418 [[],[.left],[]] .chain = true := by decide
def e299171443434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e299171443434 : Closed e299171443434 ∧ code e299171443434 = 1398683071210 := by decide
theorem cert_e299171443434 : check e299171443434 [[],[.left],[]] .chain = true := by decide
def e299171443510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e299171443510 : Closed e299171443510 ∧ code e299171443510 = 1398683071286 := by decide
theorem cert_e299171443510 : check e299171443510 [[],[.left],[]] .chain = true := by decide
def e299171443514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e299171443514 : Closed e299171443514 ∧ code e299171443514 = 1398683071290 := by decide
theorem cert_e299171443514 : check e299171443514 [[],[.left],[]] .chain = true := by decide
def e299171443610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e299171443610 : Closed e299171443610 ∧ code e299171443610 = 1398683071386 := by decide
theorem cert_e299171443610 : check e299171443610 [[],[.left],[]] .chain = true := by decide
def e299171668846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e299171668846 : Closed e299171668846 ∧ code e299171668846 = 1398683296622 := by decide
theorem cert_e299171668846 : check e299171668846 [[],[.left],[]] .sourceHead = true := by decide
def e299171668854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e299171668854 : Closed e299171668854 ∧ code e299171668854 = 1398683296630 := by decide
theorem cert_e299171668854 : check e299171668854 [[],[.left],[]] .sourceHead = true := by decide
def e299171668910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e299171668910 : Closed e299171668910 ∧ code e299171668910 = 1398683296686 := by decide
theorem cert_e299171668910 : check e299171668910 [[],[.left],[]] .sourceHead = true := by decide
def e299171668922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e299171668922 : Closed e299171668922 ∧ code e299171668922 = 1398683296698 := by decide
theorem cert_e299171668922 : check e299171668922 [[],[.left],[]] .sourceHead = true := by decide
def e299171668950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e299171668950 : Closed e299171668950 ∧ code e299171668950 = 1398683296726 := by decide
theorem cert_e299171668950 : check e299171668950 [[],[.left],[]] .sourceHead = true := by decide
def e299171668954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e299171668954 : Closed e299171668954 ∧ code e299171668954 = 1398683296730 := by decide
theorem cert_e299171668954 : check e299171668954 [[],[.left],[]] .sourceHead = true := by decide
def e299171670254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e299171670254 : Closed e299171670254 ∧ code e299171670254 = 1398683298030 := by decide
theorem cert_e299171670254 : check e299171670254 [[],[.left],[]] .sourceHead = true := by decide
def e299171670262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e299171670262 : Closed e299171670262 ∧ code e299171670262 = 1398683298038 := by decide
theorem cert_e299171670262 : check e299171670262 [[],[.left],[]] .sourceHead = true := by decide
def e299171670814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e299171670814 : Closed e299171670814 ∧ code e299171670814 = 1398683298590 := by decide
theorem cert_e299171670814 : check e299171670814 [[],[.left],[]] .sourceHead = true := by decide
def e299171670926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e299171670926 : Closed e299171670926 ∧ code e299171670926 = 1398683298702 := by decide
theorem cert_e299171670926 : check e299171670926 [[],[.left],[]] .sourceHead = true := by decide
def e299171671150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e299171671150 : Closed e299171671150 ∧ code e299171671150 = 1398683298926 := by decide
theorem cert_e299171671150 : check e299171671150 [[],[.left],[]] .sourceHead = true := by decide
def e299171671162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e299171671162 : Closed e299171671162 ∧ code e299171671162 = 1398683298938 := by decide
theorem cert_e299171671162 : check e299171671162 [[],[.left],[]] .sourceHead = true := by decide
def e299171671326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e299171671326 : Closed e299171671326 ∧ code e299171671326 = 1398683299102 := by decide
theorem cert_e299171671326 : check e299171671326 [[],[.left],[]] .sourceHead = true := by decide
def e299171671494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e299171671494 : Closed e299171671494 ∧ code e299171671494 = 1398683299270 := by decide
theorem cert_e299171671494 : check e299171671494 [[],[.left],[]] .sourceHead = true := by decide
def e299171671606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e299171671606 : Closed e299171671606 ∧ code e299171671606 = 1398683299382 := by decide
theorem cert_e299171671606 : check e299171671606 [[],[.left],[]] .sourceHead = true := by decide
def e299171671610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e299171671610 : Closed e299171671610 ∧ code e299171671610 = 1398683299386 := by decide
theorem cert_e299171671610 : check e299171671610 [[],[.left],[]] .sourceHead = true := by decide
def e299171671694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e299171671694 : Closed e299171671694 ∧ code e299171671694 = 1398683299470 := by decide
theorem cert_e299171671694 : check e299171671694 [[],[.left],[]] .sourceHead = true := by decide
def e299171671750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e299171671750 : Closed e299171671750 ∧ code e299171671750 = 1398683299526 := by decide
theorem cert_e299171671750 : check e299171671750 [[],[.left],[]] .sourceHead = true := by decide
def e299171672494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e299171672494 : Closed e299171672494 ∧ code e299171672494 = 1398683300270 := by decide
theorem cert_e299171672494 : check e299171672494 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e299171672506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e299171672506 : Closed e299171672506 ∧ code e299171672506 = 1398683300282 := by decide
theorem cert_e299171672506 : check e299171672506 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e299171672554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e299171672554 : Closed e299171672554 ∧ code e299171672554 = 1398683300330 := by decide
theorem cert_e299171672554 : check e299171672554 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e299171673198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e299171673198 : Closed e299171673198 ∧ code e299171673198 = 1398683300974 := by decide
theorem cert_e299171673198 : check e299171673198 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .smaller = true := by decide
def e299171673210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e299171673210 : Closed e299171673210 ∧ code e299171673210 = 1398683300986 := by decide
theorem cert_e299171673210 : check e299171673210 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e299171673374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e299171673374 : Closed e299171673374 ∧ code e299171673374 = 1398683301150 := by decide
theorem cert_e299171673374 : check e299171673374 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e299171673542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e299171673542 : Closed e299171673542 ∧ code e299171673542 = 1398683301318 := by decide
theorem cert_e299171673542 : check e299171673542 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e299171673882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e299171673882 : Closed e299171673882 ∧ code e299171673882 = 1398683301658 := by decide
theorem cert_e299171673882 : check e299171673882 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e299171673926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e299171673926 : Closed e299171673926 ∧ code e299171673926 = 1398683301702 := by decide
theorem cert_e299171673926 : check e299171673926 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e299171674326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e299171674326 : Closed e299171674326 ∧ code e299171674326 = 1398683302102 := by decide
theorem cert_e299171674326 : check e299171674326 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .smaller = true := by decide
def e299171674330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e299171674330 : Closed e299171674330 ∧ code e299171674330 = 1398683302106 := by decide
theorem cert_e299171674330 : check e299171674330 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e299171674346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e299171674346 : Closed e299171674346 ∧ code e299171674346 = 1398683302122 := by decide
theorem cert_e299171674346 : check e299171674346 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e299171674678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e299171674678 : Closed e299171674678 ∧ code e299171674678 = 1398683302454 := by decide
theorem cert_e299171674678 : check e299171674678 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e299171674682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e299171674682 : Closed e299171674682 ∧ code e299171674682 = 1398683302458 := by decide
theorem cert_e299171674682 : check e299171674682 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e299171674766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e299171674766 : Closed e299171674766 ∧ code e299171674766 = 1398683302542 := by decide
theorem cert_e299171674766 : check e299171674766 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e299171674822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e299171674822 : Closed e299171674822 ∧ code e299171674822 = 1398683302598 := by decide
theorem cert_e299171674822 : check e299171674822 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e299171674906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e299171674906 : Closed e299171674906 ∧ code e299171674906 = 1398683302682 := by decide
theorem cert_e299171674906 : check e299171674906 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e299171674950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e299171674950 : Closed e299171674950 ∧ code e299171674950 = 1398683302726 := by decide
theorem cert_e299171674950 : check e299171674950 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e299171679470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e299171679470 : Closed e299171679470 ∧ code e299171679470 = 1398683307246 := by decide
theorem cert_e299171679470 : check e299171679470 [[],[.left],[]] .sourceHead = true := by decide
def e299171679478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e299171679478 : Closed e299171679478 ∧ code e299171679478 = 1398683307254 := by decide
theorem cert_e299171679478 : check e299171679478 [[],[.left],[]] .sourceHead = true := by decide
def e299171679854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e299171679854 : Closed e299171679854 ∧ code e299171679854 = 1398683307630 := by decide
theorem cert_e299171679854 : check e299171679854 [[],[.left],[]] .sourceHead = true := by decide
def e299171679866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e299171679866 : Closed e299171679866 ∧ code e299171679866 = 1398683307642 := by decide
theorem cert_e299171679866 : check e299171679866 [[],[.left],[]] .sourceHead = true := by decide
def e299171680054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e299171680054 : Closed e299171680054 ∧ code e299171680054 = 1398683307830 := by decide
theorem cert_e299171680054 : check e299171680054 [[],[.left],[]] .sourceHead = true := by decide
def e299171680058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e299171680058 : Closed e299171680058 ∧ code e299171680058 = 1398683307834 := by decide
theorem cert_e299171680058 : check e299171680058 [[],[.left],[]] .sourceHead = true := by decide
def e299171682542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e299171682542 : Closed e299171682542 ∧ code e299171682542 = 1398683310318 := by decide
theorem cert_e299171682542 : check e299171682542 [[],[.left],[]] .sourceHead = true := by decide
def e299171682550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e299171682550 : Closed e299171682550 ∧ code e299171682550 = 1398683310326 := by decide
theorem cert_e299171682550 : check e299171682550 [[],[.left],[]] .sourceHead = true := by decide
def e299171683102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e299171683102 : Closed e299171683102 ∧ code e299171683102 = 1398683310878 := by decide
theorem cert_e299171683102 : check e299171683102 [[],[.left],[]] .sourceHead = true := by decide
def e299171683214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e299171683214 : Closed e299171683214 ∧ code e299171683214 = 1398683310990 := by decide
theorem cert_e299171683214 : check e299171683214 [[],[.left],[]] .sourceHead = true := by decide
def e299171683438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e299171683438 : Closed e299171683438 ∧ code e299171683438 = 1398683311214 := by decide
theorem cert_e299171683438 : check e299171683438 [[],[.left],[]] .sourceHead = true := by decide
def e299171683450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e299171683450 : Closed e299171683450 ∧ code e299171683450 = 1398683311226 := by decide
theorem cert_e299171683450 : check e299171683450 [[],[.left],[]] .sourceHead = true := by decide
def e299171683614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e299171683614 : Closed e299171683614 ∧ code e299171683614 = 1398683311390 := by decide
theorem cert_e299171683614 : check e299171683614 [[],[.left],[]] .sourceHead = true := by decide
def e299171683782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e299171683782 : Closed e299171683782 ∧ code e299171683782 = 1398683311558 := by decide
theorem cert_e299171683782 : check e299171683782 [[],[.left],[]] .sourceHead = true := by decide
def e299171683894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e299171683894 : Closed e299171683894 ∧ code e299171683894 = 1398683311670 := by decide
theorem cert_e299171683894 : check e299171683894 [[],[.left],[]] .sourceHead = true := by decide
def e299171683898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e299171683898 : Closed e299171683898 ∧ code e299171683898 = 1398683311674 := by decide
theorem cert_e299171683898 : check e299171683898 [[],[.left],[]] .sourceHead = true := by decide
def e299171683982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e299171683982 : Closed e299171683982 ∧ code e299171683982 = 1398683311758 := by decide
theorem cert_e299171683982 : check e299171683982 [[],[.left],[]] .sourceHead = true := by decide
def e299171684038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e299171684038 : Closed e299171684038 ∧ code e299171684038 = 1398683311814 := by decide
theorem cert_e299171684038 : check e299171684038 [[],[.left],[]] .sourceHead = true := by decide
def e299171686174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e299171686174 : Closed e299171686174 ∧ code e299171686174 = 1398683313950 := by decide
theorem cert_e299171686174 : check e299171686174 [[],[.left],[]] .sourceHead = true := by decide
def e299171686286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e299171686286 : Closed e299171686286 ∧ code e299171686286 = 1398683314062 := by decide
theorem cert_e299171686286 : check e299171686286 [[],[.left],[]] .sourceHead = true := by decide
def e299171689246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e299171689246 : Closed e299171689246 ∧ code e299171689246 = 1398683317022 := by decide
theorem cert_e299171689246 : check e299171689246 [[],[.left],[]] .sourceHead = true := by decide
def e299171689414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e299171689414 : Closed e299171689414 ∧ code e299171689414 = 1398683317190 := by decide
theorem cert_e299171689414 : check e299171689414 [[],[.left],[]] .sourceHead = true := by decide
def e299171690894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e299171690894 : Closed e299171690894 ∧ code e299171690894 = 1398683318670 := by decide
theorem cert_e299171690894 : check e299171690894 [[],[.left],[]] .sourceHead = true := by decide
def e299171690950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e299171690950 : Closed e299171690950 ∧ code e299171690950 = 1398683318726 := by decide
theorem cert_e299171690950 : check e299171690950 [[],[.left],[]] .sourceHead = true := by decide
def e299171694190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e299171694190 : Closed e299171694190 ∧ code e299171694190 = 1398683321966 := by decide
theorem cert_e299171694190 : check e299171694190 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299171694202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e299171694202 : Closed e299171694202 ∧ code e299171694202 = 1398683321978 := by decide
theorem cert_e299171694202 : check e299171694202 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299171694490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e299171694490 : Closed e299171694490 ∧ code e299171694490 = 1398683322266 := by decide
theorem cert_e299171694490 : check e299171694490 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299171695726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e299171695726 : Closed e299171695726 ∧ code e299171695726 = 1398683323502 := by decide
theorem cert_e299171695726 : check e299171695726 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299171695738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e299171695738 : Closed e299171695738 ∧ code e299171695738 = 1398683323514 := by decide
theorem cert_e299171695738 : check e299171695738 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299171695902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e299171695902 : Closed e299171695902 ∧ code e299171695902 = 1398683323678 := by decide
theorem cert_e299171695902 : check e299171695902 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299171696070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e299171696070 : Closed e299171696070 ∧ code e299171696070 = 1398683323846 := by decide
theorem cert_e299171696070 : check e299171696070 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299171696410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e299171696410 : Closed e299171696410 ∧ code e299171696410 = 1398683324186 := by decide
theorem cert_e299171696410 : check e299171696410 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299171696454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e299171696454 : Closed e299171696454 ∧ code e299171696454 = 1398683324230 := by decide
theorem cert_e299171696454 : check e299171696454 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e299171697438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e299171697438 : Closed e299171697438 ∧ code e299171697438 = 1398683325214 := by decide
theorem cert_e299171697438 : check e299171697438 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299171697606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e299171697606 : Closed e299171697606 ∧ code e299171697606 = 1398683325382 := by decide
theorem cert_e299171697606 : check e299171697606 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e299171699910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e299171699910 : Closed e299171699910 ∧ code e299171699910 = 1398683327686 := by decide
theorem cert_e299171699910 : check e299171699910 [[],[.left],[],[.under,.left]] .chain = true := by decide
end Blc.Floor40
