import R302902178590Data
namespace Certgen.R302902178590
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem bl216 : FloorIndex.rangeOK validState 216 12 = true := by decide +kernel
theorem bl228 : FloorIndex.rangeOK validState 228 12 = true := by decide +kernel
theorem bl240 : FloorIndex.rangeOK validState 240 12 = true := by decide +kernel
theorem bl252 : FloorIndex.rangeOK validState 252 7 = true := by decide +kernel
end Certgen.R302902178590
