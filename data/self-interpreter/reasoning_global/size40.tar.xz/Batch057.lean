import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302820452214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e302820452214 : Closed e302820452214 ∧ code e302820452214 = 1402332079990 := by decide
theorem cert_e302820452214 : check e302820452214 [[],[]] .smaller = true := by decide
def e302820452218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e302820452218 : Closed e302820452218 ∧ code e302820452218 = 1402332079994 := by decide
theorem cert_e302820452218 : check e302820452218 [[],[]] .chain = true := by decide
def e302820452278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e302820452278 : Closed e302820452278 ∧ code e302820452278 = 1402332080054 := by decide
theorem cert_e302820452278 : check e302820452278 [[],[]] .smaller = true := by decide
def e302820452310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e302820452310 : Closed e302820452310 ∧ code e302820452310 = 1402332080086 := by decide
theorem cert_e302820452310 : check e302820452310 [[],[]] .chain = true := by decide
def e302820452314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e302820452314 : Closed e302820452314 ∧ code e302820452314 = 1402332080090 := by decide
theorem cert_e302820452314 : check e302820452314 [[],[]] .chain = true := by decide
def e302820452830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e302820452830 : Closed e302820452830 ∧ code e302820452830 = 1402332080606 := by decide
theorem cert_e302820452830 : check e302820452830 [[],[]] .chain = true := by decide
def e302820452854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e302820452854 : Closed e302820452854 ∧ code e302820452854 = 1402332080630 := by decide
theorem cert_e302820452854 : check e302820452854 [[],[]] .chain = true := by decide
def e302820453598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302820453598 : Closed e302820453598 ∧ code e302820453598 = 1402332081374 := by decide
theorem cert_e302820453598 : check e302820453598 [[],[]] .chain = true := by decide
def e302820453614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302820453614 : Closed e302820453614 ∧ code e302820453614 = 1402332081390 := by decide
theorem cert_e302820453614 : check e302820453614 [[],[]] .smaller = true := by decide
def e302820453622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302820453622 : Closed e302820453622 ∧ code e302820453622 = 1402332081398 := by decide
theorem cert_e302820453622 : check e302820453622 [[],[]] .smaller = true := by decide
def e302820453626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302820453626 : Closed e302820453626 ∧ code e302820453626 = 1402332081402 := by decide
theorem cert_e302820453626 : check e302820453626 [[],[]] .chain = true := by decide
def e302820453950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e302820453950 : Closed e302820453950 ∧ code e302820453950 = 1402332081726 := by decide
theorem cert_e302820453950 : check e302820453950 [[],[]] .chain = true := by decide
def e302820454006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e302820454006 : Closed e302820454006 ∧ code e302820454006 = 1402332081782 := by decide
theorem cert_e302820454006 : check e302820454006 [[],[]] .smaller = true := by decide
def e302820454174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e302820454174 : Closed e302820454174 ∧ code e302820454174 = 1402332081950 := by decide
theorem cert_e302820454174 : check e302820454174 [[],[]] .chain = true := by decide
def e302820454198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302820454198 : Closed e302820454198 ∧ code e302820454198 = 1402332081974 := by decide
theorem cert_e302820454198 : check e302820454198 [[],[]] .chain = true := by decide
def e302820454202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302820454202 : Closed e302820454202 ∧ code e302820454202 = 1402332081978 := by decide
theorem cert_e302820454202 : check e302820454202 [[],[]] .chain = true := by decide
def e302820455262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e302820455262 : Closed e302820455262 ∧ code e302820455262 = 1402332083038 := by decide
theorem cert_e302820455262 : check e302820455262 [[],[]] .chain = true := by decide
def e302820455278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e302820455278 : Closed e302820455278 ∧ code e302820455278 = 1402332083054 := by decide
theorem cert_e302820455278 : check e302820455278 [[],[]] .smaller = true := by decide
def e302820455286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e302820455286 : Closed e302820455286 ∧ code e302820455286 = 1402332083062 := by decide
theorem cert_e302820455286 : check e302820455286 [[],[]] .smaller = true := by decide
def e302820455290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e302820455290 : Closed e302820455290 ∧ code e302820455290 = 1402332083066 := by decide
theorem cert_e302820455290 : check e302820455290 [[],[]] .chain = true := by decide
def e302820455342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e302820455342 : Closed e302820455342 ∧ code e302820455342 = 1402332083118 := by decide
theorem cert_e302820455342 : check e302820455342 [[],[]] .smaller = true := by decide
def e302820455354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e302820455354 : Closed e302820455354 ∧ code e302820455354 = 1402332083130 := by decide
theorem cert_e302820455354 : check e302820455354 [[],[]] .smaller = true := by decide
def e302820455382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e302820455382 : Closed e302820455382 ∧ code e302820455382 = 1402332083158 := by decide
theorem cert_e302820455382 : check e302820455382 [[],[]] .smaller = true := by decide
def e302820455386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e302820455386 : Closed e302820455386 ∧ code e302820455386 = 1402332083162 := by decide
theorem cert_e302820455386 : check e302820455386 [[],[]] .smaller = true := by decide
def e302820455402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e302820455402 : Closed e302820455402 ∧ code e302820455402 = 1402332083178 := by decide
theorem cert_e302820455402 : check e302820455402 [[],[]] .chain = true := by decide
def e302820455646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e302820455646 : Closed e302820455646 ∧ code e302820455646 = 1402332083422 := by decide
theorem cert_e302820455646 : check e302820455646 [[],[]] .chain = true := by decide
def e302820455662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e302820455662 : Closed e302820455662 ∧ code e302820455662 = 1402332083438 := by decide
theorem cert_e302820455662 : check e302820455662 [[],[]] .smaller = true := by decide
def e302820455670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e302820455670 : Closed e302820455670 ∧ code e302820455670 = 1402332083446 := by decide
theorem cert_e302820455670 : check e302820455670 [[],[]] .smaller = true := by decide
def e302820455674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e302820455674 : Closed e302820455674 ∧ code e302820455674 = 1402332083450 := by decide
theorem cert_e302820455674 : check e302820455674 [[],[]] .chain = true := by decide
def e302820456046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e302820456046 : Closed e302820456046 ∧ code e302820456046 = 1402332083822 := by decide
theorem cert_e302820456046 : check e302820456046 [[],[]] .smaller = true := by decide
def e302820456058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e302820456058 : Closed e302820456058 ∧ code e302820456058 = 1402332083834 := by decide
theorem cert_e302820456058 : check e302820456058 [[],[]] .smaller = true := by decide
def e302820456246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302820456246 : Closed e302820456246 ∧ code e302820456246 = 1402332084022 := by decide
theorem cert_e302820456246 : check e302820456246 [[],[]] .smaller = true := by decide
def e302820456250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302820456250 : Closed e302820456250 ∧ code e302820456250 = 1402332084026 := by decide
theorem cert_e302820456250 : check e302820456250 [[],[]] .smaller = true := by decide
def e302820456346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302820456346 : Closed e302820456346 ∧ code e302820456346 = 1402332084122 := by decide
theorem cert_e302820456346 : check e302820456346 [[],[]] .chain = true := by decide
def e302820456670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 3))))))))
theorem wire_e302820456670 : Closed e302820456670 ∧ code e302820456670 = 1402332084446 := by decide
theorem cert_e302820456670 : check e302820456670 [[],[]] .chain = true := by decide
def e302820456698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 0))))))))
theorem wire_e302820456698 : Closed e302820456698 ∧ code e302820456698 = 1402332084474 := by decide
theorem cert_e302820456698 : check e302820456698 [[],[]] .chain = true := by decide
def e302820456886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e302820456886 : Closed e302820456886 ∧ code e302820456886 = 1402332084662 := by decide
theorem cert_e302820456886 : check e302820456886 [[],[]] .smaller = true := by decide
def e302820456918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e302820456918 : Closed e302820456918 ∧ code e302820456918 = 1402332084694 := by decide
theorem cert_e302820456918 : check e302820456918 [[],[]] .smaller = true := by decide
def e302820456922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e302820456922 : Closed e302820456922 ∧ code e302820456922 = 1402332084698 := by decide
theorem cert_e302820456922 : check e302820456922 [[],[]] .smaller = true := by decide
def e302820457022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e302820457022 : Closed e302820457022 ∧ code e302820457022 = 1402332084798 := by decide
theorem cert_e302820457022 : check e302820457022 [[],[]] .chain = true := by decide
def e302820457078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e302820457078 : Closed e302820457078 ∧ code e302820457078 = 1402332084854 := by decide
theorem cert_e302820457078 : check e302820457078 [[],[]] .smaller = true := by decide
def e302820457270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302820457270 : Closed e302820457270 ∧ code e302820457270 = 1402332085046 := by decide
theorem cert_e302820457270 : check e302820457270 [[],[]] .smaller = true := by decide
def e302820457274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302820457274 : Closed e302820457274 ∧ code e302820457274 = 1402332085050 := by decide
theorem cert_e302820457274 : check e302820457274 [[],[]] .smaller = true := by decide
def e302820457414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e302820457414 : Closed e302820457414 ∧ code e302820457414 = 1402332085190 := by decide
theorem cert_e302820457414 : check e302820457414 [[],[]] .chain = true := by decide
def e302820457582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 2))))))))
theorem wire_e302820457582 : Closed e302820457582 ∧ code e302820457582 = 1402332085358 := by decide
theorem cert_e302820457582 : check e302820457582 [[],[]] .chain = true := by decide
def e302820457594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 0))))))))
theorem wire_e302820457594 : Closed e302820457594 ∧ code e302820457594 = 1402332085370 := by decide
theorem cert_e302820457594 : check e302820457594 [[],[]] .chain = true := by decide
def e302820457686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e302820457686 : Closed e302820457686 ∧ code e302820457686 = 1402332085462 := by decide
theorem cert_e302820457686 : check e302820457686 [[],[]] .chain = true := by decide
def e302820457690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e302820457690 : Closed e302820457690 ∧ code e302820457690 = 1402332085466 := by decide
theorem cert_e302820457690 : check e302820457690 [[],[]] .chain = true := by decide
def e302820457706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e302820457706 : Closed e302820457706 ∧ code e302820457706 = 1402332085482 := by decide
theorem cert_e302820457706 : check e302820457706 [[],[]] .chain = true := by decide
def e302820457758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e302820457758 : Closed e302820457758 ∧ code e302820457758 = 1402332085534 := by decide
theorem cert_e302820457758 : check e302820457758 [[],[]] .chain = true := by decide
def e302820457782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e302820457782 : Closed e302820457782 ∧ code e302820457782 = 1402332085558 := by decide
theorem cert_e302820457782 : check e302820457782 [[],[]] .chain = true := by decide
def e302820457786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e302820457786 : Closed e302820457786 ∧ code e302820457786 = 1402332085562 := by decide
theorem cert_e302820457786 : check e302820457786 [[],[]] .chain = true := by decide
def e302820457882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e302820457882 : Closed e302820457882 ∧ code e302820457882 = 1402332085658 := by decide
theorem cert_e302820457882 : check e302820457882 [[],[]] .chain = true := by decide
def e302820457926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e302820457926 : Closed e302820457926 ∧ code e302820457926 = 1402332085702 := by decide
theorem cert_e302820457926 : check e302820457926 [[],[]] .chain = true := by decide
def e302820464350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e302820464350 : Closed e302820464350 ∧ code e302820464350 = 1402332092126 := by decide
theorem cert_e302820464350 : check e302820464350 [[],[]] .chain = true := by decide
def e302820464374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e302820464374 : Closed e302820464374 ∧ code e302820464374 = 1402332092150 := by decide
theorem cert_e302820464374 : check e302820464374 [[],[]] .chain = true := by decide
def e302820464478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e302820464478 : Closed e302820464478 ∧ code e302820464478 = 1402332092254 := by decide
theorem cert_e302820464478 : check e302820464478 [[],[]] .chain = true := by decide
def e302820464494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e302820464494 : Closed e302820464494 ∧ code e302820464494 = 1402332092270 := by decide
theorem cert_e302820464494 : check e302820464494 [[],[]] .smaller = true := by decide
def e302820464502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e302820464502 : Closed e302820464502 ∧ code e302820464502 = 1402332092278 := by decide
theorem cert_e302820464502 : check e302820464502 [[],[]] .smaller = true := by decide
def e302820464506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e302820464506 : Closed e302820464506 ∧ code e302820464506 = 1402332092282 := by decide
theorem cert_e302820464506 : check e302820464506 [[],[]] .chain = true := by decide
def e302820464566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e302820464566 : Closed e302820464566 ∧ code e302820464566 = 1402332092342 := by decide
theorem cert_e302820464566 : check e302820464566 [[],[]] .smaller = true := by decide
def e302820464598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e302820464598 : Closed e302820464598 ∧ code e302820464598 = 1402332092374 := by decide
theorem cert_e302820464598 : check e302820464598 [[],[]] .chain = true := by decide
def e302820464602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e302820464602 : Closed e302820464602 ∧ code e302820464602 = 1402332092378 := by decide
theorem cert_e302820464602 : check e302820464602 [[],[]] .chain = true := by decide
def e302820465118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e302820465118 : Closed e302820465118 ∧ code e302820465118 = 1402332092894 := by decide
theorem cert_e302820465118 : check e302820465118 [[],[]] .chain = true := by decide
def e302820465142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e302820465142 : Closed e302820465142 ∧ code e302820465142 = 1402332092918 := by decide
theorem cert_e302820465142 : check e302820465142 [[],[]] .chain = true := by decide
def e302820465886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e302820465886 : Closed e302820465886 ∧ code e302820465886 = 1402332093662 := by decide
theorem cert_e302820465886 : check e302820465886 [[],[]] .chain = true := by decide
def e302820465902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e302820465902 : Closed e302820465902 ∧ code e302820465902 = 1402332093678 := by decide
theorem cert_e302820465902 : check e302820465902 [[],[]] .smaller = true := by decide
def e302820465910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e302820465910 : Closed e302820465910 ∧ code e302820465910 = 1402332093686 := by decide
theorem cert_e302820465910 : check e302820465910 [[],[]] .smaller = true := by decide
def e302820465914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e302820465914 : Closed e302820465914 ∧ code e302820465914 = 1402332093690 := by decide
theorem cert_e302820465914 : check e302820465914 [[],[]] .chain = true := by decide
def e302820466238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e302820466238 : Closed e302820466238 ∧ code e302820466238 = 1402332094014 := by decide
theorem cert_e302820466238 : check e302820466238 [[],[]] .chain = true := by decide
def e302820466294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e302820466294 : Closed e302820466294 ∧ code e302820466294 = 1402332094070 := by decide
theorem cert_e302820466294 : check e302820466294 [[],[]] .smaller = true := by decide
def e302820466462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e302820466462 : Closed e302820466462 ∧ code e302820466462 = 1402332094238 := by decide
theorem cert_e302820466462 : check e302820466462 [[],[]] .chain = true := by decide
def e302820466486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e302820466486 : Closed e302820466486 ∧ code e302820466486 = 1402332094262 := by decide
theorem cert_e302820466486 : check e302820466486 [[],[]] .chain = true := by decide
def e302820466490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e302820466490 : Closed e302820466490 ∧ code e302820466490 = 1402332094266 := by decide
theorem cert_e302820466490 : check e302820466490 [[],[]] .chain = true := by decide
def e302820477790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e302820477790 : Closed e302820477790 ∧ code e302820477790 = 1402332105566 := by decide
theorem cert_e302820477790 : check e302820477790 [[],[]] .chain = true := by decide
def e302820477806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e302820477806 : Closed e302820477806 ∧ code e302820477806 = 1402332105582 := by decide
theorem cert_e302820477806 : check e302820477806 [[],[]] .smaller = true := by decide
def e302820477814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e302820477814 : Closed e302820477814 ∧ code e302820477814 = 1402332105590 := by decide
theorem cert_e302820477814 : check e302820477814 [[],[]] .smaller = true := by decide
def e302820477818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e302820477818 : Closed e302820477818 ∧ code e302820477818 = 1402332105594 := by decide
theorem cert_e302820477818 : check e302820477818 [[],[]] .chain = true := by decide
def e302820477870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e302820477870 : Closed e302820477870 ∧ code e302820477870 = 1402332105646 := by decide
theorem cert_e302820477870 : check e302820477870 [[],[]] .smaller = true := by decide
def e302820477882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e302820477882 : Closed e302820477882 ∧ code e302820477882 = 1402332105658 := by decide
theorem cert_e302820477882 : check e302820477882 [[],[]] .smaller = true := by decide
def e302820477910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e302820477910 : Closed e302820477910 ∧ code e302820477910 = 1402332105686 := by decide
theorem cert_e302820477910 : check e302820477910 [[],[]] .smaller = true := by decide
def e302820477914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e302820477914 : Closed e302820477914 ∧ code e302820477914 = 1402332105690 := by decide
theorem cert_e302820477914 : check e302820477914 [[],[]] .smaller = true := by decide
def e302820477930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e302820477930 : Closed e302820477930 ∧ code e302820477930 = 1402332105706 := by decide
theorem cert_e302820477930 : check e302820477930 [[],[]] .chain = true := by decide
def e302820478174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e302820478174 : Closed e302820478174 ∧ code e302820478174 = 1402332105950 := by decide
theorem cert_e302820478174 : check e302820478174 [[],[]] .chain = true := by decide
def e302820478190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e302820478190 : Closed e302820478190 ∧ code e302820478190 = 1402332105966 := by decide
theorem cert_e302820478190 : check e302820478190 [[],[]] .smaller = true := by decide
def e302820478198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e302820478198 : Closed e302820478198 ∧ code e302820478198 = 1402332105974 := by decide
theorem cert_e302820478198 : check e302820478198 [[],[]] .smaller = true := by decide
def e302820478202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e302820478202 : Closed e302820478202 ∧ code e302820478202 = 1402332105978 := by decide
theorem cert_e302820478202 : check e302820478202 [[],[]] .chain = true := by decide
def e302820478574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e302820478574 : Closed e302820478574 ∧ code e302820478574 = 1402332106350 := by decide
theorem cert_e302820478574 : check e302820478574 [[],[]] .smaller = true := by decide
def e302820478586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e302820478586 : Closed e302820478586 ∧ code e302820478586 = 1402332106362 := by decide
theorem cert_e302820478586 : check e302820478586 [[],[]] .smaller = true := by decide
def e302820478774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e302820478774 : Closed e302820478774 ∧ code e302820478774 = 1402332106550 := by decide
theorem cert_e302820478774 : check e302820478774 [[],[]] .smaller = true := by decide
def e302820478778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e302820478778 : Closed e302820478778 ∧ code e302820478778 = 1402332106554 := by decide
theorem cert_e302820478778 : check e302820478778 [[],[]] .smaller = true := by decide
def e302820478874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e302820478874 : Closed e302820478874 ∧ code e302820478874 = 1402332106650 := by decide
theorem cert_e302820478874 : check e302820478874 [[],[]] .chain = true := by decide
def e302820484534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e302820484534 : Closed e302820484534 ∧ code e302820484534 = 1402332112310 := by decide
theorem cert_e302820484534 : check e302820484534 [[],[]] .smaller = true := by decide
def e302820484566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e302820484566 : Closed e302820484566 ∧ code e302820484566 = 1402332112342 := by decide
theorem cert_e302820484566 : check e302820484566 [[],[]] .smaller = true := by decide
def e302820484570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e302820484570 : Closed e302820484570 ∧ code e302820484570 = 1402332112346 := by decide
theorem cert_e302820484570 : check e302820484570 [[],[]] .smaller = true := by decide
def e302820484670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e302820484670 : Closed e302820484670 ∧ code e302820484670 = 1402332112446 := by decide
theorem cert_e302820484670 : check e302820484670 [[],[]] .chain = true := by decide
def e302820484726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e302820484726 : Closed e302820484726 ∧ code e302820484726 = 1402332112502 := by decide
theorem cert_e302820484726 : check e302820484726 [[],[]] .smaller = true := by decide
def e302820484918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e302820484918 : Closed e302820484918 ∧ code e302820484918 = 1402332112694 := by decide
theorem cert_e302820484918 : check e302820484918 [[],[]] .smaller = true := by decide
def e302820484922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e302820484922 : Closed e302820484922 ∧ code e302820484922 = 1402332112698 := by decide
theorem cert_e302820484922 : check e302820484922 [[],[]] .smaller = true := by decide
def e302820485062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e302820485062 : Closed e302820485062 ∧ code e302820485062 = 1402332112838 := by decide
theorem cert_e302820485062 : check e302820485062 [[],[]] .chain = true := by decide
def e302820487894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e302820487894 : Closed e302820487894 ∧ code e302820487894 = 1402332115670 := by decide
theorem cert_e302820487894 : check e302820487894 [[],[]] .chain = true := by decide
def e302820487898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e302820487898 : Closed e302820487898 ∧ code e302820487898 = 1402332115674 := by decide
theorem cert_e302820487898 : check e302820487898 [[],[]] .chain = true := by decide
def e302820487914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e302820487914 : Closed e302820487914 ∧ code e302820487914 = 1402332115690 := by decide
theorem cert_e302820487914 : check e302820487914 [[],[]] .chain = true := by decide
def e302820487966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e302820487966 : Closed e302820487966 ∧ code e302820487966 = 1402332115742 := by decide
theorem cert_e302820487966 : check e302820487966 [[],[]] .chain = true := by decide
def e302820487990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e302820487990 : Closed e302820487990 ∧ code e302820487990 = 1402332115766 := by decide
theorem cert_e302820487990 : check e302820487990 [[],[]] .chain = true := by decide
def e302820487994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e302820487994 : Closed e302820487994 ∧ code e302820487994 = 1402332115770 := by decide
theorem cert_e302820487994 : check e302820487994 [[],[]] .chain = true := by decide
def e302820488090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e302820488090 : Closed e302820488090 ∧ code e302820488090 = 1402332115866 := by decide
theorem cert_e302820488090 : check e302820488090 [[],[]] .chain = true := by decide
def e302820488134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e302820488134 : Closed e302820488134 ∧ code e302820488134 = 1402332115910 := by decide
theorem cert_e302820488134 : check e302820488134 [[],[]] .chain = true := by decide
def e302820713326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e302820713326 : Closed e302820713326 ∧ code e302820713326 = 1402332341102 := by decide
theorem cert_e302820713326 : check e302820713326 [[],[]] .chain = true := by decide
def e302820713334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e302820713334 : Closed e302820713334 ∧ code e302820713334 = 1402332341110 := by decide
theorem cert_e302820713334 : check e302820713334 [[],[]] .chain = true := by decide
def e302820713390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e302820713390 : Closed e302820713390 ∧ code e302820713390 = 1402332341166 := by decide
theorem cert_e302820713390 : check e302820713390 [[],[]] .chain = true := by decide
def e302820713402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e302820713402 : Closed e302820713402 ∧ code e302820713402 = 1402332341178 := by decide
theorem cert_e302820713402 : check e302820713402 [[],[]] .chain = true := by decide
def e302820713430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e302820713430 : Closed e302820713430 ∧ code e302820713430 = 1402332341206 := by decide
theorem cert_e302820713430 : check e302820713430 [[],[]] .chain = true := by decide
def e302820713434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e302820713434 : Closed e302820713434 ∧ code e302820713434 = 1402332341210 := by decide
theorem cert_e302820713434 : check e302820713434 [[],[]] .chain = true := by decide
def e302820714734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e302820714734 : Closed e302820714734 ∧ code e302820714734 = 1402332342510 := by decide
theorem cert_e302820714734 : check e302820714734 [[],[]] .chain = true := by decide
def e302820714742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e302820714742 : Closed e302820714742 ∧ code e302820714742 = 1402332342518 := by decide
theorem cert_e302820714742 : check e302820714742 [[],[]] .chain = true := by decide
def e302820715294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e302820715294 : Closed e302820715294 ∧ code e302820715294 = 1402332343070 := by decide
theorem cert_e302820715294 : check e302820715294 [[],[]] .chain = true := by decide
def e302820715406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e302820715406 : Closed e302820715406 ∧ code e302820715406 = 1402332343182 := by decide
theorem cert_e302820715406 : check e302820715406 [[],[]] .chain = true := by decide
def e302820715630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302820715630 : Closed e302820715630 ∧ code e302820715630 = 1402332343406 := by decide
theorem cert_e302820715630 : check e302820715630 [[],[]] .chain = true := by decide
def e302820715642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302820715642 : Closed e302820715642 ∧ code e302820715642 = 1402332343418 := by decide
theorem cert_e302820715642 : check e302820715642 [[],[]] .chain = true := by decide
def e302820715806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302820715806 : Closed e302820715806 ∧ code e302820715806 = 1402332343582 := by decide
theorem cert_e302820715806 : check e302820715806 [[],[]] .chain = true := by decide
def e302820715974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302820715974 : Closed e302820715974 ∧ code e302820715974 = 1402332343750 := by decide
theorem cert_e302820715974 : check e302820715974 [[],[]] .chain = true := by decide
def e302820716086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302820716086 : Closed e302820716086 ∧ code e302820716086 = 1402332343862 := by decide
theorem cert_e302820716086 : check e302820716086 [[],[]] .chain = true := by decide
def e302820716090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302820716090 : Closed e302820716090 ∧ code e302820716090 = 1402332343866 := by decide
theorem cert_e302820716090 : check e302820716090 [[],[]] .chain = true := by decide
def e302820716174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302820716174 : Closed e302820716174 ∧ code e302820716174 = 1402332343950 := by decide
theorem cert_e302820716174 : check e302820716174 [[],[]] .chain = true := by decide
def e302820716230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302820716230 : Closed e302820716230 ∧ code e302820716230 = 1402332344006 := by decide
theorem cert_e302820716230 : check e302820716230 [[],[]] .chain = true := by decide
def e302820716974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e302820716974 : Closed e302820716974 ∧ code e302820716974 = 1402332344750 := by decide
theorem cert_e302820716974 : check e302820716974 [[],[]] .chain = true := by decide
def e302820716986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e302820716986 : Closed e302820716986 ∧ code e302820716986 = 1402332344762 := by decide
theorem cert_e302820716986 : check e302820716986 [[],[]] .chain = true := by decide
def e302820717034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e302820717034 : Closed e302820717034 ∧ code e302820717034 = 1402332344810 := by decide
theorem cert_e302820717034 : check e302820717034 [[],[]] .chain = true := by decide
def e302820717678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302820717678 : Closed e302820717678 ∧ code e302820717678 = 1402332345454 := by decide
theorem cert_e302820717678 : check e302820717678 [[],[]] .chain = true := by decide
def e302820717690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302820717690 : Closed e302820717690 ∧ code e302820717690 = 1402332345466 := by decide
theorem cert_e302820717690 : check e302820717690 [[],[]] .chain = true := by decide
def e302820717854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302820717854 : Closed e302820717854 ∧ code e302820717854 = 1402332345630 := by decide
theorem cert_e302820717854 : check e302820717854 [[],[]] .chain = true := by decide
def e302820718022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302820718022 : Closed e302820718022 ∧ code e302820718022 = 1402332345798 := by decide
theorem cert_e302820718022 : check e302820718022 [[],[]] .chain = true := by decide
def e302820718362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302820718362 : Closed e302820718362 ∧ code e302820718362 = 1402332346138 := by decide
theorem cert_e302820718362 : check e302820718362 [[],[]] .chain = true := by decide
def e302820718406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302820718406 : Closed e302820718406 ∧ code e302820718406 = 1402332346182 := by decide
theorem cert_e302820718406 : check e302820718406 [[],[]] .chain = true := by decide
def e302820718806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e302820718806 : Closed e302820718806 ∧ code e302820718806 = 1402332346582 := by decide
theorem cert_e302820718806 : check e302820718806 [[],[]] .chain = true := by decide
def e302820718810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e302820718810 : Closed e302820718810 ∧ code e302820718810 = 1402332346586 := by decide
theorem cert_e302820718810 : check e302820718810 [[],[]] .chain = true := by decide
def e302820718826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e302820718826 : Closed e302820718826 ∧ code e302820718826 = 1402332346602 := by decide
theorem cert_e302820718826 : check e302820718826 [[],[]] .chain = true := by decide
def e302820719158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e302820719158 : Closed e302820719158 ∧ code e302820719158 = 1402332346934 := by decide
theorem cert_e302820719158 : check e302820719158 [[],[]] .chain = true := by decide
def e302820719162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e302820719162 : Closed e302820719162 ∧ code e302820719162 = 1402332346938 := by decide
theorem cert_e302820719162 : check e302820719162 [[],[]] .chain = true := by decide
def e302820719246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e302820719246 : Closed e302820719246 ∧ code e302820719246 = 1402332347022 := by decide
theorem cert_e302820719246 : check e302820719246 [[],[]] .chain = true := by decide
def e302820719302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e302820719302 : Closed e302820719302 ∧ code e302820719302 = 1402332347078 := by decide
theorem cert_e302820719302 : check e302820719302 [[],[]] .chain = true := by decide
def e302820719386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302820719386 : Closed e302820719386 ∧ code e302820719386 = 1402332347162 := by decide
theorem cert_e302820719386 : check e302820719386 [[],[]] .chain = true := by decide
def e302820719430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e302820719430 : Closed e302820719430 ∧ code e302820719430 = 1402332347206 := by decide
theorem cert_e302820719430 : check e302820719430 [[],[]] .chain = true := by decide
def e302820722414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e302820722414 : Closed e302820722414 ∧ code e302820722414 = 1402332350190 := by decide
theorem cert_e302820722414 : check e302820722414 [[],[]] .chain = true := by decide
def e302820722422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e302820722422 : Closed e302820722422 ∧ code e302820722422 = 1402332350198 := by decide
theorem cert_e302820722422 : check e302820722422 [[],[]] .chain = true := by decide
def e302820722606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e302820722606 : Closed e302820722606 ∧ code e302820722606 = 1402332350382 := by decide
theorem cert_e302820722606 : check e302820722606 [[],[]] .chain = true := by decide
def e302820722646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e302820722646 : Closed e302820722646 ∧ code e302820722646 = 1402332350422 := by decide
theorem cert_e302820722646 : check e302820722646 [[],[]] .chain = true := by decide
def e302820723950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e302820723950 : Closed e302820723950 ∧ code e302820723950 = 1402332351726 := by decide
theorem cert_e302820723950 : check e302820723950 [[],[]] .chain = true := by decide
def e302820723958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e302820723958 : Closed e302820723958 ∧ code e302820723958 = 1402332351734 := by decide
theorem cert_e302820723958 : check e302820723958 [[],[]] .chain = true := by decide
def e302820724334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e302820724334 : Closed e302820724334 ∧ code e302820724334 = 1402332352110 := by decide
theorem cert_e302820724334 : check e302820724334 [[],[]] .chain = true := by decide
def e302820724346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e302820724346 : Closed e302820724346 ∧ code e302820724346 = 1402332352122 := by decide
theorem cert_e302820724346 : check e302820724346 [[],[]] .chain = true := by decide
def e302820724534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e302820724534 : Closed e302820724534 ∧ code e302820724534 = 1402332352310 := by decide
theorem cert_e302820724534 : check e302820724534 [[],[]] .chain = true := by decide
def e302820724538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e302820724538 : Closed e302820724538 ∧ code e302820724538 = 1402332352314 := by decide
theorem cert_e302820724538 : check e302820724538 [[],[]] .chain = true := by decide
def e302820727022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e302820727022 : Closed e302820727022 ∧ code e302820727022 = 1402332354798 := by decide
theorem cert_e302820727022 : check e302820727022 [[],[]] .chain = true := by decide
def e302820727030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e302820727030 : Closed e302820727030 ∧ code e302820727030 = 1402332354806 := by decide
theorem cert_e302820727030 : check e302820727030 [[],[]] .chain = true := by decide
def e302820727582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e302820727582 : Closed e302820727582 ∧ code e302820727582 = 1402332355358 := by decide
theorem cert_e302820727582 : check e302820727582 [[],[]] .chain = true := by decide
def e302820727694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e302820727694 : Closed e302820727694 ∧ code e302820727694 = 1402332355470 := by decide
theorem cert_e302820727694 : check e302820727694 [[],[]] .chain = true := by decide
def e302820727918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e302820727918 : Closed e302820727918 ∧ code e302820727918 = 1402332355694 := by decide
theorem cert_e302820727918 : check e302820727918 [[],[]] .chain = true := by decide
def e302820727930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e302820727930 : Closed e302820727930 ∧ code e302820727930 = 1402332355706 := by decide
theorem cert_e302820727930 : check e302820727930 [[],[]] .chain = true := by decide
end Blc.Floor40
