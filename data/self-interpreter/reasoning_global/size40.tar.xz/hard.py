from regular40 import *
from searchprobes import configs,probe,target_steps
from smart_probe import simp_path,apps_spine
from random import Random
def variant(t,choice):
    if choice==0:return weak_path(t)
    if choice==1:
        p=simp_path(t)
        if p is not None:return p
        return weak_path(t)
    if choice==2:
        p=weak_path(t)
        if p is None:return None
        ap=simp_path(at(t,p+['right']))
        return p+['right']+ap if ap is not None else p
    raise AssertionError()
def candidates(s):
    e=lc.decode(s)[0];seen=set();terms=[]
    # The first unspecialized raw source and arbitrary opaque actual parameters.
    for tail in [[],[V(0)],[V(0),V(1)],[V(0),V(1),V(2)]]:
        t=e
        for a in tail:t=A(t,a)
        terms.append((t,('rigids',len(tail))))
    opts=list(configs());Random(410).shuffle(opts)
    # Fast targeted useful selectors. Correct targets checked independently.
    for x in [L(A(V(0),om)),L(A(A(V(0),om),om)),L(L(A(A(V(1),om),V(0)))),L(L(A(V(1),V(0)))),C,KI]:
        for n in [0,1,2,3,4]:
            for m in [I,KI]:
                aa=[om]*n
                for r in [R,L(om),om]:
                    k=target_steps(x,m,r,aa)
                    if k is not None:opts.insert(0,(x,m,r,aa,k))
    for c,m,r,aa,k in opts:
        t=probe(e,c,m,r,aa)
        terms.append((t,('probe',[lc.enc(x) for x in [c,m,r]],[lc.enc(x) for x in aa])))
    for t,mode in terms:
        if t in seen:continue
        seen.add(t)
        yield t,mode
def one(s,budget):
    start=__import__('time').monotonic(); tested=set();ntry=0
    for n,(q,typ) in enumerate(candidates(s)):
        if __import__('time').monotonic()-start>budget:return n,ntry
        if n>15 and n%3:continue
        for style in [1,0,2]:
            t=q;ps=[]
            for j in range(41):
                if j in (0,1,2,4,8,12,16,24,32,40) and t not in tested:
                    tested.add(t)
                    for k,alloc in [(0,'site'),(1,'argenv'),(2,'site'),(3,'arg'),(2,'env'),(3,'argenv'),(4,'env'),(4,'argenv')]:
                        ntry+=1
                        try:z=regular.discover(mask(t),k,cap=7000,seconds=.10,mode=alloc)
                        except regular.Limit:continue
                        if z['ok'] and z['states']<=2000:
                            c=portable.portable(z)
                            data=[len(c['states']),typ,j,k,alloc,ps,c]
                            (HERE/('h'+str(int(s,2))+'.json')).write_text(json.dumps(data))
                            return n,ntry,data[:5]
                p=variant(t,style)
                if p is None:break
                t=bounded(t,p)
                if t is None:break
                ps=ps+[p]
    return n,ntry
if __name__=='__main__':
    for s in open('open.txt').read().split():
        f=HERE/('r'+str(int(s,2))+'.json')
        if (HERE/('h'+str(int(s,2))+'.json')).exists() or f.exists() and json.loads(f.read_text())[1]!='bottom1':continue
        print(s,one(s,26),flush=True)
