import R302824803246Blk0
import R302824803246Blk6
namespace Certgen.R302824803246
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def terms : Array Term := #[(.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))) (.lam (.var 0))),(.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))),(.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))))))),(.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.var 1)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0),(.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))),(.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))),(.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))),(.var 1),(.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))),(.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))),(.var 2),(.app (.app (.var 1) (.var 0)) (.var 2)),(.app (.var 1) (.var 0)),(.var 1),(.var 0),(.var 2),(.lam (.lam (.var 1))),(.lam (.var 1)),(.var 1),(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))))))),(.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))))),(.app (.var 0) (.lam (.lam (.var 1)))),(.var 0),(.lam (.lam (.var 1))),(.lam (.var 1)),(.var 1),(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))))),(.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))),(.app (.var 0) (.lam (.lam (.var 1)))),(.var 0),(.lam (.lam (.var 1))),(.lam (.var 1)),(.var 1),(.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))),(.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))),(.app (.var 0) (.lam (.lam (.var 0)))),(.var 0),(.lam (.lam (.var 0))),(.lam (.var 0)),(.var 0),(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))),(.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))),(.app (.var 0) (.lam (.lam (.var 1)))),(.var 0),(.lam (.lam (.var 1))),(.lam (.var 1)),(.var 1),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0),(.lam (.var 0)),(.var 0)]
def termAt (p : Nat) : Term := terms[p]?.getD (.var 0)
def aligns (p : Nat) : Bool := match P p with
 | .opaque => true
 | .var i => decide (termAt p = Term.var i)
 | .lam b => decide (termAt p = Term.lam (termAt b))
 | .app f a => decide (termAt p = Term.app (termAt f) (termAt a))
theorem valid : (List.range code.size).all aligns = true := by decide
theorem every (p : Nat) : aligns p = true := by
 by_cases hp : p < code.size
 · exact List.all_eq_true.mp valid p (List.mem_range.mpr hp)
 · have hz : code[p]? = none := Array.getElem?_eq_none (by omega)
   simp [aligns,P,hz]
def model : Model P where
 term := termAt
 var_eq := by intro p i h; simpa [aligns,h] using every p
 lam_eq := by intro p b h; simpa [aligns,h] using every p
 app_eq := by intro p f a h; simpa [aligns,h] using every p
theorem allValid (i : Nat) (h : i < 132) : validState i = true := by
 by_cases h60 : i < 60
 · by_cases h24 : i < 24
   · by_cases h12 : i < 12
     · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
   · by_cases h36 : i < 36
     · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
     · by_cases h48 : i < 48
       · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
 · by_cases h96 : i < 96
   · by_cases h72 : i < 72
     · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
     · by_cases h84 : i < 84
       · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
   · by_cases h108 : i < 108
     · exact FloorIndex.rangeOK_at bl96 (by omega) (by omega)
     · by_cases h120 : i < 120
       · exact FloorIndex.rangeOK_at bl108 (by omega) (by omega)
       · exact FloorIndex.rangeOK_at bl120 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 132
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e302824803246 := by
 intro he
 have hp : replay [] (call e302824803246 (.lam (.lam (.var 1))) (.lam (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.lam (.var 0))]) = some (model.term 0) := by decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 4) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R302824803246
