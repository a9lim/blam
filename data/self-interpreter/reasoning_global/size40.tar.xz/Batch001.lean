import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e74843360214 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e74843360214 : Closed e74843360214 ∧ code e74843360214 = 1174354987990 := by decide
theorem cert_e74843360214 : check e74843360214 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e74843360218 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e74843360218 : Closed e74843360218 ∧ code e74843360218 = 1174354987994 := by decide
theorem cert_e74843360218 : check e74843360218 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e74843360494 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e74843360494 : Closed e74843360494 ∧ code e74843360494 = 1174354988270 := by decide
theorem cert_e74843360494 : check e74843360494 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e74843360502 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e74843360502 : Closed e74843360502 ∧ code e74843360502 = 1174354988278 := by decide
theorem cert_e74843360502 : check e74843360502 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e74843360878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e74843360878 : Closed e74843360878 ∧ code e74843360878 = 1174354988654 := by decide
theorem cert_e74843360878 : check e74843360878 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e74843360890 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e74843360890 : Closed e74843360890 ∧ code e74843360890 = 1174354988666 := by decide
theorem cert_e74843360890 : check e74843360890 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e74843361078 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e74843361078 : Closed e74843361078 ∧ code e74843361078 = 1174354988854 := by decide
theorem cert_e74843361078 : check e74843361078 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e74843361082 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e74843361082 : Closed e74843361082 ∧ code e74843361082 = 1174354988858 := by decide
theorem cert_e74843361082 : check e74843361082 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e74843949934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e74843949934 : Closed e74843949934 ∧ code e74843949934 = 1174355577710 := by decide
theorem cert_e74843949934 : check e74843949934 [[.under],[.under,.left]] .chain = true := by decide
def e74843949942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e74843949942 : Closed e74843949942 ∧ code e74843949942 = 1174355577718 := by decide
theorem cert_e74843949942 : check e74843949942 [[.under],[.under,.left]] .chain = true := by decide
def e74843949998 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e74843949998 : Closed e74843949998 ∧ code e74843949998 = 1174355577774 := by decide
theorem cert_e74843949998 : check e74843949998 [[.under],[.under,.left]] .chain = true := by decide
def e74843950010 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e74843950010 : Closed e74843950010 ∧ code e74843950010 = 1174355577786 := by decide
theorem cert_e74843950010 : check e74843950010 [[.under],[.under,.left]] .chain = true := by decide
def e74843950038 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e74843950038 : Closed e74843950038 ∧ code e74843950038 = 1174355577814 := by decide
theorem cert_e74843950038 : check e74843950038 [[.under],[.under,.left]] .chain = true := by decide
def e74843950042 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e74843950042 : Closed e74843950042 ∧ code e74843950042 = 1174355577818 := by decide
theorem cert_e74843950042 : check e74843950042 [[.under],[.under,.left]] .chain = true := by decide
def e74843950318 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e74843950318 : Closed e74843950318 ∧ code e74843950318 = 1174355578094 := by decide
theorem cert_e74843950318 : check e74843950318 [[.under],[.under,.left]] .chain = true := by decide
def e74843950326 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e74843950326 : Closed e74843950326 ∧ code e74843950326 = 1174355578102 := by decide
theorem cert_e74843950326 : check e74843950326 [[.under],[.under,.left]] .chain = true := by decide
def e74843950702 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e74843950702 : Closed e74843950702 ∧ code e74843950702 = 1174355578478 := by decide
theorem cert_e74843950702 : check e74843950702 [[.under],[.under,.left]] .chain = true := by decide
def e74843950714 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e74843950714 : Closed e74843950714 ∧ code e74843950714 = 1174355578490 := by decide
theorem cert_e74843950714 : check e74843950714 [[.under],[.under,.left]] .chain = true := by decide
def e74843950902 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e74843950902 : Closed e74843950902 ∧ code e74843950902 = 1174355578678 := by decide
theorem cert_e74843950902 : check e74843950902 [[.under],[.under,.left]] .chain = true := by decide
def e74843950906 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e74843950906 : Closed e74843950906 ∧ code e74843950906 = 1174355578682 := by decide
theorem cert_e74843950906 : check e74843950906 [[.under],[.under,.left]] .chain = true := by decide
def e74977422702 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e74977422702 : Closed e74977422702 ∧ code e74977422702 = 1174489050478 := by decide
theorem cert_e74977422702 : check e74977422702 [[.under]] .sourceHead = true := by decide
def e74977422710 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e74977422710 : Closed e74977422710 ∧ code e74977422710 = 1174489050486 := by decide
theorem cert_e74977422710 : check e74977422710 [[.under]] .sourceHead = true := by decide
def e74977422766 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e74977422766 : Closed e74977422766 ∧ code e74977422766 = 1174489050542 := by decide
theorem cert_e74977422766 : check e74977422766 [[.under]] .sourceHead = true := by decide
def e74977422778 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e74977422778 : Closed e74977422778 ∧ code e74977422778 = 1174489050554 := by decide
theorem cert_e74977422778 : check e74977422778 [[.under]] .sourceHead = true := by decide
def e74977422806 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e74977422806 : Closed e74977422806 ∧ code e74977422806 = 1174489050582 := by decide
theorem cert_e74977422806 : check e74977422806 [[.under]] .sourceHead = true := by decide
def e74977422810 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e74977422810 : Closed e74977422810 ∧ code e74977422810 = 1174489050586 := by decide
theorem cert_e74977422810 : check e74977422810 [[.under]] .sourceHead = true := by decide
def e74977423022 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e74977423022 : Closed e74977423022 ∧ code e74977423022 = 1174489050798 := by decide
theorem cert_e74977423022 : check e74977423022 [[.under]] .sourceHead = true := by decide
def e74977423034 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e74977423034 : Closed e74977423034 ∧ code e74977423034 = 1174489050810 := by decide
theorem cert_e74977423034 : check e74977423034 [[.under]] .sourceHead = true := by decide
def e74977423082 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e74977423082 : Closed e74977423082 ∧ code e74977423082 = 1174489050858 := by decide
theorem cert_e74977423082 : check e74977423082 [[.under]] .sourceHead = true := by decide
def e74977423190 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e74977423190 : Closed e74977423190 ∧ code e74977423190 = 1174489050966 := by decide
theorem cert_e74977423190 : check e74977423190 [[.under]] .sourceHead = true := by decide
def e74977423194 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e74977423194 : Closed e74977423194 ∧ code e74977423194 = 1174489050970 := by decide
theorem cert_e74977423194 : check e74977423194 [[.under]] .sourceHead = true := by decide
def e74977423210 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e74977423210 : Closed e74977423210 ∧ code e74977423210 = 1174489050986 := by decide
theorem cert_e74977423210 : check e74977423210 [[.under]] .sourceHead = true := by decide
def e74977424238 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e74977424238 : Closed e74977424238 ∧ code e74977424238 = 1174489052014 := by decide
theorem cert_e74977424238 : check e74977424238 [[.under]] .sourceHead = true := by decide
def e74977424246 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e74977424246 : Closed e74977424246 ∧ code e74977424246 = 1174489052022 := by decide
theorem cert_e74977424246 : check e74977424246 [[.under]] .sourceHead = true := by decide
def e74977424302 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e74977424302 : Closed e74977424302 ∧ code e74977424302 = 1174489052078 := by decide
theorem cert_e74977424302 : check e74977424302 [[.under]] .sourceHead = true := by decide
def e74977424314 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e74977424314 : Closed e74977424314 ∧ code e74977424314 = 1174489052090 := by decide
theorem cert_e74977424314 : check e74977424314 [[.under]] .sourceHead = true := by decide
def e74977424342 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e74977424342 : Closed e74977424342 ∧ code e74977424342 = 1174489052118 := by decide
theorem cert_e74977424342 : check e74977424342 [[.under]] .sourceHead = true := by decide
def e74977424346 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e74977424346 : Closed e74977424346 ∧ code e74977424346 = 1174489052122 := by decide
theorem cert_e74977424346 : check e74977424346 [[.under]] .sourceHead = true := by decide
def e74977424622 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e74977424622 : Closed e74977424622 ∧ code e74977424622 = 1174489052398 := by decide
theorem cert_e74977424622 : check e74977424622 [[.under]] .sourceHead = true := by decide
def e74977424630 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e74977424630 : Closed e74977424630 ∧ code e74977424630 = 1174489052406 := by decide
theorem cert_e74977424630 : check e74977424630 [[.under]] .sourceHead = true := by decide
def e74977425006 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e74977425006 : Closed e74977425006 ∧ code e74977425006 = 1174489052782 := by decide
theorem cert_e74977425006 : check e74977425006 [[.under]] .sourceHead = true := by decide
def e74977425018 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e74977425018 : Closed e74977425018 ∧ code e74977425018 = 1174489052794 := by decide
theorem cert_e74977425018 : check e74977425018 [[.under]] .sourceHead = true := by decide
def e74977425206 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e74977425206 : Closed e74977425206 ∧ code e74977425206 = 1174489052982 := by decide
theorem cert_e74977425206 : check e74977425206 [[.under]] .sourceHead = true := by decide
def e74977425210 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e74977425210 : Closed e74977425210 ∧ code e74977425210 = 1174489052986 := by decide
theorem cert_e74977425210 : check e74977425210 [[.under]] .sourceHead = true := by decide
def e74977425838 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e74977425838 : Closed e74977425838 ∧ code e74977425838 = 1174489053614 := by decide
theorem cert_e74977425838 : check e74977425838 [[.under]] .sourceHead = true := by decide
def e74977425850 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e74977425850 : Closed e74977425850 ∧ code e74977425850 = 1174489053626 := by decide
theorem cert_e74977425850 : check e74977425850 [[.under]] .sourceHead = true := by decide
def e74977425898 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e74977425898 : Closed e74977425898 ∧ code e74977425898 = 1174489053674 := by decide
theorem cert_e74977425898 : check e74977425898 [[.under]] .sourceHead = true := by decide
def e74977426030 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e74977426030 : Closed e74977426030 ∧ code e74977426030 = 1174489053806 := by decide
theorem cert_e74977426030 : check e74977426030 [[.under]] .sourceHead = true := by decide
def e74977426042 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e74977426042 : Closed e74977426042 ∧ code e74977426042 = 1174489053818 := by decide
theorem cert_e74977426042 : check e74977426042 [[.under]] .sourceHead = true := by decide
def e74977426330 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e74977426330 : Closed e74977426330 ∧ code e74977426330 = 1174489054106 := by decide
theorem cert_e74977426330 : check e74977426330 [[.under]] .sourceHead = true := by decide
def e74977426646 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e74977426646 : Closed e74977426646 ∧ code e74977426646 = 1174489054422 := by decide
theorem cert_e74977426646 : check e74977426646 [[.under]] .sourceHead = true := by decide
def e74977426650 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e74977426650 : Closed e74977426650 ∧ code e74977426650 = 1174489054426 := by decide
theorem cert_e74977426650 : check e74977426650 [[.under]] .sourceHead = true := by decide
def e74977426666 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e74977426666 : Closed e74977426666 ∧ code e74977426666 = 1174489054442 := by decide
theorem cert_e74977426666 : check e74977426666 [[.under]] .sourceHead = true := by decide
def e74977426742 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e74977426742 : Closed e74977426742 ∧ code e74977426742 = 1174489054518 := by decide
theorem cert_e74977426742 : check e74977426742 [[.under]] .sourceHead = true := by decide
def e74977426746 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e74977426746 : Closed e74977426746 ∧ code e74977426746 = 1174489054522 := by decide
theorem cert_e74977426746 : check e74977426746 [[.under]] .sourceHead = true := by decide
def e74977426842 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e74977426842 : Closed e74977426842 ∧ code e74977426842 = 1174489054618 := by decide
theorem cert_e74977426842 : check e74977426842 [[.under]] .sourceHead = true := by decide
def e74977430382 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e74977430382 : Closed e74977430382 ∧ code e74977430382 = 1174489058158 := by decide
theorem cert_e74977430382 : check e74977430382 [[.under]] .sourceHead = true := by decide
def e74977430390 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e74977430390 : Closed e74977430390 ∧ code e74977430390 = 1174489058166 := by decide
theorem cert_e74977430390 : check e74977430390 [[.under]] .sourceHead = true := by decide
def e74977430446 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e74977430446 : Closed e74977430446 ∧ code e74977430446 = 1174489058222 := by decide
theorem cert_e74977430446 : check e74977430446 [[.under]] .sourceHead = true := by decide
def e74977430458 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e74977430458 : Closed e74977430458 ∧ code e74977430458 = 1174489058234 := by decide
theorem cert_e74977430458 : check e74977430458 [[.under]] .sourceHead = true := by decide
def e74977430486 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e74977430486 : Closed e74977430486 ∧ code e74977430486 = 1174489058262 := by decide
theorem cert_e74977430486 : check e74977430486 [[.under]] .sourceHead = true := by decide
def e74977430490 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e74977430490 : Closed e74977430490 ∧ code e74977430490 = 1174489058266 := by decide
theorem cert_e74977430490 : check e74977430490 [[.under]] .sourceHead = true := by decide
def e74977430766 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e74977430766 : Closed e74977430766 ∧ code e74977430766 = 1174489058542 := by decide
theorem cert_e74977430766 : check e74977430766 [[.under]] .sourceHead = true := by decide
def e74977430774 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e74977430774 : Closed e74977430774 ∧ code e74977430774 = 1174489058550 := by decide
theorem cert_e74977430774 : check e74977430774 [[.under]] .sourceHead = true := by decide
def e74977431150 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e74977431150 : Closed e74977431150 ∧ code e74977431150 = 1174489058926 := by decide
theorem cert_e74977431150 : check e74977431150 [[.under]] .sourceHead = true := by decide
def e74977431162 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e74977431162 : Closed e74977431162 ∧ code e74977431162 = 1174489058938 := by decide
theorem cert_e74977431162 : check e74977431162 [[.under]] .sourceHead = true := by decide
def e74977431350 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e74977431350 : Closed e74977431350 ∧ code e74977431350 = 1174489059126 := by decide
theorem cert_e74977431350 : check e74977431350 [[.under]] .sourceHead = true := by decide
def e74977431354 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e74977431354 : Closed e74977431354 ∧ code e74977431354 = 1174489059130 := by decide
theorem cert_e74977431354 : check e74977431354 [[.under]] .sourceHead = true := by decide
def e74977437102 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e74977437102 : Closed e74977437102 ∧ code e74977437102 = 1174489064878 := by decide
theorem cert_e74977437102 : check e74977437102 [[.under]] .sourceHead = true := by decide
def e74977437114 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e74977437114 : Closed e74977437114 ∧ code e74977437114 = 1174489064890 := by decide
theorem cert_e74977437114 : check e74977437114 [[.under]] .sourceHead = true := by decide
def e74977437162 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e74977437162 : Closed e74977437162 ∧ code e74977437162 = 1174489064938 := by decide
theorem cert_e74977437162 : check e74977437162 [[.under]] .sourceHead = true := by decide
def e74977437294 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e74977437294 : Closed e74977437294 ∧ code e74977437294 = 1174489065070 := by decide
theorem cert_e74977437294 : check e74977437294 [[.under]] .sourceHead = true := by decide
def e74977437306 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e74977437306 : Closed e74977437306 ∧ code e74977437306 = 1174489065082 := by decide
theorem cert_e74977437306 : check e74977437306 [[.under]] .sourceHead = true := by decide
def e74977437594 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e74977437594 : Closed e74977437594 ∧ code e74977437594 = 1174489065370 := by decide
theorem cert_e74977437594 : check e74977437594 [[.under]] .sourceHead = true := by decide
def e74977440470 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e74977440470 : Closed e74977440470 ∧ code e74977440470 = 1174489068246 := by decide
theorem cert_e74977440470 : check e74977440470 [[.under]] .sourceHead = true := by decide
def e74977440474 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e74977440474 : Closed e74977440474 ∧ code e74977440474 = 1174489068250 := by decide
theorem cert_e74977440474 : check e74977440474 [[.under]] .sourceHead = true := by decide
def e74977440490 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e74977440490 : Closed e74977440490 ∧ code e74977440490 = 1174489068266 := by decide
theorem cert_e74977440490 : check e74977440490 [[.under]] .sourceHead = true := by decide
def e74977440566 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e74977440566 : Closed e74977440566 ∧ code e74977440566 = 1174489068342 := by decide
theorem cert_e74977440566 : check e74977440566 [[.under]] .sourceHead = true := by decide
def e74977440570 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e74977440570 : Closed e74977440570 ∧ code e74977440570 = 1174489068346 := by decide
theorem cert_e74977440570 : check e74977440570 [[.under]] .sourceHead = true := by decide
def e74977440666 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e74977440666 : Closed e74977440666 ∧ code e74977440666 = 1174489068442 := by decide
theorem cert_e74977440666 : check e74977440666 [[.under]] .sourceHead = true := by decide
def e74977577838 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e74977577838 : Closed e74977577838 ∧ code e74977577838 = 1174489205614 := by decide
theorem cert_e74977577838 : check e74977577838 [[.under]] .sourceHead = true := by decide
def e74977577846 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e74977577846 : Closed e74977577846 ∧ code e74977577846 = 1174489205622 := by decide
theorem cert_e74977577846 : check e74977577846 [[.under]] .sourceHead = true := by decide
def e74977577902 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e74977577902 : Closed e74977577902 ∧ code e74977577902 = 1174489205678 := by decide
theorem cert_e74977577902 : check e74977577902 [[.under]] .sourceHead = true := by decide
def e74977577914 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e74977577914 : Closed e74977577914 ∧ code e74977577914 = 1174489205690 := by decide
theorem cert_e74977577914 : check e74977577914 [[.under]] .sourceHead = true := by decide
def e74977577942 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e74977577942 : Closed e74977577942 ∧ code e74977577942 = 1174489205718 := by decide
theorem cert_e74977577942 : check e74977577942 [[.under]] .sourceHead = true := by decide
def e74977577946 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e74977577946 : Closed e74977577946 ∧ code e74977577946 = 1174489205722 := by decide
theorem cert_e74977577946 : check e74977577946 [[.under]] .sourceHead = true := by decide
def e74977578222 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e74977578222 : Closed e74977578222 ∧ code e74977578222 = 1174489205998 := by decide
theorem cert_e74977578222 : check e74977578222 [[.under]] .sourceHead = true := by decide
def e74977578230 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e74977578230 : Closed e74977578230 ∧ code e74977578230 = 1174489206006 := by decide
theorem cert_e74977578230 : check e74977578230 [[.under]] .sourceHead = true := by decide
def e74977578606 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e74977578606 : Closed e74977578606 ∧ code e74977578606 = 1174489206382 := by decide
theorem cert_e74977578606 : check e74977578606 [[.under]] .sourceHead = true := by decide
def e74977578618 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e74977578618 : Closed e74977578618 ∧ code e74977578618 = 1174489206394 := by decide
theorem cert_e74977578618 : check e74977578618 [[.under]] .sourceHead = true := by decide
def e74977578806 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e74977578806 : Closed e74977578806 ∧ code e74977578806 = 1174489206582 := by decide
theorem cert_e74977578806 : check e74977578806 [[.under]] .sourceHead = true := by decide
def e74977578810 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e74977578810 : Closed e74977578810 ∧ code e74977578810 = 1174489206586 := by decide
theorem cert_e74977578810 : check e74977578810 [[.under]] .sourceHead = true := by decide
def e74978167662 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e74978167662 : Closed e74978167662 ∧ code e74978167662 = 1174489795438 := by decide
theorem cert_e74978167662 : check e74978167662 [[.under]] .sourceHead = true := by decide
def e74978167670 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e74978167670 : Closed e74978167670 ∧ code e74978167670 = 1174489795446 := by decide
theorem cert_e74978167670 : check e74978167670 [[.under]] .sourceHead = true := by decide
def e74978167726 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e74978167726 : Closed e74978167726 ∧ code e74978167726 = 1174489795502 := by decide
theorem cert_e74978167726 : check e74978167726 [[.under]] .sourceHead = true := by decide
def e74978167738 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e74978167738 : Closed e74978167738 ∧ code e74978167738 = 1174489795514 := by decide
theorem cert_e74978167738 : check e74978167738 [[.under]] .sourceHead = true := by decide
def e74978167766 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e74978167766 : Closed e74978167766 ∧ code e74978167766 = 1174489795542 := by decide
theorem cert_e74978167766 : check e74978167766 [[.under]] .sourceHead = true := by decide
def e74978167770 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e74978167770 : Closed e74978167770 ∧ code e74978167770 = 1174489795546 := by decide
theorem cert_e74978167770 : check e74978167770 [[.under]] .sourceHead = true := by decide
def e74978168046 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e74978168046 : Closed e74978168046 ∧ code e74978168046 = 1174489795822 := by decide
theorem cert_e74978168046 : check e74978168046 [[.under]] .sourceHead = true := by decide
def e74978168054 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e74978168054 : Closed e74978168054 ∧ code e74978168054 = 1174489795830 := by decide
theorem cert_e74978168054 : check e74978168054 [[.under]] .sourceHead = true := by decide
def e74978168430 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e74978168430 : Closed e74978168430 ∧ code e74978168430 = 1174489796206 := by decide
theorem cert_e74978168430 : check e74978168430 [[.under]] .sourceHead = true := by decide
def e74978168442 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e74978168442 : Closed e74978168442 ∧ code e74978168442 = 1174489796218 := by decide
theorem cert_e74978168442 : check e74978168442 [[.under]] .sourceHead = true := by decide
def e74978168630 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e74978168630 : Closed e74978168630 ∧ code e74978168630 = 1174489796406 := by decide
theorem cert_e74978168630 : check e74978168630 [[.under]] .sourceHead = true := by decide
def e74978168634 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e74978168634 : Closed e74978168634 ∧ code e74978168634 = 1174489796410 := by decide
theorem cert_e74978168634 : check e74978168634 [[.under]] .sourceHead = true := by decide
def e75185898198 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e75185898198 : Closed e75185898198 ∧ code e75185898198 = 1174697525974 := by decide
theorem cert_e75185898198 : check e75185898198 [[.under]] .width = true := by decide
def e75185898202 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e75185898202 : Closed e75185898202 ∧ code e75185898202 = 1174697525978 := by decide
theorem cert_e75185898202 : check e75185898202 [[.under]] .width = true := by decide
def e75185898218 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e75185898218 : Closed e75185898218 ∧ code e75185898218 = 1174697525994 := by decide
theorem cert_e75185898218 : check e75185898218 [[.under]] .width = true := by decide
def e75185898294 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e75185898294 : Closed e75185898294 ∧ code e75185898294 = 1174697526070 := by decide
theorem cert_e75185898294 : check e75185898294 [[.under]] .width = true := by decide
def e75185898298 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e75185898298 : Closed e75185898298 ∧ code e75185898298 = 1174697526074 := by decide
theorem cert_e75185898298 : check e75185898298 [[.under]] .width = true := by decide
def e75185898394 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e75185898394 : Closed e75185898394 ∧ code e75185898394 = 1174697526170 := by decide
theorem cert_e75185898394 : check e75185898394 [[.under]] .width = true := by decide
def e75185963734 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e75185963734 : Closed e75185963734 ∧ code e75185963734 = 1174697591510 := by decide
theorem cert_e75185963734 : check e75185963734 [[.under]] .width = true := by decide
def e75185963738 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e75185963738 : Closed e75185963738 ∧ code e75185963738 = 1174697591514 := by decide
theorem cert_e75185963738 : check e75185963738 [[.under]] .width = true := by decide
def e75185963754 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e75185963754 : Closed e75185963754 ∧ code e75185963754 = 1174697591530 := by decide
theorem cert_e75185963754 : check e75185963754 [[.under]] .width = true := by decide
def e75185963830 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e75185963830 : Closed e75185963830 ∧ code e75185963830 = 1174697591606 := by decide
theorem cert_e75185963830 : check e75185963830 [[.under]] .width = true := by decide
def e75185963834 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e75185963834 : Closed e75185963834 ∧ code e75185963834 = 1174697591610 := by decide
theorem cert_e75185963834 : check e75185963834 [[.under]] .width = true := by decide
def e75185963930 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e75185963930 : Closed e75185963930 ∧ code e75185963930 = 1174697591706 := by decide
theorem cert_e75185963930 : check e75185963930 [[.under]] .width = true := by decide
def e75186422486 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e75186422486 : Closed e75186422486 ∧ code e75186422486 = 1174698050262 := by decide
theorem cert_e75186422486 : check e75186422486 [[.under]] .width = true := by decide
def e75186422490 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e75186422490 : Closed e75186422490 ∧ code e75186422490 = 1174698050266 := by decide
theorem cert_e75186422490 : check e75186422490 [[.under]] .width = true := by decide
def e75186422506 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e75186422506 : Closed e75186422506 ∧ code e75186422506 = 1174698050282 := by decide
theorem cert_e75186422506 : check e75186422506 [[.under]] .width = true := by decide
def e75186422582 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e75186422582 : Closed e75186422582 ∧ code e75186422582 = 1174698050358 := by decide
theorem cert_e75186422582 : check e75186422582 [[.under]] .width = true := by decide
def e75186422586 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e75186422586 : Closed e75186422586 ∧ code e75186422586 = 1174698050362 := by decide
theorem cert_e75186422586 : check e75186422586 [[.under]] .width = true := by decide
def e75186422682 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e75186422682 : Closed e75186422682 ∧ code e75186422682 = 1174698050458 := by decide
theorem cert_e75186422682 : check e75186422682 [[.under]] .width = true := by decide
def e75186520790 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e75186520790 : Closed e75186520790 ∧ code e75186520790 = 1174698148566 := by decide
private def t_e75186520790 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem cert_e75186520790 : ¬ IsSelfInterpreter e75186520790 :=
  wSource (t := t_e75186520790) (replay_sound (ps := []) (t := e75186520790) (by decide)) (by decide)
def e75186520794 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e75186520794 : Closed e75186520794 ∧ code e75186520794 = 1174698148570 := by decide
theorem cert_e75186520794 : check e75186520794 [[.under]] .width = true := by decide
def e75186520810 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e75186520810 : Closed e75186520810 ∧ code e75186520810 = 1174698148586 := by decide
theorem cert_e75186520810 : check e75186520810 [[.under]] .width = true := by decide
def e75186520886 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e75186520886 : Closed e75186520886 ∧ code e75186520886 = 1174698148662 := by decide
theorem cert_e75186520886 : check e75186520886 [[.under]] .width = true := by decide
def e75186520890 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e75186520890 : Closed e75186520890 ∧ code e75186520890 = 1174698148666 := by decide
theorem cert_e75186520890 : check e75186520890 [[.under]] .width = true := by decide
def e75186520986 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e75186520986 : Closed e75186520986 ∧ code e75186520986 = 1174698148762 := by decide
theorem cert_e75186520986 : check e75186520986 [[.under]] .width = true := by decide
def e75186750166 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e75186750166 : Closed e75186750166 ∧ code e75186750166 = 1174698377942 := by decide
theorem cert_e75186750166 : check e75186750166 [[.under]] .width = true := by decide
def e75186750170 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e75186750170 : Closed e75186750170 ∧ code e75186750170 = 1174698377946 := by decide
theorem cert_e75186750170 : check e75186750170 [[.under]] .width = true := by decide
def e75186750186 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e75186750186 : Closed e75186750186 ∧ code e75186750186 = 1174698377962 := by decide
theorem cert_e75186750186 : check e75186750186 [[.under]] .width = true := by decide
def e75186750262 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e75186750262 : Closed e75186750262 ∧ code e75186750262 = 1174698378038 := by decide
theorem cert_e75186750262 : check e75186750262 [[.under]] .width = true := by decide
def e75186750266 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e75186750266 : Closed e75186750266 ∧ code e75186750266 = 1174698378042 := by decide
theorem cert_e75186750266 : check e75186750266 [[.under]] .width = true := by decide
def e75186750362 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e75186750362 : Closed e75186750362 ∧ code e75186750362 = 1174698378138 := by decide
theorem cert_e75186750362 : check e75186750362 [[.under]] .width = true := by decide
def e75186782934 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e75186782934 : Closed e75186782934 ∧ code e75186782934 = 1174698410710 := by decide
private def t_e75186782934 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem cert_e75186782934 : ¬ IsSelfInterpreter e75186782934 :=
  wSource (t := t_e75186782934) (replay_sound (ps := []) (t := e75186782934) (by decide)) (by decide)
def e75186782938 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e75186782938 : Closed e75186782938 ∧ code e75186782938 = 1174698410714 := by decide
theorem cert_e75186782938 : check e75186782938 [[.under]] .width = true := by decide
def e75186782954 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e75186782954 : Closed e75186782954 ∧ code e75186782954 = 1174698410730 := by decide
theorem cert_e75186782954 : check e75186782954 [[.under]] .width = true := by decide
def e75186783030 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e75186783030 : Closed e75186783030 ∧ code e75186783030 = 1174698410806 := by decide
theorem cert_e75186783030 : check e75186783030 [[.under]] .width = true := by decide
def e75186783034 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e75186783034 : Closed e75186783034 ∧ code e75186783034 = 1174698410810 := by decide
theorem cert_e75186783034 : check e75186783034 [[.under]] .width = true := by decide
def e75186783130 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e75186783130 : Closed e75186783130 ∧ code e75186783130 = 1174698410906 := by decide
theorem cert_e75186783130 : check e75186783130 [[.under]] .width = true := by decide
def e75189043926 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e75189043926 : Closed e75189043926 ∧ code e75189043926 = 1174700671702 := by decide
theorem cert_e75189043926 : check e75189043926 [[.under]] .width = true := by decide
def e75189043930 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e75189043930 : Closed e75189043930 ∧ code e75189043930 = 1174700671706 := by decide
theorem cert_e75189043930 : check e75189043930 [[.under]] .width = true := by decide
def e75189043946 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e75189043946 : Closed e75189043946 ∧ code e75189043946 = 1174700671722 := by decide
theorem cert_e75189043946 : check e75189043946 [[.under]] .width = true := by decide
def e75189044022 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e75189044022 : Closed e75189044022 ∧ code e75189044022 = 1174700671798 := by decide
theorem cert_e75189044022 : check e75189044022 [[.under]] .width = true := by decide
def e75189044026 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e75189044026 : Closed e75189044026 ∧ code e75189044026 = 1174700671802 := by decide
theorem cert_e75189044026 : check e75189044026 [[.under]] .width = true := by decide
def e75189044122 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e75189044122 : Closed e75189044122 ∧ code e75189044122 = 1174700671898 := by decide
theorem cert_e75189044122 : check e75189044122 [[.under]] .width = true := by decide
def e75189109462 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e75189109462 : Closed e75189109462 ∧ code e75189109462 = 1174700737238 := by decide
theorem cert_e75189109462 : check e75189109462 [[.under]] .width = true := by decide
def e75189109466 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e75189109466 : Closed e75189109466 ∧ code e75189109466 = 1174700737242 := by decide
theorem cert_e75189109466 : check e75189109466 [[.under]] .width = true := by decide
def e75189109482 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e75189109482 : Closed e75189109482 ∧ code e75189109482 = 1174700737258 := by decide
theorem cert_e75189109482 : check e75189109482 [[.under]] .width = true := by decide
def e75189109558 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e75189109558 : Closed e75189109558 ∧ code e75189109558 = 1174700737334 := by decide
theorem cert_e75189109558 : check e75189109558 [[.under]] .width = true := by decide
def e75189109562 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e75189109562 : Closed e75189109562 ∧ code e75189109562 = 1174700737338 := by decide
theorem cert_e75189109562 : check e75189109562 [[.under]] .width = true := by decide
def e75189109658 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e75189109658 : Closed e75189109658 ∧ code e75189109658 = 1174700737434 := by decide
theorem cert_e75189109658 : check e75189109658 [[.under]] .width = true := by decide
def e75192189654 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e75192189654 : Closed e75192189654 ∧ code e75192189654 = 1174703817430 := by decide
theorem cert_e75192189654 : check e75192189654 [[.under]] .width = true := by decide
def e75192189658 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e75192189658 : Closed e75192189658 ∧ code e75192189658 = 1174703817434 := by decide
theorem cert_e75192189658 : check e75192189658 [[.under]] .width = true := by decide
def e75192189674 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e75192189674 : Closed e75192189674 ∧ code e75192189674 = 1174703817450 := by decide
theorem cert_e75192189674 : check e75192189674 [[.under]] .width = true := by decide
def e75192189750 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e75192189750 : Closed e75192189750 ∧ code e75192189750 = 1174703817526 := by decide
theorem cert_e75192189750 : check e75192189750 [[.under]] .width = true := by decide
def e75192189754 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e75192189754 : Closed e75192189754 ∧ code e75192189754 = 1174703817530 := by decide
theorem cert_e75192189754 : check e75192189754 [[.under]] .width = true := by decide
def e75192189850 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e75192189850 : Closed e75192189850 ∧ code e75192189850 = 1174703817626 := by decide
theorem cert_e75192189850 : check e75192189850 [[.under]] .width = true := by decide
def e75192287958 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e75192287958 : Closed e75192287958 ∧ code e75192287958 = 1174703915734 := by decide
theorem cert_e75192287958 : check e75192287958 [[.under]] .width = true := by decide
def e75192287962 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e75192287962 : Closed e75192287962 ∧ code e75192287962 = 1174703915738 := by decide
theorem cert_e75192287962 : check e75192287962 [[.under]] .width = true := by decide
end Blc.Floor40
