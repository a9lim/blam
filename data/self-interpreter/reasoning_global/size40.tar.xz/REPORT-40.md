# Size 40 is excluded

Every exact closed-source BLC self-interpreter has at least **41 bits**. This is a handwritten global classification with kernel-checked components at the standard of sections 7–9 of `docs/classical/self-interpreter/global-floor.md`. There are 10,284 layouts, 9,978 checked finite predicates with the implications given below, and 306 complete Lean exclusions. All 92 residuals after the initial pass have direct Lean proofs. The stronger single-object pruning test was unnecessary; zero layouts depend exclusively on it. No claim about size 41 is made.

## From an arbitrary interpreter to the inventory

1. Suppose an exact closed-source interpreter E has 40 bits. The previously established global floor 40 makes E globally minimum. Every β-reduct of a closed interpreter is a closed interpreter, by confluence and the contract in an application context. Thus a reduct of any length below 40 contradicts minimality, including a reduct obtained under a lambda or inside an argument.
2. Write L for the number of lambdas, V for variable leaves and X for the sum of zero-based indices. There are V−1 binary nodes, so the wire identity is 2L+4V−2+X=40. The global capture-width theorem supplies a subterm with three distinct free variables. Their binders form an ancestor chain and their occurrences cost at least 2, 1 and 0 respectively, so X≥3. The two incomparable nonlinear binders supplied by the structural theorem cannot both lie on that chain. This gives at least four live binders, and at least six leaves because each of the two nonlinear binders has a second occurrence. Solving the inequalities gives exactly the six triples in the table.
3. A closed variable root is impossible. For a root λc.B, the projection in global-floor §6 forces a width-three witness using *internal* binders of B. In detail, substituting closed K for c and appending the closed encoded pairing source, closed suffix and projection argument produces a term convertible to the pairing combinator. The inherited pairing obstruction implies that any closed term convertible to this projection target must have width at least three. The closed inserted terms have insufficient width, and a witness outside them descends from B with c removed from its free-variable set. This uses the projection obstruction, not monotonicity of width under β-reduction. Equivalently use the internal conclusion of the literal-interface lemma. The outer c is an ancestor of every other binder, so the incomparable nonlinear pair is also inside B. B therefore has four live internal binders and six internal leaves. The rigid continuation in the identity output forces c itself to be live, giving L≥5,V≥7. Only (5,7,4) remains. Two literal public lambdas are already excluded by the published 46-bit bound. This step needs just the published capture-width and literal-interface consequences. It does not classify by factorization through a captured object.
4. Generate all ordered trees with the chosen L unary nodes, V leaves and V−1 binary nodes. Maintain one pending root slot initially and replace one pending slot by the current node's arity. A preorder string is accepted precisely when the pending count first becomes zero at the last node and all counts are exhausted. Every ordered syntax tree gives such a string, and recursively filling the first pending slot reconstructs exactly one tree. At each leaf underneath d lambdas enumerate all indices 0 through d−1, retaining exactly the assignments with sum X. The lexical binder stack enforces closure, and the assignment determines the unique wire. No normality, first-contractor form, or location of the width witness is assumed.
5. For each subterm the C++ enumerator computes its free binder identities bottom-up. A variable contributes its actual binding node, lambda removes its own node, and application takes union. At a literal root exclude the public binder when counting each subterm's internal free variables. Keep width at least three, two disjoint preorder intervals of nonlinear binders, and, for a literal, an occurrence of c. In preorder the subtrees of incomparable binders have disjoint intervals. A binder is nonlinear exactly when its variable occurs at least twice.
6. Inspect every source redex (λx.B) A. Write k for x's occurrence count in B, D for the sum of the depths of those occurrences below the root of B, f for the number of free *occurrences* in A, and g for the number of B's variable occurrences referring above x. Its contracted-minus-original wire cost is (k−1)|A|+(f−1)D−2k−4−g. Indeed, each substituted copy of A gains its insertion depth for each free occurrence, deleted occurrences of x cost 2 plus their depths, the disappearing application and lambda cost four, and the g higher references each lose one bit. Outer context costs cancel. Drop a wire if any such change is strictly negative. Equal-cost contractions are retained.
7. The independent Rust procedure traverses the repository's full closed-wire grammar at length 40, with **no initial restriction on resource triples**. It computes relative-index bitmasks for occurrence-at-least-once and occurrence-at-least-twice. On application the second mask acquires the intersection of the children's first masks. At a binder both masks shift, while bit zero of the second mask detects nonlinearity. A pair exists if either child already has one or both children have a nonlinear binder. Width uses only indices smaller than the running depth from the post-public body root. This recognizes 53,008 wires out of all 130,880,047 (also the canonical census count). Python performs every possible *single* contraction on each of those wires and measures the resulting bit length directly. Exactly 42,724 have a shrinking contraction. The two implementations produce the identical remaining 10,284 wires with zero symmetric difference. The independent decoder in `verify_ledger.py` checks each literal Lean term, sentinel wire identity and certificate declaration against the ledger.

| (L,V,X) | Closed at enumerated roots | Width, pair, public conditions | Application layouts | Literal layouts |
|---|---:|---:|---:|---:|
| (4,6,10) | 28 | 0 | 0 | 0 |
| (4,7,6) | 39,136 | 1,080 | 540 | 0 |
| (5,6,8) | 26,778 | 336 | 144 | 0 |
| (5,7,4) | 13,875,080 | 34,144 | 5,940 | 1,152 |
| (6,6,6) | 546,580 | 12,240 | 2,058 | 0 |
| (7,6,4) | 2,571,978 | 5,208 | 450 | 0 |
| Total | 17,059,580 | 53,008 | 9,132 | 1,152 |

The closed column includes both roots only at (5,7,4). The final two columns also impose nonshrinking. At most five binders can be live, since a sixth would require at least eight leaves.

| Source family | Layouts | Finite predicate | Complete exclusion |
|---|---:|---:|---:|
| Application, four live | 7,248 | 6,995 | 253 |
| Application, five live | 1,884 | 1,839 | 45 |
| Literal continuation, five live | 1,152 | 1,144 | 8 |
| Total | 10,284 | 9,978 | 306 |

## Excluding every layout

`ledger.json` identifies the wire, triple, family by root, predicate or direct theorem, and local module. `Batch000.lean` through `Batch064.lean` give every literal term a proof of closure and of its exact wire. Folding the BLC code in base two starting at **one** preserves leading zeroes. Every finite reduction witness supplies concrete β-redex paths. The kernel reduces the finite predicate with ordinary `decide`; `SelfintSharp.replay_sound` connects successful path replay to β-reduction.

| Certificate | Application | Literal | Total |
|---|---:|---:|---:|
| Nonlinear binders on one chain | 3,696 | 342 | 4,038 |
| Strictly smaller reduct | 1,751 | 0 | 1,751 |
| Three or more leading lambdas | 1,508 | 122 | 1,630 |
| Wrong source HNF | 649 | 594 | 1,243 |
| Internal width below three | 850 | 82 | 932 |
| Wrong rigid identity head | 223 | 0 | 223 |
| Wrong normal identity payload or remainder | 157 | 4 | 161 |
| W/B grammar on source | 205 | 8 | 213 |
| W/B grammar on identity call | 1 | 0 | 1 |
| Regular Krivine invariant | 49 | 0 | 49 |
| Weighted rank | 42 | 0 | 42 |
| Swap parity | 1 | 0 | 1 |

For the first seven rows the semantic implication must be checked along with the finite predicates in `Floor40.lean`:

- Every source reduct is an interpreter under the hypothesis. The nonlinear pair cannot include a leading lambda because that lambda is comparable with every binder below it. After removing the prefix, a pair exists exactly when it occurs in a subtree or the two children of some application each contain a nonlinear binder. The Boolean `chain` computes the negation of this condition.
- The smaller-reduct rule uses the previous floor. Three leading lambdas leave a lambda after the two public arguments, whereas the required identity output has rigid head C.
- A closed HNF cannot have zero leading lambdas. With one it is λc.c A₁…Aₖ. Applying C and the identity stream exposes k+1 arguments of the rigid C. Correct arity forces k=1 and would identify the whole nonempty, lambda-rooted stream with its rigid suffix R. With two lambdas and head c, rigid comparison forces exactly two existing arguments. A two-lambda stream-headed form is passed on by this predicate.
- For an internal-width discharge the checked source reduct has zero, one or two leading lambdas. With zero use the global capture-width theorem. With one use the literal internal-width argument above. With two apply its two-public-binder counterpart from the literal-interface proof: instantiate both public variables by the closed continuation and stream in the pairing projection. The witness cannot come from the inserted closed terms or the final projection argument. It uses three variables bound inside the body. `measures 0 (trim t)` counts only such variables, and its maximum is taken over *all* body subterms. At a depth-d variable i the mask is empty for i≥d, otherwise it contains bit i. A lambda shifts the returned mask right and preserves the attained maximum. Application unions both masks and compares the population count with both child maxima.
- For the other two finite conditions, instantiate the exact identity source with rigid C,R, as de Bruijn variables 1,0. The required normal result is C (λz.I) R, with λz.I = Church false. In a head-normal term, reduction within arguments cannot alter leading lambdas, head variable, or spine arity. Thus any tag other than (0,1,2) is impossible. At the correct tag, confluence and rigid spine decomposition force each payload to join its required component. A *positively obtained* different normal form of that component is a contradiction.

The two W/B rows are already complete Lean exclusions. Under the empty marking, B has no normal form by the substitution and head-progress theorems of `WGrammar38.lean`. B in function position remains B when arguments are appended, so a source certificate uses the two-argument identity call; every interpreter has to normalize that call. An identity-reduct B directly contradicts the same obligation. Thus failure of a source to have a strong normal form alone is never used. The initial finite/grammar pass settles 10,192 layouts and leaves the following 92.

## The 92 residuals

`residuals.tsv` is the wire-by-wire list of all 92 with exact filename, qualified theorem name, proposition and transitive axioms. `complete.tsv` includes the other 214 direct proofs as well. For each row the proposition is `¬ Blc.IsSelfInterpreter Blc.Floor40.eN`, where N is the unsigned value of that specific 40-bit wire. `Residuals.lean` proves the collected theorem

```lean
Blc.Floor40.residuals_excluded (t : Term) (h : t ∈ Blc.Floor40.residuals) :
  ¬ Blc.IsSelfInterpreter t
```

The list is defined by the corresponding 92 source terms. Its transitive axioms are `propext`, `Classical.choice`, and `Quot.sound`.

**49 regular machine invariants.** In each `RN.lean`, `Certgen.RN.excluded` proves the direct proposition. A regular certificate contains a finite collection of abstract Krivine states with value and stack stores. The kernel verifies that the initial state is represented and every represented state admits a covered successor. The structural interpretation ties the root to the actual literal reduct, including the fillings for opaque subterms. Administrative machine steps preserve the interpreted term and decrease the head closure rank; a lambda/pop step makes a real weak-head contraction. Lexicographic descent on a hypothetical finite weak clock and the closure rank gives the contradiction. The 49 invariants use 7,282 states altogether, 12 to 1,969 per proof. Chunked tables and indexed successor checks have the same progress obligation.

The finite-clock obligation is essential. For 20 raw sources it follows by projecting twice from the normalizing identity application. The others use the exact contract on a specific closed source M: joining an actual call to C (λz.M) R is preserved when trailing arguments are appended. Positive head reduction of the latter to HNF witnesses solvability, which transfers across the join and implies a finite weak clock for the actual call. A finite β-prefix preserves existence of a clock. `RegularBase.inputCount` and `clocks_replay` prove these steps even when an argument contains Ω. There are five rigid identity probes, one with C=λv r.I and R=Ω, seven with C=K,R=Ω followed by Ω,I, thirteen projecting the rigid suffix followed by one, two or three Ω arguments (4,7,2 cases), and three custom calls. For two custom calls C=M=Church false, R is rigid and four Ω arguments follow. For the remaining call the encoded C is `0000010111001000110100001101010`, M is identity, R is rigid and three Ω arguments follow. All actual probe expressions and finite prefixes are present in the individual Lean files.

**42 weighted ranks.** `Weighted.lean` proves an all-size syntactic criterion `Blc.Floor40.Weighted.no_clock`. For any integer c define the variable rank by an environment ρ, the lambda rank by 1 plus its body rank with the new variable assigned zero, and the application rank by max(0, rank(f)−1, rank(a)−c). From a binder's body to each occurrence of its variable, a lambda edge costs +1, a left application edge −1, and a right edge −c. The guard requires the sum on each such path to be at most −c, for every binder. The empty collection of occurrences satisfies the guard.

Structural induction proves that giving a binder weight z raises the expression's rank to at most max(its zero-weight rank, z+d) when all the affected paths have score ≤d. For closed substituends evaluation commutes with substitution, and a closed guarded substituend preserves the guards of the other binders. Consequently each weak-head contraction of a closed guarded term preserves the guard and cannot increase rank. A closed term stopping at weak head must be a lambda, whose zero-environment rank is at least one. A guarded closed term of rank zero therefore admits no finite weak clock. This lemma has no wire-size, search-depth or run-time hypothesis. It discharges 20 raw sources at c=1, 10 raw sources at c=2, and 12 applications E Δ at c=1, where Δ=λx.x x. In the last case the identity call with continuation Δ has required head reduct R, so E Δ must itself have a clock. Twenty-eight witnesses apply immediately, fourteen after one checked contraction. Each direct statement is `Blc.Floor40.WeightedRows.ex_eN`.

**One swap-parity induction.** Wire `0100011010000101100000010111101011000110` denotes Δ N, where N=λx.x (swap x) (box x), swap x=λy z.x z y and box x=λy.x for closed x. Call w even if it is closed and w p q reduces to N p q for every closed p,q. N is even. Two swaps preserve evenness by direct reduction. For even w there is exactly the following first weak step and then a checked β-reduction (application associates left):

```
N w → w (swap w) (box w)
    →* N (swap (swap w)) (box (box (swap w))) (box w).
```

For the second line, use evenness to replace the head w on the displayed pair by N, expand N (swap w), and swap the next two arguments. The resulting w on closed arguments can again be replaced by N. Expand N (box (swap w)), erase the argument of that box, swap, and use evenness once more. `Parity.round` gives each of these contextual reductions explicitly. A finite clock for N w strictly decreases at the first step, cannot increase along the remaining reductions, and can only decrease or stay equal when the two trailing arguments are dropped. It would give a strictly smaller clock for N (swap² w). Strong induction excludes every such clock. The source reduces once to N N, so evenness of N contradicts `rawCount`. The direct theorem `Blc.Floor40.Parity.excluded` uses `propext` and `Quot.sound`.

## Verification and trust boundary

The grammar argument, the links between the seven positive predicates and the interpreter contract, and the final combination with the prior floor are handwritten. C++, Rust and Python are unverified implementations of the inventory checks. The dependent Lean modules verify the individual wire identities, replay predicates, the 306 direct negative propositions and the collected 92-term exclusion. No failure to normalize, fuel cap, timeout, failed model search, or memory cutoff is a proof. Finite discovery selects witnesses; only its positive certificates enter the result.

From this directory, with the existing repository Lean build available, run `python3 recheck_inventory.py`, `python3 verify_ledger.py` and `python3 recheck.py`. The first compiles both enumerators, requires byte-identical outputs to the recorded enumerations, and runs the independent contraction comparison. The second matches the Lean literals, exact binary sentinels, trace paths and tags to the ledger. The third rebuilds the dependency closure in an empty temporary object directory, with one pinned Lean 4.32.2 process at a time, `-j2 -M 900`, and emits the direct axiom tables from `#print axioms`. The only imported prebuilt dependencies are the repository's Lean library and the installed Lean toolchain. None of these commands needs a Lake build or changes tracked files.

The reproduction of the triple enumeration took 0.661 s, the independent 130,880,047-wire traversal 4.947 s, and direct contraction filtering 0.472 s. Including compilation, these stages took 6.381 s. Peak RSS for the three checking processes was 62.0 MiB, or 114.4 MiB including compilation. See `inventory-metrics.json`. The complete research lane took about 38 minutes wall time through this report.

The clean rebuild succeeded for **346 modules in 182.370 s**. The largest process was `R302398863814` at 887,816,192 bytes RSS (846.69 MiB). `recheck.json` records every module's elapsed time and RSS. Across exploratory Lean builds, including unsuccessful attempts before large proofs were split, the maximum recorded by wait4 was 972,881,920 bytes (927.81 MiB). The external lane watchdog reported a peak whole tree of 1,418 MiB and zero strikes. All 306 direct axiom reports are in `Audit40.log`. Exactly 264 theorems (all 214 grammar, 49 regular, one parity) use [propext, Quot.sound]. Exactly 42 (the weighted ranks) also use Classical.choice.

The reusable result for larger inventories is the closed guarded rank-zero obstruction in `Weighted.no_clock`. It can be applied to the raw minimum, a checked β-reduct, or a closed partial application known to have a clock. `inputCount` supplies additional solvability probes with divergent trailing arguments. Neither lemma depends on the numerical lower bound.
