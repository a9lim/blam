import Floor40
namespace Blc.Floor40
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e302801269870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e302801269870 : Closed e302801269870 ∧ code e302801269870 = 1402312897646 := by decide
theorem cert_e302801269870 : check e302801269870 [[],[]] .chain = true := by decide
def e302801269882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e302801269882 : Closed e302801269882 ∧ code e302801269882 = 1402312897658 := by decide
theorem cert_e302801269882 : check e302801269882 [[],[]] .chain = true := by decide
def e302801270046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e302801270046 : Closed e302801270046 ∧ code e302801270046 = 1402312897822 := by decide
theorem cert_e302801270046 : check e302801270046 [[],[]] .chain = true := by decide
def e302801270214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e302801270214 : Closed e302801270214 ∧ code e302801270214 = 1402312897990 := by decide
theorem cert_e302801270214 : check e302801270214 [[],[]] .chain = true := by decide
def e302801270318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e302801270318 : Closed e302801270318 ∧ code e302801270318 = 1402312898094 := by decide
theorem cert_e302801270318 : check e302801270318 [[],[]] .chain = true := by decide
def e302801270498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e302801270498 : Closed e302801270498 ∧ code e302801270498 = 1402312898274 := by decide
theorem cert_e302801270498 : check e302801270498 [[],[]] .chain = true := by decide
def e302801270510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2))))))
theorem wire_e302801270510 : Closed e302801270510 ∧ code e302801270510 = 1402312898286 := by decide
theorem cert_e302801270510 : checkPay e302801270510 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left]] = true := by decide
def e302801270550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e302801270550 : Closed e302801270550 ∧ code e302801270550 = 1402312898326 := by decide
theorem cert_e302801270550 : check e302801270550 [[],[]] .chain = true := by decide
def e302801270554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302801270554 : Closed e302801270554 ∧ code e302801270554 = 1402312898330 := by decide
theorem cert_e302801270554 : check e302801270554 [[],[]] .chain = true := by decide
def e302801270598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302801270598 : Closed e302801270598 ∧ code e302801270598 = 1402312898374 := by decide
theorem cert_e302801270598 : check e302801270598 [[],[]] .chain = true := by decide
def e302801270626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e302801270626 : Closed e302801270626 ∧ code e302801270626 = 1402312898402 := by decide
theorem cert_e302801270626 : check e302801270626 [[],[]] .chain = true := by decide
def e302801270638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2))))))
theorem wire_e302801270638 : Closed e302801270638 ∧ code e302801270638 = 1402312898414 := by decide
theorem cert_e302801270638 : checkPay e302801270638 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[],[.left]] = true := by decide
def e302801270646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1))))))
theorem wire_e302801270646 : Closed e302801270646 ∧ code e302801270646 = 1402312898422 := by decide
theorem cert_e302801270646 : checkPay e302801270646 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e302801270958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e302801270958 : Closed e302801270958 ∧ code e302801270958 = 1402312898734 := by decide
theorem cert_e302801270958 : check e302801270958 [[],[]] .chain = true := by decide
def e302801270970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e302801270970 : Closed e302801270970 ∧ code e302801270970 = 1402312898746 := by decide
theorem cert_e302801270970 : check e302801270970 [[],[]] .chain = true := by decide
def e302801271342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e302801271342 : Closed e302801271342 ∧ code e302801271342 = 1402312899118 := by decide
theorem cert_e302801271342 : check e302801271342 [[],[]] .chain = true := by decide
def e302801271522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e302801271522 : Closed e302801271522 ∧ code e302801271522 = 1402312899298 := by decide
theorem cert_e302801271522 : check e302801271522 [[],[]] .chain = true := by decide
def e302801271534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e302801271534 : Closed e302801271534 ∧ code e302801271534 = 1402312899310 := by decide
theorem cert_e302801271534 : checkPay e302801271534 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801271690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e302801271690 : Closed e302801271690 ∧ code e302801271690 = 1402312899466 := by decide
theorem cert_e302801271690 : check e302801271690 [[],[]] .chain = true := by decide
def e302801271714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e302801271714 : Closed e302801271714 ∧ code e302801271714 = 1402312899490 := by decide
theorem cert_e302801271714 : check e302801271714 [[],[]] .chain = true := by decide
def e302801271726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e302801271726 : Closed e302801271726 ∧ code e302801271726 = 1402312899502 := by decide
theorem cert_e302801271726 : checkPay e302801271726 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801271738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e302801271738 : Closed e302801271738 ∧ code e302801271738 = 1402312899514 := by decide
theorem cert_e302801271738 : checkPay e302801271738 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801271894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e302801271894 : Closed e302801271894 ∧ code e302801271894 = 1402312899670 := by decide
theorem cert_e302801271894 : check e302801271894 [[],[]] .chain = true := by decide
def e302801271898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e302801271898 : Closed e302801271898 ∧ code e302801271898 = 1402312899674 := by decide
theorem cert_e302801271898 : check e302801271898 [[],[]] .chain = true := by decide
def e302801271914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e302801271914 : Closed e302801271914 ∧ code e302801271914 = 1402312899690 := by decide
theorem cert_e302801271914 : check e302801271914 [[],[]] .chain = true := by decide
def e302801272086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e302801272086 : Closed e302801272086 ∧ code e302801272086 = 1402312899862 := by decide
theorem cert_e302801272086 : check e302801272086 [[],[]] .chain = true := by decide
def e302801272090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e302801272090 : Closed e302801272090 ∧ code e302801272090 = 1402312899866 := by decide
theorem cert_e302801272090 : check e302801272090 [[],[]] .chain = true := by decide
def e302801272134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e302801272134 : Closed e302801272134 ∧ code e302801272134 = 1402312899910 := by decide
theorem cert_e302801272134 : check e302801272134 [[],[]] .chain = true := by decide
def e302801272162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e302801272162 : Closed e302801272162 ∧ code e302801272162 = 1402312899938 := by decide
theorem cert_e302801272162 : check e302801272162 [[],[]] .chain = true := by decide
def e302801272174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e302801272174 : Closed e302801272174 ∧ code e302801272174 = 1402312899950 := by decide
theorem cert_e302801272174 : checkPay e302801272174 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.right,.left]] = true := by decide
def e302801272182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e302801272182 : Closed e302801272182 ∧ code e302801272182 = 1402312899958 := by decide
theorem cert_e302801272182 : checkPay e302801272182 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e302801272202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e302801272202 : Closed e302801272202 ∧ code e302801272202 = 1402312899978 := by decide
theorem cert_e302801272202 : check e302801272202 [[],[]] .chain = true := by decide
def e302801272226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e302801272226 : Closed e302801272226 ∧ code e302801272226 = 1402312900002 := by decide
theorem cert_e302801272226 : check e302801272226 [[],[]] .chain = true := by decide
def e302801272238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e302801272238 : Closed e302801272238 ∧ code e302801272238 = 1402312900014 := by decide
theorem cert_e302801272238 : checkPay e302801272238 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left]] = true := by decide
def e302801272250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e302801272250 : Closed e302801272250 ∧ code e302801272250 = 1402312900026 := by decide
theorem cert_e302801272250 : checkPay e302801272250 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under]] = true := by decide
def e302801272278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e302801272278 : Closed e302801272278 ∧ code e302801272278 = 1402312900054 := by decide
theorem cert_e302801272278 : checkPay e302801272278 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e302801272282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e302801272282 : Closed e302801272282 ∧ code e302801272282 = 1402312900058 := by decide
theorem cert_e302801272282 : checkPay e302801272282 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e302801273326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e302801273326 : Closed e302801273326 ∧ code e302801273326 = 1402312901102 := by decide
theorem cert_e302801273326 : check e302801273326 [[],[]] .chain = true := by decide
def e302801273334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e302801273334 : Closed e302801273334 ∧ code e302801273334 = 1402312901110 := by decide
theorem cert_e302801273334 : check e302801273334 [[],[]] .chain = true := by decide
def e302801273710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e302801273710 : Closed e302801273710 ∧ code e302801273710 = 1402312901486 := by decide
theorem cert_e302801273710 : check e302801273710 [[],[]] .chain = true := by decide
def e302801273722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e302801273722 : Closed e302801273722 ∧ code e302801273722 = 1402312901498 := by decide
theorem cert_e302801273722 : check e302801273722 [[],[]] .chain = true := by decide
def e302801273774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e302801273774 : Closed e302801273774 ∧ code e302801273774 = 1402312901550 := by decide
theorem cert_e302801273774 : check e302801273774 [[],[]] .chain = true := by decide
def e302801273834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e302801273834 : Closed e302801273834 ∧ code e302801273834 = 1402312901610 := by decide
theorem cert_e302801273834 : check e302801273834 [[],[]] .chain = true := by decide
def e302801274094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e302801274094 : Closed e302801274094 ∧ code e302801274094 = 1402312901870 := by decide
theorem cert_e302801274094 : check e302801274094 [[],[]] .chain = true := by decide
def e302801274102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e302801274102 : Closed e302801274102 ∧ code e302801274102 = 1402312901878 := by decide
theorem cert_e302801274102 : check e302801274102 [[],[]] .chain = true := by decide
def e302801274478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e302801274478 : Closed e302801274478 ∧ code e302801274478 = 1402312902254 := by decide
theorem cert_e302801274478 : check e302801274478 [[],[]] .chain = true := by decide
def e302801274490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e302801274490 : Closed e302801274490 ∧ code e302801274490 = 1402312902266 := by decide
theorem cert_e302801274490 : check e302801274490 [[],[]] .chain = true := by decide
def e302801274654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e302801274654 : Closed e302801274654 ∧ code e302801274654 = 1402312902430 := by decide
theorem cert_e302801274654 : check e302801274654 [[],[]] .chain = true := by decide
def e302801274766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e302801274766 : Closed e302801274766 ∧ code e302801274766 = 1402312902542 := by decide
theorem cert_e302801274766 : check e302801274766 [[],[]] .chain = true := by decide
def e302801274778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e302801274778 : Closed e302801274778 ∧ code e302801274778 = 1402312902554 := by decide
theorem cert_e302801274778 : check e302801274778 [[],[]] .chain = true := by decide
def e302801276014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.var 2))))))
theorem wire_e302801276014 : Closed e302801276014 ∧ code e302801276014 = 1402312903790 := by decide
theorem cert_e302801276014 : check e302801276014 [[],[]] .chain = true := by decide
def e302801276026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))) (.var 0))))))
theorem wire_e302801276026 : Closed e302801276026 ∧ code e302801276026 = 1402312903802 := by decide
theorem cert_e302801276026 : check e302801276026 [[],[]] .chain = true := by decide
def e302801276190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e302801276190 : Closed e302801276190 ∧ code e302801276190 = 1402312903966 := by decide
theorem cert_e302801276190 : check e302801276190 [[],[]] .chain = true := by decide
def e302801276358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e302801276358 : Closed e302801276358 ∧ code e302801276358 = 1402312904134 := by decide
theorem cert_e302801276358 : check e302801276358 [[],[]] .chain = true := by decide
def e302801276462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e302801276462 : Closed e302801276462 ∧ code e302801276462 = 1402312904238 := by decide
theorem cert_e302801276462 : check e302801276462 [[],[]] .chain = true := by decide
def e302801276642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e302801276642 : Closed e302801276642 ∧ code e302801276642 = 1402312904418 := by decide
theorem cert_e302801276642 : check e302801276642 [[],[]] .chain = true := by decide
def e302801276654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e302801276654 : Closed e302801276654 ∧ code e302801276654 = 1402312904430 := by decide
theorem cert_e302801276654 : checkPay e302801276654 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e302801276694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e302801276694 : Closed e302801276694 ∧ code e302801276694 = 1402312904470 := by decide
theorem cert_e302801276694 : check e302801276694 [[],[]] .chain = true := by decide
def e302801276698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.var 0))))))
theorem wire_e302801276698 : Closed e302801276698 ∧ code e302801276698 = 1402312904474 := by decide
theorem cert_e302801276698 : check e302801276698 [[],[]] .chain = true := by decide
def e302801276742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e302801276742 : Closed e302801276742 ∧ code e302801276742 = 1402312904518 := by decide
theorem cert_e302801276742 : check e302801276742 [[],[]] .chain = true := by decide
def e302801276770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e302801276770 : Closed e302801276770 ∧ code e302801276770 = 1402312904546 := by decide
theorem cert_e302801276770 : check e302801276770 [[],[]] .chain = true := by decide
def e302801276782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e302801276782 : Closed e302801276782 ∧ code e302801276782 = 1402312904558 := by decide
theorem cert_e302801276782 : checkPay e302801276782 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[]] = true := by decide
def e302801276790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e302801276790 : Closed e302801276790 ∧ code e302801276790 = 1402312904566 := by decide
theorem cert_e302801276790 : checkPay e302801276790 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e302801277150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e302801277150 : Closed e302801277150 ∧ code e302801277150 = 1402312904926 := by decide
theorem cert_e302801277150 : check e302801277150 [[],[]] .chain = true := by decide
def e302801277178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e302801277178 : Closed e302801277178 ∧ code e302801277178 = 1402312904954 := by decide
theorem cert_e302801277178 : check e302801277178 [[],[]] .chain = true := by decide
def e302801277726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e302801277726 : Closed e302801277726 ∧ code e302801277726 = 1402312905502 := by decide
theorem cert_e302801277726 : check e302801277726 [[],[]] .chain = true := by decide
def e302801277894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e302801277894 : Closed e302801277894 ∧ code e302801277894 = 1402312905670 := by decide
theorem cert_e302801277894 : check e302801277894 [[],[]] .chain = true := by decide
def e302801279038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e302801279038 : Closed e302801279038 ∧ code e302801279038 = 1402312906814 := by decide
theorem cert_e302801279038 : check e302801279038 [[],[]] .chain = true := by decide
def e302801279458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e302801279458 : Closed e302801279458 ∧ code e302801279458 = 1402312907234 := by decide
theorem cert_e302801279458 : check e302801279458 [[],[]] .chain = true := by decide
def e302801279470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e302801279470 : Closed e302801279470 ∧ code e302801279470 = 1402312907246 := by decide
theorem cert_e302801279470 : checkPay e302801279470 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e302801280030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e302801280030 : Closed e302801280030 ∧ code e302801280030 = 1402312907806 := by decide
theorem cert_e302801280030 : check e302801280030 [[],[]] .chain = true := by decide
def e302801280054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e302801280054 : Closed e302801280054 ∧ code e302801280054 = 1402312907830 := by decide
theorem cert_e302801280054 : check e302801280054 [[],[]] .chain = true := by decide
def e302801280058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e302801280058 : Closed e302801280058 ∧ code e302801280058 = 1402312907834 := by decide
theorem cert_e302801280058 : check e302801280058 [[],[]] .chain = true := by decide
def e302801280198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302801280198 : Closed e302801280198 ∧ code e302801280198 = 1402312907974 := by decide
theorem cert_e302801280198 : check e302801280198 [[],[]] .chain = true := by decide
def e302801280226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e302801280226 : Closed e302801280226 ∧ code e302801280226 = 1402312908002 := by decide
theorem cert_e302801280226 : check e302801280226 [[],[]] .chain = true := by decide
def e302801280238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e302801280238 : Closed e302801280238 ∧ code e302801280238 = 1402312908014 := by decide
theorem cert_e302801280238 : checkPay e302801280238 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left],[.under,.right],[.under,.right,.left],[.under,.right]] = true := by decide
def e302801280246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e302801280246 : Closed e302801280246 ∧ code e302801280246 = 1402312908022 := by decide
theorem cert_e302801280246 : checkPay e302801280246 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left],[.under,.right]] = true := by decide
def e302801281262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e302801281262 : Closed e302801281262 ∧ code e302801281262 = 1402312909038 := by decide
theorem cert_e302801281262 : check e302801281262 [[],[]] .chain = true := by decide
def e302801281274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e302801281274 : Closed e302801281274 ∧ code e302801281274 = 1402312909050 := by decide
theorem cert_e302801281274 : check e302801281274 [[],[]] .chain = true := by decide
def e302801281646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e302801281646 : Closed e302801281646 ∧ code e302801281646 = 1402312909422 := by decide
theorem cert_e302801281646 : check e302801281646 [[],[]] .chain = true := by decide
def e302801281658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e302801281658 : Closed e302801281658 ∧ code e302801281658 = 1402312909434 := by decide
theorem cert_e302801281658 : check e302801281658 [[],[]] .chain = true := by decide
def e302801281822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e302801281822 : Closed e302801281822 ∧ code e302801281822 = 1402312909598 := by decide
theorem cert_e302801281822 : check e302801281822 [[],[]] .chain = true := by decide
def e302801281990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e302801281990 : Closed e302801281990 ∧ code e302801281990 = 1402312909766 := by decide
theorem cert_e302801281990 : check e302801281990 [[],[]] .chain = true := by decide
def e302801282606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e302801282606 : Closed e302801282606 ∧ code e302801282606 = 1402312910382 := by decide
theorem cert_e302801282606 : check e302801282606 [[],[]] .chain = true := by decide
def e302801282786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e302801282786 : Closed e302801282786 ∧ code e302801282786 = 1402312910562 := by decide
theorem cert_e302801282786 : check e302801282786 [[],[]] .chain = true := by decide
def e302801282798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e302801282798 : Closed e302801282798 ∧ code e302801282798 = 1402312910574 := by decide
theorem cert_e302801282798 : checkPay e302801282798 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right],[.right,.left],[.right],[.right,.under,.left],[.right,.under,.left,.left,.left]] = true := by decide
def e302801282954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e302801282954 : Closed e302801282954 ∧ code e302801282954 = 1402312910730 := by decide
theorem cert_e302801282954 : check e302801282954 [[],[]] .chain = true := by decide
def e302801282978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e302801282978 : Closed e302801282978 ∧ code e302801282978 = 1402312910754 := by decide
theorem cert_e302801282978 : check e302801282978 [[],[]] .chain = true := by decide
def e302801282990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e302801282990 : Closed e302801282990 ∧ code e302801282990 = 1402312910766 := by decide
theorem cert_e302801282990 : checkPay e302801282990 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right],[.right,.under,.under,.left,.right,.right]] = true := by decide
def e302801283002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e302801283002 : Closed e302801283002 ∧ code e302801283002 = 1402312910778 := by decide
theorem cert_e302801283002 : checkPay e302801283002 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e302801283134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e302801283134 : Closed e302801283134 ∧ code e302801283134 = 1402312910910 := by decide
theorem cert_e302801283134 : check e302801283134 [[],[]] .chain = true := by decide
def e302801283554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e302801283554 : Closed e302801283554 ∧ code e302801283554 = 1402312911330 := by decide
theorem cert_e302801283554 : check e302801283554 [[],[]] .chain = true := by decide
def e302801283566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e302801283566 : Closed e302801283566 ∧ code e302801283566 = 1402312911342 := by decide
theorem cert_e302801283566 : checkPay e302801283566 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801284622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e302801284622 : Closed e302801284622 ∧ code e302801284622 = 1402312912398 := by decide
theorem cert_e302801284622 : check e302801284622 [[],[]] .chain = true := by decide
def e302801284706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e302801284706 : Closed e302801284706 ∧ code e302801284706 = 1402312912482 := by decide
theorem cert_e302801284706 : check e302801284706 [[],[]] .chain = true := by decide
def e302801284718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e302801284718 : Closed e302801284718 ∧ code e302801284718 = 1402312912494 := by decide
theorem cert_e302801284718 : checkPay e302801284718 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801284730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e302801284730 : Closed e302801284730 ∧ code e302801284730 = 1402312912506 := by decide
theorem cert_e302801284730 : checkPay e302801284730 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801285238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e302801285238 : Closed e302801285238 ∧ code e302801285238 = 1402312913014 := by decide
theorem cert_e302801285238 : check e302801285238 [[],[]] .chain = true := by decide
def e302801285242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e302801285242 : Closed e302801285242 ∧ code e302801285242 = 1402312913018 := by decide
theorem cert_e302801285242 : check e302801285242 [[],[]] .chain = true := by decide
def e302801285338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e302801285338 : Closed e302801285338 ∧ code e302801285338 = 1402312913114 := by decide
theorem cert_e302801285338 : check e302801285338 [[],[]] .chain = true := by decide
def e302801285354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e302801285354 : Closed e302801285354 ∧ code e302801285354 = 1402312913130 := by decide
theorem cert_e302801285354 : check e302801285354 [[],[]] .chain = true := by decide
def e302801285430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e302801285430 : Closed e302801285430 ∧ code e302801285430 = 1402312913206 := by decide
theorem cert_e302801285430 : check e302801285430 [[],[]] .chain = true := by decide
def e302801285434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e302801285434 : Closed e302801285434 ∧ code e302801285434 = 1402312913210 := by decide
theorem cert_e302801285434 : check e302801285434 [[],[]] .chain = true := by decide
def e302801285518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e302801285518 : Closed e302801285518 ∧ code e302801285518 = 1402312913294 := by decide
theorem cert_e302801285518 : check e302801285518 [[],[]] .chain = true := by decide
def e302801285530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e302801285530 : Closed e302801285530 ∧ code e302801285530 = 1402312913306 := by decide
theorem cert_e302801285530 : check e302801285530 [[],[]] .chain = true := by decide
def e302801285574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e302801285574 : Closed e302801285574 ∧ code e302801285574 = 1402312913350 := by decide
theorem cert_e302801285574 : check e302801285574 [[],[]] .chain = true := by decide
def e302801285910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e302801285910 : Closed e302801285910 ∧ code e302801285910 = 1402312913686 := by decide
theorem cert_e302801285910 : check e302801285910 [[],[]] .chain = true := by decide
def e302801285914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.var 0))))))
theorem wire_e302801285914 : Closed e302801285914 ∧ code e302801285914 = 1402312913690 := by decide
theorem cert_e302801285914 : check e302801285914 [[],[]] .chain = true := by decide
def e302801285958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e302801285958 : Closed e302801285958 ∧ code e302801285958 = 1402312913734 := by decide
theorem cert_e302801285958 : check e302801285958 [[],[]] .chain = true := by decide
def e302801285986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e302801285986 : Closed e302801285986 ∧ code e302801285986 = 1402312913762 := by decide
theorem cert_e302801285986 : check e302801285986 [[],[]] .chain = true := by decide
def e302801285998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e302801285998 : Closed e302801285998 ∧ code e302801285998 = 1402312913774 := by decide
theorem cert_e302801285998 : checkPay e302801285998 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.right]] = true := by decide
def e302801286006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e302801286006 : Closed e302801286006 ∧ code e302801286006 = 1402312913782 := by decide
theorem cert_e302801286006 : checkPay e302801286006 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left,.left,.left,.right],[.under,.under,.left,.right,.left,.left,.left,.right,.left],[.under,.under,.left,.right,.left,.left,.left,.right],[.under,.under,.left,.right,.left,.left,.left,.right,.under,.left],[.under,.under,.left,.right,.left,.left,.left,.right,.under,.left,.left,.left],[.under,.under,.left,.right,.left,.left,.left,.right,.under,.left,.left]] = true := by decide
def e302801286026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e302801286026 : Closed e302801286026 ∧ code e302801286026 = 1402312913802 := by decide
theorem cert_e302801286026 : check e302801286026 [[],[]] .chain = true := by decide
def e302801286050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e302801286050 : Closed e302801286050 ∧ code e302801286050 = 1402312913826 := by decide
theorem cert_e302801286050 : check e302801286050 [[],[]] .chain = true := by decide
def e302801286062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e302801286062 : Closed e302801286062 ∧ code e302801286062 = 1402312913838 := by decide
theorem cert_e302801286062 : checkPay e302801286062 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e302801286074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e302801286074 : Closed e302801286074 ∧ code e302801286074 = 1402312913850 := by decide
theorem cert_e302801286074 : checkPay e302801286074 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e302801286102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e302801286102 : Closed e302801286102 ∧ code e302801286102 = 1402312913878 := by decide
theorem cert_e302801286102 : checkPay e302801286102 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.under,.left,.left,.left],[.under,.under,.left,.right,.under,.left,.left],[.under,.under,.left,.right,.under,.left],[.under,.under,.left,.right,.under,.left,.left,.right],[.under,.under,.left,.right,.under,.left,.left,.right,.left,.left],[.under,.under,.left,.right,.under,.left,.left,.right,.left,.left,.left,.left],[.under,.under,.left,.right,.under,.left,.left,.right,.left,.left,.left,.left,.left,.left],[.under,.under,.left,.right,.under,.right,.left],[.under,.under,.left,.right,.under,.right],[.under,.under,.left,.right,.under,.right,.under,.left,.right],[.under,.under,.left,.right,.under,.right,.under,.left,.right,.left,.left]] = true := by decide
def e302801286106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e302801286106 : Closed e302801286106 ∧ code e302801286106 = 1402312913882 := by decide
theorem cert_e302801286106 : checkPay e302801286106 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.left,.right,.under,.left,.left,.left],[.under,.under,.left,.right,.under,.left,.left],[.under,.under,.left,.right,.under,.left],[.under,.under,.left,.right,.under,.left,.right,.right,.right,.left],[.under,.under,.left,.right,.under,.left,.right,.right,.right]] = true := by decide
def e302801286174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e302801286174 : Closed e302801286174 ∧ code e302801286174 = 1402312913950 := by decide
theorem cert_e302801286174 : check e302801286174 [[],[]] .chain = true := by decide
def e302801286198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e302801286198 : Closed e302801286198 ∧ code e302801286198 = 1402312913974 := by decide
theorem cert_e302801286198 : check e302801286198 [[],[]] .chain = true := by decide
def e302801286202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e302801286202 : Closed e302801286202 ∧ code e302801286202 = 1402312913978 := by decide
theorem cert_e302801286202 : check e302801286202 [[],[]] .chain = true := by decide
def e302801286342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e302801286342 : Closed e302801286342 ∧ code e302801286342 = 1402312914118 := by decide
theorem cert_e302801286342 : check e302801286342 [[],[]] .chain = true := by decide
def e302801286370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e302801286370 : Closed e302801286370 ∧ code e302801286370 = 1402312914146 := by decide
theorem cert_e302801286370 : check e302801286370 [[],[]] .chain = true := by decide
def e302801286382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e302801286382 : Closed e302801286382 ∧ code e302801286382 = 1402312914158 := by decide
theorem cert_e302801286382 : checkPay e302801286382 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e302801286390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e302801286390 : Closed e302801286390 ∧ code e302801286390 = 1402312914166 := by decide
theorem cert_e302801286390 : checkPay e302801286390 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right],[.under,.under,.right]] = true := by decide
def e302801286670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e302801286670 : Closed e302801286670 ∧ code e302801286670 = 1402312914446 := by decide
theorem cert_e302801286670 : check e302801286670 [[],[]] .chain = true := by decide
def e302801286754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e302801286754 : Closed e302801286754 ∧ code e302801286754 = 1402312914530 := by decide
theorem cert_e302801286754 : check e302801286754 [[],[]] .chain = true := by decide
def e302801286766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e302801286766 : Closed e302801286766 ∧ code e302801286766 = 1402312914542 := by decide
theorem cert_e302801286766 : checkPay e302801286766 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e302801286778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e302801286778 : Closed e302801286778 ∧ code e302801286778 = 1402312914554 := by decide
theorem cert_e302801286778 : checkPay e302801286778 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e302801286966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e302801286966 : Closed e302801286966 ∧ code e302801286966 = 1402312914742 := by decide
theorem cert_e302801286966 : checkPay e302801286966 [[.left,.left],[.left,.left],[.left],[]] 1 [[]] = true := by decide
def e302801286970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e302801286970 : Closed e302801286970 ∧ code e302801286970 = 1402312914746 := by decide
theorem cert_e302801286970 : checkPay e302801286970 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e302801292126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e302801292126 : Closed e302801292126 ∧ code e302801292126 = 1402312919902 := by decide
theorem cert_e302801292126 : check e302801292126 [[],[]] .chain = true := by decide
def e302801292142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e302801292142 : Closed e302801292142 ∧ code e302801292142 = 1402312919918 := by decide
theorem cert_e302801292142 : check e302801292142 [[],[]] .smaller = true := by decide
def e302801292150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e302801292150 : Closed e302801292150 ∧ code e302801292150 = 1402312919926 := by decide
theorem cert_e302801292150 : check e302801292150 [[],[]] .smaller = true := by decide
def e302801292154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e302801292154 : Closed e302801292154 ∧ code e302801292154 = 1402312919930 := by decide
theorem cert_e302801292154 : check e302801292154 [[],[]] .chain = true := by decide
def e302801292206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e302801292206 : Closed e302801292206 ∧ code e302801292206 = 1402312919982 := by decide
theorem cert_e302801292206 : check e302801292206 [[],[]] .smaller = true := by decide
def e302801292218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e302801292218 : Closed e302801292218 ∧ code e302801292218 = 1402312919994 := by decide
theorem cert_e302801292218 : check e302801292218 [[],[]] .smaller = true := by decide
def e302801292246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e302801292246 : Closed e302801292246 ∧ code e302801292246 = 1402312920022 := by decide
theorem cert_e302801292246 : check e302801292246 [[],[]] .smaller = true := by decide
def e302801292250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e302801292250 : Closed e302801292250 ∧ code e302801292250 = 1402312920026 := by decide
theorem cert_e302801292250 : check e302801292250 [[],[]] .smaller = true := by decide
def e302801292266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e302801292266 : Closed e302801292266 ∧ code e302801292266 = 1402312920042 := by decide
theorem cert_e302801292266 : check e302801292266 [[],[]] .chain = true := by decide
def e302801292510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e302801292510 : Closed e302801292510 ∧ code e302801292510 = 1402312920286 := by decide
theorem cert_e302801292510 : check e302801292510 [[],[]] .chain = true := by decide
def e302801292526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e302801292526 : Closed e302801292526 ∧ code e302801292526 = 1402312920302 := by decide
theorem cert_e302801292526 : check e302801292526 [[],[]] .smaller = true := by decide
def e302801292534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e302801292534 : Closed e302801292534 ∧ code e302801292534 = 1402312920310 := by decide
theorem cert_e302801292534 : check e302801292534 [[],[]] .smaller = true := by decide
def e302801292538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e302801292538 : Closed e302801292538 ∧ code e302801292538 = 1402312920314 := by decide
theorem cert_e302801292538 : check e302801292538 [[],[]] .chain = true := by decide
def e302801292862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e302801292862 : Closed e302801292862 ∧ code e302801292862 = 1402312920638 := by decide
theorem cert_e302801292862 : check e302801292862 [[],[]] .chain = true := by decide
def e302801292910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e302801292910 : Closed e302801292910 ∧ code e302801292910 = 1402312920686 := by decide
theorem cert_e302801292910 : check e302801292910 [[],[]] .smaller = true := by decide
def e302801292922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e302801292922 : Closed e302801292922 ∧ code e302801292922 = 1402312920698 := by decide
theorem cert_e302801292922 : check e302801292922 [[],[]] .smaller = true := by decide
def e302801293110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e302801293110 : Closed e302801293110 ∧ code e302801293110 = 1402312920886 := by decide
theorem cert_e302801293110 : check e302801293110 [[],[]] .smaller = true := by decide
def e302801293114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e302801293114 : Closed e302801293114 ∧ code e302801293114 = 1402312920890 := by decide
theorem cert_e302801293114 : check e302801293114 [[],[]] .smaller = true := by decide
def e302801293198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e302801293198 : Closed e302801293198 ∧ code e302801293198 = 1402312920974 := by decide
theorem cert_e302801293198 : check e302801293198 [[],[]] .chain = true := by decide
def e302801293210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e302801293210 : Closed e302801293210 ∧ code e302801293210 = 1402312920986 := by decide
theorem cert_e302801293210 : check e302801293210 [[],[]] .chain = true := by decide
def e302801300590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e302801300590 : Closed e302801300590 ∧ code e302801300590 = 1402312928366 := by decide
theorem cert_e302801300590 : check e302801300590 [[],[]] .chain = true := by decide
def e302801300602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e302801300602 : Closed e302801300602 ∧ code e302801300602 = 1402312928378 := by decide
theorem cert_e302801300602 : check e302801300602 [[],[]] .chain = true := by decide
def e302801300766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e302801300766 : Closed e302801300766 ∧ code e302801300766 = 1402312928542 := by decide
theorem cert_e302801300766 : check e302801300766 [[],[]] .chain = true := by decide
def e302801300934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e302801300934 : Closed e302801300934 ∧ code e302801300934 = 1402312928710 := by decide
theorem cert_e302801300934 : check e302801300934 [[],[]] .chain = true := by decide
def e302801301038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e302801301038 : Closed e302801301038 ∧ code e302801301038 = 1402312928814 := by decide
theorem cert_e302801301038 : check e302801301038 [[],[]] .chain = true := by decide
def e302801301218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e302801301218 : Closed e302801301218 ∧ code e302801301218 = 1402312928994 := by decide
theorem cert_e302801301218 : check e302801301218 [[],[]] .chain = true := by decide
def e302801301230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e302801301230 : Closed e302801301230 ∧ code e302801301230 = 1402312929006 := by decide
theorem cert_e302801301230 : checkPay e302801301230 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e302801301270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e302801301270 : Closed e302801301270 ∧ code e302801301270 = 1402312929046 := by decide
theorem cert_e302801301270 : check e302801301270 [[],[]] .chain = true := by decide
def e302801301274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e302801301274 : Closed e302801301274 ∧ code e302801301274 = 1402312929050 := by decide
theorem cert_e302801301274 : check e302801301274 [[],[]] .chain = true := by decide
end Blc.Floor40
