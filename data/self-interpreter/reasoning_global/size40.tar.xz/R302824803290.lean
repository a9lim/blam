import RegularBase
import Batch060
namespace Certgen.R302824803290
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
def code : Array Code := #[.app 1 62,.app 2 53,.app 3 24,.app 4 21,.app 5 9,.lam 6,.app 7 8,.var 0,.var 0,.lam 10,.lam 11,.app 12 13,.var 1,.lam 14,.app 15 16,.var 2,.app 17 20,.app 18 19,.var 2,.var 1,.var 0,.lam 22,.lam 23,.var 0,.lam 25,.app 26 31,.app 27 28,.var 0,.lam 29,.lam 30,.var 1,.lam 32,.app 33 38,.app 34 35,.var 0,.lam 36,.lam 37,.var 1,.lam 39,.app 40 45,.app 41 42,.var 0,.lam 43,.lam 44,.var 0,.lam 46,.app 47 52,.app 48 49,.var 0,.lam 50,.lam 51,.var 1,.opaque,.app 54 58,.lam 55,.app 56 57,.var 0,.var 0,.lam 59,.app 60 61,.var 0,.var 0,.app 63 67,.lam 64,.app 65 66,.var 0,.var 0,.lam 68,.app 69 70,.var 0,.var 0]
def values : Array (List AClo) := #[[⟨53,[]⟩],[⟨20,[5,3,17]⟩],[⟨24,[]⟩],[⟨21,[]⟩],[⟨62,[]⟩],[⟨13,[2,14]⟩],[⟨13,[1,16]⟩],[⟨13,[0,15]⟩],[⟨16,[4,0,15]⟩],[⟨19,[4,0,15]⟩],[⟨9,[]⟩],[⟨58,[]⟩],[⟨57,[11]⟩],[⟨61,[12]⟩,⟨61,[13]⟩],[⟨13,[3,17]⟩],[⟨16,[5,3,17]⟩],[⟨19,[5,3,17]⟩],[⟨8,[10]⟩]]
def konts : Array (List Frame) := #[[],[⟨⟨62,[]⟩,0⟩],[⟨⟨53,[]⟩,1⟩],[⟨⟨13,[0,15]⟩,1⟩],[⟨⟨13,[1,16]⟩,3⟩,⟨⟨13,[1,16]⟩,7⟩,⟨⟨13,[1,16]⟩,13⟩],[⟨⟨13,[2,14]⟩,2⟩],[⟨⟨13,[3,17]⟩,17⟩],[⟨⟨16,[4,0,15]⟩,0⟩],[⟨⟨16,[5,3,17]⟩,2⟩],[⟨⟨20,[4,0,15]⟩,0⟩],[⟨⟨20,[5,3,17]⟩,3⟩],[⟨⟨20,[5,3,17]⟩,7⟩],[⟨⟨20,[5,3,17]⟩,13⟩],[⟨⟨19,[4,0,15]⟩,9⟩],[⟨⟨19,[5,3,17]⟩,10⟩],[⟨⟨19,[5,3,17]⟩,11⟩],[⟨⟨19,[5,3,17]⟩,12⟩],[⟨⟨24,[]⟩,2⟩],[⟨⟨21,[]⟩,17⟩],[⟨⟨9,[]⟩,18⟩],[⟨⟨58,[]⟩,9⟩],[⟨⟨57,[11]⟩,9⟩],[⟨⟨61,[12]⟩,9⟩],[⟨⟨61,[13]⟩,9⟩],[⟨⟨8,[10]⟩,18⟩]]
def states : Array AState := #[⟨⟨0,[]⟩,0⟩,⟨⟨1,[]⟩,1⟩,⟨⟨2,[]⟩,2⟩,⟨⟨3,[]⟩,17⟩,⟨⟨4,[]⟩,18⟩,⟨⟨5,[]⟩,19⟩,⟨⟨6,[10]⟩,18⟩,⟨⟨7,[10]⟩,24⟩,⟨⟨8,[10]⟩,6⟩,⟨⟨8,[10]⟩,8⟩,⟨⟨8,[10]⟩,14⟩,⟨⟨8,[10]⟩,15⟩,⟨⟨8,[10]⟩,16⟩,⟨⟨9,[]⟩,6⟩,⟨⟨9,[]⟩,8⟩,⟨⟨9,[]⟩,14⟩,⟨⟨9,[]⟩,15⟩,⟨⟨9,[]⟩,16⟩,⟨⟨9,[]⟩,24⟩,⟨⟨10,[14]⟩,17⟩,⟨⟨10,[15]⟩,2⟩,⟨⟨10,[16]⟩,10⟩,⟨⟨10,[16]⟩,11⟩,⟨⟨10,[16]⟩,12⟩,⟨⟨10,[17]⟩,18⟩,⟨⟨11,[0,15]⟩,1⟩,⟨⟨11,[1,16]⟩,3⟩,⟨⟨11,[1,16]⟩,7⟩,⟨⟨11,[1,16]⟩,13⟩,⟨⟨11,[2,14]⟩,2⟩,⟨⟨11,[3,17]⟩,17⟩,⟨⟨12,[0,15]⟩,3⟩,⟨⟨12,[1,16]⟩,4⟩,⟨⟨12,[2,14]⟩,5⟩,⟨⟨12,[3,17]⟩,6⟩,⟨⟨13,[0,15]⟩,1⟩,⟨⟨13,[3,17]⟩,5⟩,⟨⟨14,[4,0,15]⟩,0⟩,⟨⟨14,[5,3,17]⟩,2⟩,⟨⟨15,[4,0,15]⟩,7⟩,⟨⟨15,[5,3,17]⟩,8⟩,⟨⟨16,[4,0,15]⟩,0⟩,⟨⟨16,[5,3,17]⟩,3⟩,⟨⟨16,[5,3,17]⟩,7⟩,⟨⟨16,[5,3,17]⟩,13⟩,⟨⟨17,[4,0,15]⟩,9⟩,⟨⟨17,[5,3,17]⟩,10⟩,⟨⟨17,[5,3,17]⟩,11⟩,⟨⟨17,[5,3,17]⟩,12⟩,⟨⟨18,[4,0,15]⟩,13⟩,⟨⟨18,[5,3,17]⟩,14⟩,⟨⟨18,[5,3,17]⟩,15⟩,⟨⟨18,[5,3,17]⟩,16⟩,⟨⟨19,[4,0,15]⟩,9⟩,⟨⟨19,[5,3,17]⟩,4⟩,⟨⟨21,[]⟩,4⟩,⟨⟨22,[6]⟩,3⟩,⟨⟨22,[6]⟩,7⟩,⟨⟨22,[6]⟩,13⟩,⟨⟨23,[7,6]⟩,1⟩,⟨⟨23,[8,6]⟩,0⟩,⟨⟨23,[9,6]⟩,9⟩,⟨⟨53,[]⟩,9⟩,⟨⟨54,[]⟩,20⟩,⟨⟨55,[11]⟩,9⟩,⟨⟨56,[11]⟩,21⟩,⟨⟨57,[11]⟩,22⟩,⟨⟨57,[11]⟩,23⟩,⟨⟨58,[]⟩,21⟩,⟨⟨58,[]⟩,22⟩,⟨⟨58,[]⟩,23⟩,⟨⟨59,[12]⟩,9⟩,⟨⟨59,[13]⟩,9⟩,⟨⟨60,[12]⟩,22⟩,⟨⟨60,[13]⟩,23⟩,⟨⟨61,[12]⟩,23⟩,⟨⟨61,[13]⟩,23⟩]
def hints : Array (List Nat) := #[[1],[2],[3],[4],[5],[6],[7],[18],[13],[14],[15],[16],[17],[19],[20],[21],[22],[23],[24],[29],[25],[26],[27],[28],[30],[31],[32],[32],[32],[33],[34],[42],[54],[36],[8],[37],[38],[39],[40],[43],[9],[45],[46],[47],[48],[49],[50],[51],[52],[44],[10],[11],[12],[62],[55],[56,57,58],[59],[60],[61],[35],[41],[53],[63],[64],[65],[68],[69],[70],[71],[72],[72],[73],[74],[66],[75,76],[67],[75,76]]
def P (i : Nat) := code[i]?.getD .opaque
def V (i : Nat) := values[i]?.getD []
def K (i : Nat) := konts[i]?.getD []
theorem block0 : checkRange P V K states hints 0 12=true := by decide
theorem block12 : checkRange P V K states hints 12 12=true := by decide
theorem block24 : checkRange P V K states hints 24 12=true := by decide
theorem block36 : checkRange P V K states hints 36 12=true := by decide
theorem block48 : checkRange P V K states hints 48 12=true := by decide
theorem block60 : checkRange P V K states hints 60 12=true := by decide
theorem block72 : checkRange P V K states hints 72 5=true := by decide
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i<77 := hi
 by_cases h0 : i<12
 · exact range_sound block0 i (by omega) h0 hi
 by_cases h12 : i<24
 · exact range_sound block12 i (by omega) h12 hi
 by_cases h24 : i<36
 · exact range_sound block24 i (by omega) h24 hi
 by_cases h36 : i<48
 · exact range_sound block36 i (by omega) h36 hi
 by_cases h48 : i<60
 · exact range_sound block48 i (by omega) h48 hi
 by_cases h60 : i<72
 · exact range_sound block60 i (by omega) h60 hi
 exact range_sound block72 i (by omega) hh hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)

open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def terms : Array Term := #[(.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))),(.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))),(.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))))))),(.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0),(.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))),(.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))),(.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))),(.var 1),(.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))),(.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))),(.var 2),(.app (.app (.var 2) (.var 1)) (.var 0)),(.app (.var 2) (.var 1)),(.var 2),(.var 1),(.var 0),(.lam (.lam (.var 0))),(.lam (.var 0)),(.var 0),(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))))))),(.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))))),(.app (.var 0) (.lam (.lam (.var 1)))),(.var 0),(.lam (.lam (.var 1))),(.lam (.var 1)),(.var 1),(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))))),(.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))),(.app (.var 0) (.lam (.lam (.var 1)))),(.var 0),(.lam (.lam (.var 1))),(.lam (.var 1)),(.var 1),(.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))),(.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))),(.app (.var 0) (.lam (.lam (.var 0)))),(.var 0),(.lam (.lam (.var 0))),(.lam (.var 0)),(.var 0),(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))),(.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)),(.app (.var 0) (.lam (.lam (.var 1)))),(.var 0),(.lam (.lam (.var 1))),(.lam (.var 1)),(.var 1),(.var 4),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0),(.lam (.app (.var 0) (.var 0))),(.app (.var 0) (.var 0)),(.var 0),(.var 0)]
def termAt (p : Nat) : Term := terms[p]?.getD (.var 0)
def aligns (p : Nat) : Bool := match P p with
 | .opaque => true
 | .var i => decide (termAt p = Term.var i)
 | .lam b => decide (termAt p = Term.lam (termAt b))
 | .app f a => decide (termAt p = Term.app (termAt f) (termAt a))
theorem valid : (List.range code.size).all aligns = true := by decide
theorem every (p : Nat) : aligns p = true := by
 by_cases hp : p < code.size
 · exact List.all_eq_true.mp valid p (List.mem_range.mpr hp)
 · have hz : code[p]? = none := Array.getElem?_eq_none (by omega)
   simp [aligns,P,hz]
def model : Model P where
 term := termAt
 var_eq := by intro p i h; simpa [aligns,h] using every p
 lam_eq := by intro p b h; simpa [aligns,h] using every p
 app_eq := by intro p f a h; simpa [aligns,h] using every p
theorem excluded : ¬ IsSelfInterpreter e302824803290 := by
 intro he
 have hp : replay [] (call e302824803290 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact regular_no_clock model closed root h hh
#print axioms excluded
end Certgen.R302824803290
