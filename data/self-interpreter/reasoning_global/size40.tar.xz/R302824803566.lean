import CodeBridge
import R302824803566Blk0
import R302824803566Blk6
namespace Certgen.R302824803566
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.Floor40 Blc.Term Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintSharp
def lit150 : Term := .var 0
def lit131 : Term := .var 1
def lit132 : Term := .var 2
def lit119 : Term := .lam lit150
def lit98 : Term := .lam lit131
def lit118 : Term := .lam lit119
def lit148 : Term := .app lit150 lit150
def lit97 : Term := .lam lit98
def lit100 : Term := .var 5
def lit147 : Term := .lam lit148
def lit130 : Term := .app lit131 lit132
def lit88 : Term := .app lit150 lit118
def lit95 : Term := .app lit150 lit97
def lit128 : Term := .app lit150 lit130
def lit142 : Term := .app lit147 lit147
def lit126 : Term := .app lit132 lit128
def lit94 : Term := .app lit95 lit100
def lit125 : Term := .lam lit126
def lit93 : Term := .lam lit94
def lit123 : Term := .app lit131 lit125
def lit122 : Term := .lam lit123
def lit121 : Term := .lam lit122
def lit87 : Term := .app lit88 lit93
def lit86 : Term := .lam lit87
def lit117 : Term := .app lit118 lit121
def lit115 : Term := .app lit150 lit117
def lit80 : Term := .app lit95 lit86
def lit79 : Term := .lam lit80
def lit73 : Term := .app lit95 lit79
def lit72 : Term := .lam lit73
def lit102 : Term := .app lit121 lit115
def lit101 : Term := .lam lit102
def lit71 : Term := .app lit72 lit101
def lit69 : Term := .app lit150 lit71
def lit36 : Term := .app lit101 lit69
def lit35 : Term := .lam lit36
def lit2 : Term := .app lit101 lit35
def lit1 : Term := .app lit2 lit142
def lit0 : Term := .app lit1 lit142
def filling : Nat → Term := fun p => if p = 100 then Term.var 5 else Term.var 0
theorem ordered_code : ordered code = true := by decide +kernel
def model : Model P := codeModel (rankedCode code ordered_code) filling
theorem sub150 : model.term 150 = lit150 := model.var_eq 150 0 (by rfl)
theorem sub149 : model.term 149 = lit150 := model.var_eq 149 0 (by rfl)
theorem sub148 : model.term 148 = lit148 := by rw [model.app_eq 148 149 150 (by rfl), sub149, sub150]; rfl
theorem sub147 : model.term 147 = lit147 := by rw [model.lam_eq 147 148 (by rfl), sub148]; rfl
theorem sub146 : model.term 146 = lit150 := model.var_eq 146 0 (by rfl)
theorem sub145 : model.term 145 = lit150 := model.var_eq 145 0 (by rfl)
theorem sub144 : model.term 144 = lit148 := by rw [model.app_eq 144 145 146 (by rfl), sub145, sub146]; rfl
theorem sub143 : model.term 143 = lit147 := by rw [model.lam_eq 143 144 (by rfl), sub144]; rfl
theorem sub142 : model.term 142 = lit142 := by rw [model.app_eq 142 143 147 (by rfl), sub143, sub147]; rfl
theorem sub141 : model.term 141 = lit150 := model.var_eq 141 0 (by rfl)
theorem sub140 : model.term 140 = lit150 := model.var_eq 140 0 (by rfl)
theorem sub139 : model.term 139 = lit148 := by rw [model.app_eq 139 140 141 (by rfl), sub140, sub141]; rfl
theorem sub138 : model.term 138 = lit147 := by rw [model.lam_eq 138 139 (by rfl), sub139]; rfl
theorem sub137 : model.term 137 = lit150 := model.var_eq 137 0 (by rfl)
theorem sub136 : model.term 136 = lit150 := model.var_eq 136 0 (by rfl)
theorem sub135 : model.term 135 = lit148 := by rw [model.app_eq 135 136 137 (by rfl), sub136, sub137]; rfl
theorem sub134 : model.term 134 = lit147 := by rw [model.lam_eq 134 135 (by rfl), sub135]; rfl
theorem sub133 : model.term 133 = lit142 := by rw [model.app_eq 133 134 138 (by rfl), sub134, sub138]; rfl
theorem sub132 : model.term 132 = lit132 := model.var_eq 132 2 (by rfl)
theorem sub131 : model.term 131 = lit131 := model.var_eq 131 1 (by rfl)
theorem sub130 : model.term 130 = lit130 := by rw [model.app_eq 130 131 132 (by rfl), sub131, sub132]; rfl
theorem sub129 : model.term 129 = lit150 := model.var_eq 129 0 (by rfl)
theorem sub128 : model.term 128 = lit128 := by rw [model.app_eq 128 129 130 (by rfl), sub129, sub130]; rfl
theorem sub127 : model.term 127 = lit132 := model.var_eq 127 2 (by rfl)
theorem sub126 : model.term 126 = lit126 := by rw [model.app_eq 126 127 128 (by rfl), sub127, sub128]; rfl
theorem sub125 : model.term 125 = lit125 := by rw [model.lam_eq 125 126 (by rfl), sub126]; rfl
theorem sub124 : model.term 124 = lit131 := model.var_eq 124 1 (by rfl)
theorem sub123 : model.term 123 = lit123 := by rw [model.app_eq 123 124 125 (by rfl), sub124, sub125]; rfl
theorem sub122 : model.term 122 = lit122 := by rw [model.lam_eq 122 123 (by rfl), sub123]; rfl
theorem sub121 : model.term 121 = lit121 := by rw [model.lam_eq 121 122 (by rfl), sub122]; rfl
theorem sub120 : model.term 120 = lit150 := model.var_eq 120 0 (by rfl)
theorem sub119 : model.term 119 = lit119 := by rw [model.lam_eq 119 120 (by rfl), sub120]; rfl
theorem sub118 : model.term 118 = lit118 := by rw [model.lam_eq 118 119 (by rfl), sub119]; rfl
theorem sub117 : model.term 117 = lit117 := by rw [model.app_eq 117 118 121 (by rfl), sub118, sub121]; rfl
theorem sub116 : model.term 116 = lit150 := model.var_eq 116 0 (by rfl)
theorem sub115 : model.term 115 = lit115 := by rw [model.app_eq 115 116 117 (by rfl), sub116, sub117]; rfl
theorem sub114 : model.term 114 = lit132 := model.var_eq 114 2 (by rfl)
theorem sub113 : model.term 113 = lit131 := model.var_eq 113 1 (by rfl)
theorem sub112 : model.term 112 = lit130 := by rw [model.app_eq 112 113 114 (by rfl), sub113, sub114]; rfl
theorem sub111 : model.term 111 = lit150 := model.var_eq 111 0 (by rfl)
theorem sub110 : model.term 110 = lit128 := by rw [model.app_eq 110 111 112 (by rfl), sub111, sub112]; rfl
theorem sub109 : model.term 109 = lit132 := model.var_eq 109 2 (by rfl)
theorem sub108 : model.term 108 = lit126 := by rw [model.app_eq 108 109 110 (by rfl), sub109, sub110]; rfl
theorem sub107 : model.term 107 = lit125 := by rw [model.lam_eq 107 108 (by rfl), sub108]; rfl
theorem sub106 : model.term 106 = lit131 := model.var_eq 106 1 (by rfl)
theorem sub105 : model.term 105 = lit123 := by rw [model.app_eq 105 106 107 (by rfl), sub106, sub107]; rfl
theorem sub104 : model.term 104 = lit122 := by rw [model.lam_eq 104 105 (by rfl), sub105]; rfl
theorem sub103 : model.term 103 = lit121 := by rw [model.lam_eq 103 104 (by rfl), sub104]; rfl
theorem sub102 : model.term 102 = lit102 := by rw [model.app_eq 102 103 115 (by rfl), sub103, sub115]; rfl
theorem sub101 : model.term 101 = lit101 := by rw [model.lam_eq 101 102 (by rfl), sub102]; rfl
theorem sub100 : model.term 100 = lit100 := (opaqueTerm (rankedCode code ordered_code) filling (p := 100) (by rfl)).trans (by rfl)
theorem sub99 : model.term 99 = lit131 := model.var_eq 99 1 (by rfl)
theorem sub98 : model.term 98 = lit98 := by rw [model.lam_eq 98 99 (by rfl), sub99]; rfl
theorem sub97 : model.term 97 = lit97 := by rw [model.lam_eq 97 98 (by rfl), sub98]; rfl
theorem sub96 : model.term 96 = lit150 := model.var_eq 96 0 (by rfl)
theorem sub95 : model.term 95 = lit95 := by rw [model.app_eq 95 96 97 (by rfl), sub96, sub97]; rfl
theorem sub94 : model.term 94 = lit94 := by rw [model.app_eq 94 95 100 (by rfl), sub95, sub100]; rfl
theorem sub93 : model.term 93 = lit93 := by rw [model.lam_eq 93 94 (by rfl), sub94]; rfl
theorem sub92 : model.term 92 = lit150 := model.var_eq 92 0 (by rfl)
theorem sub91 : model.term 91 = lit119 := by rw [model.lam_eq 91 92 (by rfl), sub92]; rfl
theorem sub90 : model.term 90 = lit118 := by rw [model.lam_eq 90 91 (by rfl), sub91]; rfl
theorem sub89 : model.term 89 = lit150 := model.var_eq 89 0 (by rfl)
theorem sub88 : model.term 88 = lit88 := by rw [model.app_eq 88 89 90 (by rfl), sub89, sub90]; rfl
theorem sub87 : model.term 87 = lit87 := by rw [model.app_eq 87 88 93 (by rfl), sub88, sub93]; rfl
theorem sub86 : model.term 86 = lit86 := by rw [model.lam_eq 86 87 (by rfl), sub87]; rfl
theorem sub85 : model.term 85 = lit131 := model.var_eq 85 1 (by rfl)
theorem sub84 : model.term 84 = lit98 := by rw [model.lam_eq 84 85 (by rfl), sub85]; rfl
theorem sub83 : model.term 83 = lit97 := by rw [model.lam_eq 83 84 (by rfl), sub84]; rfl
theorem sub82 : model.term 82 = lit150 := model.var_eq 82 0 (by rfl)
theorem sub81 : model.term 81 = lit95 := by rw [model.app_eq 81 82 83 (by rfl), sub82, sub83]; rfl
theorem sub80 : model.term 80 = lit80 := by rw [model.app_eq 80 81 86 (by rfl), sub81, sub86]; rfl
theorem sub79 : model.term 79 = lit79 := by rw [model.lam_eq 79 80 (by rfl), sub80]; rfl
theorem sub78 : model.term 78 = lit131 := model.var_eq 78 1 (by rfl)
theorem sub77 : model.term 77 = lit98 := by rw [model.lam_eq 77 78 (by rfl), sub78]; rfl
theorem sub76 : model.term 76 = lit97 := by rw [model.lam_eq 76 77 (by rfl), sub77]; rfl
theorem sub75 : model.term 75 = lit150 := model.var_eq 75 0 (by rfl)
theorem sub74 : model.term 74 = lit95 := by rw [model.app_eq 74 75 76 (by rfl), sub75, sub76]; rfl
theorem sub73 : model.term 73 = lit73 := by rw [model.app_eq 73 74 79 (by rfl), sub74, sub79]; rfl
theorem sub72 : model.term 72 = lit72 := by rw [model.lam_eq 72 73 (by rfl), sub73]; rfl
theorem sub71 : model.term 71 = lit71 := by rw [model.app_eq 71 72 101 (by rfl), sub72, sub101]; rfl
theorem sub70 : model.term 70 = lit150 := model.var_eq 70 0 (by rfl)
theorem sub69 : model.term 69 = lit69 := by rw [model.app_eq 69 70 71 (by rfl), sub70, sub71]; rfl
theorem sub68 : model.term 68 = lit132 := model.var_eq 68 2 (by rfl)
theorem sub67 : model.term 67 = lit131 := model.var_eq 67 1 (by rfl)
theorem sub66 : model.term 66 = lit130 := by rw [model.app_eq 66 67 68 (by rfl), sub67, sub68]; rfl
theorem sub65 : model.term 65 = lit150 := model.var_eq 65 0 (by rfl)
theorem sub64 : model.term 64 = lit128 := by rw [model.app_eq 64 65 66 (by rfl), sub65, sub66]; rfl
theorem sub63 : model.term 63 = lit132 := model.var_eq 63 2 (by rfl)
theorem sub62 : model.term 62 = lit126 := by rw [model.app_eq 62 63 64 (by rfl), sub63, sub64]; rfl
theorem sub61 : model.term 61 = lit125 := by rw [model.lam_eq 61 62 (by rfl), sub62]; rfl
theorem sub60 : model.term 60 = lit131 := model.var_eq 60 1 (by rfl)
theorem sub59 : model.term 59 = lit123 := by rw [model.app_eq 59 60 61 (by rfl), sub60, sub61]; rfl
theorem sub58 : model.term 58 = lit122 := by rw [model.lam_eq 58 59 (by rfl), sub59]; rfl
theorem sub57 : model.term 57 = lit121 := by rw [model.lam_eq 57 58 (by rfl), sub58]; rfl
theorem sub56 : model.term 56 = lit150 := model.var_eq 56 0 (by rfl)
theorem sub55 : model.term 55 = lit119 := by rw [model.lam_eq 55 56 (by rfl), sub56]; rfl
theorem sub54 : model.term 54 = lit118 := by rw [model.lam_eq 54 55 (by rfl), sub55]; rfl
theorem sub53 : model.term 53 = lit117 := by rw [model.app_eq 53 54 57 (by rfl), sub54, sub57]; rfl
theorem sub52 : model.term 52 = lit150 := model.var_eq 52 0 (by rfl)
theorem sub51 : model.term 51 = lit115 := by rw [model.app_eq 51 52 53 (by rfl), sub52, sub53]; rfl
theorem sub50 : model.term 50 = lit132 := model.var_eq 50 2 (by rfl)
theorem sub49 : model.term 49 = lit131 := model.var_eq 49 1 (by rfl)
theorem sub48 : model.term 48 = lit130 := by rw [model.app_eq 48 49 50 (by rfl), sub49, sub50]; rfl
theorem sub47 : model.term 47 = lit150 := model.var_eq 47 0 (by rfl)
theorem sub46 : model.term 46 = lit128 := by rw [model.app_eq 46 47 48 (by rfl), sub47, sub48]; rfl
theorem sub45 : model.term 45 = lit132 := model.var_eq 45 2 (by rfl)
theorem sub44 : model.term 44 = lit126 := by rw [model.app_eq 44 45 46 (by rfl), sub45, sub46]; rfl
theorem sub43 : model.term 43 = lit125 := by rw [model.lam_eq 43 44 (by rfl), sub44]; rfl
theorem sub42 : model.term 42 = lit131 := model.var_eq 42 1 (by rfl)
theorem sub41 : model.term 41 = lit123 := by rw [model.app_eq 41 42 43 (by rfl), sub42, sub43]; rfl
theorem sub40 : model.term 40 = lit122 := by rw [model.lam_eq 40 41 (by rfl), sub41]; rfl
theorem sub39 : model.term 39 = lit121 := by rw [model.lam_eq 39 40 (by rfl), sub40]; rfl
theorem sub38 : model.term 38 = lit102 := by rw [model.app_eq 38 39 51 (by rfl), sub39, sub51]; rfl
theorem sub37 : model.term 37 = lit101 := by rw [model.lam_eq 37 38 (by rfl), sub38]; rfl
theorem sub36 : model.term 36 = lit36 := by rw [model.app_eq 36 37 69 (by rfl), sub37, sub69]; rfl
theorem sub35 : model.term 35 = lit35 := by rw [model.lam_eq 35 36 (by rfl), sub36]; rfl
theorem sub34 : model.term 34 = lit132 := model.var_eq 34 2 (by rfl)
theorem sub33 : model.term 33 = lit131 := model.var_eq 33 1 (by rfl)
theorem sub32 : model.term 32 = lit130 := by rw [model.app_eq 32 33 34 (by rfl), sub33, sub34]; rfl
theorem sub31 : model.term 31 = lit150 := model.var_eq 31 0 (by rfl)
theorem sub30 : model.term 30 = lit128 := by rw [model.app_eq 30 31 32 (by rfl), sub31, sub32]; rfl
theorem sub29 : model.term 29 = lit132 := model.var_eq 29 2 (by rfl)
theorem sub28 : model.term 28 = lit126 := by rw [model.app_eq 28 29 30 (by rfl), sub29, sub30]; rfl
theorem sub27 : model.term 27 = lit125 := by rw [model.lam_eq 27 28 (by rfl), sub28]; rfl
theorem sub26 : model.term 26 = lit131 := model.var_eq 26 1 (by rfl)
theorem sub25 : model.term 25 = lit123 := by rw [model.app_eq 25 26 27 (by rfl), sub26, sub27]; rfl
theorem sub24 : model.term 24 = lit122 := by rw [model.lam_eq 24 25 (by rfl), sub25]; rfl
theorem sub23 : model.term 23 = lit121 := by rw [model.lam_eq 23 24 (by rfl), sub24]; rfl
theorem sub22 : model.term 22 = lit150 := model.var_eq 22 0 (by rfl)
theorem sub21 : model.term 21 = lit119 := by rw [model.lam_eq 21 22 (by rfl), sub22]; rfl
theorem sub20 : model.term 20 = lit118 := by rw [model.lam_eq 20 21 (by rfl), sub21]; rfl
theorem sub19 : model.term 19 = lit117 := by rw [model.app_eq 19 20 23 (by rfl), sub20, sub23]; rfl
theorem sub18 : model.term 18 = lit150 := model.var_eq 18 0 (by rfl)
theorem sub17 : model.term 17 = lit115 := by rw [model.app_eq 17 18 19 (by rfl), sub18, sub19]; rfl
theorem sub16 : model.term 16 = lit132 := model.var_eq 16 2 (by rfl)
theorem sub15 : model.term 15 = lit131 := model.var_eq 15 1 (by rfl)
theorem sub14 : model.term 14 = lit130 := by rw [model.app_eq 14 15 16 (by rfl), sub15, sub16]; rfl
theorem sub13 : model.term 13 = lit150 := model.var_eq 13 0 (by rfl)
theorem sub12 : model.term 12 = lit128 := by rw [model.app_eq 12 13 14 (by rfl), sub13, sub14]; rfl
theorem sub11 : model.term 11 = lit132 := model.var_eq 11 2 (by rfl)
theorem sub10 : model.term 10 = lit126 := by rw [model.app_eq 10 11 12 (by rfl), sub11, sub12]; rfl
theorem sub9 : model.term 9 = lit125 := by rw [model.lam_eq 9 10 (by rfl), sub10]; rfl
theorem sub8 : model.term 8 = lit131 := model.var_eq 8 1 (by rfl)
theorem sub7 : model.term 7 = lit123 := by rw [model.app_eq 7 8 9 (by rfl), sub8, sub9]; rfl
theorem sub6 : model.term 6 = lit122 := by rw [model.lam_eq 6 7 (by rfl), sub7]; rfl
theorem sub5 : model.term 5 = lit121 := by rw [model.lam_eq 5 6 (by rfl), sub6]; rfl
theorem sub4 : model.term 4 = lit102 := by rw [model.app_eq 4 5 17 (by rfl), sub5, sub17]; rfl
theorem sub3 : model.term 3 = lit101 := by rw [model.lam_eq 3 4 (by rfl), sub4]; rfl
theorem sub2 : model.term 2 = lit2 := by rw [model.app_eq 2 3 35 (by rfl), sub3, sub35]; rfl
theorem sub1 : model.term 1 = lit1 := by rw [model.app_eq 1 2 133 (by rfl), sub2, sub133]; rfl
theorem sub0 : model.term 0 = lit0 := by rw [model.app_eq 0 1 142 (by rfl), sub1, sub142]; rfl
theorem allValid (i : Nat) (h : i < 89) : validState i = true := by
 by_cases h48 : i < 48
 · by_cases h24 : i < 24
   · by_cases h12 : i < 12
     · exact FloorIndex.rangeOK_at bl0 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl12 (by omega) (by omega)
   · by_cases h36 : i < 36
     · exact FloorIndex.rangeOK_at bl24 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl36 (by omega) (by omega)
 · by_cases h72 : i < 72
   · by_cases h60 : i < 60
     · exact FloorIndex.rangeOK_at bl48 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl60 (by omega) (by omega)
   · by_cases h84 : i < 84
     · exact FloorIndex.rangeOK_at bl72 (by omega) (by omega)
     · exact FloorIndex.rangeOK_at bl84 (by omega) (by omega)
theorem noClock (n : Nat) : ¬ Count (model.term 0) n := by
 apply FloorIndex.sound model st (by rfl)
 intro i
 by_cases hi : i < 89
 · exact ⟨hs i, allValid i hi⟩
 · refine ⟨hs 0, ?_⟩
   have he : st i = entry := by simp [st,hi]
   unfold FloorIndex.check
   rw [he]
   exact allValid 0 (by decide)
theorem excluded : ¬ IsSelfInterpreter e302824803566 := by
 intro he
 have hp : replay [[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] (call e302824803566 (.lam (.lam (.var 0))) (.lam (.var 0)) (.var 0) [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))),(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))]) = some (model.term 0) := by rw [sub0]; decide
 obtain ⟨h,hh⟩ := clocks_replay (inputCount (k := 2) he (by decide) (by decide)) hp
 exact noClock h hh
#print axioms excluded

end Certgen.R302824803566
